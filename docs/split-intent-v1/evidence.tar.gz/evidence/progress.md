# split-intent increment (D04 part 1) — mid-implementation (2026-09-17)

Baseline committed: 6f3ee42 (storage retirement, 6th increment today).
Task #24 in_progress. SCOPE DECISION (recorded in handoff-in.md +
docs/HORIZONTAL-SCALING-PLAN.md context): D04 proceeds in increments like
D03; THIS increment is committed split-intent AUTHORITY ONLY (kind 107,
KV9SPL01) — no sealing, no child population, no directory republication,
no rerouting. The rigid single-range read model in ranges.rs read_in
(unsealed, empty start/end, version 1, one range per keyspace/region)
stays untouched this increment; generalizing it to a partition (sorted
children, no overlap/gap) happens in the publication increment.

## DONE (uncommitted, compiles, tests green)
- crates/meta/src/data_groups/split.rs: SplitIntent{root,operation,task,
  parent_bind_task,parent_region,child_low,child_high,split_key(1..1024)};
  layout 96B header + 2B keylen + key (offsets: op 40, task 56, parent_bind
  64, parent_region 72, child_low 80, child_high 88, keylen 96, key 98);
  plan_split(txn, operation, parent_region, split_key, child_low, child_high)
  — parent binding must exist unsealed (bind_task recorded), split key
  strictly inside parent, children = committed+ACTIVATED+UNBOUND creations
  with EXACTLY the parent replica set, one live split per parent region,
  idempotent confirm; committed_splits readback re-runs validate_against.
- ranges.rs: CommittedRange gains bind_task() (kind-102 row id);
  pub(crate) committed_ranges_in_txn.
- data_groups.rs: pub mod split.
- 2 catalog tests green (cargo test -p kv9-meta --lib data_groups::split):
  refusals (unbound parent/identical children/missing child), idempotent
  confirm, second-key + second-op-per-parent refusals; defect matrix over
  task/state/created/truncated/parent-bind(71)/child-low(87)/child-high(95)
  (operation & split key are self-authoritative → excluded, like
  migration's test rationale).

## REMAINING (follow the 6 prior increments' exact pipeline this session)
1. Server: proto RecordSplitIntent{root_digest,operation_id,parent_region,
   split_key,child_low_task,child_high_task} -> {task,changed}; api.rs
   RecordSplitIntentResult{intent,changed,applied} + trait default; grpc
   handler (copy record_source_removal shape; validate 16B op, nonzero,
   split_key 1..1024); runtime backend record_split_intent (catalog txn +
   plan_split, mirror record_source_removal WITHOUT extra runtime checks);
   client tests/batch_tests/workload-loopback macro stubs; data_groups.rs
   client method; CLI record-split-intent (--parent-region --split-key-hex
   --child-low-task --child-high-task) + main.rs dispatch + help line.
2. e2e scripts/split-intent-e2e.py: derive from runtime-install-e2e.py,
   port 26960, tokens split-e2e-*; KEEP harness up to 'public route
   serves' (route-probe block), CUT everything after (migrate onwards)
   until the manifest verdict update, replace with: create-group-b/c
   (operations 2,3, voters 1,2,3, create-data-group only — NO keyspace
   bind) → record-split-intent early with wrong parent region → refuse →
   record with parent region (from created['region_id'] of the FIRST
   group... note: parent must be the BOUND keyspace group from the base
   script) split key '6d' children task ids → recorded → retry confirmed
   → divergent key refuse → second op same parent refuse; verdict checks
   list updated; drop node-4 join? base script starts 4 nodes — keep(
   simplest) but skip attach steps. Also drop MinIO focused deps? env
   still needed by harness (KV9_STORAGE=minio).
3. Lean model proofs/lean/split-intent/Split.lean (~11 thms): intent
   requires bound unsealed parent + two activated unbound children with
   parent replicas; one intent per parent; intent alone seals/reroutes
   nothing (sealed/rerouted fields never set); permanence; existence
   chain. Controls ~7 (intent-without-parent, intent-onto-sealed-parent,
   children-not-activated, children-bound, child-equals-parent,
   intent-reroutes, commit-serves). Runner scripts/prove-split-intent.py
   (copy prove-replica-removal.py pattern; rename SPLIT_INTENT_PROOF_
   ACCEPTED). README table. contract pins: split.rs, ranges.rs,
   data_groups.rs, runtime.rs, api.rs, grpc.rs, server data_groups.rs,
   proto, cli, main, e2e script, model files.
4. docs/SPLIT-INTENT.md + HORIZONTAL-SCALING-PLAN.md sentence (after
   storage-retirement sentence: split intents committed; sealing/
   publication next). fmt/clippy zero; contract + sibling refresh (glob
   snippet); qualify.sh: copy retirement qualify.sh, s/retirement/split/,
   add split-intent to model list (17 models).
5. Packaging: copy retirement build-local-validation.py +
   package-storage-retirement.py → split versions (rename dirs/proof
   names; e2e-first; theorems/controls counts). Packet
   docs/split-intent-v1; portable readback; README.
6. Commit "Commit split intents for bound ranges" style + push; issues #9
   (replace S05/D03 checkpoint para with S05/D04 split-intent checkpoint,
   ≤65536!) + #24 or #25 (D04 issue is #25 — check `gh issue view 25`
   title first; append checkpoint there; #24 got the D03-closed note
   already); publication.json + next handoff (next: parent seal increment
   — seal the parent range row + group-level write fence at the split
   key... details in HORIZONTAL-SCALING-PLAN D04 row).
Conventions: MinIO creds joint-install-20260916/minio-first/; qualify
pattern; user-facing Chinese; repo/GitHub English; retain failures;
untouched: checkpoint-publication-chaos.py, checkpoint-owned-crash.py.
