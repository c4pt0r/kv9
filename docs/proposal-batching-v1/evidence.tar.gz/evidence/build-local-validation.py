import json, re, subprocess
from pathlib import Path

work = Path('/mnt/data/kv9-work/proposal-batching-20260917')
root = Path('/home/dongxu/kv9')

text = (work / 'workspace-serial.log').read_text()
tallies = [(int(a), int(b), int(c)) for a, b, c in re.findall(
    r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
serial = {
    'suites': len(tallies),
    'passed': sum(t[0] for t in tallies),
    'failed': sum(t[1] for t in tallies),
    'ignored': sum(t[2] for t in tallies),
    'exit_code': 0,
    'log': 'workspace-serial.log',
}
assert serial['failed'] == 0 and serial['suites'] > 0

minio = (work / 'minio-focused.log').read_text()
m = re.findall(r'test result: ok\. (\d+) passed; 0 failed', minio)
assert m, 'minio focused run must pass'

batching = json.loads((work / 'proposal-batching-proof/result.json').read_text())
assert batching['accepted'] and batching['theorems'] == 15 and batching['semantic_controls'] == 5

siblings = {}
for model in ['data-range', 'group-activation', 'group-control', 'group-preparation',
              'joint-install', 'learner-attach', 'migration-authority',
              'protocol-snapshot', 'routed-client', 'source-capture', 'runtime-adoption',
              'install-evidence', 'source-truncation', 'voter-promotion', 'replica-removal',
              'storage-retirement', 'split-intent', 'partition-directory', 'parent-seal',
              'child-population', 'split-publication', 'parent-retirement', 'cross-range',
              'auto-split', 'cascade-split', 'storage-reclamation', 'migration-abort']:
    r = json.loads((work / f'{model}-proof/result.json').read_text())
    assert r['accepted'], model
    siblings[model] = {'theorems': r['theorems'], 'semantic_controls': r['semantic_controls']}

retention = (work / 'retention-ledger-recheck.log').read_text()
assert 'PASS: retention ledger' in retention.splitlines()[-1]

e2e = json.loads((work / 'e2e-second/result.json').read_text())
assert e2e['verdict'] == 'accepted'
first = json.loads((work / 'e2e-first/result.json').read_text())
assert first['verdict'] == 'accepted'
bench = json.loads((work / 'bench-fourth/result.json').read_text())
assert bench['accepted'] is False, 'the failed predeclared targets are the published truth'
assert bench['verdicts']['t3']['passed'] and not bench['verdicts']['t1']['passed'] and not bench['verdicts']['t2']['passed']

clippy = subprocess.run(
    ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'kv9-raft/testing'],
    cwd=root, capture_output=True, text=True)
warnings = len(re.findall(r'^warning:', clippy.stderr, re.M))
assert clippy.returncode == 0 and warnings == 0, (clippy.returncode, warnings)

out = {
    'schema': 1,
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'workspace': {'serial': serial},
    'lint': {'clippy_warnings': 0},
    'minio_focused': {'passed': int(m[-1]), 'log': 'minio-focused.log'},
    'proposal_batching_model': {
        'theorems': batching['theorems'],
        'semantic_controls': batching['semantic_controls'],
        'policy_controls': batching['hole_and_axiom_controls'],
        'result': 'proposal-batching-proof/result.json',
    },
    'sibling_lean_models': siblings,
    'retention_tlaps': {'log': 'retention-ledger-recheck.log', 'line': retention.splitlines()[-1]},
    'e2e': {'verdict': e2e['verdict'], 'checks': e2e['checks'], 'result': 'e2e-second/result.json'},
    'also_accepted': {'runs': ['e2e-first/result.json']},
    'bench': {'accepted': False, 'verdicts': bench['verdicts'],
              'result': 'bench-fourth/result.json',
              'failed_attempts_retained': ['bench-first-crashed-compute', 'bench-second', 'bench-third']},
    'not_claimed': ['ANY throughput or latency improvement (predeclared targets T1/T2 failed; feature default OFF), '
                    'backpressure budgets, dual-WAL unification, per-tenant fairness, chaos, scaling, hosted CI'],
}
(work / 'local-validation.json').write_text(json.dumps(out, indent=2) + '\n')
print('local-validation.json written; serial', serial)
