# Proposal batching / group commit (#20 slice) — task #31

Baseline: e00c1f1. Fixture port 27120. Serial suite 939.

## Scope (bounded slice of #20)
IN: proposal AGGREGATION for public raw writes on data groups — coalesce
in-flight same-group SAME-EPOCH fenced writes into one raft entry
(Command::fenced_write_from_batch with merged batch), ONE propose + ONE
async apply wait, exact shared (term,index) receipt fanned out to every
participant. Bounded by ops count, bytes and a delay window; env-gated
default OFF (KV9_PROPOSAL_BATCH_OPS=0 disabled; KV9_PROPOSAL_BATCH_DELAY_MS
bounded). Group commit at Ready-persist and engine-apply layers ALREADY
exists (one fsync per Ready batch / per apply batch) — measured, not
rebuilt.
OUT (explicit): backpressure budgets across layers (#20 item 3-4), C04
dual-WAL unification (item 5), per-tenant fairness (T03), metadata
catalog txn batching (term-fenced semantics untouched), chaos.

## Write path facts (surveyed)
- crates/server/src/runtime/range_api.rs prepare_raw_write:
  permit(epoch) -> plan batch -> Command::fenced_write_from_batch(
  permit.0, &batch) -> driver.propose_with_async_wait -> finish_async_
  proposal. commit() is the sync path (propose_and_wait) used by raw_put
  etc; grpc raw writes go through prepare_raw_write (async).
- Epoch fence: merged commands MUST share the permit epoch; coalesce
  only equal-epoch. Order within merged batch = arrival order.
- driver.propose one raft entry per Command; Ready persistence already
  batches entries per sync_data (storage.rs:647); engine WAL applies a
  batch under one CRC+fsync (wal.rs:491).

## PREDECLARED acceptance (BEFORE any timing; never revise)
Benchmark fixture: single host, 3 voters, 1 data group, real MinIO OFF
(KV9_STORAGE default local) to isolate fsync effects; identical
durability settings both sides; concurrency C=32 parallel writers, N=4000
raw-puts of 64B values total (predeclared here, before first run):
- T1 throughput: batched (OPS=16, DELAY=2ms) >= 1.4x unbatched puts/s.
- T2 fsync: raft-log sync_data count for the fill reduced >= 2.0x.
- T3 low-concurrency cost: C=1 sequential 200 puts, batched p99 latency
  <= unbatched p99 + 25ms (the delay-window cost bound).
- T4 correctness gates: serial suite green; every written key reads
  back; receipts exact (applied position nonzero, read-your-write).
If any target fails: publish the numbers as a FAILED attempt, keep the
feature default-off, do not revise targets.

## Plan
1. Aggregator in range_api.rs (per RawGroup): pending queue of
   (epoch, WriteBatch ops, oneshot); leader-side flusher merges caps
   {ops<=KV9_PROPOSAL_BATCH_OPS, bytes<=1MiB, delay<=KV9_PROPOSAL_BATCH_
   DELAY_MS}; single propose_with_async_wait; fan-out position.
2. Unit tests: merge order, epoch segregation, caps, receipt fan-out,
   disabled-mode passthrough identical to today.
3. Lean model proofs/lean/proposal-batching/: no cross-epoch merge; a
   batch applies atomically at one position; every participant receives
   exactly the batch position; disabled mode == passthrough; no
   reordering within epoch.
4. Bench script scripts/batching-bench.py (local, no MinIO需求?
   qualify e2e uses MinIO fixture as usual for the e2e; the BENCH runs
   local storage both sides) writing raw results (before/after, fsync
   counts from metrics.json, batch distributions).
5. e2e scripts/proposal-batching-e2e.py port 27120: batched fill +
   readback + restart + a mid-fill split (epoch change) proving fence
   correctness under batching.
6. qualify (28 models) + packet docs/proposal-batching-v1 + issues #9 +
   #20 + publication.

## Status
- [x] survey + scope + predeclared targets
- [x] aggregator impl (range_api.rs WriteAggregator: stage->Staged::{Joined,Leader}; leader select(sleep delay, flush.notified) -> take -> retire slot -> ONE fenced merged command via unchanged propose/finish_async_proposal -> SharedError-typed fan-out preserving NotLeader/StaleEpoch; env KV9_PROPOSAL_BATCH_OPS (0=off default) + KV9_PROPOSAL_BATCH_DELAY_MS clamp 50; sync commit() path unbatched by design)
- [x] 4 aggregator unit tests (merge order, fence mismatch, ops/bytes caps, taken-batch never admits, SharedError typing)
- [x] Lean model 15 theorems COMPILES (constructor names: openBatch/takeBatch/applyBatch — `open`/`apply` reserved!) + prover written (5 semantic + 2 policy) + README + contract SKELETON (source_sha256 EMPTY — fill after e2e script exists, then run prover)
- [ ] bench: USE scripts/build-workload.py + target/debug (or release) kv9-workload (concurrent driver: workers/mix/measure_ms; benchmark.py shows invocation pattern: config JSON WorkloadConfig v1 + --build-manifest from build-workload). Two server fixtures same host: OPS=0 vs OPS=16 DELAY=2. Also C=1 latency run. fsync counts from node metrics.json (WalIoMetrics sync counters) before/after fill. Targets in this file are FINAL (T1 1.4x, T2 2.0x, T3 +25ms).
- [ ] e2e scripts/proposal-batching-e2e.py port 27120: 3 voters + group + keyspace; KV9_PROPOSAL_BATCH_OPS=16 DELAY=2 + KV9_AUTO_SPLIT_BYTES=8192 (epoch change mid-batching); concurrent fills via ThreadPoolExecutor of CLI raw-puts (server-side aggregation across concurrent RPCs); all keys read back; restart; survives. Derive skeleton from cascade-split-e2e.py (port/env/fill loop)
- [ ] qualify + packet + publish
