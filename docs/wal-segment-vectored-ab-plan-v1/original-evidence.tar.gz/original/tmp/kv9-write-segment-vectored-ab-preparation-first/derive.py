"""Finite identity/path derivative only; imports no driver/auditor/test/codec."""
import ast,difflib,hashlib,json,os,re,time
from pathlib import Path
H=Path(__file__).resolve().parent
O=Path('/tmp/kv9-write-crc-slicing8-ab-preparation-first')
C=Path('/tmp/kv9-write-crc-slicing8-ab-campaign-root-second')
S=Path('/tmp/kv9-write-segment-vectored-first')
BUILD=Path('/tmp/kv9-write-segment-vectored-release-first')
REV='cfd9c927f8ecd33974100f696e6b08b227d25a41'
SERVER='c88b79b53f10f76f4bb87c4293e1dd0de0a753e13dc1cce27bd0b44d45694581'
pins={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p.stat().st_size<=8*1024**2
 b=p.read_bytes();pins[str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};return json.loads(b)
def save(n,d):(H/n).write_text(json.dumps(d,indent=2)+'\n')
def copy(p,q):
 p=Path(p);q.parent.mkdir(parents=True,exist_ok=True);assert p.is_file() and not p.is_symlink();q.write_bytes(p.read_bytes())
oldinv=read(O/'inventory.json');assert pins[str(O/'inventory.json')]['sha256']=='de26af8d419cc7c1693259098bad1e51e47f81468d54a7a9034d215f9e1105ab'
for n,b in oldinv['files'].items():
 p=O/n;assert p.stat().st_size==b['bytes'] and sha(p)==b['sha256']
 copy(p,H/'origins/accepted-crc-preparation'/n)
 if n.startswith('origins/'):copy(p,H/n)
copy(O/'inventory.json',H/'origins/accepted-crc-preparation/inventory.json')
for n in ['check-smoke.py','check-smoke-corrected.py','smoke-checker-import-repair.json','smoke-readback/result.json']:
 copy(C/n,H/'origins/smoke-checker-lineage'/n)
copy('/tmp/kv9-write-crc-slicing8-ab-contract-root-first/result.json',H/'origins/accepted-controls/result.json')
man=read(BUILD/'build.json');assert man['revision']==REV and man['dirty'] is False and man['profile']=='release'
assert man['binaries']['kv9']['sha256']==SERVER and man['binaries']['kv9']['command']==['cargo','build','--locked','--bin','kv9','--release','--message-format=json-render-diagnostics']
MAN=pins[str(BUILD/'build.json')]['sha256']
rep={str(O):str(H),'kv9-write-crc-slicing8-ab-c1-c64-v1':'kv9-write-segment-vectored-ab-c1-c64-v1',
 '/tmp/kv9-write-crc-slicing8-ab-smoke-first':'/tmp/kv9-write-segment-vectored-ab-smoke-first',
 '/tmp/kv9-write-crc-slicing8-ab-timing-first':'/tmp/kv9-write-segment-vectored-ab-timing-first',
 '/tmp/kv9-write-crc-slicing8-thinlto-first':str(S),'/tmp/kv9-write-crc-slicing8-release-first':str(BUILD),
 'e748620a7b0ba326ac5f4fa8e3a6b1ff48553c6a':REV,
 '616eed1b823dfaa192a22b2b03a3e7d778bf71efdad7d2b875a49c4bfc94e476':SERVER,
 '32cf899d55b7160f5c3aacfff24da0d145d381e5082b2a6925b94b4cedcf1463':MAN,
 'bffee183d7ac80161f44bd67c4b1e391bd7914fe9d6c0ed174bbd94305bbfa01':man['source_tree_sha256']}
def substitute(text):
 return re.sub('|'.join(re.escape(k) for k in sorted(rep,key=len,reverse=True)),lambda m:rep[m[0]],text)
for n in ['compressed_retention.py','retention_audit.py','isolate-and-run.py']:(H/n).write_text(substitute((O/n).read_text()))
for n in ['compressed_retention.py','retention_audit.py']:rep[oldinv['files'][n]['sha256']]=sha(H/n)
args=json.loads(substitute((O/'driver-arguments.json').read_text()));save('driver-arguments.json',args)
rep[oldinv['files']['driver-arguments.json']['sha256']]=sha(H/'driver-arguments.json')
for n in ['matched-driver.py','audit.py','test_driver.py','test_audit_contract.py','test_smoke_schema.py']:(H/n).write_text(substitute((O/n).read_text()))
for n in ['matched-driver.py','audit.py']:rep[oldinv['files'][n]['sha256']]=sha(H/n)
smoke=(C/'check-smoke-corrected.py').read_text();assert sha(C/'check-smoke-corrected.py')=='db6f7c1b8ff12534b96cb0d1b24d9470a0c60989f992b04bd14ed92857c2136a'
(H/'check-smoke-corrected.py').write_text(substitute(smoke))
# Retain exact descriptors; role names are old/new and do not encode candidate revision.
copy(O/'expected-descriptors.json',H/'expected-descriptors.json')
proto=json.loads(substitute((O/'protocol.json').read_text()));proto['role_labels']['new']='isolated segmented-WAL vectored cfd9c927';proto['runtime_ready']=False;proto['contracts_executed']=False;proto['capacity_qualified']=False
for n,key in [('compressed_retention.py','helper'),('retention_audit.py','independent_reader')]:proto['compressed_retention'][key]={'bytes':(H/n).stat().st_size,'sha256':sha(H/n)}
proto['driver_sha256']=sha(H/'matched-driver.py');proto['auditor_sha256']=sha(H/'audit.py');save('protocol.json',proto)
commands=json.loads(substitute((O/'commands.json').read_text()));commands['runtime_commands_released']=False
commands['smoke_readback_after_smoke_terminal']=commands['contracts_root_only'][0][:-1]+[str(H/'check-smoke-corrected.py')]
save('commands.json',commands)
b=read(O/'build-bindings.json');b=json.loads(substitute(json.dumps(b)))
role=b['roles']['new'];role.update(source=str(S),build=str(BUILD),revision=REV,dirty=False,source_tree_sha256=man['source_tree_sha256'],manifest_sha256=MAN,executable=str(BUILD/'kv9'),executable_sha256=SERVER,rustc=man['rustc'],profile='release')
# Preserve selected/client original input hashes; bind new original release/recovery separately.
b['original_readback_inputs']={k:v for k,v in b['original_readback_inputs'].items() if 'write-crc-slicing8' not in k}
prior_pins=read(O/'original-input-pins.json')
for path,binding in prior_pins.items():
 if 'write-crc-slicing8' in path:continue
 q=Path(path);assert q.stat().st_size==binding['bytes'] and sha(q)==binding['sha256'];pins[path]=binding
new_inputs=[BUILD/'build.json',BUILD/'kv9-cargo.jsonl',BUILD/'kv9-build.log',
 Path('/tmp/kv9-write-segment-vectored-release-root-first/readback-first/result.json'),
 Path('/tmp/kv9-write-segment-vectored-recovery-preparation-first/release-binding.final.json'),
 Path('/tmp/kv9-write-segment-vectored-recovery-preparation-first/process-terminal.json'),
 Path('/tmp/kv9-write-segment-vectored-recovery-preparation-first/audit-terminal.json'),
 Path('/tmp/kv9-write-segment-vectored-recovery-audit-first/audit.json'),
 Path('/tmp/kv9-write-segment-vectored-chaos-status-publication-first/completed-stage-handoff.json')]
for q in new_inputs:
 assert q.is_file() and q.stat().st_size<8*1024**2
 raw=q.read_bytes();pins[str(q)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 b['original_readback_inputs'][str(q)]=pins[str(q)]
chaos=read(new_inputs[-1]);rec=read(new_inputs[-2]);release=read(new_inputs[3])
assert chaos['complete'] and chaos['source_revision']==REV and chaos['no_active_builds_benchmarks_or_codecs'] and chaos['active_sessions']==[]
qualification_path=Path(chaos['qualification']['path']);qualification=read(qualification_path)
assert pins[str(qualification_path)]['sha256']==chaos['qualification']['sha256']
assert qualification['complete'] and qualification['revision']==REV and qualification['server_sha256']==SERVER
assert qualification['windows']==21 and qualification['operations']==9636 and qualification['namespace_removed'] and qualification['archive_verified']
assert not qualification['workload_rerun'] and not qualification['post_rerun']
b['original_readback_inputs'][str(qualification_path)]=pins[str(qualification_path)]
assert rec['accepted'] and rec['complete'] and rec['revision']==REV and rec['server_sha256']==SERVER and rec['owned_lifetimes_exited']
assert release['complete'] and release['revision']==REV
save('build-bindings.json',b)
save('prerequisites.json',{'source_revision':REV,'release_readback':{'path':str(new_inputs[3]),**pins[str(new_inputs[3])]},'ordinary_recovery':{'path':str(new_inputs[-2]),**pins[str(new_inputs[-2])]},'completed_chaos_handoff':{'path':str(new_inputs[-1]),**pins[str(new_inputs[-1])]},'completed_chaos_scope':'Exact default-feature21-window Chaos plus baseline and full ordinary histories; original runtime and post both passed once. Historical parser/receipt repair lineage remains separately retained. This is a prerequisite, not new performance acceptance.','runtime_ready':False,'capacity_qualified':False})
for n in ['batch_benchmark_report.py','redis_batch_report.py','workload_report.py','history/checker.py']:
 q=Path('/tmp/kv9-point-write-measurement-v3/scripts')/n;raw=q.read_bytes();pins[str(q)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
q=Path('/tmp/kv9-redis-batch-reference-preparation/run_fixture.py');raw=q.read_bytes();pins[str(q)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
scenario_path=Path('/tmp/kv9-write-crc-slicing8-full-regression-preparation-first/capacity-scenario.json');scenario=read(scenario_path);G=1024**3;v=os.statvfs('/tmp');available=v.f_bavail*v.f_frsize
required=96*G+scenario['write_screen_compressed_bytes']+16*G+G
save('capacity.pending.json',dict(observed_ns=time.time_ns(),observed_available_bytes=available,retention_floor_bytes=96*G,reference_path=str(scenario_path),reference_sha256=pins[str(scenario_path)]['sha256'],empirical_same_shape_compressed_bytes=scenario['write_screen_compressed_bytes'],empirical_same_shape_logical_bytes=scenario['write_screen_logical_bytes'],one_cohort_restore_reserve_bytes=16*G,metadata_scenario_margin_bytes=G,empirical_required_available_bytes=required,empirical_shortfall_bytes=max(0,required-available),capacity_ready=False,guaranteed_fit=False,prior_cold_or_cache_credit_bytes=0,limits=proto['compressed_retention']['limits'],scope='Accepted CRC8-smoke+16-timing retained volume is an empirical planning comparison only, not a bound on unrun vectored throughput or storage. Root must separately qualify actual capacity and all unchanged per-cohort guards. No storage mutation authorized.'))
save('original-input-pins.json',pins)
changes={}
for n in ['matched-driver.py','audit.py','isolate-and-run.py','compressed_retention.py','retention_audit.py','test_driver.py','test_audit_contract.py','test_smoke_schema.py','check-smoke-corrected.py']:
 source=C/n if n=='check-smoke-corrected.py' else O/n;old=source.read_text();new=(H/n).read_text();ast.parse(new)
 assert substitute(old)==new,n
 of={x.name:ast.get_source_segment(old,x) for x in ast.parse(old).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))};nf={x.name:ast.get_source_segment(new,x) for x in ast.parse(new).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
 assert set(of)==set(nf)
 for k in of:assert substitute(of[k])==nf[k],(n,k)
 changes[n]={'only_declared_literal_substitutions':True,'byte_identical_functions_classes':[k for k in of if of[k]==nf[k]],'literal_only_functions_classes':[k for k in of if of[k]!=nf[k]],'removed':[],'added':[]}
 (H/(n+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(source),tofile=str(H/n))))
for n in ['driver-arguments.json','protocol.json','commands.json','build-bindings.json']:
 (H/(n+'.diff')).write_text(''.join(difflib.unified_diff((O/n).read_text().splitlines(True),(H/n).read_text().splitlines(True),fromfile=str(O/n),tofile=str(H/n))))
counts={n:sum(isinstance(x,ast.FunctionDef) and x.name.startswith('test_') for x in ast.walk(ast.parse((H/n).read_text()))) for n in ['test_driver.py','test_audit_contract.py','test_smoke_schema.py']};assert list(counts.values())==[8,15,5]
oldp=json.loads((O/'protocol.json').read_text())
for key in ['smoke_inventory','timed_inventory','expected_counts','smoke_placement','timed_placement','workload_cells','storage_guards','effective_server_limits','concurrency_points','configured_max_attempts']:assert oldp[key]==proto[key],key
assert oldp['compressed_retention']['limits']==proto['compressed_retention']['limits']
save('substitutions.json',rep);save('function-delta.json',changes)
save('STATIC.json',{'complete':True,'scope':'Static syntax, source-literal inverse and frozen-descriptor equality only; no imports, tests, validators or workload execution','contracts_prepared':counts,'all_runtime_script_changes_declared_literal_only':True,'descriptors_counts_cpu_storage_limits_unchanged':True,'native_v3_smoke_import_preserved':True,'original_preparation_inventory_sha256':sha(O/'inventory.json'),'candidate_source_files':len(man['sources']),'candidate_source_tree_sha256':man['source_tree_sha256'],'candidate_manifest_sha256':MAN,'candidate_server_sha256':SERVER,'runtime_ready':False})
print(json.dumps({'complete':True,'static_only':True,'contracts_prepared':counts,'driver':sha(H/'matched-driver.py'),'audit':sha(H/'audit.py'),'manifest':MAN,'capacity_empirical_required':required,'capacity_observed_available':available,'capacity_empirical_shortfall':max(0,required-available)}))
