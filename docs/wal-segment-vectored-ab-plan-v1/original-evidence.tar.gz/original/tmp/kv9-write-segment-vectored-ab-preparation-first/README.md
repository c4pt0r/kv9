# Vectored WAL matched write comparison preparation

This binds the accepted write comparison to exact candidate cfd9c927f8ecd33974100f696e6b08b227d25a41 and its original default ThinLTO release. The selected11113f6 server and fixed native-v3 benchmark client remain unchanged. The candidate correctness client is never substituted for the timing client.

Eight fresh two-second smokes precede sixteen ten-second timed cohorts: point Put and BatchPut(64), concurrency1/64,128-byte values,4096 keys plus sentinel,seed71,warmup128,max_calls10,000,000,closed-loop tonic_stream,1500ms deadline and the original retry policy. The second timed repetition reverses the entire first order. Every outcome, attempt, dropped call and whole-call latency histogram remains available; healthy one-attempt comparison is a separate suitability check. Unknown writes are not replayed.

Timed clients use CPUs0–1 and all three voters share CPUs2–5. Smokes use clients6–7 and voters8–15,22–31. Preserve Raft commit, sync, durable apply, response fences, final replica drains, full dataset/sentinel/nonce checks, observed lifetimes, CPU accounting and independent retained-byte audit. No builds, tests, proofs, profilers, faults or codecs may overlap timing.

Source proofs,714 workspace tests/doctests (23 existing ignored), exact release,352 ordinary recovery operations and9,636 operations in21 actual Chaos Mesh windows already pass. They are hash-bound prerequisites, not comparison observations. `build-bindings.json`, `prerequisites.json` and `original-input-pins.json` retain actual records. The benchmark driver still checks original selected/candidate/client bytes and complete source identities before and after execution.

`derive.py`, declared literal substitutions and per-file diffs reproduce from the accepted CRC harness. `frame-equivalence.json` independently confirms the runtime, reader and28 original controls differ from the current frame harness only in candidate identity, paths and dependent hashes. Descriptors, accounting predicates, retry behavior and every resource limit are unchanged. Historical failures remain in the original lineage.

`commands.json` preserves the full sequence: root contracts; fresh capacity/source/environment release; all eight smokes and independent smoke readback; all sixteen timed cohorts; complete independent audit; then throughput and tail-latency reporting. Runtime commands are unreleased. The three local suites contain8 driver,15 auditor and5 smoke-schema controls. A control result does not authorize workloads or prove a speedup.

Capacity is unresolved. `capacity.json` uses the accepted whole resident reference of48,819,441,664bytes, plus the unchanged96GiB floor,16GiB single-cohort restore reserve and1GiB metadata margin:170,152,267,776bytes required as an empirical scenario. This is not a bound on an unrun candidate. The earlier object-only estimate is preserved separately and is superseded. Retain8GiB/member,16GiB/cohort,128GiB combined logical/physical campaign,65536 files,600s codec/1800s cohort,64MiB decode memory and8MiB metadata limits. No previous cleanup credit is reused.

No benchmark, storage mutation, build or codec was executed by this preparation. Full mixed/read regressions, Redis parity, real-disk/cross-host/power-loss behavior and default promotion remain separate gates.
