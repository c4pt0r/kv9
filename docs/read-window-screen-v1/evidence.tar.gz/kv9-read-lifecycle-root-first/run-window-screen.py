import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
PREP=Path('/tmp/kv9-read-window-screen-preparation-first')
ROOT=Path('/tmp/kv9-read-lifecycle-root-first')
def verify():
 inventory=json.loads((PREP/'inventory.json').read_text())
 for name,expected in inventory.items():
  data=(PREP/name).read_bytes()
  if len(data)!=expected['bytes'] or hashlib.sha256(data).hexdigest()!=expected['sha256']:
   raise RuntimeError('frozen preparation differs: '+name)
 return hashlib.sha256((PREP/'inventory.json').read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('phase',choices=['smoke','timing','audit']);p.add_argument('--root-session');args=p.parse_args()
keys={'smoke':'smoke_root_only','timing':'timing_root_only_after_release','audit':'audit_only_after_exact_terminal_release'}
command=json.loads((PREP/'commands.json').read_text())[keys[args.phase]]
if args.phase=='audit':
 if not args.root_session:raise RuntimeError('terminal timing session required')
 command=[args.root_session if v=='ROOT_TERMINAL_TIMING_SESSION' else v for v in command]
out=ROOT/('window-screen-'+args.phase+'-first');out.mkdir()
record={'complete':False,'argv':command,'started_ns':time.time_ns(),'preparation_inventory_sha256':verify()}
try:
 with (out/'output.log').open('x') as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
  record['child_pid']=child.pid
  (out/'invocation.json').write_text(json.dumps(record,indent=2)+'\n')
  record['exit_code']=child.wait()
 record['ended_ns']=time.time_ns()
 if record['exit_code']!=0:raise RuntimeError('first '+args.phase+' attempt failed; see retained output.log')
 if verify()!=record['preparation_inventory_sha256']:raise RuntimeError('preparation changed during run')
 record['complete']=True
finally:
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS:',args.phase,'first attempt terminal; preparation unchanged')
