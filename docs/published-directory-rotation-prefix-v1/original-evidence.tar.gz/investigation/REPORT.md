# Original rotation supplement failure

The original run failed before Chaos target selection. This is a fixture namespace opt-in omission, not observed database recovery failure or a transient AllInjected wait.

The retained original command 115 timed out. The existing controller has `ENABLE_FILTER_NAMESPACE=true`. Its log at 2026-09-15T00:35:11.233Z says `namespace is not enabled for chaos-mesh`; the immediately following records-controller errors say `no pod is selected`. The owned PodChaos has Selected=false, AllInjected=false and no container records. Kubernetes failure events carry the same selection refusal. All three original voter containers still had restartCount=0, unchanged container IDs, Serving/empty-fatal status, leader 2 and committed/applied/driver-applied index 51 at the read-only observation.

The unchanged accepted ancestor `origin/full21.sh:599` explicitly annotates its newly created namespace `chaos-mesh.org/inject=enabled`. The supplement runner omitted that annotation. No new fault was injected, retried, reapplied or removed during investigation. Current observations cannot constitute post-fault recovery acceptance.

Original runtime: session 74027, actual tool terminal 00a0c3/1. Namespace `kv9-pdrot-1789432467-2626851`, UID `e647df5a-1bfa-45ec-8ceb-6ff96250b8ef`; fault UID `74f53097-29b5-425a-be96-cab0f8b5dec3`. Original failed inputs/results remain unchanged. A separate partial reader will independently validate the complete pre-burst history and all three selected topology/header observations without changing the failed outcome.

Read-only observations were retained in this directory with argv/timestamps/exit records (tools 1dbc27, 9cff7b, 1b1134, 100288; exit 0). The initial command/source reads are tools 176c21, 00d0e9, f09523, 0f0485, e375c7. No workload, compiler, payload scan or codec ran.
