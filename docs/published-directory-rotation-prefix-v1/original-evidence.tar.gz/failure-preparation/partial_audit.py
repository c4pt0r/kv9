#!/usr/bin/env python3
"""Independent retained-prefix check of one explicitly failed rotation supplement."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback

OWN=Path(__file__).resolve().parent
AUTH=json.loads((OWN/'authority.json').read_text())
sys.path.insert(0,AUTH['original_preparation'])
import audit as original_audit
from checks import digest,load,read,require
from runner import verify_preparation

def authority():
    for path,row in AUTH['inputs'].items():
        data=read(path,16*1024*1024)
        require(len(data)==row['bytes'] and digest(data)==row['sha256'],'failed original authority changed')
    result=load(Path(AUTH['original_run'])/'result.json')
    require(result['complete'] is False and result['accepted'] is False and result['command_count']==116 and
            result['failure']=="ValueError('command failed, original outputs retained: command-0115')",
            'failure type/count differs from preserved attempt')
    terminal=load(Path(AUTH['original_root'])/'runtime-terminal.json')
    require(terminal['complete'] is False and terminal['exit_code']==1 and terminal['session_id']==74027 and
            terminal['terminal_receipt']=='00a0c3/1',
            'actual failed runtime terminal differs')
    require(not Path('/proc/'+str(result['controller']['pid'])).exists(),'original runtime controller still exists')
    return result,terminal

class FailedEvidence(original_audit.Evidence):
    def __init__(self,root,p):
        self.root=Path(root);self.p=p;self.inventory={};self.commands={}
        self.result=self.json('result.json')
        for n in range(116):
            stem=f'command-{n:04d}'
            start=self.json(stem+'.start.json');row=self.json(stem+'.result.json');child=self.json(stem+'.child.json')
            require(start['argv']==row['argv'] and row['child']==child and row['complete'] is True and
                    row['reaped'] is True and row['failure'] is None and row['ended_ns']>=row['started_ns'],
                    'original command incomplete/changed')
            require(row['exit_code']==(1 if n==115 else 0),'unexpected additional failed command')
            for kind in ('stdout','stderr'):
                data=self.bytes(row[kind]['path'],p['max_command_output_bytes'])
                require(len(data)==row[kind]['bytes'] and digest(data)==row[kind]['sha256'],'original output SHA changed')
            if 'stdin'in row:require(digest(self.bytes(row['stdin']))==row['stdin_sha256'],'original input changed')
            self.commands[n]=row
        require(self.commands[115]['argv']==self.k('wait','podchaos/kill-rotation-leader','-n',AUTH['namespace'],
                '--for=condition=AllInjected','--timeout=30s'),'wrong failing command')
        error=self.bytes(self.commands[115]['stderr']['path']).decode()
        require(error=='error: timed out waiting for the condition on podchaos/kill-rotation-leader\n','different original wait failure')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    a.output.mkdir(exist_ok=False);result=dict(complete=False,partial_prefix_valid=False,accepted=False)
    try:
        original,terminal=authority();p=verify_preparation();e=FailedEvidence(AUTH['original_run'],p)
        owned=e.json('owned.json');bootstrap=e.json('bootstrap.json')
        require((owned['namespace'],owned['namespace_uid'])==(AUTH['namespace'],AUTH['namespace_uid']),'owned namespace changed')
        config,population,refs=original_audit.read_burst(e,'pre',owned,bootstrap)
        first,_,_=original_audit.read_drain(e,'initial-drain',owned['namespace'])
        pre,_,_=original_audit.read_drain(e,'pre-drain',owned['namespace'])
        top,top_refs=original_audit.read_topology(e,'pre-topology',owned['namespace'])
        require(refs['final_pod']<min(x['topology']for x in top_refs.values()) and
                max(x['topology_after']for x in top_refs.values())<114,'positive pre-topologies do not precede failed fault')
        require(set(top)==set('123'),'partial topology lacks all three voters')
        result=dict(complete=True,partial_prefix_valid=True,accepted=False,original_runtime_exit_code=1,
          original_runtime_complete=False,runtime_terminal_path=str(Path(AUTH['original_root'])/'runtime-terminal.json'),
          runtime_result_sha256=digest(read(Path(AUTH['original_run'])/'result.json')),
          namespace=owned['namespace'],namespace_uid=owned['namespace_uid'],fault_uid=AUTH['fault_uid'],
          pre_burst={k:v for k,v in population.items() if k!='expected_values'},
          independent_native_full_history_checked=True,selected_topology=top,fresh_drains={'initial':first,'pre':pre},
          scope='Only the retained pre-fault prefix is independently valid. Original attempt failed before target selection/injection. No leader-kill, DB recovery, second burst or supplement acceptance is claimed.')
        (a.output/'input-inventory.json').write_text(json.dumps(e.inventory,indent=2,sort_keys=True)+'\n')
    except BaseException as exc:
        result.update(failure=repr(exc),traceback=traceback.format_exc());raise
    finally:
        result['ended_ns']=time.time_ns();(a.output/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:result[k]for k in ('complete','partial_prefix_valid','accepted','original_runtime_exit_code')}))

if __name__=='__main__':main()
