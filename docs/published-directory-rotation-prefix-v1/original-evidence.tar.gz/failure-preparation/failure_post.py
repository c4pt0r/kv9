#!/usr/bin/env python3
"""Explicit failure-only archival/readback/cleanup; never turns the original failed run into acceptance."""
import argparse,gzip,hashlib,json,os,stat,tarfile,time,traceback,sys
from pathlib import Path
OWN=Path(__file__).resolve().parent
AUTH=json.loads((OWN/'authority.json').read_text())
sys.path.insert(0,AUTH['original_preparation'])
import post as original_post
from checks import digest,load,read,require
from runner import Commands,save,verify_preparation,capture_trees
from partial_audit import authority
HERE=Path(AUTH['original_preparation'])
files=original_post.files
terminal=original_post.terminal


def capture(a,p):
    original,_=authority();c=Commands(a.output,p,original['baseline_available']);ns=AUTH['namespace']
    i,namespace=c.get('namespace',ns)
    require(namespace['metadata']['uid']==AUTH['namespace_uid'] and
            namespace['metadata'].get('annotations',{}).get('chaos-mesh.org/inject')!='enabled','failed namespace identity/opt-in changed')
    _,fault=c.get('podchaos','kill-rotation-leader','-n',ns)
    require(fault['metadata']['uid']==AUTH['fault_uid'] and
            all(x['status']=='False' for x in fault['status']['conditions'] if x['type']in ('Selected','AllInjected')) and
            not fault['status']['experiment'].get('containerRecords'),'failure fault injection state changed')
    rows=capture_trees(c,ns,'prearchive-trees')
    before=load(Path(AUTH['original_run'])/'pre-fault-trees.json')['rows']
    require({(r['pod_uid'],r['container']) for r in rows}=={(r['pod_uid'],r['container']) for r in before},'original failed-run containers changed')
    require(len(rows)==4,'failure snapshot must retain three voters and one collector')
    for pod in ('kv9-n1','kv9-n2','kv9-n3','client-pre'):
        c.kube('logs',pod,'-n',ns)
    for n in '123':c.execute(ns,'kv9-n'+n,'cat','/data/status')
    ready=load(Path(AUTH['original_run'])/'native-pre'/'ready.json');pid=ready['process_id']
    require(type(pid)is int and pid>0,'original native PID missing')
    _,data=c.execute(ns,'client-pre','bash','-c','set -e; cat /proc/sys/kernel/random/boot_id; test ! -e /proc/$1; printf "absent\\n"','native-exit',str(pid))
    require(data.decode().splitlines()[-1]=='absent','native child no longer demonstrably exited')
    c.get('pods,pvc,podchaos,service','-n',ns);c.get('events','-n',ns)
    save(c.out/'result.json',dict(complete=True,scope='Failure archival snapshot, not supplement acceptance',
         namespace=ns,namespace_uid=AUTH['namespace_uid'],fault_uid=AUTH['fault_uid'],containers=rows,
         original_runtime_exit_code=1,native_child_absent=True,ended_ns=time.time_ns()))

def archive(a,p):
    accepted=load(a.audit/'audit.json'); require(accepted['complete'] is True and accepted['partial_prefix_valid'] is True and accepted['accepted'] is False,'independent audit did not accept')
    terminal(a.audit_terminal,a.audit_terminal_sha256,a.audit/'audit.json')
    run=load(a.run/'result.json');require(run['complete'] is False and run['accepted'] is False,'original runtime failed')
    c=Commands(a.output,p,run['baseline_available'])
    archive_path=c.out/'original-evidence.tar.gz'; inventory=[]; total=0
    roots=[('run',a.run),('audit',a.audit),('preparation',HERE),('failure-preparation',OWN),('capture',a.capture),('original-root',Path(AUTH['original_root'])),('investigation',Path(AUTH['investigation']))]
    for label,root in roots:
        for path in files(root):
            require(path.stat().st_size<=p['max_command_output_bytes'],'per-file archive bound')
            total+=path.stat().st_size
            require(total<=p['max_reporting_bytes'],'complete archive input bound')
            with path.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
            st=path.stat();inventory.append(dict(source=str(path),member=label+'/'+str(path.relative_to(root)),
                        bytes=st.st_size,sha256=sha,device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns,mode=st.st_mode))
    for name,path in [('runtime-terminal.json',Path(accepted['runtime_terminal_path'])),('audit-terminal.json',a.audit_terminal)]:
        data=read(path);st=path.stat();total+=len(data)
        inventory.append(dict(source=str(path),member='root-receipts/'+name,bytes=len(data),sha256=digest(data),
                        device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns,mode=st.st_mode))
    require(total<=p['max_reporting_bytes'],'archive input bound including actual root receipts')
    save(c.out/'input-inventory.json',inventory)
    started=time.monotonic()
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as zipped:
            with tarfile.open(fileobj=zipped,mode='w|') as tar:
                for row in inventory:
                    c.guard();require(time.monotonic()-started<1200,'archive deadline')
                    path=Path(row['source']);st=path.stat()
                    require((st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_mode)==
                            tuple(row[k] for k in ('device','inode','bytes','mtime_ns','mode')),'archive input identity changed')
                    with path.open('rb') as f:
                        info=tar.gettarinfo(str(path),arcname=row['member']);tar.addfile(info,f)
                    require(archive_path.stat().st_size<=p['max_reporting_bytes'],'compressed archive bound')
        raw.flush();os.fsync(raw.fileno())
    with archive_path.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
    result=dict(complete=True,archive=str(archive_path),sha256=sha,bytes=archive_path.stat().st_size,
       members=len(inventory),decoded_bytes=total,input_inventory_sha256=digest(read(c.out/'input-inventory.json',16*1024*1024)),
       runtime_result_sha256=digest(read(a.run/'result.json')),audit_sha256=digest(read(a.audit/'audit.json')),
       scope='FAILED original attempt and independently valid pre-fault prefix only: complete original client history including values, selected topology bytes and physical headers, commands, controller failure observations, actual root failure receipts and frozen helpers. No raw PVC WAL/SST backup; PVC data is retained until exact cleanup. Retained local ELF bytes omitted and source/build hashes retained.',
       baseline_available=run['baseline_available'],all_members_read_back=False,ended_ns=time.time_ns())
    save(c.out/'result.json',result)

def cleanup(a,p):
    run=load(a.run/'result.json');audit=load(a.audit/'audit.json');archive_result=load(a.archive/'result.json')
    verified=load(a.verified/'result.json')
    terminal(a.verify_terminal,a.verify_terminal_sha256,a.verified/'result.json')
    require(run['complete'] is False and audit['accepted'] is False and audit['partial_prefix_valid'] is True and verified['complete'] is True and
            verified['all_members_read_back'] is True and verified['all_inputs_rehashed'] is True and
            verified['archive_result_sha256']==digest(read(a.archive/'result.json')) and
            archive_result['runtime_result_sha256']==digest(read(a.run/'result.json')) and
            archive_result['audit_sha256']==digest(read(a.audit/'audit.json')),'cleanup lacks exact accepted archived readback')
    # Recheck small metadata and the original archive digest before any cluster mutation.
    with Path(archive_result['archive']).open('rb') as f:
        require(hashlib.file_digest(f,'sha256').hexdigest()==archive_result['sha256'],'verified archive changed')
    rows=json.loads(read(a.archive/'input-inventory.json',16*1024*1024))
    for row in rows:
        path=Path(row['source']);st=path.stat()
        require((st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_mode)==
                tuple(row[k] for k in ('device','inode','bytes','mtime_ns','mode')),'original artifact changed since verified archive')
    c=Commands(a.output,p,run['baseline_available']);owned=load(a.run/'owned.json');ns=owned['namespace']
    require(ns==audit['namespace'] and owned['namespace_uid']==audit['namespace_uid'] and ns not in p['preserve_namespaces'],'cleanup namespace authority differs')
    _,current=c.get('namespace',ns);require(current['metadata']['uid']==owned['namespace_uid'],'owned namespace UID changed')
    captured=load(a.capture/'prearchive-trees.json');_,pods=c.get('pods','-n',ns)
    actual={(pod['metadata']['uid'],x['containerID'].removeprefix('containerd://')) for pod in pods['items'] for x in pod['status'].get('containerStatuses',[])}
    require(actual=={(r['pod_uid'],r['container'])for r in captured['rows']},'owned container set changed since archive')
    _,fault=c.get('podchaos','kill-rotation-leader','-n',ns)
    require(fault['metadata']['uid']==audit['fault_uid'],'owned fault UID changed')
    c.kube('delete','podchaos','kill-rotation-leader','-n',ns,'--wait=true',seconds=60)
    _,current=c.get('namespace',ns);require(current['metadata']['uid']==owned['namespace_uid'],'namespace UID changed before deletion')
    c.kube('delete','namespace',ns,'--wait=true',seconds=90)
    _,namespaces=c.get('namespaces');actual_ns={x['metadata']['name']:x['metadata']['uid'] for x in namespaces['items']}
    require(actual_ns==p['preserve_namespaces'],'owned namespace remains or historical namespace changed')
    processes=[];containers=[]
    for row in captured['rows']:
        tree_record=load(a.capture/(f"command-{row['tree']:04d}.result.json"))
        text=read(a.capture/tree_record['stdout']['path']).decode()
        boot=text.split('@@BOOT@@\n')[1].split('@@')[0].strip()
        for section in text.split('@@PID@@\n')[1:]:
            statline=section.splitlines()[0];pid=int(statline.split(' ',1)[0]);start=int(statline.rsplit(')',1)[1].split()[19])
            script='set -e; cat /proc/sys/kernel/random/boot_id; if test -e /proc/"$1"/stat; then cat /proc/"$1"/stat; else printf "absent\\n"; fi'
            i,data=c.call(['docker','exec',row['node'],'bash','-c',script,'owned-exit',str(pid)])
            require(data.decode().splitlines()==[boot,'absent'],'owned process remains; PID reuse requires explicit review')
            processes.append(dict(node=row['node'],pid=pid,start_ticks=start,boot_id=boot,absent=True,command=i))
        i,data=c.call(['docker','exec',row['node'],'crictl','inspect',row['container']],allow=(0,1))
        result=load(c.out/(f'command-{i:04d}.result.json'))
        if result['exit_code']==0:
            detail=json.loads(data);require(detail['status']['state']=='CONTAINER_EXITED' and not detail.get('info',{}).get('pid'),'owned container remains live')
            state='CONTAINER_EXITED'
        else:
            error=read(c.out/result['stderr']['path']).decode().lower()
            require('not found'in error or 'notfound'in error,'CRI exit observation failed for unrelated reason');state='removed'
        containers.append(dict(container=row['container'],node=row['node'],state=state,command=i))
    # The fault never injected. One native child was observed absent before archival;
    # the original three voter containers and one collector are cleaned here.
    save(c.out/'result.json',dict(complete=True,namespace=ns,namespace_uid=owned['namespace_uid'],namespace_absent=True,
      historical_namespaces_unchanged=actual_ns,processes=processes,containers=containers,
      fault_injection_observed=False,original_runtime_exit_code=1,native_children_exited_before_archive=1,
      archive_sha256=archive_result['sha256'],verified_result_sha256=digest(read(a.verified/'result.json')),ended_ns=time.time_ns()))

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('stage',choices=('capture','archive','verify','cleanup'))
    for name in ('run','audit','archive','verified','capture','audit-terminal','verify-terminal'):
        ap.add_argument('--'+name,type=Path)
    ap.add_argument('--audit-terminal-sha256');ap.add_argument('--verify-terminal-sha256')
    ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    authority();p=verify_preparation()
    if a.run is not None:require(a.run==Path(AUTH['original_run']),'wrong failed original run')
    try:
        if a.stage=='verify':original_post.verify(a,p)
        else:globals()[a.stage](a,p)
    except BaseException as exc:
        if a.output.exists() and not (a.output/'failure.json').exists():
            save(a.output/'failure.json',dict(complete=False,stage=a.stage,failure=repr(exc),traceback=traceback.format_exc(),ended_ns=time.time_ns()))
        raise
if __name__=='__main__':main()
