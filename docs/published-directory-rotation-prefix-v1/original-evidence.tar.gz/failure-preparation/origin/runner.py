#!/usr/bin/env python3
"""Owned, finite three-voter rotation supplement. No activity occurs on import."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import subprocess
import time
import traceback

from checks import (HERE, config_check, digest, drain_check, fault_check, history_population,
                    load, native, process_identity, process_probe, query_check, query_script,
                    read, require, sample_check, selected_topology, sequence_advance, wal_layout, prepared_store)

def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())

def proc_identity(pid):
    text = Path('/proc/' + str(pid) + '/stat').read_text()
    return dict(pid=pid, start_ticks=int(text.rsplit(')', 1)[1].split()[19]),
                boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())

def verify_preparation():
    p = load(HERE / 'protocol.json')
    for item in load(HERE / 'inventory.json')['files']:
        require(digest(read(HERE / item['path'], 16 * 1024 * 1024)) == item['sha256'], 'frozen preparation changed')
    for source, item in load(HERE / 'source-pins.json').items():
        require(digest(read(source, 4 * 1024 * 1024)) == item['sha256'], 'source helper changed')
    require(digest(read(p['baseline_ready_plan']['path'], 16 * 1024 * 1024)) == p['baseline_ready_plan']['sha256'], 'baseline ready plan changed')
    baseline=load(p['baseline_ready_plan']['path']); release=baseline['root_original_release_readback']
    require(digest(read(release['path']))==release['sha256'],'actual default release readback changed')
    qualified=load(release['path'])
    require(qualified['complete'] is True and qualified['revision']==p['revision'] and
            qualified['server_sha256']==p['server']['sha256'] and qualified['workload_sha256']==p['native']['binary_sha256'],
            'exact default release source/binary binding differs')
    require(all(row['features']==[] for role in qualified['feature_attestation'].values()
                for row in role['artifacts'].values()),'default production/native feature graph not empty')
    require(digest(read(baseline['server_manifest']['path']))==baseline['server_manifest']['sha256'], 'server manifest changed')
    return p

class Commands:
    def __init__(self, out, p, baseline=None):
        self.out = Path(out); self.out.mkdir(exist_ok=False)
        self.p = p; self.started = time.time_ns(); self.deadline = time.monotonic() + p['outer_seconds']
        self.base = self.available() if baseline is None else baseline
        self.number = 0; self.total = 0
        self.k = ['kubectl', '--kubeconfig', p['kubeconfig'], '--request-timeout=10s']
        save(self.out / 'invocation.json', dict(argv=os.sys.argv, started_ns=self.started,
             process=proc_identity(os.getpid()), baseline_available=self.base, protocol_sha256=digest(read(HERE / 'protocol.json'))))
        self.guard()

    def available(self):
        s = os.statvfs(self.out.parent); return s.f_bavail * s.f_frsize

    def guard(self):
        free = self.available()
        with (self.out / 'resources.jsonl').open('a') as f:
            f.write(json.dumps(dict(unix_ns=time.time_ns(), available_bytes=free, device=self.out.stat().st_dev)) + '\n')
        require(free >= max(self.p['floor_bytes'], self.base - self.p['maximum_added_bytes']), 'space guard stopped supplement')
        require(time.monotonic() < self.deadline and self.number < self.p['max_commands'], 'finite supplement deadline/command bound')
        require(self.total <= self.p['max_reporting_bytes'], 'retained command output bound')

    def call(self, argv, *, data=None, seconds=None, allow=(0,), env=None, large=False):
        self.guard(); i = self.number; self.number += 1
        stem = f'command-{i:04d}'; out = self.out / (stem + '.stdout'); err = self.out / (stem + '.stderr')
        row = dict(argv=argv, started_ns=time.time_ns(), allowed_exit_codes=list(allow))
        input_file = None
        if data is not None:
            input_file = self.out / (stem + '.stdin'); input_file.write_bytes(data)
            row.update(stdin=input_file.name, stdin_sha256=digest(data))
        save(self.out / (stem + '.start.json'), row)
        child = None; failure = None
        def limits():
            resource.setrlimit(resource.RLIMIT_FSIZE, (self.p['max_command_output_bytes'], self.p['max_command_output_bytes']))
        try:
            with out.open('xb') as fo, err.open('xb') as fe:
                fi = input_file.open('rb') if input_file else subprocess.DEVNULL
                try:
                    child = subprocess.Popen(argv, stdin=fi, stdout=fo, stderr=fe,
                         env=env, start_new_session=True, preexec_fn=limits)
                    row['child'] = proc_identity(child.pid)
                    save(self.out / (stem + '.child.json'), row['child'])
                    until = min(self.deadline, time.monotonic() + (seconds or self.p['command_seconds']))
                    while child.poll() is None:
                        self.guard()
                        require(time.monotonic() < until, 'command deadline exceeded')
                        time.sleep(min(.2, max(0, until - time.monotonic())))
                    child.wait()
                finally:
                    if hasattr(fi, 'close'): fi.close()
        except BaseException as exc:
            failure = repr(exc)
            if child and child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try: child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=3)
            raise
        finally:
            row.update(ended_ns=time.time_ns(), complete=child is not None and child.poll() is not None,
                       reaped=child is not None and child.poll() is not None,
                       exit_code=child.returncode if child else None, failure=failure)
            for key, path in [('stdout', out), ('stderr', err)]:
                if path.exists():
                    with path.open('rb') as stream: h = hashlib.file_digest(stream, 'sha256').hexdigest()
                    row[key] = dict(path=path.name, bytes=path.stat().st_size, sha256=h); self.total += path.stat().st_size
            save(self.out / (stem + '.result.json'), row)
        require(child.returncode in allow, 'command failed, original outputs retained: ' + stem)
        return i, out if large else out.read_bytes()

    def kube(self, *argv, **kw): return self.call(self.k + list(argv), **kw)
    def get(self, *argv):
        i, data = self.kube('get', *argv, '-o', 'json'); return i, json.loads(data)
    def execute(self, ns, pod, *argv, **kw): return self.kube('exec', '-n', ns, pod, '--', *argv, **kw)
    def create(self, obj):
        return self.kube('create', '-f', '-', data=(json.dumps(obj) + '\n').encode())

def pod_spec(p, ns, n):
    # Bare Pod restartPolicy=Always retains the original Pod UID/PVC through container-kill.
    script = '''set -euo pipefail
if [ ! -f /data/prepared.txt ]; then
 /usr/local/bin/kv9 store-prepare --node-id "$NODE" --data-dir /data > /tmp/prepared.txt
 cp /tmp/prepared.txt /data/prepared.txt
fi
while [ ! -f /data/root.bin ]; do sleep 0.1; done
if [ ! -f /data/kv9-store-identity ]; then
 /usr/local/bin/kv9 init --root /data/root.bin --node-id "$NODE" --data-dir /data
fi
exec /usr/local/bin/kv9 start --node-id "$NODE" --addr 0.0.0.0:20160 --data-dir /data
'''
    env = [dict(name='NODE', value=str(n)), dict(name='KV9_PUBLIC_MAX_REQUESTS', value='8'),
           dict(name='KV9_PUBLIC_MAX_ENCODED_BYTES', value='2097152')]
    for name, key in [('KV9_BOOTSTRAP_TOKEN', 'bootstrap'), ('KV9_CLUSTER_TOKEN', 'cluster'),
                      ('KV9_CLIENT_TOKENS', 'client-tokens'), ('KV9_CLIENT_TOKEN', 'client')]:
        env.append(dict(name=name, valueFrom=dict(secretKeyRef=dict(name='auth', key=key))))
    return dict(apiVersion='v1', kind='Pod', metadata=dict(name='kv9-n'+str(n), namespace=ns,
       labels={'app':'kv9', 'kv9-node':str(n)}), spec=dict(restartPolicy='Always', terminationGracePeriodSeconds=2,
       containers=[dict(name='kv9', image=p['image'], imagePullPolicy='IfNotPresent', command=['/bin/bash', '-c', script],
                        env=env, volumeMounts=[dict(name='data', mountPath='/data')])],
       volumes=[dict(name='data', persistentVolumeClaim=dict(claimName='data-n'+str(n)))]))

def fresh_sample(c, ns):
    before_i, before = c.get('pods', '-n', ns)
    raw = {}; command_ids = {}
    for n in '123':
        i, data = c.execute(ns, 'kv9-n'+n, '/bin/bash', '-c', process_probe.PROBE,
                            'rotation-process', '/data/status', '/usr/local/bin/kv9')
        command_ids[n] = i; raw[n] = data.decode()
    after_i, after = c.get('pods', '-n', ns)
    rows = sample_check(before, raw, after, c.p)
    return dict(before=before_i, probes=command_ids, after=after_i), rows

def drain(c, ns, name):
    end = min(c.deadline, time.monotonic() + 20); refs = []; samples = []
    while time.monotonic() < end and len(samples) < 100:
        ref, rows = fresh_sample(c, ns); refs.append(ref); samples.append(rows)
        if len(samples) >= 3:
            try:
                accepted = drain_check(samples)
                value = dict(samples=refs, accepted=accepted, started_ns=c.started, ended_ns=time.time_ns())
                save(c.out / (name+'.json'), value); return value, rows
            except ValueError as exc:
                # Pending freshness or quiescence only; all raw attempts remain retained.
                if any(text in str(exc) for text in ('identity changed', 'regressed', 'voter missing')): raise
        time.sleep(.2)
    save(c.out / (name+'-incomplete.json'), dict(samples=refs, accepted=False))
    raise ValueError('all three voters did not freshly drain in 20 seconds')

def topology(c, ns, name):
    refs = {}; evidence = {}
    for n in '123':
        i, data = c.execute(ns, 'kv9-n'+n, 'bash', '-c',
            'set -e; test ! -L /data/catalog.wal; test "$(stat -c %s /data/catalog.wal)" -le 4194304; cat /data/catalog.wal')
        layout = wal_layout.decode_topology(data, Path('/data'))
        headers = {}; commands = {}
        for item in list(layout.closed) + [layout.active]:
            path = str(layout.segment_path(item))
            script = 'set -e; test ! -L "$1"; test -f "$1"; stat -c "%s %i %d" "$1"; dd if="$1" bs=60 count=1 status=none'
            j, raw = c.execute(ns, 'kv9-n'+n, 'bash', '-c', script, 'selected-segment', path)
            first, header = raw.split(b'\n', 1); size, inode, device = map(int, first.split())
            headers[str(item['sequence'])] = dict(path=path, bytes=size, inode=inode, device=device, header_hex=header.hex())
            commands[str(item['sequence'])] = j
        k, again = c.execute(ns, 'kv9-n'+n, 'cat', '/data/catalog.wal')
        require(data == again, 'selected topology changed during bounded metadata capture')
        evidence[n] = selected_topology(data, headers)
        refs[n] = dict(topology=i, headers=commands, topology_after=k)
    save(c.out / (name+'.json'), refs)
    return evidence

def burst(c, ns, phase, run_id, services, leader):
    run_name = 'pdrot-'+phase+'-'+run_id
    create_i, data = c.execute(ns, 'kv9-n'+leader, '/usr/local/bin/kv9', 'client', 'create-keyspace',
                              '--addr', '127.0.0.1:20160', '--name', run_name, '--api-type', 'raw')
    match = re.findall(rb'^keyspace_id=([1-9][0-9]*)$', data, re.M)
    require(len(match) == 1, 'fresh keyspace lacks positive identity')
    config = dict(c.p['config'], run_id=run_name, keyspace_name=run_name,
                  client=dict(c.p['client'], keyspace_id=int(match[0]),
                              peers=[dict(node_id=n, address=services[str(n)]+':20160') for n in (1,2,3)]))
    config_check(config, c.p, phase, run_id, services)
    c.create(dict(apiVersion='v1', kind='ConfigMap', metadata=dict(name='config-'+phase, namespace=ns),
                  data={'config.json':json.dumps(config)}))
    script = '''umask 077
getconf CLK_TCK > /tmp/workload-clock-ticks.txt
printf 'baseline\\n' > /tmp/workload.phase
/usr/local/bin/kv9-batch-workload --config /config/config.json --build-manifest /opt/kv9-batch-workload/build.json --output /tmp/workload --stop-file /tmp/workload.stop --phase-file /tmp/workload.phase > /tmp/workload.log 2>&1
echo $? > /tmp/workload.exit
sleep 3600
'''
    pod = 'client-'+phase
    c.create(dict(apiVersion='v1', kind='Pod', metadata=dict(name=pod, namespace=ns, labels={'app':'rotation-client'}),
      spec=dict(restartPolicy='Never', terminationGracePeriodSeconds=2,
       containers=[dict(name='workload', image=c.p['image'], imagePullPolicy='IfNotPresent', command=['/bin/bash','-c',script],
        env=[dict(name='KV9_CLIENT_TOKEN',valueFrom=dict(secretKeyRef=dict(name='auth',key='client')))],
        resources=dict(requests={'cpu':'100m','memory':'64Mi'},limits={'cpu':'2','memory':'256Mi'}),
        volumeMounts=[dict(name='config',mountPath='/config',readOnly=True)])],
       volumes=[dict(name='config',configMap=dict(name='config-'+phase))])))
    c.kube('wait', '-n', ns, '--for=jsonpath={.status.phase}=Running', 'pod/'+pod, '--timeout=60s', seconds=65)
    start_i, start_pod = c.get('pod', pod, '-n', ns)
    end = min(c.deadline, time.monotonic() + 150)
    while time.monotonic() < end:
        i, value = c.execute(ns, pod, 'bash','-c','if test -s /tmp/workload.exit; then cat /tmp/workload.exit; else printf pending; fi')
        if value.strip() != b'pending':
            require(value.strip() == b'0', 'native child failed; live fixture retained'); break
        time.sleep(.5)
    else: raise ValueError('finite native burst did not exit')
    files = {}; directory = c.out / ('native-'+phase); directory.mkdir()
    for name in ('config.json','build.json','history.jsonl','report.json','ready.json','progress.json'):
        j, path = c.execute(ns, pod, 'cat', '/tmp/workload/'+name, large=True)
        shutil.copyfile(path, directory/name); files[name] = j
    log_i, _ = c.execute(ns, pod, 'cat', '/tmp/workload.log')
    exit_i, _ = c.execute(ns, pod, 'bash','-c',
       'set -e; pid=$(sed -n \'s/.*"process_id": *\\([0-9]*\\).*/\\1/p\' /tmp/workload/ready.json); '
       'test "$pid" -gt 0; printf "process_pid=%s\\nprocess_boot_id=" "$pid"; cat /proc/sys/kernel/random/boot_id; '
       'test ! -e /proc/$pid; printf "process_absent=true\\n"')
    final_i, final_pod = c.get('pod', pod, '-n', ns)
    require(process_identity(start_pod) == process_identity(final_pod), 'client container restarted')
    validation = native.validate(directory, Path(c.p['native_build']), c.p['revision'], seconds=30)
    records = [json.loads(line) for line in read(directory/'history.jsonl', c.p['config']['history_bytes']).splitlines()]
    population = history_population(records, c.p)
    require(load(directory/'report.json')['stop']['reason'] == 'operation_limit', 'burst did not reach finite call limit')
    save(c.out/(phase+'-burst.json'), dict(create_keyspace=create_i, initial_pod=start_i, final_pod=final_i,
          files=files, log=log_i, exit_marker=i, process_exit=exit_i, validation=validation,
          population={k:v for k,v in population.items() if k != 'expected_values'}))
    return config, population

def query(c, ns, leader, config, population, name):
    script = query_script(config['client']['keyspace_id'], population['expected_values'])
    i, data = c.execute(ns, 'kv9-n'+leader, 'bash', '-c', script, seconds=140)
    result = query_check(data.decode(), population['expected_values'])
    save(c.out/(name+'.json'), dict(command=i, leader=leader, result=result))

TREE_SCRIPT = '''set -euo pipefail
printf '@@BOOT@@\\n'; cat /proc/sys/kernel/random/boot_id
walk() {
 local pid=$1
 test -r /proc/$pid/stat
 printf '@@PID@@\\n'; cat /proc/$pid/stat
 local child
 for child in $(cat /proc/$pid/task/$pid/children); do walk "$child"; done
}
walk "$1"
'''

def capture_trees(c, ns, name):
    pods_i, pods = c.get('pods', '-n', ns); rows = []
    for pod in pods['items']:
        for container in pod['status'].get('containerStatuses', []):
            require('running' in container['state'], 'prearchive container is not running')
            cid = container['containerID'].removeprefix('containerd://'); node = pod['spec']['nodeName']
            i, raw = c.call(['docker','exec',node,'crictl','inspect',cid]); inspected = json.loads(raw)
            require(inspected['status']['state'] == 'CONTAINER_RUNNING', 'CRI container not running')
            pid = inspected['info']['pid']; require(type(pid) is int and pid > 0, 'CRI PID missing')
            j, _ = c.call(['docker','exec',node,'bash','-c',TREE_SCRIPT,'owned-tree',str(pid)])
            rows.append(dict(pod=pod['metadata']['name'], pod_uid=pod['metadata']['uid'], container=cid,
                             node=node, inspect=i, tree=j))
    save(c.out/(name+'.json'), dict(pods=pods_i, rows=rows)); return rows

def run(c, args):
    p = c.p
    require(c.available() >= p['launch_bytes'], 'fresh 64 GiB launch capacity absent')
    require(str(args.full21_post_terminal) == p['full21_post_terminal']['path'] and
            args.full21_post_terminal_sha256 == p['full21_post_terminal']['sha256'], 'wrong prerequisite campaign terminal')
    terminal = load(args.full21_post_terminal)
    require(digest(read(args.full21_post_terminal)) == args.full21_post_terminal_sha256 and
            terminal.get('complete') is True and terminal.get('exit_code') == 0,
            'full21 actual post terminal absent/failed/mismatched')
    require(terminal.get('terminal_receipt') and digest(read(terminal['result_path'])) == terminal['result_sha256'],
            'full21 terminal lacks exact actual result binding')
    post = load(terminal['result_path'])
    require(post['complete'] is True and len(post['phases']) == 6 and
            all(x['complete'] is True and x['exit_code'] == 0 for x in post['phases']), 'full21 six post phases incomplete')
    # Actual path and result hashes remain external inputs until full21 post completes.
    save(c.out/'baseline-terminal.json', dict(path=str(args.full21_post_terminal), sha256=args.full21_post_terminal_sha256, record=terminal))
    ns_i, current = c.get('namespaces')
    require({x['metadata']['name']:x['metadata']['uid'] for x in current['items']} == p['preserve_namespaces'], 'unexpected live namespace or historical UID change')
    _, nodes = c.get('nodes')
    _, kinds = c.call([p['kind'],'get','nodes','--name',p['kind_cluster']])
    require(set(kinds.decode().split()) == {x['metadata']['name'] for x in nodes['items']}, 'wrong Kind/Kubernetes cluster')
    _, image = c.call(['docker','image','inspect',p['image']])
    require(json.loads(image)[0]['Id'] == p['docker_image_id'], 'image identity changed')
    with Path(p['server']['path']).open('rb') as f:
        require(hashlib.file_digest(f,'sha256').hexdigest() == p['server']['sha256'], 'retained server bytes changed')
    run_id = str(int(time.time()))+'-'+str(os.getpid()); ns = 'kv9-pdrot-'+run_id
    save(c.out/'namespace-intent.json',dict(namespace=ns,run_id=run_id,uid_pending=True,
          scope='Intent only. If create times out before UID capture, retain this exact name and require read-only ownership reconciliation before cleanup.'))
    c.create(dict(apiVersion='v1',kind='Namespace',metadata=dict(name=ns, labels={'app':'kv9-rotation-supplement'})))
    namespace_i, namespace = c.get('namespace',ns)
    identity = dict(namespace=ns, namespace_uid=namespace['metadata']['uid'], run_id=run_id,
                    namespace_command=namespace_i, namespaces_before=ns_i, baseline_available=c.base)
    save(c.out/'owned.json', identity) # Written before any further owned resource creation.
    token = 'rotation-'+run_id
    c.create(dict(apiVersion='v1',kind='Secret',metadata=dict(name='auth',namespace=ns),type='Opaque',
                  stringData={'bootstrap':token,'cluster':token,'client':token,'client-tokens':'admin='+token}))
    services = {}; prepared = {}; pvcs = {}
    for n in (1,2,3):
        c.create(dict(apiVersion='v1',kind='Service',metadata=dict(name='kv9-n'+str(n),namespace=ns),
          spec=dict(selector={'app':'kv9','kv9-node':str(n)},ports=[dict(port=20160,targetPort=20160)])))
        _, svc = c.get('service','kv9-n'+str(n),'-n',ns); services[str(n)] = svc['spec']['clusterIP']
        c.create(dict(apiVersion='v1',kind='PersistentVolumeClaim',metadata=dict(name='data-n'+str(n),namespace=ns),
          spec=dict(accessModes=['ReadWriteOnce'],resources={'requests':{'storage':'128Mi'}})))
        c.create(pod_spec(p, ns, n))
        c.kube('wait','-n',ns,'--for=jsonpath={.status.phase}=Running','pod/kv9-n'+str(n),'--timeout=60s',seconds=65)
        _, pvc = c.get('pvc','data-n'+str(n),'-n',ns); pvcs[str(n)] = pvc
        i, raw = c.execute(ns,'kv9-n'+str(n),'bash','-c',
            'set -e; for i in {1..100}; do if test -s /data/prepared.txt; then cat /data/prepared.txt; exit 0; fi; sleep .1; done; exit 1')
        fields = prepared_store(raw.decode(),n)
        prepared[str(n)] = dict(command=i, fields=fields)
    env = dict(os.environ,KV9_BOOTSTRAP_TOKEN=token)
    root_file = c.out/'root.bin'
    c.call([p['server']['path'],'root-create','--output',str(root_file),'--voters',
            ','.join(str(n)+'@'+services[str(n)]+':20160' for n in (1,2,3)), '--store-incarnations',
            ','.join(str(n)+'='+prepared[str(n)]['fields']['store_incarnation'] for n in (1,2,3))],env=env)
    encoded = base64.b64encode(read(root_file)).decode()
    for n in '123':
        c.execute(ns,'kv9-n'+n,'bash','-c',
           'set -e; set -C; printf %s "$1" | base64 -d > /data/root.bin.tmp; mv -n /data/root.bin.tmp /data/root.bin',
           'root-install',encoded)
    save(c.out/'bootstrap.json',dict(services=services, prepared=prepared, pvcs=pvcs,
          root_sha256=digest(read(root_file)), root_bytes=root_file.stat().st_size))
    # Server start may be asynchronous; wait for an actual status file before exact probes.
    for n in '123':
        c.execute(ns,'kv9-n'+n,'bash','-c','set -e; for i in {1..300}; do if test -s /data/status; then exit 0; fi; sleep .1; done; exit 1',seconds=35)
    first, _ = drain(c,ns,'initial-drain')
    pre_config, pre_population = burst(c,ns,'pre',run_id,services,first['accepted']['leader'])
    pre_drain, pre_rows = drain(c,ns,'pre-drain')
    pre_top = topology(c,ns,'pre-topology')
    victim = pre_drain['accepted']['leader']; victim_pod = 'kv9-n'+victim
    pre_trees = capture_trees(c,ns,'pre-fault-trees')
    before_i, before = c.get('pod',victim_pod,'-n',ns)
    life_i, life = c.execute(ns,victim_pod,'cat','/data/kv9-store-lifecycle')
    # Re-probe immediately before fault to bind the selected victim to the advertised leader.
    probe_i, raw = c.execute(ns,victim_pod,'bash','-c',process_probe.PROBE,'fault-leader','/data/status','/usr/local/bin/kv9')
    observed = process_probe.parse(raw.decode(),p['server']['sha256'],'/usr/local/bin/kv9')
    require(all(observed[k]['leader_id'] == victim and observed[k]['role'] == 'leader' for k in ('state','state_after')),
            'selected victim no longer reports itself as leader')
    fault_spec = dict(apiVersion='chaos-mesh.org/v1alpha1',kind='PodChaos',
      metadata=dict(name='kill-rotation-leader',namespace=ns),spec=dict(action='container-kill',mode='one',
      containerNames=['kv9'],selector=dict(namespaces=[ns],pods={ns:[victim_pod]})))
    c.create(fault_spec)
    c.kube('wait','podchaos/kill-rotation-leader','-n',ns,'--for=condition=AllInjected','--timeout=30s',seconds=35)
    fault_i, fault = c.get('podchaos','kill-rotation-leader','-n',ns)
    end = min(c.deadline,time.monotonic()+60)
    while time.monotonic()<end:
        after_i, after = c.get('pod',victim_pod,'-n',ns)
        statuses = after['status'].get('containerStatuses',[])
        if statuses and statuses[0].get('restartCount',0) > before['status']['containerStatuses'][0]['restartCount'] and 'running' in statuses[0]['state']:
            break
        time.sleep(.5)
    else: raise ValueError('owned leader container did not restart')
    life_after_i, life_after = c.execute(ns,victim_pod,'cat','/data/kv9-store-lifecycle')
    checked = fault_check(fault,before,after,victim,ns,life,life_after)
    old_tree = next(row for row in pre_trees if row['pod']==victim_pod)
    tree_text = (c.out/f"command-{old_tree['tree']:04d}.stdout").read_text()
    old_exit_commands=[]
    for section in tree_text.split('@@PID@@\n')[1:]:
        line=section.splitlines()[0];pid=int(line.split(' ',1)[0])
        script='set -e; cat /proc/sys/kernel/random/boot_id; if test -e /proc/"$1"/stat; then cat /proc/"$1"/stat; else printf "absent\\n"; fi'
        j,exited=c.call(['docker','exec',old_tree['node'],'bash','-c',script,'owned-exit',str(pid)])
        require(exited.decode().splitlines()==[tree_text.split('@@BOOT@@\n')[1].split('@@')[0].strip(),'absent'],
                'original leader process remains after container-kill')
        old_exit_commands.append(j)
    save(c.out/'fault.json',dict(before=before_i,after=after_i,lifecycle_before=life_i,lifecycle_after=life_after_i,
           leader_probe=probe_i,fault=fault_i,checked=checked,original_tree=old_tree,original_process_exit_commands=old_exit_commands))
    recovered, recovered_rows = drain(c,ns,'recovered-drain')
    require(pre_rows[victim]['process_start_ticks'] != recovered_rows[victim]['process_start_ticks'], 'server process was not replaced')
    for n in '123':
        require(pre_rows[n]['state_after']['store_incarnation'] == recovered_rows[n]['state_after']['store_incarnation'], 'recovery changed store incarnation')
    recovered_top = topology(c,ns,'recovered-topology')
    query(c,ns,recovered['accepted']['leader'],pre_config,pre_population,'recovered-pre-values')
    post_config, post_population = burst(c,ns,'post',run_id,services,recovered['accepted']['leader'])
    require(post_config['client']['keyspace_id'] != pre_config['client']['keyspace_id'], 'second keyspace is not fresh')
    post_drain, _ = drain(c,ns,'post-drain')
    post_top = topology(c,ns,'post-topology')
    sequence_advance(pre_top,recovered_top,post_top)
    query(c,ns,post_drain['accepted']['leader'],pre_config,pre_population,'final-pre-values')
    query(c,ns,post_drain['accepted']['leader'],post_config,post_population,'final-post-values')
    drain(c,ns,'final-drain')
    capture_trees(c,ns,'prearchive-trees')
    for pod in ['kv9-n1','kv9-n2','kv9-n3','client-pre','client-post']:
        c.kube('logs',pod,'-n',ns)
    resources_i, _ = c.get('pods,pvc,podchaos,service','-n',ns)
    save(c.out/'final-resource-capture.json',dict(command=resources_i))
    return dict(complete=True,accepted=True,namespace=ns,namespace_uid=identity['namespace_uid'],
        outcomes='both complete healthy 56-call histories; independent audit still required',
        process_cleanup_pending=True, topology={name:value for name,value in [('pre',pre_top),('recovered',recovered_top),('post',post_top)]})

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--full21-post-terminal',type=Path,required=True); ap.add_argument('--full21-post-terminal-sha256',required=True)
    a=ap.parse_args(); p=verify_preparation(); c=Commands(a.output,p); result=dict(complete=False,accepted=False)
    try:
        result=run(c,a)
    except BaseException as exc:
        result.update(failure=repr(exc),traceback=traceback.format_exc())
        # No cleanup, retry or fault reapplication. The original owned.json is the cleanup authority.
        if (c.out/'owned.json').exists():
            result['retained_owned_resources']=load(c.out/'owned.json')
            result['manual_archive_then_exact_cleanup_required']=True
        elif (c.out/'namespace-intent.json').exists():
            result['namespace_creation_intent']=load(c.out/'namespace-intent.json')
            result['ownership_reconciliation_required']=True
        raise
    finally:
        result.update(ended_ns=time.time_ns(),controller=proc_identity(os.getpid()), baseline_available=c.base,
                      available_bytes=c.available(), command_count=c.number)
        save(c.out/'result.json',result)

if __name__=='__main__': main()
