#!/usr/bin/env python3
"""Archive/read back original supplement evidence, then separately remove exact owned resources."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile
import time
import traceback

from checks import HERE, digest, load, read, require
from runner import Commands, save, verify_preparation

def files(root):
    result=[]
    for path in sorted(Path(root).rglob('*')):
        mode=path.lstat().st_mode
        require(stat.S_ISDIR(mode) or stat.S_ISREG(mode),'non-regular archive input')
        if stat.S_ISREG(mode): result.append(path)
    return result

def terminal(path, sha, result_path):
    require(digest(read(path))==sha,'actual tool terminal hash mismatch')
    value=load(path)
    require(value['complete'] is True and value['exit_code']==0 and value.get('terminal_receipt') and
            Path(value['result_path']).resolve()==Path(result_path).resolve() and
            value['result_sha256']==digest(read(result_path)), 'actual successful terminal/result identity missing')
    return value

def archive(a,p):
    accepted=load(a.audit/'audit.json'); require(accepted['complete'] is True and accepted['accepted'] is True,'independent audit did not accept')
    terminal(a.audit_terminal,a.audit_terminal_sha256,a.audit/'audit.json')
    run=load(a.run/'result.json');require(run['complete'] is True and run['accepted'] is True,'original runtime failed')
    c=Commands(a.output,p,run['baseline_available'])
    archive_path=c.out/'original-evidence.tar.gz'; inventory=[]; total=0
    roots=[('run',a.run),('audit',a.audit),('preparation',HERE)]
    for label,root in roots:
        for path in files(root):
            require(path.stat().st_size<=p['max_command_output_bytes'],'per-file archive bound')
            total+=path.stat().st_size
            require(total<=p['max_reporting_bytes'],'complete archive input bound')
            with path.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
            st=path.stat();inventory.append(dict(source=str(path),member=label+'/'+str(path.relative_to(root)),
                        bytes=st.st_size,sha256=sha,device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns,mode=st.st_mode))
    for name,path in [('runtime-terminal.json',Path(accepted['runtime_terminal_path'])),('audit-terminal.json',a.audit_terminal)]:
        data=read(path);st=path.stat();total+=len(data)
        inventory.append(dict(source=str(path),member='root-receipts/'+name,bytes=len(data),sha256=digest(data),
                        device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns,mode=st.st_mode))
    require(total<=p['max_reporting_bytes'],'archive input bound including actual root receipts')
    save(c.out/'input-inventory.json',inventory)
    started=time.monotonic()
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as zipped:
            with tarfile.open(fileobj=zipped,mode='w|') as tar:
                for row in inventory:
                    c.guard();require(time.monotonic()-started<1200,'archive deadline')
                    path=Path(row['source']);st=path.stat()
                    require((st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_mode)==
                            tuple(row[k] for k in ('device','inode','bytes','mtime_ns','mode')),'archive input identity changed')
                    with path.open('rb') as f:
                        info=tar.gettarinfo(str(path),arcname=row['member']);tar.addfile(info,f)
                    require(archive_path.stat().st_size<=p['max_reporting_bytes'],'compressed archive bound')
        raw.flush();os.fsync(raw.fileno())
    with archive_path.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
    result=dict(complete=True,archive=str(archive_path),sha256=sha,bytes=archive_path.stat().st_size,
       members=len(inventory),decoded_bytes=total,input_inventory_sha256=digest(read(c.out/'input-inventory.json',16*1024*1024)),
       runtime_result_sha256=digest(read(a.run/'result.json')),audit_sha256=digest(read(a.audit/'audit.json')),
       scope='Complete original client histories including values, selected topology bytes and physical headers, command outputs, process/fault/config evidence, and frozen helpers. No raw PVC WAL/SST backup; PVC data is retained until exact cleanup. Retained local ELF bytes omitted and source/build hashes retained.',
       baseline_available=run['baseline_available'],all_members_read_back=False,ended_ns=time.time_ns())
    save(c.out/'result.json',result)

def verify(a,p):
    original=load(a.archive/'result.json');require(original['complete'] is True,'archive not complete')
    c=Commands(a.output,p,original['baseline_available'])
    rows=json.loads(read(a.archive/'input-inventory.json',16*1024*1024))
    require(digest(read(a.archive/'input-inventory.json',16*1024*1024))==original['input_inventory_sha256'],'archive inventory differs')
    expected={r['member']:r for r in rows};require(len(expected)==len(rows),'duplicate archive member name')
    path=Path(original['archive']); require(path.stat().st_size==original['bytes'],'archive size changed')
    with path.open('rb') as f:require(hashlib.file_digest(f,'sha256').hexdigest()==original['sha256'],'archive SHA changed')
    found=set();total=0
    with gzip.open(path,'rb') as zipped:
        with tarfile.open(fileobj=zipped,mode='r|') as tar:
            for member in tar:
                c.guard()
                require(member.isfile() and member.name in expected and member.name not in found,'unexpected/repeated/nonregular archive member')
                row=expected[member.name];require(member.size==row['bytes'],'archive member size differs')
                f=tar.extractfile(member); h=hashlib.sha256();size=0
                while block:=f.read(1024*1024):
                    c.guard();h.update(block);size+=len(block)
                require(size==row['bytes'] and h.hexdigest()==row['sha256'],'decoded member SHA differs')
                with Path(row['source']).open('rb') as source:
                    require(hashlib.file_digest(source,'sha256').hexdigest()==row['sha256'],'original changed after archive')
                found.add(member.name);total+=size
        while zipped.read(1024*1024): pass # Consume compressed stream to EOF/CRC, not only tar end markers.
    require(found==set(expected) and total==original['decoded_bytes'],'archive readback incomplete')
    save(a.output/'result.json',dict(complete=True,all_members_read_back=True,all_inputs_rehashed=True,
        archive_result_sha256=digest(read(a.archive/'result.json')),archive_sha256=original['sha256'],
        members=len(found),decoded_bytes=total,ended_ns=time.time_ns()))

def cleanup(a,p):
    run=load(a.run/'result.json');audit=load(a.audit/'audit.json');archive_result=load(a.archive/'result.json')
    verified=load(a.verified/'result.json')
    terminal(a.verify_terminal,a.verify_terminal_sha256,a.verified/'result.json')
    require(run['complete'] is True and audit['accepted'] is True and verified['complete'] is True and
            verified['all_members_read_back'] is True and verified['all_inputs_rehashed'] is True and
            verified['archive_result_sha256']==digest(read(a.archive/'result.json')) and
            archive_result['runtime_result_sha256']==digest(read(a.run/'result.json')) and
            archive_result['audit_sha256']==digest(read(a.audit/'audit.json')),'cleanup lacks exact accepted archived readback')
    # Recheck small metadata and the original archive digest before any cluster mutation.
    with Path(archive_result['archive']).open('rb') as f:
        require(hashlib.file_digest(f,'sha256').hexdigest()==archive_result['sha256'],'verified archive changed')
    rows=json.loads(read(a.archive/'input-inventory.json',16*1024*1024))
    for row in rows:
        path=Path(row['source']);st=path.stat()
        require((st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_mode)==
                tuple(row[k] for k in ('device','inode','bytes','mtime_ns','mode')),'original artifact changed since verified archive')
    c=Commands(a.output,p,run['baseline_available']);owned=load(a.run/'owned.json');ns=owned['namespace']
    require(ns==audit['namespace'] and owned['namespace_uid']==audit['namespace_uid'] and ns not in p['preserve_namespaces'],'cleanup namespace authority differs')
    _,current=c.get('namespace',ns);require(current['metadata']['uid']==owned['namespace_uid'],'owned namespace UID changed')
    captured=load(a.run/'prearchive-trees.json');_,pods=c.get('pods','-n',ns)
    actual={(pod['metadata']['uid'],x['containerID'].removeprefix('containerd://')) for pod in pods['items'] for x in pod['status'].get('containerStatuses',[])}
    require(actual=={(r['pod_uid'],r['container'])for r in captured['rows']},'owned container set changed since archive')
    _,fault=c.get('podchaos','kill-rotation-leader','-n',ns)
    require(fault['metadata']['uid']==audit['fault']['fault_uid'],'owned fault UID changed')
    c.kube('delete','podchaos','kill-rotation-leader','-n',ns,'--wait=true',seconds=60)
    _,current=c.get('namespace',ns);require(current['metadata']['uid']==owned['namespace_uid'],'namespace UID changed before deletion')
    c.kube('delete','namespace',ns,'--wait=true',seconds=90)
    _,namespaces=c.get('namespaces');actual_ns={x['metadata']['name']:x['metadata']['uid'] for x in namespaces['items']}
    require(actual_ns==p['preserve_namespaces'],'owned namespace remains or historical namespace changed')
    processes=[];containers=[]
    for row in captured['rows']:
        tree_record=load(a.run/(f"command-{row['tree']:04d}.result.json"))
        text=read(a.run/tree_record['stdout']['path']).decode()
        boot=text.split('@@BOOT@@\n')[1].split('@@')[0].strip()
        for section in text.split('@@PID@@\n')[1:]:
            statline=section.splitlines()[0];pid=int(statline.split(' ',1)[0]);start=int(statline.rsplit(')',1)[1].split()[19])
            script='set -e; cat /proc/sys/kernel/random/boot_id; if test -e /proc/"$1"/stat; then cat /proc/"$1"/stat; else printf "absent\\n"; fi'
            i,data=c.call(['docker','exec',row['node'],'bash','-c',script,'owned-exit',str(pid)])
            require(data.decode().splitlines()==[boot,'absent'],'owned process remains; PID reuse requires explicit review')
            processes.append(dict(node=row['node'],pid=pid,start_ticks=start,boot_id=boot,absent=True,command=i))
        i,data=c.call(['docker','exec',row['node'],'crictl','inspect',row['container']],allow=(0,1))
        result=load(c.out/(f'command-{i:04d}.result.json'))
        if result['exit_code']==0:
            detail=json.loads(data);require(detail['status']['state']=='CONTAINER_EXITED' and not detail.get('info',{}).get('pid'),'owned container remains live')
            state='CONTAINER_EXITED'
        else:
            error=read(c.out/result['stderr']['path']).decode().lower()
            require('not found'in error or 'notfound'in error,'CRI exit observation failed for unrelated reason');state='removed'
        containers.append(dict(container=row['container'],node=row['node'],state=state,command=i))
    # The old leader was already terminated by the observed fault (exit 137), and both native children
    # were independently observed absent before archival. These are distinct from the five final containers.
    save(c.out/'result.json',dict(complete=True,namespace=ns,namespace_uid=owned['namespace_uid'],namespace_absent=True,
      historical_namespaces_unchanged=actual_ns,processes=processes,containers=containers,
      previous_leader_exit=audit['fault'],native_children_exited_before_archive=2,
      archive_sha256=archive_result['sha256'],verified_result_sha256=digest(read(a.verified/'result.json')),ended_ns=time.time_ns()))

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('stage',choices=('archive','verify','cleanup'))
    for name in ('run','audit','archive','verified','audit-terminal','verify-terminal'):
        ap.add_argument('--'+name,type=Path)
    ap.add_argument('--audit-terminal-sha256');ap.add_argument('--verify-terminal-sha256')
    ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();p=verify_preparation()
    try:
        globals()[a.stage](a,p)
    except BaseException as exc:
        if a.output.exists() and not (a.output/'failure.json').exists():
            save(a.output/'failure.json',dict(complete=False,stage=a.stage,failure=repr(exc),traceback=traceback.format_exc(),ended_ns=time.time_ns()))
        raise

if __name__=='__main__':main()
