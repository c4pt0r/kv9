"""Tiny synthetic controls for new supplement acceptance boundaries; no processes or cluster."""
import copy
import hashlib
import json
import unittest
import zlib
from pathlib import Path

import checks as c
from runner import pod_spec

P=c.load(c.HERE/'protocol.json')

def encoded(sequence=2,stream=b'a'*16,generation=2):
    def header(n,previous):
        raw=b'KV9SEG01'+stream+n.to_bytes(8,'little')+bytes([bool(previous)])+bytes(7)
        raw+=(1 if previous else 0).to_bytes(8,'little')+(previous or 0).to_bytes(8,'little')
        return raw+zlib.crc32(raw).to_bytes(4,'little')
    data=c.wal_layout.TOPOLOGY_MAGIC+generation.to_bytes(8,'little')+header(sequence,sequence-1)
    data+=bytes(4)+(sequence-1).to_bytes(4,'little'); physical={}
    for n in range(1,sequence):
        h=header(n,n-1)
        data+=h+(100).to_bytes(8,'little')+(1).to_bytes(8,'little')
        data+=(b'\1'+(1).to_bytes(8,'little')+n.to_bytes(8,'little'))*2+b'\0'
        physical[str(n)]=dict(header_hex=h.hex(),bytes=100,inode=100+n,device=1,
           path='/data/catalog.segments/'+stream.hex()+'/'+f'{n:020}.wal')
    physical[str(sequence)]=dict(header_hex=header(sequence,sequence-1).hex(),bytes=60,inode=100+sequence,device=1,
        path='/data/catalog.segments/'+stream.hex()+'/'+f'{sequence:020}.wal')
    return data+hashlib.sha256(data).digest(),physical

def top(sequence=2,stream=b'a'*16,generation=2):
    data,physical=encoded(sequence,stream,generation)
    return c.selected_topology(data,physical)

def fault_fixture():
    before=dict(metadata=dict(name='kv9-n2',uid='pod-2',labels={'kv9-node':'2'}),spec=dict(volumes=[{'name':'data','persistentVolumeClaim':{'claimName':'data-n2'}}]),
                status=dict(containerStatuses=[dict(name='kv9',restartCount=0,containerID='containerd://old',state={'running':{}})]))
    after=copy.deepcopy(before);after['status']['containerStatuses'][0].update(restartCount=1,containerID='containerd://new',
              lastState={'terminated':{'containerID':'containerd://old','exitCode':137}})
    fault=dict(kind='PodChaos',metadata=dict(namespace='owned',name='kill-rotation-leader',uid='fault'),
        spec=dict(action='container-kill',mode='one',containerNames=['kv9'],selector=dict(namespaces=['owned'],pods={'owned':['kv9-n2']})),
        status=dict(conditions=[{'type':'AllInjected','status':'True'}],experiment={'containerRecords':[{'id':'owned/kv9-n2/kv9','phase':'Injected','injectedCount':1}]}))
    return fault,before,after

def drain_samples():
    samples=[]
    for counter in (5,6,7):
        sample={}
        for n in '123':
            state={k:'0' for k in c.ZERO};state.update(bootstrap_state='Serving',fatal='',raft_async_apply_stopped='false',
              raft_async_read_stopped='false',raft_committed='10',applied_index='10',driver_applied_index='10',
              applied_term='1',driver_applied_term='1',leader_id='2',metrics_export_successes=str(counter))
            sample[n]=dict(pod_uid='pod'+n,process_pid=int(n),process_start_ticks=100,process_boot_id='boot',state=state,state_after=state.copy())
        samples.append(sample)
    return samples

def ledger():
    records=[dict(type='header')];seq=0
    for i in range(56):
        phase='initialization' if i<4 else 'verify' if i>=54 else 'baseline'
        op='batch_put' if i in (2,3) or 4<=i<49 else 'batch_get'
        pairs=[[f'{n:04x}','11'] for n in range(65)] if i==2 else [[f'{n:04x}','22'] for n in range(64)]
        args={'pairs':pairs} if op=='batch_put' else {'keys':['0000']}
        records.append(dict(type='invoke',seq=seq,monotonic_ns=seq,id=i,phase=phase,op=op,args=args));seq+=1
        records.append(dict(type='return',seq=seq,monotonic_ns=seq,id=i,outcome='ok'));seq+=1
    return records

class ReaderControls(unittest.TestCase):
    def test_actual_single_line_store_prepare_cli_receipt(self):
        text='store_prepared=true node_id=2 store_incarnation='+'a'*32+'\n'
        self.assertEqual(c.prepared_store(text,2)['node_id'],'2')
        for bad in (text.replace('node_id=2','node_id=3'),text.replace('true','false'),
                    text+' node_id=2',text.replace('a'*32,'a'*31)):
            with self.assertRaises(ValueError):c.prepared_store(bad,2)
    def test_fault_requires_all_three_preceding_topologies_and_prior_recovery_read(self):
        def group(start):return {n:dict(topology=start+int(n)*2,topology_after=start+int(n)*2+1)for n in '123'}
        args=[1,group(2),12,13,group(14),23,24,30,group(31)]
        c.observation_order(*args)
        for index,value in [(2,8),(5,25),(7,35)]:
            changed=copy.deepcopy(args);changed[index]=value
            with self.assertRaises(ValueError):c.observation_order(*changed)
        changed=copy.deepcopy(args);del changed[1]['3']
        with self.assertRaises(ValueError):c.observation_order(*changed)
    def test_selected_successor_and_fresh_sequence(self):
        a={n:top()for n in '123'};b=copy.deepcopy(a);d={n:top(3,generation=3)for n in '123'}
        c.sequence_advance(a,b,d)
        self.assertEqual(a['1']['active']['sequence'],2)
    def test_checksum_corruption_and_missing_physical_header_refused(self):
        raw,headers=encoded()
        with self.assertRaises(ValueError):c.selected_topology(raw[:-1]+bytes([raw[-1]^1]),headers)
        del headers['2']
        with self.assertRaises(ValueError):c.selected_topology(raw,headers)
    def test_wrong_physical_header_and_path_refused(self):
        raw,h=encoded();h['2']['header_hex']=h['1']['header_hex']
        with self.assertRaises(ValueError):c.selected_topology(raw,h)
        raw,h=encoded();h['2']['path']='/tmp/unselected.wal'
        with self.assertRaises(ValueError):c.selected_topology(raw,h)
    def test_generation_alone_is_not_rotation(self):
        a={n:top() for n in '123'};b={n:top(generation=3)for n in '123'}
        with self.assertRaises(ValueError):c.sequence_advance(a,a,b)
    def test_store_change_or_missing_voter_refused(self):
        a={n:top() for n in '123'};b={n:top(3,generation=3)for n in '123'}
        b['1']=top(3,stream=b'b'*16,generation=3)
        with self.assertRaises(ValueError):c.sequence_advance(a,a,b)
        del b['1']
        with self.assertRaises(ValueError):c.sequence_advance(a,a,b)
    def test_actual_fault_exact_leader_same_storage(self):
        f,b,a=fault_fixture();self.assertEqual(c.fault_check(f,b,a,'2','owned',b'life',b'life')['exit_code'],137)
        with self.assertRaises(ValueError):c.fault_check(f,b,a,'1','owned',b'life',b'life')
        with self.assertRaises(ValueError):c.fault_check(f,b,a,'2','owned',b'life',b'changed')
    def test_fault_receipt_restart_and_alias_refused(self):
        for mutation in ('not-injected','wrong-selector','wrong-uid','wrong-exit','twice'):
            f,b,a=fault_fixture()
            if mutation=='not-injected':f['status']['conditions'][0]['status']='False'
            if mutation=='wrong-selector':f['spec']['selector']['pods']={'owned':['kv9-n1']}
            if mutation=='wrong-uid':a['metadata']['uid']='replacement'
            if mutation=='wrong-exit':a['status']['containerStatuses'][0]['lastState']['terminated']['exitCode']=0
            if mutation=='twice':a['status']['containerStatuses'][0]['restartCount']=2
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):c.fault_check(f,b,a,'2','owned',b'life',b'life')
    def test_fresh_three_voter_drain(self):
        result=c.drain_check(drain_samples());self.assertEqual(result['advances'],dict.fromkeys('123',2))
        self.assertEqual(json.loads(json.dumps(result)),result)
    def test_stale_missing_identity_or_not_applied_drain_refused(self):
        for mutation in ('stale','missing','identity','not-applied'):
            rows=drain_samples()
            if mutation=='stale':rows[-1]=copy.deepcopy(rows[-2])
            if mutation=='missing':del rows[-1]['3']
            if mutation=='identity':rows[-1]['1']['process_start_ticks']=101
            if mutation=='not-applied':rows[-1]['1']['state_after']['driver_applied_index']='9'
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):c.drain_check(rows)
    def test_complete_population_and_outcomes(self):
        result=c.history_population(ledger(),P);self.assertEqual(result['calls'],56);self.assertEqual(result['acknowledged_batches'],45)
        for mutate in ('missing','duplicate','reordered','unknown','short'):
            rows=ledger()
            if mutate=='missing':rows.pop()
            if mutate=='duplicate':rows.append(rows[-1])
            if mutate=='reordered':rows[2],rows[3]=rows[3],rows[2]
            if mutate=='unknown':rows[4]['outcome']='unknown'
            if mutate=='short':rows=rows[:-2]
            with self.subTest(mutation=mutate),self.assertRaises(ValueError):c.history_population(rows,P)
    def test_complete_recovery_values_and_empty_sentinel(self):
        values={'aa':'dead','bb':''};text='@@KEY:aa@@\nfound=true\nvalue_hex=dead\n@@KEY:bb@@\nfound=true\nvalue_hex=\n'
        self.assertEqual(c.query_check(text,values)['keys'],2)
        for changed in (text.replace('dead','beef'),text.replace('value_hex=\n','found=false\n'),text+text):
            with self.assertRaises(ValueError):c.query_check(changed,values)
    def test_frozen_native_configuration_and_bootstrap_output_location(self):
        services={'1':'10.0.0.1','2':'10.0.0.2','3':'10.0.0.3'}
        config=dict(P['config'],run_id='pdrot-pre-1-2',keyspace_name='pdrot-pre-1-2',client=dict(P['client'],keyspace_id=1,
                 peers=[dict(node_id=n,address=services[str(n)]+':20160')for n in (1,2,3)]))
        c.config_check(config,P,'pre','1-2',services)
        config['value_bytes']=128
        with self.assertRaises(ValueError):c.config_check(config,P,'pre','1-2',services)
        script=pod_spec(P,'owned',1)['spec']['containers'][0]['command'][-1]
        self.assertIn('> /tmp/prepared.txt',script)
        self.assertNotIn('--data-dir /data > /data/prepared.txt',script)

if __name__=='__main__':unittest.main(verbosity=2)
