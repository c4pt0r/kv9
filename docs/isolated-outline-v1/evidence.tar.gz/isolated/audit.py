#!/usr/bin/env python3
"""Recheck the exact isolated candidate qualification without rerunning workloads."""
from pathlib import Path
import hashlib,json,re,subprocess,tarfile
S=Path(__file__).resolve().parent;R=Path('/home/dongxu/kv9')
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=load(S/'qualification-plan.json');build=load(S/'build-summary.json');proof=load(S/'proof-isolated/result.json');dependency=load(S/'proof-dependency/result.json');tests=load(S/'tests-accepted.json');prep=load(S/'preparation-summary.json');code=load(S/'codegen-review.json')
assert build['complete'] and proof['accepted'] and dependency['accepted'] and tests['complete'] and prep['complete'] and code['complete']
assert build['plan_sha256']==sha(S/'qualification-plan.json')
pins=[build['sources'],load(S/'proof-isolated/source-inputs.json'),load(S/'proof-dependency/source-inputs.json'),code['source_sha256']]
pins += [load(S/f'tests-{name}/sources.json')for name in ('archery','rpds')]
pins += [load(S/'tests-engine-v2/sources.json')]
for group in pins:
 for path,digest in group.items():assert sha(Path(path))==digest,path
for name,archive in plan['archives'].items():
 path=Path(archive['path']);assert sha(path)==archive['sha256']
 with tarfile.open(path)as tar:
  root=Path(archive['source'])
  for p in [root/'Cargo.toml',*sorted((root/'src').rglob('*.rs'))]:
   member=str(Path(root.name)/p.relative_to(root));assert tar.extractfile(member).read()==p.read_bytes()
assert len(proof['theorems'])==3 and len(proof['controls'])==5
assert len(dependency['guard_theorems'])==18 and len(dependency['adapter_theorems'])==8 and len(dependency['controls'])==9
assert all(c['rejected']for c in proof['controls']+dependency['controls'])
count=0;ignored=0
for directory,expected in [('tests-archery',58),('tests-rpds',276),('tests-engine-v2',189)]:
 actual=0
 for p in (S/directory).glob('*-tests.stdout'):
  result=re.findall(r'^test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; 0 filtered out;',p.read_text(),re.M);assert len(result)==1
  actual+=int(result[0][0]);ignored+=int(result[0][1])
 assert actual==expected;count+=actual
assert count==523 and ignored==3
original=S/'registry/triomphe-0.1.16/src';candidate=S/'candidate-triomphe/src'
left={str(p.relative_to(original)):p.read_bytes()for p in original.rglob('*.rs')}
right={str(p.relative_to(candidate)):p.read_bytes()for p in candidate.rglob('*.rs')}
assert left.keys()==right.keys()and [n for n in left if left[n]!=right[n]]==['arc.rs']
assert len(prep['processes'])==2 and prep['live_prefixes']==848 and prep['old_views']==424 and prep['probe_sets']==4
for row in prep['processes']:
 assert row['complete']and row['exit_code']==0
 arm=row['arm'];p=S/'preparation'/f'{arm}.json';assert sha(p)==row['result_sha256']and p.stat().st_size==row['bytes']
 assert row==load(S/'preparation'/f'{arm}-terminal.json')
 binary=build['arms'][arm]['binary'];assert sha(Path(binary['path']))==binary['sha256']==row['binary_sha256']
 graph=load(S/f'build-{arm}/metadata.json')
 for name in ('archery','rpds'):
  pkg=[p for p in graph['packages']if p['name']==name];assert len(pkg)==1 and pkg[0]['source'].startswith('registry+')
 closure='::make_mut::{{closure}}'
 symbols=(S/f'build-{arm}/symbols.txt').read_text()
 assert (closure in symbols)==(arm=='baseline')
 disassembly=(S/f'build-{arm}/disassembly.txt').read_text()
 assert '::write_applied>'in disassembly and '::snapshot>'in disassembly
assert load(S/'preparation/baseline.json')==load(S/'preparation/candidate.json')
# Child PID reuse is not interpreted as a still-running benchmark.
for row in prep['processes']:
 p=Path(f'/proc/{row["pid"]}/stat')
 if p.exists():assert int(p.read_text().rsplit(')',1)[1].split()[19])!=row['start_ticks']
result=dict(complete=True,source_groups_checked=len(pins),tests_passed=count,tests_ignored=ignored,
 total_conditional_theorems=29,total_rejecting_controls=14,live_prefixes=848,old_views=424,probe_sets=4,
 original_archery_and_rpds=True,only_triomphe_extraction=True,codegen_work_removed=True,
 promotion_authorized=False,performance_executed=False,all_preparation_children_terminal=True,
 limits='Conditional source correspondence, not verified Rust extraction. No new MinIO, recovery, Chaos, end-to-end performance or Redis acceptance.')
(S/'qualification-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
