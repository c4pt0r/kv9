#!/usr/bin/env python3
"""Retain the complete qualification, excluding executable and duplicate corpus bytes."""
from pathlib import Path
import hashlib,json,tarfile,shutil
R=Path('/home/dongxu/kv9');S=Path(__file__).resolve().parent;D=R/'docs/isolated-outline-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((S/'qualification-audit.json').read_text())['complete'];D.mkdir(exist_ok=False)
files=[]
roots=['qualification-plan.json','build-summary.json','proof-isolated','proof-dependency','tests-summary.json','tests-accepted.json','tests-engine-v2-summary.json','engine-test-fixture-correction.json','codegen-review.json','qualification-audit.json','preparation-summary.json','plan.json','reference-inputs.py','next-performance-plan.json','triomphe.patch','insert-baseline.txt','insert-candidate.txt','audit.py','package.py','candidate-triomphe','registry','build-baseline','build-candidate','source-baseline','source-candidate','tests-archery-source','tests-rpds-source','tests-engine-source','tests-engine-source-v2','tests-archery','tests-rpds','tests-engine','tests-engine-v2','preparation']
for name in roots:
 root=S/name
 for p in sorted(root.rglob('*'))if root.is_dir()else[root]:
  if not p.is_file()or p.is_symlink()or '__pycache__'in p.parts or p.name=='engine-interface'or p.name.endswith('-tests'):continue
  files.append((p,Path('isolated')/p.relative_to(S)))
for root,prefix in [(R/'scripts/isolated-outline','published-tools'),(R/'proofs/lean/isolated-outline','published-proof')]:
 for p in sorted(root.rglob('*')):
  if p.is_file()and '__pycache__'not in p.parts:files.append((p,Path(prefix)/p.relative_to(root)))
assert len({str(n)for _,n in files})==len(files)
members=[dict(path=str(n),bytes=p.stat().st_size,sha256=sha(p))for p,n in files]
archive=D/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6)as tar:
 for p,n in files:tar.add(p,arcname=str(n),recursive=False)
with tarfile.open(archive,'r:gz')as tar:
 actual=tar.getmembers();assert len(actual)==len(members)
 for info,row in zip(actual,members):
  assert info.isfile()and info.name==row['path']and info.size==row['bytes']
  assert hashlib.sha256(tar.extractfile(info).read()).hexdigest()==row['sha256']
manifest=dict(complete=True,members=len(members),expanded_bytes=sum(m['bytes']for m in members),compressed_bytes=archive.stat().st_size,sha256=sha(archive),all_members_read_back=True,
 local_root=str(S),excluded=['Executable binaries (retained locally and hashed in build/test records)','Duplicate groups.bin','GitHub payloads and mutable continuation'],
 external=dict(corpus='../outlined-mutation-path-v1/evidence.tar.gz:outlined/groups.bin',corpus_sha256=sha(S/'groups.bin'),prior_proof_work='../outlined-mutation-path-v1/evidence.tar.gz:outlined/ source/qualification tree; required by the inherited dependency proof checker',registry_archives='Original .crate archives matching Cargo.lock SHA-256 values in qualification-plan.json'),
 binaries={arm:json.loads((S/'build-summary.json').read_text())['arms'][arm]['binary']for arm in ('baseline','candidate')})
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'members.json').write_text(json.dumps(members,indent=2)+'\n')
for name in ('qualification-audit.json','codegen-review.json','next-performance-plan.json'):
 shutil.copyfile(S/name,D/name)
(D/'README.md').write_text(f'''# Isolated shared-clone qualification evidence

See the [report](../ISOLATED-OUTLINE-QUALIFICATION.md). Source, conditional proof,
release codegen and correctness qualification pass. No timing or production
promotion is included; the next screen remains prospective.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['sha256']}`.
Every member size/hash passed readback. [members.json](members.json) and
[manifest.json](manifest.json) record all retained bytes and exclusions.

The packet contains exact registry and candidate dependency sources, both release
source/build transactions and disassemblies, 29 conditional proof checks / 14
rejecting controls, 523 passed tests / three existing ignored tests, and both
independently validated semantic preparations. The failed initial engine fixture
metadata and its corrected continuation are both retained. Source copies and
logs identify original registry archery in actual release and engine/rpds tests;
the archery-specific fixture also includes retained test-only callback cases.

The original corpus is already published as `outlined/groups.bin` in the
[outlined packet](../outlined-mutation-path-v1/README.md), SHA-256
`{manifest['external']['corpus_sha256']}`. The inherited proof checker also uses
that packet's original combined-candidate source tree for dependency lemmas;
the isolated composition binds original archery separately. Archive checksums
for upstream `.crate` inputs are in `qualification-plan.json`. Compiled binaries
remain local, with exact hashes in their records.

Reproduction preserves recorded absolute paths. Restore them or adapt a fresh
experiment before building; never relabel an existing result. The
[next screen plan](next-performance-plan.json) is not executed evidence.
No MinIO, ordinary recovery, actual Chaos, database QPS or Redis acceptance is
claimed by this packet.
''')
print(json.dumps({k:v for k,v in manifest.items()if k not in ('external','binaries')}))
