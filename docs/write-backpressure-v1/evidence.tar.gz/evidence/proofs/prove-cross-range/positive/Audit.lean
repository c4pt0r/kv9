import CrossRange
#print axioms Kv9.CrossRange.initial_safe
#print axioms Kv9.CrossRange.step_safe
#print axioms Kv9.CrossRange.run_safe
#print axioms Kv9.CrossRange.chunks_walk_in_key_order
#print axioms Kv9.CrossRange.chunks_require_the_partition
#print axioms Kv9.CrossRange.no_key_is_skipped
#print axioms Kv9.CrossRange.no_key_is_duplicated
#print axioms Kv9.CrossRange.the_span_is_never_one_snapshot
#print axioms Kv9.CrossRange.a_chunk_is_permanent
#print axioms Kv9.CrossRange.a_partition_alone_serves_nothing
#print axioms Kv9.CrossRange.the_span_completes_across_the_boundary
