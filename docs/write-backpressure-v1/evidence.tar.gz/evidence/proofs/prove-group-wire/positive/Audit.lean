import Wire
#print axioms Kv9.GroupWire.data_method
#print axioms Kv9.GroupWire.legacy_drops_data
#print axioms Kv9.GroupWire.modern_metadata_rejects_data
#print axioms Kv9.GroupWire.modern_data_rejects_metadata
#print axioms Kv9.GroupWire.reserved_never_sent
#print axioms Kv9.GroupWire.stale_generation_dropped
#print axioms Kv9.GroupWire.no_cross_group_delivery
#print axioms Kv9.GroupWire.arbitrary_reconnections_safe
#print axioms Kv9.GroupWire.legacy_fallback_is_unsafe
#print axioms Kv9.GroupWire.mixed_batch_rejected
#print axioms Kv9.GroupWire.enqueue_bounded
#print axioms Kv9.GroupWire.data_preserves_metadata_capacity
#print axioms Kv9.GroupWire.full_data_still_admits_metadata
#print axioms Kv9.GroupWire.step_bounded
#print axioms Kv9.GroupWire.reachable_bounded
