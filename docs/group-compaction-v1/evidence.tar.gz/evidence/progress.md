# Healthy-group compaction — task #35 (e2e-ninth ACCEPTED)

Baseline f47cfde. Port 27360. THE hard bug: e2e ran STALE binaries for
runs 3-8 because a leftover `}` broke kv9-raft compilation (cargo build
reported it, run-e2e.sh used the old binary). Lesson: verify
`strings target/debug/kv9 | grep <sentinel>` after any raft-crate edit.

## Implemented
- meta compaction.rs: kind-110 GroupCompaction (region, floor,
  creation_task); plan_compaction (strictly-increasing floors/region,
  exact confirm, creation-bound); committed_compaction_floors (highest
  per region). 2 unit tests.
- runtime record_group_compaction verb + reconcile_compaction (LEADER-
  ONLY v1 via truncate_retained_log all-matched seam; follower log
  bounding = documented open edge); RPC/proto/CLI/client/3 stubs.
- CORE FIX: DiskRaftStorage::configuration_at_committed refused ALL
  compacted logs (first_index!=1 -> ProtocolHistoryCompacted), so a
  SECOND compaction floor above an earlier one failed
  ("no committed configuration"). Now: a cut at/above the compacted
  base with no unapplied config in the retained tail INHERITS the base
  config (from the mem snapshot restored by compact_memory); a cut
  below the base still refuses. Test rewritten to the new contract.
  THIS ALSO fixes migration re-truncation on an already-compacted log.
- status_json exposes log_first_index (raft log is append-only; the
  compaction signal is the first-index advance, NOT file bytes).

## e2e-ninth accepted
Two rounds: burst -> commit floor -> leader first-index advances past
floor; second higher floor compacts again (exercises the config fix);
stale floor refuses; full restart on compacted logs + all keys serve +
keeps writing.

## Remaining
- [ ] Lean model + prover + contract + sibling refresh
- [ ] docs/GROUP-COMPACTION.md + qualify (32 models) + packet + issues
      #9 (replace) + #20-or-new + publish
- retained failed e2e: e2e-first (bytes metric wrong), e2e-second/third/
  fourth/fifth/sixth/seventh/eighth chain (stale binary + bytes metric +
  the config bug), e2e-ninth accepted.
