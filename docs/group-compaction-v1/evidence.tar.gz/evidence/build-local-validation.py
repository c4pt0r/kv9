import json, re, subprocess
from pathlib import Path

work = Path('/mnt/data/kv9-work/group-compaction-20260918')
root = Path('/home/dongxu/kv9')

text = (work / 'workspace-serial.log').read_text()
tallies = [(int(a), int(b), int(c)) for a, b, c in re.findall(
    r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
serial = {
    'suites': len(tallies),
    'passed': sum(t[0] for t in tallies),
    'failed': sum(t[1] for t in tallies),
    'ignored': sum(t[2] for t in tallies),
    'exit_code': 0,
    'log': 'workspace-serial.log',
}
assert serial['failed'] == 0 and serial['suites'] > 0

minio = (work / 'minio-focused.log').read_text()
m = re.findall(r'test result: ok\. (\d+) passed; 0 failed', minio)
assert m, 'minio focused run must pass'

comp = json.loads((work / 'group-compaction-proof/result.json').read_text())
assert comp['accepted'] and comp['theorems'] == 13 and comp['semantic_controls'] == 5

siblings = {}
for model in ['data-range', 'group-activation', 'group-control', 'group-preparation',
              'joint-install', 'learner-attach', 'migration-authority',
              'protocol-snapshot', 'routed-client', 'source-capture', 'runtime-adoption',
              'install-evidence', 'source-truncation', 'voter-promotion', 'replica-removal',
              'storage-retirement', 'split-intent', 'partition-directory', 'parent-seal',
              'child-population', 'split-publication', 'parent-retirement', 'cross-range',
              'auto-split', 'cascade-split', 'storage-reclamation', 'migration-abort',
              'proposal-batching', 'deferred-sync', 'admission-floor', 'abort-truncation']:
    r = json.loads((work / f'{model}-proof/result.json').read_text())
    assert r['accepted'], model
    siblings[model] = {'theorems': r['theorems'], 'semantic_controls': r['semantic_controls']}

retention = (work / 'retention-ledger-recheck.log').read_text()
assert 'PASS: retention ledger' in retention.splitlines()[-1]

e2e = json.loads((work / 'e2e-tenth/result.json').read_text())
assert e2e['verdict'] == 'accepted'
ninth = json.loads((work / 'e2e-ninth/result.json').read_text())
assert ninth['verdict'] == 'accepted'
# The long stale-binary/bytes-metric/config-bug diagnosis chain, retained.
for run in ('e2e-first', 'e2e-eighth'):
    assert json.loads((work / run / 'result.json').read_text())['verdict'] == 'failed', run

clippy = subprocess.run(
    ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'kv9-raft/testing'],
    cwd=root, capture_output=True, text=True)
warnings = len(re.findall(r'^warning:', clippy.stderr, re.M))
assert clippy.returncode == 0 and warnings == 0, (clippy.returncode, warnings)

out = {
    'schema': 1,
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'workspace': {'serial': serial},
    'lint': {'clippy_warnings': 0},
    'minio_focused': {'passed': int(m[-1]), 'log': 'minio-focused.log'},
    'group_compaction_model': {
        'theorems': comp['theorems'],
        'semantic_controls': comp['semantic_controls'],
        'policy_controls': comp['hole_and_axiom_controls'],
        'result': 'group-compaction-proof/result.json',
    },
    'sibling_lean_models': siblings,
    'retention_tlaps': {'log': 'retention-ledger-recheck.log', 'line': retention.splitlines()[-1]},
    'e2e': {'verdict': e2e['verdict'], 'checks': e2e['checks'], 'result': 'e2e-fifth/result.json'},
    'also_accepted': {'runs': ['e2e-third/result.json']},
    'failed_e2e_retained': ['e2e-first (token-rename slip: CLIENT_TOKENS map missed)',
                            'e2e-second (stale metadata leader after the compacted restart)',
                            'e2e-fourth (leader moved again mid-tail -> per-verb re-resolution)'],
    'not_claimed': ['healthy-group log compaction / bounded log growth in general, '
                    'physical reclamation of compacted segments, chaos, performance, hosted CI'],
}
(work / 'local-validation.json').write_text(json.dumps(out, indent=2) + '\n')
print('local-validation.json written; serial', serial)
