# Raw apply attribution preparation

The active server and selected features are unchanged. This isolated program
will use production decode/lowering/catalog-fence APIs from the pinned source.
The `testing` capability enables the harness decoder only; no server is built
or launched. Exact engine-group tails must join the original Raft commands,
and lowered mutations must reproduce every selected engine payload byte.
All setup, replay, file I/O and validation stay outside timed component loops.
Allocation counting uses a separate feature build so the timing executable
keeps the direct production jemalloc allocator.
