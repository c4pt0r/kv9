#!/usr/bin/env python3
import hashlib,json,struct,zlib
from pathlib import Path
R=Path(__file__).resolve().parent
plan=json.loads((R/'plan.json').read_text());meta=plan['engine_segment'];source=Path(meta['source'])
before=source.stat();raw=source.read_bytes();after=source.stat()
assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
assert len(raw)==meta['bytes']<=plan['guard']['max_engine_segment_bytes'] and hashlib.sha256(raw).hexdigest()==meta['sha256']
h=raw[:60];assert h[:8]==b'KV9SEG01' and h[32]==1 and h[33:40]==bytes(7) and zlib.crc32(h[:56])==int.from_bytes(h[56:60],'little')
previous=int.from_bytes(h[48:56],'little');previous_term=int.from_bytes(h[40:48],'little');start_previous=previous
pos=60;rows=[];out=bytearray(b'KV9GRP01')
while pos<len(raw):
 f=raw[pos:pos+32];assert len(f)==32 and f[:4]==b'KV9R' and f[8]==1 and f[9:12]==bytes(3) and zlib.crc32(f[:28])==int.from_bytes(f[28:32],'little')
 size=int.from_bytes(f[4:8],'little');assert 4<=size<=64*1024**2
 term=int.from_bytes(f[12:20],'little');index=int.from_bytes(f[20:28],'little');assert index>previous and term>=previous_term
 body=raw[pos+32:pos+32+size];crc=raw[pos+32+size:pos+36+size]
 assert len(body)==size and len(crc)==4 and zlib.crc32(body,zlib.crc32(f[:28],zlib.crc32(h[:56])))==int.from_bytes(crc,'little')
 out.extend(struct.pack('<QQQI',previous,index,term,size));out.extend(body)
 rows.append(dict(previous=previous,index=index,term=term,mutations=int.from_bytes(body[:4],'little'),payload_bytes=size,payload_sha256=hashlib.sha256(body).hexdigest()))
 previous=index;previous_term=term;pos+=36+size
assert pos==len(raw) and len(rows)==106 and sum(x['mutations']for x in rows)==100096
with(R/'groups.bin').open('xb')as f:f.write(out)
summary=dict(complete=True,source=meta,source_identity_unchanged=True,groups=len(rows),first_predecessor=start_previous,last_index=previous,mutations=sum(x['mutations']for x in rows),group_file_bytes=len(out),group_file_sha256=hashlib.sha256(out).hexdigest(),rows=rows,scope='Every selected engine frame passes CRC and position checks. Command boundaries and fence results are still unverified until exact Raft join.')
(R/'groups.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ('rows','source')}))
