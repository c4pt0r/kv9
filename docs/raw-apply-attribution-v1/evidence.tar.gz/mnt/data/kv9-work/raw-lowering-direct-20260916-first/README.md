# Direct Raw lowering prototype

Only the temporary per-command mutation vectors are removed. Original command
order, cloned key/value ownership, CF conversion and final batch growth remain.
Production code is unchanged. The original corpus must match both lowerers
byte-for-byte before timing; all original fence outcomes are checked first.
The prototype is an accepted-path component and supplies no generic authority
to skip adjudication. Baseline and candidate run in opposite orders on CPU 4.
No prior component timing is pooled into this changed-variable comparison.
