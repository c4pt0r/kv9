#!/usr/bin/env python3
import hashlib,importlib.util,json,os,shutil,subprocess,time,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent;B=R/'bench';OUT=R/'build-first';OUT.mkdir(exist_ok=False)
SOURCE=Path(json.loads((R/'plan.json').read_text())['source']);target=Path('/home/dongxu/kv9/target')
os.environ['CARGO_TARGET_DIR']=str(target);os.environ['CARGO_BUILD_JOBS']='4'
assert not os.environ.get('RUSTFLAGS') and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 files=list((SOURCE/'crates').rglob('*.rs'))+list((SOURCE/'crates').rglob('*.proto'))+list((SOURCE/'crates').rglob('Cargo.toml'))+[SOURCE/'Cargo.toml',SOURCE/'Cargo.lock']
 return {str(p):sha(p)for p in files}
def registry(lock):
 return {(p['name'],p['version'],p['source']):p['checksum']for p in tomllib.loads(lock.read_text())['package']if p.get('source','').startswith('registry+')}
before=sources();original=registry(SOURCE/'Cargo.lock')
commands=[];result=dict(complete=False,started_ns=time.time_ns())
def run(argv,name,timeout=900):
 commands.append(dict(argv=argv,name=name))
 with(OUT/(name+'.stdout')).open('x')as out,(OUT/(name+'.stderr')).open('x')as err:
  x=subprocess.run(argv,cwd=B,stdout=out,stderr=err,timeout=timeout)
 commands[-1]['exit_code']=x.returncode;assert x.returncode==0,(name,x.returncode)
try:
 run(['cargo','metadata','--offline','--format-version','1','--manifest-path',str(B/'Cargo.toml')],'resolve')
 resolved=registry(B/'Cargo.lock');assert all(k in original and original[k]==v for k,v in resolved.items()),'Registry dependency drift'
 shutil.copyfile(B/'Cargo.lock',OUT/'Cargo.lock');(OUT/'dependency-binding.json').write_text(json.dumps(dict(complete=True,registry_packages=len(resolved),registry_identities_match_original=True,lock_sha256=sha(B/'Cargo.lock')),indent=2)+'\n')
 for tool in ('rustc','cargo'):run([tool,'--version','--verbose'],tool,30)
 spec=importlib.util.spec_from_file_location('cache',Path('/home/dongxu/kv9/scripts/build_cache.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 artifacts={}
 with m.BuildCache(B,OUT,True,dict(source=before,bench={str(p):sha(p)for p in (B/'Cargo.toml',B/'Cargo.lock',B/'src/main.rs')}))as cache:
  for name,features in [('timing',[]),('allocations',['--features','allocation-counting'])]:
   argv=['cargo','build','--offline','--locked','--release','--manifest-path',str(B/'Cargo.toml'),'--bin','kv9-raw-apply-attribution','--message-format','json-render-diagnostics',*features]
   log=OUT/(name+'.jsonl')
   with log.open('x')as out,(OUT/(name+'.stderr')).open('x')as err:cache.run(argv,stdout=out,stderr=err,timeout=1200)
   cache.check_artifacts(log);binary=target/'release/kv9-raw-apply-attribution';copy=OUT/('raw-apply-'+name);shutil.copyfile(binary,copy);copy.chmod(0o755);artifacts[name]=dict(path=str(copy),bytes=copy.stat().st_size,sha256=sha(copy),argv=argv)
  with(OUT/'semantics-test.stdout').open('x')as test_out,(OUT/'semantics-test.stderr').open('x')as test_err:
   cache.run(['cargo','test','--offline','--locked','--release','--manifest-path',str(B/'Cargo.toml'),'--bin','kv9-raw-apply-attribution','tests::direct_append_preserves_order_deletes_empty_inputs_and_all_column_families','--','--exact','--nocapture'],stdout=test_out,stderr=test_err,timeout=300)
  assert '1 passed; 0 failed' in (OUT/'semantics-test.stdout').read_text()
 assert before==sources(),'Protected dependency source changed'
 result.update(complete=True,artifacts=artifacts,source_files=len(before),source_pins=before,bench_sources={str(p):sha(p)for p in (B/'Cargo.toml',B/'Cargo.lock',B/'src/main.rs')},registry_packages=len(resolved))
except BaseException as e:result['failure']=repr(e);raise
finally:
 result.update(ended_ns=time.time_ns(),commands=commands);(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ('source_pins','commands')}))
