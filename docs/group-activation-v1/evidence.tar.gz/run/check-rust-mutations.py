import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/dongxu/kv9')
out=Path('/mnt/data/kv9-work/group-activation-20260916/rust-controls')
out.mkdir(exist_ok=False)
manager='crates/server/src/region_manager.rs'; pool='crates/raft/src/driver/pool.rs'; work='crates/raft/src/work.rs'
activation='region_manager::tests::group_activation_'
scheduling='driver::pool::tests::group_pool_'
controls=[
('missing-durable-active',manager,'if prepared.phase == Phase::StorageReady {','if false && prepared.phase == Phase::StorageReady {','kv9-server',activation+'publication_cuts_never_start_an_unfenced_voter','assertion failed: fired && result.is_err()'),
('active-log-reinitialized',manager,'if record.phase != Phase::IntentDurable {','if record.phase == Phase::StorageReady {','kv9-server',activation+'recovery_refuses_missing_or_empty_stores_and_foreign_history','unsafe active recovery accepted mode=0'),
('missing-fixed-membership',manager,'storage.validate_fixed_group(&voters)?;','let _ = &voters;','kv9-server',activation+'recovery_refuses_missing_or_empty_stores_and_foreign_history','unsafe active recovery accepted mode=3'),
('unchecked-engine-frame',manager,'Some(at) if storage.committed_term(at.index)? == at.term => Ok(()),','Some(_) => Ok(()),','kv9-server',activation+'recovery_refuses_missing_or_empty_stores_and_foreign_history','unsafe active recovery accepted mode=9'),
('lost-producer-wakeup',work,'self.changed.notify_one();\n            drop(state);\n            self.notify_parent();','self.changed.notify_one();\n            drop(state);','kv9-raft',scheduling+'preexisting_and_parked_notifications_do_not_wait_for_ticks','shared owner must apply work without waiting for the 60-second tick'),
('duplicate-slot-owner',pool,'if slot.running || slot.finished {','if slot.finished {','kv9-raft',scheduling+'blocked_group_does_not_hold_registry_or_other_worker','one blocked group starved another worker'),
('extra-background-owner',pool,'driver\n            .pump_started\n            .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)\n            .map_err(|_| Error::Raft("background pump already owns this driver".into()))?;','// defect: do not claim the driver background owner','kv9-raft',scheduling+'caps_groups_and_refuses_duplicate_background_owners','assertion failed: first.spawn(Duration::from_millis(1)).is_err()'),
('group-cap-off-by-one',pool,'registry.slots.len() >= MAX_GROUPS','registry.slots.len() > MAX_GROUPS','kv9-raft',scheduling+'caps_groups_and_refuses_duplicate_background_owners','assertion failed: pool.register(driver(MAX_GROUPS as u64 + 2)).is_err()'),
]
results=[]
for label,name,before,after,package,test,failure in controls:
 path=root/name;original=path.read_text();assert original.count(before)==1,label
 mutated=original.replace(before,after)
 directory=out/label;directory.mkdir();(directory/path.name).write_text(mutated);path.write_text(mutated)
 try:
  cmd=['cargo','test','-p',package,'--lib',test,'--','--exact','--nocapture']
  result=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,env=dict(__import__('os').environ,KV9_TEST_DATA_DIR=str(out/'fixtures')))
  (directory/'test.log').write_text(result.stdout)
  assert result.returncode==101 and 'running 1 test' in result.stdout and failure in result.stdout,(label,result.stdout)
  results.append(dict(label=label,source=name,command=cmd,exit_code=result.returncode,expected_failure=failure,source_sha256=hashlib.sha256(mutated.encode()).hexdigest()))
 finally:
  assert path.read_text()==mutated,'concurrent source edit: refusing to overwrite'
  path.write_text(original)
 print(label+': rejected',flush=True)
(out/'result.json').write_text(json.dumps({'accepted':True,'controls':results},indent=2)+'\n')
