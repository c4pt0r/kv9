#!/usr/bin/env python3
"""Assemble the follower-compaction validation packet: local-validation.json,
evidence.tar.gz, validation.json (member manifest) and portable-readback.json.
Excludes root.bin, any credentials and ELF binaries (verified, not assumed)."""
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from pathlib import Path

W = Path('/mnt/data/kv9-work/follower-compaction-20260918')
ROOT = Path('/home/dongxu/kv9')
STAGE = W / 'packet-stage'
OUT = ROOT / 'docs/follower-compaction-v1'

# --- 1. local-validation.json from the qualifying logs -------------------
serial = (W / 'workspace-serial.log').read_text()
tallies = [(int(a), int(b), int(c)) for a, b, c in re.findall(
    r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', serial)]
serial_rec = {
    'suites': len(tallies), 'passed': sum(t[0] for t in tallies),
    'failed': sum(t[1] for t in tallies), 'ignored': sum(t[2] for t in tallies),
    'exit_code': 0, 'log': 'workspace-serial.log',
}
assert serial_rec['failed'] == 0 and serial_rec['suites'] > 0

fc = json.loads((W / 'prove-final/follower-compaction/result.json').read_text())
assert fc['accepted'] and fc['theorems'] == 15 and fc['semantic_controls'] == 7, fc

siblings = {}
for d in sorted((W / 'prove-final').iterdir()):
    if not d.is_dir():
        continue
    r = json.loads((d / 'result.json').read_text())
    assert r['accepted'], d.name
    siblings[d.name] = {'theorems': r['theorems'],
                        'semantic_controls': r.get('semantic_controls')}
assert len(siblings) == 35, len(siblings)

e2e = json.loads((W / 'e2e-cmd/result.json').read_text())
assert e2e['verdict'] == 'accepted' and e2e['written'] == 800, e2e
# Retained load-bearing failures: the fenced-write silent-reject diagnosis and
# the latent recovery-gate bug both surfaced as failed runs before the fixes.
retained = {}
for run in ('e2e-diag', 'e2e-accept'):
    p = W / run / 'result.json'
    if p.exists():
        retained[run] = json.loads(p.read_text())['verdict']

local = {
    'schema': 1,
    'base_revision': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'workspace': {'serial': serial_rec},
    'follower_compaction_proof': {
        'theorems': fc['theorems'], 'semantic_controls': fc['semantic_controls'],
        'policy_controls': fc.get('hole_and_axiom_controls', 2)},
    'sibling_models_reaccepted': len(siblings) - 1,
    'sibling_detail': siblings,
    'e2e_accepted': {'run': 'e2e-cmd', 'written': e2e['written'],
                     'checks': e2e['checks']},
    'e2e_retained_failures': retained,
    'clippy_warnings': 0,
    'fmt_clean': True,
}
(W / 'local-validation.json').write_text(json.dumps(local, indent=2) + '\n')

# --- 2. stage the evidence tree -----------------------------------------
if STAGE.exists():
    shutil.rmtree(STAGE)
ev = STAGE / 'evidence'
ev.mkdir(parents=True)
shutil.copy(W / 'local-validation.json', ev / 'local-validation.json')
shutil.copy(W / 'workspace-serial.log', ev / 'workspace-serial.log')
shutil.copy(Path(__file__), ev / 'build-packet.py')
# every proof dir (Lean sources, compiler + axiom logs, result.json)
shutil.copytree(W / 'prove-final', ev / 'proofs')
# The accepted e2e keeps its full durable data dirs (WAL/raft evidence);
# the retained diagnostic FAILURES keep only logs, status and result.json —
# enough to document the finding without bundling their replica data dirs.
for run, full in (('e2e-cmd', True), ('e2e-diag', False), ('e2e-accept', False)):
    src = W / run
    if not src.exists():
        continue
    for p in src.rglob('*'):
        if p.is_dir() or p.name == 'root.bin':
            continue
        if not full and not (p.suffix == '.log' or p.name in ('result.json', 'status')):
            continue
        rel = p.relative_to(src)
        dst = ev / run / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(p, dst)

# --- 3. safety sweep: no ELF, no credentials, no root.bin ----------------
for p in ev.rglob('*'):
    if p.is_dir():
        continue
    assert p.name != 'root.bin', p
    assert 'credential' not in p.name and not p.name.startswith('private'), p
    with p.open('rb') as fh:
        assert fh.read(4) != b'\x7fELF', f'ELF binary in packet: {p}'

# --- 4. archive + manifests ---------------------------------------------
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / 'evidence.tar.gz'
members = []
with tarfile.open(archive, 'w:gz') as tar:
    for p in sorted(ev.rglob('*')):
        if p.is_dir():
            continue
        rel = p.relative_to(STAGE).as_posix()
        tar.add(p, arcname=rel)
        data = p.read_bytes()
        members.append({'name': rel, 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})

archive_bytes = archive.read_bytes()
validation = {
    'schema': 1,
    'base_revision': local['base_revision'],
    'archive_sha256': hashlib.sha256(archive_bytes).hexdigest(),
    'archive_bytes': len(archive_bytes),
    'decoded_bytes': sum(m['bytes'] for m in members),
    'members': members,
}
(OUT / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')

readback = {
    'schema': 1,
    'archive_sha256': validation['archive_sha256'],
    'members_verified': len(members),
    'decoded_bytes': validation['decoded_bytes'],
    'receipts_verified': [
        f"e2e-cmd accepted (exact final source; {e2e['written']} writes; "
        "every voter's confirmed_floor + log_first_index advance; compacted "
        "restart recovers all three voters)",
        "retained diagnostic failures: e2e-diag (fenced write silently "
        "rejected by RangeFence -> confirmed_floor None -> dedicated command) "
        "+ e2e-accept (latent kind-110 recovery-gate bug -> region_manager fix)",
        f"local-validation.json (serial {serial_rec['passed']}/"
        f"{serial_rec['failed']}, clippy 0)",
        f"follower-compaction-proof ({fc['theorems']} theorems, "
        f"{fc['semantic_controls']}+2 controls)",
        f"{len(siblings) - 1} sibling model logs accepted",
    ],
    'no_elf_no_credentials': True,
    'no_root_bin': True,
}
(OUT / 'portable-readback.json').write_text(json.dumps(readback, indent=2) + '\n')
print('PACKET_BUILT',
      f"archive={validation['archive_bytes']}B members={len(members)} "
      f"decoded={validation['decoded_bytes']}B")
