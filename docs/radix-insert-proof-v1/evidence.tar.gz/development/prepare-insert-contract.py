from pathlib import Path
import json,re,hashlib
repo=Path('/home/dongxu/kv9'); proofs=repo/'proofs/lean/radix'
prior=json.loads((proofs/'delete-contract.json').read_text())
new=['InsertSplits.lean','InsertStep.lean','InsertLoop.lean','InsertWordSplits.lean','InsertWordStep.lean','InsertWordLoop.lean']
modules=prior['modules']+new
runner=(repo/'scripts/resident-radix/prove-delete.py').read_text().replace('indexed edge and iterative deletion','insertion action, mutable-slot and machine-word').replace('delete-contract.json','insert-contract.json').replace('import DeleteWordLoop\\n','import InsertWordLoop\\n').replace('injectedDeleteFalse','injectedInsertFalse')
(repo/'scripts/resident-radix/prove-insert.py').write_text(runner)
controls=[]
def add(name,module,old,new,kind='semantic'):
 text=(proofs/module).read_text(); assert text.count(old)==1,(name,text.count(old))
 controls.append(dict(name=name,module=module,old=old,new=new,kind=kind))
add('leaf-prefix-too-long','InsertSplits.lean','leafSplitBytes ((old.key.drop depth).take sharedLength)','leafSplitBytes ((old.key.drop depth).take (sharedLength + 1))')
add('leaf-new-byte-offset','InsertSplits.lean','old fresh old.key[cut]? fresh.key[cut]?','old fresh old.key[cut]? fresh.key[cut + 1]?')
add('leaf-wrong-terminal','InsertSplits.lean','| none, some byte => some (.branch pfx (some old)','| none, some byte => some (.branch pfx (some fresh)')
add('branch-keeps-edge-byte','InsertSplits.lean','let oldChild := Tree.branch (pfx.drop (sharedLength + 1))','let oldChild := Tree.branch (pfx.drop sharedLength)')
add('branch-prefix-too-long','InsertSplits.lean','| none => some (.branch (pfx.take sharedLength) (some fresh)','| none => some (.branch (pfx.take (sharedLength + 1)) (some fresh)')
add('replace-selects-split','InsertStep.lean','if old.key = fresh.key then some .replaceLeaf','if old.key = fresh.key then some (.splitLeaf 0)')
add('split-at-full-prefix','InsertStep.lean','if sharedLength < pfx.length then some (.splitBranch sharedLength)','if sharedLength <= pfx.length then some (.splitBranch sharedLength)')
add('descent-skips-byte','InsertStep.lean','some (.descend index (depth + sharedLength + 1))','some (.descend index (depth + sharedLength + 2))')
add('replace-keeps-old-value','InsertStep.lean','| .leaf _ => .done (.leaf fresh) false','| .leaf old => .done (.leaf old) false')
add('terminal-always-inserted','InsertStep.lean','| .branch pfx terminal children => .done (.branch pfx (some fresh) children) terminal.isNone','| .branch pfx _ children => .done (.branch pfx (some fresh) children) true')
add('edge-wrong-insertion-index','InsertStep.lean','(.branch pfx terminal (edgeInsert index byte (.leaf fresh) children)) true','(.branch pfx terminal (edgeInsert (index + 1) byte (.leaf fresh) children)) true')
add('mutable-slot-wrong-index','InsertStep.lean','(edgeSet frame.index child frame.children)','(edgeSet (frame.index + 1) child frame.children)')
add('context-discards-parent','InsertLoop.lean','| frame :: tail, child => plugInsertFrames tail (plugInsert frame child)','| _ :: tail, child => plugInsertFrames tail child')
add('context-skips-index-check','InsertLoop.lean','if frame.index < edgeCount frame.children then plugInsertChecked','if frame.index + 1 < edgeCount frame.children then plugInsertChecked')
add('loop-loses-inserted-flag','InsertLoop.lean','(plugInsertChecked frames replacement).map (fun root => (root, inserted))','(plugInsertChecked frames replacement).map (fun root => (root, false))')
add('loop-drops-ancestors','InsertLoop.lean','insertLoop fresh child nextDepth (frame :: frames)','insertLoop fresh child nextDepth (frame :: [])')
add('word-leaf-cut-offset','InsertWordSplits.lean','let cut := depth + USize.ofNat sharedLength','let cut := depth + USize.ofNat sharedLength + 1')
add('word-branch-keeps-edge-byte','InsertWordSplits.lean','(pfx.drop (sharedWord + 1).toNat)','(pfx.drop sharedWord.toNat)')
add('word-descent-skips-byte','InsertWordStep.lean','some (.descend index (endOffset + 1).toNat)','some (.descend index (endOffset + 2).toNat)')
add('word-new-edge-byte-offset','InsertWordStep.lean','match fresh.key[(depth + USize.ofNat pfx.length).toNat]?','match fresh.key[(depth + USize.ofNat pfx.length + 1).toNat]?')
add('word-loop-loses-inserted-flag','InsertWordLoop.lean','(plugInsertChecked frames replacement).map (fun root => (root, inserted))','(plugInsertChecked frames replacement).map (fun root => (root, false))')
add('word-count-extra-increment','InsertWordLoop.lean','some (⟨some result.1, state.size + result.2.toUSize⟩, result.2)','some (⟨some result.1, state.size + result.2.toUSize + 1⟩, result.2)')
add('empty-root-wrong-size','InsertWordLoop.lean','| none => some (⟨some (.leaf fresh), 1⟩, true)','| none => some (⟨some (.leaf fresh), 0⟩, true)')
add('insert-proof-hole','InsertLoop.lean','| cons frame tail ih => exact ih (plugInsert frame child)','| cons frame tail ih => sorry','hole')
add('insert-custom-axiom','InsertLoop.lean','| cons frame tail ih => exact ih (plugInsert frame child)','| cons frame tail ih => exact False.elim injectedInsertFalse','axiom')
rust=(repo/'scripts/resident-radix/src/lib.rs').read_text(); source_controls=[]
for label,old,new_text in [
 ('rust-insert-descent','Ok(index) => InsertAction::Descend(index, end + 1),','Ok(index) => InsertAction::Descend(index, end + 2),'),
 ('rust-insert-leaf-cut','let cut = depth + common;','let cut = depth + common + 1;'),
 ('rust-insert-count','self.size += usize::from(inserted);','self.size += usize::from(inserted) + 1;')]:
 assert rust.count(old)==1
 source_controls.append(dict(name=label,old=old,new=new_text))
names=[n for m in modules for n in re.findall(r'^\s*theorem\s+(\w+)',(proofs/m).read_text(),re.M)]
assert names[:len(prior['theorems'])]==prior['theorems'] and len(set(names))==len(names)
sources=dict(prior['sources'])
for n in ['proofs/lean/radix/delete-contract.json','scripts/resident-radix/prove-insert.py']+['proofs/lean/radix/'+m for m in new]: sources[n]=hashlib.sha256((repo/n).read_bytes()).hexdigest()
contract=dict(modules=modules,theorems=names,new_theorems=names[len(prior['theorems']):],sources=sources,lean_sha256=prior['lean_sha256'],controls=controls,source_controls=source_controls,complete_algorithm_gate=False,
 scope='Reviewed value-level insertion correspondence: absolute-offset split helpers; separate six-way action selection/execution; mutable-slot ghost context with selected-child provenance; terminating insertion loop; actual word cut/drain/descent arithmetic; checked stored-count and returned flag refinement. Valid representable routing buffers and resident result count are explicit premises. No Arc/COW heap proof, verified extraction or performance result.',
 remaining=['Indexed seek/depth and pending-Vec correspondence','Arc/COW heap ownership, snapshots, reclamation and resident-count representability; bridge routing-buffer fits and Rust/compiler/library contracts','Exact-source executable Rust/model differential evaluation before predeclared timing; promotion still requires recovery, actual Chaos Mesh and Redis throughput/latency'])
(proofs/'insert-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
print(json.dumps({'theorems':len(names),'new_theorems':len(contract['new_theorems']),'semantic_controls':sum(c['kind']=='semantic' for c in controls),'controls':len(controls)+len(source_controls)}))
