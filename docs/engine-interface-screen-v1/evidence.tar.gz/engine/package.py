#!/usr/bin/env python3
"""Package the completed diagnostic without duplicating its source corpus."""
from pathlib import Path
import hashlib,json,shutil,tarfile
R=Path('/home/dongxu/kv9');S=Path(__file__).resolve().parent;D=R/'docs/engine-interface-screen-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((S/'analysis.json').read_text())['complete']
D.mkdir(exist_ok=False)
files=[]
for name in ('plan.json','reference-inputs.py','next-isolated-outline-plan.json','build-summary-v1.json','harness-metadata-v1.json','harness-metadata-v1.stderr','prepare-summary.json','measure-summary.json','inputs-accepted.json','input-validation.stdout','input-validation.stderr','codegen-review.json','analysis.json','tool-versions.json','package.py'):
 files.append((S/name,Path('engine')/name))
for arm in ('baseline','candidate'):
 for name in (f'symbols-{arm}.txt',f'disassembly-{arm}.txt'):
  files.append((S/name,Path('engine')/name))
for directory in ('source-baseline-v1','source-candidate-v1','build-baseline-v1','build-candidate-v1','runs','tools'):
 for p in sorted((S/directory).rglob('*')):
  if p.is_file() and p.name!='timing' and '__pycache__' not in p.parts:
   files.append((p,Path('engine')/p.relative_to(S)))
for p in sorted((R/'scripts/engine-interface-experiment').rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:
  files.append((p,Path('published-harness')/p.relative_to(R/'scripts/engine-interface-experiment')))
assert len({str(name) for _,name in files})==len(files)
members=[dict(path=str(name),bytes=p.stat().st_size,sha256=sha(p))for p,name in files]
archive=D/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6)as tar:
 for p,name in files:tar.add(p,arcname=str(name),recursive=False)
with tarfile.open(archive,'r:gz')as tar:
 actual=tar.getmembers();assert len(actual)==len(members)
 for info,expected in zip(actual,members):
  assert info.isfile()and info.name==expected['path']and info.size==expected['bytes']
  assert hashlib.sha256(tar.extractfile(info).read()).hexdigest()==expected['sha256']
(D/'members.json').write_text(json.dumps(members,indent=2)+'\n')
manifest=dict(complete=True,archive_sha256=sha(archive),members=len(members),expanded_bytes=sum(x['bytes']for x in members),compressed_bytes=archive.stat().st_size,member_readback=True,
 excluded=['groups.bin (referenced from prior packet)','copied timing ELFs (retained locally with exact hashes)','GitHub payloads and mutable continuation/progress','abandoned draft planning'],
 external={'corpus':'../outlined-mutation-path-v1/evidence.tar.gz:outlined/groups.bin','corpus_sha256':'d978ba9e491f6277f975ecd333c33854845cc03bd14ee57a22fff915a08350','corpus_sha256_actual':sha(S/'groups.bin'),'qualification':'../outlined-mutation-path-v1/evidence.tar.gz:outlined/ dependency, proof and qualification trees'},
 local_root=str(S),binaries={arm:json.loads((S/'build-summary-v1.json').read_text())['arms'][arm]['timing']for arm in ('baseline','candidate')})
# Use exactly the independently checked corpus hash, never a hand-transcribed one.
manifest['external']['corpus_sha256']=manifest['external'].pop('corpus_sha256_actual')
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ('plan.json','analysis.json','next-isolated-outline-plan.json'):
 shutil.copyfile(S/name,D/name)
(D/'README.md').write_text(f'''# Engine interface diagnostic evidence

See the [report](../ENGINE-INTERFACE-SCREEN.md). All 90 processes / 152 rows
pass independent checks. Actual apply improves, but owned reads regress;
production remains unchanged and the previous selection gate remains failed.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['archive_sha256']}`.
Every member size and hash passed archive readback. [members.json](members.json)
and [manifest.json](manifest.json) bind retained bytes and exclusions.

The packet contains both isolated source/build transactions, production engine
and common source copies, exact dependency graphs and changed dependency sources,
static call-boundary review, both independently validated preparations, all 88
measurement outputs and 90 launch/terminal records, and the full analysis.
`published-harness/` contains the runnable harness and orchestration tools.
No new production algorithm proof or Chaos acceptance is claimed.

Restore the original corpus from the [outlined packet](../outlined-mutation-path-v1/README.md),
member `outlined/groups.bin`, SHA-256
`{manifest['external']['corpus_sha256']}`. Its qualified dependency/proof trees
supply the prior qualification inputs. Executables remain in the local retained
root with exact hashes in the manifest. Reproduction tools use recorded absolute
paths: restore those paths or adjust a fresh experiment before building, without
relabeling these measured artifacts.

Whole-pass p99 is the latency of 512 queries, not individual request p99.
All per-call/whole-pass, owned/resident and first-probe/warm results remain
separate in [analysis.json](analysis.json). The
[next isolated candidate plan](next-isolated-outline-plan.json) is prospective;
it has not been built, proved or timed in this packet.
''')
print(json.dumps({k:v for k,v in manifest.items()if k not in ('external','binaries')}))
