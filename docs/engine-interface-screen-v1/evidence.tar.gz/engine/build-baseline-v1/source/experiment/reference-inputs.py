#!/usr/bin/env python3
"""Independent corpus/state/key-transform/probe reconstruction, before timing."""
import hashlib,json,struct
from pathlib import Path
R=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(rows):
 h=hashlib.sha256();h.update(struct.pack('<Q',len(rows)))
 for k,v in rows:h.update(struct.pack('<Q',len(k)));h.update(k);h.update(struct.pack('<Q',len(v)));h.update(v)
 return h.hexdigest()
def reconstruct():
 b=(R/'groups.bin').read_bytes();assert hashlib.sha256(b).hexdigest()=='d978ba9e49131f6277f975ecd333c33854845cc03bd14ee57a22fff915a08350'
 assert b[:8]==b'KV9GRP01';pos=8;previous_end=14221;groups=[]
 while pos<len(b):
  previous,last,term,length=struct.unpack_from('<QQQI',b,pos);pos+=28;end=pos+length;assert previous==previous_end and last>previous and term==1;previous_end=last
  count=struct.unpack_from('<I',b,pos)[0];pos+=4;group=[]
  for _ in range(count):
   tag,cf,n=struct.unpack_from('<BBI',b,pos);pos+=6;assert tag==cf==0
   k=b[pos:pos+n];pos+=n;n=struct.unpack_from('<I',b,pos)[0];pos+=4;v=b[pos:pos+n];pos+=n;assert pos<=end;group.append((k,v))
  assert pos==end;groups.append(group)
 assert len(groups)==106 and sum(map(len,groups))==100096 and previous_end==15785
 originals=sorted({k for g in groups for k,v in g});assert len(originals)==4096
 models={};metadata=[]
 for dataset in ('original24','short4','dispersed0'):
  mapping={}
  for rank,k in enumerate(originals):
   prefix=b'raw:' if dataset=='short4' else b''
   key=prefix+hashlib.sha256(k).digest()[:19-len(prefix)]+rank.to_bytes(8,'big')
   key=bytes([key[0]&127])+key[1:]
   mapping[k]=k if dataset=='original24' else key
  assert len(set(mapping.values()))==4096 and all(len(k)==27 for k in mapping.values())
  flat=[(mapping[k],v)for g in groups for k,v in g]
  for name in ('overwrite','initial_fill','unique_insert'):
   final={}
   for i,(k,v)in enumerate(flat,1):final[k+(i.to_bytes(8,'big')if name=='unique_insert'else b'')]=v
   rows=sorted(final.items());models[dataset,name]=rows
   metadata.append(dict(dataset=dataset,workload=name,groups=106,initial_keys=4096 if name=='overwrite'else 0,final_keys=len(rows),final_state_sha256=digest(rows)))
 return models,metadata

def probes(rows,op):
 # Independent full permutation with the same fixed generator specification.
 state=71;mask=(1<<64)-1;perm=list(range(len(rows)))
 for i in range(len(perm)-1,0,-1):
  bound=i+1;threshold=((1<<64)-bound)%bound
  while True:
   state^=(state<<13)&mask;state^=state>>7;state^=(state<<17)&mask
   if state>=threshold:break
  j=state%bound;perm[i],perm[j]=perm[j],perm[i]
 selected=perm[:512];assert len(set(selected))==512
 keys={k for k,v in rows};out=[]
 for i,index in enumerate(selected):
  k=rows[index][0]
  if op=='get_miss'or(op=='predecessor'and i%2):
   k+=b'\xff'
   while k in keys:k+=b'\xff'
  out.append(k)
 return out

def main():
 models,metadata=reconstruct();identities=[];prepared={}
 for arm in ('baseline','candidate'):
  p=R/'runs'/('prepare-'+arm+'.json');x=json.loads(p.read_bytes())
  assert x['complete']and x['mode']=='prepare'and x['workloads']==metadata
  assert x['input_plan_sha256']==sha(R/'timing-plan.json')and x['group_file_sha256']==sha(R/'groups.bin')
  assert x['correctness_live_prefixes']==1908 and x['correctness_old_views']==954
  assert len(x['read_inputs'])==6
  current=[]
  for w in x['read_inputs']:
   rows=models[w['dataset'],w['workload']];assert w['keys_hex']==[k.hex()for k,v in rows]
   assert [q['operation']for q in w['queries']]==['get_hit','get_miss','predecessor','scan16']
   for q in w['queries']:
    expected=probes(rows,q['operation']);assert q['queries_hex']==[k.hex()for k in expected]
    assert q['query_sha256']==digest([(k,b'')for k in expected]);current.append(dict(dataset=w['dataset'],workload=w['workload'],operation=q['operation'],query_sha256=q['query_sha256']))
  if identities:assert identities==current
  identities=current;prepared[arm]=sha(p)
 assert len(set(prepared.values()))==1
 result=dict(complete=True,prepared_sha256=prepared,models=metadata,query_identities=identities,independent_reconstruction=True)
 (R/'runs/inputs-accepted.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':True,'models':len(metadata),'probe_sets':len(identities),'arms':2}))
if __name__=='__main__':main()
