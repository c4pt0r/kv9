------------------------ MODULE ConfigurationCutProof ------------------------
EXTENDS ConfigurationCut, TLAPS
THEOREM HCInvariantInit == HCInit => HCInvariant
BY HCInputs, SMT DEF HCInit, HCInvariant, HCType, HCFound
THEOREM HCInvariantStep == ASSUME HCInvariant, [HCNext]_hcVars PROVE HCInvariant'
<1>1. \A i \in 1..HCLimit : HCStage(i) => HCInvariant'
    BY HCInputs, SMT DEF HCStage, HCInvariant, HCType, HCFound, hcView
<1>2. HCSync \/ HCPublish => HCInvariant'
    BY HCInputs, SMT DEF HCSync, HCPublish, HCInvariant, HCType, HCFound, hcView
<1>3. HCFail \/ HCRecover \/ HCAmbiguous => HCInvariant'
    BY HCInputs, SMT DEF HCFail, HCRecover, HCAmbiguous, HCInvariant, HCType, HCFound, hcView
<1>4. HCQueries => HCInvariant'
    BY HCInputs, SMT DEF HCQueries, HCQuery, HCInvariant, HCType, HCFound, HCLatest
<1>5. UNCHANGED hcVars => HCInvariant'
    BY SMT DEF hcVars, hcView, HCInvariant, HCType, HCFound
<1> QED BY <1>1, <1>2, <1>3, <1>4, <1>5, SMT DEF HCNext
THEOREM HCInvariantAlways == HCSpec => []HCInvariant
BY HCInvariantInit, HCInvariantStep, PTL DEF HCSpec
THEOREM HCFoundIsLatest == HCInvariant /\ hcResult = "Found" => HCLatest(hcCut, hcSelected)
BY DEF HCInvariant, HCFound
THEOREM HCFoundIsDurable == HCInvariant /\ hcResult = "Found" => hcSelected \in {0} \cup hcDurable
BY DEF HCInvariant, HCFound
THEOREM HCFencedLookup ==
    ASSUME NEW q \in 1..HCLimit, NEW s \in 0..HCLimit, NEW claim \in Nat,
           HCQuery(q, s, claim), ~hcWriter
    PROVE hcResult' = "Invalid"
BY SMT DEF HCQuery
THEOREM HCMissingConfiguration ==
    ASSUME NEW q \in 1..HCLimit, NEW s \in 0..HCLimit, NEW claim \in Nat,
           HCQuery(q, s, claim), \E i \in HCChanges : s < i /\ i <= q
    PROVE hcResult' # "Found"
BY SMT DEF HCQuery
THEOREM HCFutureExcluded ==
    ASSUME NEW q \in 1..HCLimit, NEW s \in 0..HCLimit, NEW claim \in Nat, HCQuery(q, s, claim)
    PROVE hcSelected' <= hcCut'
BY SMT DEF HCQuery
THEOREM HCCompleteHistorySucceeds ==
    ASSUME NEW q \in 1..HCLimit, NEW s \in 0..HCLimit, HCInvariant,
           HCQuery(q, s, HCTerms[q]), hcWriter, hcKnown,
           hcApplied \subseteq HCChanges,
           \A i \in HCChanges : i <= q => i \in hcApplied,
           \A i \in hcApplied : i <= q => i <= s,
           \A i \in 1..q : HCTerms[i] <= HCTerms[q]
    PROVE hcResult' = "Found"
BY HCInputs, SMT DEF HCQuery, HCInvariant, HCType
THEOREM HCQuerySettles ==
    ASSUME NEW q \in 1..HCLimit, NEW s \in 0..HCLimit, NEW claim \in Nat, HCQuery(q, s, claim)
    PROVE hcResult' # "Idle"
BY SMT DEF HCQuery
THEOREM HCStableInspectionProgress == HCInspectSpec => HCInspectProgress
<1>1. HCInvariant /\ [HCQueries]_hcVars => HCInvariant'
    BY HCInvariantStep, SMT DEF HCNext
<1>2. HCInspectSpec => []HCInvariant
    BY <1>1, PTL DEF HCInspectSpec
<1>3. hcPending = 0 /\ hcResult = "Idle" /\ [HCQueries]_hcVars =>
          (hcPending = 0 /\ hcResult = "Idle")' \/ (hcResult' # "Idle")
    BY SMT DEF HCQueries, HCQuery, hcVars, hcView
<1>4. HCQueries => hcResult' # "Idle"
    BY SMT DEF HCQueries, HCQuery
<1>5. HCInvariant /\ hcPending = 0 /\ hcResult = "Idle" => ENABLED <<HCQueries>>_hcVars
    <2>1. HCInvariant /\ hcPending = 0 /\ hcResult = "Idle" =>
              ENABLED <<HCQuery(1, 0, HCTerms[1])>>_hcVars
        BY HCInputs, ExpandENABLED, SMT DEF HCQuery, HCInvariant, HCType, hcVars, hcView
    <2> QED BY <2>1, HCInputs, ExpandENABLED, SMT DEF HCQueries
<1> QED BY <1>2, <1>3, <1>4, <1>5, PTL DEF HCInspectSpec, HCInspectProgress
=============================================================================
