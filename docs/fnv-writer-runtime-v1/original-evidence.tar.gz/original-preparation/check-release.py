"""Read back exact FNV-writer release provenance; never build or run a server."""
import hashlib,json,os,shlex,subprocess,time
from pathlib import Path
HERE=Path(__file__).parent
ROOT=Path('/tmp/kv9-fnv-writer-release-root-20260914-first')
SOURCE=Path('/tmp/kv9-raft-fnv-interleave-writer-20260914-first')
BUILD=Path('/tmp/kv9-fnv-writer-release-20260914-first')
CHECKPOINT='12f44d35590ede5f89337fe731dd950162865154'
TARGET=Path('/home/dongxu/kv9/target')
used={}
def sha(p):
 p=Path(p);assert p.is_file() and not p.is_symlink()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 b=dict(bytes=p.stat().st_size,sha256=h)
 assert str(p) not in used or used[str(p)]==b
 used[str(p)]=b;return h
def read(p):sha(p);return json.loads(Path(p).read_text())
def canonical(d):return json.dumps(d,sort_keys=True,separators=(',',':')).encode()
def save(p,d):
 with p.open('x')as f:f.write(json.dumps(d,indent=2)+'\n')
out=ROOT/'readback-first';out.mkdir(exist_ok=False)
r=dict(complete=False,started_ns=time.time_ns())
try:
 term=read(ROOT/'terminal.json');original=read(ROOT/'source-result.json');pre=read(ROOT/'preflight.json')
 REV=pre['revision'];assert pre['complete'] and pre['runtime_checkpoint']==CHECKPOINT
 assert term['complete'] and term['exit_code']==0 and term['session_id']>0
 assert sha(ROOT/'source-result.json')==term['result_sha256'] and original['complete'] and original['exit_code']==0
 assert not Path('/proc',str(original['pid'])).exists()
 assert original['minimum_available_bytes']==80*1024**3 and original['additional_consumption_ceiling_bytes']==16*1024**3
 assert original['initial_available_bytes']>=96*1024**3 and original['samples']
 assert all(x['available_bytes']>=96*1024**3 and original['initial_available_bytes']-x['available_bytes']<=16*1024**3 for x in original['samples'])
 assert original['ended_ns']-original['started_ns']<=1200*10**9
 assert sha(HERE/'run-release.py')==pre['supervisor_sha256']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==REV
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=SOURCE)
 for name,h in pre['source_helper_sha256'].items():assert sha(SOURCE/'scripts'/name)==h
 for name,h in pre['protected_release_hashes'].items():
  p=Path(name);assert not p.resolve().is_relative_to(TARGET) and p.stat().st_nlink==1 and sha(p)==h
 manifest=read(BUILD/'build.json');workload=read(BUILD/'workload/build.json');sources=read(BUILD/'workload/sources.json');cache=read(BUILD/'cache-safety.json')
 assert manifest['revision']==workload['revision']==sources['revision']==REV and manifest['dirty'] is workload['dirty'] is sources['dirty'] is False
 assert manifest['profile']==workload['profile']=='release' and manifest['rustc']==workload['rustc']
 assert manifest['sources']==sources['sources']==pre['source_snapshot']['sources']
 assert set(manifest['sources'])==set(subprocess.check_output(['git','ls-files','-z'],cwd=SOURCE).decode().strip('\0').split('\0'))
 tree=hashlib.sha256(canonical(manifest['sources'])).hexdigest()
 assert tree==manifest['source_tree_sha256']==workload['source_tree_sha256']==sources['source_tree_sha256']
 for name,h in manifest['sources'].items():assert sha(SOURCE/name)==h
 assert sources['build_environment']=={},'Unexpected compiler environment override'
 assert cache['complete'] and cache['invalidation_complete'] and cache['profile']=='release' and cache['target_directory']==str(TARGET)
 assert cache['source_root']==str(SOURCE) and cache['first_party_packages']==['kv9','kv9-common','kv9-engine','kv9-meta','kv9-raft','kv9-region','kv9-server','kv9-txn']
 assert cache['metadata_exit_code']==0 and len(cache['commands'])==3 and all(x['exit_code']==0 for x in cache['commands'])
 assert not Path('/proc',str(cache['pid'])).exists()
 seen=set()
 for row in cache['first_party_artifacts']:
  assert row['features']==[],'Non-default first-party production feature graph'
  key=json.dumps([row['package_id'],row['target'],row['profile'],row['features']],sort_keys=True)
  assert row['seen_after_invalidation']==(key in seen)
  if key not in seen:assert row['fresh'] is False
  seen.add(key)
 assert seen
 for name in ('kv9','workload/kv9-batch-workload'):
  binary=BUILD/name;assert not binary.resolve().is_relative_to(TARGET) and binary.stat().st_nlink==1
 server=sha(BUILD/'kv9');client=sha(BUILD/'workload/kv9-batch-workload')
 assert server==manifest['binaries']['kv9']['sha256'] and client==workload['binary_sha256']==sources['binary_sha256']
 assert sha(BUILD/'workload/build.json')==manifest['workload_build_sha256']
 attestation={};codegen=[]
 for label,rel,wanted,command,crate,log in (
  ('server','kv9-cargo.jsonl',('kv9','kv9_engine','kv9_raft','kv9_server'),manifest['binaries']['kv9']['command'],'kv9','kv9-build.log'),
  ('workload','workload/cargo.jsonl',('kv9-batch-workload','kv9_engine','kv9_raft','kv9_server'),sources['command'],'kv9_batch_workload','workload/build.log')):
  assert command[:2]==['cargo','build'] and '--release' in command and '--locked' in command
  assert not any(x.startswith(('--features','--all-features','--no-default-features'))for x in command)
  cargo=BUILD/rel;sha(cargo);rows=[json.loads(x)for x in cargo.read_text().splitlines()]
  assert rows[-1]==dict(reason='build-finished',success=True) and sum(x.get('reason')=='build-finished'for x in rows)==1
  selected={}
  for name in wanted:
   hits=[x for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']==name];assert len(hits)==1
   row=hits[0];assert row['features']==[] and row['profile']['test'] is False and row['profile']['opt_level']=='3'
   assert Path(row['manifest_path']).is_relative_to(SOURCE);selected[name]=row
  assert selected[wanted[0]]['executable'] and selected[wanted[0]]['target']['kind']==['bin']
  text=(BUILD/log).read_text();sha(BUILD/log);lines=[x for x in text.splitlines() if 'Running `' in x and '--crate-name '+crate+' ' in x]
  assert len(lines)==1;argv=shlex.split(lines[0].split('`',1)[1].rsplit('`',1)[0])
  assert all(x in argv for x in ('opt-level=3','lto=thin','codegen-units=1')) and '--cfg' not in argv
  assert not any(x.startswith(('target-cpu=', 'target-feature=', 'panic=')) for x in argv),'Unexpected CPU/target/panic codegen override'
  codegen.append(dict(path=str(BUILD/log),sha256=used[str(BUILD/log)]['sha256'],rustc_command=lines[0]))
  attestation[label]=dict(command=command,artifacts=selected,cargo_sha256=used[str(cargo)]['sha256'])
 for name,b in list(used.items()):assert sha(name)==b['sha256']
 r.update(complete=True,revision=REV,runtime_checkpoint=CHECKPOINT,preparation_hashes={name:sha(HERE/name) for name in ('process-runner.py','run-recovery.py','audit.py')},source_files=len(manifest['sources']),source_tree_sha256=tree,server_sha256=server,workload_sha256=client,manifest_sha256=used[str(BUILD/'build.json')]['sha256'],default_production_codegen=codegen,feature_attestation=attestation,cache_lock_and_first_party_invalidation_checked=True,protected_releases_unchanged=True,release_terminal=term,minimum_observed_available_bytes=min(x['available_bytes']for x in original['samples']),scope='Exact clean default release, retained source/binary/Cargo/verbose codegen/cache and original resource guards; no runtime recovery, Chaos or performance acceptance')
except BaseException as e:r['failure']=repr(e);raise
finally:
 r['ended_ns']=time.time_ns();save(out/'result.json',r);save(out/'input-hashes.json',used)
print(json.dumps({k:r[k]for k in ('complete','revision','source_files','server_sha256','workload_sha256','minimum_observed_available_bytes')}))
