#!/usr/bin/env python3
"""Root-only read-only source/release preflight; never invokes Cargo or a fixture."""
import argparse,hashlib,importlib.util,json,os,re,subprocess,time
from pathlib import Path
HERE=Path(__file__).parent
SOURCE=Path('/tmp/kv9-fnv-writer-release-source-20260914-first')
ROOT=Path('/tmp/kv9-fnv-writer-release-root-20260914-runtime-source')
BUILD=Path('/tmp/kv9-fnv-writer-release-20260914-runtime-source')
CHECKPOINT='12f44d35590ede5f89337fe731dd950162865154'
GATE=Path('/tmp/kv9-fnv-writer-source-20260914-first')
GATE_ROOT=Path('/tmp/kv9-fnv-writer-source-root-20260914-first')
TARGET=Path('/home/dongxu/kv9/target')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=SOURCE)
def docs(name):return name.startswith('docs/') or name=='README.md'
def main():
 assert __debug__
 ap=argparse.ArgumentParser();ap.add_argument('--expected-revision',required=True);args=ap.parse_args()
 assert re.fullmatch('[0-9a-f]{40}',args.expected_revision)
 assert args.expected_revision==CHECKPOINT,'this detached release source must be exact tested 12f44d'
 ROOT.mkdir(exist_ok=False)
 r=dict(complete=False,started_ns=time.time_ns(),runtime_checkpoint=CHECKPOINT,revision=args.expected_revision,source_root=str(SOURCE))
 try:
  assert not BUILD.exists(),'release output already exists'
  assert git('rev-parse','HEAD').decode().strip()==args.expected_revision
  assert not git('status','--porcelain','--untracked-files=all'),'release requires clean source'
  subprocess.run(['git','merge-base','--is-ancestor',CHECKPOINT,args.expected_revision],cwd=SOURCE,check=True)
  changed=git('diff','--name-only','-z',CHECKPOINT,args.expected_revision).decode().strip('\0').split('\0')
  changed=[name for name in changed if name]
  assert all(docs(name) for name in changed),'non-documentation change after tested writer checkpoint'
  original=read(GATE_ROOT/'source-result.json');gate=read(GATE/'result.json')
  before=read(GATE/'source-before.json');after=read(GATE/'source-after.json')
  assert original['complete'] and original['exit_code']==0 and original['reaped'] and original['pid_absent']
  assert not Path('/proc',str(original['pid'])).exists()
  assert gate['complete'] and gate['source_unchanged'] and before==after
  assert before['revision']==CHECKPOINT and before['dirty'] is False
  spec=importlib.util.spec_from_file_location('writer_release_builder',SOURCE/'scripts/build-workload.py')
  builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
  snapshot=builder.snapshot()
  assert snapshot['revision']==args.expected_revision and snapshot['dirty'] is False
  assert {k:v for k,v in snapshot['sources'].items() if not docs(k)}=={k:v for k,v in before['sources'].items() if not docs(k)}
  helper_manifest=read(HERE/'helper-equivalence.json')
  helpers={row['relative_path'].removeprefix('scripts/'):row['candidate_sha256'] for row in helper_manifest['helpers']}
  assert all(sha(SOURCE/'scripts'/name)==expected for name,expected in helpers.items())
  protected={
   '/tmp/kv9-crc-main-integration-release-20260914-first/kv9':'106f517c84fabe790ea139f3c18661e14447abd9e257fdd6ba82bfabe6796eb9',
   '/tmp/kv9-crc-main-integration-release-20260914-first/workload/kv9-batch-workload':'ec8002c00253fa6264a2f7bef3814e33dc871c7ef895e6163b7be38be2edffad',
  }
  for name,expected in protected.items():
   p=Path(name);assert not p.is_symlink() and not p.resolve().is_relative_to(TARGET) and p.stat().st_nlink==1 and sha(p)==expected
  storage=os.statvfs('/home/dongxu/kv9');available=storage.f_bavail*storage.f_frsize
  assert available>=96*1024**3,'unchanged release launch minimum is 96 GiB'
  r.update(complete=True,source_snapshot=snapshot,documentation_changes_after_checkpoint=changed,
   source_gate_inputs={str(p):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in (GATE_ROOT/'source-result.json',GATE/'result.json',GATE/'source-before.json',GATE/'source-after.json')},
   source_helper_sha256=helpers,supervisor_sha256=sha(HERE/'run-release.py'),protected_release_hashes=protected,
   available_bytes=available,release_launch_minimum_bytes=96*1024**3,release_runtime_floor_bytes=96*1024**3,
   inherited_declared_floor_bytes=80*1024**3,maximum_available_byte_decrease=16*1024**3,
   capacity_note='96 GiB is the inherited launch minimum; 112 GiB permits the entire 16 GiB ceiling above the actual 96 GiB release floor. Fresh monitored usage decides fit.')
 except BaseException as error:r['failure']=repr(error);raise
 finally:
  r['ended_ns']=time.time_ns();(ROOT/'preflight.json').write_text(json.dumps(r,indent=2)+'\n')
 print('PASS: clean release source bound to tested writer runtime checkpoint')
if __name__=='__main__':main()
