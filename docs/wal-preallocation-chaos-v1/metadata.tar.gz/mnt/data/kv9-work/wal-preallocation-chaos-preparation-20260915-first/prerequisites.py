"""Bind the actual current paired-release/source/proof/recovery metadata shapes; no gates rerun."""
from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent
B=Path('/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first')
D=Path('/mnt/data/kv9-work/wal-payload-preallocation-development-20260915-first')
S=B/'source';REV='86aa6fc07d82f4d49b43fbfe309e0e5c20276da5'
read=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def proof_result(result,count,controls):
 assert result['complete'] and result['accepted']
 assert len(result['theorems'])==count and len(result['controls'])==controls and all(x['rejected']for x in result['controls'])

def verify(p):
 for name,r in read(P/'current-prerequisite-pins.json').items():
  assert Path(name).stat().st_size==r['bytes'] and sha(name)==r['sha256'],name
 m=read(B/'build/preallocated/build.json');rb=read(B/'build/independent-readback.json');native=read(B/'correctness-client/build.json')
 assert rb['complete'] and rb['revision']==REV and rb['source_files']==len(m['sources'])==1529
 assert m['sources']==p['source'] and m['source_tree_sha256']==p['source_tree_sha256']==native['source_tree_sha256']==rb['source_tree_sha256']
 assert m['binary_sha256']==p['production_binary']['sha256']=='1a38b0a0223650f42aa306131787937f55d7cfc9db2963b2d4bdf8f3d2c8566e'
 assert native['binary_sha256']=='49ebe15e52f8851899372cf350cc8b7d9de1cc30fb3abcb8a76670d7a4369730' and native==p['native_client_build']
 receipts=read(B/'actual-tool-receipts.json')
 expected={'paired_server_release':'28098/b14640/0','paired_release_readback':'dbdde0/0','native_correctness_client_build':'1504/bc943b/0','preallocated_ordinary_recovery':'18408/b609dc/0','independent_recovery_audit':'e8026c/0'}
 for k,v in expected.items():assert receipts[k]==v,k
 assert read(B/'build/build-result.json')['complete'] and read(B/'build/tool-terminal.json')=={'session_id':28098,'terminal_receipt':'b14640','exit_code':0}
 for directory,count,controls in [('capacity-proof-first',11,7),('crc-proof-first',47,8)]:
  result=read(D/directory/'result.json');proof_result(result,count,controls)
  for name,authority in read(D/directory/'source-inputs.json').items():
   rel=Path(name).relative_to('/home/dongxu/kv9')if name.startswith('/')else Path(name)
   h=authority['sha256']if isinstance(authority,dict)else authority
   assert sha(S/rel)==h and m['sources'][str(rel)]==h,name
 for variant in ['default','feature']:
  result=read(D/('workspace-'+variant+'-result.json'));assert result['exit_code']==0
 pub=read(P/'original-current-source-report.json');assert all(pub['tests']['workspace-'+v]=={'passed':851,'failed':0,'ignored':28,'suite_summaries':31}for v in ['default','feature'])
 delta=subprocess.check_output(['git','-C',str(S),'diff','--name-only','fb9d390',REV],text=True).splitlines()
 assert sorted(delta)==['scripts/build-workload.py','scripts/check-source-inventory.py'],delta
 assert subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()==REV
 assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'])
 rr=read(B/'recovery-preallocated-result.json');summary=read(B/'recovery-preallocated/summary.json');audit=read(B/'recovery-audit.json')
 assert rr['complete'] and rr['source_revision']==REV and rr['variant']=='preallocated'
 assert sha(B/'recovery-preallocated/summary.json')==rr['summary_sha256']
 for k in ['complete','bound_artifacts_unchanged','helpers_unchanged','owned_children_exited','owned_children_identified','owned_lifetimes_exited','workloads_complete']:assert summary[k] is True,k
 assert summary['cleanup_errors']==[] and summary['source_revision']==REV and summary['server_sha256']==m['binary_sha256']
 assert audit['complete'];chosen=[v for v in audit['variants']if v['variant']=='preallocated'];assert len(chosen)==1;chosen=chosen[0]
 assert chosen['server_sha256']==m['binary_sha256'] and chosen['client_sha256']==native['binary_sha256'] and chosen['lifetimes']==7
 assert {c['transport']for c in chosen['cases']}=={'tonic_stream','tonic_unary'}
 for c in chosen['cases']:
  assert c['successful_final_batch_reads']==1 and c['fresh_drained_voters']==3 and c['fault_windows']==2
  assert c['operations']==sum(c['outcomes'].values()) and set(c['outcomes'])=={'ok','unknown'}
 for case in summary['cases']:
  assert case['checked']['accepted'] and case['checked']['full_history_independently_checked'] and case['checked']['history']['verdict']=='valid'
 return {'complete':True,'revision':REV,'source_files':len(m['sources']),'source_tree_sha256':m['source_tree_sha256'],'server_sha256':m['binary_sha256'],'workload_sha256':native['binary_sha256'],'selected_recovery':chosen,'original_receipts':expected,'scope':'Actual current source/proof/paired-release and ordinary selected-ELF recovery only; no Chaos acceptance.'}
