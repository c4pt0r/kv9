from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
# Relocate only host original-artifact path predicates, not in-pod /tmp syscall evidence paths.
for n in ['archive.py','cleanup/execute.py','cleanup/capture.py','capture-point-client.py','overlay/runner.py']:
 f=P/n;t=f.read_text().replace("raw.parent==Path('/tmp')","raw.parent==Path('/mnt/data/kv9-work')").replace("raw.parent == Path('/tmp')","raw.parent == Path('/mnt/data/kv9-work')").replace("artifact.parent==Path('/tmp')","artifact.parent==Path('/mnt/data/kv9-work')");f.write_text(t)
f=P/'root-runners/run-image.py';t=f.read_text();a=t.index("assert hashlib.sha256(raw).hexdigest()==");b=t.index('\n',a);t=t[:a]+f"assert hashlib.sha256(raw).hexdigest()=={hashlib.sha256((P/'commands.json').read_bytes()).hexdigest()!r}"+t[b:]
t=t.replace("def available():\n    s=os.statvfs('/tmp');return s.f_bavail*s.f_frsize","from space_guard import Guard\nspace=Guard(launch=True)\ndef available():return space.observe()")
t=t.replace("floor=8*1024**3", "ROOT.mkdir(parents=True,exist_ok=False)\nfloor=8*1024**3")
t=t.replace("scope='Local copied-binary", "filesystem_baseline=space.baseline,scope='Local copied-binary").replace('available_bytes=free))','available_bytes=free,filesystems=space.last))');f.write_text(t)
f=P/'root-runners/run-runtime.py';t=f.read_text();a=t.index("assert read('");b=t.index('\nplan=read',a)
t=t[:a]+"from prerequisites import verify\nverify(read(P/'plan.json'))"+t[b:]
t=t.replace("def avail():s=os.statvfs('/tmp');return s.f_bavail*s.f_frsize","from space_guard import Guard\ndef avail():return space.observe()")
t=t.replace("initial=avail();check_launch(initial)","capacity=read(str(P/'roots/finalize/capacity.json'));check_capacity(capacity)\nspace=Guard(capacity['filesystems'],launch=True)\nR.mkdir(parents=True,exist_ok=False)\ninitial=avail();check_launch(initial)")
t=t.replace('available_bytes=available));','available_bytes=available,filesystems=space.last));')
f.write_text(t)
f=P/'root-runners/run-post.py';t=f.read_text().replace("def avail():s=os.statvfs('/tmp');return s.f_bavail*s.f_frsize","from space_guard import Guard\ndef avail():return space.observe()")
a=t.index("phases=[");t=t[:a]+"space=Guard(capacity['filesystems'])\n"+t[a:];t=t.replace('available_bytes=available));','available_bytes=available,filesystems=space.last));');f.write_text(t)
# Finalizer retains original actual-image/source/history/namespace/cleanup gates; new prerequisite metadata shape delegates to independent pins.
f=P/'final-preparation/finalize.py';t=f.read_text();a=t.index("    prod_path=Path(");b=t.index('    # Cold work must actually be terminal',a)
t=t[:a]+'''    from prerequisites import verify
    prod_path=P/'release-binding.json';prod=verify(p)
    assert read(prod_path)==prod
    assert read(P/'build-binding-first.json')['complete'] is True
'''+t[b:]
t=t.replace("v=os.statvfs('/tmp'); available=v.f_bavail*v.f_frsize", "from space_guard import snapshot,check\n        filesystems=snapshot();available=check(filesystems,capacity['filesystems'],launch=True)")
t=t.replace("available_bytes=available,cold_terminal=", "available_bytes=available,filesystems=filesystems,cold_terminal=")
t=t.replace("workspace=bind('"+str(P/'pending-release-root/preflight.json')+"')","workspace=bind(P/'current-prerequisite-pins.json')")
f.write_text(t)
# Required future original files: selected metadata, real auxiliary/image terminal artifacts, and exact static sources.
paths=[str(P/n)for n in ['release-binding.json','recovery-binding.final.json','current-prerequisite-pins.json','release-input-pins.json','build-binding-first.json','check-build-binding.py','prerequisites.py','commands.json','auxiliary-build-commands.json','storage-policy.json','space_guard.py']]
paths+=list(json.loads((P/'current-prerequisite-pins.json').read_text()))
for role,names in [('auxiliary-second',['terminal.json','result.json','independent-codegen-readback.json']),('image',['terminal.json','result.json','image_inspect_after_build.stdout','image_probe_after_build.stdout','cri_readback_after_kind_load.stdout'])]:
 paths.extend(str(P/'roots'/role/n)for n in names)
(P/'final-preparation/required-prerequisite-paths.json').write_text(json.dumps(sorted(set(paths)),indent=2)+'\n')
