from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;B=Path('/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first');S=B/'source'
f=P/'check-build-binding.py';t=f.read_text().replace("SERVER_MANIFEST='e6f3ebab9510cdf87c1e521d5b64578c224a08842956998cb2c9690f67498cb7'","SERVER_MANIFEST='f6febda670eb6ceb228b739590e8e6608d91cde492ad5fb557e232f443a9eeb5'").replace('6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49','1a38b0a0223650f42aa306131787937f55d7cfc9db2963b2d4bdf8f3d2c8566e').replace('44d0f6429fd549fc7d0fac6e71ba67b413a2a8aca0e3e3f0386a64058ac06769','49ebe15e52f8851899372cf350cc8b7d9de1cc30fb3abcb8a76670d7a4369730')
t=t.replace("  else:\n   assert x['features']==[], 'production role has non-default features'","  else:\n   package=x['package_id'].rsplit('#',1)[-1].split('@',1)[0]\n   assert package in set(PRESSURE_FEATURES)|{'kv9'}, 'unexpected production package'\n   expected=['wal-payload-preallocation'] if role=='server' and package in ('kv9','kv9-engine') else []\n   assert x['features']==expected, 'exact production role features differ'")
t=t.replace(" cache_check(base/'cache-safety.json',str(source))"," verify_server(plan)")
# New paired build retains a single two-variant cache transaction, and exact per-variant Cargo streams.
a=t.index('\ndef verify(plan):')
extra='''
def verify_server(plan):
 source=Path(plan['worktree']);base=Path(plan['server_manifest']['path']).parent
 m=read(base/'build.json');b=base.parent
 authority=read(R/'release-input-pins.json')
 for path,row in authority.items():
  assert Path(path).stat().st_size==row['bytes'] and sha(path)==row['sha256'],path
 rb=read(b/'independent-readback.json')
 assert rb['complete'] and rb['revision']==REV and rb['source_files']==len(m['sources'])
 assert rb['source_tree_sha256']==m['source_tree_sha256']==plan['source_tree_sha256']
 assert m['complete'] and m['source_before_equals_after'] and m['source_root']==str(source)
 assert m['wal_payload_preallocation_enabled'] and not m['diagnostics_enabled'] and not m['write_stage_tracing_enabled']
 assert m['jobs']==4 and m['offline'] and m['profile']=='release'
 assert sha(base/'build.log')==m['build_log_sha256'] and sha(base/'kv9-cargo.jsonl')==m['cargo_jsonl_sha256']
 assert m['command']==['cargo','build','--offline','--locked','--release','--bin','kv9','--message-format=json-render-diagnostics','-v','--features','wal-payload-preallocation']
 c=read(plan['server_cache_path'])
 assert c['complete'] and c['invalidation_complete'] and c['profile']=='release'
 assert c['source_root']==str(source) and c['target_directory']=='/home/dongxu/kv9/target'
 assert c['source_identity_sha256']==m['source_identity_sha256']
 allrows=[]
 for variant in ['default','preallocated']:
  vm=read(b/variant/'build.json');rows=[json.loads(s)for s in (b/variant/'kv9-cargo.jsonl').read_text().splitlines()]
  assert vm['revision']==REV and not vm['dirty'] and vm['sources']==m['sources']
  assert rows[-1]=={'reason':'build-finished','success':True}
  own=[x for x in rows if x.get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file://'+str(source))]
  feature_check(own,'server' if variant=='preallocated' else 'point')
  assert len(own)==10 and {x['target']['name']for x in own}>={'kv9','kv9_engine','kv9_server','kv9_raft'}
  allrows+=own
 assert len(c['first_party_artifacts'])==len(allrows)
 for row,actual in zip(c['first_party_artifacts'],allrows):
  for key in ['package_id','target','features','fresh','profile']:assert row[key]==actual[key],key
  assert row['fresh'] is False or row['seen_after_invalidation'] is True
 return m
'''
t=t[:a]+extra+t[a:]
t=t.replace("'production_default_features':{'server':[],'native':[],'point':[]}","'production_features':{'server':{'kv9':['wal-payload-preallocation'],'kv9-engine':['wal-payload-preallocation'],'others':[]},'native':[],'point':[]}")
f.write_text(t)
# Keep independent feature checks independently exact; only selected server target/root engine are permitted the flag.
f=P/'overlay/verify-prebuilt.py';t=f.read_text().replace("assert len(found) == 1 and found[0]['features'] == [], name","expected=['wal-payload-preallocation'] if filename==Path(p['server_cargo_path']) and name in ('kv9','kv9_engine') else []\n            assert len(found) == 1 and found[0]['features'] == expected, name")
f.write_text(t)
f=P/'independent/audit.py';t=f.read_text().replace("found[0]['features']==[] and found[0]['profile']['test'] is False,(path,name)","found[0]['features']==(['wal-payload-preallocation'] if path==Path(p['server_cargo_path']) and name in ('kv9','kv9_engine') else []) and found[0]['profile']['test'] is False,(path,name)")
t=t.replace("normal_features=[]","server_features={'kv9':['wal-payload-preallocation'],'kv9-engine':['wal-payload-preallocation'],'others':[]}").replace('Exact clean a6ac335 default-feature release server','Exact clean 86aa6fc explicitly preallocated release server')
f.write_text(t)
# Source-only release receipt pins; no retained ELF read needed until original binding runs.
pins={}
for p in [B/'build/independent-readback.json',B/'build/tool-terminal.json',B/'build/build-result.json',B/'build/cache-safety.json',B/'build/default/build.json',B/'build/preallocated/build.json',B/'correctness-client/build.json',B/'correctness-client/sources.json']:
 raw=p.read_bytes();pins[str(p)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(P/'release-input-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
# Raw retained output uses fresh data-volume parent; remote pod /tmp paths remain original.
f=P/'overlay/scripts/chaos-mesh-e2e.sh';t=f.read_text().replace('mktemp -d /tmp/kv9-chaos-e2e.XXXXXX','mktemp -d /mnt/data/kv9-work/kv9-chaos-e2e.XXXXXX');f.write_text(t)
