"""Tiny synthetic metadata controls only; never run the finalizer or external commands."""
import copy, hashlib, importlib.util, json, tempfile, unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('finalize',HERE/'finalize.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
class Controls(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='synthetic-control-',dir=HERE)
        self.p=Path(self.tmp.name)/'result.json'; self.p.write_text('{"complete":true}\n')
        self.t=dict(complete=True,session_id=7,terminal_receipt='abcdef',exit_code=0,result_path=str(self.p),result_sha256=f.sha(self.p))
    def tearDown(self): self.tmp.cleanup()
    def test_actual_terminal_schema(self):
        self.assertEqual(f.terminal(self.t),{'complete':True})
    def test_missing_failed_or_fabricated_terminal(self):
        for key,value in [('complete',False),('exit_code',1),('session_id',None),('session_id',True),('session_id',0),('terminal_receipt','PENDING')]:
            with self.subTest(key=key,value=value):
                row=copy.deepcopy(self.t);row[key]=value
                with self.assertRaises((AssertionError,TypeError)): f.terminal(row)
    def test_result_hash_and_completion_are_bound(self):
        self.p.write_text('{"complete":false}\n')
        with self.assertRaises(AssertionError):f.terminal(self.t)
        self.t['result_sha256']=f.sha(self.p)
        with self.assertRaises(AssertionError):f.terminal(self.t)
    def test_required_portable_codegen(self):
        f.codegen(['rustc','-C','opt-level=3','-C','lto=thin','-C','codegen-units=1'])
        f.codegen('     Running `rustc -C opt-level=3 -C lto=thin -C codegen-units=1 -C panic=unwind`')
    def test_codegen_rejects_feature_and_profile_changes(self):
        base=['rustc','-C','opt-level=3','-C','lto=thin','-C','codegen-units=1']
        bad=[base[:-2],base+['-C','panic=abort'],base+['-C','target-cpu=native'],base+['--cfg','feature="testing"'],['rustc','-C','opt-level=3','-C','lto=fat','-C','codegen-units=1']]
        for argv in bad:
            with self.subTest(argv=argv):
                with self.assertRaises(AssertionError):f.codegen(argv)
if __name__=='__main__':unittest.main()
