"""Root-only binding and context copy after actual point/pressure builds; does not build an image."""
from pathlib import Path
import importlib.util,json,hashlib,shutil
R=Path(__file__).parent
spec=importlib.util.spec_from_file_location('binding',R/'check-build-binding.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=m.read(R/'plan.json');assert not p['build_complete'] and not p['fixture_started'] and not p['plan_ready']
p['correctness_client_build']=m.read(Path(p['point_build_directory'])/'build.json')
p['pressure_binary']['sha256']=m.read(p['pressure_manifest_path'])['binary_sha256']
verified=m.verify(p)
context=Path(p['context']);context.mkdir(exist_ok=False)
sources={'kv9':Path(p['production_binary']['path']),'admission-pressure':Path(p['pressure_binary']['path']),'kv9-workload':Path(p['point_build_directory'])/'kv9-workload','point-build.json':Path(p['point_build_directory'])/'build.json','kv9-batch-workload':Path(p['native_build_directory'])/'kv9-batch-workload','native-build.json':Path(p['native_build_directory'])/'build.json','no-statx.c':Path(p['worktree'])/'chaos/no-statx.c','Dockerfile':R/'image.Dockerfile'}
for name,src in sources.items():
 shutil.copy2(src,context/name);assert m.sha(src)==m.sha(context/name)
p['context_files']={name:m.sha(context/name) for name in sources}
p['source_unchanged']=True
with (R/'build-binding-first.json').open('x') as f:json.dump({'complete':True,'verified':verified,'copied_context':{name:{'source':str(src),'sha256':m.sha(src)} for name,src in sources.items()},'image_built':False,'runtime_authorized':False},f,indent=2)
(R/'plan.json').write_text(json.dumps(p,indent=2,sort_keys=True)+'\n')
print(json.dumps({'complete':True,'build_binding':True,'image_ready':False,'runtime_ready':False,'point':verified['point'],'pressure':verified['pressure']}))
