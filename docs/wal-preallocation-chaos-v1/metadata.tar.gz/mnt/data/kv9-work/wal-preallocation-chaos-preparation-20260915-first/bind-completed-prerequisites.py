"""Read-only verification of actual authorities, followed by fresh local metadata binding; no runtime."""
from pathlib import Path
import copy,hashlib,json,os
from prerequisites import verify
P=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def save(name,d):
 with (P/name).open('x')as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
p=read(P/'plan.pending.json');v=verify(p)
assert not p['fixture_started'] and not p['build_complete'] and not p['plan_ready'] and not p['fixture_launch_authorized']
p['scope']='Actual exact source/proof/release and selected-ELF ordinary recovery metadata bound; fresh helper qualification, image and full21 runtime acceptance remain separate.'
p['pending_inputs']=p['pending_inputs'][1:]
save('plan.source-recovery.json',p);save('plan.json',p);save('release-binding.json',v)
save('recovery-binding.final.json',dict(complete=True,revision=p['revision'],selected_recovery=v['selected_recovery'],ordinary_recovery=p['ordinary_recovery'],actual_receipts=v['original_receipts'],runtime_ready=False))
print(json.dumps({'complete':True,'revision':p['revision'],'source_files':len(p['source']),'runtime_ready':False}))
