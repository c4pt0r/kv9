"""Bounded source-only derivation. Does not build or launch any gate."""
from pathlib import Path
import json,hashlib,os,difflib
P=Path(__file__).resolve().parent;O=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first');B=Path('/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first');S=B/'source';W=P.parent
REV='86aa6fc07d82f4d49b43fbfe309e0e5c20276da5'
oldrev='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
replacements={str(O):str(P),'/tmp/kv9-receipt-upper-bound-20260915-first':str(S),oldrev:REV,'upper-bound-e2e23cca':'wal-preallocation-86aa6fc','receipt-tail-a6ac335-full21-independent-payload-20260915-first':'wal-preallocation-86aa6fc-full21-independent-payload-20260915-first','/tmp/kv9-p0-tools/kind-linux-amd64':str(W/'chaos-tools-20260915-first/kind'),'/tmp/kv9-p0-ci-chaos.kubeconfig':str(W/'chaos-tools-20260915-first/kubeconfig')}
for x in ['auxiliary','image','finalize','chaos']:
 replacements['/tmp/kv9-upper-bound-'+x+'-root-20260915-first']=str(W/('wal-preallocation-'+x+'-root-20260915-first'))
# Historical release/recovery absolute references require an explicit metadata-shape adapter below.
for x in ['release','recovery','recovery-audit']:
 replacements['/tmp/kv9-upper-bound-'+x+'-root-20260915-first']=str(P/('pending-'+x+'-root'))
replacements['/tmp/kv9-upper-bound-recovery-audit-20260915-first']=str(P/'pending-recovery-audit')
def subst(t):
 for a,b in replacements.items():t=t.replace(a,b)
 return t
inv=json.loads((O/'inventory.pending.json').read_text())['entries'];copied=[]
for n,row in inv.items():
 if n.startswith(('origin/','diffs/')):continue
 q=O/n;r=P/'origin'/n;r.parent.mkdir(parents=True,exist_ok=True)
 if q.is_symlink():r.symlink_to(os.readlink(q))
 else:r.write_bytes(q.read_bytes())
 # Only code and required historical authorities are active; old results/pass flags remain origin-only.
 active=n.endswith(('.py','.sh')) or n in ['commands.json','auxiliary-build-commands.json','image.Dockerfile','historical-controls.json','historical-resources-preserve.json','timestamp-repair.json','final-preparation/commands.json','final-preparation/required-root-input-schema.json'] or q.is_symlink()
 if not active:continue
 d=P/n;d.parent.mkdir(parents=True,exist_ok=True)
 if q.is_symlink():d.symlink_to(subst(os.readlink(q)))
 else:d.write_text(subst(q.read_text()));d.chmod(q.stat().st_mode&0o777)
 copied.append(n)
for n in ['plan.pending.json','storage-policy.json']:
 (P/'origin'/n).write_bytes((O/n).read_bytes())
m=json.loads((B/'build/preallocated/build.json').read_text());native=json.loads((B/'correctness-client/build.json').read_text())
p=json.loads(subst((O/'plan.pending.json').read_text()));p.update(worktree=str(S),revision=REV,runtime_revision=REV,source=m['sources'],source_tree_sha256=m['source_tree_sha256'],production_binary={'path':str(B/'build/preallocated/kv9'),'sha256':m['binary_sha256']},server_manifest={'path':str(B/'build/preallocated/build.json'),'sha256':hashlib.sha256((B/'build/preallocated/build.json').read_bytes()).hexdigest()},server_cargo_path=str(B/'build/preallocated/kv9-cargo.jsonl'),server_cache_path=str(B/'build/cache-safety.json'),native_build_directory=str(B/'correctness-client'),native_client_build=native,native_contract_revision=REV,scope='Prepared full21 test of exact current-source WAL preallocation feature ELF. Source/proof/recovery binding pending; no current Chaos acceptance.',source_unchanged=False)
p['root_original_release_readback']={'path':str(B/'build/independent-readback.json'),'bytes':(B/'build/independent-readback.json').stat().st_size,'sha256':hashlib.sha256((B/'build/independent-readback.json').read_bytes()).hexdigest()}
p['build_codegen_requirement']['original_production_evidence']=p['root_original_release_readback'];p['build_codegen_requirement']['production_features']={'server':{'kv9':['wal-payload-preallocation'],'kv9-engine':['wal-payload-preallocation'],'others':[]},'native':[],'point':[]}
p['ordinary_recovery']={k:{'path':None,'bytes':None,'sha256':None}for k in ['audit','audit_terminal','process_terminal']}
p['pending_inputs']=['Actual current source/proof and selected-ELF recovery authority','Same-source point/pressure builds and independent codegen readback','Fresh image/probe/Kind/CRI','Fresh dual-filesystem capacity and exclusive coordination','Finalization and separate one-use runtime release']
p['readiness']['complete']=False
for group in [p['pressure_role'],p['source_default_limits']]:
 def refresh(x):
  if isinstance(x,dict):
   if isinstance(x.get('path'),str) and x['path'].startswith(str(S)):
    f=Path(x['path']);x.update(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
   for v in x.values():refresh(v)
  elif isinstance(x,list):
   for v in x:refresh(v)
 refresh(group)
p['pressure_role']['normal_server_feature_graph_unchanged']=False;p['pressure_role']['server_feature_scope']='Only explicit root/engine preallocation is enabled in tested server; pressure remains separate original remote read-only example.'
(P/'plan.pending.json').write_text(json.dumps(p,indent=2,sort_keys=True)+'\n')
(P/'derivation-state.json').write_text(json.dumps({'origin':str(O),'source':str(S),'revision':REV,'active_copied_files':copied,'substitutions':replacements,'source_helper_links_identical':True,'no_gate_executed':True},indent=2)+'\n')
print(json.dumps({'copied':len(copied),'source_files':len(m['sources']),'pending':True}))
