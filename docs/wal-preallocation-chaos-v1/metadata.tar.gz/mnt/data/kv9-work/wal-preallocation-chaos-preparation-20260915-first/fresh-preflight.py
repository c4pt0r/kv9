"""Fresh root-only host/process/resource coordination; no old cold transaction is concurrent."""
from pathlib import Path
import argparse,json,os,time
from space_guard import snapshot,check
from storage_policy import POLICY,EXPECTED_SHA256
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--capacity-output',type=Path,required=True);args=ap.parse_args()
for out in [args.output,args.capacity_output]:assert out.is_relative_to(P) and not out.exists()
forbidden=[];historical_container_processes=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdecimal():continue
 try:
  comm=(proc/'comm').read_text().strip()
  if comm in {'cargo','rustc','rustdoc','lean','lake','perf','zstd','gzip','pigz','redis-benchmark','kv9-batch-benchm','kv9-redis-batch-'}:forbidden.append({'pid':int(proc.name),'comm':comm})
  elif comm.startswith('kv9'):
   nsline=next((x for x in (proc/'status').read_text().splitlines()if x.startswith('NSpid:')),'').split()[1:]
   row={'pid':int(proc.name),'comm':comm,'pid_namespace_depth':len(nsline)}
   if len(nsline)<=1:forbidden.append(row)
   else:historical_container_processes.append(row)
 except (FileNotFoundError,ProcessLookupError):continue
assert not forbidden,forbidden
now=time.time_ns();fs=snapshot();available=check(fs,fs,launch=True)
coord={'complete':True,'observed_unix_ns':now,'no_live_builds_or_codecs':True,'no_other_fixture_or_timing':True,'forbidden_processes':forbidden,'historical_container_processes':historical_container_processes,'scope':'Fresh host coordination, not a historical cold-work terminal. Historical namespaces/container resources are preserved and exact namespace/UID membership is separately required by finalizer.'}
cap={'policy_id':POLICY['policy_id'],'policy_sha256':EXPECTED_SHA256,'started_ns':now,'available_bytes':available,'filesystems':fs,**{k:POLICY[k]for k in ['preflight_minimum_available_bytes','minimum_available_bytes','maximum_additional_build_image_archive_bytes']}}
for out,value in [(args.output,coord),(args.capacity_output,cap)]:
 out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x')as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'complete':True,'available_bytes':available,'coordination':str(args.output),'capacity':str(args.capacity_output)}))
