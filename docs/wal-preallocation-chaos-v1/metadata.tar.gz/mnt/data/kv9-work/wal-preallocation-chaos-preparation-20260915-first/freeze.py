"""Freeze current preparation/control sources and metadata; exclude mutable stage outputs and ELFs."""
from pathlib import Path
import ast,hashlib,json,os,difflib
P=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,d):(P/name).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
# Check all authored Python source syntax without importing a runtime entry point.
active=[]
for q in sorted(P.rglob('*.py')):
 if q.is_symlink() or any(x in q.relative_to(P).parts for x in ['origin','roots','failures','image-context-first','persistent-build','persistent-build-second','pressure-build-first']):continue
 ast.parse(q.read_text(),filename=str(q));active.append(str(q.relative_to(P)))
# Record finite actual source deltas, retaining original copies byte-for-byte.
diffs=[];D=P/'diffs';D.mkdir(exist_ok=True)
for q in sorted((P/'origin').rglob('*')):
 if not q.is_file() or q.is_symlink():continue
 rel=q.relative_to(P/'origin');dest=P/rel
 if not dest.is_file() or dest.is_symlink() or dest.suffix not in ['.py','.json','.sh'] and dest.name!='image.Dockerfile':continue
 before=q.read_text();after=dest.read_text()
 if before!=after:
  out=D/(str(rel).replace('/','__')+'.diff');out.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(q),tofile=str(dest))))
  diffs.append({'source':str(q),'derived':str(dest),'original_sha256':sha(q),'derived_sha256':sha(dest),'diff':str(out),'diff_sha256':sha(out)})
save('source-diffs.json',{'complete':True,'diffs':diffs,'scope':'Originals retained. Identity/path changes, strict role-specific feature/cache metadata, dual-filesystem bounds, and explicitly fresh helper qualification/coordination are separate from unrun full21 acceptance.'})
# Fresh-control provenance includes the exact historical metadata used by the native compatibility pass.
old=Path('/tmp/kv9-chaos-e2e.Q7qvIj');native_inputs=[old/'native-config.json',old/'persistent-client-pod.json']
phases=read(P/'historical-lineage/upper-bound-audit.json')['windows']
for phase in phases:
 for suffix in ['persistent-faults.json','persistent-victim.json']:
  q=old/(phase+'-'+suffix)
  if q.exists():native_inputs.append(q)
save('fresh-control-inputs.json',{'scope':'Existing accepted upper-bound small metadata used in fresh parser/predicate compatibility controls; no WAL or full history read. Timestamp/stale-format samples newly synthesized and explicitly labeled.','files':[{'path':str(q),'bytes':q.stat().st_size,'sha256':sha(q)}for q in native_inputs]})
# Existing ROOT-COMMANDS only refers to completed original lineage. Publish current concrete routes.
base=['sudo','-n','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','GIT_CONFIG_COUNT=1','GIT_CONFIG_KEY_0=safe.directory','GIT_CONFIG_VALUE_0=/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first/source','taskset','-c','6-15,22-31','python3']
cmds={'scope':'Completed auxiliary/control work is not to be repeated. Image actual terminal is already accepted; remaining root-only finite finalization/runtime/post commands are distinct.','cwd':'/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first/source','completed':{'auxiliary':{'session_id':81504,'terminal_receipt':'2a2c6c','exit_code':0,'root':str(P/'roots/auxiliary-second')},'auxiliary_readback':{'terminal_receipt':'15793d','exit_code':0},'source_recovery_context_bind':{'terminal_receipt':'6d7fe2','exit_code':0},'fresh_controls':{'terminal_receipt':'a529f0','exit_code':0,'groups':10,'controls':122},'image':{'session_id':9857,'terminal_receipt':'6737e3','exit_code':0,'root':str(P/'roots/image')}},'freeze_prerequisites_once':base+[str(P/'final-preparation/freeze-prerequisites.py')],'fresh_coordination_capacity_once':base+[str(P/'fresh-preflight.py'),'--output',str(P/'roots/finalize/coordination.json'),'--capacity-output',str(P/'roots/finalize/capacity.json')],'finalize_once':base+[str(P/'final-preparation/finalize.py'),'--input-pins-sha256','REQUIRED_ACTUAL_FROZEN_INPUT_PINS_SHA256','--coordination',str(P/'roots/finalize/coordination.json'),'--coordination-sha256','REQUIRED_ACTUAL_COORDINATION_SHA256','--capacity-reservation',str(P/'roots/finalize/capacity.json'),'--capacity-reservation-sha256','REQUIRED_ACTUAL_CAPACITY_SHA256','--archive-cleanup-reviewed'],'verify_prebuilt_once':base+[str(P/'overlay/verify-prebuilt.py'),'--plan',str(P/'plan.json')],'runtime_root_only_after_review':base+[str(P/'root-runners/run-runtime.py')],'post_after_actual_runtime_terminal':base+[str(P/'root-runners/run-post.py')],'runtime_root_must_be_absent_before_launch':str(P/'roots/runtime'),'actual_runtime_terminal_required_at':str(P/'roots/runtime/terminal.json'),'runtime_terminal_schema':{'complete':True,'exit_code':0,'session_id':'actual positive tool session or null with execution_kind direct_tool_terminal','terminal_receipt':'actual tool chunk','result_path':str(P/'roots/runtime/result.json'),'result_sha256':'actual complete result SHA256'},'runtime_ready':False,'images_or_faults_authorized_by_this_file':False}
save('ROOT-COMMANDS.json',cmds)
required=read(P/'final-preparation/required-prerequisite-paths.json')
required+=list(read(P/'fresh-qualification.json')['groups'][k]['path']for k in read(P/'fresh-qualification.json')['groups'])
required+=[str(P/q)for q in ['fresh-qualification.json','fresh-preflight.py','fresh-control-inputs.json','ROOT-COMMANDS.json']]
(P/'final-preparation/required-prerequisite-paths.json').write_text(json.dumps(sorted(set(required)),indent=2)+'\n')
save('preparation-check.json',{'complete':True,'active_python_files_syntax_checked':len(active),'actual_source_files':1529,'source_revision':'86aa6fc07d82f4d49b43fbfe309e0e5c20276da5','runtime_ready':False,'original_helper_qualification_receipts_restored':False,'fresh_helper_controls':122,'remaining':['Fresh current coordination/capacity and finalizer/prebuilt validation','Actual full21 runtime and all six post phases'],'historical_failure_preservation':'Original missing paths/hashes retained under origin and historical-lineage; current PATH, readback path and proof-control-fixture failures preserved separately.'})
excluded={'roots','image-context-first','persistent-build','persistent-build-second','pressure-build-first','__pycache__'}
entries={}
for q in sorted(P.rglob('*')):
 rel=q.relative_to(P)
 if any(x in excluded for x in rel.parts) or str(rel) in ['inventory.pending.json','inventory.source-recovery.json','inventory.json']:continue
 if q.is_symlink():entries[str(rel)]={'symlink':os.readlink(q),'resolved':str(q.resolve())}
 elif q.is_file():entries[str(rel)]={'bytes':q.stat().st_size,'sha256':sha(q)}
# The active plan now includes the actual context binding. Inventory validates the immutable pre-context copy instead.
source_entries=dict(entries);source_entries['plan.json']=dict(entries['plan.source-recovery.json'])
total=sum(x.get('bytes',0)for x in entries.values());assert total<=16*1024**2
save('inventory.pending.json',{'complete':True,'preparation_only':True,'runtime_ready':False,'entries':entries,'regular_bytes':total})
save('inventory.source-recovery.json',{'complete':True,'preparation_only':True,'runtime_ready':False,'entries':source_entries,'regular_bytes':total,'scope':'Fresh controls and exact source/recovery metadata. Mutable roots/build/image/runtime outputs excluded and bound by actual prerequisite/plan manifests.'})
files=[{'path':str(P/n),'bytes':r['bytes'],'sha256':r['sha256']}for n,r in entries.items()if 'sha256'in r]
for n in ['inventory.pending.json','inventory.source-recovery.json']:files.append({'path':str(P/n),'bytes':(P/n).stat().st_size,'sha256':sha(P/n)})
save('inventory.json',{'files':files,'symlinks':{n:r for n,r in entries.items()if 'symlink'in r},'complete':True,'runtime_ready':False,'scope':'Static preparation closure; stage payloads/ELFs and mutable runtime outputs are excluded, not claimed absent.'})
print(json.dumps({'complete':True,'files':len(files),'regular_bytes':total,'inventory_sha256':sha(P/'inventory.json'),'commands_sha256':sha(P/'ROOT-COMMANDS.json'),'source_recovery_inventory_sha256':sha(P/'inventory.source-recovery.json')}))
