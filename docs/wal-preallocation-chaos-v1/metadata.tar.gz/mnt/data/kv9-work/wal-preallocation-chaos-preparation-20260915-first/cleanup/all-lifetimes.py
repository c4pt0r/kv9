"""Readback exit/absence for every container supporting an accepted server lifetime."""
import json,subprocess,time
from pathlib import Path
O=Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/cleanup');assert json.loads((O/'summary.json').read_text())['complete'];raw=Path(json.loads(Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/plan.json').read_text())['artifact']);live=json.loads((raw/'async-write-live-observer.json').read_text());node='kv9-chaos-ci-p0-20260908-control-plane';lifetimes={};containers={};commands=[]
for batch in live['observations']:
 for row in batch['rows']:
  if not row.get('identity_matched'):continue
  key=(row['node'],row['pod_uid'],row['process_pid'],row['process_start_ticks'],row['process_boot_id']);cids=[]
  for status in row['container_statuses']:
   cid=status['containerID'].removeprefix('containerd://');cids.append(cid);containers[cid]=row['pod_uid']
  if key in lifetimes:assert lifetimes[key]==cids
  lifetimes[key]=cids
results={}
for cid,poduid in sorted(containers.items()):
 cmd=['docker','exec',node,'crictl','inspect',cid];started=time.time_ns();q=subprocess.run(cmd,capture_output=True,text=True,timeout=10);r=dict(command=cmd,started_unix_ns=started,ended_unix_ns=time.time_ns(),exit_code=q.returncode,stdout=q.stdout,stderr=q.stderr);commands.append(r)
 if q.returncode==0:
  detail=json.loads(q.stdout);assert detail['status']['labels']['io.kubernetes.pod.uid']==poduid;assert detail['status']['state']=='CONTAINER_EXITED'and not detail.get('info',{}).get('pid');results[cid]='CONTAINER_EXITED'
 else:assert 'not found'in q.stderr.lower()or'notfound'in q.stderr.lower(),q.stderr;results[cid]='removed'
result=dict(complete=True,scope=__doc__,server_lifetimes=[dict(node=k[0],pod_uid=k[1],namespace_pid=k[2],start_ticks=k[3],boot_id=k[4],container_ids=v,all_containers_exited=True)for k,v in sorted(lifetimes.items())],container_states=results,commands=commands,completed_unix_ns=time.time_ns());(O/'all-server-lifetimes-exited.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(complete=True,lifetimes=len(lifetimes),containers=len(containers))))
