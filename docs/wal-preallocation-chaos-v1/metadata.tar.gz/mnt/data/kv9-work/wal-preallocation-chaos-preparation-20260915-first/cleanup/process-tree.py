"""Read-only node PID/start/boot snapshot of all current owned container descendants."""
import json,subprocess,time
from pathlib import Path
O=Path(__file__).parent;b=json.loads((O/'before.json').read_text());rows=[]
script=r'''set -eu
printf '@@BOOT@@\n'; cat /proc/sys/kernel/random/boot_id
pending="$1"
while test -n "$pending"; do
 current=${pending%% *}
 if test "$pending" = "$current"; then pending=""; else pending=${pending#* }; fi
 if test -e /proc/$current/stat; then
  printf '@@PID@@\n';cat /proc/$current/stat
  printf '@@NSPID@@\n';sed -n '/NSpid:/p' /proc/$current/status
  printf '@@EXE@@\n';sha256sum /proc/$current/exe || true
  children=$(cat /proc/$current/task/$current/children)
  for child in $children;do pending="${pending:+$pending }$child";done
 fi
done
'''
for row in b['containers']:
 if not row['node_pid']:continue
 cmd=['docker','exec',row['node'],'bash','-c',script,'owned-tree',str(row['node_pid'])];started=time.time_ns();r=subprocess.run(cmd,capture_output=True,text=True,timeout=15);assert r.returncode==0;r=dict(container=row['container'],node=row['node'],pod_uid=row['pod_uid'],command=cmd,started_unix_ns=started,ended_unix_ns=time.time_ns(),exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr);rows.append(r)
(O/'process-tree-before.json').write_text(json.dumps(dict(complete=True,namespace=b['namespace'],namespace_uid=b['namespace_uid'],rows=rows),indent=2)+'\n');print('Retained',len(rows),'owned container process trees')
