"""Root-only original pressure executable build inside the source's existing BuildCache transaction."""
import hashlib, importlib.util, json, os, shutil, subprocess, time
from pathlib import Path
R=Path(__file__).parent;S=Path('/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first/source');OUT=R/'pressure-build-first'
def load(n,p):
 spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
w=load('original_workload_builder',S/'scripts/build-workload.py')
assert os.environ['CARGO_TARGET_DIR']=='/home/dongxu/kv9/target'
before=w.snapshot();assert before['revision']=='86aa6fc07d82f4d49b43fbfe309e0e5c20276da5' and not before['dirty']
OUT.mkdir(exist_ok=False)
command=['cargo','build','--locked','--release','-p','kv9-server','--example','admission-pressure','--message-format=json-render-diagnostics']
started=time.time_ns();result={'command':command,'started_unix_ns':started,'exit_code':None,'complete':False}
try:
 with w.cache.BuildCache(S,OUT,True,before) as session:
  with (OUT/'cargo.jsonl').open('x') as log,(OUT/'build.log').open('x') as err:session.run(command,stdout=log,stderr=err)
  session.check_artifacts(OUT/'cargo.jsonl');after=w.snapshot();assert after==before
  rows=[json.loads(s) for s in (OUT/'cargo.jsonl').read_text().splitlines()]
  selected=[x for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']=='admission-pressure' and x.get('executable')]
  assert len(selected)==1 and selected[0]['features']==[] and selected[0]['profile']['opt_level']=='3' and not selected[0]['profile']['test']
  binary=Path(selected[0]['executable']);assert 0<binary.stat().st_size<=512*1024*1024
  shutil.copy2(binary,OUT/'admission-pressure')
  h=hashlib.sha256((OUT/'admission-pressure').read_bytes()).hexdigest()
  manifest=dict(version=1,**before,profile='release',source_tree_sha256=w.sha(w.canonical(before['sources'])),binary_sha256=h,command=command,before=before,after=after,exit_code=0,started_unix_ns=started,ended_unix_ns=time.time_ns(),rustc=subprocess.check_output(['rustc','-vV'],cwd=S,text=True))
  (OUT/'build.json').write_text(json.dumps(manifest,indent=2)+'\n');assert w.snapshot()==before
 result.update(complete=True,exit_code=0)
except BaseException as e:
 result['failure']=repr(e);raise
finally:
 result['ended_unix_ns']=time.time_ns();(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
