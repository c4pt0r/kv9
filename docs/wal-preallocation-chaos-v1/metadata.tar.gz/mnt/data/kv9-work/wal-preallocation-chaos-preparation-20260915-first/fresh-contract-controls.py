"""Fresh source-bound delay-selection, pressure-role and cleanup scope controls. No server/cluster calls."""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,sys
P=Path(__file__).resolve().parent;O=P/'fresh-contract-controls';O.mkdir(exist_ok=False)
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
g=module('gate',P/'overlay/delay-gate.py');b=module('binding',P/'check-build-binding.py')
results={k:[]for k in ['delay-selection-regressions','pressure-role','cleanup-retention']}
def check(group,name,fn,accepted):
 try:fn();success=True;reason=None
 except (AssertionError,ValueError,KeyError,TypeError)as e:success=False;reason=repr(e)
 assert success==accepted,(group,name,reason)
 results[group].append({'name':name,'accepted':success,'expected_accepted':accepted,'reason':reason})
def require(x):assert x
def row(n,uid='a',start=100):return {'pod_uid':uid,'process_pid':1,'process_start_ticks':start,'process_boot_id':'owned-boot','state':{'metrics_export_successes':str(n)},'state_after':{'metrics_export_successes':str(n)}}
seed={'1':row(10),'2':row(20,uid='b')}
def observe(seq,want):
 f=g.ServerFreshness(seed)
 for rows,expected in zip(seq,want):require(bool(f.observe(rows))==expected)
cases=[('subset-never-fresh',[{'1':row(11)},{'1':row(12)}],[False,False]),('all-need-two-advances',[{'1':row(11),'2':row(21,'b')},{'1':row(12),'2':row(22,'b')}],[False,True]),('large-jump-is-one',[{'1':row(1000),'2':row(2000,'b')}],[False]),('mixed-stale-remains-ineligible',[{'1':row(11),'2':row(20,'b')},{'1':row(12),'2':row(21,'b')}],[False,False]),('missing-after-fresh-not-selected',[{'1':row(11),'2':row(21,'b')},{'1':row(12),'2':row(22,'b')},{'1':row(13)}],[False,True,False]),('replaced-process-excluded',[{'1':row(11,start=101),'2':row(21,'b')},{'1':row(12,start=101),'2':row(22,'b')}],[False,False]),('empty-sample-does-not-advance',[{},{}],[False,False])]
for name,seq,want in cases:check('delay-selection-regressions',name,lambda seq=seq,want=want:observe(seq,want),True)
check('delay-selection-regressions','monotonicity-required',lambda:observe([{'1':row(9),'2':row(21,'b')}],[False]),False)
rows=[x for s in (P/'pressure-build-first/cargo.jsonl').read_text().splitlines()if (x:=json.loads(s)).get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file:///mnt/data/kv9-work/wal-preallocation-runtime-20260915-first/source')]
check('pressure-role','actual-feature-target-inventory',lambda:b.feature_check(rows,'pressure'),True)
for pkg in b.PRESSURE_FEATURES:
 x=copy.deepcopy(rows);next(r for r in x if r['package_id'].rsplit('#',1)[-1].split('@')[0]==pkg)['features'].append('wal-payload-preallocation');check('pressure-role','extra-feature-'+pkg,lambda x=x:b.feature_check(x,'pressure'),False)
for name,mutate in [('missing-target',lambda x:x.pop()),('duplicate-target',lambda x:x.append(copy.deepcopy(x[0]))),('test-artifact',lambda x:x[0]['profile'].update(test=True)),('wrong-target',lambda x:x[0]['target'].update(name='other'))]:
 x=copy.deepcopy(rows);mutate(x);check('pressure-role',name,lambda x=x:b.feature_check(x,'pressure'),False)
check('pressure-role','unknown-role',lambda:b.feature_check(rows,'unrecognized'),False)
# Evaluate the actual acceptance expressions from cleanup source, not reconstructed mirrors.
tree=ast.parse((P/'cleanup/execute.py').read_text());assertions=[n for n in ast.walk(tree)if isinstance(n,ast.Assert)]
owned=next(n.test for n in assertions if 'ns==created' in ast.unparse(n.test).replace(' ',''))
archive=next(n.test for n in assertions if 'all_members_read_back' in ast.unparse(n.test))
def runexpr(expr,env):require(eval(compile(ast.Expression(expr),'<actual-cleanup-guard>','eval'),{},env))
def namespace():
 env={'ns':'fresh','created':{'metadata':{'name':'fresh','uid':'one'}},'before':{'namespace_uid':'one'},'plan':{'preserve_namespaces':{'historical':'old'}}};runexpr(owned,env)
 for edit in ['uid','protected']:
  x=copy.deepcopy(env)
  if edit=='uid':x['before']['namespace_uid']='two'
  else:x['plan']['preserve_namespaces']['fresh']='one'
  try:runexpr(owned,x)
  except AssertionError:continue
  raise AssertionError('changed/protected namespace accepted')
def archived():
 env={'archive':{'complete':True,'all_members_read_back':True,'all_inputs_rehashed':True}};runexpr(archive,env)
 for k in env['archive']:
  x=copy.deepcopy(env);x['archive'][k]=False
  try:runexpr(archive,x)
  except AssertionError:continue
  raise AssertionError('missing archive acceptance accepted')
check('cleanup-retention','exact-owned-namespace-and-uid',namespace,True);check('cleanup-retention','verified-archive-before-cleanup',archived,True)
for name,rows in results.items():
 out=O/name;out.mkdir();(out/'result.json').write_text(json.dumps({'complete':True,'cases':rows,'scope':__doc__},indent=2)+'\n')
(P/'fresh-contract-controls/result.json').write_text(json.dumps({'complete':True,'groups':{k:len(v)for k,v in results.items()},'source_pins':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [P/'overlay/delay-gate.py',P/'check-build-binding.py',P/'cleanup/execute.py']},'scope':__doc__},indent=2)+'\n')
print(json.dumps({'complete':True,'groups':{k:len(v)for k,v in results.items()}}))
