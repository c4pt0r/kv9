import hashlib,json,os,signal,subprocess,time
from pathlib import Path
R=Path('/tmp/kv9-upper-bound-chaos-root-20260915-first');P=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first');G=1024**3

import sys
sys.path.insert(0,str(P))
from storage_policy import POLICY,EXPECTED_SHA256,check_launch,check_space,check_capacity,guard_floor
read=lambda p:json.loads(Path(p).read_text())
def save(p,r):Path(p).write_text(json.dumps(r,indent=2)+'\n')
def avail():s=os.statvfs('/tmp');return s.f_bavail*s.f_frsize
runtime=read(R/'result.json');assert runtime['complete'] and all(x['exit_code']==0 for x in runtime['commands'])
terminal=read(R/'terminal.json')
assert terminal['complete'] and terminal['exit_code']==0 and terminal['result_path']==str(R/'result.json')
assert terminal['result_sha256']==hashlib.sha256((R/'result.json').read_bytes()).hexdigest()
assert isinstance(terminal['terminal_receipt'],str) and terminal['terminal_receipt']
assert (type(terminal.get('session_id')) is int and terminal['session_id']>0) or (terminal.get('session_id') is None and terminal.get('execution_kind')=='direct_tool_terminal')
commands=read(P/'commands.json');capacity=read('/tmp/kv9-upper-bound-finalize-root-20260915-first/capacity.json');check_capacity(capacity);floor=guard_floor(capacity['available_bytes'])
phases=[('independent','independent_after_runtime_terminal'),('cleanup-capture','cleanup_capture_after_independent'),('process-tree','cleanup_process_tree'),('archive','archive_before_cleanup'),('cleanup','reviewed_cleanup_after_archive'),('all-lifetimes','all_observed_server_lifetimes')]
result=dict(complete=False,started_ns=time.time_ns(),runtime_terminal=str(R/'terminal.json'),phases=[]);samples=[];p=None
try:
 for name,key in phases:
  out=R/name;out.mkdir(exist_ok=False);argv=commands[key];row=dict(name=name,argv=argv,started_ns=time.time_ns(),complete=False)
  with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:
   p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True);row['pid']=p.pid;result['phases'].append(row);save(out/'invocation.json',row)
   while True:
    available=avail();samples.append(dict(phase=name,observed_ns=time.time_ns(),available_bytes=available));assert available>=floor,'original capacity reservation crossed'
    try:row['exit_code']=p.wait(timeout=5);break
    except subprocess.TimeoutExpired:assert time.time_ns()-row['started_ns']<1200*10**9,'phase deadline exceeded'
  row['ended_ns']=time.time_ns();row['complete']=row['exit_code']==0;save(out/'result.json',row)
  assert row['complete'],(name,'original phase failed')
  print('PASS: '+name+' terminal exit 0',flush=True)
 result['complete']=True
except BaseException as e:
 result['failure']=repr(e)
 if p is not None and p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 raise
finally:
 result['ended_ns']=time.time_ns();result['final_available_bytes']=avail();save(R/'post-resource-samples.json',samples);save(R/'post-result.json',result)
print(json.dumps(result))
