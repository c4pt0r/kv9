"""Root-only final binding; no build, codec, fixture, fault or runtime release is performed."""
import argparse, copy, hashlib, json, os, re, shlex, subprocess, time
from pathlib import Path
F=Path(__file__).resolve().parent; P=F.parent
I=Path('/tmp/kv9-upper-bound-image-root-20260915-first')
A=Path('/tmp/kv9-upper-bound-auxiliary-root-20260915-first')
REV='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
# Future original prerequisite inventory is a required explicit root argument, never an inherited hash.
GIB=1024**3

import sys
sys.path.insert(0,str(P))
from storage_policy import POLICY,EXPECTED_SHA256,check_launch,check_space,check_capacity,guard_floor

def read(p): return json.loads(Path(p).read_text())
def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def bind(p):
    p=Path(p); return dict(path=str(p),sha256=sha(p))
def save(p,d):
    with Path(p).open('x') as f:
        json.dump(d,f,indent=2,sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
def checked(path,h):
    path=Path(path); assert path.is_file() and sha(path)==h,str(path); return read(path)
def codegen(argv):
    if isinstance(argv,str): argv=shlex.split(argv.split('Running `',1)[1].rsplit('`',1)[0])
    opts=[argv[i+1]for i,x in enumerate(argv[:-1])if x=='-C']
    cfg=[argv[i+1]for i,x in enumerate(argv[:-1])if x=='--cfg']
    assert all(x in opts for x in ['opt-level=3','lto=thin','codegen-units=1'])
    assert not any(x.startswith('panic=') and x!='panic=unwind' for x in opts)
    assert not any(x.startswith('target-cpu=') for x in opts)
    assert not any(x.startswith('feature=') for x in cfg)
def terminal(d):
    assert d['complete'] is True and type(d['exit_code']) is int and d['exit_code']==0
    assert isinstance(d['session_id'],int) and not isinstance(d['session_id'],bool) and d['session_id']>0
    assert isinstance(d['terminal_receipt'],str) and re.fullmatch(r'[0-9a-f]{6,}',d['terminal_receipt'])
    result=checked(d['result_path'],d['result_sha256']); assert result['complete'] is True
    return result

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-pins-sha256',required=True)
    ap.add_argument('--cold-terminal',type=Path,required=True)
    ap.add_argument('--cold-terminal-sha256',required=True)
    ap.add_argument('--coordination',type=Path,required=True)
    ap.add_argument('--coordination-sha256',required=True)
    ap.add_argument('--capacity-reservation',type=Path,required=True)
    ap.add_argument('--capacity-reservation-sha256',required=True)
    ap.add_argument('--archive-cleanup-reviewed',action='store_true',required=True)
    args=ap.parse_args(); assert __debug__
    assert sha(F/'input-pins.json')==args.input_pins_sha256
    pins=read(F/'input-pins.json')
    assert set(pins)==set(read(F/'required-prerequisite-paths.json'))
    for name,row in pins.items():
        q=Path(name); assert q.stat().st_size==row['bytes'] and sha(q)==row['sha256'],name
    # The original active plan legitimately gained only actual build bindings.
    static=read(P/'inventory.source-recovery.json')['entries']
    for name,row in static.items():
        q=P/name
        if name=='plan.json': q=P/'plan.source-recovery.json'
        if 'sha256' in row:
            assert q.stat().st_size==row['bytes'] and sha(q)==row['sha256'],name
        else:
            assert q.is_symlink() and os.readlink(q)==row['symlink'] and str(q.resolve())==row['resolved'],name
    p=read(P/'plan.json'); original=copy.deepcopy(p)
    assert p['revision']==REV and not p['fixture_started'] and not p['plan_ready']
    assert not p['fixture_launch_authorized'] and p['source_unchanged']
    assert not (P/'ready-plan.json').exists() and not (P/'root-runtime-release.json').exists()
    assert not (P/'runtime-release-consumed.json').exists()
    initial=read(P/'plan.source-recovery.json'); allowed={'correctness_client_build','pressure_binary','context_files','source_unchanged'}
    assert set(initial)==set(p)
    for k in initial:
        if k not in allowed: assert initial[k]==p[k],('unexpected pre-freeze plan mutation',k)
    # Actual outer image terminal, exact five child argv and successful exits.
    image_result=terminal(read(I/'terminal.json'))
    assert image_result==read(I/'result.json') and image_result['probe_container_absent'] is True
    assert image_result['command_manifest_sha256']==sha(P/'commands.json')
    commands=read(P/'commands.json'); phases=['image_build_after_binding','image_probe_after_build','image_inspect_after_build','kind_load_after_probe','cri_readback_after_kind_load']
    assert [x['name']for x in image_result['commands']]==phases
    for row in image_result['commands']:
        assert row['argv']==commands[row['name']] and row['exit_code']==0 and row['ended_ns']>=row['started_ns']
        assert not Path('/proc/'+str(row['pid'])).exists(),('image child still present',row['pid'])
    auxiliary=terminal(read(A/'terminal.json')); assert auxiliary==read(A/'result.json')
    aux_commands=read(P/'auxiliary-build-commands.json')
    assert auxiliary['command_manifest_sha256']==sha(P/'auxiliary-build-commands.json')
    assert [r['name']for r in auxiliary['commands']]==['build_point','build_pressure']
    for row in auxiliary['commands']:
        assert row['argv']==aux_commands[row['name']] and row['exit_code']==0
        assert not Path('/proc/'+str(row['pid'])).exists()
    aux=read(A/'independent-codegen-readback.json'); assert aux['complete'] and aux['revision']==REV
    assert set(aux['roles'])=={'point','pressure'}
    for role,directory in [('point',Path(p['point_build_directory'])),('pressure',Path(p['pressure_manifest_path']).parent)]:
        row=aux['roles'][role]; codegen(row['actual_rustc_argv'])
        assert row['manifest_sha256']==sha(directory/'build.json')
        assert row['binary_sha256']==read(directory/'build.json')['binary_sha256']
        assert row['source_tree_sha256']==p['source_tree_sha256'] and row['source_files']==len(p['source'])
    prod_path=Path('/tmp/kv9-upper-bound-release-root-20260915-first/readback-first/result.json')
    prod=read(prod_path); assert prod['complete'] and prod['revision']==REV and prod['source_files']==len(p['source'])
    assert prod['server_sha256']==p['production_binary']['sha256'] and prod['workload_sha256']==p['native_client_build']['binary_sha256']
    expected_production={'kv9':'kv9-build.log','kv9_batch_workload':'workload/build.log'}
    production_rows=prod['default_production_codegen']
    assert len(production_rows)==2
    expected_logs={str(Path(p['server_manifest']['path']).parent/rel):crate for crate,rel in expected_production.items()}
    assert {r['path'] for r in production_rows}==set(expected_logs)
    for row in production_rows:
        log=Path(row['path']); crate=expected_logs[str(log)]
        assert sha(log)==row['sha256']==pins[str(log)]['sha256']
        lines=[s for s in log.read_text().splitlines() if 'Running `' in s and '--crate-name '+crate+' ' in s]
        assert lines==[row['rustc_command']]
        codegen(row['rustc_command'])
    source_gate=read('/tmp/kv9-upper-bound-release-root-20260915-first/preflight.json')
    assert source_gate['complete'] is True and source_gate['revision']==REV
    assert source_gate['source_snapshot']['sources']==p['source'] and source_gate['source_root']==p['worktree']
    assert source_gate['proof_bound_files']==13 and source_gate['reconstructed_parent_driver'] is True
    for name,binding in source_gate['source_gate_inputs'].items():
        if name.startswith('/tmp/kv9-upper-bound-'):
            assert type(binding) is str and len(binding)==64
            assert sha(name)==binding==pins[name]['sha256']
            assert Path(name).stat().st_size==pins[name]['bytes']
    assert read(P/'build-binding-first.json')['complete'] is True
    recovery=checked(p['ordinary_recovery']['audit']['path'],p['ordinary_recovery']['audit']['sha256'])
    assert recovery['complete'] and recovery['accepted'] and recovery['revision']==REV
    assert recovery['source_unchanged'] and recovery['original_inputs_unchanged'] and recovery['owned_lifetimes_exited']
    assert recovery['server_sha256']==p['production_binary']['sha256'] and recovery['client_sha256']==p['native_client_build']['binary_sha256']
    # Cold work must actually be terminal; root separately supplies fresh coordination.
    cold=checked(args.cold_terminal,args.cold_terminal_sha256); terminal(cold)
    coordination=checked(args.coordination,args.coordination_sha256)
    assert coordination['complete'] is True and coordination['no_live_builds_or_codecs'] is True
    assert coordination['no_other_fixture_or_timing'] is True
    assert coordination['cold_terminal']==bind(args.cold_terminal)
    assert 0<=time.time_ns()-coordination['observed_unix_ns']<180*10**9
    capacity=checked(args.capacity_reservation,args.capacity_reservation_sha256)
    check_capacity(capacity)
    assert 0<=time.time_ns()-capacity['started_ns']<180*10**9
    out=F/'finalization-first'; out.mkdir(exist_ok=False); calls=[]
    def run(name,argv,expect=0):
        started=time.time_ns(); q=subprocess.run(argv,capture_output=True,text=True,timeout=120)
        (out/(name+'.stdout')).write_text(q.stdout); (out/(name+'.stderr')).write_text(q.stderr)
        calls.append(dict(name=name,argv=argv,exit_code=q.returncode,started_ns=started,ended_ns=time.time_ns()))
        assert q.returncode==expect,(name,q.returncode,q.stderr[-1200:]); return q.stdout
    try:
        assert run('source-head',['git','-C',p['worktree'],'rev-parse','HEAD']).strip()==REV
        assert run('source-clean',['git','-C',p['worktree'],'status','--porcelain'])==''
        run('original-build-binding',['python3',str(P/'check-build-binding.py'),'--plan',str(P/'plan.json')])
        for row in p['readiness']['preflights'].values(): assert sha(row['path'])==row['sha256']
        image=read(I/'image_inspect_after_build.stdout'); assert len(image)==1; image=image[0]
        current=json.loads(run('image-current',['docker','image','inspect',p['image']])); assert current[0]['Id']==image['Id']
        payload={}
        for line in (I/'image_probe_after_build.stdout').read_text().splitlines():
            m=re.fullmatch(r'([0-9a-f]{64})  (/\S+)',line)
            if m: assert m[2] not in payload; payload[m[2]]=m[1]
        assert len(payload)==8
        for name in ['kv9','kv9-workload','kv9-batch-workload','admission-pressure']:
            assert payload['/usr/local/bin/'+name]==p['context_files'][name]
        for name,target in [('point-build.json','/opt/kv9-workload/build.json'),('native-build.json','/opt/kv9-batch-workload/build.json')]: assert payload[target]==p['context_files'][name]
        for name,h in p['context_files'].items(): assert sha(Path(p['context'])/name)==h,name
        missing=run('probe-absence',['docker','container','inspect','upper-bound-e2e23cca-full21-image-probe-20260915-first'],1)
        assert 'No such container:'in(out/'probe-absence.stderr').read_text()
        kube=['kubectl','--kubeconfig',p['kubeconfig'],'--request-timeout=10s']
        nodes=sorted(run('kind-nodes',[p['kind'],'get','nodes','--name',p['kind_cluster']]).splitlines())
        cluster=json.loads(run('nodes',kube+['get','nodes','-o','json']))
        assert nodes==sorted(n['metadata']['name']for n in cluster['items'])
        assert all(any(c['type']=='Ready' and c['status']=='True'for c in n['status']['conditions'])for n in cluster['items'])
        loaded={}
        for n,node in enumerate(nodes):
            entries=json.loads(run('cri-'+str(n),['docker','exec',node,'crictl','images','--output','json']))['images']
            rows=[x for x in entries if 'docker.io/library/'+p['image']in x.get('repoTags',[])]
            assert len(rows)==1 and rows[0]['id']==image['Id']; loaded[node]=rows[0]
        assert len(loaded)==1,'unchanged single-node Kind protocol'
        cri=next(iter(loaded.values()))
        oldcri=[x for x in read(I/'cri_readback_after_kind_load.stdout')['images']if x['id']==image['Id']]
        assert oldcri==[cri] and cri['repoDigests'] and all('@sha256:'in x for x in cri['repoDigests'])
        ns=json.loads(run('namespaces',kube+['get','namespaces','-o','json']))
        actual={x['metadata']['name']:x['metadata']['uid']for x in ns['items']}; assert actual==p['preserve_namespaces']
        faults=json.loads(run('faults',kube+['get','podchaos,networkchaos,iochaos','-A','-o','json']))
        identities=[dict(kind=x['kind'],namespace=x['metadata']['namespace'],name=x['metadata']['name'],uid=x['metadata']['uid'])for x in faults['items']]
        assert sorted(identities,key=str)==sorted(read(P/'historical-resources-preserve.json')['faults'],key=str)
        crds=json.loads(run('crds',kube+['get','crd','podchaos.chaos-mesh.org','networkchaos.chaos-mesh.org','iochaos.chaos-mesh.org','-o','json']))
        assert len(crds['items'])==3 and all(any(c['type']=='Established'and c['status']=='True'for c in x['status']['conditions'])for x in crds['items'])
        pods=json.loads(run('chaos-pods',kube+['get','pods','-n','chaos-mesh','-o','json']))
        for prefix in ['chaos-controller-manager-','chaos-daemon-','chaos-dns-server-']:
            rows=[x for x in pods['items']if x['metadata']['name'].startswith(prefix)]
            assert rows and all(x['status']['phase']=='Running' and x['status'].get('containerStatuses') and all(s['ready']for s in x['status']['containerStatuses'])for x in rows)
        v=os.statvfs('/tmp'); available=v.f_bavail*v.f_frsize
        check_launch(available); check_space(available,capacity['available_bytes'])
        assert time.time_ns()-coordination['observed_unix_ns']<180*10**9
        fresh=dict(complete=True,checked_ns=time.time_ns(),namespaces=actual,loaded=loaded,available_bytes=available,cold_terminal=bind(args.cold_terminal),coordination=bind(args.coordination),capacity=bind(args.capacity_reservation),commands=calls)
        save(out/'readiness.json',fresh); save(out/'plan-before-finalization.json',original)
        p.update(build_complete=True,plan_ready=True,fixture_launch_authorized=False,archive_cleanup_reviewed=True,pending_inputs=[],accepted_cri_image_ids=cri['repoDigests'],prepared_image=dict(complete=True,tag=p['image'],docker_image_id=image['Id'],cri=cri,hashes=payload))
        p['readiness'].update(complete=True,cluster=bind(out/'readiness.json'))
        p['root_original_release_readback']=bind(prod_path)
        p['build_codegen_requirement']['original_production_evidence']=bind(prod_path)
        p['build_codegen_requirement']['auxiliary_codegen_readback']=bind(A/'independent-codegen-readback.json')
        p['root_final_prerequisites']=dict(image_terminal=bind(I/'terminal.json'),cold_terminal=bind(args.cold_terminal),coordination=bind(args.coordination),capacity=bind(args.capacity_reservation),workspace=bind('/tmp/kv9-upper-bound-release-root-20260915-first/preflight.json'),final_binder=bind(Path(__file__)),input_pins=bind(F/'input-pins.json'))
        assert read(P/'plan.json')==original,'active plan changed during finalization'
        with (P/'image-inspect.stdout').open('xb')as f:f.write((I/'image_inspect_after_build.stdout').read_bytes());f.flush();os.fsync(f.fileno())
        save(P/'ready-plan.json',p);p['ready_plan_sha256']=sha(P/'ready-plan.json')
        save(out/'plan-final.json',p)
        # Root-authorized prospective finalization; original pending and pre-final plans retained.
        temporary=P/'plan.finalizing.json';save(temporary,p);os.replace(temporary,P/'plan.json')
        inventory={}
        for q in sorted(P.rglob('*')):
            if '__pycache__'in q.parts or q.is_relative_to(out):continue
            name=str(q.relative_to(P))
            if q.is_symlink():inventory[name]=dict(symlink=os.readlink(q),resolved=str(q.resolve()))
            elif q.is_file():inventory[name]=dict(bytes=q.stat().st_size,sha256=sha(q))
        save(out/'runtime-input-inventory.json',dict(complete=True,entries=inventory,scope='Current actual prepared inputs; no runtime release or result.'))
        receipt=dict(complete=True,plan_sha256=sha(P/'plan.json'),ready_plan_sha256=p['ready_plan_sha256'],inventory=bind(out/'runtime-input-inventory.json'),image_id=image['Id'],revision=REV,fixture_launch_authorized=False,root_runtime_release_created=False,commands=calls)
        save(out/'result.json',receipt);print(json.dumps(receipt))
    except BaseException as e:
        save(out/'failure.json',dict(complete=False,failure=repr(e),commands=calls,observed_ns=time.time_ns()));raise
if __name__=='__main__':main()
