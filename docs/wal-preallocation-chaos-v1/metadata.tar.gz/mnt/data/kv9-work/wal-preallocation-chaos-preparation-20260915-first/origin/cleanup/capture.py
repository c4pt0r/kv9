"""Retain only the created fixture namespace ownership before scoped cleanup."""
import json,subprocess,time,hashlib
from pathlib import Path
O=Path(__file__).parent;plan=json.loads(Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/plan.json').read_text());raw=Path(plan['artifact']);created=json.loads((raw/'owned-namespace-created.json').read_text());ns=created['metadata']['name'];assert ns not in plan['preserve_namespaces'];commands=[]
def run(name,args):
 r=dict(command=args,started_unix_ns=time.time_ns());q=subprocess.run(args,capture_output=True,text=True,timeout=30);r.update(ended_unix_ns=time.time_ns(),exit_code=q.returncode,stdout=name+'.stdout',stderr=name+'.stderr');(O/r['stdout']).write_text(q.stdout);(O/r['stderr']).write_text(q.stderr);commands.append(r);(O/'capture-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert q.returncode==0,(args,q.stderr);return q.stdout
k=['kubectl','--kubeconfig',plan['kubeconfig'],'--request-timeout=10s'];namespace=json.loads(run('namespace-before',k+['get','namespace',ns,'-o','json']));assert namespace['metadata']['uid']==created['metadata']['uid'];pods=json.loads(run('pods-before',k+['get','pods','-n',ns,'-o','json']));run('resources-before',k+['get','pods,services,endpoints,endpointslices,deployments,persistentvolumeclaims','-n',ns,'-o','json']);run('faults-before',k+['get','podchaos,networkchaos,iochaos','-n',ns,'-o','json']);containers=[]
for pod in pods['items']:
 assert pod['metadata']['namespace']==ns
 for status in pod['status'].get('containerStatuses',[]):
  cid=status.get('containerID','').removeprefix('containerd://')
  if not cid:continue
  node=pod['spec']['nodeName'];name=pod['metadata']['name']+'-'+status['name'];detail=json.loads(run(name+'-cri',['docker','exec',node,'crictl','inspect',cid]));assert detail['status']['labels']['io.kubernetes.pod.uid']==pod['metadata']['uid'];pid=detail.get('info',{}).get('pid',0);r=dict(pod=pod['metadata']['name'],pod_uid=pod['metadata']['uid'],container=cid,node=node,state=detail['status']['state'],node_pid=pid)
  if pid:
   script='set -e; cat /proc/sys/kernel/random/boot_id; cat /proc/"$1"/stat; sha256sum /proc/"$1"/exe; tr "\\0" "\\n" < /proc/"$1"/cmdline'
   r['process_evidence']=run(name+'-process',['docker','exec',node,'bash','-c',script,'owned-node-process',str(pid)])
  containers.append(r)
result=dict(complete=True,namespace=ns,namespace_uid=namespace['metadata']['uid'],containers=containers,commands=commands,captured_unix_ns=time.time_ns(),scope=__doc__,historical_namespaces=plan['preserve_namespaces']);(O/'before.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(complete=True,namespace=ns,containers=len(containers),running=sum(bool(r['node_pid'])for r in containers))))
