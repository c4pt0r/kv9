"""Root-only bounded metadata freeze after auxiliary/image terminal; no builds or runtime."""
from pathlib import Path
import hashlib,json,os
F=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert __debug__
paths=read(F/'required-prerequisite-paths.json'); assert len(paths)==len(set(paths))
rows={}
for name in paths:
 p=Path(name);assert p.is_file() and not p.is_symlink() and p.stat().st_size<=16*1024*1024,name
 rows[name]=dict(bytes=p.stat().st_size,sha256=sha(p))
for root in ['/tmp/kv9-upper-bound-auxiliary-root-20260915-first','/tmp/kv9-upper-bound-image-root-20260915-first']:
 t=read(Path(root)/'terminal.json');assert t['complete'] and t['exit_code']==0
 assert read(t['result_path'])['complete'] and sha(t['result_path'])==t['result_sha256']
with (F/'input-pins.json').open('x')as f:json.dump(rows,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(complete=True,input_pins_sha256=sha(F/'input-pins.json'),files=len(rows),runtime_authorized=False)))
