from pathlib import Path
import importlib.util,json,time,copy,hashlib
P=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/overlay/delay-gate.py');spec=importlib.util.spec_from_file_location('gate',P);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);root=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/overlay/preflight/gate-check');root.mkdir(exist_ok=False);rows=[]
def check(name,fn,accept):
 try:result=fn();passed=True;reason=None
 except (AssertionError,TimeoutError,KeyError,ValueError) as e:passed=False;reason=repr(e)
 assert passed==accept,(name,reason);rows.append(dict(name=name,accepted=passed,expected_accepted=accept,reason=reason))
ns='kv9-chaos-owned-preflight';fault={'items':[{'kind':'NetworkChaos','metadata':{'name':'delay-follower','namespace':ns,'uid':'owned-fault'},'spec':{'selector':{'namespaces':[ns]}},'status':{'conditions':[{'type':'AllInjected','status':'True'}]}}]}
check('active-owned-fault',lambda:g.active_fault(fault,ns),True)
healed=copy.deepcopy(fault);healed['items'][0]['metadata']['deletionTimestamp']='now';check('healed-fault',lambda:g.active_fault(healed,ns),False)
expired=copy.deepcopy(fault);expired['items'][0]['status']['conditions'].append({'type':'AllRecovered','status':'True'});check('expired-fault',lambda:g.active_fault(expired,ns),False)
check('wrong-namespace',lambda:g.active_fault(fault,ns+'-other'),False)
fixture=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/overlay/preflight/probe-check/actual-live-writer.stdout');raw=fixture.read_text();prior=json.loads(Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/overlay/preflight/probe-check/result.json').read_text());exe=prior['command'][-1];parsed=g.probe.parse(raw,prior['executable_sha256'],exe)
check('stale-same-pid-cannot-enter-gate',lambda:g.probe.parse(raw.replace('process_start_ticks='+str(prior['start_ticks']),'process_start_ticks='+str(prior['start_ticks']-1)),prior['executable_sha256'],exe),False)
a=copy.deepcopy(parsed);a['pod_uid']='pod';a['state_after']['public_raw_get_completed_inline']='10';b=copy.deepcopy(a);b['state']['public_raw_get_completed_inline']='12'
check('same-lifetime-inline-growth',lambda: g.matching_growth({'1':a},{'1':b}) or (_ for _ in ()).throw(AssertionError('no growth')),True)
stale=copy.deepcopy(b);stale['process_start_ticks']+=1;check('restarted-lifetime-is-not-growth',lambda: g.matching_growth({'1':a},{'1':stale}) or (_ for _ in ()).throw(AssertionError('no same-lifetime growth')),False)
fallen=copy.deepcopy(b);fallen['state']['public_raw_get_completed_inline']='9';check('monotonicity-not-waived',lambda:g.matching_growth({'1':a},{'1':fallen}),False)
events=[{'type':'invoke','id':1,'op':'get','phase':'delay','monotonic_ns':101},{'type':'return','id':1,'outcome':'ok','monotonic_ns':102}]
check('complete-contained-get',lambda:g.completed_get(events,100) or (_ for _ in ()).throw(AssertionError('no contained GET')),True)
check('old-invocation-excluded',lambda:g.completed_get(events,102) or (_ for _ in ()).throw(AssertionError('no contained GET')),False)
unknown=copy.deepcopy(events);unknown[1]['outcome']='unknown';check('unknown-get-excluded',lambda:g.completed_get(unknown,100) or (_ for _ in ()).throw(AssertionError('no contained GET')),False)
started=time.monotonic();check('bounded-empty-evidence-timeout',lambda:g.wait_qualifying(lambda:None,time.monotonic()+.03,.005),False);assert .025<=time.monotonic()-started<.5
check('qualifying-evidence-finishes',lambda:g.wait_qualifying(lambda:{'qualified':True},time.monotonic()+.1),True)
result=dict(complete=True,cases=rows,gate_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),scope='Pure observer-gate predicates and bounded wait plus independently captured actual-child boot/start probe input. Does not inject chaos or accept a candidate; missing/stale writer identities and missing completed success fail.');(root/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':True,'cases':len(rows),'gate_sha256':result['gate_sha256']}))
