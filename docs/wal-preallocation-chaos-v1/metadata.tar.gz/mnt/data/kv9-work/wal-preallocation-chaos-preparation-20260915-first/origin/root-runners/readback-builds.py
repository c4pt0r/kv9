import hashlib, json, shlex, subprocess
from pathlib import Path

ROOT=Path('/tmp/kv9-upper-bound-auxiliary-root-20260915-first')
PREP=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first')
SOURCE=Path('/tmp/kv9-receipt-upper-bound-20260915-first')
revision='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
assert json.loads((ROOT/'result.json').read_text())['complete']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==revision
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=SOURCE)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
roles={
    'point':(PREP/'persistent-build','kv9-workload','kv9_workload'),
    'pressure':(PREP/'pressure-build-first','admission-pressure','admission_pressure'),
}
result=dict(complete=False,revision=revision,roles={})
for role,(directory,binary,crate) in roles.items():
    manifest=json.loads((directory/'build.json').read_text())
    assert manifest['revision']==revision and not manifest['dirty'] and manifest['profile']=='release'
    assert sha(directory/binary)==manifest['binary_sha256']
    if 'sources' in manifest:sources=manifest['sources']
    else:sources=json.loads((directory/'sources.json').read_text())['sources']
    for p,h in sources.items():assert sha(SOURCE/p)==h,p
    lines=[line for line in (directory/'build.log').read_text().splitlines()
           if 'Running `' in line and '--crate-name '+crate+' ' in line]
    assert len(lines)==1,(role,len(lines))
    argv=shlex.split(lines[0].split('Running `',1)[1].rsplit('`',1)[0])
    options=[argv[i+1] for i,arg in enumerate(argv[:-1]) if arg=='-C']
    assert all(option in options for option in ('opt-level=3','lto=thin','codegen-units=1')),options
    assert not any(x.startswith('panic=') and x!='panic=unwind' for x in options)
    cfgs=[argv[i+1] for i,arg in enumerate(argv[:-1]) if arg=='--cfg']
    assert not any(x.startswith('feature=') for x in cfgs)
    result['roles'][role]=dict(binary_sha256=manifest['binary_sha256'],manifest_sha256=sha(directory/'build.json'),
        source_files=len(sources),source_tree_sha256=manifest['source_tree_sha256'],
        actual_rustc_argv=argv,codegen_options=options,crate_feature_cfgs=cfgs,
        panic_strategy='Rust default unwind; no override',
        scope='Default point binary or test-only pressure example; full package features checked by original build-binding verifier')
result['complete']=True
with (ROOT/'independent-codegen-readback.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(complete=True,roles={name:{k:v for k,v in row.items() if k!='actual_rustc_argv'} for name,row in result['roles'].items()})))
