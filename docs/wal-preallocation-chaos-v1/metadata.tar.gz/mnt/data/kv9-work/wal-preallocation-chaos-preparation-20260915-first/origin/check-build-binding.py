"""Read-only original-build verification; not a compiler or retrospective manifest generator."""
import argparse, hashlib, json
from pathlib import Path
R=Path(__file__).parent
REV='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
SERVER_MANIFEST='e6f3ebab9510cdf87c1e521d5b64578c224a08842956998cb2c9690f67498cb7'
SERVER='6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49'
NATIVE='44d0f6429fd549fc7d0fac6e71ba67b413a2a8aca0e3e3f0386a64058ac06769'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
PRESSURE_FEATURES = {
 'kv9-common':['testing'], 'kv9-engine':['testing'], 'kv9-raft':['experimental-leader-lease','testing'],
 'kv9-meta':[], 'kv9-region':[], 'kv9-server':[], 'kv9-txn':[],
}
PRESSURE_TARGETS = {
 ('kv9-raft','build-script-build',('custom-build',)),
 ('kv9-server','build-script-build',('custom-build',)),
 *{(name,name.replace('-','_'),('lib',)) for name in PRESSURE_FEATURES},
 ('kv9-server','admission-pressure',('example',)),
}

def feature_check(rows,role):
 assert role in ('server','native','point','pressure'), 'unknown build role'
 assert rows, 'first-party artifact inventory missing'
 observed=set()
 for x in rows:
  assert x['profile']['test'] is False, 'test harness artifact is not a release helper'
  if role=='pressure':
   package=x['package_id'].rsplit('#',1)[-1].split('@',1)[0]
   assert package in PRESSURE_FEATURES, 'unexpected pressure package'
   assert x['features']==PRESSURE_FEATURES[package], 'pressure package feature set differs'
   target=(package,x['target']['name'],tuple(x['target']['kind']))
   assert target in PRESSURE_TARGETS and target not in observed, 'pressure target inventory differs'
   observed.add(target)
  else:
   assert x['features']==[], 'production role has non-default features'
 if role=='pressure':assert observed==PRESSURE_TARGETS, 'pressure required target missing'

def cache_check(path,source,role='server'):
 c=read(path)
 assert c['complete'] and c['invalidation_complete'] and c['profile']=='release'
 assert c['target_directory']=='/home/dongxu/kv9/target' and c['source_root']==source
 feature_check(c['first_party_artifacts'],role)
 for x in c['first_party_artifacts']:
  assert x['fresh'] is False or x['seen_after_invalidation'] is True, 'stale first-observed first-party artifact'
  if x['target']['kind']!=['custom-build']:assert x['profile']['opt_level']=='3'
 return c

def verify(plan):
 source=Path(plan['worktree']); assert plan['revision']==REV
 base=Path(plan['server_manifest']['path']).parent
 assert sha(base/'build.json')==SERVER_MANIFEST and sha(base/'kv9')==SERVER
 m=read(base/'build.json');assert m['revision']==REV and not m['dirty'] and m['profile']=='release'
 assert m['sources']==plan['source'] and m['source_tree_sha256']==plan['source_tree_sha256']
 for name,h in m['sources'].items():assert sha(source/name)==h,name
 cache_check(base/'cache-safety.json',str(source))
 native=Path(plan['native_build_directory']);point=Path(plan['point_build_directory']);pressure=Path(plan['pressure_manifest_path']).parent
 for directory,binary,expected in [(native,'kv9-batch-workload',plan['native_client_build']),(point,'kv9-workload',plan['correctness_client_build'])]:
  b=read(directory/'build.json');i=read(directory/'sources.json')
  assert expected is not None and b==expected
  assert b['revision']==REV and b['dirty'] is False and b['profile']=='release'
  assert i['sources']==m['sources'] and b['source_tree_sha256']==m['source_tree_sha256']
  assert sha(directory/binary)==b['binary_sha256']
  rows=[json.loads(s) for s in (directory/'cargo.jsonl').read_text().splitlines()]
  feature_check([x for x in rows if x.get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file://'+str(source)+'/')], 'native' if binary=='kv9-batch-workload' else 'point')
  assert rows[-1]=={'reason':'build-finished','success':True}
  for name in [binary,'kv9_engine','kv9_raft','kv9_server']:
   x=[a for a in rows if a.get('reason')=='compiler-artifact' and a['target']['name']==name]
   assert len(x)==1 and x[0]['features']==[] and x[0]['profile']['test'] is False and x[0]['profile']['opt_level']=='3'
 assert sha(native/'kv9-batch-workload')==NATIVE
 cache_check(point/'cache-safety.json',str(source),'point');cache_check(pressure/'cache-safety.json',str(source),'pressure')
 pressure_rows=[json.loads(s) for s in (pressure/'cargo.jsonl').read_text().splitlines()]
 assert pressure_rows[-1]=={'reason':'build-finished','success':True}
 feature_check([x for x in pressure_rows if x.get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file://'+str(source)+'/')], 'pressure')
 pm=read(pressure/'build.json');assert pm['revision']==REV and pm['dirty'] is False and pm['profile']=='release'
 assert pm['sources']==m['sources'] and pm['source_tree_sha256']==m['source_tree_sha256']
 assert pm['binary_sha256']==plan['pressure_binary']['sha256']==sha(pressure/'admission-pressure')
 assert pm['command']==['cargo','build','--locked','--release','-p','kv9-server','--example','admission-pressure','--message-format=json-render-diagnostics']
 assert pm['before']==pm['after'] and pm['exit_code']==0
 return {'complete':True,'revision':REV,'source_files':len(m['sources']),'production_default_features':{'server':[],'native':[],'point':[]},'pressure_role':{'kind':'test-only remote read-pressure example','package_features':PRESSURE_FEATURES,'test_harness':False,'database_instantiated':False},'profile':'release','separate_original_builds':True,'server':SERVER,'native':NATIVE,'point':expected['binary_sha256'],'pressure':pm['binary_sha256']}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--plan',type=Path,required=True);args=a.parse_args();print(json.dumps(verify(read(args.plan)),sort_keys=True))
