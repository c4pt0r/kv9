"""Cleanup only the exact archived native matrix namespace; verify every retained process exit."""
import json,subprocess,time,re,hashlib
from pathlib import Path
O=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/cleanup');before=json.loads((O/'before.json').read_text());tree=json.loads((O/'process-tree-before.json').read_text());archive=json.loads(Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/archive-first/result.json').read_text());assert archive['complete'] and archive['all_members_read_back']and archive['all_inputs_rehashed'];assert archive['original_fixture_exit_code']==0;assert Path(archive['archive']).stat().st_size==archive['bytes'];assert hashlib.file_digest(Path(archive['archive']).open('rb'),'sha256').hexdigest()==archive['sha256']
plan=json.loads(Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/plan.json').read_text());ns=before['namespace'];created=json.loads((Path(plan['artifact'])/'owned-namespace-created.json').read_text());assert ns==created['metadata']['name'] and before['namespace_uid']==created['metadata']['uid'] and ns not in plan['preserve_namespaces'];k=['kubectl','--kubeconfig',plan['kubeconfig'],'--request-timeout=10s'];commands=[]
def run(name,args,timeout=30,allow_failure=False):
 started=time.time_ns();p=subprocess.run(args,capture_output=True,text=True,timeout=timeout);row=dict(command=args,started_unix_ns=started,ended_unix_ns=time.time_ns(),exit_code=p.returncode,stdout=name+'.stdout',stderr=name+'.stderr');(O/row['stdout']).write_text(p.stdout);(O/row['stderr']).write_text(p.stderr);commands.append(row);(O/'cleanup-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert allow_failure or p.returncode==0,(args,p.stderr);return p
now=json.loads(run('namespace-identity-recheck',k+['get','namespace',ns,'-o','json']).stdout);assert now['metadata']['uid']==before['namespace_uid'];current=json.loads(run('pods-identity-recheck',k+['get','pods','-n',ns,'-o','json']).stdout)
assert {(p['metadata']['uid'],s['containerID'].removeprefix('containerd://'))for p in current['items']for s in p['status'].get('containerStatuses',[])}=={(r['pod_uid'],r['container'])for r in before['containers']},'owned container set changed since archive'
run('delete-owned-faults',k+['delete','podchaos,networkchaos,iochaos','--all','-n',ns,'--ignore-not-found','--wait=true'],timeout=60)
run('delete-owned-namespace',k+['delete','namespace',ns,'--wait=true'],timeout=90)
nsdoc=json.loads(run('namespaces-after',k+['get','namespaces','-o','json']).stdout);actual={x['metadata']['name']:x['metadata']['uid']for x in nsdoc['items']};assert ns not in actual and actual==plan['preserve_namespaces']
processes=[]
for row in tree['rows']:
 boot=row['stdout'].split('@@BOOT@@\n')[1].split('@@')[0].strip()
 for section in row['stdout'].split('@@PID@@\n')[1:]:
  stat=section.splitlines()[0];pid=int(stat.split(' ',1)[0]);start=int(stat.rsplit(')',1)[1].split()[19]);script='set -e; cat /proc/sys/kernel/random/boot_id; if test -e /proc/"$1"/stat; then cat /proc/"$1"/stat; else printf "absent\\n"; fi';r=run(f'exited-{pid}',['docker','exec',row['node'],'bash','-c',script,'owned-exit',str(pid)]);lines=r.stdout.splitlines();assert lines[0]==boot and lines[1]=='absent',('owned process remains',pid,lines);processes.append(dict(node=row['node'],pid=pid,start_ticks=start,boot_id=boot,absent=True))
containers=[]
for r in before['containers']:
 q=run('container-exit-'+r['container'][:12],['docker','exec',r['node'],'crictl','inspect',r['container']],allow_failure=True)
 if q.returncode==0:
  detail=json.loads(q.stdout);assert detail['status']['state']=='CONTAINER_EXITED' and not detail.get('info',{}).get('pid'),r;state='CONTAINER_EXITED'
 else:assert 'not found'in q.stderr.lower()or'notfound'in q.stderr.lower(),q.stderr;state='removed'
 containers.append(dict(container=r['container'],pod_uid=r['pod_uid'],state=state))
for key in ('fixture_pid','observer_pid'):assert not Path('/proc/'+str(plan[key])).exists()
result=dict(complete=True,namespace=ns,namespace_uid=before['namespace_uid'],namespace_absent=True,precleanup_archive=archive,processes=processes,containers=containers,historical_namespaces_unchanged=actual,fixture_pid=plan['fixture_pid'],observer_pid=plan['observer_pid'],host_fixture_observer_exited=True,commands=commands,completed_unix_ns=time.time_ns(),scope=__doc__,original_fixture_exit_code=0,independent_evidence_accepted=True)
(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ('commands','precleanup_archive','processes','containers')},indent=2))
