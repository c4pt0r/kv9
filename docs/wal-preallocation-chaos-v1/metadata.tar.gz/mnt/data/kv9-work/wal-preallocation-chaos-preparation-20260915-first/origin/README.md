# Upper-bound candidate: full21 Chaos preparation

Exact candidate `e2e23cca5e70a9ea0cc241877b3b35b5b6433d27` uses the existing clean `/tmp/kv9-receipt-upper-bound-20260915-first` source. This is a finite derivative of the accepted `/tmp/kv9-receipt-tail-chaos-preparation-20260915-first` closure. No controls, Cargo, image build, server, fault, codec, cluster mutation or cleanup ran during preparation. No runtime release exists.

The actual standard default release is bound: root session3119/78ef53/0 and independent readback debafc/0, with server SHA `6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49` and same-source native correctness client SHA `44d0f6429fd549fc7d0fac6e71ba67b413a2a8aca0e3e3f0386a64058ac06769`. Ordinary recovery independently passed: session81788/4be379/0, audit e09584/0, 360 complete operations (330 OK/30 unknown), six fresh drains and five server plus two client lifetimes exited. `observed-prerequisites.json` and the audit-terminal resolution bind these original small records. The diagnostic-only release is separate observer evidence and is not deployed in this default-feature Chaos campaign.

Run the arrays in `ROOT-COMMANDS.json` only after root review. All commands use CPUs6–15,22–31 with bytecode disabled and `PYTHONOPTIMIZE=0`:

1. `bind-completed-prerequisites.py` verifies the frozen pending inventory and actual release/recovery results/terminals, then writes fresh `plan.source-recovery.json`, `plan.json`, release/recovery bindings and `inventory.source-recovery.json`. This root metadata gate is prepared but has not run here.
2. `root-runners/run-builds.py` serially builds same-source default `kv9-workload` and the test-only pressure example. Root creates `/tmp/kv9-upper-bound-auxiliary-root-20260915-first` first and retains its actual terminal. Run `root-runners/readback-builds.py` afterward.
3. `bind-builds.py` verifies all four binary/source/Cargo/codegen roles and creates only the exact image context. Root creates `/tmp/kv9-upper-bound-image-root-20260915-first`, then runs `root-runners/run-image.py`: image build, network-disabled payload/loader probe, image inspection, Kind load and CRI readback. Retain the actual terminal and prove the uniquely named probe container absent.
4. Freeze actual prerequisite hashes using `final-preparation/freeze-prerequisites.py`. Supply fresh root coordination and capacity per `final-preparation/required-root-input-schema.json`; run the finalizer command with actual hashes, followed by `overlay/verify-prebuilt.py --plan .../plan.json`.
5. Only root's separate one-use runtime command may set the active launch flag and create `root-runtime-release.json`. After its actual terminal, `root-runners/run-post.py` runs all six ordered phases: independent audit, capture, process-tree readback, full archive/readback, exact-UID cleanup, and all-lifetime readback. Retain first failures without retrying or replacing their outputs.

Fresh root paths are `/tmp/kv9-upper-bound-{auxiliary,image,finalize,chaos}-root-20260915-first`. Image tag is `kv9-chaos:upper-bound-e2e23cca-full21-20260915-first`; probe name is `upper-bound-e2e23cca-full21-image-probe-20260915-first`. All original paths remain historical evidence. Future auxiliary/image/finalization/runtime/post binaries, image IDs, observations and terminal receipts remain pending; no prior values fill those roles.

## What is preserved

All29 source-relative fixture helpers are byte-identical to accepted receipt-tail source; the24 source helper links resolve to this candidate's scripts/history. The55 copied helper files retain every full21 fault, complete-history/unknown-outcome, clock/effect, fresh-drain, feature isolation, archive/readback, UID and lifetime predicate. `origin/` preserves predecessor bytes, `diffs/` gives exact deltas, and `source-delta.json` records the static comparison. Only two Python files differ beyond string substitutions:

- `bind-completed-prerequisites.py`: exact candidate source count1,116 and proof-bound file count13 replace869/12.
- `final-preparation/finalize.py`: proof count13 and the actual root source-gate schema, path-to-SHA strings, replace the old byte/SHA rows. Every actual source-gate SHA must equal the frozen prerequisite SHA and full file digest; the actual byte count must equal the frozen prerequisite length. Source/proof/readiness checks are retained.

All other Python ASTs are identical after replacing string literals for paths, revision, identity hashes and labels. Some inherited audit description text still names earlier source stages; machine source/binary/revision bindings are the candidate's exact values, and no historical acceptance transfers. The schema adaptation was explicitly reviewed by root. Its initial failed authoring attempt and the temporary missing actual audit-terminal observation are preserved; neither was a workload failure or runtime attempt.

Default server/native/point features remain empty. The separately built remote pressure example retains only the accepted testing graph: common/engine testing, Raft testing plus experimental-leader-lease, and all other packages/example empty. The production database receives none of those experimental features. All builds use the existing shared BuildCache lock and inherited descriptors, offline four jobs, actual release opt3/ThinLTO/codegen1/unwind checks and the unchanged source inventories.

Historical control outputs, failed runtime/archive lineage, source repairs, and all original data remain at their original pinned locations. `historical-controls.json` identifies their authority. No passed control is replayed merely to update source counts; historical command arrays are explicitly labeled not to replay. The source-specific binder/finalizer changes require root review, not fabricated new test acceptance.

## Resource and coordination requirements

Storage policy `kv9-upper-bound-chaos-v3` changes the candidate label only. Fresh auxiliary/image and finalizer/runtime launch require **21,483,225,088 bytes** (20 GiB +8 MiB) available; continuous floor is **8,589,934,592 bytes**; maximum sampled decrease is **12,884,901,888 bytes**. Preserve five-second sampling,1,200-second bounds and every existing tmpfs/member/history/archive limit. Use `f_bavail * f_frsize`; never count excluded filesystem blocks.

Runtime and every post phase share the finalizer's original capacity baseline and enforce `max(8 GiB, baseline−12 GiB)`. Raw data, independent copies and full archive coexist within that allowance until verified cleanup. No baseline reset, hidden cold restore, archive omission or changed benchmark policy is introduced. The latest preparation-only snapshot was27,064,975,360 available bytes; it is not a reserved allocation or launch receipt. Recheck after actual auxiliary and image builds.

Fresh coordination must establish no live build, codec, other fixture or timing. The retained old cold terminal proves that historical transaction ended; it does not establish current inactivity. The unchanged Kind cluster/tool/kubeconfig and all eight historical namespace UIDs plus fault identities need fresh read-only verification before finalization. This authoring task made no cluster call and authorizes no mutation of historical resources.

No acceptance beyond the already completed default release/recovery is claimed. Current full21 acceptance remains pending actual auxiliary/image/readback, finalization, one fresh runtime, complete post archive/readback and exact cleanup.
