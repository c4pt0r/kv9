"""Root-only actual release/recovery metadata binding and bounded helper inventory freeze; no ELF reads or execution."""
from pathlib import Path
import copy, hashlib, json, os, re
P=Path(__file__).resolve().parent
BR=Path('/tmp/kv9-upper-bound-release-root-20260915-first')
RR=Path('/tmp/kv9-upper-bound-recovery-root-20260915-first')
RA=Path('/tmp/kv9-upper-bound-recovery-audit-20260915-first')
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 p=Path(p);assert p.stat().st_size<=16*1024**2;return hashlib.sha256(p.read_bytes()).hexdigest()
def row(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def save(n,d):
 with (P/n).open('x')as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
assert __debug__
original=read(P/'inventory.pending.json');entries=copy.deepcopy(original['entries'])
for n,r in entries.items():
 q=P/n
 if 'sha256'in r:assert q.stat().st_size==r['bytes'] and sha(q)==r['sha256'],n
 else:assert q.is_symlink() and os.readlink(q)==r['symlink'] and str(q.resolve())==r['resolved'],n
p=read(P/'plan.pending.json');rev=p['revision'];B=Path(p['server_manifest']['path']).parent
prod=read(BR/'readback-first/result.json');m=read(B/'build.json');native=read(B/'workload/build.json');pre=read(BR/'preflight.json')
assert rev=='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
assert prod['complete'] and prod['revision']==rev and m['revision']==rev and not m['dirty']
assert prod['source_files']==len(m['sources'])==1116 and prod['manifest_sha256']==sha(B/'build.json')==p['server_manifest']['sha256']
assert m['sources']==p['source']==pre['source_snapshot']['sources'] and pre['complete'] and pre['source_root']==p['worktree']
assert pre['proof_bound_files']==13 and pre['reconstructed_parent_driver'] is True
assert native==p['native_client_build'] and native['revision']==rev and not native['dirty']
assert m['source_tree_sha256']==prod['source_tree_sha256']==native['source_tree_sha256']==p['source_tree_sha256']
assert prod['server_sha256']==p['production_binary']['sha256']=='6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49'
assert native['binary_sha256']==prod['workload_sha256']=='44d0f6429fd549fc7d0fac6e71ba67b413a2a8aca0e3e3f0386a64058ac06769'
for q in [BR/'terminal.json',RR/'terminal.json']:
 t=read(q);assert t['complete'] and type(t['exit_code'])is int and t['exit_code']==0
 assert type(t['session_id'])is int and t['session_id']>0 and re.fullmatch(r'[0-9a-f]{6,}',t['terminal_receipt'])
 assert sha(t['result_path'])==t['result_sha256'] and read(t['result_path'])['complete']
audit=read(RA/'audit.json');at=read(RA/'tool-terminal.json')
assert at['complete'] is True and type(at['exit_code'])is int and at['exit_code']==0
assert re.fullmatch(r'[0-9a-f]{6,}',at['chunk_id']) and at['result_sha256']==sha(RA/'audit.json')
assert audit['complete'] and audit['accepted'] and audit['revision']==rev
assert audit['source_unchanged'] and audit['original_inputs_unchanged'] and audit['owned_lifetimes_exited']
assert audit['server_sha256']==prod['server_sha256'] and audit['client_sha256']==prod['workload_sha256']
for x in p['ordinary_recovery'].values():x.update(row(x['path']))
p['scope']='Exact upper-bound e2e23cca release/source/proof and ordinary recovery independently accepted. All21 original fault/history/clock/feature/archive/cleanup predicates preserved; current auxiliary/image/finalization/Chaos acceptance remains separate.'
p['pending_inputs']=p['pending_inputs'][1:]
save('plan.source-recovery.json',p);save('plan.json',p)
save('release-binding.json',dict(complete=True,runtime_ready=False,revision=rev,source_files=len(m['sources']),source_tree_sha256=m['source_tree_sha256'],server_sha256=prod['server_sha256'],native_sha256=prod['workload_sha256'],manifest_sha256=prod['manifest_sha256'],root_readback=row(BR/'readback-first/result.json'),root_terminal=row(BR/'terminal.json'),source_proof_preflight=row(BR/'preflight.json'),scope='Original root metadata acceptance pinned; no retained ELF execution or byte hashing by this binder.'))
save('recovery-binding.final.json',dict(complete=True,runtime_ready=False,revision=rev,operations=sum(c['operations']for c in audit['cases']),outcomes={k:sum(c['outcomes'].get(k,0)for c in audit['cases'])for k in ['ok','unknown']},fresh_drains=sum(c['fresh_drained_voters']for c in audit['cases']),server_lifetimes=audit['server_lifetimes'],client_lifetimes=audit['client_lifetimes'],all_owned_exited=audit['owned_lifetimes_exited'],input_pins=p['ordinary_recovery'],terminals=dict(process=read(RR/'terminal.json'),audit=at)))
inputs=read(P/'input-bindings.pending.json')
for q in [BR/'readback-first/result.json',BR/'terminal.json',BR/'source-result.json',B/'build.json',B/'cache-safety.json',B/'workload/build.json',B/'workload/sources.json',B/'kv9-build.log',B/'workload/build.log',RR/'terminal.json',RA/'tool-terminal.json',RR/'source-result.json',RA/'audit.json']:
 inputs[str(q)]={k:v for k,v in row(q).items()if k!='path'}
save('input-bindings.json',inputs)
for n in ['plan.source-recovery.json','plan.json','release-binding.json','recovery-binding.final.json','input-bindings.json']:
 entries[n]=dict(bytes=(P/n).stat().st_size,sha256=sha(P/n))
total=sum(x.get('bytes',0)for x in entries.values());assert total<=16*1024**2
save('inventory.source-recovery.json',dict(complete=True,preparation_only=True,runtime_ready=False,entries=entries,regular_bytes=total,scope='Exact authored helpers plus actual source/recovery bindings. Future build/image/fixture outputs excluded.'))
print(json.dumps(dict(complete=True,release=True,recovery=True,source_files=len(m['sources']),runtime_ready=False,inventory_sha256=sha(P/'inventory.source-recovery.json'),plan_sha256=sha(P/'plan.source-recovery.json'))))
