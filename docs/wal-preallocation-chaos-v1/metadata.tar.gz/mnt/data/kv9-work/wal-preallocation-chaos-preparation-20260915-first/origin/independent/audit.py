"""Independent exact-source additive native batch Chaos acceptance; original run artifacts stay unchanged."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json, subprocess, shutil, time, re, importlib.util, os
A=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/independent');P=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first');p=json.loads((P/'plan.json').read_text());raw=Path(p['artifact']);tree=Path(p['worktree']);I=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/independent-copy-first');O=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/overlay');commands=[]
def read(path):return json.loads(Path(path).read_text())
def digest(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,obj):(A/name).write_text(json.dumps(obj,indent=2)+'\n')
def run(name,args,cwd=tree):
 start=time.time_ns();q=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=120);(A/(name+'.stdout')).write_text(q.stdout);(A/(name+'.stderr')).write_text(q.stderr);row=dict(name=name,command=args,cwd=str(cwd),started_unix_ns=start,ended_unix_ns=time.time_ns(),exit_code=q.returncode);commands.append(row);write('commands.json',commands);assert q.returncode==0,(name,q.returncode,q.stderr[-1500:]);return q.stdout
assert p['fixture_exit_code']==0 and p['observer_exit_code']==0
assert read(raw/'native-window-audit.json')['accepted'] is True
timestamp_control=p['readiness']['preflights']['timestamp-controls']
assert timestamp_control=={'count': 14, 'path': '/tmp/kv9-release-thin-lto-full-chaos-preparation-first/independent/timestamp-controls/summary.json', 'sha256': 'a3e0256e39be826b36da5cdc8e1b67c2b3f745cebe15798402221872b045886f'}
assert digest(timestamp_control['path'])==timestamp_control['sha256'] and read(timestamp_control['path'])['accepted']
assert digest(A/'native-window-readback-v2.py')=='ae4db1aba2b0006757e72fd1b09f7860ec397300e4fe05a8cb30895a67da307d'
assert digest(P/'ready-plan.json')==p['ready_plan_sha256']
log=(P/'matrix.log').read_text().splitlines();assert log[-1]=='COMMAND_EXIT=0' and not any('ValueError: physical observation timestamp malformed'==x for x in log)
assert not run('git-status',['git','status','--porcelain']);assert run('git-head',['git','rev-parse','HEAD']).strip()==p['revision']
for rel,h in p['source'].items():assert digest(tree/rel)==h,rel
for name,h in p['overlay_inputs'].items():
 assert digest(name)==h,name
 assert digest(raw/'owned-native-batch-overlay'/Path(name).relative_to(O))==h,name
for name,target in p['overlay_helper_links'].items():
 assert Path(name).is_symlink() and str(Path(name).resolve())==target
 assert (raw/'owned-native-batch-overlay'/Path(name).relative_to(O)).is_symlink()
 assert str((raw/'owned-native-batch-overlay'/Path(name).relative_to(O)).resolve())==target
runtime_difference=run('runtime-difference',['git','diff','--name-only',p['runtime_revision'],p['revision']]).splitlines()
run('original-build-binding',['python3',str(P/'check-build-binding.py'),'--plan',str(P/'plan.json')])
for path,target_names in [(Path(p['server_cargo_path']),['kv9','kv9_engine','kv9_raft','kv9_server']),(raw/'persistent-build/cargo.jsonl',['kv9-workload','kv9_engine','kv9_raft','kv9_server']),(raw/'native-build/cargo.jsonl',['kv9-batch-workload','kv9_engine','kv9_raft','kv9_server'])]:
 rows=[json.loads(x) for x in path.read_text().splitlines()];assert rows[-1]['reason']=='build-finished' and rows[-1]['success'] is True
 for name in target_names:
  found=[x for x in rows if x['reason']=='compiler-artifact' and x['target']['name']==name];assert len(found)==1 and found[0]['features']==[] and found[0]['profile']['test'] is False,(path,name)
client=read(P/'point-live-client-identity.json');assert client['complete'] and client['executing_sha256']==p['correctness_client_build']['binary_sha256'];assert client['configuration']==read(raw/'persistent-config.json');assert client['configuration']['rpc_transport']=='tonic_stream';assert all(int(x[2].split(':')[1],16)==20160 for x in client['connections'])
report=read(raw/'persistent-run/report.json');assert report['version']==2 and report['complete'] and report['failure'] is None;assert report['configuration']==client['configuration'];assert report['build']==p['correctness_client_build']==read(raw/'persistent-build/build.json');assert report['process_id']==client['process_pid']
image=read(P/'image-inspect.stdout')[0];assert image['Id']==p['prepared_image']['docker_image_id'];current_image=json.loads(run('image-readback',['docker','image','inspect',p['image']]))[0];assert current_image['Id']==image['Id']
mapping=json.loads(run('cri-readback',['docker','exec',p['kind_cluster']+'-control-plane','crictl','inspecti',image['Id']]));assert mapping==client['cri_image_mapping'];assert mapping['status']['id']==image['Id'] and 'docker.io/library/'+p['image'] in mapping['status']['repoTags']
payload=run('image-payload-readback',['docker','run','--rm','--name','receipt-tail-a6ac335-full21-independent-payload-20260915-first','--cpuset-cpus','6-15,22-31','--network','none','--entrypoint','sha256sum',p['image'],*p['prepared_image']['hashes']]);hashes={x.split(None,1)[1].strip():x.split()[0] for x in payload.splitlines()};assert hashes==p['prepared_image']['hashes']
assert digest(p['production_binary']['path'])==hashes['/usr/local/bin/kv9'];assert digest(p['pressure_binary']['path'])==hashes['/usr/local/bin/admission-pressure'];assert digest(raw/'persistent-build/kv9-workload')==hashes['/usr/local/bin/kv9-workload']
for name,h in p['context_files'].items():assert digest(Path(p['context'])/name)==h,name
live=read(raw/'async-write-live-observer.json');assert live['complete'] and client['namespace']==live['namespace'];matched=[r for o in live['observations'] for r in o['rows'] if r.get('identity_matched')];assert {'1','2','3','4'}<={r['node'] for r in matched}
for row in matched:
 assert row['status_contract_valid'] is True
 for status in row['container_statuses']:assert status['imageID'] in mapping['status']['repoDigests']
 assert hashes['/usr/local/bin/kv9']+f'  /proc/{row["process_pid"]}/exe' in row['stdout'];assert hashes['/usr/local/bin/kv9']+'  /usr/local/bin/kv9' in row['stdout']
nsdoc=json.loads(run('namespaces-after',['kubectl','--kubeconfig',p['kubeconfig'],'get','namespaces','-o','json']));names={x['metadata']['name']:x['metadata']['uid'] for x in nsdoc['items']};assert live['namespace'] in names, 'successful fixture namespace must be retained before readback archive'
namespace_uid=names[live['namespace']]
created=read(raw/'owned-namespace-created.json')
assert created['metadata']['name']==live['namespace'] and created['metadata']['uid']==namespace_uid
assert read(raw/'cleanup-pending-namespace.json')['metadata']['uid']==namespace_uid
for name,uid in p['preserve_namespaces'].items():assert names[name]==uid,name
for key in ['fixture_pid','observer_pid']:assert not Path('/proc/'+str(p[key])).exists(),key
assert p['fixture_command']==['taskset','-c','6-15,22-31','bash',str(O/'scripts/chaos-mesh-e2e.sh')]
write('identity.json',dict(complete=True,revision=p['revision'],runtime_revision=p['runtime_revision'],source_files=len(p['source']),source_tree_sha256=p['source_tree_sha256'],source_unchanged=True,normal_features=[],image_id=image['Id'],cri_mapping=mapping,image_hashes=hashes,client=client,namespace_retained=live['namespace'],namespace_uid=namespace_uid,preserved_namespaces=p['preserve_namespaces'],owned_host_fixture_observer_collectors_exited=True))
workflow=(tree/'.github/workflows/correctness.yml').read_text();block=workflow.split('      - name: Run and verify the Chaos Mesh acceptance matrix\n',1)[1].split('      - name: Collect cluster diagnostics',1)[0]
markers=re.findall(r"grep -Fxc '([^']+)'",block)
assert markers, 'CI marker contract missing'
for marker in markers:assert log.count(marker)==1,marker
phases=['registration-seed-blackhole','pod-failure-1','pod-failure-2','pod-failure-3','partition','public-admission-overload','delay']+[f'io-voter-{n}-errno-{e}' for n in (1,2,3) for e in (5,28)]+[f'store-loss-voter-{n}-{k}' for k in ('log-missing','pvc-replacement') for n in (1,2,3)]+['endpoint-migration-pending','endpoint-migration-recovered'];assert len(phases)==len(set(phases))==21
for phase in phases:
 for cli in ('concurrent','persistent'):assert log.count(f'PASS: {cli} put and read completed during {phase}')==1,(phase,cli)
for n in (1,2,3):
 for e in (5,28):assert log.count(f'PASS: IOChaos voter {n} errno {e} reached Raft, exited, and recovered with majority service')==1
excluded=['persistent-evidence-controls','persistent-history-checker.json','native-window-audit.json'];shutil.copytree(raw,I,symlinks=True,ignore=lambda directory,names:excluded if Path(directory)==raw else [])
run('persistent-history',['python3','scripts/check-persistent-chaos.py',str(I),'--expected-revision',p['revision']])
run('cli-history',['python3','scripts/history/checker.py',str(I/'history.jsonl'),'--output',str(I/'independent-history-checker.json'),'--acceptance','--require','put','get','delete','scan','delete_range','create_keyspace','--seconds','60','--require-phase',*phases])
assert read(raw/'history-checker.json')['verdict']==read(I/'independent-history-checker.json')['verdict']=='valid';shutil.copy2(I/'independent-history-checker.json',I/'history-checker.json')
for name,args in [('formation',[]),('store-loss',[]),('store-replacement',[]),('endpoint-migration',[]),('latency-metrics',[]),('admission-pressure',['--self-test'])]:
 script='scripts/check-'+name+('-chaos' if name in ['formation','store-loss','store-replacement','endpoint-migration'] else '')+'.py';run(name,['python3',script,str(I),*args])
for name in ['inline-audit','apply-audit','delay-audit']:run(name,['python3',str(A/(name+'.py'))])
run('native-windows',['python3',str(A/'native-window-readback-v2.py'),'--plan',str(P/'plan.json'),'--artifact',str(I)])
native=read(I/'native-window-audit.json');assert native['accepted'] and len(native['windows'])==22 and len(native['final_drain']['writers'])==4
# The new fixture explicitly captured fresh final drains before cleanup.
write('fresh-final-drain.json',native['final_drain'])
histories={};outcomes={}
for name,rel in [('cli','history.jsonl'),('persistent','persistent-run/history.jsonl'),('native','native-run/history.jsonl')]:
 assert (raw/rel).read_bytes()==(I/rel).read_bytes();events=[json.loads(x) for x in (raw/rel).read_text().splitlines()];inv={x['id']:x for x in events if x.get('type')=='invoke'};ret=[x for x in events if x.get('type')=='return'];assert len(inv)==len(ret);counts=Counter();totals=Counter()
 for event in ret:
  call=inv[event['id']];reason=(event.get('observation') or {}).get('reason');counts[(call['op'],call.get('phase',''),event['outcome'],json.dumps(reason,sort_keys=True))]+=1;totals[event['outcome']]+=1
 histories[name]=dict(sha256=digest(raw/rel),bytes=(raw/rel).stat().st_size,invokes=len(inv),returns=len(ret),outcomes=dict(totals));outcomes[name]=[dict(op=k[0],phase=k[1],outcome=k[2],reason=json.loads(k[3]),count=v) for k,v in sorted(counts.items())]
write('outcomes.json',outcomes)
preflights=p['readiness']['preflights']
for name,row in preflights.items():
 assert digest(row['path'])==row['sha256']
assert sum(preflights[n]['count']for n in ('probe-check','fields-check','gate-check','freshness-check'))==43
assert preflights['native-check-final']['count']==18 and preflights['config-drain-check']['count']==24
manifest={}
for path in sorted(raw.rglob('*')):
 if path.is_symlink():manifest[str(path.relative_to(raw))]=dict(symlink=os.readlink(path),resolved=str(path.resolve()))
 elif path.is_file():manifest[str(path.relative_to(raw))]=dict(bytes=path.stat().st_size,sha256=digest(path))
write('raw-manifest.json',dict(root=str(raw),entries=manifest))
result=dict(complete=True,accepted=True,evidence_accepted=True,original_harness_exit_code=0,original_harness_complete=True,prospective_timestamp_repair=read(P/'timestamp-repair.json'),cleanup_complete=False,namespace_retained_for_archive=live['namespace'],observed_unix_ns=time.time_ns(),revision=p['revision'],runtime_revision=p['runtime_revision'],windows=phases,histories=histories,native=native,namespace=live['namespace'],image_id=image['Id'],binary_sha256=hashes['/usr/local/bin/kv9'],client_sha256=hashes['/usr/local/bin/kv9-workload'],native_client_sha256=hashes['/usr/local/bin/kv9-batch-workload'],source_files=len(p['source']),source_tree_sha256=p['source_tree_sha256'],source_unchanged=True,runtime_difference=runtime_difference,markers=len(markers),observer_batches=len(live['observations']),accepted_runtime_samples=len(matched),observed_cpu_masks=sorted({r['cpu_allowed']for r in matched}),preflight_controls=preflights,independent_copy=str(I),independent_commands=commands,excluded_generated_outputs=excluded,raw_files=sum('sha256'in x for x in manifest.values()),raw_symlinks=sum('symlink'in x for x in manifest.values()),raw_bytes=sum(x.get('bytes',0)for x in manifest.values()),fresh_final_drained_replicas=4,scope='Exact clean a6ac335 default-feature release server, ordinary-port tonic_stream point and native atomic batch clients, plus original CLI/catalog histories. Original 21 actual voter/storage/endpoint Chaos windows and effects; independent complete histories, source/executable/process identity and fresh final drains. Dedicated client-link/quorum acceptance, performance, cross-host, power-loss and whole-Rust proof are separate.')
write('audit.json',result);print(json.dumps({k:v for k,v in result.items()if k not in ('native','independent_commands','preflight_controls')},sort_keys=True))
