from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
paths={'config-drain-check':P/'overlay/preflight/config-drain-check/summary.json','fields-check':P/'overlay/preflight/fields-check/result.json','freshness-check':P/'overlay/preflight/freshness-check/result.json','gate-check':P/'overlay/preflight/gate-check/result.json','native-check-final':P/'overlay/preflight/native-check-image-independent-first/summary.json','probe-check':P/'overlay/preflight/probe-check/result.json','timestamp-controls':P/'independent/timestamp-controls/summary.json'}
for n in ['delay-selection-regressions','pressure-role','cleanup-retention']:paths[n]=P/'fresh-contract-controls'/n/'result.json'
preflights={}
for name,path in paths.items():
 x=read(path);assert x.get('complete',x.get('accepted'))is True
 rows=x.get('cases',x.get('checks',x.get('synthetic_controls',x.get('controls'))));count=len(rows)
 preflights[name]={'count':count,'path':str(path),'sha256':h(path),'qualification':'fresh current helper qualification, not restored historical receipt'}
for n in ['plan.pending.json','plan.source-recovery.json','plan.json']:
 q=P/n;shutil.copy2(q,P/'origin'/('before-fresh-'+n));p=read(q);p['readiness']['preflights']=preflights
 p['derivative_lineage']['historical_deleted_repair_path']=p['derivative_lineage']['repair_path'];p['derivative_lineage']['repair_path']=str(P/'historical-lineage')
 write(q,p)
# Same original native reader, path-only derivative: retain actual current reader and synthetic clock-control pins.
f=P/'independent/audit.py';t=f.read_text();a=t.index('assert timestamp_control==');b=t.index('\nassert digest(timestamp_control',a);t=t[:a]+f'assert timestamp_control=={preflights["timestamp-controls"]!r}'+t[b:]
t=t.replace('ae4db1aba2b0006757e72fd1b09f7860ec397300e4fe05a8cb30895a67da307d',h(P/'independent/native-window-readback-v2.py'));f.write_text(t)
f=P/'final-preparation/finalize.py';t=f.read_text();t=t.replace("    ap.add_argument('--cold-terminal',type=Path,required=True)\n",'').replace("    ap.add_argument('--cold-terminal-sha256',required=True)\n",'')
t=t.replace("    # Cold work must actually be terminal; root separately supplies fresh coordination.\n    cold=checked(args.cold_terminal,args.cold_terminal_sha256); terminal(cold)\n", "    # Root selected fresh current coordination: the historical cold transaction is no longer concurrent.\n")
t=t.replace("    assert coordination['cold_terminal']==bind(args.cold_terminal)\n",'')
t=t.replace('cold_terminal=bind(args.cold_terminal),','')
f.write_text(t)
cmd=read(P/'final-preparation/commands.json');argv=cmd['finalize_after_cold_terminal_and_root_review'];i=argv.index('--cold-terminal');del argv[i:i+4];cmd['finalize_after_fresh_coordination_and_root_review']=argv;del cmd['finalize_after_cold_terminal_and_root_review']
cmd['fresh_coordination_and_capacity']=['env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','taskset','-c','6-15,22-31','python3',str(P/'fresh-preflight.py'),'--output',str(P/'roots/finalize/coordination.json'),'--capacity-output',str(P/'roots/finalize/capacity.json')]
write(P/'final-preparation/commands.json',cmd)
H=P/'historical-lineage';H.mkdir();shutil.copy2(P/'historical-controls.json',H/'historical-controls.json')
old=Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first')
for src,name in [(old/'independent/audit.json','upper-bound-audit.json'),(old/'archive-first/result.json','upper-bound-full-archive-authority.json'),(old.parent/'kv9-upper-bound-chaos-root-20260915-first/terminal.json','upper-bound-runtime-terminal.json'),(old.parent/'kv9-upper-bound-chaos-root-20260915-first/post-terminal.json','upper-bound-post-terminal.json')]:shutil.copy2(src,H/name)
(H/'README.md').write_text('Historical controls/failure references are preserved here. Several original control receipt/sample directories are no longer present; fresh current helper qualification replaces those live prerequisites explicitly. The old full-archive authority and accepted upper-bound audit remain distinct from this unrun candidate. No historical full payload is claimed newly restored.\n')
write(P/'fresh-qualification.json',{'complete':True,'actual_tool_terminal':'a529f0','exit_code':0,'groups':preflights,'total_controls':sum(x['count']for x in preflights.values()),'focused_binding_controls':{'first_result':str(P/'controls-first/result.json'),'first_terminal':'531a6a/1','seven_methods_passed':True,'failed_method':'proof mapping/list fixture','corrected_method_result':str(P/'fresh-qualification-first/result.json'),'actual_corrected_terminal':'a529f0/0'},'historical_receipts_restored':False,'runtime_launched':False})
for n in ['plan.pending.json','plan.source-recovery.json','plan.json']:
 p=read(P/n);p['overlay_inputs']={str(q):h(q)for q in map(Path,p['overlay_inputs'])};write(P/n,p)
print(json.dumps({'fresh_groups':{k:v['count']for k,v in preflights.items()},'total':sum(x['count']for x in preflights.values())}))
