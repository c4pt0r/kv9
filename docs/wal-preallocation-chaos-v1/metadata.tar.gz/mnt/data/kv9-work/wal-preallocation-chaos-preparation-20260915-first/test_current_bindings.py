"""Focused metadata controls for new feature, current proof and dual-device budget bindings only."""
from pathlib import Path
import copy,importlib.util,json,unittest,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P))
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('binding',P/'check-build-binding.py');q=load('prerequisite',P/'prerequisites.py');g=load('space',P/'space_guard.py')
B=q.B

def rows(path):return [x for s in path.read_text().splitlines()if (x:=json.loads(s)).get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file://'+str(q.S))]
class Controls(unittest.TestCase):
 def test_actual_server_and_missing_or_extra_features(self):
  r=rows(B/'build/preallocated/kv9-cargo.jsonl');b.feature_check(r,'server')
  for package,feature in [('kv9',[]),('kv9-engine',[]),('kv9-raft',['wal-payload-preallocation']),('kv9-server',['testing']),('kv9-engine',['wal-payload-preallocation','testing'])]:
   x=copy.deepcopy(r);next(v for v in x if v['package_id'].rsplit('#',1)[-1].split('@')[0]==package)['features']=feature
   with self.subTest(package=package,feature=feature),self.assertRaises(AssertionError):b.feature_check(x,'server')
 def test_actual_default_clients_and_pressure_are_distinct(self):
  for role,path in [('native',B/'correctness-client/cargo.jsonl'),('point',P/'persistent-build-second/cargo.jsonl'),('pressure',P/'pressure-build-first/cargo.jsonl')]:
   r=rows(path);b.feature_check(r,role);x=copy.deepcopy(r);x[0]['features'].append('wal-payload-preallocation')
   with self.subTest(role=role),self.assertRaises(AssertionError):b.feature_check(x,role)
 def test_actual_two_variant_cache_and_readback(self):b.verify_server(json.loads((P/'plan.pending.json').read_text()))
 def test_actual_current_source_proof_and_recovery_authorities(self):self.assertTrue(q.verify(json.loads((P/'plan.pending.json').read_text()))['complete'])
 def test_proof_incomplete_missing_theorem_or_accepted_mutant_rejected(self):
  for d,n,c in [('capacity-proof-first',11,7),('crc-proof-first',47,8)]:
   r=q.read(q.D/d/'result.json');q.proof_result(r,n,c)
   for case in range(4):
    x=copy.deepcopy(r)
    if case==0:x['complete']=False
    elif case==1:x['accepted']=False
    elif case==2:
     if isinstance(x['theorems'],dict):x['theorems'].pop(next(iter(x['theorems'])))
     else:x['theorems']=x['theorems'][:-1]
    else:x['controls'][0]['rejected']=False
    with self.subTest(proof=d,case=case),self.assertRaises(AssertionError):q.proof_result(x,n,c)
 def test_dual_device_equality_and_one_byte_below(self):
  floor=g.POLICY['minimum_available_bytes'];base={str(n):{'device':n,'available_bytes':floor}for n in [1,2]};self.assertEqual(g.check(base,base),floor)
  bad=copy.deepcopy(base);bad['2']['available_bytes']-=1
  with self.assertRaises(AssertionError):g.check(bad,base)
 def test_combined_decline_and_device_continuity(self):
  cap=g.POLICY['maximum_additional_build_image_archive_bytes'];base={str(n):{'device':n,'available_bytes':10*cap}for n in [1,2]};cur=copy.deepcopy(base)
  for x in cur.values():x['available_bytes']-=cap//2
  g.check(cur,base);cur['2']['available_bytes']-=1
  with self.assertRaises(AssertionError):g.check(cur,base)
  bad=copy.deepcopy(base);bad['2']['device']=3
  with self.assertRaises(AssertionError):g.check(bad,base)
 def test_each_launch_filesystem_floor(self):
  f=g.POLICY['preflight_minimum_available_bytes'];base={str(n):{'device':n,'available_bytes':f}for n in [1,2]};g.check(base,base,True)
  bad=copy.deepcopy(base);bad['2']['available_bytes']-=1
  with self.assertRaises(AssertionError):g.check(bad,base,True)
if __name__=='__main__':unittest.main(verbosity=2)
