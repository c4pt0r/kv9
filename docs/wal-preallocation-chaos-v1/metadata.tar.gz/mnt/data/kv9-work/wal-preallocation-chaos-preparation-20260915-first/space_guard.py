"""Observe distinct root/output filesystems; preserve original floor and combined decrease cap."""
import os
from pathlib import Path
from storage_policy import POLICY,check_launch,integer
OUTPUT=Path(__file__).resolve().parent

def snapshot():
    rows={}
    for p in (Path('/'),OUTPUT):
        st=p.stat();v=os.statvfs(p);key=str(st.st_dev)
        if key not in rows:rows[key]={'device':st.st_dev,'path':str(p),'available_bytes':v.f_bavail*v.f_frsize}
    return rows

def check(current,baseline,launch=False):
    assert set(current)==set(baseline),'filesystem devices changed'
    decline=0
    for key,b in baseline.items():
        c=current[key];assert type(c['device'])is int and c['device']==b['device'] and str(c['device'])==key
        integer(c['available_bytes']);integer(b['available_bytes'])
        if launch:check_launch(c['available_bytes'])
        assert c['available_bytes']>=POLICY['minimum_available_bytes'],'root/output available floor'
        decline+=max(0,b['available_bytes']-c['available_bytes'])
    assert decline<=POLICY['maximum_additional_build_image_archive_bytes'],'combined root/output decrease cap'
    return min(c['available_bytes']for c in current.values())

class Guard:
    def __init__(self,baseline=None,launch=False):
        self.baseline=snapshot()if baseline is None else baseline
        self.last=None;self.observe(launch)
    def observe(self,launch=False):
        self.last=snapshot();return check(self.last,self.baseline,launch)
