"""Finite fresh helper qualification. Stops at the first failure; original outputs remain."""
from pathlib import Path
import hashlib,json,subprocess,time
P=Path(__file__).resolve().parent;O=P/'fresh-qualification-first';O.mkdir(exist_ok=False)
commands=[['python3',str(P/'test_current_bindings.py'),'Controls.test_proof_incomplete_missing_theorem_or_accepted_mutant_rejected']]
commands += [['python3',str(P/'overlay/preflight'/name)]for name in ['probe-check.py','fields-check.py','gate-check.py','freshness-check.py','config-drain-check.py','native-check-final.py']]
commands += [['python3',str(P/'independent/timestamp-controls.py')],['python3',str(P/'fresh-contract-controls.py')]]
r={'complete':False,'scope':'New source/preflight qualification after historical receipt loss. No prior run restored and no database/Chaos workload. Probe/fields controls own short sleep processes.','commands':[],'started_ns':time.time_ns()}
try:
 for i,argv in enumerate(commands):
  start=time.time_ns();q=subprocess.run(argv,capture_output=True,timeout=120);(O/f'{i:02d}.stdout').write_bytes(q.stdout);(O/f'{i:02d}.stderr').write_bytes(q.stderr)
  row={'argv':argv,'exit_code':q.returncode,'started_ns':start,'ended_ns':time.time_ns(),'source_sha256':hashlib.sha256(Path(argv[1]).read_bytes()).hexdigest()};r['commands'].append(row)
  print(json.dumps(row),flush=True)
  if q.returncode:print(q.stderr.decode(errors='replace'),flush=True);raise RuntimeError('fresh control failed: '+str(i))
 r['complete']=True
finally:
 r['ended_ns']=time.time_ns();(O/'result.json').write_text(json.dumps(r,indent=2)+'\n')
