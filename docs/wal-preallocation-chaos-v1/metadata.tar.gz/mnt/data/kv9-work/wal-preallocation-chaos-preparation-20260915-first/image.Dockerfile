FROM ubuntu@sha256:224a1869083a311ef3f13648a154ba79832fbef6364d31493642ca03082da254 AS fixture-builder
RUN apt-get update && apt-get install -y --no-install-recommends gcc libc6-dev \
    && rm -rf /var/lib/apt/lists/*
COPY no-statx.c /tmp/no-statx.c
RUN gcc -O2 -Wall -Wextra -Werror /tmp/no-statx.c -o /usr/local/bin/no-statx \
    && gcc --version > /tmp/launcher-toolchain.txt \
    && dpkg-query -W gcc libc6-dev libc6 >> /tmp/launcher-toolchain.txt
FROM ubuntu@sha256:224a1869083a311ef3f13648a154ba79832fbef6364d31493642ca03082da254
COPY kv9 admission-pressure kv9-workload kv9-batch-workload /usr/local/bin/
COPY point-build.json /opt/kv9-workload/build.json
COPY native-build.json /opt/kv9-batch-workload/build.json
COPY --from=fixture-builder /usr/local/bin/no-statx /usr/local/bin/no-statx
COPY --from=fixture-builder /tmp/launcher-toolchain.txt /opt/launcher-toolchain.txt
RUN chmod 0755 /usr/local/bin/kv9 /usr/local/bin/admission-pressure /usr/local/bin/kv9-workload /usr/local/bin/kv9-batch-workload /usr/local/bin/no-statx \
    && chmod 0644 /opt/kv9-workload/build.json /opt/kv9-batch-workload/build.json /opt/launcher-toolchain.txt
ENTRYPOINT ["/usr/local/bin/kv9"]
