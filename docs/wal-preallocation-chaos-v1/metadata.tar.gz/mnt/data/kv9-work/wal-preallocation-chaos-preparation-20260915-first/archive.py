"""Freeze, archive and independently read back current native Chaos evidence before cleanup."""
import hashlib,json,os,tarfile,time
from pathlib import Path
R=Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first');plan=json.loads((R/'plan.json').read_text());accepted=json.loads((R/'independent/audit.json').read_text())
assert plan['fixture_exit_code']==0 and plan['observer_exit_code']==0 and accepted['accepted']
ROOTS=[Path(plan['artifact']),R,Path(plan['server_manifest']['path']).parent,Path(plan['point_build_directory']),Path(plan['pressure_manifest_path']).parent,Path(plan['context']),Path(plan['derivative_lineage']['repair_path'])]
OUT=R/'archive-first';OUT.mkdir(exist_ok=False)
ARCHIVE=OUT/'evidence.tar.gz';RESULT=OUT/'result.json';INVENTORY=OUT/'inventory.json'
def sha(path):
 with path.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
started=time.time_ns();files={};members={}
for root in ROOTS:
 for path in [root,*sorted(root.rglob('*'))]:
  if '__pycache__'in path.parts or path==OUT or path.is_relative_to(OUT) or path==R/'roots' or path.is_relative_to(R/'roots'):continue
  name=str(path).removeprefix('/')
  if path.is_symlink():members[name]=dict(type='symlink',target=os.readlink(path))
  elif path.is_file():members[name]=dict(type='file',bytes=path.stat().st_size,sha256=sha(path));files[name]=path
  elif path.is_dir():members[name]=dict(type='directory')
INVENTORY.write_text(json.dumps(dict(roots=[str(x)for x in ROOTS],members=members),indent=2)+'\n');print('Manifest frozen:',len(members),'members',flush=True)
with tarfile.open(ARCHIVE,'w:gz',compresslevel=1,dereference=False)as archive:
 for name in sorted(members):archive.add('/'+name,arcname=name,recursive=False)
 archive.add(INVENTORY,arcname=INVENTORY.name,recursive=False)
print('Archive written:',ARCHIVE.stat().st_size,'bytes',flush=True)
seen={}
with tarfile.open(ARCHIVE,'r|gz')as archive:
 for member in archive:
  if member.name==INVENTORY.name:
   assert member.isfile()and hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==sha(INVENTORY);continue
  assert member.name in members and member.name not in seen,member.name;expected=members[member.name]
  if member.isfile():assert expected['type']=='file'and member.size==expected['bytes']and hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==expected['sha256'],member.name
  elif member.issym():assert expected==dict(type='symlink',target=member.linkname),member.name
  else:assert member.isdir()and expected['type']=='directory',member.name
  seen[member.name]=True
assert set(seen)==set(members)
for name,path in files.items():assert sha(path)==members[name]['sha256'],('input changed during archive',name)
result=dict(complete=True,archive=str(ARCHIVE),bytes=ARCHIVE.stat().st_size,sha256=sha(ARCHIVE),inventory=str(INVENTORY),inventory_sha256=sha(INVENTORY),members=len(members)+1,files=len(files),file_bytes=sum(v.get('bytes',0)for v in members.values()),roots=[str(x)for x in ROOTS],all_members_read_back=True,all_inputs_rehashed=True,started_unix_ns=started,ended_unix_ns=time.time_ns(),scope=__doc__,outer_root_logs_retained_separately=str(R/'roots'),original_fixture_exit_code=0,independent_retained_evidence_accepted=True,cleanup_in_separate_supplement=True);RESULT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
