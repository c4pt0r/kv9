import concurrent.futures,hashlib,json,os,subprocess,time
from pathlib import Path
R=Path(__file__).parent; O=R/'environment-first'; O.mkdir()
k=['kubectl','--kubeconfig','/mnt/data/kv9-work/chaos-tools-20260915-first/kubeconfig','--request-timeout=10s']
commands={
'context':k+['config','current-context'],
'kind-clusters':['/mnt/data/kv9-work/chaos-tools-20260915-first/kind','get','clusters'],
'kind-nodes':['/mnt/data/kv9-work/chaos-tools-20260915-first/kind','get','nodes','--name','kv9-chaos-ci-p0-20260908'],
'nodes':k+['get','nodes','-o','json'],
'namespaces':k+['get','namespaces','-o','json'],
'pods':k+['get','pods','-A','-o','custom-columns=NAMESPACE:.metadata.namespace,NAME:.metadata.name,UID:.metadata.uid,PHASE:.status.phase,READY:.status.containerStatuses[*].ready,RESTARTS:.status.containerStatuses[*].restartCount,IMAGEID:.status.containerStatuses[*].imageID'],
'faults':k+['get','podchaos,networkchaos,iochaos','-A','-o','json'],
'crds':k+['get','crd','podchaos.chaos-mesh.org','networkchaos.chaos-mesh.org','iochaos.chaos-mesh.org','-o','json'],
'docker-ps':['docker','ps','-a','--format','{{json .}}'],
'base-image':['docker','image','inspect','--format','{{json .Id}} {{json .RepoDigests}}','ubuntu@sha256:224a1869083a311ef3f13648a154ba79832fbef6364d31493642ca03082da254'],
'prior-qualified-image':['docker','image','inspect','--format','{{json .Id}} {{json .RepoTags}}','kv9-chaos:release-thin-lto-02d0c01-full21-first']}
def run(item):
 name,argv=item;start=time.time_ns()
 try:
  q=subprocess.run(argv,capture_output=True,timeout=25);out,err,code=q.stdout,q.stderr,q.returncode;failure=None
 except Exception as e:out,err,code=b'',str(e).encode(),None;failure=repr(e)
 (O/(name+'.stdout')).write_bytes(out);(O/(name+'.stderr')).write_bytes(err)
 return dict(name=name,argv=argv,started_ns=start,ended_ns=time.time_ns(),exit_code=code,failure=failure,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: rows=list(pool.map(run,commands.items()))
s=os.statvfs('/tmp');t=os.statvfs('/dev/shm')
r=dict(complete=all(x['exit_code']==0 for x in rows),observed_ns=time.time_ns(),commands=rows,available_bytes=s.f_bavail*s.f_frsize,tmpfs_available_bytes=t.f_bavail*t.f_frsize,scope='Read-only local availability; no image build/load/probe, container exec, namespace/fault mutation or fixture run.')
(O/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='commands'}));print(json.dumps({x['name']:x['exit_code'] for x in rows}))
