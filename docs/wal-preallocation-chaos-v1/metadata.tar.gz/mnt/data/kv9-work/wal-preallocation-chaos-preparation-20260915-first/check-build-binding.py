"""Read-only original-build verification; not a compiler or retrospective manifest generator."""
import argparse, hashlib, json
from pathlib import Path
R=Path(__file__).parent
REV='86aa6fc07d82f4d49b43fbfe309e0e5c20276da5'
SERVER_MANIFEST='f6febda670eb6ceb228b739590e8e6608d91cde492ad5fb557e232f443a9eeb5'
SERVER='1a38b0a0223650f42aa306131787937f55d7cfc9db2963b2d4bdf8f3d2c8566e'
NATIVE='49ebe15e52f8851899372cf350cc8b7d9de1cc30fb3abcb8a76670d7a4369730'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
PRESSURE_FEATURES = {
 'kv9-common':['testing'], 'kv9-engine':['testing'], 'kv9-raft':['experimental-leader-lease','testing'],
 'kv9-meta':[], 'kv9-region':[], 'kv9-server':[], 'kv9-txn':[],
}
PRESSURE_TARGETS = {
 ('kv9-raft','build-script-build',('custom-build',)),
 ('kv9-server','build-script-build',('custom-build',)),
 *{(name,name.replace('-','_'),('lib',)) for name in PRESSURE_FEATURES},
 ('kv9-server','admission-pressure',('example',)),
}

def feature_check(rows,role):
 assert role in ('server','native','point','pressure'), 'unknown build role'
 assert rows, 'first-party artifact inventory missing'
 observed=set()
 for x in rows:
  assert x['profile']['test'] is False, 'test harness artifact is not a release helper'
  if role=='pressure':
   package=x['package_id'].rsplit('#',1)[-1].split('@',1)[0]
   assert package in PRESSURE_FEATURES, 'unexpected pressure package'
   assert x['features']==PRESSURE_FEATURES[package], 'pressure package feature set differs'
   target=(package,x['target']['name'],tuple(x['target']['kind']))
   assert target in PRESSURE_TARGETS and target not in observed, 'pressure target inventory differs'
   observed.add(target)
  else:
   package=x['package_id'].rsplit('#',1)[-1].split('@',1)[0]
   assert package in set(PRESSURE_FEATURES)|{'kv9'}, 'unexpected production package'
   expected=['wal-payload-preallocation'] if role=='server' and package in ('kv9','kv9-engine') else []
   assert x['features']==expected, 'exact production role features differ'
 if role=='pressure':assert observed==PRESSURE_TARGETS, 'pressure required target missing'

def cache_check(path,source,role='server'):
 c=read(path)
 assert c['complete'] and c['invalidation_complete'] and c['profile']=='release'
 assert c['target_directory']=='/home/dongxu/kv9/target' and c['source_root']==source
 feature_check(c['first_party_artifacts'],role)
 for x in c['first_party_artifacts']:
  assert x['fresh'] is False or x['seen_after_invalidation'] is True, 'stale first-observed first-party artifact'
  if x['target']['kind']!=['custom-build']:assert x['profile']['opt_level']=='3'
 return c

def verify_server(plan):
 source=Path(plan['worktree']);base=Path(plan['server_manifest']['path']).parent
 m=read(base/'build.json');b=base.parent
 authority=read(R/'release-input-pins.json')
 for path,row in authority.items():
  assert Path(path).stat().st_size==row['bytes'] and sha(path)==row['sha256'],path
 rb=read(b/'independent-readback.json')
 assert rb['complete'] and rb['revision']==REV and rb['source_files']==len(m['sources'])
 assert rb['source_tree_sha256']==m['source_tree_sha256']==plan['source_tree_sha256']
 assert m['complete'] and m['source_before_equals_after'] and m['source_root']==str(source)
 assert m['wal_payload_preallocation_enabled'] and not m['diagnostics_enabled'] and not m['write_stage_tracing_enabled']
 assert m['jobs']==4 and m['offline'] and m['profile']=='release'
 assert sha(base/'build.log')==m['build_log_sha256'] and sha(base/'kv9-cargo.jsonl')==m['cargo_jsonl_sha256']
 assert m['command']==['cargo','build','--offline','--locked','--release','--bin','kv9','--message-format=json-render-diagnostics','-v','--features','wal-payload-preallocation']
 c=read(plan['server_cache_path'])
 assert c['complete'] and c['invalidation_complete'] and c['profile']=='release'
 assert c['source_root']==str(source) and c['target_directory']=='/home/dongxu/kv9/target'
 assert c['source_identity_sha256']==m['source_identity_sha256']
 allrows=[]
 for variant in ['default','preallocated']:
  vm=read(b/variant/'build.json');rows=[json.loads(s)for s in (b/variant/'kv9-cargo.jsonl').read_text().splitlines()]
  assert vm['revision']==REV and not vm['dirty'] and vm['sources']==m['sources']
  assert rows[-1]=={'reason':'build-finished','success':True}
  own=[x for x in rows if x.get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file://'+str(source))]
  feature_check(own,'server' if variant=='preallocated' else 'point')
  assert len(own)==10 and {x['target']['name']for x in own}>={'kv9','kv9_engine','kv9_server','kv9_raft'}
  allrows+=own
 assert len(c['first_party_artifacts'])==len(allrows)
 for row,actual in zip(c['first_party_artifacts'],allrows):
  for key in ['package_id','target','features','fresh','profile']:assert row[key]==actual[key],key
  assert row['fresh'] is False or row['seen_after_invalidation'] is True
 return m

def verify(plan):
 source=Path(plan['worktree']); assert plan['revision']==REV
 base=Path(plan['server_manifest']['path']).parent
 assert sha(base/'build.json')==SERVER_MANIFEST and sha(base/'kv9')==SERVER
 m=read(base/'build.json');assert m['revision']==REV and not m['dirty'] and m['profile']=='release'
 assert m['sources']==plan['source'] and m['source_tree_sha256']==plan['source_tree_sha256']
 for name,h in m['sources'].items():assert sha(source/name)==h,name
 verify_server(plan)
 native=Path(plan['native_build_directory']);point=Path(plan['point_build_directory']);pressure=Path(plan['pressure_manifest_path']).parent
 for directory,binary,expected in [(native,'kv9-batch-workload',plan['native_client_build']),(point,'kv9-workload',plan['correctness_client_build'])]:
  b=read(directory/'build.json');i=read(directory/'sources.json')
  assert expected is not None and b==expected
  assert b['revision']==REV and b['dirty'] is False and b['profile']=='release'
  assert i['sources']==m['sources'] and b['source_tree_sha256']==m['source_tree_sha256']
  assert sha(directory/binary)==b['binary_sha256']
  rows=[json.loads(s) for s in (directory/'cargo.jsonl').read_text().splitlines()]
  feature_check([x for x in rows if x.get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file://'+str(source)+'/')], 'native' if binary=='kv9-batch-workload' else 'point')
  assert rows[-1]=={'reason':'build-finished','success':True}
  for name in [binary,'kv9_engine','kv9_raft','kv9_server']:
   x=[a for a in rows if a.get('reason')=='compiler-artifact' and a['target']['name']==name]
   assert len(x)==1 and x[0]['features']==[] and x[0]['profile']['test'] is False and x[0]['profile']['opt_level']=='3'
 assert sha(native/'kv9-batch-workload')==NATIVE
 cache_check(point/'cache-safety.json',str(source),'point');cache_check(pressure/'cache-safety.json',str(source),'pressure')
 pressure_rows=[json.loads(s) for s in (pressure/'cargo.jsonl').read_text().splitlines()]
 assert pressure_rows[-1]=={'reason':'build-finished','success':True}
 feature_check([x for x in pressure_rows if x.get('reason')=='compiler-artifact' and x['package_id'].startswith('path+file://'+str(source)+'/')], 'pressure')
 pm=read(pressure/'build.json');assert pm['revision']==REV and pm['dirty'] is False and pm['profile']=='release'
 assert pm['sources']==m['sources'] and pm['source_tree_sha256']==m['source_tree_sha256']
 assert pm['binary_sha256']==plan['pressure_binary']['sha256']==sha(pressure/'admission-pressure')
 assert pm['command']==['cargo','build','--locked','--release','-p','kv9-server','--example','admission-pressure','--message-format=json-render-diagnostics']
 assert pm['before']==pm['after'] and pm['exit_code']==0
 return {'complete':True,'revision':REV,'source_files':len(m['sources']),'production_features':{'server':{'kv9':['wal-payload-preallocation'],'kv9-engine':['wal-payload-preallocation'],'others':[]},'native':[],'point':[]},'pressure_role':{'kind':'test-only remote read-pressure example','package_features':PRESSURE_FEATURES,'test_harness':False,'database_instantiated':False},'profile':'release','separate_original_builds':True,'server':SERVER,'native':NATIVE,'point':expected['binary_sha256'],'pressure':pm['binary_sha256']}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--plan',type=Path,required=True);args=a.parse_args();print(json.dumps(verify(read(args.plan)),sort_keys=True))
