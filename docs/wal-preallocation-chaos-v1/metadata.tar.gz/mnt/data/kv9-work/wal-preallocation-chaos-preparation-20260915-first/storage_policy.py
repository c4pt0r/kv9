"""Explicit root-selected Chaos host-storage policy; no process or filesystem mutation."""
import hashlib,json
from pathlib import Path
EXPECTED_SHA256='2e8857a0a34d6f4dcb6ab87f45c2cfe19068a0889913c7df1fa44a91bdf87331'
EXPECTED={'accounting': 'statvfs f_bavail * f_frsize; never count excluded free blocks', 'maximum_additional_build_image_archive_bytes': 12884901888, 'minimum_available_bytes': 8589934592, 'outer_seconds': 1200, 'policy_id': 'kv9-wal-preallocation-chaos-v3', 'preflight_minimum_available_bytes': 21483225088, 'resource_sample_seconds': 5, 'runtime_post_baseline': 'one finalizer available_bytes baseline across runtime and all six post phases', 'scope': 'Exact current-source preallocation full21 auxiliary/image/runtime/post only; root and output filesystems retain original floors and combined positive 12 GiB decrease cap.', 'version': 3}
raw=Path(__file__).with_name('storage-policy.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()==EXPECTED_SHA256,'storage policy bytes changed'
POLICY=json.loads(raw)
assert POLICY==EXPECTED,'storage policy differs'
def integer(n):
    assert type(n) is int and n>=0,'invalid available-byte observation'
def check_launch(available):
    integer(available)
    assert available>=POLICY['preflight_minimum_available_bytes'],'Chaos launch capacity below 20 GiB plus 8 MiB'
def guard_floor(baseline):
    integer(baseline)
    return max(POLICY['minimum_available_bytes'],baseline-POLICY['maximum_additional_build_image_archive_bytes'])
def check_space(available,baseline):
    integer(available)
    assert available>=guard_floor(baseline),'Chaos host floor or original 12 GiB decrease cap crossed'
def check_capacity(d):
    assert d['policy_id']==POLICY['policy_id'] and d['policy_sha256']==EXPECTED_SHA256,'capacity policy binding differs'
    for k in ('preflight_minimum_available_bytes','minimum_available_bytes','maximum_additional_build_image_archive_bytes'):
        assert type(d[k]) is int and d[k]==POLICY[k],('capacity limit differs',k)
    check_launch(d['available_bytes'])
    from space_guard import snapshot,check
    assert d['available_bytes']==min(x['available_bytes']for x in d['filesystems'].values())
    check(snapshot(),d['filesystems'],launch=True)
