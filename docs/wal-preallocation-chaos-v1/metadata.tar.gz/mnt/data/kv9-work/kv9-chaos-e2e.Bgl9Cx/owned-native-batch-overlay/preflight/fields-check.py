"""Bounded real wrapper/child identity plus new status-contract controls."""
from pathlib import Path
import importlib.util,hashlib,json,subprocess,time,os,signal,copy
R=Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/preflight/fields-check');R.mkdir(exist_ok=False)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
probe=module('probe','/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/process-probe.py');fields=module('fields','/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/observer-fields.py');exe=Path('/usr/bin/sleep');h=hashlib.sha256(exe.read_bytes()).hexdigest()
script='sleep 90 & child=$!; echo "$child" > "$1/pid"; wait "$child"';p=subprocess.Popen(['bash','-c',script,'owned-wrapper',str(R)],start_new_session=True);result=dict(cases=[],wrapper_pid=p.pid)
try:
 for _ in range(100):
  if (R/'pid').exists():break
  time.sleep(.02)
 child=int((R/'pid').read_text());assert child!=p.pid
 state=dict(pid=str(child),process_start_ticks=Path('/proc',str(child),'stat').read_text().rsplit(')',1)[1].split()[19],process_boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),public_rpc_limit_requests='8',public_rpc_limit_encoded_bytes='2097152',raft_async_read_limit='128',raft_async_apply_limit='128',raft_async_apply_queued='2',raft_async_apply_in_flight='3',raft_async_apply_peak='4',raft_async_apply_stopped='false')
 (R/'status').write_text(''.join(k+'='+v+'\n' for k,v in state.items()))
 q=subprocess.run(['bash','-c',probe.PROBE,'owned-probe',str(R/'status'),str(exe)],text=True,capture_output=True,timeout=5);(R/'probe.stdout').write_text(q.stdout);(R/'probe.stderr').write_text(q.stderr);assert q.returncode==0
 parsed=probe.parse(q.stdout,h,str(exe));assert parsed['process_pid']==child
 defaults=dict(public_rpc_limit_requests=64,public_rpc_limit_encoded_bytes=67108864,raft_async_read_limit=128,raft_async_apply_limit=128)
 pod=dict(spec=dict(containers=[dict(env=[dict(name='KV9_PUBLIC_MAX_REQUESTS',value='8'),dict(name='KV9_PUBLIC_MAX_ENCODED_BYTES',value='2097152')])]))
 accepted=fields.validate(parsed,pod,defaults);result['cases'].append('actual wrapped child and bounded active async-apply status accepted')
 stopped=copy.deepcopy(parsed)
 for name in ['state','state_after']:stopped[name]['raft_async_apply_stopped']='true'
 fields.validate(stopped,pod,defaults);result['cases'].append('intentional stopped intermediate state retained as valid identity/observation')
 for label,name,value in [('wrong limit','raft_async_apply_limit','64'),('queued exceeds reserved','raft_async_apply_queued','4'),('in-flight exceeds peak','raft_async_apply_in_flight','5'),('peak exceeds source limit','raft_async_apply_peak','129'),('invalid stopped string','raft_async_apply_stopped','unknown'),('negative occupancy','raft_async_apply_queued','-1')]:
  mutant=copy.deepcopy(parsed);mutant['state'][name]=value
  try:fields.validate(mutant,pod,defaults)
  except (AssertionError,KeyError,ValueError) as e:result['cases'].append(dict(control=label,rejected=str(e)))
  else:raise AssertionError('invalid status accepted: '+label)
 mutant=copy.deepcopy(parsed);mutant['state_after']['raft_async_apply_peak']='3'
 try:fields.validate(mutant,pod,defaults)
 except AssertionError as e:result['cases'].append(dict(control='within-sample peak decrease',rejected=str(e)))
 else:raise AssertionError('peak decrease accepted')
 healed=state|dict(raft_async_apply_queued='0',raft_async_apply_in_flight='0');fields.final_drained(healed)
 for label,change in [('stopped final',dict(raft_async_apply_stopped='true')),('undrained final',dict(raft_async_apply_in_flight='1'))]:
  try:fields.final_drained(healed|change)
  except AssertionError:result['cases'].append(dict(control=label,rejected=True))
  else:raise AssertionError(label+' accepted')
 result.update(complete=True,actual_child_pid=child,process_start_ticks=parsed['process_start_ticks'],probe_sha256=hashlib.sha256(Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/process-probe.py').read_bytes()).hexdigest(),fields_sha256=hashlib.sha256(Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/observer-fields.py').read_bytes()).hexdigest(),accepted=accepted,scope='Observer mechanism/field controls only, synthetic counters on a real Bash-parent/child process. No runtime acceptance claim; unchanged PID probe has prior before/after PID/start/hash/dead-PID controls retained separately.')
finally:
 os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5);result.update(wrapper_exited=True,child_exited=not Path('/proc/'+str(child)).exists());(R/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
