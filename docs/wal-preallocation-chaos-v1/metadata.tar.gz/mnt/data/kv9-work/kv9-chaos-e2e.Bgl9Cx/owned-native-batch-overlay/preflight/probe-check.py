from pathlib import Path
import json,hashlib,importlib.util,subprocess,os,time
root=Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/preflight/probe-check');root.mkdir(exist_ok=False);source=Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/process-probe.py');spec=importlib.util.spec_from_file_location('probe',source);probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
child=subprocess.Popen(['/usr/bin/sleep','30']);rows=[]
try:
 pid=child.pid;proc=Path('/proc')/str(pid);stat=(proc/'stat').read_text();start=int(stat.rsplit(')',1)[1].split()[19]);boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();exe=Path(os.readlink(proc/'exe'));expected=hashlib.sha256(exe.read_bytes()).hexdigest();status=root/'status';status.write_text(f'pid={pid}\nprocess_start_ticks={start}\nprocess_boot_id={boot}\nraft_async_apply_peak=1\n')
 command=['bash','-c',probe.PROBE,'owned-probe',str(status),str(exe)];result=subprocess.run(command,capture_output=True,text=True,timeout=10);assert result.returncode==0;raw=result.stdout;(root/'actual-probe.stdout').write_text(raw);(root/'actual-probe.stderr').write_text(result.stderr)
 def check(name,text,accept,expected_reason=None):
  try:value=probe.parse(text,expected,str(exe));passed=True;reason=None
  except (AssertionError,KeyError,ValueError) as e:passed=False;reason=repr(e)
  assert passed==accept,(name,passed,reason)
  if expected_reason:assert expected_reason in reason,(name,reason)
  path=root/(name+'.stdout');path.write_text(text);rows.append(dict(name=name,accepted=passed,expected_accepted=accept,reason=reason,input=str(path),sha256=hashlib.sha256(text.encode()).hexdigest()))
 check('actual-live-writer',raw,True)
 def section_edit(label,transform):
  tag='@@'+label+'@@\n';prefix,tail=raw.split(tag,1);body,suffix=tail.split('@@',1);return prefix+tag+transform(body)+'@@'+suffix
 check('stale-same-pid-status-before',section_edit('STATUS_BEFORE',lambda s:s.replace(f'process_start_ticks={start}',f'process_start_ticks={start-1}')),False,'status writer start identity mismatch')
 check('stale-same-pid-status-after',section_edit('STATUS_AFTER',lambda s:s.replace(f'process_start_ticks={start}',f'process_start_ticks={start-1}')),False,'status writer start identity mismatch')
 for label in ['STATUS_BEFORE','STATUS_AFTER']:
  check('wrong-boot-'+label.lower(),section_edit(label,lambda s:s.replace(boot,'00000000-0000-0000-0000-000000000000')),False,'status writer boot identity mismatch')
 check('missing-start',raw.replace(f'process_start_ticks={start}\n',''),False,'status writer start identity mismatch')
 check('missing-boot',raw.replace(f'process_boot_id={boot}\n',''),False,'status writer boot identity mismatch')
 check('unavailable-start',raw.replace(f'process_start_ticks={start}','process_start_ticks=unavailable'),False,'status writer start identity mismatch')
 check('unavailable-boot',raw.replace(f'process_boot_id={boot}','process_boot_id=unavailable'),False,'status writer boot identity mismatch')
 check('actual-boot-changed',section_edit('BOOT_AFTER',lambda s:s.replace(boot,'00000000-0000-0000-0000-000000000000')),False,'actual boot ID changed')
 check('wrong-executing-hash',section_edit('HASH_AFTER',lambda s:s.replace(expected,'0'*64)),False,'executing executable mismatch')
 # Fresh synthetic old-format status refuses attribution; the deleted historical sample is not recreated.
 old=raw.replace(f'pid={pid}\n','pid=1\n').replace(f'process_start_ticks={start}\n','').replace(f'process_boot_id={boot}\n','')
 try:probe.parse(old,expected,str(exe))
 except (AssertionError,KeyError,ValueError) as e:rows.append(dict(name='synthetic-old-format-stale-pid1',accepted=False,reason=repr(e),source='fresh synthetic mutation of owned current probe'))
 else:raise AssertionError('old-format stale identity was accepted')

finally:
 child.terminate();child.wait(timeout=5)
assert not proc.exists();record=dict(complete=True,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=command,process_pid=pid,start_ticks=start,boot_id=boot,executable_sha256=expected,checks=rows,owned_child_exited=True,scope='Owned actual-process probe preflight plus explicit corrupted-status controls; no candidate rebuild/runtime or shared-validator modification. Missing/unavailable identities do not attest a lifetime. Registry monotonicity rules are unchanged.');(root/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(complete=True,cases=len(rows),owned_child_exited=True,source_sha256=record['source_sha256'])))
