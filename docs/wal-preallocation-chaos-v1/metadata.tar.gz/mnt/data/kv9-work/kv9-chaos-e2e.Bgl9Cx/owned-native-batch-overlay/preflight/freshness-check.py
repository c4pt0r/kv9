from pathlib import Path
import importlib.util,json,copy,hashlib,time
P=Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/delay-gate.py');spec=importlib.util.spec_from_file_location('gate2',P);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);root=Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay/preflight/freshness-check');root.mkdir(exist_ok=False)
def row(exports,inline=10,start=100,boot='owned-boot'):
 return {'pod_uid':'owned-pod','process_pid':1,'process_start_ticks':start,'process_boot_id':boot,'status_writer_identity_matched':True,'state':{'metrics_export_successes':str(exports),'public_raw_get_completed_inline':str(inline)},'state_after':{'metrics_export_successes':str(exports),'public_raw_get_completed_inline':str(inline)}}
results=[]
def test(name,fn):fn();results.append({'name':name,'passed':True})
def require(value):assert value
seed={'1':row(10)}
def stale():
 f=g.ServerFreshness(seed);require(not f.observe({'1':row(10,inline=500)}))
 try:g.wait_qualifying(lambda:f.observe({'1':row(10,inline=500)}) or None,time.monotonic()+.03,.005)
 except TimeoutError:return
 raise AssertionError('stale snapshot avoided timeout')
test('stale-export-despite-inline-growth-times-out',stale)
def one():
 f=g.ServerFreshness(seed);require(not f.observe({'1':row(11)}));require(not f.observe({'1':row(11)}))
test('one-advance-is-insufficient',one)
def two():
 f=g.ServerFreshness(seed);require(not f.observe({'1':row(11)}));require(bool(f.observe({'1':row(12)})))
test('two-serial-advances-qualify',two)
def jump():
 f=g.ServerFreshness(seed);require(not f.observe({'1':row(1000)}));require(bool(f.observe({'1':row(1001)})))
test('large-first-jump-still-needs-second-observation',jump)
def reused():
 f=g.ServerFreshness(seed);require(not f.observe({'1':row(11,start=101)}));require(not f.observe({'1':row(12,start=101)}))
test('same-pid-new-start-cannot-advance-old-writer',reused)
def boot():
 f=g.ServerFreshness(seed);require(not f.observe({'1':row(11,boot='new-boot')}));require(not f.observe({'1':row(12,boot='new-boot')}))
test('new-boot-cannot-advance-old-writer',boot)
def decrease():
 f=g.ServerFreshness(seed);f.observe({'1':row(11)})
 try:f.observe({'1':row(10)})
 except AssertionError:return
 raise AssertionError('counter decrease accepted')
test('server-export-monotonicity-not-waived',decrease)
record={'complete':True,'gate_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'cases':results,'scope':'Deterministic stale-snapshot/serial-export controls; no runtime process, fault or full matrix launched.'};(root/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'complete':True,'cases':len(results),'gate_sha256':record['gate_sha256']}))
