"""Launch only an explicitly authorized prepared point plus native batch matrix and its owned observer."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first')
OVERLAY = Path('/mnt/data/kv9-work/wal-preallocation-chaos-preparation-20260915-first/overlay')
PLAN = ROOT / 'plan.json'
p = json.loads(PLAN.read_text())
assert p['fixture_launch_authorized'] is True and p['plan_ready'] is True and p['build_complete'] is True
assert not p['fixture_started']
assert p.get('archive_cleanup_reviewed') is True, 'archive/UID cleanup must be reviewed before runtime'
assert (ROOT / 'root-runtime-release.json').is_file(), 'fresh root release missing'
release = json.loads((ROOT / 'root-runtime-release.json').read_text())
import hashlib
assert release['plan_sha256'] == hashlib.sha256(PLAN.read_bytes()).hexdigest()
assert release['revision'] == p['revision'] and release['single_use'] is True
(ROOT / 'runtime-release-consumed.json').open('x').write(json.dumps(release) + '\n')
subprocess.run(['python3', str(OVERLAY / 'verify-prebuilt.py'), '--plan', str(PLAN)], check=True)
env = dict(os.environ, CARGO_TARGET_DIR=p['shared_cargo_target'], KUBECONFIG=p['kubeconfig'],
           KIND=p['kind'], KV9_KIND_CLUSTER=p['kind_cluster'], KV9_CHAOS_IMAGE=p['image'],
           KV9_BIN=p['production_binary']['path'], CARGO_BUILD_JOBS='4', GITHUB_SHA=p['revision'],
           KV9_OBSERVER_GATE_PLAN=str(PLAN), PYTHONDONTWRITEBYTECODE='1', PYTHONOPTIMIZE='0')
command = ['taskset', '-c', '6-15,22-31', 'bash', str(OVERLAY / 'scripts/chaos-mesh-e2e.sh')]
p.update(fixture_started=True, fixture_started_unix_ns=time.time_ns(), fixture_command=command,
         fixture_environment={key: env[key] for key in ('CARGO_TARGET_DIR', 'KUBECONFIG', 'KIND', 'KV9_KIND_CLUSTER',
             'KV9_CHAOS_IMAGE', 'KV9_BIN', 'GITHUB_SHA', 'KV9_OBSERVER_GATE_PLAN')})


def save():
    PLAN.write_text(json.dumps(p, indent=2) + '\n')


save()
observer = None
observer_log = None
try:
    with (ROOT / 'matrix.log').open('x') as log:
        process = subprocess.Popen(command, cwd=p['worktree'], env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, bufsize=1)
        p['fixture_pid'] = process.pid
        save()
        for line in process.stdout:
            log.write(line)
            log.flush()
            if line.startswith('Artifacts: '):
                assert observer is None
                p['artifact'] = line.strip().split('Artifacts: ', 1)[1]
                save()
                raw = Path(p['artifact'])
                shutil.copytree(OVERLAY, raw / 'owned-native-batch-overlay', symlinks=True)
                shutil.copy2(PLAN, raw / 'owned-prelaunch-plan.json')
                observer_log = (ROOT / 'observer.log').open('x')
                observer = subprocess.Popen(['taskset', '-c', '6-15,22-31', 'python3', str(OVERLAY / 'observer.py')],
                                            env=env, stdout=observer_log, stderr=subprocess.STDOUT)
                p['observer_pid'] = observer.pid
                save()
        code = process.wait()
        p.update(fixture_exit_code=code, fixture_ended_unix_ns=time.time_ns())
        log.write(f'COMMAND_EXIT={code}\n')
finally:
    if observer:
        (Path(p['artifact']) / 'async-write-observer.stop').touch()
        try:
            p['observer_exit_code'] = observer.wait(timeout=35)
        except subprocess.TimeoutExpired:
            observer.terminate()
            p['observer_exit_code'] = observer.wait(timeout=15)
        observer_log.close()
    save()
print(json.dumps({key: p.get(key) for key in ('artifact', 'fixture_exit_code', 'observer_exit_code')}))
raise SystemExit(p.get('fixture_exit_code', 1) or p.get('observer_exit_code', 1))
