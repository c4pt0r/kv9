import Promotion
#print axioms Kv9.VoterPromotion.initial_safe
#print axioms Kv9.VoterPromotion.step_safe
#print axioms Kv9.VoterPromotion.run_safe
#print axioms Kv9.VoterPromotion.promotion_requires_the_committed_evidence
#print axioms Kv9.VoterPromotion.evidence_implies_membership
#print axioms Kv9.VoterPromotion.never_learner_and_voter
#print axioms Kv9.VoterPromotion.no_serving_capability
#print axioms Kv9.VoterPromotion.a_voter_is_permanent
#print axioms Kv9.VoterPromotion.the_learner_never_returns_after_promotion
#print axioms Kv9.VoterPromotion.an_evidence_row_alone_promotes_nothing
#print axioms Kv9.VoterPromotion.the_committed_chain_reaches_the_voter
