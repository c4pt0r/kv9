import Attach
#print axioms Kv9.LearnerAttach.initial_safe
#print axioms Kv9.LearnerAttach.step_safe
#print axioms Kv9.LearnerAttach.run_safe
#print axioms Kv9.LearnerAttach.attach_requires_the_committed_intent
#print axioms Kv9.LearnerAttach.the_destination_is_never_a_voter
#print axioms Kv9.LearnerAttach.no_serving_capability
#print axioms Kv9.LearnerAttach.the_learner_is_monotone
#print axioms Kv9.LearnerAttach.confirmation_re_advances_the_cut
#print axioms Kv9.LearnerAttach.an_intent_alone_attaches_nothing
