import Control
#print axioms Kv9.GroupControl.initial_safe
#print axioms Kv9.GroupControl.step_safe
#print axioms Kv9.GroupControl.run_safe
#print axioms Kv9.GroupControl.automatic_start_requires_exact_committed_pair
#print axioms Kv9.GroupControl.preparation_alone_cannot_run
#print axioms Kv9.GroupControl.staging_cannot_publish_desire
#print axioms Kv9.GroupControl.commit_preserves_existing_creation
#print axioms Kv9.GroupControl.committed_desire_survives_restart
#print axioms Kv9.GroupControl.desire_is_monotone
#print axioms Kv9.GroupControl.acknowledgment_is_not_readiness
#print axioms Kv9.GroupControl.one_attempt_per_turn
#print axioms Kv9.GroupControl.selected_has_exact_identity_and_is_not_failed
