import Capture
#print axioms Kv9.SourceCapture.initial_safe
#print axioms Kv9.SourceCapture.step_safe
#print axioms Kv9.SourceCapture.run_safe
#print axioms Kv9.SourceCapture.configuration_is_at_or_before_the_cut
#print axioms Kv9.SourceCapture.upload_requires_committed_pins
#print axioms Kv9.SourceCapture.receipt_requires_pinned_upload_of_the_exact_cut
#print axioms Kv9.SourceCapture.no_serving_or_voting_capability
#print axioms Kv9.SourceCapture.the_cut_is_immutable
#print axioms Kv9.SourceCapture.one_image_per_operation
#print axioms Kv9.SourceCapture.retry_is_a_pure_receipt
#print axioms Kv9.SourceCapture.a_frozen_cut_alone_uploads_nothing
