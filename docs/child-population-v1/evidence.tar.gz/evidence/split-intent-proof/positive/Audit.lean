import Split
#print axioms Kv9.SplitIntent.initial_safe
#print axioms Kv9.SplitIntent.step_safe
#print axioms Kv9.SplitIntent.run_safe
#print axioms Kv9.SplitIntent.an_intent_requires_the_bound_parent_and_ready_children
#print axioms Kv9.SplitIntent.nothing_seals_here
#print axioms Kv9.SplitIntent.nothing_republishes_or_reroutes_here
#print axioms Kv9.SplitIntent.no_serving_capability
#print axioms Kv9.SplitIntent.an_intent_is_permanent
#print axioms Kv9.SplitIntent.one_intent_per_parent
#print axioms Kv9.SplitIntent.readiness_alone_records_nothing
#print axioms Kv9.SplitIntent.the_committed_chain_reaches_the_intent
