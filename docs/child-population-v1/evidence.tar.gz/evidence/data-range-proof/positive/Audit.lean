import Range
#print axioms Kv9.DataRange.no_write_before_install
#print axioms Kv9.DataRange.accepted_write_has_exact_scope
#print axioms Kv9.DataRange.future_epoch_refused
#print axioms Kv9.DataRange.stale_conf_refused
#print axioms Kv9.DataRange.sealed_refuses_every_write
#print axioms Kv9.DataRange.batch_is_all_or_none
#print axioms Kv9.DataRange.rejected_batch_has_no_prefix
#print axioms Kv9.DataRange.existing_range_cannot_be_reinitialized
#print axioms Kv9.DataRange.install_cannot_change_data
#print axioms Kv9.DataRange.sealing_preserves_namespace_and_bounds
#print axioms Kv9.DataRange.exact_open_seal_establishes_terminal_state
#print axioms Kv9.DataRange.seal_is_terminal
#print axioms Kv9.DataRange.seal_survives_arbitrary_traces
#print axioms Kv9.DataRange.lower_bound_is_inclusive
#print axioms Kv9.DataRange.upper_bound_is_exclusive
#print axioms Kv9.DataRange.single_read_view_cannot_authorize_different_scope
