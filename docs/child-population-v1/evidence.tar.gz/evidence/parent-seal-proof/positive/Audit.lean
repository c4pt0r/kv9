import Seal
#print axioms Kv9.ParentSeal.initial_safe
#print axioms Kv9.ParentSeal.step_safe
#print axioms Kv9.ParentSeal.run_safe
#print axioms Kv9.ParentSeal.a_seal_requires_the_committed_intent
#print axioms Kv9.ParentSeal.nothing_serves_through_a_seal
#print axioms Kv9.ParentSeal.the_catalog_is_untouched_here
#print axioms Kv9.ParentSeal.the_seal_never_reverts
#print axioms Kv9.ParentSeal.a_seal_is_permanent
#print axioms Kv9.ParentSeal.restart_preserves_the_fence
#print axioms Kv9.ParentSeal.an_intent_alone_fences_nothing
#print axioms Kv9.ParentSeal.the_committed_chain_reaches_the_fence
