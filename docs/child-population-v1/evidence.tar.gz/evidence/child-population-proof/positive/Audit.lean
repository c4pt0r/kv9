import Population
#print axioms Kv9.ChildPopulation.initial_safe
#print axioms Kv9.ChildPopulation.step_safe
#print axioms Kv9.ChildPopulation.run_safe
#print axioms Kv9.ChildPopulation.population_requires_the_fence
#print axioms Kv9.ChildPopulation.every_committed_copy_is_exact
#print axioms Kv9.ChildPopulation.no_divergent_child_ever_commits
#print axioms Kv9.ChildPopulation.children_serve_nothing_here
#print axioms Kv9.ChildPopulation.a_copy_is_permanent
#print axioms Kv9.ChildPopulation.a_rerun_converges
#print axioms Kv9.ChildPopulation.a_fence_alone_copies_nothing
#print axioms Kv9.ChildPopulation.the_chain_reaches_both_exact_children
