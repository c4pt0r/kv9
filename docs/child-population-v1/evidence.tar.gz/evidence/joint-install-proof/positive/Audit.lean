import Installation
#print axioms Kv9.JointInstall.initial_safe
#print axioms Kv9.JointInstall.step_safe
#print axioms Kv9.JointInstall.run_safe
#print axioms Kv9.JointInstall.selected_requires_both_durable
#print axioms Kv9.JointInstall.receipt_requires_selector_sync
#print axioms Kv9.JointInstall.success_survives_every_step
#print axioms Kv9.JointInstall.failed_has_no_receipt
#print axioms Kv9.JointInstall.recovery_is_one_whole_pair
#print axioms Kv9.JointInstall.recovery_has_no_mixed_image
#print axioms Kv9.JointInstall.corrupted_selection_refuses
#print axioms Kv9.JointInstall.recovered_target_is_exact
#print axioms Kv9.JointInstall.recovery_does_not_lower_term
#print axioms Kv9.JointInstall.recovery_preserves_same_term_vote
