#!/usr/bin/env python3
"""Revive the PRESERVED e2e-third hang state (auto-split increment,
revision aaeba7d-dirty) with the CURRENT binary, whose reconcile surfaces
publish errors in data_group_control_error. The historical hang left a
second-level parent sealed-but-unpublished; the revived reconcile retries
the same publish every turn — whatever it refuses with IS the diagnosis.

Copies the state first; the original evidence directory is never touched.
Requires the SAME MinIO env the original run used, and the original
ports (addresses live in the committed catalog).
"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

SOURCE = Path('/mnt/data/kv9-work/auto-split-20260917/e2e-third')
BASE_PORT = 27020


def fields(text):
    return dict(line.split('=', 1) for line in text.splitlines() if '=' in line)


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--watch-seconds', type=int, default=180)
    args = parser.parse_args()
    binary, output = args.bin.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, KV9_CLUSTER_TOKEN='autosplit-e2e-cluster',
               KV9_CLIENT_TOKENS='admin=autosplit-e2e-client', KV9_CLIENT_TOKEN='autosplit-e2e-client',
               KV9_BOOTSTRAP_TOKEN='autosplit-e2e-bootstrap', KV9_STORAGE='minio',
               # NOT 0: the whole pipeline driver (seal/populate/publish of
               # EXISTING intents) sits behind the trigger gate — 0 froze the
               # first revive silently. New triggers are impossible in this
               # state anyway: both bound parents carry live intents and the
               # four children are unbound.
               KV9_AUTO_SPLIT_BYTES='4096')
    for name in ('KV9_OBJECT_STORE_ENDPOINT', 'KV9_OBJECT_STORE_BUCKET',
                 'KV9_OBJECT_STORE_ACCESS_KEY', 'KV9_OBJECT_STORE_SECRET_KEY'):
        assert env.get(name), f'{name} must be set (original fixture bucket)'
    addresses = {i: f'127.0.0.1:{BASE_PORT+i}' for i in range(1, 5)}
    for node in (1, 2, 3, 4):
        shutil.copytree(SOURCE / f'n{node}', output / f'n{node}')
    processes, handles = {}, []
    record = dict(verdict='running', source=str(SOURCE), observations=[])

    def status(node):
        path = output / f'n{node}/status'
        if not path.exists() or node not in processes:
            return {}
        value = fields(path.read_text())
        return value if value.get('pid') == str(processes[node].pid) else {}

    try:
        for node in (1, 2, 3, 4):
            log = (output / f'revive-{node}.log').open('w')
            handles.append(log)
            processes[node] = subprocess.Popen(
                [str(binary), 'start', '--node-id', str(node), '--addr', addresses[node],
                 '--data-dir', str(output / f'n{node}')],
                env=env, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            if any(status(n).get('endpoint_ready') == 'true' for n in processes):
                break
            time.sleep(0.5)
        errors = {}
        end = time.monotonic() + args.watch_seconds
        while time.monotonic() < end:
            snap = dict(monotonic=time.monotonic())
            for n in (1, 2, 3, 4):
                s = status(n)
                snap[f'n{n}'] = dict(role=s.get('role'), ready=s.get('endpoint_ready'),
                                     groups=s.get('data_groups'),
                                     control_error=s.get('data_group_control_error'))
                err = s.get('data_group_control_error')
                if err and err != 'null' and err not in errors:
                    errors[err] = dict(node=n, at=snap['monotonic'])
                    print(f'ERROR SURFACED n{n}: {err}', flush=True)
            record['observations'].append(snap)
            time.sleep(3)
        record.update(verdict='observed', surfaced_errors=sorted(errors),
                      error_details=errors)
    except Exception as error:
        record.update(verdict='failed', error=str(error))
        raise
    finally:
        for node, process in list(processes.items()):
            if process.poll() is None:
                process.kill()
            process.wait(timeout=10)
        for handle in handles:
            handle.close()
        (output / 'result.json').write_text(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__':
    main()
