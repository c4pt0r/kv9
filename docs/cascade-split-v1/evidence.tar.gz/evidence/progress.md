# Cascade-split diagnosis (task #28) — progress

Baseline: b9847c8 (auto-split published). Open edge from e2e-third
(auto-split increment): second-level parent sealed-but-unpublished,
slice permanently fenced.

## Diagnosis timeline
- repro-first (400 writes, threshold 4096, weak acceptance): did NOT
  hang — acceptance was too weak (children count as 'active' from
  creation; fills happened to miss the seal window). RETAINED.
- repro-second (800 writes + post-fill writes + full readback): HANG
  REPRODUCED at write 114 — same shape as e2e-third (100 retired,
  101/102 bound, 103..106 created, two second-level intents in flight,
  zero progress). surfaced_errors EMPTY.
- Error blackout root cause #1: the reconcile chain ASSIGNED
  group_control_error from the final committed_ranges/reconcile_ranges
  expression, erasing every inner reconcile's error each turn (the
  auto-split increment's "publish errors surfaced" fix was dead on
  arrival). FIXED: None at turn start, each step records, clean turn
  clears.
- revive-first of e2e-third state: KV9_AUTO_SPLIT_BYTES=0 froze the
  WHOLE pipeline driver (seal/populate/publish of existing intents sit
  behind the trigger gate) — a product-level finding to document:
  turning the env off freezes in-flight splits. Revive uses 4096 now.
- revive-fourth (instrumented): 6742× `committed_splits: config error:
  split parent range is already sealed` — reconcile_auto_split bails at
  the TOP every turn on every node.
- HANG ROOT CAUSE: validate_against's sealed-parent acceptance required
  both children bound UNSEALED. A grandchild's publication seals a child
  binding → the GRANDPARENT's intent row retroactively fails readback →
  committed_splits errors atomically → seal/populate/publish/split-
  retirement all freeze forever. In e2e-third: 101's publication froze
  102's pipeline at sealed-unpublished.
- FIX (crates/meta/src/data_groups/split.rs): drop the `!sealed`
  requirement — bound ranges never change boundaries, so exact start/end
  remain permanent evidence of the publication. Regression test
  `a_cascade_publication_never_invalidates_its_grandparent_intent`
  (fails on the old code with the exact historical error).
- revive-fifth: subsystem unfroze; bindings 5→7 (both second-level
  publications committed; start=5 confirms the original run had already
  published 101's split — the freeze trigger). But 101/102 never
  RETIRED.
- STARVATION ROOT CAUSE #2: reconcile_split_retirement `break`s after
  the FIRST published intent — intent-100's idempotent no-op confirm
  starves every later parent forever. Same class in
  reconcile_retirement (multiple removals naming one store). FIXED:
  process every matching decision per turn.
- revive-sixth: e2e-third state FULLY recovers — 100/101/102 retired,
  103..106 active, zero errors.

## In flight
- repro-third (bk2wbrz3s): full from-scratch cascade with all fixes;
  expect verdict 'completed' (all writes land + every key reads back).
- TEMP KV9_CASCADE_DIAG eprintlns still in runtime.rs — STRIP before
  qualification.

## Increment plan (after repro-third)
- Strip diag lines; keep: clobber fix, validate_against fix, two
  break-starvation fixes.
- scripts/cascade-split-e2e.py from cascade-repro.py (require
  'completed'; keep hang-collection path as refusal evidence).
- Lean model proofs/lean/cascade-split/: published-shape validity is
  permanent; retirement covers every published parent (no starvation);
  pipeline driver never freezes on valid history. ~11 theorems + 5
  semantic + 2 policy controls, prove-cascade-split.py.
- Docs: extend docs/AUTO-SPLIT.md cascade section; contract pins;
  sibling refresh; qualify.sh; packet docs/cascade-split-v1;
  issues #9 (replace checkpoint) + #25 (append); commit/push.
- Retained evidence: repro-first/second/third, revive-first..sixth
  (revive-second/third-run show the observability gap), e2e-third
  original stays untouched in auto-split-20260917.
