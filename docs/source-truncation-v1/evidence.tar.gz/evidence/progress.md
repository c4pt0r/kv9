# source-truncation increment — mid-implementation state (2026-09-17)

Committed baseline: d515f8c (destination evidence published; issues updated).
Task #20 in_progress. ALL CODE COMPILES; binary built; e2e-first launched
(background task bbvogyihm, scripts/source-truncation-e2e.py, port 26920).

## Implemented (uncommitted)
- crates/meta/src/data_groups/truncation.rs: kind 105 KV9TRC01
  TruncationDecision{root,operation,task,evidence_task,region,floor},
  plan_truncation(txn, operation, floor) (requires committed evidence via
  evidence::from_row_for_siblings; floor.index ≤ evidence.cut().index; one
  per operation/region; idempotent confirm), committed_truncations(store).
  data_groups.rs: pub mod truncation. evidence.rs: pub(crate)
  from_row_for_siblings wrapper.
- crates/raft/src/rawnode.rs: RaftPeer::truncate_retained_log(floor,
  decision_bytes) -> Result<u64 /*new first_index*/>: leader-only, applied
  ≥ floor, ALL prs() matched ≥ floor, term-at-floor check,
  configuration_at_committed(floor) must be Found, image = Snapshot{data:
  decision bytes, meta floor + conf}, hs{term: current, vote, commit:
  floor.index}, store.install_protocol_snapshot. Idempotent (first > floor
  → return first).
- crates/raft/src/storage.rs: DiskRaftStorage::compacted_base() ->
  Option<AppliedPosition> (inherent, uses raft::Storage internally).
- crates/server/src/region_manager.rs: start_group(+truncations param):
  compacted_base Some(base) requires a committed decision with region+floor
  == base, then RaftPeer::with_installed_storage + NodeDriver::
  with_installed_base; else unchanged. resume_active(+truncations).
  activate passes &[]. tests.rs call site updated with &[].
- crates/server/src/runtime.rs: resume_active call reads
  committed_truncations(store) each reconcile; backend record_source_truncation
  (catalog txn; plan_truncation; ALSO requires source pin Released via
  migration_owner_ids + retention_owner) and truncate_source_log (local
  committed decision by operation; raw_directory group; driver.peer()
  .truncate_retained_log).
- proto: RecordSourceTruncation/TruncateSourceLog RPCs + messages; grpc.rs
  handlers; api.rs RecordSourceTruncationResult/TruncateSourceLogResult +
  trait defaults; client tests/batch_tests/workload-loopback stubs updated.
- crates/server/src/data_groups.rs client methods record_source_truncation
  /truncate_source_log; CLI verbs record-source-truncation (--floor-term/
  --floor-index) and truncate-source-log; main.rs dispatch + help.
- scripts/source-truncation-e2e.py (derived from destination-evidence-e2e,
  port 26920, tokens truncation-e2e-*): after settled release —
  truncate-early refuses; floor beyond evidence cut refuses; record ×2
  (recorded/confirmed); truncate() retry loop (local application) →
  first_index == floor+1, idempotent; restart compacted leader → active
  (restart-path gate!); raw-get 616c706861 survives; learner tracks new
  put 6f6d656761 afterwards. Checks list updated.

## Remaining for this increment
1. e2e verdict (bbvogyihm) — retain failures as evidence if any; fix and
   rerun as e2e-second etc.
2. Meta unit tests for truncation.rs (mirror evidence.rs tests: requires
   committed evidence + released?? NO — Released check is server-side only;
   planner tests: no evidence → refuse; floor > evidence cut → refuse;
   idempotent confirm; divergence refuses; readback defect matrix incl.
   cross-field flips; region duplicate).
   Optional: raft unit test for truncate_retained_log refusal shapes
   (InProcessCluster leader; behind-peer refusal via matched check).
3. Lean model proofs/lean/source-truncation/ (Truncation.lean, ~12
   theorems: decision requires evidence; floor ≤ evidence cut; compaction
   requires decision + all-matched; restart requires decision floor ==
   base; retained floor never regresses below acknowledged...; controls
   ~8) + scripts/prove-source-truncation.py (copy prove-install-evidence
   pattern) + README + source-contract.json.
4. docs/SOURCE-TRUNCATION.md + HORIZONTAL-SCALING-PLAN.md delivery-seq
   sentence (after destination-evidence sentence; next = catchup after
   truncation for stranded learners, promotion, removal, split).
5. cargo fmt + clippy zero; contract refresh (schema-1 lean contracts +
   proofs/tlaps/retention_ledger/inventory.json) via the glob refresh
   snippet (see destination-evidence session); qualify.sh: copy
   /mnt/data/kv9-work/destination-evidence-20260917/qualify.sh, change W=
   .../source-truncation-20260917, add source-truncation to model list.
6. build-local-validation.py + package-source-truncation.py: copy from
   destination-evidence workdir, rename destination-evidence→
   source-truncation, install-evidence-proof→source-truncation-proof
   expectations (theorems/controls counts), packet docs/source-truncation-v1.
7. Portable readback + README.md packet; commit (message: authorize/perform
   source log truncation under committed decisions); push; issues #9
   (replace S05/D03 checkpoint para, ≤65536 bytes — trim!), #19 (append
   checkpoint: truncation seam), #24 (append checkpoint); exact readback;
   publication.json + next-*.md handoff (next: stranded-learner catchup via
   fresh capture/install round, promotion, removal, split).
8. Keep untouched/uncommitted: scripts/checkpoint-publication-chaos.py,
   scripts/checkpoint-owned-crash.py.

Conventions: user-facing Chinese; repo/GitHub English; MinIO env from
/mnt/data/kv9-work/joint-install-20260916/minio-first/private-credentials.json
(endpoint http://172.21.0.4:9000, bucket kv9-joint-install-cbc8bed9c73d);
Lean/TLA tool paths in destination-evidence qualify.sh; never commit
credentials/root.bin; serial suite is the qualifying run.

## e2e-first FAILED (retained as evidence) — real finding
truncate-source-log refused 20×: "protocol snapshot: installation lowers
term/vote or replaces committed history". Root cause: truncate_retained_log
reused install_protocol_snapshot, but validate_transition (storage/
snapshot.rs:66) requires image.index > old.commit — it is a FORWARD-install
seam. Worse: a snapshot record REPLACES the logical prefix at replay; for
self-truncation at floor < last_index the physical record order would be
[entries 1..N, snapshot(floor)] and replay semantics for that ordering must
be checked in storage.rs replay — likely discards the retained tail above
the floor (data loss) or refuses. DO NOT reuse install_protocol_snapshot.

NEXT STEP (attempt 2): add a dedicated PREFIX-COMPACTION seam to
DiskRaftStorage, e.g. `compact_retained_prefix(floor: AppliedPosition,
decision: &[u8]) -> Result<()>`:
- validate floor.index < mem last_index, floor ≤ applied/commit,
  mem.term(floor.index) == floor.term;
- durable record: a NEW record kind in the raft log file (magic e.g.
  KV9CMPT1) carrying floor + decision digest, appended like other records
  (write + sync, same fs discipline as install_protocol_snapshot);
- in-memory: build a minimal Snapshot{meta: floor, conf: configuration at
  or before floor} and mem.wl().compact(floor.index+1)? raft-rs MemStorage
  compact(idx) keeps entries >= idx. Also need mem snapshot metadata set so
  first_index = floor+1 and term(floor) answerable → use
  mem.wl().apply_snapshot? NO (replaces log). MemStorage compact() keeps
  tail and sets its internal snapshot metadata — verify raft-rs 0.7
  MemStorageCore::compact semantics; term(floor) after compact must return
  floor.term (raft-rs keeps entries[0] as dummy at compact point).
- replay in storage.rs recovery: on KV9CMPT1 record, perform the same
  in-memory compaction after the log is rebuilt; entries below floor were
  already replayed then dropped — fine. Torn-tail rules unchanged.
- rawnode truncate_retained_log: call the new seam instead; keep leadership/
  matched/term checks; DROP the constructed image/hs (no HardState change).
- restart path base: compacted_base() reads first_index-1 — after replay
  compaction first_index = floor+1, term(floor) from compact metadata ✓.
- with_installed_storage on restart requires storage.term(base) == term ✓.
- Check DiskRaftStorage snapshot() serving: stored self-compaction has no
  full image — snapshot(request) should keep returning
  SnapshotTemporarilyUnavailable for stragglers (fence intact) — ensure the
  compaction record does NOT populate the served snapshot slot.
Then rerun scripts/source-truncation-e2e.py as e2e-second (keep e2e-first).

## Attempt-2/3 log (context-compaction insurance)
- e2e-second FAILED (retained): compaction seam WORKED (new REC_COMPACTION=7
  path, compact_retained_prefix keeps tail; truncate/truncate-again passed)
  but the restarted compacted voter hit PRE-EXISTING gap:
  DiskRaftStorage::validate_fixed_group required conf == creation voters
  exactly + is_unstarted — ANY source voter restart after learner attach
  failed ("data group configuration is not authorized by its creation
  intent"). First e2e ever to restart a source voter post-attach.
- Fix: ConfigurationHistory::evolved_from(expected) (unambiguous, initial ==
  creation, applied nonempty) + validate_fixed_group now authorizes
  committed-history membership: voters must still equal creation voters
  (sorted), no voters_outgoing/learners_next; learners allowed. Unstarted
  branch unchanged.
- e2e-third launched (b2sfgc0c2). If accepted: fmt/clippy → contract
  (proofs/lean/source-truncation/source-contract.json — pins per README
  table files + scripts/source-truncation-e2e.py + storage.rs +
  storage/configuration.rs + rawnode.rs + region_manager.rs + runtime.rs +
  truncation.rs + evidence.rs + proto + cli + main; theorems list = 13 from
  Truncation.lean; runner scripts/prove-source-truncation.py READY) →
  sibling refresh → qualify.sh (add source-truncation to model list; workdir
  source-truncation-20260917) → packet docs/source-truncation-v1 → commit →
  issues #9/#19/#24 → publication + next handoff (stranded-learner catchup,
  promotion, removal, split). Meta truncation tests DONE (2 tests pass).
  Lean model+runner+README DONE (compiles).

## Attempt-3 finding + fix
e2e-third FAILED (retained): restart validator #2 — WAL replay cross-checks
EVERY batch position against raft history (region_manager prepare closure
`storage.committed_term(at.index) == at.term`); batches below the compacted
floor probe compacted entries → "applied position missing from Raft
history: log compacted". Fix: fn position_in_history(storage, at) in
region_manager.rs — positions < compacted_base accepted (the durable
REC_COMPACTION record, startup-gated on the committed decision, vouches for
the prefix); == base requires exact term; else committed_term check
unchanged. Both call sites (per-batch closure + final applied-position
check) now use it. e2e-fourth launched (bu939ktwz). fmt/clippy zero;
contract + sibling refresh DONE (13 contracts refreshed incl new
source-truncation); qualify.sh ready (13-model list).
Remaining: docs/SOURCE-TRUNCATION.md + plan sentence; packaging scripts
(copy destination-evidence, rename, source-truncation-proof expects 13
theorems/8 controls, add install-evidence-proof.log to sibling logs list);
qualify run; packet docs/source-truncation-v1; commit; issues; handoff.
NOTE: contract hashes were computed BEFORE the position_in_history fix —
region_manager.rs/storage hashes CHANGED since; re-run the sibling-refresh
snippet after fmt before the qualify run.
