use kv9_packed_comparison_diagnostic::{trace_start, trace_stop, PackedMap};
use rpds::RedBlackTreeMapSync;
use serde_json::json;
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use std::hint::black_box;
use std::path::PathBuf;
#[global_allocator]
static ALLOCATOR: tikv_jemallocator::Jemalloc = tikv_jemallocator::Jemalloc;
type Pair = (Vec<u8>, Vec<u8>);
type Model = BTreeMap<Vec<u8>, Vec<u8>>;
trait Index: Clone + Default {
    fn put(&mut self, key: Vec<u8>, value: Vec<u8>);
    fn get(&self, key: &[u8]) -> Option<&Vec<u8>>;
    fn predecessor(&self, key: &[u8]) -> Option<(&Vec<u8>, &Vec<u8>)>;
    fn scan(&self, start: &[u8], end: &[u8], limit: usize) -> Vec<Pair>;
    fn rows(&self) -> Vec<Pair>;
    fn validate(&self);
}
impl Index for PackedMap {
    fn put(&mut self, key: Vec<u8>, value: Vec<u8>) {
        self.insert(key, value);
    }
    fn get(&self, key: &[u8]) -> Option<&Vec<u8>> {
        self.get(key)
    }
    fn predecessor(&self, key: &[u8]) -> Option<(&Vec<u8>, &Vec<u8>)> {
        self.seek_le(key)
    }
    fn scan(&self, start: &[u8], end: &[u8], limit: usize) -> Vec<Pair> {
        self.range(start, end)
            .take(limit)
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect()
    }
    fn rows(&self) -> Vec<Pair> {
        self.iter().map(|(k, v)| (k.clone(), v.clone())).collect()
    }
    fn validate(&self) {
        self.validate();
    }
}
impl Index for RedBlackTreeMapSync<Vec<u8>, Vec<u8>> {
    fn put(&mut self, key: Vec<u8>, value: Vec<u8>) {
        self.insert_mut(key, value);
    }
    fn get(&self, key: &[u8]) -> Option<&Vec<u8>> {
        self.get(key)
    }
    fn predecessor(&self, key: &[u8]) -> Option<(&Vec<u8>, &Vec<u8>)> {
        self.range(..=key.to_vec()).next_back()
    }
    fn scan(&self, start: &[u8], end: &[u8], limit: usize) -> Vec<Pair> {
        self.range(start.to_vec()..end.to_vec())
            .take(limit)
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect()
    }
    fn rows(&self) -> Vec<Pair> {
        self.iter().map(|(k, v)| (k.clone(), v.clone())).collect()
    }
    fn validate(&self) {}
}
fn hash(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn digest(rows: &[Pair]) -> String {
    let mut h = Sha256::new();
    h.update((rows.len() as u64).to_le_bytes());
    for (key, value) in rows {
        h.update((key.len() as u64).to_le_bytes());
        h.update(key);
        h.update((value.len() as u64).to_le_bytes());
        h.update(value);
    }
    format!("{:x}", h.finalize())
}
fn corpus(data: &[u8]) -> Vec<Vec<Pair>> {
    assert_eq!(
        hash(data),
        "d978ba9e49131f6277f975ecd333c33854845cc03bd14ee57a22fff915a08350"
    );
    assert_eq!(&data[..8], b"KV9GRP01");
    let mut offset = 8;
    let mut previous_end = 14221;
    let mut groups = Vec::new();
    fn u32_at(data: &[u8], offset: &mut usize) -> usize {
        let n = u32::from_le_bytes(data[*offset..*offset + 4].try_into().unwrap()) as usize;
        *offset += 4;
        n
    }
    while offset < data.len() {
        let previous = u64::from_le_bytes(data[offset..offset + 8].try_into().unwrap());
        let last = u64::from_le_bytes(data[offset + 8..offset + 16].try_into().unwrap());
        let term = u64::from_le_bytes(data[offset + 16..offset + 24].try_into().unwrap());
        offset += 24;
        assert_eq!(previous, previous_end);
        assert!(last > previous);
        assert_eq!(term, 1);
        previous_end = last;
        let length = u32_at(data, &mut offset);
        let end = offset + length;
        assert!(end <= data.len());
        let count = u32_at(data, &mut offset);
        let mut group = Vec::with_capacity(count);
        for _ in 0..count {
            assert_eq!(&data[offset..offset + 2], &[0, 0]);
            offset += 2;
            let keylen = u32_at(data, &mut offset);
            let key = data[offset..offset + keylen].to_vec();
            offset += keylen;
            let vallen = u32_at(data, &mut offset);
            let value = data[offset..offset + vallen].to_vec();
            offset += vallen;
            assert!(key.len() >= 4 && key[0] == b'r' && offset <= end);
            assert!(!value.is_empty());
            group.push((key, value));
        }
        assert_eq!(offset, end);
        groups.push(group);
    }
    assert_eq!(groups.len(), 106);
    assert_eq!(previous_end, 15785);
    assert_eq!(groups.iter().map(Vec::len).sum::<usize>(), 100096);
    groups
}
struct Workload {
    name: &'static str,
    groups: Vec<Vec<Pair>>,
    initial: Vec<Pair>,
    final_rows: Vec<Pair>,
}
fn workload(name: &'static str, source: &[Vec<Pair>]) -> Workload {
    let mut groups = source.to_vec();
    if name == "unique_insert" {
        for (i, (key, _)) in groups.iter_mut().flatten().enumerate() {
            key.extend_from_slice(&(i as u64 + 1).to_be_bytes());
        }
    }
    let mut model = Model::new();
    if name == "overwrite" {
        for (key, value) in groups.iter().flatten() {
            let mut value = value.clone();
            value[0] ^= 255;
            model.insert(key.clone(), value);
        }
    }
    let initial = model.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
    for (key, value) in groups.iter().flatten() {
        model.insert(key.clone(), value.clone());
    }
    if name == "unique_insert" {
        assert_eq!(model.len(), 100096);
    }
    Workload {
        name,
        groups,
        initial,
        final_rows: model.into_iter().collect(),
    }
}
fn populate<M: Index>(rows: &[Pair]) -> M {
    let mut map = M::default();
    for (key, value) in rows {
        map.put(key.clone(), value.clone());
    }
    map
}
fn check_workload<M: Index>(work: &Workload, pinned: bool) {
    let mut map = populate::<M>(&work.initial);
    let mut expected: Model = work.initial.iter().cloned().collect();
    for group in &work.groups {
        let old = pinned.then(|| map.clone());
        for (key, value) in group {
            map.put(key.clone(), value.clone());
        }
        if let Some(old) = old {
            assert_eq!(
                old.rows(),
                expected
                    .iter()
                    .map(|(k, v)| (k.clone(), v.clone()))
                    .collect::<Vec<_>>()
            );
        }
        for (key, value) in group {
            expected.insert(key.clone(), value.clone());
        }
        assert_eq!(
            map.rows(),
            expected
                .iter()
                .map(|(k, v)| (k.clone(), v.clone()))
                .collect::<Vec<_>>()
        );
        map.validate();
    }
    assert_eq!(map.rows(), work.final_rows);
}

fn selected_keys(work: &Workload, selection: &str) -> Vec<Vec<u8>> {
    let count = work.final_rows.len();
    let indices: Vec<usize> = match selection {
        "all_keys" => (0..count).collect(),
        "prior_stride512" => (0..512).map(|i| (i * count / 512 + 71) % count).collect(),
        "seeded_without_replacement512" => {
            let mut state = 71u64;
            let mut seen = BTreeSet::new();
            let mut result = Vec::new();
            while result.len() < 512 {
                state ^= state << 13;
                state ^= state >> 7;
                state ^= state << 17;
                let index = state as usize % count;
                if seen.insert(index) {
                    result.push(index);
                }
            }
            result
        }
        _ => unreachable!(),
    };
    indices
        .into_iter()
        .map(|i| work.final_rows[i].0.clone())
        .collect()
}
fn main() {
    let root = PathBuf::from(std::env::args().nth(1).unwrap());
    let output = PathBuf::from(std::env::args().nth(2).unwrap());
    assert!(!output.exists());
    let bytes = std::fs::read(root.join("groups.bin")).unwrap();
    let groups = corpus(&bytes);
    let works: Vec<_> = ["overwrite", "initial_fill", "unique_insert"]
        .into_iter()
        .map(|n| workload(n, &groups))
        .collect();
    let mut rows = Vec::new();
    for work in &works {
        for pinned in [false, true] {
            check_workload::<PackedMap>(work, pinned);
            let mut map = populate::<PackedMap>(&work.initial);
            let mut totals = [[0u64; 5]; 7];
            for group in &work.groups {
                let old = pinned.then(|| map.clone());
                trace_start();
                for (key, value) in group {
                    map.put(key.clone(), value.clone());
                }
                let counts = trace_stop();
                for (sum, values) in totals.iter_mut().zip(counts) {
                    for (a, b) in sum.iter_mut().zip(values) {
                        *a += b;
                    }
                }
                black_box(&old);
                drop(old);
            }
            assert_eq!(map.rows(), work.final_rows);
            map.validate();
            rows.push(json!({"operation":"write","workload":work.name,"pinned":pinned,"mutations":100096,"counts":totals,"final_state_sha256":digest(&work.final_rows)}));
        }
    }
    for work in [&works[0], &works[2]] {
        let map = populate::<PackedMap>(&work.final_rows);
        map.validate();
        for selection in [
            "all_keys",
            "prior_stride512",
            "seeded_without_replacement512",
        ] {
            let probes = selected_keys(work, selection);
            for op in ["get_hit", "get_miss", "predecessor", "scan16"] {
                let mut probes = probes.clone();
                if op == "get_miss" {
                    for key in &mut probes {
                        key.push(255);
                        assert!(Index::get(&map, key).is_none());
                    }
                }
                trace_start();
                for key in &probes {
                    match op {
                        "get_hit" => {
                            assert!(black_box(Index::get(&map, key)).is_some());
                        }
                        "get_miss" => {
                            assert!(black_box(Index::get(&map, key)).is_none());
                        }
                        "predecessor" => {
                            black_box(map.predecessor(key));
                        }
                        "scan16" => {
                            black_box(map.scan(key, &[255], 16));
                        }
                        _ => unreachable!(),
                    }
                }
                let counts = trace_stop();
                rows.push(json!({"operation":op,"workload":work.name,"selection":selection,"queries":probes.len(),"counts":counts,
                    "query_sha256":digest(&probes.iter().map(|k|(k.clone(),vec![])).collect::<Vec<_>>())}));
            }
        }
    }
    let result = json!({"complete":true,"rows":rows,"groups_sha256":hash(&bytes),"plan_sha256":hash(&std::fs::read(root.join("diagnostic-plan.json")).unwrap()),
        "scope":"Logical comparator calls and common-prefix lengths. No latency, CPU/cache attribution or production change."});
    let file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(output)
        .unwrap();
    serde_json::to_writer_pretty(file, &result).unwrap();
    println!("{}", json!({"complete":true,"rows":30}));
}
