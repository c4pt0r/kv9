#!/usr/bin/env python3
import hashlib,json,math
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location("inputs",Path(__file__).resolve().parent/"validate-inputs.py");inputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(inputs)
reconstruct,digest=inputs.reconstruct,inputs.digest
R=Path(__file__).resolve().parent;used={}
def data(p):
 b=p.read_bytes();used[str(p)]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());return b
def read(p):return json.loads(data(p))
def pct(s,p):return sorted(s)[math.ceil(len(s)*p/100)-1]
plan=read(R/'timing-plan.json');build=read(R/'benchmark-build-corrected/result.json');cache=read(R/'benchmark-build-corrected/cache-safety.json');qual=read(R/'candidate-qualification-first/result.json');proof=read(R/'strict-proof-second/result.json')
assert build['complete']and cache['complete']and cache['invalidation_complete']and qual['complete']and qual['tests_passed']==8
assert proof['accepted']and proof['complete']and len(proof['theorems'])==18 and len(proof['controls'])==8 and all(x['rejected']for x in proof['controls'])
for path,h in build['sources'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
assert hashlib.sha256(json.dumps(build['sources'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==cache['source_identity_sha256']
for name in ('lib.rs','tests.rs'):
 path=plan['source']+'/src/'+name;assert qual['sources'][path]==build['sources'][path]
assert '8 passed; 0 failed' in data(R/'candidate-qualification-first/tests.stdout').decode()
accepted=read(R/'runs-first/inputs-accepted.json');assert accepted['complete']and accepted['independent_reconstruction']
models,metadata=reconstruct();assert metadata==accepted['models']
results={}
for stage in ('prepare','diagnostic','timing','allocations'):
 terminal=read(R/'runs-first'/f'{stage}-terminal.json');assert terminal['complete']and terminal['exit_code']==0
 mode='timing'if stage=='prepare'else stage;pin=build['artifacts'][mode]
 assert terminal['argv'][3]==pin['path']and terminal['binary_sha256']==pin['sha256']==hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()
 x=read(R/'runs-first'/f'{stage}.json');assert x['complete']and terminal['result_sha256']==used[str(R/'runs-first'/f'{stage}.json')]['sha256']
 if stage=='prepare':
  assert x['workloads']==metadata and x['correctness_live_prefixes']==5724 and x['correctness_old_views']==2862
  assert accepted['prepared_sha256']==terminal['result_sha256'];continue
 if stage=='diagnostic':
  assert x['prepared_sha256']==accepted['prepared_sha256']and len(x['rows'])==12
  for row in x['rows']:
   query=next(q for q in accepted['query_identities']if(q['dataset'],q['workload'],q['operation'])==(row['dataset'],row['workload'],row['operation']));assert row['query_sha256']==query['query_sha256']
   for scope in ('all','selected'):
    d=row[scope];assert sum(d['histogram'].values())==d['count'];assert sum(int(k)*v for k,v in d['histogram'].items())==d['sum'];assert d['mean']==d['sum']/d['count']
   assert row['all']['count']==len(models[row['dataset'],row['workload']])and row['selected']['count']==512
  continue
 assert x['counting_build']==(stage=='allocations')and len(x['rows'])==252 and x['workloads']==metadata
 assert x['input_plan_sha256']==used[str(R/'timing-plan.json')]['sha256']and x['group_file_sha256']==hashlib.sha256((R/'groups.bin').read_bytes()).hexdigest()
 expected_passes=12 if stage=='timing'else 1
 for row in x['rows']:
  assert row['passes']==expected_passes;m=row['metrics'];assert m['windows']==expected_passes*(106 if row['operation']=='write'else 512)
  if row['operation']=='write':assert row['mutations']==expected_passes*100096
  else:
   assert row['queries']==512 and row['all_query_outputs_checked']
   query=next(q for q in accepted['query_identities']if(q['dataset'],q['workload'],q['operation'])==(row['dataset'],row['workload'],row['operation']));assert row['query_sha256']==query['query_sha256']
  if stage=='timing':
   s=m['samples_ns'];assert len(s)==m['windows']and all(type(n)is int and n>0 for n in s)
   assert m['sum_ns']==sum(s)and m['mean_ns']==sum(s)/len(s)
   for q in (50,95,99):assert m[f'p{q}_ns']==pct(s,q)
  else:assert 'samples_ns'not in m and 'mean_ns'not in m
 results[stage]=x
reports=[]
case_keys=[(d,'write',w,p)for d in plan['datasets']for w in ('overwrite','initial_fill','unique_insert')for p in (False,True)]+[(d,op,w,False)for d in plan['datasets']for w in ('overwrite','unique_insert')for op in ('get_hit','get_miss','predecessor','scan16')]
for dataset,operation,workload,pinned in case_keys:
 def select(mode):return[r for r in results[mode]['rows']if(r['dataset'],r['operation'],r['workload'],r['pinned'])==(dataset,operation,workload,pinned)]
 rows=select('timing');counts=select('allocations');assert len(rows)==len(counts)==6
 assert [r['backend']for r in rows]==[r['backend']for r in counts]==plan['orders']and [r['order']for r in rows]==[r['order']for r in counts]==list(range(6))
 pooled={};allocation={};memory={}
 for backend in ('rpds','packed','prefix'):
  s=[n for r in rows if r['backend']==backend for n in r['metrics']['samples_ns']];pooled[backend]=dict(samples=len(s),mean_ns=sum(s)/len(s),p99_ns=pct(s,99))
  c=[r for r in counts if r['backend']==backend];assert c[0]['metrics']==c[1]['metrics'];allocation[backend]=c[0]['metrics']
  if operation=='write':
   assert c[0]['requested_live_bytes']==c[1]['requested_live_bytes']and c[0]['requested_live_bytes']['released_after_drop'];memory[backend]=c[0]['requested_live_bytes']
 comparisons={}
 for baseline,pairs in [('rpds',[(0,2),(5,3)]),('packed',[(1,2),(4,3)])]:
  p,b=pooled['prefix'],pooled[baseline];orders=[]
  for old,new in pairs:
   a,c=rows[old]['metrics'],rows[new]['metrics'];orders.append(dict(baseline_order=old,prefix_order=new,mean_change_percent=(c['mean_ns']/a['mean_ns']-1)*100,p99_change_percent=(c['p99_ns']/a['p99_ns']-1)*100,baseline_mean_ns=a['mean_ns'],prefix_mean_ns=c['mean_ns'],baseline_p99_ns=a['p99_ns'],prefix_p99_ns=c['p99_ns']))
  comparisons[baseline]=dict(mean_change_percent=(p['mean_ns']/b['mean_ns']-1)*100,p99_change_percent=(p['p99_ns']/b['p99_ns']-1)*100,orders=orders)
 if operation=='write':
  model=models[dataset,workload]
  for r in rows+counts:assert r['final_state_sha256']==digest(model)and r['final_keys']==len(model)
 reports.append(dict(dataset=dataset,operation=operation,workload=workload,pinned=pinned,pooled=pooled,comparisons=comparisons,allocation_counts_per_pass=allocation,requested_live_bytes=memory))
writes=[r for r in reports if r['operation']=='write'];reads=[r for r in reports if r['operation']!='write']
material=all(r['comparisons']['rpds']['mean_change_percent']<=-10 for r in writes if r['dataset']=='original24'and r['workload']in('overwrite','unique_insert'))
orders=all(o['mean_change_percent']<0 for r in writes for o in r['comparisons']['rpds']['orders'])
read_gate=all(r['comparisons']['rpds']['mean_change_percent']<=2 and r['comparisons']['rpds']['p99_change_percent']<=2 for r in reads)
result=dict(complete=True,production_changed=False,new_database_qps=False,independent_final_states_query_identities_and_statistics=True,cases=reports,predeclared_gate=dict(original_material_write_gain=material,all_write_order_means_better=orders,reads_within_two_percent=read_gate,advance=material and orders and read_gate),scope=results['timing']['scope'])
(R/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');(R/'analysis-inputs.json').write_text(json.dumps(used,indent=2)+'\n')
print(json.dumps({'complete':True,'predeclared_gate':result['predeclared_gate'],'writes':[{'dataset':r['dataset'],'workload':r['workload'],'pinned':r['pinned'],'comparisons':r['comparisons']}for r in writes]},indent=2))
