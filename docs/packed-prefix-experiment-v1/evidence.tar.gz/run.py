#!/usr/bin/env python3
import hashlib,json,shutil,subprocess,time,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/'runs-first';O.mkdir(exist_ok=False)
build=json.loads((R/'benchmark-build-corrected/result.json').read_text());assert build['complete']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((R/'timing-plan.json').read_text());assert sha(R/'timing-plan.json')=='1f69908965a83e128009128e24bbecf9f5d6a98be4e1ef88710dbf187bc341a5'
for path,h in build['sources'].items():assert sha(Path(path))==h
proof=json.loads((R/'strict-proof-second/result.json').read_text());assert proof['accepted']and len(proof['theorems'])==18 and len(proof['controls'])==8
proof_inputs=json.loads((R/'strict-proof-second/source-inputs.json').read_text())
for name,h in proof_inputs.items():assert sha(Path('/home/dongxu/kv9')/name)==h
qual=json.loads((R/'candidate-qualification-first/result.json').read_text());assert qual['complete']and qual['tests_passed']==8
for name in ('lib.rs','tests.rs'):
 path='/home/dongxu/kv9/scripts/resident-packed-prefix/src/'+name;assert build['sources'][path]==qual['sources'][path]
def registry(p):return{(x['name'],x['version'],x['source']):x['checksum']for x in tomllib.loads(p.read_text())['package']if x.get('source','').startswith('registry+')}
root=registry(Path('/home/dongxu/kv9/Cargo.lock'));resolved=registry(Path('/home/dongxu/kv9/scripts/resident-packed-prefix/Cargo.lock'));assert all(root.get(k)==v for k,v in resolved.items())
for stage,mode in [('prepare','timing'),('diagnostic','diagnostic'),('timing','timing'),('allocations','allocations')]:
 pin=build['artifacts'][mode];assert sha(Path(pin['path']))==pin['sha256']
 free={p:shutil.disk_usage(p).free for p in ('/home/dongxu/kv9','/mnt/data')};assert min(free.values())>=plan['minimum_free_bytes']
 argv=['taskset','-c','4',pin['path']]
 if stage=='diagnostic':argv +=[str(O/'prepare.json'),str(O/'diagnostic.json')]
 else:argv +=[str(R),str(O/(stage+'.json')),'prepare'if stage=='prepare'else'measure']
 rec=dict(complete=False,argv=argv,binary_sha256=pin['sha256'],started_ns=time.time_ns(),free_bytes=free,loadavg=Path('/proc/loadavg').read_text().strip(),cpu=4,cpu_siblings=Path('/sys/devices/system/cpu/cpu4/topology/thread_siblings_list').read_text().strip(),shared_host=True)
 p=None
 try:
  with (O/(stage+'.stdout')).open('x')as out,(O/(stage+'.stderr')).open('x')as err:
   p=subprocess.Popen(argv,stdout=out,stderr=err);rec['pid']=p.pid;(O/(stage+'-launch.json')).write_text(json.dumps(rec,indent=2)+'\n')
   rec['exit_code']=p.wait(timeout=900);assert rec['exit_code']==0
  payload=(O/(stage+'.json')).read_bytes();assert len(payload)<=plan['metadata_limits']['prepare_bytes'if stage=='prepare'else'measurement_bytes']
  x=json.loads(payload);assert x['complete']
  if stage in ('timing','allocations'):assert len(x['rows'])==252 and x['counting_build']==(stage=='allocations')
  assert sha(Path(pin['path']))==pin['sha256'];rec.update(complete=True,result_bytes=len(payload),result_sha256=hashlib.sha256(payload).hexdigest())
 finally:
  if p is not None and p.poll()is None:p.terminate();p.wait(timeout=30)
  rec['ended_ns']=time.time_ns();(O/(stage+'-terminal.json')).write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps(rec),flush=True)
 if stage=='prepare':
  with (O/'inputs-check.stdout').open('x')as out,(O/'inputs-check.stderr').open('x')as err:
   check=subprocess.run(['python3','-B',str(R/'validate-inputs.py')],stdout=out,stderr=err,timeout=120)
  assert check.returncode==0
for path,h in build['sources'].items():assert sha(Path(path))==h
