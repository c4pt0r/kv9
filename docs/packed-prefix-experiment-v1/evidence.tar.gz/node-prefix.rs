use std::cmp::Ordering;
use std::sync::Arc;

const MAX: usize = 32;
const MIN: usize = MAX / 2;

fn common_prefix_len(a: &[u8], b: &[u8]) -> usize {
    a.iter().zip(b).take_while(|(x, y)| x == y).count()
}

fn query_skip(prefix: usize, reference: &[u8], query: &[u8]) -> usize {
    if query.starts_with(&reference[..prefix]) { prefix } else { 0 }
}

fn suffix_cmp(a: &[u8], b: &[u8], skip: usize) -> Ordering {
    a[skip..].cmp(&b[skip..])
}

#[derive(Debug)]
struct Entry { key: Vec<u8>, value: Vec<u8> }

#[derive(Clone, Debug)]
struct Child { minimum: Vec<u8>, node: Arc<Node> }

impl Child {
    fn new(node: Arc<Node>) -> Self { Self { minimum: node.first_key().to_vec(), node } }
    fn refresh(&mut self) {
        // Deliberately unchanged: minimum-refresh suppression is a different experiment.
        if self.minimum.as_slice() != self.node.first_key() {
            self.minimum = self.node.first_key().to_vec();
        }
    }
}

#[derive(Clone, Debug)]
enum Body { Leaf(Vec<Arc<Entry>>), Branch(Vec<Child>) }

#[derive(Clone, Debug)]
struct Node {
    // A prefix common to ALL subtree keys, not only branch separator minima.
    prefix: usize,
    body: Body,
}

impl Node {
    fn new(body: Body) -> Self {
        let mut node = Self { prefix: 0, body };
        node.reset_prefix();
        node
    }
    fn first_key(&self) -> &[u8] {
        match &self.body {
            Body::Leaf(entries) => &entries[0].key,
            Body::Branch(children) => &children[0].minimum,
        }
    }
    fn last_key(&self) -> &[u8] {
        match &self.body {
            Body::Leaf(entries) => &entries.last().unwrap().key,
            Body::Branch(children) => children.last().unwrap().node.last_key(),
        }
    }
    fn reset_prefix(&mut self) {
        self.prefix = common_prefix_len(self.first_key(), self.last_key());
    }
    fn search_skip(&self, query: &[u8]) -> usize {
        query_skip(self.prefix, self.first_key(), query)
    }
    fn admit_prefix(&mut self, key: &[u8]) {
        let previous = &self.first_key()[..self.prefix];
        if !key.starts_with(previous) { self.prefix = common_prefix_len(previous, key); }
    }
    fn occupancy(&self) -> usize {
        match &self.body { Body::Leaf(entries) => entries.len(), Body::Branch(children) => children.len() }
    }
    fn child_for(children: &[Child], key: &[u8], skip: usize) -> usize {
        children.partition_point(|child| suffix_cmp(&child.minimum, key, skip) != Ordering::Greater).saturating_sub(1)
    }
    fn insert(node: &mut Arc<Self>, entry: Arc<Entry>) -> (bool, Option<Arc<Self>>) {
        let current = Arc::make_mut(node);
        current.admit_prefix(&entry.key);
        let skip = current.prefix;
        let inserted = match &mut current.body {
            Body::Leaf(entries) => match entries.binary_search_by(|old| suffix_cmp(&old.key, &entry.key, skip)) {
                Ok(index) => { entries[index] = entry; false }
                Err(index) => { entries.insert(index, entry); true }
            },
            Body::Branch(children) => {
                let index = Self::child_for(children, &entry.key, skip);
                let (inserted, right) = Self::insert(&mut children[index].node, entry);
                children[index].refresh();
                if let Some(right) = right { children.insert(index + 1, Child::new(right)); }
                inserted
            }
        };
        let right = if current.occupancy() > MAX {
            let body = match &mut current.body {
                Body::Leaf(entries) => Body::Leaf(entries.split_off(MIN)),
                Body::Branch(children) => Body::Branch(children.split_off(MIN)),
            };
            current.reset_prefix();
            Some(Arc::new(Self::new(body)))
        } else { None };
        (inserted, right)
    }
    fn borrow_left(left: &mut Arc<Self>, right: &mut Arc<Self>) {
        let (left,right) = (Arc::make_mut(left),Arc::make_mut(right));
        match (&mut left.body, &mut right.body) {
            (Body::Leaf(left),Body::Leaf(right)) => right.insert(0,left.pop().unwrap()),
            (Body::Branch(left),Body::Branch(right)) => right.insert(0,left.pop().unwrap()),
            _ => unreachable!("siblings have equal depth"),
        }
        left.reset_prefix();right.reset_prefix();
    }
    fn borrow_right(left: &mut Arc<Self>, right: &mut Arc<Self>) {
        let (left,right) = (Arc::make_mut(left),Arc::make_mut(right));
        match (&mut left.body, &mut right.body) {
            (Body::Leaf(left),Body::Leaf(right)) => left.push(right.remove(0)),
            (Body::Branch(left),Body::Branch(right)) => left.push(right.remove(0)),
            _ => unreachable!("siblings have equal depth"),
        }
        left.reset_prefix();right.reset_prefix();
    }
    fn merge(left: &mut Arc<Self>, right: Arc<Self>) {
        let left = Arc::make_mut(left);
        match (&mut left.body, Arc::unwrap_or_clone(right).body) {
            (Body::Leaf(left),Body::Leaf(mut right)) => left.append(&mut right),
            (Body::Branch(left),Body::Branch(mut right)) => left.append(&mut right),
            _ => unreachable!("siblings have equal depth"),
        }
        left.reset_prefix();
    }
    fn repair(children: &mut Vec<Child>, index: usize) {
        if children[index].node.occupancy() >= MIN { return; }
        if index > 0 && children[index-1].node.occupancy() > MIN {
            let (left,right) = children.split_at_mut(index);
            Self::borrow_left(&mut left[index-1].node, &mut right[0].node);
            left[index-1].refresh();right[0].refresh();
        } else if index+1 < children.len() && children[index+1].node.occupancy() > MIN {
            let (left,right) = children.split_at_mut(index+1);
            Self::borrow_right(&mut left[index].node,&mut right[0].node);
            left[index].refresh();right[0].refresh();
        } else {
            let left=if index==0 {0}else{index-1};let right=children.remove(left+1);
            Self::merge(&mut children[left].node,right.node);children[left].refresh();
        }
    }
    fn remove_present(node: &mut Arc<Self>, key: &[u8]) {
        let current = Arc::make_mut(node);
        let skip = current.search_skip(key);
        match &mut current.body {
            Body::Leaf(entries) => {
                let index=entries.binary_search_by(|entry|suffix_cmp(&entry.key,key,skip)).unwrap();
                entries.remove(index);
            }
            Body::Branch(children) => {
                let index=Self::child_for(children,key,skip);
                Self::remove_present(&mut children[index].node,key);
                children[index].refresh();Self::repair(children,index);
            }
        }
        // Removing keys only takes a subset of the subtree; the old prefix stays valid.
        // The empty root leaf is removed by PackedMap before any later observation.
    }
}
