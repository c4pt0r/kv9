#!/usr/bin/env python3
import hashlib,importlib.util,json,os,shutil,time,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent;B=Path('/home/dongxu/kv9/scripts/resident-packed-prefix');O=R/'benchmark-build-corrected';O.mkdir(exist_ok=False)
os.environ['CARGO_TARGET_DIR']='/home/dongxu/kv9/target';os.environ['CARGO_BUILD_JOBS']='4'
assert not os.environ.get('RUSTFLAGS') and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
import subprocess
subprocess.run(['cargo','metadata','--offline','--format-version','1'],cwd=B,stdout=subprocess.DEVNULL,check=True)
reference=Path('/home/dongxu/kv9/scripts/resident-packed')
sources={str(p):sha(p)for p in [reference/'Cargo.toml',reference/'src/lib.rs',B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]}
qualified=json.loads((R/'candidate-qualification-first/result.json').read_text());assert qualified['complete']
for name in ('src/lib.rs','src/tests.rs'):assert sources[str(B/name)]==qualified['sources'][str(B/name)]
for name in sources:
 p=Path(name);dst=O/'source'/p.relative_to(Path('/home/dongxu/kv9'));dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
spec=importlib.util.spec_from_file_location('cache','/home/dongxu/kv9/scripts/build_cache.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result=dict(complete=False,started_ns=time.time_ns(),sources=sources,qualified_library_and_tests_unchanged=True,artifacts={})
try:
 with m.BuildCache(B,O,True,sources) as cache:
  for mode,features in [('timing',[]),('allocations',['--features','allocation-counting'])]:
   with (O/(mode+'-clippy.stdout')).open('x') as out,(O/(mode+'-clippy.stderr')).open('x') as err:cache.run(['cargo','clippy','--offline','--locked','--release','--all-targets',*features,'--','-D','warnings'],stdout=out,stderr=err,timeout=900)
   argv=['cargo','build','--offline','--locked','--release','--bin','kv9-packed-prefix-experiment','--message-format','json-render-diagnostics',*features]
   with (O/(mode+'.jsonl')).open('x') as out,(O/(mode+'.stderr')).open('x') as err:cache.run(argv,stdout=out,stderr=err,timeout=900)
   cache.check_artifacts(O/(mode+'.jsonl'))
   source=Path('/home/dongxu/kv9/target/release/kv9-packed-prefix-experiment');binary=O/('packed-'+mode);shutil.copyfile(source,binary);binary.chmod(0o755)
   result['artifacts'][mode]=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary),argv=argv)
  with (O/'diagnostic.jsonl').open('x') as out,(O/'diagnostic.stderr').open('x') as err:cache.run(['cargo','build','--offline','--locked','--release','--bin','key-comparisons','--message-format','json-render-diagnostics'],stdout=out,stderr=err,timeout=900)
  cache.check_artifacts(O/'diagnostic.jsonl')
  binary=O/'key-comparisons';shutil.copyfile('/home/dongxu/kv9/target/release/key-comparisons',binary);binary.chmod(0o755)
  result['artifacts']['diagnostic']=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary))
 assert all(sha(Path(p))==h for p,h in sources.items())
 result['complete']=True
except BaseException as e:result['failure']=repr(e);raise
finally:
 result['ended_ns']=time.time_ns();(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
