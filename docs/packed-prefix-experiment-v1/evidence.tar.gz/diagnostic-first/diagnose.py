#!/usr/bin/env python3
import hashlib,importlib.util,json,os,shutil,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent;B=R/'diagnostic-source';O=R/'diagnostic-first';O.mkdir(exist_ok=False)
os.environ['CARGO_TARGET_DIR']='/home/dongxu/kv9/target';os.environ['CARGO_BUILD_JOBS']='4';assert not os.environ.get('RUSTFLAGS') and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(O/'resolve.stdout').open('x')as out,(O/'resolve.stderr').open('x')as err:subprocess.run(['cargo','metadata','--offline','--format-version','1'],cwd=B,stdout=out,stderr=err,check=True)
sources={str(p):sha(p)for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]}
spec=importlib.util.spec_from_file_location('cache','/home/dongxu/kv9/scripts/build_cache.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result=dict(complete=False,started_ns=time.time_ns(),sources=sources)
try:
 with m.BuildCache(B,O,True,sources)as cache:
  with(O/'clippy.stdout').open('x')as out,(O/'clippy.stderr').open('x')as err:cache.run(['cargo','clippy','--offline','--locked','--release','--all-targets','--','-D','warnings'],stdout=out,stderr=err)
  with(O/'tests.stdout').open('x')as out,(O/'tests.stderr').open('x')as err:cache.run(['cargo','test','--offline','--locked','--release','--lib','--','--test-threads=1'],stdout=out,stderr=err,timeout=900)
  assert '6 passed; 0 failed' in (O/'tests.stdout').read_text()
  with(O/'build.jsonl').open('x')as out,(O/'build.stderr').open('x')as err:cache.run(['cargo','build','--offline','--locked','--release','--bin','kv9-packed-comparison-diagnostic','--message-format','json-render-diagnostics'],stdout=out,stderr=err)
  cache.check_artifacts(O/'build.jsonl');binary=O/'packed-comparisons';shutil.copyfile('/home/dongxu/kv9/target/release/kv9-packed-comparison-diagnostic',binary);binary.chmod(0o755);result['binary_sha256']=sha(binary)
  with(O/'run.stdout').open('x')as out,(O/'run.stderr').open('x')as err:p=subprocess.run(['taskset','-c','4',str(binary),str(R),str(O/'counts.json')],stdout=out,stderr=err,timeout=900)
  result['exit_code']=p.returncode;assert p.returncode==0
 assert all(sha(Path(p))==digest for p,digest in sources.items());assert sha(Path('/home/dongxu/kv9/scripts/resident-packed/src/lib.rs'))=='f8b44a3f401d4e56886265025623df8502fa448fac4962bbb7346b841eec23da'
 result['complete']=True
except BaseException as e:result['failure']=repr(e);raise
finally:
 result['ended_ns']=time.time_ns();(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
