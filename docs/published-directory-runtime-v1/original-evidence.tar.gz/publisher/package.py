from pathlib import Path
import hashlib,json,tarfile,gzip,io,shutil
OUT=Path('/tmp/kv9-published-directory-runtime-evidence-20260914-first/docs/published-directory-runtime-v1');OUT.mkdir()
groups={
 'preparation':Path('/tmp/kv9-published-directory-release-recovery-preparation-20260914-first'),
 'release':Path('/tmp/kv9-published-directory-release-20260914-first'),
 'release-root':Path('/tmp/kv9-published-directory-release-root-20260914-first'),
 'recovery':Path('/tmp/kv9-published-directory-recovery-20260914-first'),
 'recovery-root':Path('/tmp/kv9-published-directory-recovery-root-20260914-first'),
 'recovery-audit':Path('/tmp/kv9-published-directory-recovery-audit-20260914-first'),
 'dev-retirement':Path('/tmp/kv9-published-directory-dev-cache-retirement-20260914-first'),
 'publisher':Path('/tmp/kv9-published-directory-runtime-publication-20260914-first'),
}
rows=[];excluded=[]
for label,root in groups.items():
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink()
  if not path.is_file():continue
  row={'path':label+'/'+str(path.relative_to(root)),'original':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
  if label=='release' and path.name in ('kv9','kv9-batch-workload'):excluded.append(row)
  else:rows.append(row)
assert sum(r['bytes'] for r in rows)<128*1024**2
archive=OUT/'original-evidence.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for row in rows:
  data=Path(row['original']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
  t=tarfile.TarInfo(row['path']);t.size=len(data);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(data))
manifest={'complete':True,'files':rows,'decoded_bytes':sum(r['bytes'] for r in rows),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'excluded_local_binaries':excluded,'scope':'Default release and complete original ordinary-recovery inputs; not Chaos or performance acceptance.'}
(OUT/'inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
verify=Path('/tmp/kv9-wal-published-directory-20260914-first/docs/published-directory-source-v1/verify.py').read_text().replace("root / 'evidence.tar.gz'","root / 'original-evidence.tar.gz'")
(OUT/'verify.py').write_text(verify)
(OUT/'README.md').write_text(f'''# Published-directory default release and recovery

Exact runtime: `483b8c3629b033734f5d7a2b8653a1352304a4b5`.
The archive retains {len(rows)} original members / {manifest['decoded_bytes']:,} decoded bytes,
in {manifest['archive_bytes']:,} compressed bytes. Run `python3 verify.py` for full
member SHA256 verification without extraction. Original server/client binaries
remain local with exact paths, sizes and hashes in the inventory.

Default release80235/57e676/0 and independent readbackf68dc7/0 pass. Ordinary
recovery39585/962723/0 and independent audit027b71/0 pass:364 complete operations,
333OK and31unknown;6 fresh exporter drains;5 voter and2 client lifetimes exited.
Source inventories, cache invalidation, compiler/codegen records, both complete
histories, original WAL bytes, audit outputs and scoped cleanup are retained.
These are same-host process recovery results, not a physical power-cut test.

The separate explicit v2 release/recovery phase policy uses64GiB plus8MiB
launch headroom,48GiB continuous floor,16GiB sampled decrease cap and the unchanged
1200-second deadline. Historical FNV helpers remain under `preparation/origin/`;
exact path/revision/policy differences remain under `preparation/diffs/`.
This policy does not replace the separately versioned benchmark or Chaos guards.
Inactive first-party dev-cache retirement reclaimed5,172,379,648 observed bytes;
all8 protected executable hashes remain unchanged. No source, dependency cache,
release cache, retained binary or original payload was removed.

The selected mainline remains CRC. Actual Chaos Mesh and matched database
throughput/latency acceptance of this candidate are still separate gates.
'''.replace('release80235','release 80235').replace('readbackf68','readback f68').replace('recovery39585','recovery 39585').replace('audit027','audit 027').replace('pass:364','pass: 364').replace('333OK and31unknown;6','333 OK and 31 unknown; 6').replace(';5 voter and2','; 5 voter and 2').replace('uses64GiB plus8MiB','uses 64 GiB plus 8 MiB').replace('headroom,48GiB','headroom, 48 GiB').replace('floor,16GiB','floor, 16 GiB').replace('reclaimed5,','reclaimed 5,').replace('all8','all 8'))
print(json.dumps({'files':len(rows),'decoded_bytes':manifest['decoded_bytes'],'archive_bytes':manifest['archive_bytes'],'archive_sha256':manifest['archive_sha256']}))
