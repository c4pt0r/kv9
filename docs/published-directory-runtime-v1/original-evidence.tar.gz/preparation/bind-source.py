"""Bind the exact clean release source to completed source/proof qualification."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
HERE=Path(__file__).resolve().parent
SOURCE=Path('/tmp/kv9-published-directory-release-source-20260914-first')
ROOT=Path('/tmp/kv9-published-directory-release-root-20260914-first')
BUILD=Path('/tmp/kv9-published-directory-release-20260914-first')
GATE=Path('/tmp/kv9-published-directory-source-20260914-first')
REV='483b8c3629b033734f5d7a2b8653a1352304a4b5'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
ROOT.mkdir()
r=dict(complete=False,started_ns=time.time_ns(),runtime_checkpoint=REV,revision=REV,source_root=str(SOURCE))
try:
 assert __debug__ and not BUILD.exists()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==REV
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=SOURCE)
 gate=read(GATE/'result.json');before=read(GATE/'source-before.json');after=read(GATE/'source-after.json')
 assert gate['complete'] and before==after
 cache=read(GATE/'cache-safety.json');assert cache['complete'] and cache['invalidation_complete']
 assert all(c['exit_code']==0 for c in cache['commands']) and not Path('/proc',str(cache['pid'])).exists()
 term=read('/tmp/kv9-published-directory-source-preparation-20260914-first/tool-terminals.json')
 assert term['source']=={'session_id':98335,'chunk_id':'7c7935','exit_code':0}
 spec=importlib.util.spec_from_file_location('published_release_builder',SOURCE/'scripts/build-workload.py')
 builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder);snapshot=builder.snapshot()
 assert snapshot['revision']==REV and snapshot['dirty'] is False
 docs=lambda name:name.startswith('docs/') or name=='README.md'
 assert {n:h for n,h in snapshot['sources'].items() if not docs(n)}=={n:h for n,h in before.items() if not docs(n)}
 proof=read('/tmp/kv9-published-directory-proof-20260914-validated/result.json')
 assert proof['complete'] and proof['obligations']==24
 for n,h in proof['source'].items():assert snapshot['sources'][n]==h
 old=read('/tmp/kv9-fnv-writer-release-recovery-preparation-20260914-runtime-source/helper-equivalence.json')
 helpers={row['relative_path'].removeprefix('scripts/'):row['candidate_sha256'] for row in old['helpers']}
 assert all(sha(SOURCE/'scripts'/n)==h for n,h in helpers.items())
 protected={
  '/tmp/kv9-crc-main-integration-release-20260914-first/kv9':'106f517c84fabe790ea139f3c18661e14447abd9e257fdd6ba82bfabe6796eb9',
  '/tmp/kv9-crc-main-integration-release-20260914-first/workload/kv9-batch-workload':'ec8002c00253fa6264a2f7bef3814e33dc871c7ef895e6163b7be38be2edffad',
  '/tmp/kv9-fnv-writer-release-20260914-runtime-source/kv9':'d84b0ec8e466a9dc3f4953751605d91c90a90a66df1b03b57a3412e43e42603e',
  '/tmp/kv9-fnv-writer-release-20260914-runtime-source/workload/kv9-batch-workload':'6b1867110dd7eaab5d3a8571b2227e77658ecb6b89f59dd4460836b691935ff3',
  '/tmp/kv9-point-write-v3-release-first/native/kv9-batch-benchmark':'8da9af469f962a938027d1970141bbe4622f7d42b2b795f720e288fb3f8d5957',
  '/tmp/kv9-published-directory-source-20260914-first/published_directory_probe':'c0e86eba0d46b7aafb36d4275bfa27c9f4fca5143fe67a17e3c538ab494c9087',
 }
 for n,h in protected.items():
  p=Path(n);assert p.is_file() and not p.is_symlink() and not p.resolve().is_relative_to('/home/dongxu/kv9/target') and p.stat().st_nlink==1 and sha(p)==h
 policy=read(HERE/'storage-policy.json');v=os.statvfs('/home/dongxu/kv9');free=v.f_bavail*v.f_frsize
 assert free>=policy['launch_available_minimum_bytes']
 r.update(complete=True,storage_policy=policy['name'],policy_sha256=sha(HERE/'storage-policy.json'),source_snapshot=snapshot,source_helper_sha256=helpers,supervisor_sha256=sha(HERE/'run-release.py'),protected_release_hashes=protected,available_bytes=free,policy=policy,source_gate_inputs={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in [GATE/'result.json',GATE/'source-before.json',GATE/'source-after.json',GATE/'cache-safety.json',Path('/tmp/kv9-published-directory-proof-20260914-validated/result.json')]})
except BaseException as error:r['failure']=repr(error);raise
finally:
 r['ended_ns']=time.time_ns();(ROOT/'preflight.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: clean release source bound to qualified runtime, helpers and explicit v2 phase budget')
