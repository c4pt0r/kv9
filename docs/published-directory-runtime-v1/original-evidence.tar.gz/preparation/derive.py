from pathlib import Path
import json,hashlib,difflib,ast
OLD=Path('/tmp/kv9-fnv-writer-release-recovery-preparation-20260914-runtime-source')
NEW=Path('/tmp/kv9-published-directory-release-recovery-preparation-20260914-first')
(NEW/'origin').mkdir();(NEW/'diffs').mkdir()
subs={
 '/tmp/kv9-fnv-writer-release-recovery-preparation-20260914-runtime-source':str(NEW),
 '/tmp/kv9-fnv-writer-release-source-20260914-first':'/tmp/kv9-published-directory-release-source-20260914-first',
 '/tmp/kv9-fnv-writer-release-root-20260914-runtime-source':'/tmp/kv9-published-directory-release-root-20260914-first',
 '/tmp/kv9-fnv-writer-release-20260914-runtime-source':'/tmp/kv9-published-directory-release-20260914-first',
 '/tmp/kv9-fnv-writer-recovery-root-20260914-runtime-source':'/tmp/kv9-published-directory-recovery-root-20260914-first',
 '/tmp/kv9-fnv-writer-recovery-20260914-runtime-source':'/tmp/kv9-published-directory-recovery-20260914-first',
 '12f44d35590ede5f89337fe731dd950162865154':'483b8c3629b033734f5d7a2b8653a1352304a4b5',
 'FNV-writer':'published-directory',
}
records=[]
for name in ('run-release.py','run-recovery.py','check-release.py','process-runner.py','audit.py'):
 original=(OLD/name).read_text();text=original
 for old,new in subs.items():text=text.replace(old,new)
 # Explicit phase-specific capacity policy; unchanged timeout, drop cap,
 # process cleanup, source verification and runtime/history predicates.
 if name in ('run-release.py','run-recovery.py'):
  text=text.replace('floor=80*1024**3','floor=48*1024**3').replace('max(floor,96*1024**3)','floor')
  text=text.replace("start=available();floor", "start=available();floor")
  text=text.replace("if start-ceiling<floor:raise RuntimeError('source reservation cannot fit')", "if start-ceiling<floor+8*1024**2:raise RuntimeError('v2 phase reservation cannot fit')")
  text=text.replace("r=dict(complete=False,argv=cmd", "r=dict(storage_policy='kv9-published-directory-release-recovery-v2',complete=False,argv=cmd")
 if name=='check-release.py':
  text=text.replace("assert original['minimum_available_bytes']==80*1024**3", "assert original['storage_policy']==pre['storage_policy']=='kv9-published-directory-release-recovery-v2'\n assert original['minimum_available_bytes']==48*1024**3")
  text=text.replace("original['initial_available_bytes']>=96*1024**3", "original['initial_available_bytes']>=64*1024**3+8*1024**2")
  text=text.replace("x['available_bytes']>=96*1024**3", "x['available_bytes']>=48*1024**3")
  text=text.replace('and original resource guards','and explicit v2 phase resource guards')
 ast.parse(text)
 (NEW/'origin'/name).write_text(original);(NEW/name).write_text(text)
 (NEW/'diffs'/(name+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='original/'+name,tofile='candidate/'+name)))
 records.append({'name':name,'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'sha256':hashlib.sha256(text.encode()).hexdigest(),'byte_identical':original==text})
policy={'name':'kv9-published-directory-release-recovery-v2','scope':'Only release build and ordinary recovery for483b8c3; not a benchmark or Chaos policy','launch_available_minimum_bytes':64*1024**3+8*1024**2,'continuous_floor_bytes':48*1024**3,'maximum_sampled_available_decrease_bytes':16*1024**3,'sample_seconds':5,'timeout_seconds':1200,'metadata_allowance_bytes':8*1024**2,'accounting':'f_bavail * f_frsize; unrelated host writers are included; finite sampled guard, not a hard allocation reservation','rationale':'The inherited96GiB launch and96GiB actual release floor were operational and did not even budget the full16GiB drop. The v2 phase launch budgets the entire16GiB decrease above48GiB plus8MiB metadata. Preserve source/build, feature, history, sync, quorum, payload and cleanup requirements; originals remain unchanged.'}
(NEW/'storage-policy.json').write_text(json.dumps(policy,indent=2)+'\n')
(NEW/'derivation.json').write_text(json.dumps({'substitutions':subs,'helpers':records,'policy':policy},indent=2)+'\n')
# Pure boundary checks for the declared reservation and sampled guards.
floor=policy['continuous_floor_bytes'];cap=policy['maximum_sampled_available_decrease_bytes'];reserve=policy['metadata_allowance_bytes'];start=floor+cap+reserve
assert start-cap>=floor+reserve
assert not (start-1-cap>=floor+reserve)
assert start-cap>=floor
assert not (floor-1>=floor)
assert not (start-(start-cap-1)<=cap)
assert start-start<=cap
(NEW/'capacity-controls.json').write_text(json.dumps({'complete':True,'controls':6,'policy':policy['name']},indent=2)+'\n')
print('Prepared five helpers, explicit v2 phase policy and six capacity boundaries.')
