import hashlib,json,os,signal,subprocess,time
from pathlib import Path
root=Path('/tmp/kv9-published-directory-release-root-20260914-first');script=Path('/tmp/kv9-published-directory-release-source-20260914-first/scripts/build-native-batch.py')
cmd=['taskset','-c','6-15,22-31','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','CARGO_TERM_VERBOSE=true','python3',str(script),'--release','--output','/tmp/kv9-published-directory-release-20260914-first']
def available():
 s=os.statvfs('/home/dongxu/kv9');return s.f_bavail*s.f_frsize
os.environ.update(CARGO_TARGET_DIR='/home/dongxu/kv9/target',CARGO_BUILD_JOBS='4',CARGO_NET_OFFLINE='true')
pre=json.loads((root/'preflight.json').read_text());assert pre['complete'] and pre['supervisor_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert pre['source_helper_sha256']['build-native-batch.py']==hashlib.sha256(script.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=script.parent.parent,text=True).strip()==pre['revision']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=script.parent.parent)
start=available();floor=48*1024**3;ceiling=16*1024**3
if start-ceiling<floor+8*1024**2:raise RuntimeError('v2 phase reservation cannot fit')
r=dict(storage_policy='kv9-published-directory-release-recovery-v2',complete=False,argv=cmd,script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),started_ns=time.time_ns(),initial_available_bytes=start,minimum_available_bytes=floor,additional_consumption_ceiling_bytes=ceiling,accounting='Conservative decrease in available filesystem bytes, including unrelated host writers; 5-second samples',samples=[])
p=None
try:
 with (root/'source-first.log').open('x') as log:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=p.pid
  (root/'source-invocation.json').write_text(json.dumps(r,indent=2)+'\n')
  while True:
   
   if time.time_ns()-r['started_ns']>1200*1_000_000_000:raise RuntimeError('release command budget exceeded')
   free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
   if free<floor or start-free>ceiling:raise RuntimeError('source qualification disk guard exceeded')
   try:r['exit_code']=p.wait(timeout=5);break
   except subprocess.TimeoutExpired:pass
  free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
  if free<floor or start-free>ceiling:raise RuntimeError('final disk guard exceeded')
  if r['exit_code']!=0:raise RuntimeError('source qualification failed')
 r['complete']=True
except BaseException as e:
 r['failure']=repr(e)
 if p is not None and p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 raise
finally:
 if p is not None:r.update(exit_code=p.returncode,reaped=p.poll() is not None,pid_absent=not Path('/proc',str(p.pid)).exists())
 r['ended_ns']=time.time_ns();(root/'source-result.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: source qualification completed within its disk reservation')
