from pathlib import Path
import hashlib,json,os,sys,time
ROOT=Path('/tmp/kv9-wal-published-directory-20260914-first')
OUT=Path('/tmp/kv9-published-directory-dev-cache-retirement-20260914-first')
os.environ.update(CARGO_TARGET_DIR='/home/dongxu/kv9/target',CARGO_NET_OFFLINE='true')
sys.path.insert(0,str(ROOT/'scripts'))
from build_cache import BuildCache

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():
 x=os.statvfs(ROOT);return x.f_bavail*x.f_frsize
pre=json.loads(Path('/tmp/kv9-published-directory-release-root-20260914-first/preflight.json').read_text())
protected=dict(pre['protected_release_hashes'])
protected.update({'/tmp/kv9-published-directory-release-20260914-first/kv9':'43d8bcb2d852d6fcbebb7f528808e53b3eb93588e2637195e9053cd91e8d5450','/tmp/kv9-published-directory-release-20260914-first/workload/kv9-batch-workload':'205bcf4451d8f1d59023bcd4893d3388ed73846cf0980cbc9efa6cb5df578a2e'})
for n,h in protected.items():assert sha(n)==h and not Path(n).resolve().is_relative_to('/home/dongxu/kv9/target')
before=free();record={'complete':False,'started_ns':time.time_ns(),'available_before':before,'protected':protected,'scope':'Only inactive first-party Cargo dev artifacts; preserve dependencies, release caches, source, retained binaries and all test payloads.'}
try:
 with BuildCache(ROOT,OUT,False,{'purpose':record['scope'],'protected':protected}):pass
 for n,h in protected.items():assert sha(n)==h
 record.update(complete=True,available_after=free(),protected_hashes_unchanged=True)
 record['observed_available_gain']=record['available_after']-before
except BaseException as error:record['failure']=repr(error);raise
finally:
 record['ended_ns']=time.time_ns();(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='protected'}))
