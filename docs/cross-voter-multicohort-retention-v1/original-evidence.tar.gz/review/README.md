# Multi-cohort readback policy review

No concrete blocker remains in the reviewed reader and transaction deltas. This is source/metadata review only; controls and actual migrations were not executed by this reviewer.

The three adapted readers change only the current free-space comparison in `full_decode` to 8 GiB, plus its explicit constant/comment. All other function bytes remain identical. Historical `LIMITS`, storage policy/hash, catalog equality, resource samples, byte/metadata/receipt/child/time/scope/output predicates stay unchanged. The original directory reader already uses 8 GiB and is unchanged. Replacing the global historical floor would have broken this isolation; the actual copies do not do that.

Readback results bind both the original and actual reader plus an explicit scope. The second COLD transition requires the exact completed restoration and selected readback result, including both reader bindings. Adapted FNV/frame/CRC readback is never a claim that their historical 48/96 GiB current-floor check passed today. Original readers and campaign results remain preserved.

The wrappers parameterize only the selected cohort counts and declared migration budgets. Exact-byte reconstruction, publication, retirement and no-overwrite restoration primitives remain unchanged. They still record new restored inode/ctime honestly. Session accounting includes retained transaction files, a constant allowance for all restored targets outside the transaction root, interrupted decode reservations and full readback reservations.

Metadata analysis of the exact 96 selections found 12,906 distinct recorded object paths/inodes, no cross-cohort aliases and no base also selected for retirement. Every selected coexistence allowance and full two-restore/two-readback decoded scenario fits its declared cap. The largest declared migration caps are 7 GiB allocation and 70 GiB cumulative decoding; these are separate prospective migration budgets, not a current free-space qualification or benchmark policy change.

Ten new controls were read, not run. They exercise actual reader floor logic with mocked I/O at equality and one byte below, unchanged historical-budget refusal, source/policy/path equality, finite selection refusal, external allocation, interrupted reservation charging and second-COLD adapter binding. The completed single-cohort controls were not repeated.

Exact hashes and line references are in `result-first.json`; independent reader diffs and metadata accounting are retained alongside it. Root owns final commands, execution, fresh capacity and acceptance.
