"""Root-only bounded metadata control; no child or codec is launched."""
import ast,tempfile,unittest
from pathlib import Path
import run

class DispatcherReplay(unittest.TestCase):
 def test_actual_staging_gate(self):
  with tempfile.TemporaryDirectory(prefix='kv9-group-dispatch-control-')as folder:
   root=Path(folder)/'transaction'
   run.ensure_staging_phase(root)
   root.mkdir();run.ensure_staging_phase(root)
   retired=root/'retire-1';retired.mkdir()
   with self.assertRaisesRegex(RuntimeError,'retirement already begun'):run.ensure_staging_phase(root)
   retired.rmdir();retired.symlink_to(root/'missing')
   with self.assertRaisesRegex(RuntimeError,'retirement already begun'):run.ensure_staging_phase(root)
 def test_gate_precedes_actual_stage_dispatch(self):
  tree=ast.parse(Path(run.__file__).read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main')
  blocks=[n for n in ast.walk(main)if isinstance(n,ast.If)and ast.unparse(n.test)=="a.mode == 'stage-verify'"and any(isinstance(x,ast.Expr)and isinstance(x.value,ast.Call)and isinstance(x.value.func,ast.Name)and x.value.func.id=='ensure_staging_phase'for x in n.body)]
  self.assertEqual(len(blocks),1);first=blocks[0].body[0]
  self.assertEqual(ast.unparse(first),'ensure_staging_phase(root)')
  self.assertTrue(any(isinstance(x,ast.Call)and isinstance(x.func,ast.Name)and x.func.id=='step'for n in blocks[0].body[1:]for x in ast.walk(n)))
if __name__=='__main__':unittest.main(verbosity=2)
