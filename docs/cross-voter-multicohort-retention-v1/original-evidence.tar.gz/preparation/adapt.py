"""Deterministic preparation-only source adaptation; never opens object payloads."""
from pathlib import Path
import json,hashlib,difflib
P=Path(__file__).resolve().parent;O=P/'predecessor';GIB=1024**3;MIB=1024**2

def replace(s,old,new,n=1):
 assert s.count(old)==n,(old,s.count(old));return s.replace(old,new)
def write(name,s):
 (P/name).write_text(s)
 original='legacy.py' if name=='readback.py' else name
 (P/(name+'.diff')).write_text(''.join(difflib.unified_diff((O/original).read_text().splitlines(True),s.splitlines(True),fromfile='predecessor/'+original,tofile=name)))
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
g=json.loads((P/'group-plan.json').read_text())
for r in g['rows']:
 p=Path(r['selection']['path']);s=json.loads(p.read_text());l=s['limits']
 l['metadata_bytes']=((4*MIB+s['target_count']*384*1024+s['original_object_count']*48*1024+MIB-1)//MIB)*MIB
 assert l['metadata_bytes']<=128*MIB
 l['tx_allocated_bytes']=((s['maximum_patch_bytes']+l['external_restored_target_allowance_bytes']+l['scratch_reserve_bytes']+l['metadata_bytes']+l['retained_codec_bytes']+GIB-1)//GIB)*GIB
 l['launch_available_bytes']=8*GIB+l['tx_allocated_bytes']+16*MIB
 p.write_text(json.dumps(s,sort_keys=True,separators=(',',':'))+'\n');r['selection']=pin(p);r['tx_cap_bytes']=l['tx_allocated_bytes'];r['launch_available_bytes']=l['launch_available_bytes'];r['metadata_cap_bytes']=l['metadata_bytes']
g['first_cohort_qualification']=pin(P/'first-cohort-qualification.json')
(P/'group-plan.json').write_text(json.dumps(g,indent=2)+'\n')
s=(O/'common.py').read_text()
s=replace(s,'def allocated(root):','def allocated(root,metadata_cap=16*MIB):')
s=replace(s,"if metadata_total>16*MIB:raise RuntimeError('16 MiB transaction metadata allocation cap')","if metadata_total>metadata_cap:raise RuntimeError('declared transaction metadata allocation cap')")
s=replace(s,'def __init__(self, root, baseline, decoded=0):','def __init__(self, root, baseline, decoded=0, limits=None):')
s=replace(s,'self.minimum_available=None;self.maximum_allocation=0;self.guard_observations=0','self.minimum_available=None;self.maximum_allocation=0;self.guard_observations=0\n        self.limits=limits or dict(tx_allocated_bytes=4*GIB,cumulative_decoded_bytes=32*GIB,metadata_bytes=16*MIB)')
s=replace(s,'used=allocated(self.root)',"used=allocated(self.root,self.limits['metadata_bytes'])")
s=replace(s,"if used+reserve+self.external_allocation_reserve>4*GIB:raise RuntimeError('4 GiB transaction allocation cap')","if used+reserve+self.external_allocation_reserve>self.limits['tx_allocated_bytes']:raise RuntimeError('declared whole-transaction allocation cap')")
s=replace(s,"if decoded and self.decoded+limit>32*GIB:raise RuntimeError('32 GiB cumulative transaction decoded cap')","if decoded and self.decoded+limit>self.limits['cumulative_decoded_bytes']:raise RuntimeError('declared cumulative transaction decoded cap')")
write('common.py',s)
s=(O/'support.py').read_text()
s=replace(s,"a=argparse.ArgumentParser();a.add_argument('--selection-sha256',required=True)","a=argparse.ArgumentParser();a.add_argument('--selection',required=True);a.add_argument('--selection-sha256',required=True)")
s=replace(s,"need(digest(P/'selection.json')['sha256']==a.selection_sha256,'selection changed');need(digest(P/'code-pins.json')['sha256']==a.code_pins_sha256,'code manifest changed')","sp=canonical_path(a.selection);need(sp.parent==P/'selections','selection path outside finite group');need(digest(sp)['sha256']==a.selection_sha256,'selection changed');need(digest(P/'code-pins.json')['sha256']==a.code_pins_sha256,'code manifest changed')")
s=replace(s,"s=js(P/'selection.json');need(s['target_count']==80 and s['original_object_count']==150,'exact cohort scope')","s=js(sp);group=js(P/'group-plan.json');validate_selection(s,group,sp,a.selection_sha256);first_cohort_qualified(group)")
s=replace(s,'def charged_decoded(root):',"def charged_decoded(root,limit):")
s=replace(s,"root.glob('legacy-*/decode-reservation.json')","root.glob('readback-*/decode-reservation.json')")
s=replace(s,"need(decoded<=32*GIB,'cumulative decoded byte cap')","need(decoded<=limit,'cumulative decoded byte cap')")
s=replace(s,'def session(root):','def session(root,s):')
s=replace(s,'decoded=charged_decoded(root)',"decoded=charged_decoded(root,s['limits']['cumulative_decoded_bytes'])")
s=replace(s,'time.monotonic_ns()),decoded)','time.monotonic_ns()),decoded,s[\'limits\'])')
s=replace(s,"sess.external_allocation_reserve=js(P/'selection.json')['limits']['external_restored_target_allowance_bytes']","sess.external_allocation_reserve=s['limits']['external_restored_target_allowance_bytes']")
s=replace(s,'added=allocated(root);gross=',"added=allocated(root,s['limits']['metadata_bytes']);gross=")
s += '''\n\ndef validate_selection(s,group,sp,sha):
 rows=[r for r in group['rows']if r['selection']['path']==str(sp)]
 need(len(rows)==1,'selection absent/duplicate in finite group');r=rows[0]
 need(r['selection']['sha256']==sha and r['root']==s['root']and r['cohort']==s['cohort']and r['ordinal']==s['group_ordinal'],'finite selection binding')
 need(s['cohort']!=group['excluded_qualification_cohort'],'first cohort excluded')
 need(s['target_count']==r['target_count']==len(s['pairs'])and s['original_object_count']==r['original_object_count']==len(s['members']),'exact cohort counts')
 mm=members(s);need(len(mm)==len(s['members']),'duplicate original ID')
 need(len({p['id']for p in s['pairs']})==len(s['pairs'])and len({p['target']for p in s['pairs']})==len(s['pairs']),'duplicate pair/target')
 need(len({m['path']for m in s['members']})==len(s['members']),'duplicate object path')
 for pair in s['pairs']:
  need(pair['base']in mm and pair['target']in mm,'pair outside exact inventory')
  need(0<pair['patch_limit']<=128*MIB and 0<mm[pair['base']]['original']['bytes']<=128*MIB and 0<mm[pair['target']]['original']['bytes']<=128*MIB,'migration per-member bound')
 l=s['limits'];need(l['free_floor_bytes']==8*GIB and l['member_bytes']==128*MIB and l['phase_seconds']==1200 and l['legacy_seconds']==1800,'fixed runtime constraints')
 need(l['tx_allocated_bytes']==r['tx_cap_bytes']and l['cumulative_decoded_bytes']==r['cumulative_decoded_cap_bytes']and l['metadata_bytes']==r['metadata_cap_bytes'],'whole-cohort limits binding')
 need(l['metadata_bytes']<=128*MIB and l['cumulative_decoded_bytes']<=128*GIB,'bounded aggregate limits')
 need(l['tx_allocated_bytes']>=s['maximum_patch_bytes']+l['external_restored_target_allowance_bytes']+l['scratch_reserve_bytes']+l['metadata_bytes']+l['retained_codec_bytes'],'coexistence reservation')
 need(l['launch_available_bytes']==8*GIB+l['tx_allocated_bytes']+16*MIB,'launch reservation binding')
 check(s['legacy_reader']['path'],s['legacy_reader'],'original reader changed');check(s['readback_reader']['path'],s['readback_reader'],'selected readback reader changed')
 need((s['readback_scope']=='unchanged_original_directory_reader')==(s['readback_reader']==s['legacy_reader']),'honest reader representation')

def first_cohort_qualified(group):
 b=group['first_cohort_qualification'];check(b['path'],b,'first-cohort binding changed');q=js(b['path'])
 for row in q['pins']:check(row['path'],row,'actual first-cohort authority changed')
 summary=js(q['summary']['path']);terminal=js(q['terminal']['path'])
 need(summary['complete']and summary['state']=='COLD'and summary['controls_passed']==19 and summary['target_count']==80 and summary['original_object_count']==150,'first cohort incomplete')
 need(terminal['exit_code']==0 and terminal['chunk_id']=='b6ea21'and terminal['result_sha256']==q['summary']['sha256'],'actual first-cohort terminal differs')
 need(len(summary['lifetimes'])==870 and all(not r['same_lifetime_present']for r in summary['lifetimes']),'first-cohort lifetime acceptance')
 root=Path(q['root']);restored=js(root/'restore-1/result.json');legacy=js(root/'legacy-1/result.json');cold=js(root/'retire-2/result.json')
 need(restored['complete']and restored['state']=='RESTORED'and legacy['complete']and cold['complete']and cold['state']=='COLD'and cold['cycle']==2,'first complete restore/readback/COLD sequence required')
 need(legacy['restore_result_sha256']==summary['phases']['restore-1/result.json']and legacy['observed']['files']==150 and legacy['observed']['logical_bytes']==4015670348,'actual unchanged original readback binding')
 need(legacy['unchanged_reader']['sha256']=='88fe5866978679ffdb4a41cc571e0ca808d2ab8d187662b2f51669f4ca495148','original directory reader prerequisite')
'''
write('support.py',s)
for name in ['stage.py','verify.py','transition.py','legacy.py']:
 s=(O/name).read_text().replace('session(root)','session(root,s)')
 s=s.replace('==80',"==s['target_count']").replace('==150',"==s['original_object_count']")
 if name=='stage.py':
  s=s.replace('Stage exactly eighty patches','Stage the exact finite selected cohort patches')
  s=replace(s,"v.f_bavail*v.f_frsize>=12*GIB+16*MIB,'fresh 12 GiB + 16 MiB migration launch reservation'","v.f_bavail*v.f_frsize>=s['limits']['launch_available_bytes'],'fresh declared whole-cohort migration launch reservation'")
  s=replace(s,'+384*MIB+24*MIB',"+s['limits']['scratch_reserve_bytes']+s['limits']['metadata_bytes']+s['limits']['retained_codec_bytes']")
 if name=='verify.py':s=s.replace('all eighty target members','all exact selected target members')
 if name=='transition.py':
  s=s.replace('legacy_result_sha256','readback_result_sha256').replace('--legacy-result-sha256','--readback-result-sha256').replace("root/'legacy-1/result.json'","root/'readback-1/result.json'")
  s=s.replace("legacy['unchanged_reader']==s['legacy_reader']","legacy['readback_reader']==s['readback_reader']and legacy['original_reader']==s['legacy_reader']and legacy['readback_scope']==s['readback_scope']and legacy['selection_sha256']==a.selection_sha256")
  s=s.replace('unchanged-reader','selected whole-cohort reader').replace('legacy_reader_acceptance_pending','selected_reader_acceptance_pending')
 if name=='legacy.py':
  s=s.replace('Run the original whole-cohort retention reader unchanged','Run the exactly bound whole-cohort readback representation')
  s=s.replace('legacy','readback').replace('unchanged_readback','selected_readback')
  # After literal rename use explicit selected and original reader names, never relabel adapted acceptance.
  s=s.replace("s['readback_reader']","s['readback_reader']")
  s=s.replace("sess.decoded+charged<=32*GIB","sess.decoded+charged<=s['limits']['cumulative_decoded_bytes']")
  s=s.replace("selected_readback_reader=s['readback_reader']","readback_reader=s['readback_reader'],original_reader=s['legacy_reader'],readback_scope=s['readback_scope']")
  s=s.replace("unchanged_reader=s['readback_reader']","readback_reader=s['readback_reader'],original_reader=s['legacy_reader'],readback_scope=s['readback_scope']")
  s=s.replace("'Original verify() with all original", "'Selected reader verify() with all original")
  name='readback.py'
 write(name,s)
