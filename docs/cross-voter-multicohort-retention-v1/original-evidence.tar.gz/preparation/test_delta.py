"""Root-only focused metadata/mocked-I/O controls. No codec or original payload access."""
import ast,copy,hashlib,importlib.util,io,json,os,time,types,unittest
from pathlib import Path
from unittest.mock import patch
import common,support,transition
P=Path(__file__).resolve().parent

def mod(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def fake_decode(m,free=8*1024**3,data=b'abc',expected=None,exit_code=0,elapsed=0):
 # Actual adapted full_decode executes; pipes/process/files are bounded in-memory fakes.
 class Pipe:
  def __init__(self,fd):self.fd=fd
  def fileno(self):return self.fd
  def close(self):pass
 class Child:
  pid=999999999;stdout=Pipe(10);stderr=Pipe(11);returncode=exit_code
  def poll(self):return self.returncode
  def wait(self,timeout=None):return self.returncode
  def kill(self):self.returncode=-9
 class FakePath:
  parent=None
  def __init__(self,p='input'):self.p=str(p);self.parent=self
  def read_bytes(self):return b'codec'
  def read_text(self):return '1 (codec) '+' '.join(['0']*20) if self.p.endswith('/stat') else 'boot'
  def exists(self):return False
  def open(self,mode):return io.BytesIO(b'compressed')
 class Selector:
  def __init__(self):self.keys={}
  def register(self,f,event,data):self.keys[f.fd]=types.SimpleNamespace(fileobj=f,data=data)
  def unregister(self,f):del self.keys[f.fd]
  def get_map(self):return self.keys
  def select(self,timeout):return [(k,0)for k in list(self.keys.values())]
  def close(self):pass
 chunks={10:[data,b''],11:[b'']};ticks=iter([0,elapsed,elapsed,elapsed,elapsed]);obs={}
 expected=expected or dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 with patch.object(m,'Path',FakePath),patch.object(m,'validate_frame',lambda p:None),patch.object(m,'CODEC_SHA',hashlib.sha256(b'codec').hexdigest()),patch.object(m.subprocess,'Popen',lambda *a,**k:Child()),patch.object(m.selectors,'DefaultSelector',Selector),patch.object(m.shutil,'disk_usage',lambda p:types.SimpleNamespace(free=free)),patch.object(m.os,'read',lambda fd,n:chunks[fd].pop(0)),patch.object(m.os,'sched_getaffinity',lambda pid:set(m.CPUS)),patch.object(m.time,'monotonic',lambda:next(ticks)):
  m.full_decode(FakePath(),expected,obs)
 return obs

class ReaderDelta(unittest.TestCase):
 def test_exact_floor_only_source_delta(self):
  for label in ['fnv-writer','frame-buffer-crc','crc-full-regression']:
   old=(P/'original-readers'/f'{label}.py').read_text();new=(P/'readers'/f'{label}.py').read_text()
   before={x.name:ast.dump(x,include_attributes=False)for x in ast.parse(old).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
   after={x.name:ast.dump(x,include_attributes=False)for x in ast.parse(new).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
   self.assertEqual(set(before),set(after));self.assertEqual({k:v for k,v in before.items()if k!='full_decode'},{k:v for k,v in after.items()if k!='full_decode'})
   normalized=new.replace("check(free>=READBACK_AVAILABLE_FLOOR_BYTES,'decode retention floor')","check(free>=LIMITS['retention_floor_bytes'],'decode retention floor')")
   full=next(x for x in ast.parse(normalized).body if isinstance(x,ast.FunctionDef)and x.name=='full_decode')
   self.assertEqual(before['full_decode'],ast.dump(full,include_attributes=False))
   m=mod(label,P/'readers'/f'{label}.py');o=mod('old_'+label,P/'original-readers'/f'{label}.py')
   self.assertEqual(m.LIMITS,o.LIMITS)
   for key in ['CODEC','CODEC_SHA','COHORT_ROOTS','STORAGE_POLICY','STORAGE_POLICY_SHA']:
    if hasattr(o,key):self.assertEqual(getattr(m,key),getattr(o,key))
 def test_current_floor_boundaries(self):
  for label in ['fnv-writer','frame-buffer-crc','crc-full-regression']:
   m=mod(label,P/'readers'/f'{label}.py')
   self.assertTrue(fake_decode(m)['complete'])
   with self.assertRaisesRegex(ValueError,'decode retention floor'):fake_decode(m,free=8*1024**3-1)
 def test_other_decode_rejections(self):
  m=mod('fnv',P/'readers/fnv-writer.py')
  for expected in [dict(bytes=3,sha256='0'*64),dict(bytes=4,sha256=hashlib.sha256(b'abc').hexdigest()),dict(bytes=2,sha256=hashlib.sha256(b'abc').hexdigest())]:
   with self.assertRaises(ValueError):fake_decode(m,expected=expected)
  with self.assertRaisesRegex(ValueError,'deadline'):fake_decode(m,elapsed=601)
  with self.assertRaisesRegex(ValueError,'decoder failure'):fake_decode(m,exit_code=1)
 def test_historical_budget_floor_stays_active(self):
  for label in ['fnv-writer','frame-buffer-crc','crc-full-regression']:
   m=mod(label,P/'readers'/f'{label}.py');tree=ast.parse((P/'readers'/f'{label}.py').read_text());verify=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='verify')
   predicate=next(x for x in verify.body if isinstance(x,ast.Expr)and isinstance(x.value,ast.Call)and any(isinstance(a,ast.Constant)and a.value=='retention space guard evidence'for a in x.value.args))
   run=compile(ast.fix_missing_locations(ast.Module(body=[predicate],type_ignores=[])),'actual historical predicate','exec')
   floor=m.LIMITS['retention_floor_bytes'];env=dict(check=m.check,LIMITS=m.LIMITS,budget=dict(complete=True,minimum_available_bytes=floor,samples=[dict(available_bytes=floor,allocated_bytes=0)]));exec(run,env)
   env['budget']['samples'][0]['available_bytes']=8*1024**3
   with self.assertRaises(ValueError):exec(run,env)
 def test_path_and_policy_guards_unchanged(self):
  m=mod('fnv',P/'readers/fnv-writer.py')
  with self.assertRaises(ValueError):m.name_ok('../x')
  with self.assertRaises(ValueError):m.unique_pairs([('x',1),('x',2)])
  d=dict(storage_policy=copy.deepcopy(m.STORAGE_POLICY),storage_policy_sha256=m.STORAGE_POLICY_SHA);m.check_storage_policy(d)
  d['storage_policy']['post_run']['host_floor_bytes']=8*1024**3
  with self.assertRaises(ValueError):m.check_storage_policy(d)

class SelectionAndAccounting(unittest.TestCase):
 def setUp(self):
  self.g=json.loads((P/'group-plan.json').read_text());self.r=self.g['rows'][0];self.sp=Path(self.r['selection']['path']);self.s=json.loads(self.sp.read_text());self.sha=self.r['selection']['sha256']
 def call(self,s=None,g=None):
  # Source-file hash checks are separately pinned; isolate exact manifest predicates here.
  with patch.object(support,'check',lambda *a:None):support.validate_selection(s or self.s,g or self.g,self.sp,self.sha)
 def test_exact_selected_manifest(self):self.call()
 def test_finite_selection_rejections(self):
  for mutate in [lambda s:s.update(root=s['root']+'-wrong'),lambda s:s.update(cohort=self.g['excluded_qualification_cohort']),lambda s:s.update(target_count=s['target_count']-1),lambda s:s['pairs'].pop(),lambda s:s['members'].pop(),lambda s:s['pairs'].append(s['pairs'][0]),lambda s:s['limits'].update(tx_allocated_bytes=4*1024**3),lambda s:s.update(readback_scope='unchanged_original_directory_reader')]:
   s=copy.deepcopy(self.s);mutate(s)
   with self.assertRaises((RuntimeError,KeyError)):self.call(s=s)
  g=copy.deepcopy(self.g);g['rows'].pop(0)
  with self.assertRaises(RuntimeError):self.call(g=g)
 def test_whole_transaction_external_allocation(self):
  limits=dict(self.s['limits']);sess=common.Session(P,dict(device=P.stat().st_dev,started_monotonic_ns=time.monotonic_ns()),0,limits);sess.external_allocation_reserve=limits['external_restored_target_allowance_bytes']
  with patch.object(common,'allocated',lambda *a:limits['tx_allocated_bytes']-sess.external_allocation_reserve),patch.object(common.os,'statvfs',lambda p:types.SimpleNamespace(f_bavail=100*1024**3,f_frsize=1)):
   sess.guard()
   with self.assertRaisesRegex(RuntimeError,'allocation cap'):sess.guard(1)
 def test_cumulative_reservations_and_readback_charge(self):
  # Real reconciliation helper, fake finite metadata paths; never scans a transaction.
  intent=Path('/intent.child-intent.json');reservation=Path('/readback/decode-reservation.json')
  class Root:
   def rglob(self,p):return [intent]
   def glob(self,p):return [reservation]if 'readback' in p else []
  docs={str(intent):dict(decoded=True,reserved_decoded_bytes=17),str(reservation):dict(charged_decoded_bytes=23)}
  with patch.object(support,'js',lambda p:docs[str(p)]),patch.object(Path,'exists',lambda p:False):
   self.assertEqual(support.charged_decoded(Root(),40),40)
   with self.assertRaisesRegex(RuntimeError,'cumulative'):support.charged_decoded(Root(),39)
 def test_second_cold_binds_actual_adapter(self):
  a=types.SimpleNamespace(restore_result_sha256='restore',readback_result_sha256='reader',selection_sha256=self.sha,release_verified_sha256='verified');root=Path('/fake')
  restored=dict(complete=True,state='RESTORED',selection_sha256=self.sha,verified_sha256='verified',rows=[dict(id=p['target'],identity={})for p in self.s['pairs']])
  reader=dict(complete=True,restore_result_sha256='restore',selection_sha256=self.sha,readback_reader=self.s['readback_reader'],original_reader=self.s['legacy_reader'],readback_scope=self.s['readback_scope'])
  def run(doc):
   with patch.object(transition,'digest',lambda p:dict(sha256='restore'if 'restore-1'in str(p)else'reader')),patch.object(transition,'js',lambda p:restored if 'restore-1'in str(p)else doc):return transition.second_cycle_gate(self.s,root,a)
  self.assertEqual(len(run(reader)),self.s['target_count'])
  for key,val in [('complete',False),('readback_reader',self.s['legacy_reader']),('original_reader',{}),('readback_scope','unchanged_original_directory_reader'),('restore_result_sha256','wrong'),('selection_sha256','wrong')]:
   d=copy.deepcopy(reader);d[key]=val
   with self.assertRaises(RuntimeError):run(d)

if __name__=='__main__':unittest.main(verbosity=2)
