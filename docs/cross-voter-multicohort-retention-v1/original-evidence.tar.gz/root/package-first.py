"""Package completed migration source and original reporting, excluding WAL payloads."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
PREP = Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first')
TX = Path('/tmp/kv9-cross-voter-group-000-fnv-writer-20260915-first')
REVIEW = Path('/tmp/kv9-cross-voter-multicohort-policy-review-20260915-first')
OUT = Path('/home/dongxu/kv9/docs/cross-voter-multicohort-retention-v1')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

summary = json.loads((ROOT / 'group-000-accepted-summary.json').read_bytes())
assert summary['complete'] and summary['state'] == 'COLD'
inputs = {}
def add(name, source):
    assert name not in inputs
    st = source.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_size <= 16 * 1024**2
    inputs[name] = source

for prefix, folder in [('preparation', PREP), ('review', REVIEW), ('root', ROOT), ('execution', Path('/tmp/kv9-cross-voter-multicohort-execution-20260915-first'))]:
    for source in sorted(folder.rglob('*')):
        if source.is_file():
            assert not source.is_symlink()
            assert source.suffix not in ('.raw', '.zst', '.pyc')
            add(prefix + '/' + source.relative_to(folder).as_posix(), source)
for source in sorted(TX.rglob('*')):
    if source.is_file() and source.suffix in ('.json', '.stderr', '.lock'):
        add('transaction/' + source.relative_to(TX).as_posix(), source)
selection = json.loads((PREP / 'selections/000.json').read_bytes())
for group in ['metadata', 'authorities', 'exact_object_qualification']:
    for index, entry in enumerate(selection[group]):
        source = Path(entry['path'])
        assert sha(source.read_bytes()) == entry['sha256']
        add(f'original-inputs/{group}/{index:03d}-{source.name}', source)
inventory = []
total = 0
with (OUT / 'original-evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for name, source in sorted(inputs.items()):
                before = source.stat()
                data = source.read_bytes()
                after = source.stat()
                assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                total += len(data)
                assert total <= 128 * 1024**2
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o644
                item.mtime = 0
                archive.addfile(item, io.BytesIO(data))
                inventory.append(dict(name=name, source=str(source), bytes=len(data), sha256=sha(data)))
save(OUT / 'input-inventory.json', inventory)
manifest = dict(complete=True, members=len(inventory), logical_bytes=total,
    archive_bytes=(OUT / 'original-evidence.tar.gz').stat().st_size,
    archive_sha256=sha((OUT / 'original-evidence.tar.gz').read_bytes()),
    inventory_sha256=sha((OUT / 'input-inventory.json').read_bytes()),
    scope='Exact original source and reporting. Original base objects, patches and retained executable payloads remain local; this archive alone cannot restore WAL objects.')
save(OUT / 'manifest.json', manifest)
print(json.dumps(manifest))
