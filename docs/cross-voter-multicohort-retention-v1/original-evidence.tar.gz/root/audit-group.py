"""Independent completed-group audit; no codec or database execution."""
import argparse, hashlib, json, sys, time
from pathlib import Path

P=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first')
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import support as q
import run as dispatcher

ap=argparse.ArgumentParser()
ap.add_argument('--ordinal',type=int,required=True)
ap.add_argument('--finish-tool-sha256',required=True)
a=ap.parse_args()
graw=(P/'group-plan.json').read_bytes()
assert hashlib.sha256(graw).hexdigest()=='e0e9956c1334149ded0f23f2989f90e2ef54d3510a25293d30f1d5b7d66a86de'
group=json.loads(graw);row=group['rows'][a.ordinal]
q.check(row['selection']['path'],row['selection'])
s=q.js(row['selection']['path']);tx=Path(s['root'])
terminal_path=ROOT/f'group-{a.ordinal:03d}-finish-tool-terminal.json'
assert q.digest(terminal_path)['sha256']==a.finish_tool_sha256
terminal=q.js(terminal_path)
assert terminal['exit_code']==0 and terminal['result_path']==str(tx/'retire-2/result.json')
assert q.digest(tx/'retire-2/result.json')['sha256']==terminal['result_sha256']
mm=q.members(s);targets={x['target'] for x in s['pairs']}
assert len(targets)==s['target_count'] and len(mm)==s['original_object_count']
results={};phase_hashes={}
for name in ['staged.json','verification-first/result.json','retire-1/result.json','restore-1/result.json','readback-1/result.json','retire-2/result.json']:
    data=(tx/name).read_bytes();result=json.loads(data)
    assert result['complete'] and result['selection_sha256']==row['selection']['sha256']
    results[name]=result;phase_hashes[name]=hashlib.sha256(data).hexdigest()
stage=results['staged.json'];verified=results['verification-first/result.json']
restored=results['restore-1/result.json'];reader=results['readback-1/result.json'];cold=results['retire-2/result.json']
assert verified['staged_sha256']==phase_hashes['staged.json']
assert restored['verified_sha256']==cold['verified_sha256']==phase_hashes['verification-first/result.json']
assert reader['restore_result_sha256']==phase_hashes['restore-1/result.json']
assert reader['readback_reader']==s['readback_reader'] and reader['original_reader']==s['legacy_reader'] and reader['readback_scope']==s['readback_scope']
for result in [stage,verified,restored]:
    assert result['all_children_reaped'] and len(result['rows'])==len(targets) and {x['id'] for x in result['rows']}==targets
for x in verified['rows']:
    assert x['decoded_to_eof'] and x['original_compressed_exact']
    assert x['original']==mm[x['id']]['original'] and x['compressed']==mm[x['id']]['compressed']
assert reader['observed']['files']==s['original_object_count']
assert reader['observed']['logical_bytes']==s['logical_cohort_bytes'] and reader['observed']['compressed_bytes']==s['encoded_cohort_bytes']
assert cold['state']=='COLD' and cold['cycle']==2 and len(cold['rows'])==len(targets)
assert all(q.absent(Path(mm[key]['path'])) for key in targets)
for x in stage['rows']:q.check_patch(tx,x)
q.preserved(s);q.no_references(s);q.no_codec_processes(s)
preserved=[]
for key,m in mm.items():
    if key in targets:continue
    path=Path(m['path']);before=q.identity(path)
    assert before==m['identity'] and before['bytes']==m['compressed']['bytes']<=8*1024**3
    h=hashlib.sha256();count=0
    with path.open('rb') as stream:
        while block:=stream.read(1024**2):h.update(block);count+=len(block)
    assert q.identity(path)==before
    assert count==m['compressed']['bytes'] and h.hexdigest()==m['compressed']['sha256']
    preserved.append(dict(id=key,bytes=count,sha256=h.hexdigest()))
children=[c for x in stage['rows'] for c in x['children']]+verified['children']+restored['children']+reader['decoder_receipts']
expected_codecs=9*s['target_count']+s['original_object_count']
assert len(children)==expected_codecs
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();lifetimes=[]
for c in children:
    assert c['exit_code']==0 and (c.get('reaped') or c.get('absent'))
    same=False
    try:
        data=(Path('/proc')/str(c['pid'])/'stat').read_text()
        same=boot==c['boot_id'] and int(data[data.rfind(')')+2:].split()[19])==c['start_ticks']
    except FileNotFoundError:pass
    assert not same
    lifetimes.append(dict(pid=c['pid'],start_ticks=c['start_ticks'],boot_id=c['boot_id'],same_lifetime_present=same))
for c in verified['children']+restored['children']:
    assert c['argv'][0]==str(tx/'toolchain/ld-linux-x86-64.so.2')
accounting=dispatcher.account(group)
assert accounting['complete'] and not accounting['incomplete_or_restored_cohorts']
report=dict(complete=True,ordinal=a.ordinal,state='COLD',selection_sha256=row['selection']['sha256'],phase_hashes=phase_hashes,finish_tool_sha256=a.finish_tool_sha256,targets=s['target_count'],objects=s['original_object_count'],logical_bytes=s['logical_cohort_bytes'],encoded_bytes=s['encoded_cohort_bytes'],patch_bytes=sum(x['patch']['pin']['bytes'] for x in stage['rows']),codec_lifetimes=lifetimes,preserved_objects=preserved,charged_decoded_bytes=q.charged_decoded(tx,s['limits']['cumulative_decoded_bytes']),readback_scope=s['readback_scope'],original_reader=s['legacy_reader'],readback_reader=s['readback_reader'],accounting=accounting,all_original_metadata_unchanged=True,new_database_benchmark=False,observed_ns=time.time_ns())
q.durable_json(ROOT/f'group-{a.ordinal:03d}-accepted-summary.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ['codec_lifetimes','preserved_objects','phase_hashes']}))
