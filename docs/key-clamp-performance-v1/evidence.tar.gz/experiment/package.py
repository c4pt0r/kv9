#!/usr/bin/env python3
"""Retain new qualification, failed setup and complete accepted three-arm screen."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

R=Path('/home/dongxu/kv9');S=Path(__file__).resolve().parent
T=Path('/mnt/data/kv9-work/key-clamp-qualification-20260916-first')
F=Path('/mnt/data/kv9-work/key-clamp-performance-20260916-first')
O=R/'docs/key-clamp-performance-v1';O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
a=load(S/'analysis.json');assert a['complete'] and not a['stage_one_gate_passed'] and a['processes']==78
assert load(T/'qualification-audit.json')['complete']
assert len(list((S/'runs').glob('*-terminal.json')))==78
members={};excluded=[]
for prefix,root in [('experiment',S),('qualification',T),('failed-preparation',F)]:
    for p in sorted(root.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:continue
        if p.name in ('groups.bin','continuation.json') or p.name.endswith('-progress.json') or p.name.startswith('issue9'):continue
        relative=prefix+'/'+str(p.relative_to(root))
        with p.open('rb') as f:magic=f.read(4)
        if magic==b'\x7fELF' or p.suffix=='.olean':excluded.append(relative);continue
        members[relative]=p
for directory in ['scripts/key-clamp','scripts/key-clamp-performance','proofs/lean/key-clamp']:
    for p in sorted((R/directory).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:members['repo/'+str(p.relative_to(R))]=p
members['repo/scripts/build_cache.py']=R/'scripts/build_cache.py'
records=[];archive=O/'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,p in sorted(members.items()):
                assert not p.is_symlink();data=p.read_bytes();info=tar.gettarinfo(str(p),arcname=name)
                info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
                with p.open('rb') as f:tar.addfile(info,f)
                records.append(dict(path=name,bytes=len(data),sha256=sha(data)))
with tarfile.open(archive,'r:gz') as tar:
    assert tar.getnames()==[r['path'] for r in records]
    for r in records:
        b=tar.extractfile(r['path']).read();assert len(b)==r['bytes'] and sha(b)==r['sha256']
manifest=dict(complete=True,members=len(records),expanded_bytes=sum(r['bytes'] for r in records),compressed_bytes=archive.stat().st_size,
              sha256=sha(archive.read_bytes()),all_members_read_back=True,local_roots={'accepted':str(S),'qualification':str(T),'failed_preparation':str(F)},
              accepted_processes=78,timing_rows=48,allocation_rows=24,failed_preparation_processes=1,failed_attempt_timing_rows=0,
              stage_one_gate_passed=False,stage_two='not run; stopped by declared write gate',production_promoted=False,
              excluded_binaries_and_lean_objects=excluded,other_exclusions=['Duplicate corpus','Mutable progress/continuation/GitHub payloads and Python caches'],
              external=dict(corpus='../outlined-mutation-path-v1/evidence.tar.gz:outlined/groups.bin',corpus_sha256='d978ba9e49131f6277f975ecd333c33854845cc03bd14ee57a22fff915a08350',
                            unchanged_qualification='../entry-buffer-qualification-v1/evidence.tar.gz',qualification_sha256='401e3194629ef3138736df1d2b08f12067a9cb2d523a3613fe4b6e92a50cb2fa',
                            prior_codegen_and_plan='../entry-buffer-performance-v1/evidence.tar.gz',prior_performance_sha256='93931fa137c702f53b81f6a87af4a2ba42252a60de2eb6b0d23b4056c8514db5'),
              accepted_binaries=load(S/'build-summary.json')['arms'])
for name,data in [('manifest.json',manifest),('members.json',records)]:
    (O/name).write_text(json.dumps(data,indent=2)+'\n')
for name in ['plan.json','declared-plan.json','analysis.json','allocation-analysis.json','radix-topology.json','next-radix-plan.json']:
    shutil.copyfile(S/name,O/name)
shutil.copyfile(T/'qualification-audit.json',O/'qualification-audit.json')
(O/'README.md').write_text(f'''# Safe-accessor qualification and write-screen evidence

See the [report](../KEY-CLAMP-PERFORMANCE.md). Qualification and accounting pass;
the write-selection gate fails. Read/range timing is not run; production stays
unchanged.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['sha256']}`.
All sizes/hashes passed member readback; [members.json](members.json) and
[manifest.json](manifest.json) record exact provenance and excluded local binaries.

`qualification/` retains the changed candidate workspace, source bindings,
206-test output, 26-theorem/15-control proof, 198 allocation observations and
audit. The source-checked unchanged baseline/control evidence is external below.
`failed-preparation/` retains the initial six builds, first configuration-guard
failure and exact pre-fix tools. It produced no workload or timing samples.
`experiment/` retains the six corrected builds, comparator excerpts, all 78
accepted workload launches/terminals and outputs, raw timing/count windows,
independent analyses and the exact two-guard correction audit.

The [earlier qualification](../entry-buffer-qualification-v1/README.md) supplies
unchanged baseline/control sources and reusable tests. The
[earlier single-buffer packet](../entry-buffer-performance-v1/README.md) supplies
the original codegen control and declared next plan. The corpus is
`outlined/groups.bin` in the [outlined packet](../outlined-mutation-path-v1/README.md).
Manifest hashes bind these inputs. Reproduction starts from `b23506d` and the
recorded paths, or an explicitly identified fresh attempt.

The [radix census](radix-topology.json) checks static topology only. The
[next radix plan](next-radix-plan.json) is prospective: no Rust radix implementation,
algorithm proof, timing or speedup exists. No new database/Redis, MinIO/recovery,
actual Chaos acceptance or industrial checklist closure is included.
''')
print(json.dumps({k:v for k,v in manifest.items() if k not in ('accepted_binaries','excluded_binaries_and_lean_objects')}))
