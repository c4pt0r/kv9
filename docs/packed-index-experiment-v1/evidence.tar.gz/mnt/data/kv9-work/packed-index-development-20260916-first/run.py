#!/usr/bin/env python3
import hashlib,json,shutil,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/'runs-first';O.mkdir(exist_ok=False)
build=json.loads((R/'benchmark-build-corrected/result.json').read_text());assert build['complete']
assert hashlib.sha256((R/'timing-plan.json').read_bytes()).hexdigest()=='3026df446336396134dba2135b407a8a4f54e4ca4195e7fc3024405904fb024a'
for path,digest in build['sources'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
for mode in ('timing','allocations'):
 pin=build['artifacts'][mode];assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
 free={p:shutil.disk_usage(p).free for p in ('/home/dongxu/kv9','/mnt/data')};assert min(free.values())>=8*1024**3
 argv=['taskset','-c','4',pin['path'],str(R),str(O/(mode+'.json'))]
 rec=dict(complete=False,argv=argv,binary_sha256=pin['sha256'],started_ns=time.time_ns(),free_bytes=free,loadavg=Path('/proc/loadavg').read_text().strip(),cpu=4,cpu_siblings=Path('/sys/devices/system/cpu/cpu4/topology/thread_siblings_list').read_text().strip(),shared_host=True)
 with (O/(mode+'.stdout')).open('x') as out,(O/(mode+'.stderr')).open('x') as err:
  p=subprocess.Popen(argv,stdout=out,stderr=err);rec['pid']=p.pid;(O/(mode+'-launch.json')).write_text(json.dumps(rec,indent=2)+'\n')
  try:
   rec['exit_code']=p.wait(timeout=900)
   if rec['exit_code']==0:
    data=(O/(mode+'.json')).read_bytes();assert len(data)<=8*1024**2;result=json.loads(data);assert result['complete'] and len(result['rows'])==56 and result['counting_build']==(mode=='allocations')
    assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256'];rec.update(complete=True,result_bytes=len(data),result_sha256=hashlib.sha256(data).hexdigest())
  finally:
   rec['ended_ns']=time.time_ns();(O/(mode+'-terminal.json')).write_text(json.dumps(rec,indent=2)+'\n')
 assert rec['complete'],rec
 print(json.dumps(rec),flush=True)
