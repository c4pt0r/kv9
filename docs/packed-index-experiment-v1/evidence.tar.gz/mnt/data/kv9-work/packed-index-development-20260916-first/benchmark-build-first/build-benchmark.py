#!/usr/bin/env python3
import hashlib,importlib.util,json,os,shutil,time,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent;B=Path('/home/dongxu/kv9/scripts/resident-packed');O=R/'benchmark-build-first';O.mkdir(exist_ok=False)
os.environ['CARGO_TARGET_DIR']='/home/dongxu/kv9/target';os.environ['CARGO_BUILD_JOBS']='4'
assert not os.environ.get('RUSTFLAGS') and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p):sha(p)for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]}
qualified=json.loads((R/'qualification-corrected/result.json').read_text());assert qualified['complete']
for name in ('src/lib.rs','src/tests.rs'):assert sources[str(B/name)]==qualified['sources'][str(B/name)]
for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]:
 dst=O/'source'/p.relative_to(B);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
spec=importlib.util.spec_from_file_location('cache','/home/dongxu/kv9/scripts/build_cache.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result=dict(complete=False,started_ns=time.time_ns(),sources=sources,qualified_library_and_tests_unchanged=True,artifacts={})
try:
 with m.BuildCache(B,O,True,sources) as cache:
  for mode,features in [('timing',[]),('allocations',['--features','allocation-counting'])]:
   with (O/(mode+'-clippy.stdout')).open('x') as out,(O/(mode+'-clippy.stderr')).open('x') as err:cache.run(['cargo','clippy','--offline','--locked','--release','--all-targets',*features,'--','-D','warnings'],stdout=out,stderr=err,timeout=900)
   argv=['cargo','build','--offline','--locked','--release','--bin','kv9-packed-index-experiment','--message-format','json-render-diagnostics',*features]
   with (O/(mode+'.jsonl')).open('x') as out,(O/(mode+'.stderr')).open('x') as err:cache.run(argv,stdout=out,stderr=err,timeout=900)
   cache.check_artifacts(O/(mode+'.jsonl'))
   source=Path('/home/dongxu/kv9/target/release/kv9-packed-index-experiment');binary=O/('packed-'+mode);shutil.copyfile(source,binary);binary.chmod(0o755)
   result['artifacts'][mode]=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary),argv=argv)
 assert sources=={str(p):sha(p)for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]}
 result['complete']=True
except BaseException as e:result['failure']=repr(e);raise
finally:
 result['ended_ns']=time.time_ns();(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
