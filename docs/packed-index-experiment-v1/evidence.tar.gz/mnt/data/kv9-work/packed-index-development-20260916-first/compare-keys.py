#!/usr/bin/env python3
import hashlib,importlib.util,json,os,shutil,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent;B=Path('/home/dongxu/kv9/scripts/resident-packed');O=R/'key-comparison-first';O.mkdir(exist_ok=False)
os.environ['CARGO_TARGET_DIR']='/home/dongxu/kv9/target';os.environ['CARGO_BUILD_JOBS']='4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources={str(p):sha(p)for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]}
spec=importlib.util.spec_from_file_location('cache','/home/dongxu/kv9/scripts/build_cache.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result=dict(complete=False,started_ns=time.time_ns(),sources=sources,input_sha256=sha(R/'key-comparison-input.json'))
try:
 with m.BuildCache(B,O,True,sources) as cache:
  with (O/'clippy.stdout').open('x') as out,(O/'clippy.stderr').open('x') as err:cache.run(['cargo','clippy','--offline','--locked','--release','--bin','key-comparisons','--','-D','warnings'],stdout=out,stderr=err)
  with (O/'build.jsonl').open('x') as out,(O/'build.stderr').open('x') as err:cache.run(['cargo','build','--offline','--locked','--release','--bin','key-comparisons','--message-format','json-render-diagnostics'],stdout=out,stderr=err)
  cache.check_artifacts(O/'build.jsonl');binary=O/'key-comparisons';shutil.copyfile('/home/dongxu/kv9/target/release/key-comparisons',binary);binary.chmod(0o755)
  result['binary_sha256']=sha(binary)
  with (O/'run.stdout').open('x') as out,(O/'run.stderr').open('x') as err:
   p=subprocess.run(['taskset','-c','4',str(binary),str(R/'key-comparison-input.json'),str(O/'comparisons.json')],stdout=out,stderr=err,timeout=120)
  result['exit_code']=p.returncode;assert p.returncode==0
 assert all(sha(Path(p))==digest for p,digest in sources.items());result['complete']=True
except BaseException as e:result['failure']=repr(e);raise
finally:
 result['ended_ns']=time.time_ns();(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
