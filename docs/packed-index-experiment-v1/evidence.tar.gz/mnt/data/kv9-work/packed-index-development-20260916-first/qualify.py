#!/usr/bin/env python3
import hashlib,importlib.util,json,os,shutil,subprocess,time,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent;B=Path('/home/dongxu/kv9/scripts/resident-packed');O=R/'qualification-corrected';O.mkdir(exist_ok=False)
os.environ['CARGO_TARGET_DIR']='/home/dongxu/kv9/target';os.environ['CARGO_BUILD_JOBS']='4'
assert not os.environ.get('RUSTFLAGS') and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def registry(lock):return {(p['name'],p['version'],p['source']):p['checksum']for p in tomllib.loads(lock.read_text())['package']if p.get('source','').startswith('registry+')}
result=dict(complete=False,started_ns=time.time_ns());commands=[]
def run(argv,name,timeout=600):
 with (O/(name+'.stdout')).open('x') as out,(O/(name+'.stderr')).open('x') as err:
  x=subprocess.run(argv,cwd=B,stdout=out,stderr=err,timeout=timeout)
 commands.append(dict(argv=argv,exit_code=x.returncode));assert x.returncode==0,name
try:
 run(['cargo','metadata','--offline','--format-version','1'],'metadata')
 original=registry(Path('/home/dongxu/kv9/Cargo.lock'));resolved=registry(B/'Cargo.lock');assert all(original.get(k)==v for k,v in resolved.items())
 sources={str(p):sha(p)for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]};result['sources']=sources
 for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]:
  dst=O/'source'/p.relative_to(B);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 spec=importlib.util.spec_from_file_location('cache','/home/dongxu/kv9/scripts/build_cache.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 with m.BuildCache(B,O,True,sources) as cache:
  argv=['cargo','test','--offline','--locked','--release','--lib','--no-run','--message-format','json-render-diagnostics']
  with (O/'test-build.jsonl').open('x') as out,(O/'test-build.stderr').open('x') as err:cache.run(argv,stdout=out,stderr=err,timeout=900)
  cache.check_artifacts(O/'test-build.jsonl')
  artifacts=[json.loads(s)for s in (O/'test-build.jsonl').read_text().splitlines()];test=[a for a in artifacts if a.get('executable') and a.get('profile',{}).get('test')];assert len(test)==1
  binary=O/'packed-tests';shutil.copyfile(test[0]['executable'],binary);binary.chmod(0o755);result['test_binary']=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary))
  run(['taskset','-c','6',str(binary),'--test-threads=1'],'tests',900)
  assert '6 passed; 0 failed' in (O/'tests.stdout').read_text()
  with (O/'clippy.stdout').open('x') as out,(O/'clippy.stderr').open('x') as err:cache.run(['cargo','clippy','--offline','--locked','--release','--all-targets','--','-D','warnings'],stdout=out,stderr=err,timeout=900)
 assert sources=={str(p):sha(p)for p in [B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]}
 result.update(complete=True,tests_passed=6,registry_packages=len(resolved))
except BaseException as e:result['failure']=repr(e);raise
finally:
 result.update(commands=commands,ended_ns=time.time_ns());(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
