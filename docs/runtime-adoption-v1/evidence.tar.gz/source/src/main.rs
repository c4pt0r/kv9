//! kv9 — the single binary (DESIGN §1 goal 2, §11).
//!
//! One `kv9` executable is *every* role: storage node, metadata member, request router.
//! This entry point parses the node CLI (`--node-id`, `--join`, `--data-dir`, `--addr`)
//! and wires a [`kv9_server::NodeRuntime`]. Txn groups are deliberately NOT a CLI flag:
//! a txn group is a TSO shard *inside a keyspace* (DESIGN §3.6 "Txn group (a TSO
//! shard inside a keyspace)"), declared per keyspace at
//! `CREATE KEYSPACE ... [, txn_group = <g>]` (§3.2) and stored in the `txn_groups`
//! catalog table keyed by `keyspace_id`.

use std::collections::HashSet;
use std::fs;
use std::net::SocketAddr;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

use kv9_common::{
    load_root_bundle, persist_root_bundle, write_new_root_descriptor, ApiType, BootstrapGeneration,
    ClusterId, Config, NodeId, RootDescriptor, RootVoter, SeedPeer, StoreIdentity,
    StoreIncarnation, ROOT_DESCRIPTOR_FILE, STORE_IDENTITY_FILE,
};
use kv9_server::{
    admit_node_blocking, create_keyspace_blocking, promote_node_blocking, NodeRuntime, RawClient,
    RawClientOutcome, RuntimeAuth,
};

mod data_group_cli;
mod endpoint_cli;
mod retention_cli;

// Confined to the Linux kv9 binary: library users and benchmark clients retain
// their own allocator. No Raft, storage, admission or scheduling policy changes.
#[cfg(target_os = "linux")]
#[global_allocator]
static ALLOCATOR: tikv_jemallocator::Jemalloc = tikv_jemallocator::Jemalloc;

/// Parsed CLI arguments (DESIGN §11).
#[derive(Debug, Default)]
struct Cli {
    node_id: Option<NodeId>,
    addr: Option<String>,
    advertise_addr: Option<String>,
    data_dir: Option<String>,
    join: Vec<SeedPeer>,
    cluster_id: Option<ClusterId>,
    data_workers: Option<usize>,
}

fn print_usage() {
    eprintln!(
        "kv9 — single-binary distributed KV\n\
         \n\
         USAGE:\n\
           kv9 store-prepare --node-id <id> --data-dir <path>\n\
           KV9_BOOTSTRAP_TOKEN=<token> kv9 root-create --output <file> --voters <id@ip:port,...> --store-incarnations <id=hex,...>\n\
           KV9_BOOTSTRAP_TOKEN=<token> kv9 init --root <file> --node-id <id> --data-dir <path>\n\
           KV9_JOIN_TICKET=<ticket> kv9 join --root <file> --node-id <id> --addr <ip:port> --data-dir <path>\n\
           KV9_OBJECT_STORE_*=... kv9 install-migration-image --data-dir <stopped-store> --record-file <path>\n\
           KV9_CLUSTER_TOKEN=<token> KV9_CLIENT_TOKENS=<principal=token,...> kv9 start --node-id <id> --addr <ip:port> --data-dir <path> [--data-workers <1..=32>]\n\
           KV9_CLIENT_TOKEN=<token> kv9 client create-keyspace --addr <ip:port> --name <name> --api-type <txn|raw> [--tenant-id <id>]\n\
           KV9_CLIENT_TOKEN=<token> kv9 client create-data-group --addr <leader-ip:port> --root-digest <hex> --operation-id <hex> --voters <id,id,id>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client create-data-keyspace --addr <leader-ip:port> --root-digest <hex> --creation-task <id> --name <name> [--tenant-id <id>]\n\
           KV9_CLIENT_TOKEN=<token> kv9 client migrate-data-group --addr <leader-ip:port> --root-digest <hex> --operation-id <hex> --creation-task <id> --destination-node <id>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client bind-migration-image --addr <leader-ip:port> --root-digest <hex> --operation-id <hex> --manifest-file <path>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client attach-migration-learner --addr <group-leader-ip:port> --root-digest <hex> --operation-id <hex>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client plan-migration-image --addr <group-leader-ip:port> --root-digest <hex> --operation-id <hex> --manifest-file <path>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client capture-migration-image --addr <group-leader-ip:port> --root-digest <hex> --operation-id <hex> --record-file <path>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client admit-node --addr <leader-ip:port> --node-id <id> --node-addr <ip:port> [--ttl-seconds <seconds>]\n\
           KV9_CLIENT_TOKEN=<token> kv9 client promote-node --addr <leader-ip:port> --node-id <id>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client get-node-endpoint --addr <leader-ip:port> --node-id <id>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client retention-apply --addr <leader-ip:port> --root-digest <hex> --request-file <path>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client retention-owner --addr <leader-ip:port> --root-digest <hex> --owner-id <hex>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client change-node-endpoint --addr <leader-ip:port> --cluster-id <hex> --node-id <id> --store-incarnation <hex> --expected-address <ip:port> --expected-generation <n> --new-address <ip:port>\n\
           KV9_CLIENT_TOKEN=<token> kv9 client raw-put --addr <leader-ip:port> --keyspace <id> --key-hex <hex> --value-hex <hex>\n\\
           KV9_CLIENT_TOKEN=<token> kv9 client raw-get --addr <leader-ip:port> --keyspace <id> --key-hex <hex>\n\\
           KV9_CLIENT_TOKEN=<token> kv9 client raw-delete --addr <leader-ip:port> --keyspace <id> --key-hex <hex>\n\\
           KV9_CLIENT_TOKEN=<token> kv9 client raw-scan --addr <leader-ip:port> --keyspace <id> --start-hex <hex> --end-hex <hex> [--limit <n>]\n\\
           KV9_CLIENT_TOKEN=<token> kv9 client raw-delete-range --addr <leader-ip:port> --keyspace <id> --start-hex <hex> --end-hex <hex>\n\\
         \n\
         RAW COMMANDS:\n\\
           Keys and values are hex (printf 'hello' | xxd -p): a binary key cannot be passed\n\\
           safely as a shell string. Empty --start-hex/--end-hex means unbounded on that side.\n\\
           Address them to the CURRENT LEADER: a follower answers NotLeader with a redirect\n\\
           hint, and the client does not follow it for you.\n\\
         \n\\
         FLAGS (DESIGN §11):\n\
           --node-id     non-zero stable identity of this node (required)\n\
           --addr        serving address to bind (default 127.0.0.1:20160)\n\
           --advertise-addr canonical peer endpoint for start (root address or listener by default)\n\
           --data-dir    local data directory (default ./kv9-data)\n\
           --root        canonical RootDescriptor generated by root-create\n\
           --voters      fixed initial voters; creation only, never ordinary startup\n\
           -h, --help    print this help"
    );
}

fn parse_cli(args: impl Iterator<Item = String>) -> std::result::Result<Cli, String> {
    let mut cli = Cli::default();
    let mut args = args.peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--node-id" => {
                let value = args.next().ok_or("--node-id needs a value")?;
                let id = value
                    .parse::<u64>()
                    .map_err(|_| "--node-id must be a non-zero integer".to_string())?;
                if id == 0 {
                    return Err("--node-id must be a non-zero integer".to_string());
                }
                cli.node_id = Some(NodeId(id));
            }
            "--addr" => cli.addr = Some(args.next().ok_or("--addr needs a value")?),
            "--advertise-addr" => {
                cli.advertise_addr = Some(args.next().ok_or("--advertise-addr needs a value")?)
            }
            "--data-dir" => cli.data_dir = Some(args.next().ok_or("--data-dir needs a value")?),
            "--data-workers" => {
                let value = args.next().ok_or("--data-workers needs a value")?;
                let workers = value
                    .parse::<usize>()
                    .ok()
                    .filter(|w| (1..=32).contains(w))
                    .ok_or("--data-workers must be within 1..=32".to_string())?;
                cli.data_workers = Some(workers);
            }
            "--join" => {
                let v = args.next().ok_or("--join needs a value")?;
                cli.join = v
                    .split(',')
                    .filter(|s| !s.trim().is_empty())
                    .map(parse_seed_peer)
                    .collect::<std::result::Result<Vec<_>, _>>()?;
            }
            "--cluster-id" => {
                let value = args.next().ok_or("--cluster-id needs a value")?;
                cli.cluster_id = Some(
                    value
                        .parse::<ClusterId>()
                        .map_err(|error| error.to_string())?,
                );
            }
            "-h" | "--help" => return Err("help".to_string()),
            other => return Err(format!("unknown argument: {other}")),
        }
    }
    if cli.node_id.is_none() {
        return Err("--node-id is required".to_string());
    }
    validate_declared_seed_set(&cli)?;
    Ok(cli)
}

fn parse_seed_peer(raw: &str) -> std::result::Result<SeedPeer, String> {
    let (id, addr) = raw
        .trim()
        .split_once('@')
        .ok_or_else(|| format!("invalid --join peer '{raw}': expected node-id@ip:port"))?;
    let node_id = id
        .parse::<u64>()
        .map_err(|_| format!("invalid --join peer '{raw}': node id must be non-zero"))?;
    if node_id == 0 {
        return Err(format!(
            "invalid --join peer '{raw}': node id must be non-zero"
        ));
    }
    let addr = addr
        .parse::<SocketAddr>()
        .map_err(|_| format!("invalid --join peer '{raw}': address must be ip:port"))?;
    Ok(SeedPeer {
        node_id: NodeId(node_id),
        addr,
    })
}

fn validate_declared_seed_set(cli: &Cli) -> std::result::Result<(), String> {
    if cli.join.is_empty() {
        return Ok(());
    }
    let mut ids = HashSet::new();
    let mut addrs = HashSet::new();
    for seed in &cli.join {
        if !ids.insert(seed.node_id) {
            return Err(format!("duplicate --join node id {}", seed.node_id.0));
        }
        if !addrs.insert(seed.addr) {
            return Err(format!("duplicate --join address {}", seed.addr));
        }
    }
    let node_id = cli.node_id.expect("node id checked before seed set");
    let own_addr = cli
        .addr
        .as_deref()
        .unwrap_or("127.0.0.1:20160")
        .parse::<SocketAddr>()
        .map_err(|_| "--addr must be ip:port".to_string())?;
    match cli.join.iter().find(|seed| seed.node_id == node_id) {
        Some(seed) if seed.addr == own_addr && cli.cluster_id.is_none() => Ok(()),
        Some(_) if cli.cluster_id.is_some() => Err(
            "--cluster-id is only valid when this node is absent from --join (join-existing mode)"
                .to_string(),
        ),
        Some(seed) => Err(format!(
            "--join declares this node {} at {}, but --addr is {}",
            node_id.0, seed.addr, own_addr
        )),
        None if cli.cluster_id.is_some() => Ok(()),
        None => Err(format!(
            "node {} is absent from --join; join-existing mode requires --cluster-id",
            node_id.0
        )),
    }
}

fn config_from_cli(cli: Cli) -> Config {
    let mut cfg = Config {
        advertise_addr: cli.advertise_addr,
        ..Config::default()
    };
    if let Some(a) = cli.addr {
        cfg.addr = a;
    }
    if let Some(d) = cli.data_dir {
        cfg.data_dir = d;
    }
    if let Some(w) = cli.data_workers {
        cfg.data_workers = w;
    }
    cfg.join = cli.join;
    cfg
}

fn take_named_arg(arguments: &mut Vec<String>, name: &str) -> Result<String, String> {
    let Some(index) = arguments.iter().position(|argument| argument == name) else {
        return Err(format!("{name} is required"));
    };
    if index + 1 >= arguments.len() {
        return Err(format!("{name} needs a value"));
    }
    let value = arguments.remove(index + 1);
    arguments.remove(index);
    Ok(value)
}

fn run_store_prepare(args: impl Iterator<Item = String>) -> ExitCode {
    let cli = match parse_cli(args) {
        Ok(cli) => cli,
        Err(error) => return command_error(&error),
    };
    if !cli.join.is_empty()
        || cli.cluster_id.is_some()
        || cli.addr.is_some()
        || cli.advertise_addr.is_some()
    {
        return command_error("store-prepare accepts only --node-id and --data-dir");
    }
    let node_id = cli.node_id.expect("parse_cli enforces node id");
    let config = config_from_cli(cli);
    let result = kv9_common::store_lifecycle::StoreGuard::lock(Path::new(&config.data_dir))
        .and_then(|mut guard| guard.prepare(node_id));
    match result {
        Ok(record) => {
            println!(
                "store_prepared=true node_id={} store_incarnation={}",
                record.node_id.0, record.incarnation
            );
            ExitCode::SUCCESS
        }
        Err(error) => command_error(&error.to_string()),
    }
}

fn run_root_create(args: impl Iterator<Item = String>) -> ExitCode {
    let mut arguments: Vec<String> = args.collect();
    let output = match take_named_arg(&mut arguments, "--output") {
        Ok(value) => PathBuf::from(value),
        Err(error) => return command_error(&error),
    };
    let voters = match take_named_arg(&mut arguments, "--voters") {
        Ok(value) => value,
        Err(error) => return command_error(&error),
    };
    let incarnations =
        match take_named_arg(&mut arguments, "--store-incarnations") {
            Ok(value) => value,
            Err(_) => return command_error(
                "--store-incarnations is required; run store-prepare on each data directory first",
            ),
        };
    let mut prepared = std::collections::BTreeMap::new();
    for item in incarnations.split(',') {
        let Some((id, incarnation)) = item.split_once('=') else {
            return command_error("store incarnations must be node_id=32_hex pairs");
        };
        let (Ok(id), Ok(incarnation)) =
            (id.parse::<u64>(), incarnation.parse::<StoreIncarnation>())
        else {
            return command_error("invalid store incarnation pair");
        };
        if id == 0
            || incarnation.as_bytes() == &[0; 16]
            || prepared.insert(NodeId(id), incarnation).is_some()
        {
            return command_error(
                "store incarnations require unique non-zero node ids and non-zero identities",
            );
        }
    }
    if !arguments.is_empty() {
        return command_error(&format!("unknown argument: {}", arguments[0]));
    }
    let credential = std::env::var("KV9_BOOTSTRAP_TOKEN").unwrap_or_default();
    if credential.is_empty() {
        return command_error("KV9_BOOTSTRAP_TOKEN must be non-empty");
    }
    let seeds = match voters
        .split(',')
        .filter(|value| !value.trim().is_empty())
        .map(parse_seed_peer)
        .collect::<Result<Vec<_>, _>>()
    {
        Ok(seeds) => seeds,
        Err(error) => return command_error(&error),
    };
    let voters = match seeds
        .into_iter()
        .map(|seed| {
            Ok(RootVoter {
                node_id: seed.node_id,
                addr: seed.addr,
                store_incarnation: prepared.remove(&seed.node_id).ok_or_else(|| {
                    kv9_common::Error::Config(
                        "every root voter needs its independently prepared incarnation".into(),
                    )
                })?,
            })
        })
        .collect::<kv9_common::Result<Vec<_>>>()
    {
        Ok(voters) => voters,
        Err(error) => return command_error(&error.to_string()),
    };
    if !prepared.is_empty() {
        return command_error("store incarnation supplied for a node outside the root voter set");
    }
    let root = match ClusterId::mint().and_then(|cluster_id| {
        BootstrapGeneration::mint().and_then(|generation| {
            RootDescriptor::new(cluster_id, generation, voters, credential.as_bytes())
        })
    }) {
        Ok(root) => root,
        Err(error) => return command_error(&error.to_string()),
    };
    if let Err(error) = write_new_root_descriptor(&output, &root) {
        return command_error(&error.to_string());
    }
    println!(
        "root_created=true cluster_id={} bootstrap_generation={} root_digest={} output={}",
        root.cluster_id,
        root.bootstrap_generation,
        root.digest(),
        output.display()
    );
    for voter in &root.voters {
        println!(
            "root_voter={}@{} store_incarnation={}",
            voter.node_id.0, voter.addr, voter.store_incarnation
        );
    }
    ExitCode::SUCCESS
}

fn run_provision(args: impl Iterator<Item = String>, joining: bool) -> ExitCode {
    let mut arguments: Vec<String> = args.collect();
    let root_path = match take_named_arg(&mut arguments, "--root") {
        Ok(value) => PathBuf::from(value),
        Err(error) => return command_error(&error),
    };
    let cli = match parse_cli(arguments.into_iter()) {
        Ok(cli) => cli,
        Err(error) => return command_error(&error),
    };
    if !cli.join.is_empty() || cli.cluster_id.is_some() {
        return command_error("init/join accept membership only from --root");
    }
    if cli.advertise_addr.is_some() {
        return command_error("--advertise-addr is a start-only option");
    }
    let bytes = match fs::read(&root_path) {
        Ok(bytes) => bytes,
        Err(error) => return command_error(&format!("read {}: {error}", root_path.display())),
    };
    let root = match RootDescriptor::decode(&bytes) {
        Ok(root) => root,
        Err(error) => return command_error(&error.to_string()),
    };
    let node_id = cli.node_id.expect("parse_cli enforces node id");
    let config = config_from_cli(cli);
    let mut store = match kv9_common::store_lifecycle::StoreGuard::lock(Path::new(&config.data_dir))
    {
        Ok(store) => store,
        Err(error) => return command_error(&error.to_string()),
    };
    let identity = if joining {
        let ticket = std::env::var("KV9_JOIN_TICKET").unwrap_or_default();
        if ticket.len() != 64 || !ticket.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            return command_error("KV9_JOIN_TICKET must be the 64-hex credential from admit-node");
        }
        if root.voter(node_id).is_some() {
            return command_error("join is only for nodes absent from the initial root voter set");
        }
        let data_dir = Path::new(&config.data_dir);
        let root_exists = data_dir.join(ROOT_DESCRIPTOR_FILE).exists();
        let store_exists = data_dir.join(STORE_IDENTITY_FILE).exists();
        match (root_exists, store_exists) {
            (true, true) => match load_root_bundle(data_dir) {
                Ok((saved_root, identity)) if saved_root == root && identity.node_id == node_id => {
                    identity
                }
                Ok(_) => {
                    return command_error(
                        "data directory is bound to a different root/store identity",
                    )
                }
                Err(error) => return command_error(&error.to_string()),
            },
            (false, false) => match store
                .prepare(node_id)
                .and_then(|record| StoreIdentity::for_joiner(&root, node_id, record.incarnation))
            {
                Ok(identity) => identity,
                Err(error) => return command_error(&error.to_string()),
            },
            _ => {
                return command_error("data directory contains an incomplete root identity bundle")
            }
        }
    } else {
        let credential = std::env::var("KV9_BOOTSTRAP_TOKEN").unwrap_or_default();
        if credential.is_empty() {
            return command_error("KV9_BOOTSTRAP_TOKEN must be non-empty");
        }
        if root.bootstrap_credential_sha256 != kv9_common::RootDigest::sha256(credential.as_bytes())
        {
            return command_error("bootstrap credential does not match the root descriptor");
        }
        match StoreIdentity::for_voter(&root, node_id) {
            Ok(identity) => identity,
            Err(error) => return command_error(&error.to_string()),
        }
    };
    if let Err(error) = store.verify(&identity) {
        return command_error(&error.to_string());
    }
    if let Err(error) = persist_root_bundle(Path::new(&config.data_dir), &root, &identity) {
        return command_error(&error.to_string());
    }
    if let Err(error) = store.bind(&root, &identity) {
        return command_error(&error.to_string());
    }
    println!(
        "store_initialized=true mode={} node_id={} cluster_id={} root_digest={} store_incarnation={} data_dir={}",
        if joining { "join" } else { "init" },
        node_id.0,
        root.cluster_id,
        root.digest(),
        identity.store_incarnation,
        config.data_dir
    );
    ExitCode::SUCCESS
}

/// Offline destination-side installation of one captured record. The store
/// must be stopped and bound to the image root; every check is the joint
/// installer's own. Prints a receipt; grants no serving or voting.
fn run_install_migration_image(mut args: impl Iterator<Item = String>) -> ExitCode {
    let mut data_dir = None;
    let mut record_file = None;
    while let Some(flag) = args.next() {
        let value = match args.next() {
            Some(value) => value,
            None => return command_error(&format!("{flag} needs a value")),
        };
        match flag.as_str() {
            "--data-dir" => data_dir = Some(value),
            "--record-file" => record_file = Some(value),
            other => return command_error(&format!("unknown install flag {other}")),
        }
    }
    let (Some(data_dir), Some(record_file)) = (data_dir, record_file) else {
        return command_error("--data-dir and --record-file are required");
    };
    let directory = Path::new(&data_dir);
    let result = (|| -> Result<_, Box<dyn std::error::Error>> {
        let guard = kv9_common::store_lifecycle::StoreGuard::lock(directory)?;
        let (root, identity) = load_root_bundle(directory)?;
        identity.verify(&root, identity.node_id)?;
        let record = fs::read(&record_file)?;
        let uploader = kv9_engine::checkpoint::RemoteUploader::new(std::sync::Arc::new(
            kv9_engine::minio::MinioObjectStore::connect(
                kv9_engine::minio::MinioConfig::from_env()?,
            )?,
        ));
        let installed = kv9_raft::snapshot_install::install_captured_record(
            &guard, identity, &record, &uploader,
        )?;
        Ok(installed)
    })();
    match result {
        Ok(installed) => {
            println!(
                "install_outcome=selected
generation={}
image_digest={}
cut_term={}
cut_index={}
records={}
object_bytes={}
serving=false
capability=offline_generation_only",
                installed.generation,
                installed.image_digest,
                installed.position.term,
                installed.position.index,
                installed.records,
                installed.object_bytes
            );
            ExitCode::SUCCESS
        }
        Err(error) => command_error(&error.to_string()),
    }
}

fn command_error(error: &str) -> ExitCode {
    eprintln!("error: {error}");
    ExitCode::FAILURE
}

fn main() -> ExitCode {
    let arguments: Vec<String> = std::env::args().skip(1).collect();
    if arguments
        .first()
        .is_some_and(|argument| argument == "client")
    {
        return run_client(arguments.into_iter().skip(1));
    }
    let Some(command) = arguments.first().map(String::as_str) else {
        eprintln!("error: explicit command required; ordinary startup never creates a cluster\n");
        print_usage();
        return ExitCode::FAILURE;
    };
    match command {
        "store-prepare" => return run_store_prepare(arguments.into_iter().skip(1)),
        "root-create" => return run_root_create(arguments.into_iter().skip(1)),
        "init" => return run_provision(arguments.into_iter().skip(1), false),
        "install-migration-image" => {
            return run_install_migration_image(arguments.into_iter().skip(1))
        }
        "join" => return run_provision(arguments.into_iter().skip(1), true),
        "start" => {}
        "-h" | "--help" => {
            print_usage();
            return ExitCode::SUCCESS;
        }
        _ => {
            eprintln!(
                "error: explicit root-create, init, join, start, or client command required\n"
            );
            print_usage();
            return ExitCode::FAILURE;
        }
    }
    let cli = match parse_cli(arguments.into_iter().skip(1)) {
        Ok(cli) => cli,
        Err(e) => {
            if e == "help" {
                print_usage();
                return ExitCode::SUCCESS;
            }
            eprintln!("error: {e}\n");
            print_usage();
            return ExitCode::FAILURE;
        }
    };

    let node_id = cli.node_id.expect("parse_cli enforces node id");
    if !cli.join.is_empty() || cli.cluster_id.is_some() {
        eprintln!(
            "error: start reads membership and cluster identity only from the durable root bundle"
        );
        return ExitCode::FAILURE;
    }
    let auth = RuntimeAuth {
        cluster_token: std::env::var("KV9_CLUSTER_TOKEN").unwrap_or_default(),
        client_tokens: parse_client_tokens(&std::env::var("KV9_CLIENT_TOKENS").unwrap_or_default()),
    };
    let mut config = config_from_cli(cli);
    let data_dir = PathBuf::from(&config.data_dir);
    let (root, identity) = match load_root_bundle(&data_dir) {
        Ok(bundle) => bundle,
        Err(error) => {
            eprintln!("failed to load durable root/store identity: {error}");
            return ExitCode::FAILURE;
        }
    };
    if identity.node_id != node_id {
        eprintln!("failed to start node: --node-id does not match durable store identity");
        return ExitCode::FAILURE;
    }
    config.join = root
        .voters
        .iter()
        .map(|voter| SeedPeer {
            node_id: voter.node_id,
            addr: voter.addr,
        })
        .collect();
    let join_ticket = std::env::var("KV9_JOIN_TICKET").ok();
    let runtime = match NodeRuntime::start_with_root_and_ticket(
        node_id,
        config,
        auth,
        root,
        identity,
        join_ticket.as_deref(),
    ) {
        Ok(runtime) => runtime,
        Err(e) => {
            eprintln!("failed to start node: {e}");
            return ExitCode::FAILURE;
        }
    };

    println!(
        "kv9 node {} running; machine-readable status: {}",
        node_id.0,
        runtime.status_path().display()
    );
    if let Err(e) = runtime.run() {
        eprintln!("node runtime failed: {e}");
        return ExitCode::FAILURE;
    }
    unreachable!("node runtime returns only on failure")
}

/// Decode a lowercase/uppercase hex string into bytes.
///
/// On failure the input is **not** echoed: a mistyped `--key-hex` is one thing, but the
/// same flag shape is used for material that must not reach logs, and an error path is
/// exactly where a stray value gets printed and persisted.
fn decode_hex(flag: &str, value: &str) -> Result<Vec<u8>, String> {
    if !value.len().is_multiple_of(2) {
        return Err(format!("{flag} must have an even number of hex digits"));
    }
    if !value.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err(format!("{flag} must be hexadecimal"));
    }
    (0..value.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&value[i..i + 2], 16).map_err(|_| format!("{flag} is not hex")))
        .collect()
}

fn encode_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

/// Report a not-leader refusal in a form a script can branch on.
fn print_not_leader(leader: Option<kv9_common::NodeId>) -> ExitCode {
    match leader {
        Some(id) => eprintln!("not_leader=true leader_node_id={}", id.0),
        // Absent hint means "re-discover", not "retry me" — the script must be able to
        // tell those apart, so it is spelled out rather than omitted.
        None => eprintln!("not_leader=true leader_node_id=unknown"),
    }
    ExitCode::FAILURE
}

fn run_raw_client(command: &str, mut args: impl Iterator<Item = String>) -> ExitCode {
    let mut addr = None;
    let mut keyspace = None;
    let mut key = None;
    let mut value = None;
    let mut start = Vec::new();
    let mut end = Vec::new();
    let mut limit = 1024u32;

    while let Some(flag) = args.next() {
        let Some(raw) = args.next() else {
            eprintln!("error: {flag} needs a value");
            return ExitCode::FAILURE;
        };
        let decoded = |v: &str| decode_hex(&flag, v);
        match flag.as_str() {
            "--addr" => addr = Some(raw),
            "--keyspace" => match raw.parse::<u32>() {
                Ok(v) => keyspace = Some(v),
                Err(_) => {
                    eprintln!("error: --keyspace must be an integer");
                    return ExitCode::FAILURE;
                }
            },
            "--limit" => match raw.parse::<u32>() {
                Ok(v) => limit = v,
                Err(_) => {
                    eprintln!("error: --limit must be an integer");
                    return ExitCode::FAILURE;
                }
            },
            "--key-hex" | "--value-hex" | "--start-hex" | "--end-hex" => {
                let bytes = match decoded(&raw) {
                    Ok(bytes) => bytes,
                    Err(e) => {
                        eprintln!("error: {e}");
                        return ExitCode::FAILURE;
                    }
                };
                match flag.as_str() {
                    "--key-hex" => key = Some(bytes),
                    "--value-hex" => value = Some(bytes),
                    "--start-hex" => start = bytes,
                    _ => end = bytes,
                }
            }
            _ => {
                eprintln!("error: unknown client flag {flag}");
                return ExitCode::FAILURE;
            }
        }
    }

    let (Some(addr), Some(keyspace)) = (addr, keyspace) else {
        eprintln!("error: --addr and --keyspace are required");
        return ExitCode::FAILURE;
    };
    let token = std::env::var("KV9_CLIENT_TOKEN").unwrap_or_default();
    if token.is_empty() {
        eprintln!("error: KV9_CLIENT_TOKEN must be non-empty");
        return ExitCode::FAILURE;
    }
    let client = match RawClient::connect(&addr, &token, keyspace) {
        Ok(client) => client,
        Err(e) => {
            eprintln!("client request failed: {e}");
            return ExitCode::FAILURE;
        }
    };

    macro_rules! finish {
        ($call:expr, $on_ok:expr) => {
            match $call {
                Ok(RawClientOutcome::Ok(value)) => {
                    #[allow(clippy::redundant_closure_call)]
                    ($on_ok)(value);
                    ExitCode::SUCCESS
                }
                Ok(RawClientOutcome::NotLeader { leader }) => print_not_leader(leader),
                Ok(RawClientOutcome::AdmissionRefused { reason }) => {
                    eprintln!("admission_refused=true reason={reason}");
                    ExitCode::FAILURE
                }
                // A partial write must surface as stable fields, not prose: the caller
                // has to know how much of the range is already gone.
                Err(kv9_common::Error::PartialDeleteRange {
                    committed_chunks,
                    last_applied_term,
                    last_applied_index,
                    cause,
                }) => {
                    eprintln!("partial_write=true");
                    eprintln!("committed_chunks={committed_chunks}");
                    eprintln!("last_applied_term={last_applied_term}");
                    eprintln!("last_applied_index={last_applied_index}");
                    eprintln!("cause={cause}");
                    ExitCode::FAILURE
                }
                // Stable machine fields, same convention as `not_leader=true`:
                // the partition E2E's typed-exclusivity assertion keys on
                // these, never on prose (prose may be reworded; a matcher on
                // it breaks silently). `phase` uses the same two words as the
                // wire marker — one vocabulary end to end.
                Err(kv9_common::Error::ReadUnconfirmed { phase }) => {
                    eprintln!(
                        "read_unconfirmed=true phase={}",
                        match phase {
                            kv9_common::ReadBarrierPhase::QuorumConfirmation => "quorum",
                            kv9_common::ReadBarrierPhase::ApplyCatchUp => "apply",
                        }
                    );
                    ExitCode::FAILURE
                }
                Err(e) => {
                    eprintln!("client request failed: {e}");
                    ExitCode::FAILURE
                }
            }
        };
    }

    match command {
        "raw-put" => {
            let (Some(key), Some(value)) = (key, value) else {
                eprintln!("error: raw-put requires --key-hex and --value-hex");
                return ExitCode::FAILURE;
            };
            finish!(
                client.put(key, value),
                |r: kv9_server::proto::RawWriteResponse| {
                    // The position the write actually reached, straight from the response.
                    // Reading it from a status file afterwards cannot prove identity: a
                    // concurrent command moves that same number.
                    println!("applied_term={}", r.applied_term);
                    println!("applied_index={}", r.applied_index);
                }
            )
        }
        "raw-get" => {
            let Some(key) = key else {
                eprintln!("error: raw-get requires --key-hex");
                return ExitCode::FAILURE;
            };
            finish!(client.get(key), |found: Option<Vec<u8>>| match found {
                // A miss is a successful answer, not a failure: the script must be able
                // to distinguish it from a misdirected request.
                None => println!("found=false"),
                Some(bytes) => println!("value_hex={}", encode_hex(&bytes)),
            })
        }
        "raw-delete" => {
            let Some(key) = key else {
                eprintln!("error: raw-delete requires --key-hex");
                return ExitCode::FAILURE;
            };
            finish!(
                client.delete(key),
                |r: kv9_server::proto::RawWriteResponse| {
                    println!("applied_term={}", r.applied_term);
                    println!("applied_index={}", r.applied_index);
                }
            )
        }
        "raw-scan" => {
            finish!(client.scan(start, end, limit), |rows: Vec<(
                Vec<u8>,
                Vec<u8>
            )>| {
                for (key, value) in &rows {
                    println!(
                        "key_hex={} value_hex={}",
                        encode_hex(key),
                        encode_hex(value)
                    );
                }
                println!("count={}", rows.len());
            })
        }
        "raw-delete-range" => {
            finish!(
                client.delete_range(start, end),
                |r: kv9_server::proto::RawDeleteRangeResponse| {
                    println!("committed_chunks={}", r.committed_chunks);
                    println!("last_applied_term={}", r.last_applied_term);
                    println!("last_applied_index={}", r.last_applied_index);
                }
            )
        }
        _ => unreachable!("dispatch checked the command"),
    }
}

fn run_client(mut args: impl Iterator<Item = String>) -> ExitCode {
    let command = args.next().unwrap_or_default();
    match command.as_str() {
        "raw-put" | "raw-get" | "raw-delete" | "raw-scan" | "raw-delete-range" => {
            run_raw_client(&command, args)
        }
        "create-keyspace" => run_create_keyspace(args),
        "create-data-group" => data_group_cli::run(args, false),
        "create-data-keyspace" => data_group_cli::run(args, true),
        "migrate-data-group" => data_group_cli::run_migrate(args),
        "bind-migration-image" => data_group_cli::run_bind_image(args),
        "capture-migration-image" => data_group_cli::run_capture_image(args),
        "plan-migration-image" => data_group_cli::run_plan_image(args),
        "attach-migration-learner" => data_group_cli::run_attach_learner(args),
        "admit-node" => run_admit_node(args),
        "promote-node" => run_promote_node(args),
        "get-node-endpoint" => endpoint_cli::run(args, false),
        "retention-apply" => retention_cli::run(args, true),
        "retention-owner" => retention_cli::run(args, false),
        "change-node-endpoint" => endpoint_cli::run(args, true),
        _ => {
            eprintln!(
                "error: client command must be one of create-keyspace, raw-put, raw-get, \
                 raw-delete, raw-scan, raw-delete-range, admit-node, promote-node"
            );
            ExitCode::FAILURE
        }
    }
}

fn run_create_keyspace(mut args: impl Iterator<Item = String>) -> ExitCode {
    let mut addr = None;
    let mut name = None;
    let mut api_type = None;
    let mut tenant_id = 0u64;
    while let Some(flag) = args.next() {
        let value = match args.next() {
            Some(value) => value,
            None => {
                eprintln!("error: {flag} needs a value");
                return ExitCode::FAILURE;
            }
        };
        match flag.as_str() {
            "--addr" => addr = Some(value),
            "--name" => name = Some(value),
            "--api-type" => {
                api_type = match value.as_str() {
                    "txn" => Some(ApiType::Txn),
                    "raw" => Some(ApiType::Raw),
                    _ => {
                        eprintln!("error: --api-type must be txn or raw");
                        return ExitCode::FAILURE;
                    }
                };
            }
            "--tenant-id" => match value.parse() {
                Ok(value) => tenant_id = value,
                Err(_) => {
                    eprintln!("error: --tenant-id must be an integer");
                    return ExitCode::FAILURE;
                }
            },
            _ => {
                eprintln!("error: unknown client flag {flag}");
                return ExitCode::FAILURE;
            }
        }
    }
    let Some((addr, name, api_type)) = addr
        .zip(name)
        .zip(api_type)
        .map(|((addr, name), api_type)| (addr, name, api_type))
    else {
        eprintln!("error: --addr, --name, and --api-type are required");
        return ExitCode::FAILURE;
    };
    let Some(token) = client_token() else {
        return ExitCode::FAILURE;
    };
    match create_keyspace_blocking(&addr, &token, name, tenant_id, api_type) {
        Ok(response) => {
            println!("keyspace_id={}", response.keyspace_id);
            println!("proposed_term={}", response.proposed_term.unwrap_or(0));
            println!("proposed_index={}", response.proposed_index.unwrap_or(0));
            ExitCode::SUCCESS
        }
        Err(error) => {
            eprintln!("client request failed: {error}");
            ExitCode::FAILURE
        }
    }
}

fn run_admit_node(mut args: impl Iterator<Item = String>) -> ExitCode {
    let mut addr = None;
    let mut node_id = None;
    let mut node_addr = None;
    let mut ttl_seconds = 600u64;
    while let Some(flag) = args.next() {
        let Some(value) = args.next() else {
            eprintln!("error: {flag} needs a value");
            return ExitCode::FAILURE;
        };
        match flag.as_str() {
            "--addr" => addr = Some(value),
            "--node-id" => node_id = parse_client_node_id(&value),
            "--node-addr" => match value.parse::<SocketAddr>() {
                Ok(value) => node_addr = Some(value),
                Err(_) => {
                    eprintln!("error: --node-addr must be ip:port");
                    return ExitCode::FAILURE;
                }
            },
            "--ttl-seconds" => match value.parse::<u64>() {
                Ok(value) if value > 0 => ttl_seconds = value,
                _ => {
                    eprintln!("error: --ttl-seconds must be a non-zero integer");
                    return ExitCode::FAILURE;
                }
            },
            _ => {
                eprintln!("error: unknown client flag {flag}");
                return ExitCode::FAILURE;
            }
        }
        if flag == "--node-id" && node_id.is_none() {
            return ExitCode::FAILURE;
        }
    }
    let Some((addr, node_id, node_addr)) = addr
        .zip(node_id)
        .zip(node_addr)
        .map(|((addr, node_id), node_addr)| (addr, node_id, node_addr))
    else {
        eprintln!("error: --addr, --node-id, and --node-addr are required");
        return ExitCode::FAILURE;
    };
    let Some(token) = client_token() else {
        return ExitCode::FAILURE;
    };
    match admit_node_blocking(&addr, &token, node_id, node_addr.to_string(), ttl_seconds) {
        Ok(response) => print_membership_response(response),
        Err(kv9_common::Error::NotLeader { leader }) => print_not_leader(leader),
        Err(error) => {
            eprintln!("client request failed: {error}");
            ExitCode::FAILURE
        }
    }
}

fn run_promote_node(mut args: impl Iterator<Item = String>) -> ExitCode {
    let mut addr = None;
    let mut node_id = None;
    while let Some(flag) = args.next() {
        let Some(value) = args.next() else {
            eprintln!("error: {flag} needs a value");
            return ExitCode::FAILURE;
        };
        match flag.as_str() {
            "--addr" => addr = Some(value),
            "--node-id" => node_id = parse_client_node_id(&value),
            _ => {
                eprintln!("error: unknown client flag {flag}");
                return ExitCode::FAILURE;
            }
        }
        if flag == "--node-id" && node_id.is_none() {
            return ExitCode::FAILURE;
        }
    }
    let Some((addr, node_id)) = addr.zip(node_id) else {
        eprintln!("error: --addr and --node-id are required");
        return ExitCode::FAILURE;
    };
    let Some(token) = client_token() else {
        return ExitCode::FAILURE;
    };
    match promote_node_blocking(&addr, &token, node_id) {
        Ok(response) => print_membership_response(response),
        Err(kv9_common::Error::NotLeader { leader }) => print_not_leader(leader),
        Err(error) => {
            eprintln!("client request failed: {error}");
            ExitCode::FAILURE
        }
    }
}

fn parse_client_node_id(value: &str) -> Option<NodeId> {
    match value.parse::<u64>() {
        Ok(value) if value > 0 => Some(NodeId(value)),
        _ => {
            eprintln!("error: --node-id must be a non-zero integer");
            None
        }
    }
}

fn client_token() -> Option<String> {
    let token = std::env::var("KV9_CLIENT_TOKEN").unwrap_or_default();
    if token.is_empty() {
        eprintln!("error: KV9_CLIENT_TOKEN must be non-empty");
        None
    } else {
        Some(token)
    }
}

fn print_membership_response(
    response: kv9_server::grpc::proto::MembershipChangeResponse,
) -> ExitCode {
    println!("applied_term={}", response.applied_term);
    println!("applied_index={}", response.applied_index);
    println!(
        "meta_voters={}",
        response
            .voters
            .iter()
            .map(u64::to_string)
            .collect::<Vec<_>>()
            .join(",")
    );
    println!(
        "meta_learners={}",
        response
            .learners
            .iter()
            .map(u64::to_string)
            .collect::<Vec<_>>()
            .join(",")
    );
    if !response.join_ticket.is_empty() {
        println!("join_ticket={}", response.join_ticket);
    }
    ExitCode::SUCCESS
}

fn parse_client_tokens(value: &str) -> Vec<(String, String)> {
    value
        .split(',')
        .filter_map(|credential| {
            let (principal, token) = credential.split_once('=')?;
            (!principal.is_empty() && !token.is_empty())
                .then(|| (token.to_string(), principal.to_string()))
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn args(items: &[&str]) -> impl Iterator<Item = String> {
        items
            .iter()
            .map(|item| (*item).to_string())
            .collect::<Vec<_>>()
            .into_iter()
    }

    #[test]
    fn cli_maps_node_configuration() {
        let cli = parse_cli(args(&[
            "--node-id",
            "7",
            "--addr",
            "127.0.0.1:30160",
            "--data-dir",
            "/tmp/kv9-test",
            "--join",
            "7@127.0.0.1:30160,8@127.0.0.1:30161",
        ]))
        .unwrap();
        let config = config_from_cli(cli);

        assert_eq!(config.addr, "127.0.0.1:30160");
        assert_eq!(config.data_dir, "/tmp/kv9-test");
        assert_eq!(
            config.join,
            [
                SeedPeer {
                    node_id: NodeId(7),
                    addr: "127.0.0.1:30160".parse().unwrap(),
                },
                SeedPeer {
                    node_id: NodeId(8),
                    addr: "127.0.0.1:30161".parse().unwrap(),
                },
            ]
        );
    }

    #[test]
    fn cli_requires_a_non_zero_node_id() {
        assert_eq!(parse_cli(args(&[])).unwrap_err(), "--node-id is required");
        assert_eq!(
            parse_cli(args(&["--node-id", "0"])).unwrap_err(),
            "--node-id must be a non-zero integer"
        );
    }

    #[test]
    fn txn_groups_is_not_a_node_cli_option() {
        let err = parse_cli(args(&["--node-id", "1", "--txn-groups", "4"])).unwrap_err();
        assert_eq!(err, "unknown argument: --txn-groups");
    }

    #[test]
    fn cli_rejects_ambiguous_or_mismatched_seed_identity() {
        for bad in [
            "127.0.0.1:20160",
            "0@127.0.0.1:20160",
            "x@127.0.0.1:20160",
            "1@localhost:20160",
        ] {
            assert!(parse_cli(args(&["--node-id", "1", "--join", bad])).is_err());
        }

        let duplicate_id = parse_cli(args(&[
            "--node-id",
            "1",
            "--join",
            "1@127.0.0.1:20160,1@127.0.0.1:20161",
        ]));
        assert_eq!(duplicate_id.unwrap_err(), "duplicate --join node id 1");

        let duplicate_addr = parse_cli(args(&[
            "--node-id",
            "1",
            "--join",
            "1@127.0.0.1:20160,2@127.0.0.1:20160",
        ]));
        assert_eq!(
            duplicate_addr.unwrap_err(),
            "duplicate --join address 127.0.0.1:20160"
        );

        let missing_self = parse_cli(args(&[
            "--node-id",
            "1",
            "--join",
            "2@127.0.0.1:20161,3@127.0.0.1:20162",
        ]));
        assert_eq!(
            missing_self.unwrap_err(),
            "node 1 is absent from --join; join-existing mode requires --cluster-id"
        );

        let joining = parse_cli(args(&[
            "--node-id",
            "4",
            "--addr",
            "127.0.0.1:20163",
            "--join",
            "1@127.0.0.1:20160,2@127.0.0.1:20161,3@127.0.0.1:20162",
            "--cluster-id",
            "00112233445566778899aabbccddeeff",
        ]))
        .unwrap();
        assert_eq!(
            joining.cluster_id.unwrap().to_string(),
            "00112233445566778899aabbccddeeff"
        );

        let initial_with_cluster = parse_cli(args(&[
            "--node-id",
            "1",
            "--join",
            "1@127.0.0.1:20160,2@127.0.0.1:20161",
            "--cluster-id",
            "00112233445566778899aabbccddeeff",
        ]));
        assert_eq!(
            initial_with_cluster.unwrap_err(),
            "--cluster-id is only valid when this node is absent from --join (join-existing mode)"
        );

        let mismatched_self = parse_cli(args(&[
            "--node-id",
            "1",
            "--addr",
            "127.0.0.1:30160",
            "--join",
            "1@127.0.0.1:20160,2@127.0.0.1:20161",
        ]));
        assert_eq!(
            mismatched_self.unwrap_err(),
            "--join declares this node 1 at 127.0.0.1:20160, but --addr is 127.0.0.1:30160"
        );
    }
}
