# split-publication increment (D04 part 5, finale) — progress

Baseline 3e029ca. Task #24. Meta publish_split DONE (+ published-shape
tolerance in validate_against; 65 meta tests green incl. publication
test). Server PublishSplit RPC/CLI publish-split DONE (local dual-digest
verification via factored half_digest/split_bounds helpers in inherent
RuntimeBackend impl). Lean model Publication.lean compiles (12 thms:
trio + full-chain + routing-flips-exactly + no-partial/no-lost +
permanent + confirm + 2 existence... count=11? recount at contract
time!). Runner prove-split-publication.py READY (6 controls).

e2e history (scripts/split-publication-e2e.py port 26990):
- e2e-first FAILED (retained): publish-again → committed_splits refused
  post-publication ("parent already sealed") → FIXED: validate_against
  accepts the intent's own published shape.
- e2e-second FAILED (retained): children never served — ROOT CAUSE:
  RawDirectory::get(keyspace) required EXACTLY ONE group per keyspace;
  post-split there are 3 (sealed parent + 2 children) → None → legacy
  metadata path refusal. FIXED: key-aware get_for(keyspace, key)
  (unsealed + contains, unique) + any_unsealed for keyless leader hints;
  ALL 12 raw serving callsites patched (get/put/delete/batch anchor =
  first key; scan/delete_range anchor = start; RawWrite::BatchPut anchor
  covered); authorize still re-checks per request.
- e2e-third RUNNING (b6lvtm3u5).

Remaining: e2e green → README/docs (docs/SPLIT-PUBLICATION.md + plan
sentence: manual split COMPLETE end to end; remaining: parent retirement
after split? note sealed parent group keeps running fenced — its
retirement is future work; automatic triggers future) → fmt/clippy →
contract (pins: split.rs ranges.rs runtime.rs range_api.rs api grpc
server-data_groups proto cli main e2e model files) + sibling refresh →
qualify (21 models list = +split-publication) → packaging (copy
child-population scripts, e2e-third as accepted, first/second retained)
→ commit/push → issues #9 (replace D04 checkpoint) + #25 (append FINALE
checkpoint: manual split end-to-end complete) → publication.json +
next handoff (candidates: routed-scan/delete-range across children
(cross-range), parent retirement post-split, stranded-learner recovery,
physical reclamation, D06 placement, or the 3/6/9 benchmark harness).

## Attempt-3 finding + fix
e2e-third FAILED (retained): low child served but high child unresolvable
on some nodes — ROOT CAUSE #3: RawDirectory::insert used entry().or_insert
→ the parent's directory entry NEVER updated to its sealed binding → the
stale UNSEALED parent binding kept matching get_for alongside the child →
two matches → None → legacy refusal (node-dependent by restart history).
FIX: insert now REPLACES (authorize re-reads the engine row per request;
identity comparison excludes version/sealed so replacement is safe).
e2e-fourth RUNNING (bba8cga0o). Three retained failures = three REAL
serving-path defects fixed by this increment's e2e (intent readback after
publication; single-range keyspace resolution; stale directory binding).
