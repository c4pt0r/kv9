"""Read back complete histories, feature bindings, lifetimes, drains and retained WAL bytes."""
import hashlib, json, sys, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'source/scripts'),str(HERE/'source/scripts/history')]
from recovery_binding import normal_build
from checker import load, verify_witness, coverage

def read(p):return json.loads(p.read_text())
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    result={'complete':False,'started_ns':time.time_ns(),'variants':[]}
    try:
        for variant in ['default','preallocated']:
            out=HERE/('recovery-'+variant);outer=read(HERE/('recovery-'+variant+'-result.json'))
            summary=read(out/'summary.json');build=HERE/('recovery-input-'+variant)
            manifest,client,features=normal_build(build)
            assert outer['complete'] and summary['complete'] and features['wal_payload_preallocation_enabled']==(variant=='preallocated')
            assert digest(out/'summary.json')==outer['summary_sha256']
            assert summary['server_sha256']==digest(build/'kv9')==manifest['binary_sha256']
            for name,h in summary['bound_artifacts'].items():assert digest(Path(name))==h
            for name,h in outer['inputs'].items():assert digest(Path(name))==h
            assert len(summary['lifetimes'])==5 and len(summary['owned_children'])==7
            for row in summary['owned_children']:
                assert row['identity_captured'] and row['exit_code'] is not None
                stat=Path('/proc',str(row['pid']),'stat')
                if stat.exists():assert int(stat.read_text().rsplit(')',1)[1].split()[19])!=row['start_ticks']
            assert summary['cleanup_errors']==[] and summary['owned_children_exited'] and summary['owned_lifetimes_exited']
            cases=[]
            for case in summary['cases']:
                transport=case['transport'];folder=out/('batch-'+transport.replace('_','-'))
                history=load(folder/'history.jsonl');report=read(folder/'report.json')
                assert verify_witness(history,case['checked']['history']['witness'])
                counted=coverage(history)
                assert counted==case['checked']['history']['coverage']
                events=[json.loads(x) for x in (folder/'history.jsonl').read_text().splitlines()]
                invocations={e['id']:e for e in events if e['type']=='invoke'}
                final=[e for e in invocations.values() if e['phase']=='verify']
                assert len(final)==1 and final[0]['op']=='batch_get'
                offset=report['wall_anchor_unix_ns']-report['wall_anchor_monotonic_ns']
                for window in case['windows']:
                    successes={k:[] for k in ['get','put','delete','batch_get','batch_put']}
                    for event in events:
                        if event['type']!='return' or event['outcome']!='ok':continue
                        call=invocations[event['id']]
                        if (call['phase']=='measure' and window['start_unix_ns']+1_000_000<=offset+call['monotonic_ns'] and
                            offset+event['monotonic_ns']<=window['end_unix_ns']-1_000_000):successes[call['op']].append(event['id'])
                    assert successes==window['successes'] and successes['batch_get'] and successes['batch_put']
                zero=['public_rpc_in_flight','public_rpc_queued','public_rpc_running','public_rpc_encoded_bytes',
                      'raft_async_apply_queued','raft_async_apply_in_flight','raft_async_read_queued',
                      'raft_async_read_active','raft_async_read_in_flight','raft_async_read_active_groups']
                for node,state in case['drained_status'].items():
                    before=case['drain_freshness']['baseline'][node];first=case['drain_freshness']['first_advances'][node]['status']
                    assert int(before['metrics_export_successes'])<int(first['metrics_export_successes'])<int(state['metrics_export_successes'])
                    for field in ['pid','process_start_ticks','process_boot_id']:assert state[field]==first[field]==before[field]
                    assert all(state[x]=='0' for x in zero) and state['fatal']=='' and state['bootstrap_state']=='Serving'
                    assert state['raft_async_apply_stopped']==state['raft_async_read_stopped']=='false'
                cases.append({'transport':transport,'history_sha256':digest(folder/'history.jsonl'),
                              'operations':counted['operations'],'outcomes':counted['outcomes'],
                              'successful_final_batch_reads':counted['successful_by_phase']['verify']['batch_get'],
                              'fresh_drained_voters':len(case['drained_status']),'fault_windows':len(case['windows'])})
            assert {c['transport'] for c in cases}=={'tonic_stream','tonic_unary'}
            retention=read(out/'wal-retention.json');assert digest(out/'wal-retention.json')==outer['wal_retention_sha256']
            for name,row in retention.items():
                for key in ['source','retained']:
                    p=Path(row[key]);assert p.is_file() and not p.is_symlink()
                    assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
            result['variants'].append({'variant':variant,'server_sha256':manifest['binary_sha256'],
                'client_sha256':client['binary_sha256'],'cases':cases,'lifetimes':len(summary['owned_children']),
                'retained_files':len(retention),'retained_bytes':sum(r['bytes'] for r in retention.values())})
        result['complete']=True
    except BaseException as error:
        result['failure']=repr(error);raise
    finally:
        result['ended_ns']=time.time_ns();(HERE/'recovery-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
