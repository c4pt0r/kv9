def normal_build(build):
    """Use the existing standalone build-benchmark layout, never its calibration server."""
    manifest = read(build / "build.json")
    workload = read(build / "workload/build.json")
    sources = read(build / "workload/sources.json")
    if manifest["dirty"] is not False or workload["dirty"] is not False:
        raise ValueError("normal transport acceptance requires a clean frozen source")
    if (digest(build / "kv9") != manifest["binaries"]["kv9"]["sha256"] or
        digest(build / "workload/kv9-batch-workload") != workload["binary_sha256"] or
        digest(build / "workload/build.json") != manifest["workload_build_sha256"] or
        any(workload[key] != manifest[key] for key in ("revision", "dirty", "source_tree_sha256", "profile", "rustc")) or
        sources["sources"] != manifest["sources"] or sources["revision"] != manifest["revision"] or
        sources["dirty"] is not False or sources["source_tree_sha256"] != manifest["source_tree_sha256"] or
        hashlib.sha256(json.dumps(sources["sources"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            != manifest["source_tree_sha256"]):
        raise ValueError("standalone server/client source and executable provenance differs")
    attestation = {}
    for name, path, command, wanted in (
        ("server", build / "kv9-cargo.jsonl", manifest["binaries"]["kv9"]["command"],
         ("kv9", "kv9_engine", "kv9_raft", "kv9_server")),
        ("workload", build / "workload/cargo.jsonl", sources["command"],
         ("kv9-batch-workload", "kv9_engine", "kv9_raft", "kv9_server")),
    ):
        if any(flag in command for flag in ("--features", "--all-features", "--no-default-features")):
            raise ValueError("normal RPC acceptance requires the standalone default-feature build")
        records = [json.loads(line) for line in path.read_text().splitlines()]
        selected = {}
        for target in wanted:
            rows = [r for r in records if r.get("reason") == "compiler-artifact" and
                    r.get("target", {}).get("name") == target]
            if len(rows) != 1 or rows[0]["features"] != []:
                raise ValueError("missing, ambiguous or non-default Cargo artifact: " + target)
            selected[target] = rows[0]
        executable = selected[wanted[0]]
        if not executable.get("executable") or "bin" not in executable["target"]["kind"]:
            raise ValueError("selected Cargo artifact is not the standalone executable")
        attestation[name] = dict(command=command, artifacts=selected, cargo_sha256=digest(path))
    return manifest, workload, attestation
