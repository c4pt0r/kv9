"""Publish original runtime evidence, excluding retained executables and source checkout."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path('/home/dongxu/kv9')
RUN = Path(__file__).resolve().parent
OUT = ROOT / 'docs/wal-preallocation-runtime-v1'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def main():
    OUT.mkdir(exist_ok=True)
    revision = '86aa6fc07d82f4d49b43fbfe309e0e5c20276da5'
    predecessor = 'fb9d39013188f34a31a519ce2ac7512138203b79'
    delta = subprocess.check_output(['git', 'diff', '--name-only', predecessor, revision], cwd=ROOT, text=True).splitlines()
    assert delta == ['scripts/build-workload.py', 'scripts/check-source-inventory.py']
    source = RUN / 'source'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == revision
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
    overlays = {}
    base = ROOT / 'docs/wal-payload-preallocation-v1/candidate-source'
    for p in sorted(base.rglob('*')):
        if p.is_file():
            rel = p.relative_to(base)
            assert p.read_bytes() == (source / rel).read_bytes()
            overlays[str(rel)] = digest(p.read_bytes())
    save(RUN / 'source-equivalence.json', {
        'complete': True, 'source_revision': revision, 'published_source_proof_revision': predecessor,
        'changed_paths': delta, 'candidate_overlays': overlays,
        'scope': 'All Rust, Cargo and proof inputs are unchanged. The two inventory helper edits are qualified separately; source-tree identity itself is different.'})
    observed = {'observed_unix_ns': time.time_ns(), 'filesystems': {}}
    for p in ['/', '/mnt/data', '/dev/shm']:
        s = os.statvfs(p)
        observed['filesystems'][p] = {'device': os.stat(p).st_dev, 'available_bytes': s.f_bavail * s.f_frsize}
    observed['scope'] = 'Point-in-time available space; no reservation, continuous monitor or cleanup claim.'
    save(RUN / 'output-placement-observation.json', observed)
    directories = ['build', 'correctness-client', 'recovery-input-default', 'recovery-input-preallocated',
                   'binding-controls', 'recovery-default', 'recovery-preallocated']
    top = ['actual-tool-receipts.json', 'audit-recovery.py', 'binding-controls.json', 'build-pair-original.py',
           'build-pair.py', 'build.stderr', 'build.stdout', 'client-readback.json',
           'correctness-client.stderr', 'correctness-client.stdout', 'normal-build-original.py',
           'readback-original.py', 'readback.py', 'readback.stderr', 'readback.stdout',
           'recovery-audit.json', 'recovery-default-result.json', 'recovery-default.stderr', 'recovery-default.stdout',
           'recovery-preallocated-result.json', 'recovery-preallocated.stderr', 'recovery-preallocated.stdout',
           'recovery_binding.py', 'run-recovery.py', 'source-inventory-tests.stderr', 'source-inventory-tests.stdout',
           'source-preflight-first.json', 'source-equivalence.json', 'output-placement-observation.json', 'package-runtime.py']
    paths = {RUN / name for name in top}
    for name in directories:
        for parent, dirs, files in os.walk(RUN / name, followlinks=False):
            dirs[:] = [d for d in dirs if d != '__pycache__' and not (Path(parent) / d).is_symlink()]
            paths.update(Path(parent) / f for f in files)
    archive = OUT / 'evidence.tar.gz'
    inventory = {}
    excluded = []
    with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as tar:
        for p in sorted(paths):
            rel = str(p.relative_to(RUN))
            assert not p.is_symlink() and p.is_file()
            with p.open('rb') as f:
                magic = f.read(4)
            if magic == b'\x7fELF':
                excluded.append({'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())})
                continue
            data = p.read_bytes()
            assert len(data) < 32 * 1024**2
            assert not ('kubeconfig' in p.name or p.suffix in ['.key', '.pem'])
            inventory[rel] = {'bytes': len(data), 'sha256': digest(data)}
            info = tarfile.TarInfo(rel)
            info.size = len(data)
            info.mode = 0o644
            tar.addfile(info, io.BytesIO(data))
    readback = {}
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
            data = tar.extractfile(member).read()
            assert member.name not in readback
            readback[member.name] = {'bytes': len(data), 'sha256': digest(data)}
            assert data == (RUN / member.name).read_bytes()
    assert readback == inventory
    save(OUT / 'archive-inventory.json', inventory)
    for name in ['recovery-audit.json', 'source-equivalence.json', 'actual-tool-receipts.json', 'binding-controls.json', 'output-placement-observation.json']:
        (OUT / name).write_bytes((RUN / name).read_bytes())
    (OUT / 'build-readback.json').write_bytes((RUN / 'build/independent-readback.json').read_bytes())
    result = {'complete': True, 'source_revision': revision,
              'archive': {'members': len(inventory), 'logical_bytes': sum(x['bytes'] for x in inventory.values()),
                          'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes())},
              'excluded_local_executables': excluded,
              'complete_operations': 728, 'outcomes': {'ok': 666, 'unknown': 62},
              'final_batch_reads': 4, 'fresh_voter_drains': 12, 'exited_lifetimes': 14,
              'retained_wal_files': 66, 'retained_wal_bytes': 2572835,
              'default_off': True, 'actual_chaos_complete': False, 'runtime_performance_complete': False,
              'scope': 'Matching release and ordinary owned three-voter recovery only. Original histories, logs and small WAL fixtures are included; large executables and checkout remain local. No historical failed preflight has been removed.'}
    save(OUT / 'result.json', result)
    print(json.dumps({k:v for k,v in result.items() if k != 'excluded_local_executables'}, indent=2))

if __name__ == '__main__':
    main()
