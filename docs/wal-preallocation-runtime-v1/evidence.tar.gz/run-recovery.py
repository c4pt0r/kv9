"""Run the frozen complete native recovery scenario with explicit feature/storage bindings."""
import argparse, hashlib, importlib.util, json, os, shutil, sys, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'source'
sys.path.insert(0,str(SOURCE/'scripts'))
from recovery_binding import normal_build

def digest(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--variant',choices=['default','preallocated'],required=True)
    args=parser.parse_args()
    build=HERE/('recovery-input-'+args.variant)
    output=HERE/('recovery-'+args.variant)
    data=Path('/tmp/kv9-wal-preallocation-recovery-20260915-first-'+args.variant)
    if output.exists() or data.exists():raise ValueError('fresh output and NVMe fixture directory required')
    if os.stat('/tmp').st_dev != os.stat('/home/dongxu/kv9').st_dev:raise ValueError('expected existing NVMe fixture device changed')
    for path in [HERE,Path('/tmp')]:
        stats=os.statvfs(path)
        if stats.f_bavail*stats.f_frsize < 24*1024**3:raise ValueError('recovery launch headroom insufficient')
    spec=importlib.util.spec_from_file_location('native_frozen',SOURCE/'scripts/native-batch-e2e.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    # The scenario, full-history validator and endpoint semantics remain the
    # frozen source. The separate binder permits only the declared WAL feature.
    module.normal_build=normal_build
    original=module.StreamingFixture
    class NvmeFixture(original):
        def __init__(self,out,retained_build):
            super().__init__(out,retained_build)
            data.mkdir(mode=0o700)
            (out/'data').symlink_to(data,target_is_directory=True)
            save(out/'storage.json',{'logical_data_path':str(out/'data'),'physical_data_path':str(data),
                'device':data.stat().st_dev,'bulk_output':str(output),'placement':'Fresh NVMe fixture through an explicit new symlink; no existing data moved or symlink replaced.'})
    module.StreamingFixture=NvmeFixture
    protected={str(p):digest(p) for p in [HERE/'run-recovery.py',HERE/'recovery_binding.py',SOURCE/'scripts/native-batch-e2e.py',build/'build.json',build/'kv9',build/'workload/kv9-batch-workload']}
    result={'complete':False,'variant':args.variant,'started_ns':time.time_ns(),'source_revision':'86aa6fc07d82f4d49b43fbfe309e0e5c20276da5','inputs':protected,'scope':'Ordinary three-voter WAL recovery; frozen full native histories and final batch reads with explicit feature binding. Not actual Chaos Mesh or throughput.'}
    try:
        sys.argv=[str(SOURCE/'scripts/native-batch-e2e.py'),'--build',str(build),'--output',str(output)]
        module.main()
        summary=json.loads((output/'summary.json').read_text())
        if not summary['complete']:raise ValueError('native scenario incomplete')
        if any(digest(Path(name))!=expected for name,expected in protected.items()):raise ValueError('runtime inputs changed')
        # Copy completed owned fixtures into data-volume retention. Keep their
        # original NVMe paths intact for independent readback in this phase.
        retained=output/'retained-wal';retained.mkdir()
        inventory={}
        for path in sorted(data.rglob('*')):
            if path.is_symlink():raise ValueError('unexpected symlink inside owned WAL fixture')
            if not path.is_file():continue
            relative=path.relative_to(data);dest=retained/relative;dest.parent.mkdir(parents=True,exist_ok=True)
            before=digest(path);size=path.stat().st_size;shutil.copy2(path,dest)
            if digest(dest)!=before or digest(path)!=before or dest.stat().st_size!=size:raise ValueError('retention copy differs')
            inventory[str(relative)]={'source':str(path),'retained':str(dest),'bytes':size,'sha256':before}
        save(output/'wal-retention.json',inventory)
        result.update(complete=True,retained_files=len(inventory),retained_bytes=sum(x['bytes'] for x in inventory.values()),
                      summary_sha256=digest(output/'summary.json'),wal_retention_sha256=digest(output/'wal-retention.json'))
    except BaseException as error:
        result['failure']=repr(error);raise
    finally:
        result['ended_ns']=time.time_ns();save(HERE/('recovery-'+args.variant+'-result.json'),result)
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
