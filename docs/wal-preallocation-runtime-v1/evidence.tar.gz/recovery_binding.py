"""Exact same-source bindings for default or solely WAL-preallocation servers."""
import hashlib
from pathlib import Path
import json
from benchmark import read

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def normal_build(build):
    """Use the existing standalone build-benchmark layout, never its calibration server."""
    manifest = read(build / "build.json")
    feature = manifest.get("wal_payload_preallocation_enabled")
    if type(feature) is not bool:
        raise ValueError("explicit WAL feature selection required")
    workload = read(build / "workload/build.json")
    sources = read(build / "workload/sources.json")
    if manifest["dirty"] is not False or workload["dirty"] is not False:
        raise ValueError("normal transport acceptance requires a clean frozen source")
    if (digest(build / "kv9") != manifest["binaries"]["kv9"]["sha256"] or
        digest(build / "workload/kv9-batch-workload") != workload["binary_sha256"] or
        digest(build / "workload/build.json") != manifest["workload_build_sha256"] or
        any(workload[key] != manifest[key] for key in ("revision", "dirty", "source_tree_sha256", "profile", "rustc")) or
        sources["sources"] != manifest["sources"] or sources["revision"] != manifest["revision"] or
        sources["dirty"] is not False or sources["source_tree_sha256"] != manifest["source_tree_sha256"] or
        hashlib.sha256(json.dumps(sources["sources"], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            != manifest["source_tree_sha256"]):
        raise ValueError("standalone server/client source and executable provenance differs")
    attestation = {}
    for name, path, command, wanted in (
        ("server", build / "kv9-cargo.jsonl", manifest["binaries"]["kv9"]["command"],
         ("kv9", "kv9_engine", "kv9_raft", "kv9_server")),
        ("workload", build / "workload/cargo.jsonl", sources["command"],
         ("kv9-batch-workload", "kv9_engine", "kv9_raft", "kv9_server")),
    ):
        if name == "server" and feature:
            if ("--all-features" in command or "--no-default-features" in command or
                command.count("--features") != 1 or
                command[command.index("--features") + 1:] != ["wal-payload-preallocation"]):
                raise ValueError("server command lacks the exact preallocation-only feature")
        elif any(flag in command for flag in ("--features", "--all-features", "--no-default-features")):
            raise ValueError("default server and native client require default Cargo features")
        records = [json.loads(line) for line in path.read_text().splitlines()]
        selected = {}
        for target in wanted:
            rows = [r for r in records if r.get("reason") == "compiler-artifact" and
                    r.get("target", {}).get("name") == target]
            expected = ["wal-payload-preallocation"] if name == "server" and feature and target in ("kv9", "kv9_engine") else []
            if len(rows) != 1 or rows[0]["features"] != expected:
                raise ValueError("missing, ambiguous or unexpected Cargo artifact: " + target)
            selected[target] = rows[0]
        executable = selected[wanted[0]]
        if not executable.get("executable") or "bin" not in executable["target"]["kind"]:
            raise ValueError("selected Cargo artifact is not the standalone executable")
        attestation[name] = dict(command=command, artifacts=selected, cargo_sha256=digest(path))
    attestation["wal_payload_preallocation_enabled"] = feature
    return manifest, workload, attestation
