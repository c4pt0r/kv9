#!/usr/bin/env python3
"""Package bounded qualification evidence; keep binaries local."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

R=Path('/home/dongxu/kv9');S=Path(__file__).resolve().parent
O=R/'docs/entry-buffer-qualification-v1';O.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
audit=json.loads((S/'qualification-audit.json').read_text());assert audit['complete']
members={}
excluded=[]
for p in sorted(S.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    if any(part.startswith('issue9') for part in p.relative_to(S).parts):continue
    with p.open('rb') as f: magic=f.read(4)
    if magic==b'\x7fELF' or p.suffix=='.olean':
        excluded.append(str(p.relative_to(S)));continue
    members['experiment/'+str(p.relative_to(S))]=p
for directory in ('scripts/entry-buffer','proofs/lean/entry-buffer'):
    for p in sorted((R/directory).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:members['repo/'+str(p.relative_to(R))]=p
members['repo/scripts/build_cache.py']=R/'scripts/build_cache.py'
for rel in ('scripts/inline-key/test.py','scripts/inline-key/model.rs','scripts/engine-interface-counting/src/counting.rs'):
    members['repo/'+rel]=R/rel
records=[];archive=O/'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,p in sorted(members.items()):
                assert not p.is_symlink()
                data=p.read_bytes();info=tar.gettarinfo(str(p),arcname=name)
                info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
                with p.open('rb') as f:tar.addfile(info,f)
                records.append(dict(path=name,bytes=len(data),sha256=sha(data)))
with tarfile.open(archive,'r:gz') as tar:
    assert tar.getnames()==[r['path'] for r in records]
    for r in records:
        data=tar.extractfile(r['path']).read();assert len(data)==r['bytes'] and sha(data)==r['sha256']
manifest=dict(complete=True,members=len(records),expanded_bytes=sum(r['bytes'] for r in records),
              compressed_bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),all_members_read_back=True,
              local_root=str(S),selected_layout='layout',excluded_binaries_and_lean_objects=excluded,
              limits='No timing, new database/Redis, external MinIO, distributed recovery or actual Chaos acceptance. Conditional proof; production unchanged.')
for name,data in [('manifest.json',manifest),('members.json',records)]:
    (O/name).write_text(json.dumps(data,indent=2)+'\n')
for name in ('qualification-plan.json','qualification-audit.json','next-performance-plan.json'):
    shutil.copyfile(S/name,O/name)
shutil.copyfile(S/'layout/observations.json',O/'allocation-observations.json')
(O/'README.md').write_text(f"""# Single-buffer qualification evidence

See the [report](../ENTRY-BUFFER-QUALIFICATION.md). Source/model/proof/layout
qualification passes; engine timing and production promotion remain pending.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['sha256']}`.
Every member size/hash passed readback; [members.json](members.json) and
[manifest.json](manifest.json) record retained bytes and excluded local binaries.

The packet contains the two engine/common workspaces, exact private type and
reviewed patch, inherited and payload models, full Clippy/build/test outputs,
23-theorem / 13-control conditional proof, 198 allocator rows, disassembly and
independent audit. Selected dependency sources match all 50 source/manifest
members of Cargo.lock-pinned archives. Reused build-cache/test/model/counter
helpers are included. Retained executable identities remain in build records.

The selected allocation probe is `layout`. Initial proof-authoring diagnostics
are retained separately and do not count as accepted proof. No latency is
recorded by this allocation-only probe.

Reproduction uses source base `e9ebdc4` and these experiment tools; absolute
paths and a pinned Lean binary are recorded. Restore those inputs or identify
a fresh attempt without relabeling retained results. The prospective
[next screen](next-performance-plan.json) has not been executed. Its original
corpus is in the [outlined packet](../outlined-mutation-path-v1/README.md),
member `outlined/groups.bin`.

No new database/Redis, MinIO, ordinary distributed recovery or actual Chaos
acceptance is included. No industrial checklist item closes here.
""")
print(json.dumps(manifest))
