from pathlib import Path
import hashlib, importlib.util, json, os, re, shutil, subprocess, time
repo=Path('/home/dongxu/kv9'); package=repo/'scripts/redis-reference'; out=Path('/tmp/kv9-redis3-client-legacy-source-first')
os.environ.update(CARGO_TARGET_DIR=str(repo/'target'),CARGO_BUILD_JOBS='4',CARGO_NET_OFFLINE='true')
out.mkdir()
def save(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
names=sorted([p for p in (package/'src').rglob('*.rs')]+[package/'Cargo.toml',package/'Cargo.lock',repo/'crates/server/src/bin/kv9-batch-benchmark/common.rs'])
def snapshot(): return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in names}
before=snapshot();save('source-before.json',before)
for p in names:
 target=out/'source'/p.relative_to(repo);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
spec=importlib.util.spec_from_file_location('redis3_cache',repo/'scripts/build_cache.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
commands=[
 ('compile-tests',['cargo','test','--locked','--bin','kv9-redis-batch-reference','--no-run','--message-format=json-render-diagnostics'],True),
 ('tests',['cargo','test','--locked','--bin','kv9-redis-batch-reference','--','--test-threads=4'],False),
 ('clippy',['cargo','clippy','--locked','--bin','kv9-redis-batch-reference','--tests','--','-D','warnings'],False),
 ('build',['cargo','build','--locked','--bin','kv9-redis-batch-reference','--message-format=json-render-diagnostics'],True),
]
result={'complete':False,'commands':[]};save('commands.json',commands)
try:
 with mod.BuildCache(package,out,False,before) as cache:
  for name,command,check in commands:
   row={'name':name,'argv':command,'started_ns':time.time_ns()};result['commands'].append(row);save('result.json',result)
   print(name,'started',flush=True)
   with (out/(name+'.stdout')).open('x') as stdout,(out/(name+'.stderr')).open('x') as stderr:
    row['exit_code']=cache.run(command,stdout=stdout,stderr=stderr,timeout=1200).returncode
   row['ended_ns']=time.time_ns()
   if check:cache.check_artifacts(out/(name+'.stdout'))
   if name=='tests':
    text=(out/(name+'.stdout')).read_text()
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    assert len(matches)==1 and int(matches[0][0])>=20 and matches[0][1:]==('0','0'),matches
    assert len(re.findall(r'^test wire::confirmation_tests::\w+ \.\.\. ok$',text,re.M))==7
    row['test_results']=matches
   if name=='build':
    rows=[json.loads(line) for line in (out/'build.stdout').read_text().splitlines()]
    bins=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='kv9-redis-batch-reference']
    assert len(bins)==1
    binary=Path(bins[0]);assert binary.stat().st_size<=512*1024**2
    retained=out/'kv9-redis-batch-reference';shutil.copy2(binary,retained)
    sha=hashlib.sha256(retained.read_bytes()).hexdigest();assert hashlib.sha256(binary.read_bytes()).hexdigest()==sha
    build={'version':1,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'dirty':bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo)),'source_tree_sha256':hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'binary_sha256':sha,'profile':'debug','rustc':subprocess.check_output(['rustc','-Vv'],text=True).strip()}
    save('build.json',build);row['binary_bytes']=retained.stat().st_size
   assert snapshot()==before,'client source changed during validation'
   save('result.json',result);print(name,'passed',flush=True)
 result['complete']=True;save('source-after.json',snapshot())
except BaseException as error:
 result['failure']=repr(error);raise
finally:save('result.json',result)
