from pathlib import Path
import hashlib, importlib.util, json, os, socket, subprocess, time
out=Path('/tmp/kv9-redis3-client-process-reader-first')
prior=Path('/tmp/kv9-redis3-client-process-first')
source=Path('/tmp/kv9-redis3-client-schema-source-first')
fixture=Path('/tmp/kv9-write-redis3-correctness-first')
helper=Path('/tmp/kv9-redis-batch-reference-preparation/run_fixture.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='008c5bea0640a4a5a092feb6617798a84e9dd4889fd11bf8c6791cfe0852864a'
spec=importlib.util.spec_from_file_location('redis3_readback',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ready=json.loads((fixture/'ready.json').read_text())
def save(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
def identity():
 assert time.time_ns()+30_000_000_000 < ready['hold_expires_unix_ns']
 for node in ready['nodes'].values():
  ident=node['identity'];raw=Path('/proc',str(ident['pid']),'stat').read_text()
  assert int(raw[raw.rfind(')')+2:].split()[19])==ident['start_ticks']
 assert os.statvfs('/home/dongxu/kv9').f_bavail*os.statvfs('/home/dongxu/kv9').f_frsize>=80*1024**3
result={'complete':False,'scope':'Debug client correctness only; no performance acceptance','cases':[]}
try:
 identity()
 for batch in (1,64):
  for replicas in (1,2):
   label=f'b{batch}-wait{replicas}'
   config=dict(version=4,address='127.0.0.1:17379',deadline_ms=1000,run_id=f'redis3-v4-{label}',seed=71,workers=4,keys=128,batch_size=batch,value_bytes=128,read_percent=0,warmup_calls=8,measure_ms=1000,max_calls=64,load={'kind':'closed_loop'},read_api='get' if batch==1 else 'mget',write_api='set' if batch==1 else 'mset',write_confirmation={'kind':'wait','replicas':replicas,'timeout_ms':100})
   save(label+'.config.json',config)
   case_out=prior if (prior/label/'report.json').exists() else out
   command=['taskset','-c','6-15,22-31',str(source/'kv9-redis-batch-reference'),'--config',str(out/(label+'.config.json')),'--output',str(case_out/label),'--build-manifest',str(source/'build.json')]
   row={'label':label,'argv':command,'started_ns':time.time_ns()};result['cases'].append(row);save('result.json',result)
   if case_out==prior:
    old_row=json.loads((prior/'result.json').read_text())['cases'][0]
    assert old_row['label']==label and old_row['exit_code']==0
    row.update(old_row);row['reused_original_client_run']=True
   else:
    with (out/(label+'.stdout')).open('x') as stdout,(out/(label+'.stderr')).open('x') as stderr:
     child=subprocess.Popen(command,stdout=stdout,stderr=stderr);row['pid']=child.pid
     try:row['exit_code']=child.wait(timeout=120)
     finally:
      if child.poll() is None:child.kill();child.wait()
   row['ended_ns']=time.time_ns();row['pid_absent_after_reap']=not Path('/proc',str(row['pid'])).exists()
   assert row['exit_code']==0 and row['pid_absent_after_reap']
   report=json.loads((case_out/label/'report.json').read_text());row['original_report_path']=str(case_out/label/'report.json');assert report['complete'] and not report['timing_eligible']
   assert report['stop_reason']=='operation_limit' and report['measured_issued']==report['measured_completed']==64
   stats=report['metrics']['measurement']['statistics'][1]
   assert stats['populations'][0]['calls']==64 and stats['populations'][0]['input_items']==64*batch
   assert stats['populations'][1]['calls']==stats['populations'][2]['calls']==0
   assert stats['command_attempts']==stats['confirmation_attempts']==64 and stats['total_resp_command_attempts']==128
   assert sum(stats['replica_confirmation_replies'][replicas:])==64
   for stage in report['metrics'].values():assert stage['valid'] and all(op['data_failures']==0 for op in stage['statistics'])
   # A fresh write on this connection followed by WAIT 2 covers all earlier
   # primary replication offsets, including other worker connections' writes.
   barrier=(config['run_id']+'-barrier').encode()
   with socket.create_connection(('127.0.0.1',17379),timeout=2) as conn:
    conn.sendall(m.resp_encode([b'SET',barrier,b'complete'])+m.resp_encode([b'WAIT',b'2',b'1000']))
    with conn.makefile('rb') as stream:
     assert m.resp_read(stream)==b'OK';assert m.resp_read(stream)==2
   keys=[f"{config['run_id']}:{i:016x}".encode() for i in range(config['keys']+1)]
   datasets={name:m.request(node['address'],[b'MGET']+keys) for name,node in ready['nodes'].items()}
   assert all(values==datasets['primary'] for values in datasets.values())
   m.valid_dataset(config,dict(zip(keys,datasets['primary'],strict=True)))
   save(label+'.dataset.json',{'keys_hex':[x.hex() for x in keys],'values_hex':[x.hex() for x in datasets['primary']],'matching_nodes':list(datasets)})
   row.update(measured_successes=64,measured_input_items=64*batch,confirmation_attempts=64,replica_confirmation_replies=stats['replica_confirmation_replies'],matching_keys_per_node=len(keys),barrier_replicas=2)
   identity();save('result.json',result);print(label,'passed',flush=True)
 result['complete']=True
except BaseException as error:
 result['failure']=repr(error);raise
finally:save('result.json',result)
print('PASS: four real Redis replication-confirmed client correctness cells')
