#!/usr/bin/env python3
"""One owned, memory-only Redis3 correctness run, followed by a bounded hold."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
HELPER = Path('/tmp/kv9-redis-batch-reference-preparation/run_fixture.py')
HELPER_SHA = '008c5bea0640a4a5a092feb6617798a84e9dd4889fd11bf8c6791cfe0852864a'
SERVER = '/usr/bin/redis-server'
SERVER_SHA = '1b2950213684d355e0e49fe6702c7bfb9d40b78f0da9ce289fc0e8f2a295e540'
CAP = 4 * 1024**3
FLOOR = 80 * 1024**3


def sha(path):
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(name, value):
    path = ROOT / name
    with path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def require(value, reason):
    if not value:
        raise ValueError(reason)


require(sha(HELPER) == HELPER_SHA, 'inherited helper changed')
spec = importlib.util.spec_from_file_location('inherited_redis_fixture', HELPER)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
children = h.Children(ROOT)
held = []
paused = set()
nodes = {}
history = (ROOT / 'history.jsonl').open('x', buffering=1)
sequence = 0


def guard():
    v = os.statvfs(ROOT)
    free = v.f_bavail * v.f_frsize
    used = sum(p.stat().st_blocks * 512 for p in ROOT.rglob('*') if p.is_file())
    require(free >= FLOOR, '80 GiB available floor exhausted')
    require(used <= CAP, '4 GiB output cap exhausted')
    return {'available_bytes': free, 'allocated_bytes': used}


def record(kind, value):
    global sequence
    sequence += 1
    history.write(json.dumps({'sequence': sequence, 'kind': kind,
                             'observed_ns': time.time_ns(), **value}) + '\n')


class Connection:
    def __init__(self, port):
        self.port = port
        self.socket = socket.create_connection(('127.0.0.1', port), timeout=2)
        self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.stream = self.socket.makefile('rb')

    def close(self):
        self.stream.close()
        self.socket.close()

    def command(self, args, deadline=None, phase='control'):
        start = time.monotonic_ns()
        remaining = 2 if deadline is None else deadline - time.monotonic()
        require(remaining > 0, 'logical command deadline exhausted')
        self.socket.settimeout(remaining)
        wire = h.resp_encode(args)
        self.socket.sendall(wire)
        reply = h.resp_read(self.stream)
        # Small control replies and INFO payloads are retained verbatim.
        rendered = reply.decode('utf-8') if isinstance(reply, bytes) else reply
        if isinstance(reply, list):
            rendered = [None if x is None else {'bytes': len(x), 'sha256': hashlib.sha256(x).hexdigest()} for x in reply]
        record('command', {'phase': phase, 'port': self.port, 'connection_local': self.socket.getsockname(),
                          'command': args[0].decode(), 'argument_count': len(args),
                          'wire_bytes': len(wire), 'wire_sha256': hashlib.sha256(wire).hexdigest(),
                          'reply': rendered, 'elapsed_ns': time.monotonic_ns() - start})
        return reply


def request(port, args, phase):
    c = Connection(port)
    try:
        return c.command(args, phase=phase)
    finally:
        c.close()


def info(port, section, phase):
    raw = request(port, [b'INFO', section.encode()], phase)
    return {k: v for line in raw.decode().splitlines() if line and not line.startswith('#')
            for k, sep, v in [line.partition(':')] if sep}


def snapshot(label):
    result = {}
    for name, node in nodes.items():
        identity = h.serial_identity(h.process_identity(node['process'].pid))
        require(identity['start_ticks'] == node['identity']['start_ticks'] and
                identity['boot_id'] == node['identity']['boot_id'], 'owned identity changed')
        result[name] = {'identity': identity, 'listener': h.listener_identity(node['process'].pid, node['port']),
                        'server': info(node['port'], 'server', label),
                        'replication': info(node['port'], 'replication', label),
                        'persistence': info(node['port'], 'persistence', label)}
    save(label + '.json', result)
    return result


def await_replication(timeout=15):
    end = time.monotonic() + timeout
    while True:
        guard()
        last = {name: info(node['port'], 'replication', 'sync-observation') for name, node in nodes.items()}
        primary = last['primary']
        replicas = [last['replica-a'], last['replica-b']]
        if (primary.get('role') == 'master' and primary.get('connected_slaves') == '2'
                and all(r.get('role') == 'slave' and r.get('master_link_status') == 'up'
                        and r.get('master_sync_in_progress') == '0'
                        and r.get('master_host') == '127.0.0.1' and r.get('master_port') == '17379'
                        and r.get('master_replid') == primary.get('master_replid') for r in replicas)
                and all('state=online' in primary.get('slave' + str(i), '') for i in range(2))):
            return last
        require(time.monotonic() < end, 'replica initialization did not complete')
        time.sleep(.05)


def value(index, nonce):
    prefix = index.to_bytes(8, 'big') + nonce.to_bytes(8, 'big')
    return prefix + hashlib.sha256(prefix).digest() * 3 + hashlib.sha256(prefix).digest()[:16]


def key(index):
    return ('redis3-owned:%016x' % index).encode()


expected = {key(i): value(i, 0) for i in range(4096)}


def verify_dataset(label):
    summaries = {}
    for name, node in nodes.items():
        digest = hashlib.sha256()
        for start in range(0, 4096, 64):
            keys = [key(i) for i in range(start, start + 64)]
            actual = request(node['port'], [b'MGET', *keys], label)
            require(actual == [expected[k] for k in keys], 'dataset mismatch on ' + name)
            for k, v in zip(keys, actual):
                digest.update(k + v)
        require(request(node['port'], [b'GET', b'redis3-owned:missing'], label) is None, 'missing key was written')
        summaries[name] = {'keys': 4096, 'key_value_sha256': digest.hexdigest(), 'missing_key_null': True}
    save(label + '.json', summaries)
    return summaries


def assert_paused():
    node = nodes['replica-b']
    current = h.process_identity(node['process'].pid)
    require(current['start_ticks'] == node['identity']['start_ticks'] and current['boot_id'] == node['identity']['boot_id'], 'paused identity changed')
    stat = (Path('/proc') / str(node['process'].pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    require(stat[0] in ('T', 't'), 'replica B is not stopped')


def write_wait(label, batch, required, nonce, shortfall=False, stopped=False):
    guard()
    if stopped:
        assert_paused()
    keys = [key(i) for i in range(batch)]
    vals = [value(i, nonce) for i in range(batch)]
    args = [b'SET' if batch == 1 else b'MSET']
    for k, v in zip(keys, vals):
        args.extend([k, v])
    c = Connection(17379)
    start = time.monotonic_ns()
    deadline = time.monotonic() + 2
    try:
        require(c.command(args, deadline, label) == b'OK', 'write reply not OK')
        for k, v in zip(keys, vals):
            expected[k] = v
        count = c.command([b'WAIT', str(required).encode(), b'100'], deadline, label)
        require(type(count) is int, 'WAIT reply is not an integer')
        require(count == 1 if shortfall else count >= required, 'unexpected WAIT confirmation count')
        if stopped:
            assert_paused()
        result = {'label': label, 'api': args[0].decode(), 'items': batch, 'wait_required': required,
                  'wait_acknowledged': count, 'write_reply': 'OK', 'same_connection': True,
                  'command_attempts': 2, 'logical_attempts': 1, 'retry_count': 0,
                  'outcome': 'unknown_confirmation' if shortfall else 'success',
                  'elapsed_ns': time.monotonic_ns() - start, 'nonce': nonce}
        record('logical-write', result)
        return result
    finally:
        c.close()


def resume_owned():
    for name in list(paused):
        node = nodes[name]
        require(node['process'].poll() is None, 'stopped owned process exited')
        current = h.process_identity(node['process'].pid)
        require((current['start_ticks'], current['boot_id']) ==
                (node['identity']['start_ticks'], node['identity']['boot_id']), 'refuse resume of changed PID')
        os.kill(node['process'].pid, signal.SIGCONT)
        end = time.monotonic() + 2
        while True:
            state = (Path('/proc') / str(node['process'].pid) / 'stat').read_text().rsplit(')', 1)[1].split()[0]
            if state not in ('T', 't'):
                break
            require(time.monotonic() < end, 'resume was not observed')
            time.sleep(.01)
        paused.remove(name)
        record('resume', {'name': name, 'pid': node['process'].pid, 'state': state, 'same_lifetime': True})


def interrupted(signum, frame):
    raise RuntimeError('fixture interrupted by signal ' + str(signum))


signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
result = {'complete': False, 'controls_accepted': False, 'started_ns': time.time_ns(),
          'pid': os.getpid(), 'cpu_affinity': sorted(os.sched_getaffinity(0)), 'benchmark': False}
try:
    require(not (ROOT / 'invocation.json').exists(), 'one-use invocation already exists')
    require(sha(SERVER) == SERVER_SHA, 'Redis server bytes changed')
    save('invocation.json', {'argv': sys.argv, 'pid': os.getpid(), 'started_ns': time.time_ns(),
                            'helper_sha256': HELPER_SHA, 'server_sha256': SERVER_SHA,
                            'script_sha256': sha(__file__), 'limits': {'retained_bytes': CAP, 'free_floor_bytes': FLOOR, 'hold_seconds': 900},
                            'authority': 'Parent explicitly authorized owned Redis3 correctness, pause/resume and 15-minute v4 hold.'})
    save('before-capacity.json', guard())
    for port in (17379, 17380, 17381):
        reservation = socket.socket()
        reservation.bind(('127.0.0.1', port))
        held.append((port, reservation))
    for name, port in [('primary', 17379), ('replica-a', 17380), ('replica-b', 17381)]:
        data = ROOT / (name + '-data')
        data.mkdir()
        config = '\n'.join(['bind 127.0.0.1', 'port ' + str(port), 'protected-mode yes', 'daemonize no',
                            'logfile ""', 'dir ' + str(data), 'save ""', 'appendonly no', 'maxmemory 64mb',
                            'maxmemory-policy noeviction', 'io-threads 1', 'maxclients 512',
                            *([] if name == 'primary' else ['replicaof 127.0.0.1 17379', 'replica-read-only yes'])]) + '\n'
        config_path = ROOT / (name + '.conf')
        with config_path.open('x') as f:
            f.write(config)
        next(sock for p, sock in held if p == port).close()
        child = children.launch(name, [SERVER, str(config_path)], SERVER)
        nodes[name] = {'port': port, 'process': child, 'identity': children.rows[-1]['identity']}
        end = time.monotonic() + 5
        while True:
            require(child.poll() is None, 'Redis exited during startup')
            try:
                require(request(port, [b'PING'], 'startup') == b'PONG', 'unexpected PING')
                break
            except ConnectionRefusedError:
                require(time.monotonic() < end, 'startup listener timeout')
                time.sleep(.01)
        h.listener_identity(child.pid, port)
        for field, target in [(b'save', b''), (b'appendonly', b'no'), (b'maxmemory', b'67108864'),
                              (b'maxmemory-policy', b'noeviction'), (b'io-threads', b'1')]:
            actual = request(port, [b'CONFIG', b'GET', field], 'configuration')
            require(actual == [field, target], 'configuration readback differs')
    await_replication()
    before = snapshot('before-controls')
    init = Connection(17379)
    try:
        for start in range(0, 4096, 64):
            args = [b'MSET']
            for i in range(start, start + 64):
                args.extend([key(i), expected[key(i)]])
            require(init.command(args, phase='initialize') == b'OK', 'initialization write failed')
        require(init.command([b'WAIT', b'2', b'1000'], phase='initialize') >= 2, 'initialization WAIT 2 failed')
    finally:
        init.close()
    verify_dataset('initialized-dataset')
    controls = []
    for nonce, (batch, required) in enumerate([(1, 1), (64, 1), (1, 2), (64, 2)], 1):
        controls.append(write_wait('positive-' + str(nonce), batch, required, nonce))
    b = nodes['replica-b']
    require(h.process_identity(b['process'].pid)['start_ticks'] == b['identity']['start_ticks'], 'stop identity changed')
    paused.add('replica-b')
    os.kill(b['process'].pid, signal.SIGSTOP)
    end = time.monotonic() + 2
    while True:
        pid, status = os.waitpid(b['process'].pid, os.WUNTRACED | os.WNOHANG)
        if pid:
            require(os.WIFSTOPPED(status), 'owned child did not stop')
            record('stop', {'pid': pid, 'wait_status': status, 'stop_signal': os.WSTOPSIG(status)})
            break
        require(time.monotonic() < end, 'stopped-child notification missing')
        time.sleep(.01)
    assert_paused()
    controls.append(write_wait('paused-wait1-set', 1, 1, 5, stopped=True))
    controls.append(write_wait('paused-wait1-mset', 64, 1, 6, stopped=True))
    controls.append(write_wait('paused-wait2-set', 1, 2, 7, shortfall=True, stopped=True))
    controls.append(write_wait('paused-wait2-mset', 64, 2, 8, shortfall=True, stopped=True))
    resume_owned()
    await_replication(timeout=10)
    sentinel = Connection(17379)
    try:
        require(sentinel.command([b'SET', b'redis3-owned:barrier', b'after-resume'], phase='resume-barrier') == b'OK', 'barrier write failed')
        require(sentinel.command([b'WAIT', b'2', b'1000'], phase='resume-barrier') >= 2, 'resume WAIT 2 failed')
    finally:
        sentinel.close()
    verify_dataset('resumed-dataset')
    for node in nodes.values():
        require(request(node['port'], [b'GET', b'redis3-owned:barrier'], 'resume-barrier') == b'after-resume', 'barrier value differs')
    after = snapshot('after-controls')
    require(all(before[n]['server']['run_id'] == after[n]['server']['run_id'] for n in nodes), 'Redis run ID changed')
    require(all(v['persistence']['aof_enabled'] == '0' and v['persistence']['rdb_bgsave_in_progress'] == '0' for v in after.values()), 'persistence/full sync activity unresolved')
    result['controls_accepted'] = True
    save('controls-result.json', {'complete': True, 'accepted': True, 'controls': controls,
                                 'logical_calls': 8, 'successes': 6, 'unknown_confirmations': 2,
                                 'logical_key_writes': 260, 'wire_commands': 16, 'retries': 0,
                                 'setup_and_barrier_excluded': True, 'three_datasets_verified': True,
                                 'benchmark': False})
    hold_start = time.monotonic()
    ready = {'complete': True, 'controls_accepted': True, 'supervisor_pid': os.getpid(),
             'ready_ns': time.time_ns(), 'hold_expires_unix_ns': time.time_ns() + 900_000_000_000,
             'stop_request_path': str(ROOT / 'stop-request.json'),
             'nodes': {n: {'address': '127.0.0.1:' + str(v['port']), 'identity': h.serial_identity(v['identity'])} for n, v in nodes.items()},
             'capacity': guard(), 'scope': 'Memory-only owned correctness; available for root v4 checks, no QPS acceptance.'}
    save('ready.json', ready)
    print(json.dumps({'event': 'READY', 'path': str(ROOT / 'ready.json'), **ready}), flush=True)
    while time.monotonic() - hold_start < 900:
        require(all(n['process'].poll() is None for n in nodes.values()), 'owned Redis exited during hold')
        guard()
        if (ROOT / 'stop-request.json').exists():
            result['hold_end_reason'] = 'root_checks_complete_stop_requested'
            break
        time.sleep(1)
    else:
        result['hold_end_reason'] = '15_minute_hold_limit'
    snapshot('before-shutdown')
    result['complete'] = True
except BaseException as error:
    result['error'] = repr(error)
    save('first-failure.json', {'error': repr(error), 'traceback': traceback.format_exc(), 'observed_ns': time.time_ns()})
    traceback.print_exc()
finally:
    for _, sock in held:
        sock.close()
    try:
        resume_owned()
    except BaseException as error:
        result['resume_cleanup_error'] = repr(error)
    errors = children.cleanup()
    result['cleanup_errors'] = errors
    result['cleanup_complete'] = not errors and not paused and 'resume_cleanup_error' not in result
    result['ended_ns'] = time.time_ns()
    result['capacity'] = guard()
    history.close()
    result['history_sha256'] = sha(ROOT / 'history.jsonl')
    result['exit_code'] = 0 if result['complete'] and result['cleanup_complete'] else 1
    save('result.json', result)
    print(json.dumps({'event': 'TERMINAL', **result}), flush=True)
sys.exit(result['exit_code'])
