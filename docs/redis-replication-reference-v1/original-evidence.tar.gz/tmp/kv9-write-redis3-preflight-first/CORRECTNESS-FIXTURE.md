# Proposed three-instance correctness fixture (not executed)

The fixture exercises the actual root-built v4 client, not `redis-benchmark`. Root supplies its source/binary/manifest/schema pins after compilation. The finite wire sequences below state semantic requirements; they are not a shell script or permission to start processes.

## Owned setup

Use one unique output root and three separate data directories on `/dev/shm`. Proposed ports are primary **17379**, replica A **17380**, replica B **17381**, subject to fresh exclusive availability checks. Foreground commands have the form:

```
taskset -c 8-15,22-31 /usr/bin/redis-server <owned-primary.conf>
taskset -c 8-15,22-31 /usr/bin/redis-server <owned-replica-a.conf>
taskset -c 8-15,22-31 /usr/bin/redis-server <owned-replica-b.conf>
```

Each configuration pins `bind 127.0.0.1`, its unique port, `protected-mode yes`, `daemonize no`, `logfile ""`, `io-threads 1`, `maxclients 512`, and an exclusive absolute `dir`. Replicas add `replicaof 127.0.0.1 17379` and `replica-read-only yes`. Use exactly the selected persistence row in README on **all three** nodes. Never point to existing system port 6379 or historical data. No OS/Redis automatic restart is configured.

Record the executable hash, argv, config, PID/start ticks/boot ID, `/proc/PID/exe` device/inode/hash, listener identity, and Redis `run_id` for each process. Read back CONFIG and INFO server/replication/persistence. Require one primary with exactly two expected online replicas, both replicas linked to that primary, no sync in progress, and the chosen AOF settings/status. All three histories remain attributable to those exact processes.

Initialize the fixed 4096-key, 128-byte deterministic dataset. The initializer must keep its connection through a final fresh sentinel write and `WAIT 2`, then verify the full deterministic dataset and reserved sentinel on all three nodes. WAIT on an unrelated connection cannot certify initialization. Retain the initialization history separately from controls. Ensure any full-sync child work is complete before recording controls.

## Finite controls

Use a single worker and distinct expected payload nonces in each control. Bound to **one logical write per control**, not a duration/QPS trial. Root should use the client's maximum-call limit if its validated schema supports this; otherwise retain a focused v4 client entry point rather than inventing JSON fields. The initializer and readback calls are additional explicitly counted phases.

| Phase | Exact requirement | Expected result |
| --- | --- | --- |
| Positive, four calls | SET+WAIT 1, MSET(64)+WAIT 1, SET+WAIT 2, MSET(64)+WAIT 2, each write and WAIT on its worker's same connection | Write reply valid; integer acknowledgments at least requested. Four successes, 130 logical key writes. |
| Pause replica B | Recheck owned PID/start/boot. Send SIGSTOP to that one process. Obtain a stopped-child notification and observed stopped state before any negative-phase write. Keep primary and replica A running. | Same B lifetime is stopped; no sleep alone establishes the boundary. |
| One-replica positive, two calls | Fresh SET+WAIT 1 and MSET(64)+WAIT 1 while B remains stopped | Each confirms through A. Two successes, 65 key writes. |
| Shortfall, two calls | Fresh SET+WAIT 2 and MSET(64)+WAIT 2 while B remains stopped; finite WAIT 100 ms within the same 2-second outer deadline | Valid write replies followed by integer acknowledgments **1 < 2**. Both calls are unknown-confirmation outcomes with no replay. A zero count or transport/deadline failure is retained but does not pass this intended one-remaining-replica control. |
| Resume and catch up | Recheck B identity, SIGCONT, require continued/running state, same PID/start and Redis run ID; no restart. Both replicas must now be running and linked. A fresh sentinel write+WAIT 2 on one connection establishes a new barrier after all preceding writes. | Ack count at least 2 and bounded catch-up. This does not retroactively convert the two unknown client outcomes into successes. |
| Final verification | Read every initialized/touched key and sentinel on primary, A and B; check deterministic payloads and the exact final nonce of the unknown writes. | All three final states match; no lost or duplicated logical retries concealed by final equality. Capture per-phase histories to distinguish those cases. |

There are eight measured-by-the-control logical client writes: six expected confirmation successes and two expected unknown-confirmation outcomes, **260 API key writes** in total (four SET and four MSET(64)); setup/barriers/readbacks are separate. These are proposed counts, not observed results. With eight two-command controls, the expected control wire population is sixteen commands. Require actual attempts, command types, integer acknowledgment counts, reasons and latencies rather than inferring counts from the schedule.

Pause **before a fresh changing write** so an earlier replica offset acknowledgment cannot satisfy the new WAIT. Assert the paused process remains the same stopped lifetime throughout both WAIT 2 controls. Do not kill/restart B: that tests a different failure mode and cannot be described as resumed. The primary's successful write and later convergence are evidence that an insufficient WAIT receipt is not rollback.

## Accounting and cleanup

Store complete original v4 reports/histories and all outcomes, including the shortfall calls. Report whole write-plus-WAIT duration and any component samples as separate populations; no percentile averaging or new performance comparison. Distinguish logical batches, keys, wire commands, offered/issued/dropped slots, connection attempts, retries, deadline/transport/protocol errors, and unknown writes. Exact client process identities and exit/reap records are required even when the intended report includes unknown outcomes.

Collect the existing source-bound CPU/RSS/resource intervals for all three servers and the actual client children. Aggregate CPU using the same observed interval accounting, with the explicit limit that it is not exclusively measurement-window CPU or per-request service time. Initialization full-sync/RDB children must be identified and closed or reported; they are not hidden inside a single-server roster.

Retain original configs, INFO/CONFIG snapshots, logs, histories, terminal receipts and chosen persistence-directory contents within the bounded reservation. AOF uses multiple files plus manifest: never archive one guessed filename. The correctness proposal reserves 64 MiB total tmpfs data and 128 MiB retained artifacts, checked during execution; exceeding either is a preserved failure. Preserve the existing filesystem/tmpfs guards as well.

Use an outer `finally` which first resumes any **still-owned stopped** child, then applies the inherited bounded terminate/kill/wait/reap sequence to all three owned processes and clients. Capture first failures and cleanup failures separately. Recheck PID/start/boot before every signal; if identity is ambiguous, refuse to signal that process and report the cleanup failure. Never signal the system Redis. No repeated phase or automatic retry to obtain the expected result; no failure-time report is overwritten by post-resume verification.

Root must supply the executable wrapper and explicit run release after v4 controls compile. This document establishes the finite fixture target only.
