# Redis primary plus two replicas: read-only preflight

This preparation identifies a feasible **local correctness fixture**, pending root's v4 client qualification and explicit launch. No server, benchmark, fault, Redis command against an existing server, VM, or container was started. VM qualification was stopped; its partial report remains incomplete at `/tmp/kv9-lease-clock-vm-preflight-first/incomplete.json`.

## Observed capabilities

`tool-versions-first.json`, `source-tool-bindings.json`, `resources-first.json`, and the two process/port records retain the observations. Redis server, CLI, and benchmark are installed at version **7.0.15**, Ubuntu package `5:7.0.15-1ubuntu0.24.04.4`; server reports jemalloc 5.3.0, 64-bit, build `e53ff17674aa6190`. The server executable SHA-256 is `1b2950213684d355e0e49fe6702c7bfb9d40b78f0da9ce289fc0e8f2a295e540`. `/usr/bin/redis-server` resolves to `/usr/bin/redis-check-rdb`; launch and `/proc/PID/exe` identity checks must allow this exact Debian multi-call executable identity.

Docker is installed, but the read-only `docker image ls ... 'redis*'` query found no matching tagged images. Native host processes need no image acquisition. `taskset`, `numactl`, `ss`, and `lsof` are available. This does not establish any new package or image qualification.

The existing system Redis is PID **2363**, start ticks **3738**, serving loopback port **6379** (IPv4 and IPv6). It must remain untouched. Proposed owned ports **17379–17381** were unbound when inspected; they must be freshly reserved and bound to the actual owned listeners at launch. The privileged read-only identity census completed without gaps. Its earlier unprivileged access failure and the first port-parser header failure are retained.

Available affinity is CPUs 0–31. The observed machine has about 123.4 GiB total RAM and 116 GiB available RAM, with about 61.7 GiB free tmpfs. The latest `/tmp` available capacity was **104,002,551,808 bytes**, only **923,336,704 bytes above the retained 96 GiB preflight floor**. This can support the small bounded correctness proposal below, subject to a fresh reservation; it does not establish capacity for an AOF performance campaign. All values are snapshots, not reservations. Retained performance guards remain 32/16 GiB tmpfs and 96/64 GiB filesystem preflight/runtime, respectively.

## Existing source and fixture reuse

The fixed client source is `/tmp/kv9-point-write-measurement-v3`, revision `0be806d9671e2c50701a64aa7889c8859b7648ba`.

| Existing input | Role and relevant boundary |
| --- | --- |
| `/tmp/kv9-point-write-v3-release-first/redis/kv9-redis-batch-reference` | Retained v3 client, SHA `5a8ac274b8cc6548a072f5305b04936a08cc4d1ba84d50150f675bab563049af`; build manifest `10f9ce2a754a2ef43a6439856c1d5fb00c5a1e5004173e52897a3ea19d6124f0`. Preserve unchanged. |
| `/tmp/kv9-point-write-v3-release-first/native/kv9-batch-benchmark` | Fixed native client, SHA `8da9af469f962a938027d1970141bbe4622f7d42b2b795f720e288fb3f8d5957`; manifest `eb8b4e1421dd4e64dcca59fcc7829926d5789611f6b3748d07c4090f634f2c4c`. |
| `scripts/redis-reference/src/batch/model.rs:35` in the source above | Strict versioned configuration. v3 contains no WAIT setting. |
| `scripts/redis-reference/src/batch/wire.rs:105` and `:219` | GET/SET/MGET/MSET encoding; one command attempt and reply per call, one absolute deadline, connection discarded after failure, no same-call replay. Root's v4 must explicitly extend these counters and semantics. |
| `scripts/redis-reference/src/bin/kv9-redis-batch-reference.rs:115` | One persistent connection per worker. Reuse this ownership for write plus WAIT. |
| `scripts/redis_batch_report.py:169` and adjacent controls | Existing outcome, timing, nonce and resource checks; WAIT outcomes need explicit v4 accounting, not a relabeled v3 report. |
| `/tmp/kv9-redis-batch-reference-preparation/run_fixture.py:43`, `:59`, `:75` | Process identity, owned listener identity, bounded child cleanup. Helper SHA `008c5bea0640a4a5a092feb6617798a84e9dd4889fd11bf8c6791cfe0852864a`. |
| Same helper, `:124`, `:129`, `:163` | Bounded RESP primitives. **`request()` opens a new connection for every call. It cannot implement SET followed by WAIT via two calls.** It is suitable for independent INFO/PING/readback queries. |
| `/tmp/kv9-thin-lto-compressed-performance-preparation-first/matched-driver.py:610` | Original single Redis fixture and lifecycle/resource accounting. It explicitly requires `connected_slaves:0`, `save=""`, and `appendonly=no`; this predicate and its single-process resource roster cannot qualify Redis3 unchanged. |

`source-tool-bindings.json` records all 21 inspected files with original paths, current byte counts, SHA-256 and metadata identity. It binds existing inputs only; v4 source/build/report schema and its test receipts remain pending root inputs.

## Confirmation and persistence scope

`WAIT 1` confirms the primary's preceding writes on at least one replica; `WAIT 2` requests both replicas. WAIT must use the **same connection** as the write. Check the returned count is at least the requested count: timeout also returns a count. Use a positive finite timeout, outside MULTI/Lua. WAIT does not make Redis a strongly consistent failover protocol. [Redis WAIT documentation](https://redis.io/docs/latest/commands/wait/)

Three processes always exist in both arms. WAIT 1 is two confirmed copies within a three-instance deployment; WAIT 2 is three confirmed copies. Count one SET or one MSET(64) plus its WAIT as one logical write call, with two wire commands and separately recorded API/item populations. The call deadline and whole-call latency include both commands. A write reply followed by insufficient WAIT acknowledgments is an **unknown confirmation outcome**, not an undone write. Root is implementing this explicitly in v4.

Two configurations can be stated honestly:

| Mode | All three nodes | Meaning |
| --- | --- | --- |
| Memory replication | `save ""`, `appendonly no`, owned data dirs on tmpfs | Preserves the old Redis memory-only configuration but adds replication. It omits KV9's WAL append/sync work. |
| AOF on tmpfs | `save ""`, `appendonly yes`, `appendfsync always`, `auto-aof-rewrite-percentage 0`, separate owned tmpfs dirs | Includes AOF logging and sync policy in all three nodes; still no host power-loss durability. Disable automatic rewrite explicitly for this finite fixture and retain that setting. |

Redis 7 uses multipart AOF with a manifest, so retention must cover the whole appendonly directory. `appendfsync always` can group commands before fsync; do not equate its syscall count with one fsync per logical API call. `everysec` would be a different declared arm. [Redis persistence documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/persistence/)

WAIT acknowledgment is not an explicit replica AOF fsync receipt. `WAITAOF` is a separate command introduced in Redis 7.2 and is unavailable in installed 7.0.15. AOF-on-tmpfs plus WAIT therefore remains a stated comparison scope, not proof of equal Raft commit, persistence acknowledgment or failover semantics. [Redis WAITAOF documentation](https://redis.io/docs/latest/commands/waitaof/)

## Bounded correctness setup for root

`CORRECTNESS-FIXTURE.md` specifies the proposed finite phases and cleanup. Use owned native processes, fresh directories, no Redis Cluster/Sentinel, no daemonization, no restart policy. Run one persistence mode at a time; qualify the AOF-on-tmpfs mode before describing it as the logged comparison. The memory mode is separately labeled if exercised.

For this correctness-only fixture, propose shared server affinity CPUs **8–15,22–31** and client/helper CPUs **6–7**, consistent with the existing smoke placement. A later timed comparison uses the existing collective server CPUs **2–5** and client CPUs **0–1**: all three Redis nodes share that server allocation. Do not multiply the server CPU allowance by three.

Proposed correctness reservations are **4 GiB RAM**, **64 MiB total owned tmpfs data**, and **128 MiB retained output**, with one fixture and no concurrency with timing. Bound startup to 15 seconds, each control write to 2 seconds, WAIT to 100 ms, catch-up to 10 seconds, and cleanup to the inherited bounded termination/reap path. A missing response or exhausted budget is a retained failure, never a retry. These are prospective finite correctness budgets, not edits to the retained performance protocol.

Replication initialization can require a full sync and temporary RDB work even with periodic saves disabled. Wait for actual role/link/sync completion and stable process identities before controls; preserve replication IDs and offsets. Do not use arbitrary cross-snapshot offset equality while replication heartbeat traffic is live. A primary without persistence must not be automatically restarted in this fixture. [Redis replication documentation](https://redis.io/docs/latest/operate/oss_and_stack/management/replication/)

Remaining blockers: root's actual v4 client and validator build/test pins, exact per-phase v4 invocation shape, chosen persistence mode, fresh exclusive ports and capacity reservation, and an owned pause/resume/cleanup wrapper. No executable correctness driver or new framework was added here. The existing code provides reusable identity, RESP and lifecycle pieces; it does not itself perform this three-instance protocol.

## Retained first failures and limits

`first-inspection-failure.json` preserves the nonexistent fixture-path lookup. `port-reader-first-failure.json` preserves the unhandled ss header; `ports-and-existing-processes.json` retains the unprivileged process access gaps, resolved by the separate privileged read-only record. No server/test execution failed because none was attempted. Source/build, correctness acceptance, throughput, tail latency, and fault acceptance are all **pending** for Redis3/v4.
