"""Derive a prospective exact-candidate write screen; never start a workload."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,shutil
H=Path(__file__).parent
B=Path('/tmp/kv9-fnv-writer-performance-budget-v2-preparation-20260914-first')
G=1024**3
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v): (H/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
old=json.loads((B/'storage-policy.json').read_text());policy=copy.deepcopy(old)
policy['policy_id']='kv9-local-benchmark-storage-v3'
policy['pre_cohort']['host_bytes']=policy['measurement']['host_bytes']=24*G
policy['post_run']['host_floor_bytes']=8*G
save('storage-policy.json',policy)
sub={str(B):str(H),'kv9-fnv-writer-write-ab-c1-c64-storage-v2':'kv9-published-directory-write-ab-c1-c64-storage-v3',
 '/tmp/kv9-fnv-writer-performance-budget-v2-smoke-20260914-first':'/tmp/kv9-published-directory-performance-v3-smoke-20260915-first',
 '/tmp/kv9-fnv-writer-performance-budget-v2-timing-20260914-first':'/tmp/kv9-published-directory-performance-v3-timing-20260915-first',
 '/tmp/kv9-fnv-writer-release-source-20260914-first':'/tmp/kv9-published-directory-release-source-20260914-first',
 '/tmp/kv9-fnv-writer-release-20260914-runtime-source':'/tmp/kv9-published-directory-release-20260914-first',
 '12f44d35590ede5f89337fe731dd950162865154':'483b8c3629b033734f5d7a2b8653a1352304a4b5',
 'd84b0ec8e466a9dc3f4953751605d91c90a90a66df1b03b57a3412e43e42603e':'43d8bcb2d852d6fcbebb7f528808e53b3eb93588e2637195e9053cd91e8d5450',
 'c845942f728d67acc5682af6eb8c7f3e0b06c19ee5f9145942e75711cf92a1af':sha('/tmp/kv9-published-directory-release-20260914-first/build.json'),
 sha(B/'storage-policy.json'):sha(H/'storage-policy.json')}
names=['matched-driver.py','audit.py','retention_audit.py','compressed_retention.py','isolate-and-run.py','check-smoke-corrected.py','test_driver.py','test_audit_contract.py','test_smoke_schema.py','test_storage_policy.py','test_cleanup_metadata.py','test_compressed_retention.py','driver-arguments.json','commands.json','protocol.json']
(H/'v2-original').mkdir(exist_ok=True)
for n in names:(H/'v2-original'/n).write_bytes((B/n).read_bytes())
for name in ('origins','v1-original'):shutil.copytree(B/name,H/name,dirs_exist_ok=True)
def rebind(s):
 # Replace the whole policy literal before individual identifiers to avoid partial mappings.
 s=s.replace(repr(old),repr(policy))
 for a,b in sorted(sub.items(),key=lambda x:len(x[0]),reverse=True):s=s.replace(a,b)
 return s
for n in names:(H/n).write_text(rebind((B/n).read_text()))
# Exact operational host thresholds only; do not touch tmpfs, codec windows or payload caps.
changes={
 'matched-driver.py': [('"retention": 64 * 1024**3','"retention": 24 * 1024**3',2)],
 'audit.py': [("'retention':64*1024**3","'retention':24*1024**3",2)],
 'compressed_retention.py': [('retention_floor_bytes=48*1024**3','retention_floor_bytes=8*1024**3',1),('retention 48 GiB floor/space reservation','retention 8 GiB floor/space reservation',1)],
 'retention_audit.py': [("'retention_floor_bytes':48*1024**3","'retention_floor_bytes':8*1024**3",1)],
 'test_driver.py': [("'retention':64","'retention':24",2)],
 'test_audit_contract.py': [("'retention':64*1024**3","'retention':24*1024**3",3)],
 'test_compressed_retention.py': [('free=48*1024**3-1','free=8*1024**3-1',1)],
 'test_storage_policy.py': [("'kv9-local-benchmark-storage-v2'","'kv9-local-benchmark-storage-v3'",1),("'retention':64*G","'retention':24*G",2),('host_bytes=64*G','host_bytes=24*G',2),('host_floor_bytes=48*G','host_floor_bytes=8*G',1),('free=48*G+reserve','free=8*G+reserve',2),("['retention_floor_bytes'],48*G","['retention_floor_bytes'],8*G",1)]}
for n,pairs in changes.items():
 q=H/n;s=q.read_text()
 for a,b,count in pairs:
  assert s.count(a)==count,(n,a,s.count(a),count);s=s.replace(a,b)
 ast.parse(s);q.write_text(s)
# Rebind hash dependencies in producer/reader -> driver -> audit -> smoke order.
for upstream,downstream in [
 ('compressed_retention.py',['matched-driver.py','audit.py']),
 ('retention_audit.py',['audit.py']),
 ('driver-arguments.json',['audit.py']),
 ('matched-driver.py',['audit.py','check-smoke-corrected.py','commands.json']),
 ('audit.py',['check-smoke-corrected.py'])]:
 old_sha=sha(B/upstream);new_sha=sha(H/upstream)
 for name in downstream:
  q=H/name;s=q.read_text();s=s.replace(old_sha,new_sha);q.write_text(s)
p=json.loads((H/'protocol.json').read_text())
p.update(storage_policy=policy,storage_policy_sha256=sha(H/'storage-policy.json'),driver_sha256=sha(H/'matched-driver.py'),auditor_sha256=sha(H/'audit.py'),runtime_ready=False,capacity_qualified=False,contracts_executed=False)
p['storage_scope']='Prospective storage v3: host24GiB before/during each cohort, host8GiB during serial retention. Unchanged16GiB maximum fresh restore additionally needs8MiB metadata above the floor; bare24GiB is not restore readiness. Every original cohort, byte/codec/campaign cap and failure predicate remains. Empirical whole-campaign budget is not maximum-output assurance.'
p['large_synthetic_qualified']='Inherited unchanged codec/streaming bounds; new policy controls pending.'
for phase in p['storage_guards'].values():phase['retention']=24*G
p['compressed_retention']['storage_policy']=policy;p['compressed_retention']['storage_policy_sha256']=sha(H/'storage-policy.json');p['compressed_retention']['limits']['retention_floor_bytes']=8*G
for key,name in [('helper','compressed_retention.py'),('independent_reader','retention_audit.py')]:p['compressed_retention'][key]=dict(bytes=(H/name).stat().st_size,sha256=sha(H/name))
save('protocol.json',p)
save('substitutions.json',sub)
(H/'diffs').mkdir(exist_ok=True)
for n in names:
 a=(B/n).read_text();b=(H/n).read_text();(H/'diffs'/f'{n}.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(B/n),tofile=str(H/n))))
 if n.endswith('.py'):ast.parse(b)
# Independently compare the actual measured-loop and retained decode/cleanup functions.
def functions(p):
 s=p.read_text();return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
for name,selected in {
 'matched-driver.py':['native_trial','configs','final_dataset','observe_client','fresh_drain','allocator_provenance','summary_from_report','make_plan','source_binding','cargo_server'],
 'compressed_retention.py':['codec','single_frame','hash_original','tree_inventory','no_references','close_fixture'],
 'retention_audit.py':['full_decode','validate_frame','combined_physical'],
 'isolate-and-run.py':list(functions(B/'isolate-and-run.py'))}.items():
 before,after=functions(B/name),functions(H/name)
 for fn in selected:assert before[fn]==after[fn],(name,fn,'protected execution changed')
save('derivation-result.json',dict(complete=True,scope='Static exact-candidate/policy derivation only; no workload, controls, capacity qualification or cleanup executed.',reference=str(B),runtime_ready=False,policy=policy,policy_sha256=sha(H/'storage-policy.json'),protected_functions_unchanged=True,default_server_manifest_sha256=sha('/tmp/kv9-published-directory-release-20260914-first/build.json'),required_prerequisites=['Actual positive rotation/same-store crash/recovery supplement and independent audit','Fresh complete capacity qualification after actual cleanup/migration','New helper controls and frozen source/policy/command inventory']))
print(json.dumps(json.loads((H/'derivation-result.json').read_text())))
