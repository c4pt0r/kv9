# Published-directory write screen: storage policy v3

This is a prospective comparison of selected CRC main `bd42e60` with the
published-directory candidate `483b8c3`. No performance cohort has run.
The completed FNV comparison remains the latest performance result.

`accepted-controls.json` binds 71 passing local controls: 8 driver, 15 audit,
5 smoke schema, 7 policy, 2 failed-metadata cleanup and 34 codec/restore cases.
Original unsuccessful derivations and controls remain alongside their fixes.
The preparation-time false flags in `protocol.json` and
`derivation-result.json` remain immutable; they are not current test results.

Fresh read-only source/build verification (`49f424/0`) binds all 859 baseline,
871 candidate and 581 fixed-client source files and their retained executables.
`build-bindings.json` retains the original role attestations separately.
`candidate-source-delta.json` contains the complete baseline-to-candidate file
delta; production changes are confined to `wal_segment.rs` and `wal_stream.rs`.
The fixed native v3 performance client remains `0be806d`.

## Unchanged measurement

Run all eight 2-second smoke cohorts, then all sixteen 10-second timed cohorts:
Put and BatchPut(64), concurrency 1 and 64, both servers, two complete opposite
timing orders. Preserve every attempted cohort and every outcome, the full
histograms, datasets, sentinel, attempts, process lifetimes, fresh applied
drains, per-process CPU and host interference observations. No failed cohort
may be silently replaced, omitted or pooled as a healthy result.

Three voters retain the original quorum, WAL synchronization, apply and reply
fences. This screen uses tmpfs and does not establish physical power-loss or
cross-host durability. It compares throughput and tail latency together;
successful audit alone does not promote the candidate.

## Prospective space budget

Policy `kv9-local-benchmark-storage-v3` requires 24 GiB available host space
before and during a cohort, and an 8 GiB floor during serial retention.
Tmpfs guards stay 32 GiB before / 16 GiB during measurement. The 8 GiB member,
16 GiB cohort and 128 GiB combined retention caps remain unchanged. Complete
original byte hashing, independent decode, checksum/EOF checks, verified
catalog-before-unlink and exclusive restoration remain required.

A maximum-size fresh restore needs 24 GiB plus 8 MiB available, rather than
barely satisfying the cohort's 24 GiB guard. The empirical whole-campaign
estimate is 52,612,304,896 historical retained bytes plus a 25 GiB envelope:
**79,455,850,496 bytes** initially. The envelope includes 1 GiB for metadata.
This is a scenario based on actual prior allocation, not a guarantee against
larger candidate output or unrelated writers. All live guards still apply.

After successful smoke, fresh availability already excludes its resident
allocation. The conservative remaining timing scenario is
**73,462,044,626 bytes**; do not charge the smoke objects twice. Only actual
net cache retirement or verified lossless migration may count as recovered
space. Reserved filesystem blocks and expected compression ratios do not.

## Outstanding execution gates

The default release, ordinary recovery and unchanged full21 Chaos baseline
passed. The first separate rotation supplement completed its initial history
and topology capture, then failed because its namespace lacked the Chaos Mesh
opt-in label. Its terminal is `74027/00a0c3/1`; no leader kill or recovery
acceptance is established by that attempt. Preserve it and qualify a fresh
corrected supplement, including independent audit, archive and exact cleanup.

Before benchmark launch, retain successful supplement terminals, finish cache
retirement and any profile migration, observe actual available space, and
freeze the complete helper/source/prerequisite/command inventory. All codecs,
fault campaigns, builds and unrelated tests must be terminal before timing.
Run only the exact arrays in `commands.json`, with actual terminal bindings
filled after their corresponding commands exit. All execution is local.
