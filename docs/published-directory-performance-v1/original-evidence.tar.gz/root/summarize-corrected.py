"""Summarize accepted paired cohorts; never pool smoke or earlier campaigns."""
import ast
import hashlib
import json
from pathlib import Path

PREP = Path('/tmp/kv9-published-directory-performance-v3-preparation-20260915-first')
ROOT = Path('/tmp/kv9-published-directory-performance-v3-root-20260915-second')
source = (PREP / 'audit.py').read_bytes()
assert hashlib.sha256(source).hexdigest() == 'a78b64b21972c2881e068b10b9278abf173832028fcaceca603e317d4af13ae1'
definitions = [node for node in ast.parse(source).body if
               isinstance(node, ast.FunctionDef) and node.name in {'require', 'histogram'}]
assert len(definitions) == 2
functions = {}
exec(compile(ast.Module(body=definitions, type_ignores=[]), '<original-auditor>', 'exec'), functions)
path = PREP / 'results-first/audit.json'
raw = path.read_bytes()
audit = json.loads(raw)
assert audit['complete'] and audit['matched_diagnostic_accepted'] and audit['all_success_single_attempt']
assert len(audit['cases']) == 16
reports = {}
for case in audit['cases']:
    report = Path(case['directory']) / 'run/report.json'
    data = report.read_bytes()
    assert hashlib.sha256(data).hexdigest() == case['report_sha256']
    reports[case['ordinal']] = json.loads(data)


def pool(cases):
    assert len(cases) == 2 and {case['repeat'] for case in cases} == {0, 1}
    calls = sum(case['calls'] for case in cases)
    elapsed = sum(case['cohort_elapsed_ns'] for case in cases)
    items = sum(case['input_items'] for case in cases)
    populations = [pop for case in cases for op in
                   reports[case['ordinal']]['metrics']['measurement']['statistics']
                   for pop in op['populations']]
    latency = functions['histogram'](populations)
    assert latency['count'] == calls
    return dict(calls=calls, input_items=items, elapsed_ns=elapsed,
                calls_per_second=calls*1e9/elapsed, items_per_second=items*1e9/elapsed,
                mean_us=latency['mean_ns']/1000,
                p99_us={k.removesuffix('_ns'): v/1000 for k, v in latency['p99'].items()},
                latency=latency, ordinals=[case['ordinal'] for case in cases])


rows = []
for concurrency in (1, 64):
    for workload in ('point-r000', 'batch64-r000'):
        selected = [c for c in audit['cases'] if
                    c['concurrency'] == concurrency and c['workload'] == workload]
        old = pool([c for c in selected if c['arm'] == 'old-'+workload])
        new = pool([c for c in selected if c['arm'] == 'new-'+workload])
        rows.append(dict(concurrency=concurrency, workload=workload, old=old, new=new,
                         throughput_change_percent=(new['calls_per_second']/old['calls_per_second']-1)*100,
                         mean_change_percent=(new['mean_us']/old['mean_us']-1)*100))
result = dict(complete=True, audit_sha256=hashlib.sha256(raw).hexdigest(), rows=rows,
              calls=sum(c['calls'] for c in audit['cases']),
              input_items=sum(c['input_items'] for c in audit['cases']),
              outcomes={name: sum(c['outcomes'][name] for c in audit['cases'])
                        for name in audit['cases'][0]['outcomes']},
              dropped_slots=sum(c['dropped_slots'] for c in audit['cases']),
              scope='Only the sixteen accepted timed cohorts. Sum counts/elapsed, count-weighted means, merged original whole-call histograms. No smoke, historical or Redis pooling.')
with (ROOT / 'performance-summary-v2.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
