import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/dongxu/kv9')
out=Path('/mnt/data/kv9-work/group-wire-fencing-20260916/rust-controls')
out.mkdir(exist_ok=False)
path=root/'crates/raft/src/grpc.rs'
original=path.read_text()
controls=[
('missing-method-gate','if batch.msgs.iter().any(|env| !class.accepts(env.region_id)) {','if false && batch.msgs.iter().any(|env| !class.accepts(env.region_id)) {','grpc::wire_tests::group_wire_methods_reject_wrong_domains_before_any_batch_delivery','called `Result::unwrap_err()` on an `Ok` value'),
('legacy-fallback','StreamClass::Data => client.batch_data_raft(stream_req).await,','StreamClass::Data => client.batch_raft(stream_req).await,','grpc::wire_tests::group_wire_sender_refuses_legacy_fallback_and_backs_off_unsupported_method','sender leaked data through legacy RPC'),
('shared-queue','StreamClass::Data => &mut peer.data_sender,','StreamClass::Data => &mut peer.sender,','grpc::wire_tests::group_wire_data_saturation_reserves_metadata_queue_and_bounds_worker_count','called `Option::unwrap()` on a `None` value'),
('stale-data-route','[&peer.sender, &peer.data_sender].into_iter().flatten()','[&peer.sender, &peer.sender].into_iter().flatten()','grpc::wire_tests::group_wire_data_saturation_reserves_metadata_queue_and_bounds_worker_count','worker retained an old endpoint generation'),
('retry-spin','// UNIMPLEMENTED. The outer worker can still cancel on a route update.\n        tokio::time::sleep(backoff).await;','// UNIMPLEMENTED. The outer worker can still cancel on a route update.','grpc::wire_tests::group_wire_sender_refuses_legacy_fallback_and_backs_off_unsupported_method','unsupported method retried without its backoff budget'),
('stale-envelope','if Arc::ptr_eq(&message.destination, destination) {\n            return Some(message.envelope);','if true {\n            return Some(message.envelope);','grpc::tests::route_generation_filter_rejects_old_queue_entries_even_after_address_reuse','assertion `left == right` failed'),
]
results=[]
for label,before,after,test,failure in controls:
    assert original.count(before)==1, label
    assert path.read_text()==original
    mutated=original.replace(before,after)
    directory=out/label
    directory.mkdir()
    (directory/'grpc.rs').write_text(mutated)
    path.write_text(mutated)
    try:
        cmd=['cargo','test','-p','kv9-raft','--lib',test,'--','--exact','--nocapture']
        result=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
        (directory/'test.log').write_text(result.stdout)
        assert result.returncode==101 and 'running 1 test' in result.stdout and failure in result.stdout, (label,result.stdout)
        results.append(dict(label=label,command=cmd,exit_code=result.returncode,expected_failure=failure,source_sha256=hashlib.sha256(mutated.encode()).hexdigest()))
    finally:
        assert path.read_text()==mutated, 'concurrent source edit: refusing to overwrite'
        path.write_text(original)
    print(label+': rejected',flush=True)
report={'accepted':True,'controls':results,'restored_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
