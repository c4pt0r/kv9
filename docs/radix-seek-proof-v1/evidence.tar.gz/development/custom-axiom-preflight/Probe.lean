import VectorRange
#print axioms Kv9.Radix.seek_word_vector_next_empty
