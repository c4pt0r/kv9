from pathlib import Path
import subprocess,json,time,sys,os
root=Path(__file__).resolve().parent
out=root/sys.argv[1];out.mkdir()
modules=json.loads(Path('/home/dongxu/kv9/proofs/lean/radix/insert-contract.json').read_text())['modules']+sys.argv[2:]
for name in modules:
 (out/name).write_bytes((Path('/home/dongxu/kv9/proofs/lean/radix')/name).read_bytes())
lean='/mnt/data/kv9-work/lean-toolchain-restoration-20260915-first/installation/lean-4.33.1-linux/bin/lean'
results=[]
for name in modules:
 with (out/(name+'.log')).open('x') as f:
  r=subprocess.run([lean,'-DwarningAsError=true','-o',name.replace('.lean','.olean'),name],cwd=out,env=dict(os.environ,LEAN_PATH=str(out)),stdout=f,stderr=subprocess.STDOUT,timeout=120)
 results.append({'file':name,'exit_code':r.returncode,'ended_ns':time.time_ns()})
 print((out/(name+'.log')).read_text())
 if r.returncode: break
(out/'result.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
sys.exit(1 if any(row['exit_code'] for row in results) else 0)
