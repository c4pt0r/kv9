# Next implementation proof: concrete Arc/COW ownership

Source reviewed after completing the seek models: unchanged
`scripts/resident-radix/src/lib.rs`, hash
`00235871d6f168b3549da377793429dd4db281549425dbab38b1a66c37103fcc`.
These are planned obligations, not accepted proofs or a completed gate.

1. Represent heap nodes by identities, owned key/value/prefix buffers and
   outgoing strong references. Include live map roots, insertion mutable places,
   deletion `current`/detached frames/replacement, and destructor worklists as
   separate ownership tokens. Reference accounting must include temporaries,
   not only published roots. Establish acyclicity and a value-unfolding relation.
2. Model the actual no-Weak Arc contracts used here: new/clone/get_mut/make_mut/
   into_inner and release. Shallow Node/Branch clone copies entry and prefix
   buffers while cloning child Arc references. A uniqueness check authorizes
   in-place mutation only after proving disjointness from every other live root.
   A shared ancestor must be copied before taking its child mutable place.
3. Refine all six insertion actions and the actual split helpers. In particular,
   model unique leaf replacement versus allocation for shared replacement;
   moving a leaf into a terminal through make_mut and mem::take; cloning the old
   child before root replacement; and branch-prefix draining after COW.
4. Refine deletion's root take, edge removal into the current token, retained
   parent frames, checked edge restoration, and normalization. Terminal-only
   collapse moves Entry out; single-child collapse may COW the child before
   prefix concatenation. Preserve other roots through these transient states.
5. Model Node::drop's iterative detached-edge worklist and Arc::into_inner
   interleavings, including concurrent last-owner releases. Show one owner
   reclaims each node, all outgoing references are accounted for, live roots
   retain their values, and no recursive depth-proportional destructor remains.
6. Derive distinct resident Entry storage from the heap relation and valid
   full-key routing, including terminal entries and empty keys/values. Bridge
   resident count, routing buffers and query slices to addressable Rust storage;
   do not simply assume ResidentHistory or restate resident_count_fits.
7. Keep standard allocation, Arc, Vec, slice and Rust/compiler contracts explicit.
   Local rust-src is available under the toolchains' library/alloc/src/sync.rs;
   pin the exact compiler/library source used by the candidate differential run.
8. Differentially execute retained exact Rust source and executable Lean models
   for operation/return values, snapshots, forward/reverse bounds and mixed
   range histories. Include source/model fault controls. Only then begin the
   predeclared matched timing gate; runtime promotion still requires recovery,
   actual Chaos Mesh and three-copy Redis throughput and latency.

Concrete starting relation: use an inductive finite `RepNode heap address tree`
with exact payload and outgoing-edge identities, rather than assuming each
address directly contains an already-unfolded pure tree. A cyclic heap cannot
produce a finite representation derivation. Count strong ownership as a multiset
of external/temporary tokens plus outgoing edges of live heap nodes. Prove local
get_mut/make_mut transitions preserve the interpretations of all retained roots.
Do not use allocation chronology as a permanent DAG rank: an in-place parent may
acquire a newly allocated child during insertion.

Local `stable` rust-src inspection confirms `Arc::into_inner` atomically decrements
the strong count and returns ownership only to the decrement from one; it avoids
also invoking ordinary Arc Drop on that token. `make_mut` clones when strong
uniqueness cannot be obtained, and also has a Weak-disassociation branch. The
candidate's private Node API never creates Weak references, which needs an API
invariant in the correspondence. This inspection is not a proof of the standard
library, and `stable` is not a permanent source pin. Preserve explicit library
contracts and pin the compiler/library before the differential run.
