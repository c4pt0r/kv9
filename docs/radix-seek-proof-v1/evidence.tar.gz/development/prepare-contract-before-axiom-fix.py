from pathlib import Path
import hashlib
import json
import re

repo = Path('/home/dongxu/kv9')
proofs = repo / 'proofs/lean/radix'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
prior = json.loads((proofs / 'insert-contract.json').read_text())
new_modules = ['PendingVector.lean', 'SeekPartition.lean', 'SeekStep.lean', 'SeekLoop.lean',
               'SeekWordStep.lean', 'SeekWordLoop.lean', 'VectorRange.lean']
controls = []
def add(name, module, old, new, kind='semantic'):
    assert (proofs / module).read_text().count(old) == 1, (name, 'ambiguous anchor')
    controls.append(dict(name=name, module=module, old=old, new=new, kind=kind))

add('vec-pops-head', 'PendingVector.lean', '\n  pending.getLast?.map (fun task', '\n  pending.head?.map (fun task')
add('vec-drops-head', 'PendingVector.lean', '(task, pending.dropLast))', '(task, pending.tail))')
add('forward-child-push-order', 'PendingVector.lean',
    'else (forestTasks children).reverse ++ terminalTasks terminal',
    'else forestTasks children ++ terminalTasks terminal')
add('reverse-terminal-push-order', 'PendingVector.lean',
    'if reverse then terminalTasks terminal ++ forestTasks children',
    'if reverse then forestTasks children ++ terminalTasks terminal')
add('expansion-prepends-pushes', 'PendingVector.lean',
    'nextVector reverse (rest ++ branchPush reverse terminal children)\ntermination_by',
    'nextVector reverse (branchPush reverse terminal children ++ rest)\ntermination_by')
add('endpoint-ignores-exclusion', 'SeekPartition.lean',
    '(if inclusive then terminalTasks terminal else [])\n\ndef seekPush',
    '(if inclusive then terminalTasks terminal else terminalTasks terminal)\n\ndef seekPush')
add('seek-keeps-matched-child', 'SeekPartition.lean',
    'else (forestTasks (edgeDrop (index + (if found then 1 else 0)) children)).reverse',
    'else (forestTasks (edgeDrop (index + (if found then 0 else 1)) children)).reverse')
add('seek-reverses-before-push', 'SeekPartition.lean',
    'if reverse then terminalTasks terminal ++ forestTasks (edgeTake index children)',
    'if reverse then terminalTasks terminal ++ (forestTasks (edgeTake index children)).reverse')
add('mismatch-wrong-order', 'SeekPartition.lean',
    '| some byte => decide (byte < oldByte))', '| some byte => decide (oldByte < byte))')
add('hit-skips-depth-byte', 'SeekStep.lean',
    'child (endOffset + 1)\n      else .failed', 'child (endOffset + 2)\n      else .failed')
add('miss-rejects-end-index', 'SeekStep.lean',
    'if index ≤ edgeCount children then .done', 'if index < edgeCount children then .done')
add('hit-selects-next-child', 'SeekStep.lean', 'match edgeGet index children with', 'match edgeGet (index + 1) children with')
add('seek-rejects-end-depth', 'SeekStep.lean', 'if depth ≤ query.length then', 'if depth < query.length then')
add('full-prefix-classified-mismatch', 'SeekStep.lean', 'if sharedLength < pfx.length then', 'if sharedLength ≤ pfx.length then')
add('seek-skips-query-byte', 'SeekStep.lean', 'let endOffset := depth + sharedLength', 'let endOffset := depth + sharedLength + 1')
add('leaf-inverts-bound', 'SeekStep.lean',
    '| .leaf entry => .done (if accepts query inclusive reverse entry then [.entry entry] else [])',
    '| .leaf entry => .done (if !accepts query inclusive reverse entry then [.entry entry] else [])')
add('loop-drops-prior-pending', 'SeekLoop.lean',
    '| .done pushes => some (pending ++ pushes)', '| .done pushes => some pushes')
add('loop-pushes-before-ancestors', 'SeekLoop.lean',
    'seekLoop query inclusive reverse child nextDepth (pending ++ pushes)\ntermination_by',
    'seekLoop query inclusive reverse child nextDepth (pushes ++ pending)\ntermination_by')
add('word-mismatch-skips-byte', 'SeekWordStep.lean',
    'def mismatchWordAt (pfx suffix : Key) : Option Bool :=\n  let sharedLength := USize.ofNat (common pfx suffix).length',
    'def mismatchWordAt (pfx suffix : Key) : Option Bool :=\n  let sharedLength := USize.ofNat (common pfx suffix).length + 1')
add('word-after-extra-increment', 'SeekWordStep.lean',
    '(edgeDrop (index + found.toUSize).toNat children)',
    '(edgeDrop (index + found.toUSize + 1).toNat children)')
add('word-miss-index-shift', 'SeekWordStep.lean',
    '| .miss index =>\n      let wordIndex := USize.ofNat index',
    '| .miss index =>\n      let wordIndex := USize.ofNat (index + 1)')
add('word-descent-extra-increment', 'SeekWordStep.lean',
    'child (endOffset + 1).toNat', 'child (endOffset + 2).toNat')
add('word-prefix-offset-shift', 'SeekWordStep.lean',
    'let endOffset := depth + sharedLength', 'let endOffset := depth + sharedLength + 1')
add('word-loop-loses-terminal-pushes', 'SeekWordLoop.lean',
    '| .done pushes => some (pending ++ pushes)', '| .done _ => some pending')
add('word-loop-resumes-wrong-depth', 'SeekWordLoop.lean',
    'seekWordLoop query inclusive reverse child (USize.ofNat nextDepth) (pending ++ pushes)\ntermination_by',
    'seekWordLoop query inclusive reverse child (USize.ofNat nextDepth + 1) (pending ++ pushes)\ntermination_by')
add('word-root-starts-too-deep', 'SeekWordLoop.lean',
    '| some tree, some (query, inclusive) => seekWordLoop query inclusive reverse tree 0 []',
    '| some tree, some (query, inclusive) => seekWordLoop query inclusive reverse tree 1 []')
add('range-loads-wrong-direction', 'VectorRange.lean',
    'match nextVector reverse pending with', 'match nextVector (!reverse) pending with')
add('range-inverts-crossover', 'VectorRange.lean',
    'if last.key < first.key then', 'if first.key < last.key then')
add('range-advances-wrong-frontier', 'VectorRange.lean',
    '(some first, ⟨loadVector false state.front.pending, state.back⟩)',
    '(some first, ⟨loadVector false state.back.pending, state.back⟩)')
add('range-initializes-wrong-upper', 'VectorRange.lean',
    '(seekWordVector root upper true).map', '(seekWordVector root upper false).map')
hole = 'exact next_vector_empty reverse pending empty\n\nend Kv9.Radix'
add('seek-proof-hole', 'SeekWordLoop.lean', hole, 'sorry\n\nend Kv9.Radix', 'hole')
add('seek-custom-axiom', 'SeekWordLoop.lean', hole, 'exact False.elim injectedSeekFalse\n\nend Kv9.Radix', 'axiom')
source_controls = [
    dict(name='rust-seek-after-offset', old='let after = index + usize::from(found.is_ok());',
         new='let after = index + usize::from(found.is_ok()) + 1;'),
    dict(name='rust-seek-before-slice', old='branch.edges[..index].iter().map(|e| Task::Node(&e.node))',
         new='branch.edges[..=index].iter().map(|e| Task::Node(&e.node))'),
    dict(name='rust-cursor-pop-order', old='while let Some(task) = self.pending.pop() {',
         new='while let Some(task) = self.pending.first().copied() {'),
]
rust = (repo / 'scripts/resident-radix/src/lib.rs').read_text()
for control in source_controls:
    assert rust.count(control['old']) == 1, control['name']
new_names = [name for module in new_modules for name in re.findall(r'^\s*theorem\s+(\w+)', (proofs/module).read_text(), re.M)]
sources = dict(prior['sources'])
for name in ['proofs/lean/radix/insert-contract.json','scripts/resident-radix/prove-seek.py'] + ['proofs/lean/radix/'+m for m in new_modules]:
    sources[name] = sha(repo / name)
contract = dict(modules=prior['modules']+new_modules, theorems=prior['theorems']+new_names,
    new_theorems=new_names, sources=sources, lean_sha256=prior['lean_sha256'],
    controls=controls, source_controls=source_controls, complete_algorithm_gate=False,
    scope='Reviewed value-level indexed seek correspondence: physical bottom-first pending Vec push/pop and traversal; sorted search hit/miss partitions; exact depth and checked index/slice descent; terminating natural-number and native-word loops; bounded root initialization and arbitrary mixed-direction range histories. Query length and ordinary Rust/compiler/library contracts remain explicit premises. No Arc/COW heap proof, verified Rust extraction or performance result.',
    remaining=['Arc/COW heap ownership, immutable saved roots, reclamation and distinct addressable resident storage; bridge routing-buffer, query-length and resident-count premises to Rust storage',
               'Exact-source executable Rust/model differential evaluation before predeclared matched timing; promotion still requires recovery, actual Chaos Mesh and three-copy Redis throughput/latency'])
(proofs/'seek-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
print(json.dumps({'modules':len(contract['modules']), 'theorems':len(contract['theorems']), 'new_theorems':len(new_names), 'controls':len(controls)+len(source_controls)}))
