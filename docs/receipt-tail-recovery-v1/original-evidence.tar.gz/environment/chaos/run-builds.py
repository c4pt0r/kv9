import hashlib, json, os, signal, subprocess, time
from pathlib import Path

ROOT=Path('/tmp/kv9-receipt-tail-auxiliary-root-20260915-first')
PREP=Path('/tmp/kv9-receipt-tail-chaos-preparation-20260915-first')

import sys
sys.path.insert(0,str(PREP))
from storage_policy import POLICY,EXPECTED_SHA256,check_launch,check_space,check_capacity,guard_floor
COMMANDS=PREP/'auxiliary-build-commands.json'
assert hashlib.sha256(COMMANDS.read_bytes()).hexdigest()=='PENDING_EXACT_AUXILIARY_COMMAND_SHA256'
c=json.loads(COMMANDS.read_text())
assert hashlib.sha256((PREP/'build-pressure.py').read_bytes()).hexdigest()==c['pressure_script_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=c['cwd'],text=True).strip()==c['revision']
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=c['cwd'])
def available():
    s=os.statvfs('/home/dongxu/kv9');return s.f_bavail*s.f_frsize
start=available();floor=8*1024**3;ceiling=12*1024**3
check_launch(start)
# The original cold transaction is terminal; no concurrent conversion runs.
cold_reserve=0
r=dict(storage_policy=POLICY['policy_id'],storage_policy_sha256=EXPECTED_SHA256,complete=False,started_ns=time.time_ns(),initial_available_bytes=start,
       minimum_available_bytes=floor,additional_consumption_ceiling_bytes=ceiling,
       concurrent_cold_transaction_reservation=cold_reserve,extra_metadata_margin_bytes=0,
       command_manifest_sha256=hashlib.sha256(COMMANDS.read_bytes()).hexdigest(),
       commands=[],samples=[],timeout_seconds=1200)
p=None;began=time.monotonic()
try:
    for name in ('build_point','build_pressure'):
        row=dict(name=name,argv=c[name],started_ns=time.time_ns());r['commands'].append(row)
        with (ROOT/(name+'.log')).open('xb') as log:
            p=subprocess.Popen(c[name],cwd=c['cwd'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            row['pid']=p.pid
            (ROOT/'invocation.json').write_text(json.dumps(r,indent=2)+'\n')
            while True:
                free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
                check_space(free,start)
                assert time.monotonic()-began<1200,'source outer timeout exceeded'
                try:row['exit_code']=p.wait(timeout=5);break
                except subprocess.TimeoutExpired:pass
        row['ended_ns']=time.time_ns();row['reaped']=p.poll() is not None;row['pid_absent']=not Path('/proc',str(p.pid)).exists()
        assert row['exit_code']==0,name+' failed'
        p=None
    assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=c['cwd'])
    free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
    check_space(free,start)
    r['complete']=True
except BaseException as e:
    r['failure']=repr(e)
    if p is not None and p.poll() is None:
        os.killpg(p.pid,signal.SIGTERM)
        try:p.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise
finally:
    r['ended_ns']=time.time_ns();(ROOT/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: clean-source point and pressure release builds within original reservation')
