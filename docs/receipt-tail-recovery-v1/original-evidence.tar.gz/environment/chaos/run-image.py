import hashlib,json,os,signal,subprocess,time
from pathlib import Path

ROOT=Path('/tmp/kv9-receipt-tail-image-root-20260915-first')
PREP=Path('/tmp/kv9-receipt-tail-chaos-preparation-20260915-first')

import sys
sys.path.insert(0,str(PREP))
from storage_policy import POLICY,EXPECTED_SHA256,check_launch,check_space,check_capacity,guard_floor
raw=(PREP/'commands.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='PENDING_EXACT_IMAGE_COMMAND_SHA256'
c=json.loads(raw);assert json.loads((PREP/'build-binding-first.json').read_text())['complete']
# The original cold transaction is complete; image operations are exclusive.
cold=0
def available():
    s=os.statvfs('/tmp');return s.f_bavail*s.f_frsize
floor=8*1024**3;ceiling=12*1024**3;start=available()
check_launch(start)
r=dict(storage_policy=POLICY['policy_id'],storage_policy_sha256=EXPECTED_SHA256,complete=False,started_ns=time.time_ns(),initial_available_bytes=start,minimum_available_bytes=floor,
       additional_consumption_ceiling_bytes=ceiling,cold_transaction_reservation_bytes=cold,
       extra_metadata_margin_bytes=0,commands=[],samples=[],command_manifest_sha256=hashlib.sha256(raw).hexdigest(),
       scope='Local copied-binary fixture image, compatibility probe and Kind image availability; no fault injection or benchmark')
names=['image_build_after_binding','image_probe_after_build','image_inspect_after_build','kind_load_after_probe','cri_readback_after_kind_load']
p=None;t=time.monotonic()
try:
    for name in names:
        row=dict(name=name,argv=c[name],started_ns=time.time_ns());r['commands'].append(row)
        with (ROOT/(name+'.stdout')).open('xb') as out,(ROOT/(name+'.stderr')).open('xb') as err:
            p=subprocess.Popen(c[name],cwd=c['cwd'],stdout=out,stderr=err,start_new_session=True);row['pid']=p.pid
            (ROOT/'invocation.json').write_text(json.dumps(r,indent=2)+'\n')
            while True:
                free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
                check_space(free,start)
                assert time.monotonic()-t<1200,'image preparation outer timeout'
                try:row['exit_code']=p.wait(timeout=5);break
                except subprocess.TimeoutExpired:pass
        row['ended_ns']=time.time_ns();row['reaped']=p.poll() is not None;row['pid_absent']=not Path('/proc',str(p.pid)).exists();assert row['exit_code']==0,name+' failed'
        p=None
    probe=subprocess.run(['docker','container','inspect','receipt-tail-a6ac335-full21-image-probe-20260915-first'],capture_output=True)
    (ROOT/'probe-absence.stdout').write_bytes(probe.stdout);(ROOT/'probe-absence.stderr').write_bytes(probe.stderr)
    assert probe.returncode==1 and b'No such container:' in probe.stderr,probe.stderr
    r['probe_container_absent']=True
    free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
    check_space(free,start)
    r['complete']=True
except BaseException as e:
    r['failure']=repr(e)
    if p is not None and p.poll() is None:
        os.killpg(p.pid,signal.SIGTERM)
        try:p.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise
finally:
    r['ended_ns']=time.time_ns();(ROOT/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: original-binary Chaos image build, no-network compatibility probe and Kind image load')
