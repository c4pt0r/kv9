import hashlib,json,os,signal,subprocess,time
from pathlib import Path
R=Path('/tmp/kv9-receipt-tail-chaos-root-20260915-first');P=Path('/tmp/kv9-receipt-tail-chaos-preparation-20260915-first');G=1024**3

import sys
sys.path.insert(0,str(P))
from storage_policy import POLICY,EXPECTED_SHA256,check_launch,check_space,check_capacity,guard_floor
read=lambda p:json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,r):Path(p).write_text(json.dumps(r,indent=2)+'\n')
def avail():s=os.statvfs('/tmp');return s.f_bavail*s.f_frsize
assert __debug__
assert read(P/'final-preparation/finalization-first/result.json')['complete']
assert read('/tmp/kv9-receipt-tail-recovery-root-20260915-first/actual-terminal.json')['complete']
assert read('/tmp/kv9-receipt-tail-recovery-root-20260915-first/actual-audit-terminal.json')['complete']
plan=read(P/'plan.json');assert plan['plan_ready'] and plan['build_complete'] and not plan['fixture_started'] and not plan['fixture_launch_authorized']
assert plan['revision']=='a6ac335ef4567f2e1a2b33da1a723d694cd5b7d9'
assert not (P/'root-runtime-release.json').exists() and not (P/'runtime-release-consumed.json').exists()
initial=avail();check_launch(initial)
capacity=read('/tmp/kv9-receipt-tail-finalize-root-20260915-first/capacity.json');check_capacity(capacity);floor=guard_floor(capacity['available_bytes'])
forbidden=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdecimal():continue
 try:comm=(proc/'comm').read_text().strip()
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 if comm in {'cargo','rustc','rustdoc','lean','lake','perf','zstd','gzip','pigz','redis-benchmark','kv9-batch-benchm','kv9-redis-batch-'}:forbidden.append(dict(pid=int(proc.name),comm=comm))
assert not forbidden,forbidden
save(R/'preflight.json',dict(complete=True,observed_ns=time.time_ns(),initial_available_bytes=initial,minimum_available_bytes=floor,maximum_additional_bytes=12*G,capacity_origin='/tmp/kv9-receipt-tail-finalize-root-20260915-first/capacity.json',forbidden_processes=forbidden,ready_plan_sha256=sha(P/'ready-plan.json'),no_performance_or_build_or_codec_active=True))
plan['fixture_launch_authorized']=True;save(P/'plan.json',plan)
release=dict(plan_sha256=sha(P/'plan.json'),revision=plan['revision'],single_use=True,observed_ns=time.time_ns(),preflight_sha256=sha(R/'preflight.json'))
with (P/'root-runtime-release.json').open('x') as out:json.dump(release,out,indent=2);out.write('\n')
argv=read(P/'final-preparation/commands.json')['runtime_only_after_separate_root_release']
point_argv=read(P/'commands.json')['capture_point_while_runtime_live']
r=dict(complete=False,started_ns=time.time_ns(),argv=argv,release=release,commands=[]);children=[];samples=[];handles=[];point=None;runner=None
try:
 for name in ('runtime','point'):
  handles.append(((R/(name+'.stdout')).open('xb'),(R/(name+'.stderr')).open('xb')))
 runner=subprocess.Popen(argv,stdout=handles[0][0],stderr=handles[0][1],start_new_session=True);children.append(runner)
 r['commands'].append(dict(name='runtime',argv=argv,pid=runner.pid,started_ns=time.time_ns()));save(R/'invocation.json',r)
 while True:
  available=avail();samples.append(dict(observed_ns=time.time_ns(),available_bytes=available));assert available>=floor,'original capacity reservation crossed'
  assert time.time_ns()-r['started_ns']<1200*10**9,'runtime outer deadline exceeded'
  if point is None:
   try:live=read(P/'plan.json')
   except json.JSONDecodeError:live={}
   if live.get('artifact'):
    point=subprocess.Popen(point_argv,stdout=handles[1][0],stderr=handles[1][1],start_new_session=True);children.append(point)
    r['commands'].append(dict(name='point-capture',argv=point_argv,pid=point.pid,started_ns=time.time_ns()));save(R/'invocation.json',r)
  for row,child in zip(r['commands'],children):
   code=child.poll()
   if code is not None and 'exit_code' not in row:row.update(exit_code=code,ended_ns=time.time_ns());save(R/'invocation.json',r)
  if runner.poll() is not None and (point is None or point.poll() is not None):break
  time.sleep(5)
 assert point is not None,'point collector was never started'
 assert all(row['exit_code']==0 for row in r['commands']),r['commands']
 final=read(P/'plan.json');assert final['fixture_exit_code']==0 and final['observer_exit_code']==0
 r.update(complete=True,artifact=final['artifact'],fixture_pid=final['fixture_pid'],observer_pid=final['observer_pid'],fixture_exit_code=0,observer_exit_code=0)
except BaseException as e:
 r['failure']=repr(e)
 for child in children:
  if child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=30)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 for row,child in zip(r['commands'],children):row.setdefault('exit_code',child.returncode)
 raise
finally:
 for pair in handles:
  for handle in pair:handle.close()
 r['ended_ns']=time.time_ns();r['final_available_bytes']=avail();save(R/'resource-samples.json',samples);save(R/'result.json',r)
print(json.dumps(r))
