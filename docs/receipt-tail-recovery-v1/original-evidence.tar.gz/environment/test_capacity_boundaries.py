"""Pure checks of the copied supervisor expressions and new explicit policies."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
GIB = 1024**3
MIB = 1024**2
spec = importlib.util.spec_from_file_location('receipt_chaos_policy', HERE/'chaos/storage_policy.py')
chaos = importlib.util.module_from_spec(spec)
spec.loader.exec_module(chaos)
release = json.loads((HERE/'release/storage-policy.json').read_text())


def guards(filename):
    source = (HERE/'release'/filename).read_text()
    tree = ast.parse(source)
    values = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('floor','ceiling'):
            values[node.targets[0].id] = eval(compile(ast.Expression(node.value), '<literal-limit>', 'eval'), {'__builtins__': {}})
    launch = next(n.test for n in tree.body if isinstance(n, ast.If)
                  and 'start-ceiling' in ast.get_source_segment(source, n.test))
    sampled = [n.test for n in ast.walk(tree) if isinstance(n, ast.If)
               and ast.get_source_segment(source, n.test) == 'free<floor or start-free>ceiling']
    assert len(sampled) == 2
    return values, launch, sampled


def evaluates(node, values):
    return eval(compile(ast.Expression(node), '<original-supervisor-guard>', 'eval'), {'__builtins__': {}}, values)


class CapacityBoundaries(unittest.TestCase):
    def test_release_launch_boundary_both_supervisors(self):
        for name in ('run-release.py','run-recovery.py'):
            values, launch, sampled = guards(name)
            self.assertEqual(values, {'floor':8*GIB,'ceiling':16*GIB})
            self.assertFalse(evaluates(launch, dict(values,start=24*GIB+8*MIB)))
            self.assertTrue(evaluates(launch, dict(values,start=24*GIB+8*MIB-1)))
        self.assertEqual(release['launch_available_minimum_bytes'],24*GIB+8*MIB)

    def test_release_sample_and_final_floor_and_full_cap(self):
        for name in ('run-release.py','run-recovery.py'):
            values, launch, sampled = guards(name)
            for node in sampled:
                self.assertFalse(evaluates(node,dict(values,start=24*GIB,free=8*GIB)))
                self.assertTrue(evaluates(node,dict(values,start=24*GIB,free=8*GIB-1)))
                self.assertFalse(evaluates(node,dict(values,start=40*GIB,free=24*GIB)))
                self.assertTrue(evaluates(node,dict(values,start=40*GIB,free=24*GIB-1)))

    def test_release_readback_preserves_exact_new_guard(self):
        text=(HERE/'release/check-release.py').read_text()
        for literal in ('original[\'minimum_available_bytes\']==8*1024**3',
                        'original[\'additional_consumption_ceiling_bytes\']==16*1024**3',
                        'original[\'initial_available_bytes\']>=24*1024**3+8*1024**2',
                        'original[\'ended_ns\']-original[\'started_ns\']<=1200*10**9'):
            self.assertIn(literal,text)

    def test_chaos_launch_boundary(self):
        chaos.check_launch(20*GIB+8*MIB)
        with self.assertRaises(AssertionError): chaos.check_launch(20*GIB+8*MIB-1)
        for invalid in (True,-1,20.0*GIB):
            with self.assertRaises(AssertionError): chaos.check_launch(invalid)

    def test_chaos_full_decrease_and_original_baseline(self):
        baseline=20*GIB+8*MIB
        chaos.check_space(8*GIB+8*MIB,baseline)
        with self.assertRaises(AssertionError): chaos.check_space(8*GIB+8*MIB-1,baseline)
        chaos.check_space(28*GIB,40*GIB)
        with self.assertRaises(AssertionError): chaos.check_space(28*GIB-1,40*GIB)
        # The same immutable finalizer record anchors runtime and every post phase.
        path='/tmp/kv9-receipt-tail-finalize-root-20260915-first/capacity.json'
        for filename in ('run-runtime.py','run-post.py'):
            text=(HERE/'chaos'/filename).read_text()
            self.assertIn(path,text)
            self.assertIn("guard_floor(capacity['available_bytes'])",text)

    def test_chaos_capacity_schema_rejects_other_policy_or_limits(self):
        good={k:chaos.POLICY[k] for k in ('policy_id','preflight_minimum_available_bytes','minimum_available_bytes','maximum_additional_build_image_archive_bytes')}
        good.update(policy_sha256=chaos.EXPECTED_SHA256,available_bytes=20*GIB+8*MIB)
        chaos.check_capacity(good)
        for key,value in [('policy_id','kv9-published-directory-chaos-v2'),('policy_sha256','0'*64),
                          ('minimum_available_bytes',48*GIB),('maximum_additional_build_image_archive_bytes',12*GIB+1),
                          ('preflight_minimum_available_bytes',20*GIB)]:
            bad=copy.deepcopy(good);bad[key]=value
            with self.subTest(key=key),self.assertRaises(AssertionError):chaos.check_capacity(bad)


if __name__ == '__main__':
    unittest.main(verbosity=2)
