"""Explicit root-selected Chaos host-storage policy; no process or filesystem mutation."""
import hashlib,json
from pathlib import Path
EXPECTED_SHA256='6180d3d2ac1fd01a0235c40a4aa474ea8316fa8a4f7957f49a7ef56719ae923a'
EXPECTED={'policy_id': 'kv9-published-directory-chaos-v2', 'version': 2, 'preflight_minimum_available_bytes': 68719476736, 'minimum_available_bytes': 51539607552, 'maximum_additional_build_image_archive_bytes': 12884901888, 'resource_sample_seconds': 5, 'outer_seconds': 1200, 'accounting': 'statvfs f_bavail * f_frsize; never count excluded free blocks', 'runtime_post_baseline': 'one finalizer available_bytes baseline across runtime and all six post phases', 'scope': 'Candidate Chaos auxiliary/image/runtime/post only; separate release/recovery policy has a 16 GiB cap. No benchmark or encoded-payload change.'}
raw=Path(__file__).with_name('storage-policy.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()==EXPECTED_SHA256,'storage policy bytes changed'
POLICY=json.loads(raw)
assert POLICY==EXPECTED,'storage policy differs'
def integer(n):
    assert type(n) is int and n>=0,'invalid available-byte observation'
def check_launch(available):
    integer(available)
    assert available>=POLICY['preflight_minimum_available_bytes'],'Chaos launch capacity below 64 GiB'
def guard_floor(baseline):
    integer(baseline)
    return max(POLICY['minimum_available_bytes'],baseline-POLICY['maximum_additional_build_image_archive_bytes'])
def check_space(available,baseline):
    integer(available)
    assert available>=guard_floor(baseline),'Chaos host floor or original 12 GiB decrease cap crossed'
def check_capacity(d):
    assert d['policy_id']==POLICY['policy_id'] and d['policy_sha256']==EXPECTED_SHA256,'capacity policy binding differs'
    for k in ('preflight_minimum_available_bytes','minimum_available_bytes','maximum_additional_build_image_archive_bytes'):
        assert type(d[k]) is int and d[k]==POLICY[k],('capacity limit differs',k)
    check_launch(d['available_bytes'])
