"""Retain original receipt qualification reporting and small recovery payloads."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

OUT = Path('/home/dongxu/kv9/docs/receipt-tail-recovery-v1')
ROOTS = {
    'release': Path('/tmp/kv9-receipt-tail-release-20260915-first'),
    'release-root': Path('/tmp/kv9-receipt-tail-release-root-20260915-first'),
    'recovery': Path('/tmp/kv9-receipt-tail-recovery-20260915-first'),
    'recovery-root': Path('/tmp/kv9-receipt-tail-recovery-root-20260915-first'),
    'audit': Path('/tmp/kv9-receipt-tail-recovery-audit-20260915-first'),
    'environment': Path('/tmp/kv9-receipt-tail-runtime-environment-20260915-first'),
}
EXCLUDE = {'release/kv9', 'release/workload/kv9-batch-workload'}

def pin(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(bytes=path.stat().st_size, sha256=digest)

entries = []
for label, root in ROOTS.items():
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), str(path)
        if not path.is_file():
            continue
        name = label+'/'+str(path.relative_to(root))
        if name in EXCLUDE:
            continue
        entries.append(dict(member=name, original=str(path), **pin(path)))
for path in (Path(__file__), Path('/tmp/kv9-receipt-tail-release-preflight-20260915.py')):
    entries.append(dict(member='root-helpers/'+path.name, original=str(path), **pin(path)))
assert len({row['member'] for row in entries}) == len(entries)
assert sum(row['bytes'] for row in entries) < 32*1024**2
with (OUT/'original-evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', compresslevel=6, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for row in entries:
                path = Path(row['original'])
                assert pin(path) == {key:row[key] for key in ('bytes','sha256')}
                info = tarfile.TarInfo(row['member'])
                info.size = row['bytes']
                info.mode = 0o644
                with path.open('rb') as stream:
                    archive.addfile(info, stream)
                assert pin(path) == {key:row[key] for key in ('bytes','sha256')}
with (OUT/'input-inventory.json').open('x') as stream:
    json.dump(entries, stream, indent=2, sort_keys=True)
    stream.write('\n')
manifest = dict(version=1, revision='a6ac335ef4567f2e1a2b33da1a723d694cd5b7d9',
                members=len(entries), decoded_bytes=sum(row['bytes'] for row in entries),
                files={name:pin(OUT/name) for name in ('original-evidence.tar.gz','input-inventory.json','README.md','verify.py')},
                excluded_members=sorted(EXCLUDE), scope='Exact default release and ordinary recovery; Chaos and performance pending')
with (OUT/'manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(manifest, sort_keys=True))
