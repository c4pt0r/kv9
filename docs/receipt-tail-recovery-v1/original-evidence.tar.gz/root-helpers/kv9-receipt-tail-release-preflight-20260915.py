"""Bind the receipt candidate's completed source/proof gates before release."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

SOURCE = Path('/tmp/kv9-receipt-tail-release-source-20260915-first')
ROOT = Path('/tmp/kv9-receipt-tail-release-root-20260915-first')
ENV = Path('/tmp/kv9-receipt-tail-runtime-environment-20260915-first')
REV = 'a6ac335ef4567f2e1a2b33da1a723d694cd5b7d9'
GATE = Path('/tmp/kv9-receipt-tail-hint-source-20260914-first')
PROOF = Path('/tmp/kv9-receipt-tail-hint-proof-20260914-first')
inputs = {}

def sha(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    inputs[str(path)] = dict(bytes=path.stat().st_size, sha256=digest)
    return digest

def read(path):
    sha(path)
    return json.loads(Path(path).read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE)

assert not ROOT.exists()
ROOT.mkdir()
result = dict(complete=False, started_ns=time.time_ns(), revision=REV,
              runtime_checkpoint=REV, source_root=str(SOURCE))
try:
    assert git('rev-parse', 'HEAD').decode().strip() == REV
    assert not git('status', '--porcelain', '--untracked-files=all')
    before = read(GATE/'source-before.json')
    assert before == read(GATE/'source-after.json')
    assert before['revision'] == REV and before['dirty'] is False
    paths = git('ls-files', '-z').decode().strip('\0').split('\0')
    actual = {name: sha(SOURCE/name) for name in paths}
    assert actual == before['sources'] and len(actual) == 869
    gate = read(GATE/'result.json')
    assert gate['complete'] and gate['source_unchanged'] and len(gate['commands']) == 7
    assert all(row['complete'] and row['exit_code'] == 0 and row['source_unchanged'] for row in gate['commands'])
    terminal_root = Path('/tmp/kv9-receipt-tail-hint-source-root-20260914-first')
    terminal = read(terminal_root/'tool-terminal.json')
    assert terminal['exit_code'] == 0 and terminal['result_sha256'] == sha(terminal_root/'result.json')
    source_run = read(terminal_root/'result.json')
    assert source_run['complete'] and source_run['exit_code'] == 0
    proof = read(PROOF/'result.json')
    proof_terminal = read(PROOF/'tool-terminal.json')
    assert proof_terminal['exit_code'] == 0 and proof_terminal['result_sha256'] == sha(PROOF/'result.json')
    assert proof['complete'] and proof['source_unchanged']
    for name, digest in proof['source_binding']['files'].items():
        assert actual[name] == digest == hashlib.sha256(git('show', REV+':'+name)).hexdigest()
    assert len(proof['source_binding']['files']) == 12
    assert proof['cases'][0]['theorems'] == 18 and proof['cases'][0]['obligations'] == 158
    contract = read(PROOF/'source/source-contract.json')
    driver = (SOURCE/'crates/raft/src/driver.rs').read_text()
    for old, new in contract['reverse_driver_edits']:
        assert driver.count(old) == 1
        driver = driver.replace(old, new)
    assert driver.encode() == git('show', contract['parent']+':crates/raft/src/driver.rs')
    policy = read(ENV/'release/storage-policy.json')
    assert policy['launch_available_minimum_bytes'] == 24*1024**3+8*1024**2
    supervisor = ENV/'release/run-release.py'
    assert str(SOURCE/'scripts/build-native-batch.py') in supervisor.read_text()
    original = read('/tmp/kv9-published-directory-release-root-20260914-first/preflight.json')
    protected = dict(original['protected_release_hashes'])
    protected.update({
        '/tmp/kv9-published-directory-release-20260914-first/kv9': '43d8bcb2d852d6fcbebb7f528808e53b3eb93588e2637195e9053cd91e8d5450',
        '/tmp/kv9-published-directory-release-20260914-first/workload/kv9-batch-workload': '205bcf4451d8f1d59023bcd4893d3388ed73846cf0980cbc9efa6cb5df578a2e',
    })
    for name, digest in protected.items():
        assert sha(name) == digest and Path(name).stat().st_nlink == 1
    s = os.statvfs('/home/dongxu/kv9')
    available = s.f_bavail*s.f_frsize
    assert available >= policy['launch_available_minimum_bytes']
    result.update(complete=True, source_snapshot=before,
                  source_helper_sha256={name:sha(SOURCE/'scripts'/name) for name in original['source_helper_sha256']},
                  supervisor_sha256=sha(supervisor), protected_release_hashes=protected,
                  storage_policy=policy['name'], policy=policy,
                  policy_sha256=sha(ENV/'release/storage-policy.json'),
                  source_gate_inputs={k:v for k,v in inputs.items() if not k.startswith(str(SOURCE)+'/')},
                  proof_bound_files=12, reconstructed_parent_driver=True, available_bytes=available)
except BaseException as error:
    result['failure'] = repr(error)
    raise
finally:
    result['ended_ns'] = time.time_ns()
    (ROOT/'preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(complete=result['complete'], source_files=len(actual), available_bytes=available)))
