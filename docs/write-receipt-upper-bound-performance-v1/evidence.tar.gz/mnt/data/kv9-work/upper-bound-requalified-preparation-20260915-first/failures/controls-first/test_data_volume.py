"""Focused new root-filesystem/client closure controls; no codec or workload."""
import ast,copy,hashlib,importlib.util,json,os,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).resolve().parent;G=1024**3
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,P/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
d=load('volume_driver','matched-driver.py');p=load('volume_producer','compressed_retention.py');r=load('volume_reader','retention_audit.py')
tree=ast.parse((P/'audit.py').read_text());constants={'STORAGE_POLICY','STORAGE_POLICY_SHA','STORAGE_GUARDS'};functions={'require','check_storage_policy','validate_storage'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in functions or isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)and n.targets[0].id in constants]
a={'json':json};exec(compile(ast.Module(body=nodes,type_ignores=[]),'audit.py:actual-metadata-functions','exec'),a)
def usage(n):return types.SimpleNamespace(f_frsize=1,f_blocks=100*G,f_bfree=99*G,f_bavail=n)
def funcs(file):
 raw=file.read_text();return{n.name:ast.get_source_segment(raw,n)for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
class DataVolume(unittest.TestCase):
 def observation(self,phase):
  return dict(started_unix_ns=1,completed_unix_ns=2,filesystems={name:dict(path={'root':'/','tmpfs':'/dev/shm','retention':'/owned'}[name],device={'root':33,'tmpfs':11,'retention':22}[name],fragment_bytes=1,blocks=100*G,free_blocks=99*G,available_blocks=n,available_bytes=n)for name,n in d.SPACE_GUARDS[phase].items()})
 def test_cohort_threshold_equal_and_one_byte_below_each_filesystem(self):
  for phase in ('preflight','runtime'):
   good=self.observation(phase);d.require_storage(good,phase);self.assertEqual(a['validate_storage'](good,Path('/owned'),phase),dict(root=33,tmpfs=11,retention=22))
   for name in good['filesystems']:
    bad=copy.deepcopy(good)
    for field in ['available_blocks','available_bytes']:bad['filesystems'][name][field]-=1
    with self.assertRaisesRegex(ValueError,'storage guard'):d.require_storage(bad,phase)
    with self.assertRaisesRegex(ValueError,'storage guard'):a['validate_storage'](bad,Path('/owned'),phase)
 def test_missing_root_wrong_path_device_and_arithmetic_are_refused(self):
  good=self.observation('runtime');devices=a['validate_storage'](good,Path('/owned'),'runtime')
  bad=copy.deepcopy(good);del bad['filesystems']['root']
  with self.assertRaises((KeyError,ValueError)):d.require_storage(bad,'runtime')
  with self.assertRaisesRegex(ValueError,'filesystem inventory'):a['validate_storage'](bad,Path('/owned'),'runtime')
  for key,value in [('path','/mnt/data'),('device',34),('available_bytes',24*G+1),('device',True)]:
   bad=copy.deepcopy(good);bad['filesystems']['root'][key]=value
   with self.assertRaises(ValueError):a['validate_storage'](bad,Path('/owned'),'runtime',devices)
 def test_observation_includes_root_and_uses_available_not_reserved_blocks(self):
  with patch.object(d.os,'statvfs',return_value=usage(7*G))as observed:result=d.storage_observation(P)
  self.assertEqual(set(result['filesystems']),{'root','tmpfs','retention'})
  self.assertEqual(result['filesystems']['root']['path'],'/')
  self.assertEqual(result['filesystems']['root']['device'],Path('/').stat().st_dev)
  self.assertEqual([str(x.args[0])for x in observed.call_args_list],['/dev/shm',str(P),'/'])
  self.assertTrue(all(x['available_bytes']==7*G and x['free_blocks']==99*G for x in result['filesystems'].values()))
 def test_policy_missing_or_old_binding_refused_independently(self):
  policy=json.loads((P/'storage-policy.json').read_text());good=dict(storage_policy=policy,storage_policy_sha256=hashlib.sha256((P/'storage-policy.json').read_bytes()).hexdigest())
  old=json.loads((P/'predecessor/storage-policy.json').read_text())
  self.assertEqual({k:v for k,v in policy.items()if k not in ['additional_root_filesystem','policy_id']},{k:v for k,v in old.items()if k!='policy_id'})
  for gate in [d.check_storage_policy,p.check_storage_policy,r.check_storage_policy,a['check_storage_policy']]:
   gate(good)
   for bad in [{},dict(good,storage_policy=old),dict(good,storage_policy_sha256='0'*64)]:
    with self.assertRaisesRegex(ValueError,'storage policy'):gate(bad)
 def test_retention_root_floor_equality_below_device_and_reserved_blocks(self):
  for helper in [p,r]:
   with patch.object(helper.os,'statvfs',return_value=usage(8*G)):
    row=helper.root_storage_observation();self.assertEqual(row['available_bytes'],8*G)
    with self.assertRaisesRegex(ValueError,'device changed'):helper.root_storage_observation(row['device']+1)
   with patch.object(helper.os,'statvfs',return_value=usage(8*G-1)):
    with self.assertRaisesRegex(ValueError,'root filesystem retention floor'):helper.root_storage_observation()
 def test_budget_preserves_output_reservation_and_adds_independent_root_floor(self):
  parent=P/'synthetic-first';parent.mkdir(exist_ok=True)
  with tempfile.TemporaryDirectory(dir=parent,prefix='root-budget-')as tmp:
   budget=p.Budget(Path(tmp));reserve=1024**2
   with patch.object(p.shutil,'disk_usage',return_value=types.SimpleNamespace(free=8*G+reserve)),patch.object(p.os,'statvfs',return_value=usage(8*G)):
    budget.check(reserve);r.validate_root_budget(budget.report())
   with patch.object(p.shutil,'disk_usage',return_value=types.SimpleNamespace(free=8*G+reserve-1)),patch.object(p.os,'statvfs',return_value=usage(8*G)):
    with self.assertRaisesRegex(ValueError,'floor/space reservation'):budget.check(reserve)
   with patch.object(p.shutil,'disk_usage',return_value=types.SimpleNamespace(free=100*G)),patch.object(p.os,'statvfs',return_value=usage(8*G-1)):
    with self.assertRaisesRegex(ValueError,'root filesystem retention floor'):budget.check()
 def test_independent_budget_missing_mutated_and_below_floor_refusals(self):
  sample=self.observation('runtime')['filesystems']['root'];sample['available_blocks']=sample['available_bytes']=8*G
  good=dict(root_device=33,root_minimum_available_bytes=8*G,samples=[dict(root_filesystem=sample)])
  r.validate_root_budget(good)
  bads=[{},dict(good,root_minimum_available_bytes=8*G-1),dict(good,root_device=34),dict(good,samples=[])]
  for key,val in [('path','/mnt/data'),('device',34),('available_bytes',8*G+1),('available_blocks',False)]:
   b=copy.deepcopy(good);b['samples'][0]['root_filesystem'][key]=val;bads.append(b)
  for bad in bads:
   with self.assertRaises(ValueError):r.validate_root_budget(bad)
 def test_decoder_refuses_low_root_before_codec_or_payload_access(self):
  with patch.object(r.os,'statvfs',return_value=usage(8*G-1)),patch.object(r.subprocess,'Popen',side_effect=AssertionError('codec must not start')),patch.object(r,'validate_frame',side_effect=AssertionError('payload must not be read')):
   with self.assertRaisesRegex(ValueError,'root filesystem retention floor'):r.full_decode(P/'absent-object',dict(bytes=0,sha256='0'*64),{})
 def test_measured_semantics_source_attestation_and_codec_closure_unchanged(self):
  original=funcs(P/'predecessor/matched-driver.py');derived=funcs(P/'matched-driver.py')
  for name in ['native_trial','observe_client','fresh_drain','make_plan','verify_inputs','verify_client_cargo','source_binding','cargo_server']:self.assertEqual(original[name],derived[name],name)
  original=funcs(P/'predecessor/compressed_retention.py');derived=funcs(P/'compressed_retention.py')
  for name in ['codec','single_frame','hash_original','tree_inventory','no_references','close_fixture']:self.assertEqual(original[name],derived[name],name)
  self.assertEqual(p.LIMITS,r.LIMITS);self.assertEqual(p.LIMITS['member_bytes'],8*G);self.assertEqual(p.LIMITS['cohort_bytes'],16*G);self.assertEqual(p.LIMITS['campaign_bytes'],128*G)
 def test_exact_new_client_and_full_matrix_path_hash_closure(self):
  protocol=json.loads((P/'protocol.json').read_text());old=json.loads((P/'predecessor/protocol.json').read_text())
  self.assertEqual(d.CLIENT_PINS['client']['binary_sha256'],'1b8060eb168610328c10a27480de16bd8b2d6805166d8169638f85ceef0992c4')
  self.assertNotEqual(d.CLIENT_PINS['client']['binary_sha256'],old['client_sha256'])
  self.assertEqual(d.SERVER_PINS,old['server_pins'])
  self.assertEqual(protocol['client_pins']['client'],d.CLIENT_PINS['client'])
  for key in ['smoke_inventory','timed_inventory','expected_counts','configured_max_attempts','effective_server_limits']:self.assertEqual(protocol[key],old[key])
  self.assertEqual(len(d.make_plan(True)),8);self.assertEqual(len(d.make_plan(False)),16)
  for key,file in [('driver_sha256','matched-driver.py'),('auditor_sha256','audit.py')]:self.assertEqual(protocol[key],hashlib.sha256((P/file).read_bytes()).hexdigest())
  self.assertEqual(list(map(str,p.COHORT_ROOTS)),list(map(str,r.COHORT_ROOTS)))
  self.assertTrue(all(str(x).startswith('/mnt/data/kv9-work/')for x in p.COHORT_ROOTS))
  self.assertEqual(hashlib.sha256((P/'run_fixture.py').read_bytes()).hexdigest(),d.RESP_HELPER_SHA)
  self.assertFalse(protocol['runtime_ready'])
if __name__=='__main__':unittest.main(verbosity=2)
