"""Pure metadata/boundary controls; no workloads or codecs. Root executes."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

H=Path(__file__).parent
G=1024**3
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,H/file)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
d=load('budget_v2_driver','matched-driver.py')
p=load('budget_v2_producer','compressed_retention.py')
r=load('budget_v2_reader','retention_audit.py')
# Extract the real independent auditor's metadata gates, without invoking main.
s=(H/'audit.py').read_text();tree=ast.parse(s)
constants={'STORAGE_POLICY','STORAGE_POLICY_SHA','STORAGE_GUARDS'}
functions={'require','check_storage_policy','validate_storage'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in functions or
       isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in constants]
a={'json':json};exec(compile(ast.Module(body=nodes,type_ignores=[]),'audit.py:metadata-only','exec'),a)

class StoragePolicy(unittest.TestCase):
    def binding(self):
        return dict(storage_policy=json.loads((H/'storage-policy.json').read_text()),
                    storage_policy_sha256=hashlib.sha256((H/'storage-policy.json').read_bytes()).hexdigest())
    def observation(self,phase):
        limits={'preflight':{'tmpfs':32*G,'retention':24*G},
                'runtime':{'tmpfs':16*G,'retention':24*G}}[phase]
        return dict(started_unix_ns=1,completed_unix_ns=2,filesystems={name:dict(
            path='/dev/shm' if name=='tmpfs' else '/owned',device=11 if name=='tmpfs' else 22,
            fragment_bytes=1,blocks=n+100,free_blocks=n+50,available_blocks=n,available_bytes=n)
            for name,n in limits.items()})
    def test_exact_independent_policy_and_missing_mismatch_refusal(self):
        original=self.binding()
        self.assertEqual(original['storage_policy']['policy_id'],'kv9-local-benchmark-storage-v3')
        self.assertEqual(original['storage_policy']['pre_cohort'],dict(tmpfs_bytes=32*G,host_bytes=24*G))
        self.assertEqual(original['storage_policy']['measurement'],dict(tmpfs_bytes=16*G,host_bytes=24*G))
        self.assertEqual(original['storage_policy']['post_run'],dict(host_floor_bytes=8*G,fresh_restore_reserve_bytes=16*G,metadata_margin_bytes=G))
        guards=[d.check_storage_policy,p.check_storage_policy,r.check_storage_policy,a['check_storage_policy']]
        for guard in guards:
            guard(original)
            bads=[{},dict(storage_policy=original['storage_policy']),dict(original,storage_policy_sha256='0'*64)]
            for key in ('policy_id','post_run','pre_cohort','measurement','available_space'):
                bad=copy.deepcopy(original);bad['storage_policy'].pop(key);bads.append(bad)
            bad=copy.deepcopy(original);bad['storage_policy']['post_run']['host_floor_bytes']=96*G;bads.append(bad)
            bad=copy.deepcopy(original);bad['storage_policy']['policy_id']='kv9-local-benchmark-storage-v1';bads.append(bad)
            for bad in bads:
                with self.assertRaisesRegex(ValueError,'storage policy'):guard(bad)
    def test_preflight_and_measured_equality_one_byte_below(self):
        for phase in ('preflight','runtime'):
            good=self.observation(phase)
            d.require_storage(good,phase)
            self.assertEqual(a['validate_storage'](good,Path('/owned'),phase),dict(tmpfs=11,retention=22))
            for name in ('tmpfs','retention'):
                bad=copy.deepcopy(good)
                for field in ('available_bytes','available_blocks'):bad['filesystems'][name][field]-=1
                with self.assertRaises(ValueError):d.require_storage(bad,phase)
                with self.assertRaisesRegex(ValueError,'storage guard'):a['validate_storage'](bad,Path('/owned'),phase)
    def test_missing_wrong_device_and_inconsistent_available_refusal(self):
        good=self.observation('runtime')
        for field in ('tmpfs','retention'):
            bad=copy.deepcopy(good);del bad['filesystems'][field]
            with self.assertRaises((KeyError,ValueError)):d.require_storage(bad,'runtime')
            with self.assertRaises(ValueError):a['validate_storage'](bad,Path('/owned'),'runtime')
            bad=copy.deepcopy(good);bad['filesystems'][field]['device']+=1
            with self.assertRaisesRegex(ValueError,'device identity'):a['validate_storage'](bad,Path('/owned'),'runtime',dict(tmpfs=11,retention=22))
        for field in ('device','available_blocks','available_bytes'):
            bad=copy.deepcopy(good);del bad['filesystems']['retention'][field]
            with self.assertRaises(ValueError):a['validate_storage'](bad,Path('/owned'),'runtime')
        bad=copy.deepcopy(good);bad['filesystems']['retention']['available_bytes']+=1
        with self.assertRaisesRegex(ValueError,'statvfs arithmetic'):a['validate_storage'](bad,Path('/owned'),'runtime')
    def test_observation_uses_available_not_excluded_free_blocks(self):
        v=types.SimpleNamespace(f_frsize=4096,f_blocks=100000000,f_bfree=90000000,f_bavail=12345)
        with patch.object(d.os,'statvfs',return_value=v):result=d.storage_observation(H)
        for row in result['filesystems'].values():
            self.assertEqual(row['available_bytes'],12345*4096)
            self.assertNotEqual(row['available_bytes'],row['free_blocks']*4096)
    def test_retention_floor_and_per_file_reservation_boundary(self):
        parent=H/'synthetic-first';parent.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='policy-metadata-',dir=parent) as tmp:
            for reserve in (0,8*G+(8*G)//128+1024**2+8*1024**2):
                budget=p.Budget(Path(tmp))
                with patch.object(p.shutil,'disk_usage',return_value=types.SimpleNamespace(free=8*G+reserve)):
                    budget.check(reserve)
                with patch.object(p.shutil,'disk_usage',return_value=types.SimpleNamespace(free=8*G+reserve-1)):
                    with self.assertRaisesRegex(ValueError,'floor/space'):budget.check(reserve)
    def test_independent_limits_and_unchanged_codec_and_measured_closure(self):
        self.assertEqual(p.LIMITS,r.LIMITS)
        self.assertEqual(p.LIMITS['retention_floor_bytes'],8*G)
        def funcs(file):
            raw=file.read_text();return {n.name:ast.get_source_segment(raw,n) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
        for file,names in [('compressed_retention.py',['codec','single_frame','hash_original','tree_inventory','no_references','close_fixture']),
                           ('retention_audit.py',['full_decode','validate_frame','combined_physical']),
                           ('matched-driver.py',['observe_client','fresh_drain','require_storage','storage_observation','make_plan'])]:
            old=funcs(H/'v1-original'/file);new=funcs(H/file)
            for name in names:self.assertEqual(old[name],new[name],name)
        # The authorized cleanup repair changes finally/completion only.
        bodies=[]
        for file in (H/'v1-original/matched-driver.py',H/'matched-driver.py'):
            raw=file.read_text()
            function=next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name=='native_trial')
            measured=next(n for n in function.body if isinstance(n,ast.Try) and n.finalbody)
            bodies.append([ast.get_source_segment(raw,n) for n in measured.body])
        self.assertEqual(*bodies)
    def test_protocol_commands_and_hash_closure(self):
        protocol=json.loads((H/'protocol.json').read_text());d.check_storage_policy(protocol)
        self.assertEqual(protocol['protocol_id'],'kv9-upper-bound-write-ab-c1-c64-storage-v3')
        for field,file in [('driver_sha256','matched-driver.py'),('auditor_sha256','audit.py')]:
            self.assertEqual(protocol[field],hashlib.sha256((H/file).read_bytes()).hexdigest())
        for field,file in [('helper','compressed_retention.py'),('independent_reader','retention_audit.py')]:
            self.assertEqual(protocol['compressed_retention'][field]['sha256'],hashlib.sha256((H/file).read_bytes()).hexdigest())
        self.assertFalse(protocol['runtime_ready'])
        self.assertEqual([str(x) for x in p.COHORT_ROOTS],[str(x) for x in r.COHORT_ROOTS])
        self.assertNotEqual(str(p.COHORT_ROOTS[0]),'/tmp/kv9-fnv-writer-performance-smoke-20260914-first')

if __name__=='__main__':unittest.main(verbosity=2)
