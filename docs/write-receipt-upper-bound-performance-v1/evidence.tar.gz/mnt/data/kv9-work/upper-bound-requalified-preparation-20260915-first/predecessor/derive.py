"""Finite source/metadata-only derivation. Does not import or execute campaign code."""
from pathlib import Path
import ast, copy, difflib, hashlib, json, os, time

P=Path(__file__).resolve().parent
Q=P/'readiness'
O=Path('/tmp/kv9-receipt-tail-performance-v3-preparation-20260915-first')
OR=Path('/tmp/kv9-receipt-tail-performance-v3-readiness-preparation-20260915-first')
B=Path('/tmp/kv9-upper-bound-release-20260915-first')
S=Path('/tmp/kv9-receipt-upper-bound-20260915-first')
REV='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
SMOKE='/tmp/kv9-upper-bound-performance-smoke-20260915-first'
TIMING='/tmp/kv9-upper-bound-performance-timing-20260915-first'

def raw(p):
    p=Path(p)
    assert p.is_file() and not p.is_symlink() and p.stat().st_size<=2*1024**2, str(p)
    return p.read_bytes()
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
def read(p):return json.loads(raw(p))
def pin(p):return dict(path=str(p),bytes=len(raw(p)),sha256=sha(p))
def write(p,data):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb')as f:f.write(data.encode()if isinstance(data,str)else data)
def save(p,data):write(p,json.dumps(data,indent=2,sort_keys=True)+'\n')

# Preserve all finite frozen predecessor files, including original failures/diffs.
origins=[]
for source,name in [(O,'predecessor'),(OR,'predecessor-readiness')]:
    inv=read(source/'inventory.json')
    for row in inv['files']:
        rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts
        source_file=source/rel;data=raw(source_file)
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],str(source_file)
        write(P/name/rel,data)
    write(P/name/'inventory.json',raw(source/'inventory.json'))
    origins.append(pin(source/'inventory.json'))

manifest=read(B/'build.json')
assert manifest['revision']==REV and manifest['dirty'] is False and manifest['profile']=='release'
server_sha=manifest['binaries']['kv9']['sha256']
assert server_sha=='6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49'
sub={str(O):str(P),str(OR):str(Q),
 '/tmp/kv9-receipt-tail-release-source-20260915-first':str(S),
 '/tmp/kv9-receipt-tail-release-20260915-first':str(B),
 'a6ac335ef4567f2e1a2b33da1a723d694cd5b7d9':REV,
 'd83b4e2ede7bcd81e4a6c4adbc407d2fbd6790d9fcab5851314ed907a6fb0a8c':server_sha,
 '5f9875e74ad972be7842a37b0be7f91100931060c9df60fbeb748ad0d91d483c':sha(B/'build.json'),
 'kv9-receipt-tail-write-ab-c1-c64-storage-v3':'kv9-upper-bound-write-ab-c1-c64-storage-v3',
 '/tmp/kv9-receipt-tail-performance-v3-smoke-20260915-first':SMOKE,
 '/tmp/kv9-receipt-tail-performance-v3-timing-20260915-first':TIMING}
def replace(text):
    for a,b in sorted(sub.items(),key=lambda row:-len(row[0])):text=text.replace(a,b)
    return text

names=['matched-driver.py','audit.py','compressed_retention.py','retention_audit.py','isolate-and-run.py',
 'test_driver.py','test_audit_contract.py','test_smoke_schema.py','test_storage_policy.py',
 'test_cleanup_metadata.py','test_compressed_retention.py','driver-arguments.json','commands.json',
 'protocol.json','storage-policy.json']
qnames=['check-smoke-v3.py','test_smoke_v3_bindings.py','test_source_bindings.py','bind-roles.py',
 'runtime-commands.json']
texts={P/n:replace(raw(O/n).decode())for n in names}
texts.update({Q/n:replace(raw(OR/n).decode())for n in qnames})
def th(p):return hashlib.sha256(texts[p].encode()).hexdigest()
for upstream,downstream in [
 ('compressed_retention.py',[P/'matched-driver.py',P/'audit.py',Q/'check-smoke-v3.py',Q/'test_smoke_v3_bindings.py']),
 ('retention_audit.py',[P/'audit.py']),('isolate-and-run.py',[P/'audit.py']),
 ('driver-arguments.json',[P/'audit.py']),
 ('matched-driver.py',[P/'audit.py',Q/'check-smoke-v3.py',P/'commands.json',Q/'runtime-commands.json']),
 ('audit.py',[Q/'check-smoke-v3.py'])]:
    for target in downstream:texts[target]=texts[target].replace(sha(O/upstream),th(P/upstream))

p=json.loads(texts[P/'protocol.json'])
p.update(driver_sha256=th(P/'matched-driver.py'),auditor_sha256=th(P/'audit.py'),
         runtime_ready=False,capacity_qualified=False,contracts_executed=False,chaos_accepted=False)
p['role_labels']['new']='Receipt upper-bound exact e2e23cca (default production release)'
p['large_synthetic_qualified']='Inherited accepted functions/limits unchanged. No local control, codec or campaign execution in this preparation.'
for k,n in [('helper','compressed_retention.py'),('independent_reader','retention_audit.py')]:
    p['compressed_retention'][k]=dict(bytes=len(texts[P/n].encode()),sha256=th(P/n))
texts[P/'protocol.json']=json.dumps(p,indent=2,sort_keys=True)+'\n'

for target,data in texts.items():write(target,data)
# Qualified fixtures referenced by unchanged control source; retained, not replayed.
for folder in ['origins','v1-original']:
    for source in sorted((O/folder).iterdir()):write(P/folder/source.name,raw(source))

roles=json.loads(replace(raw(OR/'role-inputs.json').decode()))
new=roles['roles']['new'];new.update(source_files=len(manifest['sources']),source_tree_sha256=manifest['source_tree_sha256'],
 rustc=manifest['rustc'],manifest=pin(B/'build.json'))
roles.update(fresh_role_gate_executed=False,runtime_ready=False)
save(Q/'role-inputs.json',roles)

c=json.loads(replace(raw(OR/'ROOT-COMMANDS.json').decode()))
for key,value in c.items():
    if isinstance(value,list):c[key]=[item.replace(sha(O/'matched-driver.py'),th(P/'matched-driver.py'))if isinstance(item,str)else item for item in value]
c['runtime_commands_released']=False;c['fresh_capacity_pending']=True;c['candidate_chaos_pending']=True
c['serial_order']=['root_completed_candidate_chaos_and_post_binding','root_review_static_helper_closure',
 'bind_current_source_and_retained_roles','root_fresh_full_campaign_capacity_and_exclusivity',
 'smoke_root_only_after_contracts_and_capacity','smoke_readback_after_smoke_terminal',
 'root_actual_remaining_capacity','timing_root_only_after_smoke_terminal_and_capacity','audit_root_only_after_timing_terminal']
c['inherited_controls']='Commands retained for review; no unchanged control replay requested or executed. Root decides whether changed source pins need the existing focused controls.'
c['prerequisite_file']=str(P/'prerequisites.json')
save(P/'ROOT-COMMANDS.json',c)

# Bind completed prerequisites without borrowing the predecessor candidate's Chaos acceptance.
inputs=[B/'build.json',Path('/tmp/kv9-upper-bound-release-root-20260915-first/terminal.json'),
 Path('/tmp/kv9-upper-bound-release-root-20260915-first/readback-first/result.json'),
 Path('/tmp/kv9-upper-bound-release-root-20260915-first/readback-first/input-hashes.json'),
 Path('/tmp/kv9-upper-bound-recovery-root-20260915-first/terminal.json'),
 Path('/tmp/kv9-upper-bound-recovery-audit-20260915-first/audit.json'),
 Path('/tmp/kv9-upper-bound-recovery-audit-20260915-first/tool-terminal.json'),
 Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/inventory.pending.json'),
 Path('/tmp/kv9-upper-bound-chaos-preparation-20260915-first/ROOT-COMMANDS.json')]
save(P/'prerequisites.json',dict(complete=False,runtime_ready=False,candidate_revision=REV,
 default_release_and_ordinary_recovery='Actual completed receipts pinned; no diagnostic server used.',
 completed_metadata_inputs=[pin(f)for f in inputs],
 pending=dict(full21_runtime_terminal='/tmp/kv9-upper-bound-chaos-root-20260915-first/terminal.json',
 full21_post_terminal='/tmp/kv9-upper-bound-chaos-root-20260915-first/post-terminal.json',
 full21_independent_audit='/tmp/kv9-upper-bound-chaos-preparation-20260915-first/independent/audit.json',
 full21_all_lifetimes='/tmp/kv9-upper-bound-chaos-preparation-20260915-first/cleanup/all-server-lifetimes-exited.json',
 fresh_role_binding=str(Q/'role-bindings-first.json'),fresh_capacity=True),
 scope='Candidate full21 runtime, independent history/drains, archive/readback and exact cleanup must actually complete. No previous candidate result authorizes this screen. Root records actual current receipts separately after terminal.'))

# Small original accepted report metadata only; no payload stat/hash/decoder or tree census.
ap=O/'results-first/audit.json';a=read(ap)
assert a['complete'] and a['matched_diagnostic_accepted'] and a['successful_arms']==16
ret=a['compressed_retention'];physical=ret['combined_independent_allocated_bytes']
timed=sum(row['compressed_bytes']for row in ret['cohorts'])
smoke=sum(row['compressed_bytes']for row in ret['smoke_byte_retention'])
overhead=physical-timed-smoke;assert overhead>=0
G=1024**3;inherited=79455850496;remaining=73462044626
sv=os.statvfs('/tmp');shm=os.statvfs('/dev/shm');available=sv.f_bavail*sv.f_frsize
save(P/'capacity.json',dict(runtime_ready=False,capacity_qualified=False,observed_ns=time.time_ns(),
 available_bytes=available,available_formula='f_bavail * f_frsize',filesystem_device=os.stat('/tmp').st_dev,
 tmpfs_available_bytes=shm.f_bavail*shm.f_frsize,
 original_policy=read(P/'storage-policy.json'),policy_sha256=sha(P/'storage-policy.json'),
 actual_prior_receipt_screen=dict(audit=pin(ap),terminal=pin(Path('/tmp/kv9-receipt-tail-performance-v3-execution-evidence-20260915-first/audit-terminal.json')),
 whole_resident_allocated_bytes=physical,smoke_compressed_object_bytes=smoke,timed_compressed_object_bytes=timed,
 whole_campaign_non_object_and_allocation_overhead_bytes=overhead,
 additional_whole_campaign_empirical_scenario_bytes=physical+25*G,
 remaining_timing_scenario_charging_all_prior_overhead_bytes=timed+overhead+25*G),
 retained_conservative_plan=dict(initial_required_available_bytes=inherited,remaining_timing_required_available_bytes=remaining,
 historical_resident_bytes=52612304896,envelope_bytes=25*G,
 reference=pin(Path('/tmp/kv9-published-directory-performance-v3-preparation-20260915-first/README.md')),
 runtime_host_floor_bytes=24*G,retention_host_floor_bytes=8*G,max_restore_bytes=16*G,metadata_margin_bytes=G,
 arithmetic='P + max(24 GiB, 8 GiB + 16 GiB) + 1 GiB; keep larger accepted prior P, not object-only bytes.'),
 phase_guards=dict(smoke_and_timing_host_launch_bytes=24*G,tmpfs_launch_bytes=32*G,tmpfs_runtime_bytes=16*G,
 max_fresh_restore_launch_bytes=24*G+8*1024**2),
 observed_full_campaign_gap_bytes=max(0,inherited-available),
 proposal=dict(scope='Capacity proposal only; no inventory expansion or conversion/cleanup authorization.',
 finite_goal='After candidate Chaos/post terminal, obtain actual additional available bytes to reach the retained 79,455,850,496-byte scenario; then root refreshes space and exclusive-use checks.',
 constraints='Only separately frozen task-owned inactive-cache retirement or existing qualified lossless retained-object migration may contribute actual receipts. No old cleanup credit, object deletion, reserved blocks, assumed compression ratio or lowered guard.',
 current_transform_selection=None),
 limitations='Whole-resident empirical scenario, not a guaranteed bound. New throughput/output and unrelated writers may change use. A per-cohort threshold alone does not fund the complete 8+16 campaign. After smoke, actual availability already excludes its retention; use remaining-timing scenario without charging smoke twice. Root auxiliary build was active during this read-only observation.'))

# Source-only equality proofs. No imports, helper functions, controls or codecs executed.
def functions(text):return{n.name:ast.get_source_segment(text,n)for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def normalized(text):
    tree=ast.parse(text)
    for n in ast.walk(tree):
        if isinstance(n,ast.Constant)and isinstance(n.value,str):n.value='<string>'
    return ast.dump(tree,include_attributes=False)
changes=[];protected={}
for source,target,group in [(O,P,names),(OR,Q,qnames)]:
    for n in group:
        before=raw(source/n).decode();after=raw(target/n).decode()
        diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(source/n),tofile=str(target/n)))
        write(P/'diffs'/('readiness'if target==Q else 'helpers')/(n+'.diff'),diff)
        if n.endswith('.py'):assert normalized(before)==normalized(after),n
        changes.append(dict(original=pin(source/n),derived=pin(target/n),string_only_ast=n.endswith('.py')))
for n in ['matched-driver.py','compressed_retention.py','retention_audit.py','isolate-and-run.py']:
    a,b=functions(raw(O/n).decode()),functions(raw(P/n).decode())
    changed=[k for k in a if a[k]!=b[k]]
    assert changed==(['main']if n=='matched-driver.py'else[]),(n,changed)
    protected[n]=dict(changed=changed,unchanged_functions_and_classes=[k for k in a if k not in changed])
assert raw(P/'storage-policy.json')==raw(O/'storage-policy.json')
for field in ['smoke_inventory','timed_inventory','expected_counts','storage_guards','client_pins','client_revision']:
    assert p[field]==read(O/'protocol.json')[field],field
for f in P.rglob('*.py'):ast.parse(raw(f))
save(P/'substitutions.json',sub)
save(P/'source-delta.json',dict(complete=True,static_only=True,tests_executed=False,
 original_inventories=origins,files=changes,protected=protected,
 unchanged_policy_sha256=sha(P/'storage-policy.json'),
 scope='Exact path/source/revision/default-server/helper pins and labels only. All non-string AST nodes, complete 8+16 descriptors, measured functions, codec/decode/restore classes and predicates unchanged. Original failures and accepted control evidence preserved.'))
print(json.dumps(dict(prepared=True,driver_sha256=sha(P/'matched-driver.py'),auditor_sha256=sha(P/'audit.py'),
 protocol_sha256=sha(P/'protocol.json'),commands_sha256=sha(P/'ROOT-COMMANDS.json'),
 capacity_gap_bytes=inherited-available,runtime_ready=False)))
