# Upper-bound candidate: original matched write screen preparation

This is a preparation, not runtime or performance acceptance. Compare the
retained default `e2e23cca` upper-bound server with selected CRC `bd42e60`, using
the unchanged native v3 `0be806d` client. The diagnostic-feature server is not a
campaign input. Actual default release and ordinary recovery receipts are in
`prerequisites.json`; candidate full21 Chaos and its complete post acceptance
remain pending. Preparation-time false flags stay immutable.

The exact eight 2-second smokes and sixteen 10-second timed descriptors are
unchanged: Put and BatchPut64, concurrency 1 and 64, both roles, two complete
opposite timing orders, 4096 keys, 128-byte values, seed 71 and 128 warmup calls.
Three-voter quorum, WAL/sync/reply fences, sentinel/dataset checks, all outcomes,
attempts, fresh drains, PID/start/boot identities, CPU placement and host samples,
cleanup, retention and independent audit predicates are retained. The fixed
native v3 scripts import in the smoke reader is preserved. Full measured
histograms describe whole calls; batch latency is not divided by 64. This is a
shared-host/tmpfs diagnostic screen, with no power-loss durability or automatic
candidate-promotion claim.

`predecessor/` and `predecessor-readiness/` contain byte-exact copies of all 78
files in the two original frozen inventories, plus both inventories themselves.
These preserve the accepted helper/control lineage, original unsuccessful
derivations and earlier source diffs. `diffs/` and `source-delta.json` describe
this derivative. All non-string Python AST nodes are unchanged; producer,
decoder, restore and isolation function/class bytes are unchanged. Driver
`main` changes only strings for source paths and dependent helper pins; the
actual measured and cleanup functions are byte-identical. The full smoke and
timing descriptor JSONs are equal to the accepted predecessor. No controls,
builds, source/payload hashing gate, codecs or workloads were executed here.

## Exact root command sequence

`ROOT-COMMANDS.json` contains literal argv arrays with command-scoped
`safe.directory` for exactly the baseline, candidate and fixed-client sources,
`PYTHONOPTIMIZE=0` and helper CPUs 6-15,22-31. Root must first bind actual
candidate full21/runtime/post/history/archive/cleanup success and review this
frozen source closure. Then:

1. `bind_current_source_and_retained_roles` writes the fresh
   `readiness/role-bindings-first.json` using the original source-map, retained
   binary, compiler and default-feature checks. No rebuild is needed.
2. Record fresh full-campaign capacity and absence of competing work. Run
   `smoke_root_only_after_contracts_and_capacity`, retaining the actual terminal.
3. Run `smoke_readback_after_smoke_terminal`; require all eight actual smokes.
4. Refresh actual remaining timing capacity, then run
   `timing_root_only_after_smoke_terminal_and_capacity` with the original
   isolation/restoration wrapper.
5. After its actual successful terminal and restoration, run
   `audit_root_only_after_timing_terminal`. Replace only
   `ACTUAL_TERMINAL_TIMING_SESSION` with that actual timing session. A launch
   receipt is not acceptance.

The inherited focused and full control command arrays are retained for review;
this handoff does not request replay of unchanged controls. Root owns any
necessary qualification of changed source pins. Smoke, timing, role and audit
output paths are fresh. All original absolute paths identify local execution
locations, not a portable installation.

## Phase storage and remaining capacity

The original `kv9-local-benchmark-storage-v3` policy is byte-identical:
24 GiB host available before/during cohorts, 32/16 GiB tmpfs before/during,
8 GiB available during serial retention, with 8 GiB/member, 16 GiB/cohort and
128 GiB combined caps. A maximum fresh restore needs 24 GiB + 8 MiB available.
All available-space arithmetic uses `f_bavail`, excluding reserved blocks.

The accepted receipt screen's original final audit records **52,000,653,312 B**
whole resident allocation: **51,675,241,611 B** compressed objects plus
**325,411,701 B** metadata/allocation overhead. Its corresponding initial
scenario is **78,844,198,912 B**. Charging every byte of that overhead to timing
gives a conservative timing-only scenario of **73,071,311,296 B**.

Keep the slightly larger established planning requirements:
**79,455,850,496 B** before smoke and **73,462,044,626 B** before timing.
The first is 52,612,304,896 B historical resident output plus
`max(24 GiB, 8 GiB + 16 GiB) + 1 GiB`. Fresh availability after smoke already
includes its storage cost; do not charge smoke again in the timing scenario.

`capacity.json` pins these original audit/terminal/reference inputs. Its
26,839,244,800 B snapshot leaves a **52,616,605,696 B** initial gap. This was a
read-only observation while root auxiliary work was active, not a reservation.
The bounded proposal is to obtain at least that actual additional capacity
through separately frozen task-owned inactive-cache retirement or already
qualified lossless retained-object migration, and refresh the deficit after
Chaos/post exits. No transform selection or savings is authorized here; no
previous cleanup, expected ratio, retained-object deletion or lowered guard is
credited. The estimates are empirical scenarios, not worst-case output bounds;
all actual per-phase guards/caps remain controlling.

Static authoring completed with actual tool receipt `7dd6c8/0`; independent
syntax-only readback completed `55d237/0`. Full21 is currently root-owned; this
directory neither launches it nor changes its frozen inputs.
