"""Pre-timing smoke accounting and datasets; full enclosing audit remains required."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).parent
PREP = Path('/mnt/data/kv9-work/upper-bound-requalified-preparation-20260915-first')
SMOKE = Path('/mnt/data/kv9-work/upper-bound-requalified-smoke-20260915-first')
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(name, path):
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
NATIVE_SOURCE = Path('/mnt/data/kv9-work/performance-input-recovery-20260915-first/rebuild-first/source/scripts')
assert sha(NATIVE_SOURCE/'batch_benchmark_report.py') == '56cd11ddc7475a44ff1cf420f2086b4eefb19aa424c7270b95d4141920a40a96'
sys.path.insert(0,str(NATIVE_SOURCE))
import batch_benchmark_report as native
read = lambda path: native.strict_json(Path(path).read_bytes())
assert __debug__
assert sha(PREP/'matched-driver.py') == 'd494ae312ae4bf0a476bd4d6c58137cf66ba1ebf042880b4d11670d32f058a3e'
assert sha(PREP/'audit.py') == 'cc3cc0982b4f63046a5d8dbf36833105987976f22a1fbec0bd1a22a66fddd07f'
driver = load('crc_ab_smoke_driver',PREP/'matched-driver.py')
tree = ast.parse((PREP/'audit.py').read_text())
functions = [node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in {'require','mix','value','dataset_check'}]
assert len(functions) == 4
checks = {}
exec(compile(ast.Module(body=functions,type_ignores=[]),str(PREP/'audit.py'),'exec'),checks)
matrix = read(SMOKE/'matrix.json')
assert matrix['complete'] and matrix['smoke'] and len(matrix['attempts']) == 8
assert matrix['cohort_inventory'] == driver.make_plan(True)
driver.check_storage_policy(matrix)
assert matrix['protocol_id'] == driver.PROTOCOL_ID and matrix['storage_guards'] == driver.SPACE_GUARDS
assert sha(PREP/'storage-policy.json') == driver.STORAGE_POLICY_SHA
assert matrix['helper_hashes'][str(PREP/'storage-policy.json')] == driver.STORAGE_POLICY_SHA
driver.check_storage_policy(matrix['compressed_retention'])
assert matrix['compressed_retention']['helper_sha256'] == '00a2ccc16fd6a8ac57480b0b14eab5151cd2eb08f011a415d34f891f6376143b'
assert matrix['helper_hashes'][str(PREP/'compressed_retention.py')] == matrix['compressed_retention']['helper_sha256']
assert matrix['compressed_retention']['logical_campaign_roots'] == [str(SMOKE),'/mnt/data/kv9-work/upper-bound-requalified-timing-20260915-first/cohorts']
assert matrix['compressed_retention']['limits'] == dict(member_bytes=8*1024**3,cohort_bytes=16*1024**3,campaign_bytes=128*1024**3,metadata_bytes=8*1024**2,files=65536,codec_seconds=600,cohort_seconds=1800,io_bytes=1024**2,decode_memory_bytes=64*1024**2,retention_floor_bytes=8*1024**3)
out = ROOT/'smoke-readback'
out.mkdir(exist_ok=False)
result = dict(complete=False, started_ns=time.time_ns(), cases=[], matrix_sha256=sha(SMOKE/'matrix.json'), enclosing_auditor_sha256=sha(PREP/'audit.py'), scope=__doc__)
lifetimes = set()
try:
    for attempt in matrix['attempts']:
        assert attempt['complete'] and attempt['descriptor']['target'] == 'kv9'
        directory = Path(attempt['directory'])
        config = read(directory/'run/config.json')
        report = read(directory/'run/report.json')
        build = read(directory/'run/build.json')
        assert build == read('/mnt/data/kv9-work/performance-input-recovery-20260915-first/rebuild-first/native/build.json')
        accounting = native.report_check(report,config,build)
        assert accounting['successful_calls'] == report['measured_completed'] == report['measured_issued']
        assert report['dropped_slots'] == 0 and sha(directory/'run/report.json') == attempt['report_sha256']
        cleanup = read(directory/'cleanup.json')
        assert cleanup['complete'] and len(cleanup['children']) == 4
        for child in cleanup['children']:
            identity = child['identity']
            pid = identity['pid']
            assert pid not in lifetimes and not Path('/proc',str(pid)).exists()
            lifetimes.add(pid)
            assert child.get('absent',child.get('pid_absent_after_reap')) is True
            assert child['exit_code'] == (0 if pid == report['process_id'] else -9)
        dataset = {}
        pages = sorted(directory.glob('readback-*.txt'))
        assert pages
        for page in pages:
            lines = page.read_text().splitlines()
            assert lines[-1] == f'count={len(lines)-1}'
            for line in lines[:-1]:
                fields = dict(part.split('=',1) for part in line.split())
                key = bytes.fromhex(fields['key_hex'])
                assert key not in dataset
                dataset[key] = bytes.fromhex(fields['value_hex'])
        checked = checks['dataset_check'](config,dataset)
        result['cases'].append(dict(directory=str(directory), server_role=attempt['descriptor']['server_role'], calls=report['measured_completed'], successful_items=sum(op['populations'][0]['input_items'] for op in report['metrics']['measurement']['statistics']), report_sha256=sha(directory/'run/report.json'), dataset=checked))
    assert len(lifetimes) == 32
    result.update(complete=True, owned_lifetimes_exited=len(lifetimes), total_calls=sum(row['calls'] for row in result['cases']), successful_input_items=sum(row['successful_items'] for row in result['cases']))
except BaseException as error:
    result['failure'] = repr(error)
    raise
finally:
    result['ended_ns'] = time.time_ns()
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key != 'cases'}))
