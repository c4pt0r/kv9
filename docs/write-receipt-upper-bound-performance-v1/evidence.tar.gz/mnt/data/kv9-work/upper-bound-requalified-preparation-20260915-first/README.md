# Requalified client and data-volume matched write preparation

This is a separately identified preparation for the original eight 2-second smokes and sixteen 10-second timed cohorts: CRC `bd42e60` versus upper-bound `e2e23cca`, Put and BatchPut64, concurrency 1 and 64, and both opposite timing orders. Keys, values, seed, warmup, request limits, admission/queue semantics, quorum/durable-reply fences, all-success/single-attempt requirements, whole-call histograms, dataset/drain/lifetime checks and CPU placement are unchanged.

Both server roles use exactly one rebuilt client ELF, SHA-256 `1b8060eb168610328c10a27480de16bd8b2d6805166d8169638f85ceef0992c4`, 5,592,624 bytes. Its 581 source files match clean `0be806d`, and original Rust/Cargo 1.94 attestation checks remain. It is not the historical `8da9` ELF. The server source/ELF pins are unchanged. The recovered RESP utility is copied byte-exactly into this preparation; its development entry point is not invoked.

The original 136-file preparation and its inventory are preserved under `predecessor/`, including earlier diffs, controls and failures. `diffs/` and `source-delta.json` bind the final derivative. Actual native trial, request observation, fresh drain, source/Cargo validation and producer codec/hash/reference function bodies are byte-identical. The extra root-filesystem stat observation adds observer work, equally for both arms; the complete timing environment is not claimed unchanged.

Voters still run on the original volatile tmpfs. Only retained outputs move to `/mnt/data/kv9-work/upper-bound-requalified-{smoke,timing}-20260915-first`. This is a shared-host diagnostic screen with no physical-power-loss or automatic candidate-promotion claim. Historical measurements are not pooled with the requalified ELF's future results.

## Storage and launch

Keep the unchanged **79,455,850,496-byte** whole-campaign empirical available-space requirement on the output filesystem. After successful smoke/readback, refresh available space and use the unchanged **73,462,044,626-byte** remaining timing scenario; do not count smoke twice. Neither scenario is a worst-case output guarantee.

Each cohort additionally requires **24 GiB available on `/` and on its retained-output filesystem** at preflight and throughout sampled measurement. Tmpfs still requires 32 GiB before a cohort and 16 GiB during measurement. Producer retention, independent decoding and restoration require 8 GiB available separately on `/` and on their output filesystem. Original 8 GiB/member, 16 GiB/cohort, 128 GiB combined, metadata/restore reservations, codec memory/time/EOF/hash and lifetime guards remain. Every available-space calculation uses `f_bavail`; excluded reserved space is not credited. Output and restoration bytes are reserved once on the actual output device. If root and output share a device, the requirements take their maximum rather than charging output bytes twice.

The new explicit storage policy binds these additional root observations. The enclosing audit rejects missing root observations, wrong path/arithmetic, low space and device changes between preflight and runtime. Independent retention readback requires the reported root minimum to equal the actual minimum of retained samples. Sampling does not establish an uninterrupted kernel reservation or bound unrelated writers.

`capacity.json` is a historical preparation snapshot, not launch acceptance. Root must refresh capacity/exclusivity immediately before the exact commands in `ROOT-COMMANDS.json`.

## Qualification and exact execution sequence

The new client source tests passed under explicit Rust 1.94: 15 benchmark-binary, 26 client-library and 19 Python report tests; one existing independent-fixture client test remained ignored. Their original logs/terminals and the initial root-owned Git refusal are retained under `client-qualification/`. This is source-level qualification. The actual ELF still requires all eight complete smokes and independent report/dataset/drain/lifetime acceptance.

Fresh role binding passed actual `d9a635/0`: all 859 CRC, 1,116 candidate and 581 client source files, retained binaries, manifest/Cargo feature graphs and common compiler were checked. Only three exact process-local `safe.directory` entries are used. No global Git configuration changed.

The first new metadata control run (`304b88/1`) passed nine cases and exposed one preparation bug: an added root observation name collided with the producer's existing root-path loop variable. Its exact source and failure remain under `failures/controls-first/`. The corrected variable, exact sampled minimum, and dependent pin closure passed the three affected checks (`48e8d7/0`). The ten unique focused cases are covered by these retained results; this is not a claim that the first run passed or that unchanged historical controls were replayed. No codec, build or workload ran in this preparation.

Root's sequence is: review final inventory and retained qualification; refresh full root/data/tmpfs capacity and exclusivity; run the exact smoke argv; retain the actual terminal; run the smoke reader; refresh remaining timing capacity; run the original isolation wrapper and retain actual restoration/terminal; then run the enclosing audit with the actual successful timing session. Audit outputs are fresh under this preparation. No output path may overwrite a prior attempt. Current preparation flags remain `runtime_ready=false`; this packet does not grant launch release.
