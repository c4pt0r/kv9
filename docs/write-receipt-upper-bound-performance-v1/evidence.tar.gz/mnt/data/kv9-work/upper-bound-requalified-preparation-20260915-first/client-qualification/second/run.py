from pathlib import Path
import subprocess,json,time,os,hashlib
base=Path('/mnt/data/kv9-work');out=Path(__file__).resolve().parent
source=base/'performance-input-recovery-20260915-first/rebuild-first/source';native=source.parent/'native'
meta=json.loads((native/'build.json').read_text());sources=json.loads((native/'sources.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,PATH='/home/dongxu/.rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',RUSTUP_TOOLCHAIN='1.94.0-x86_64-unknown-linux-gnu',RUSTUP_HOME='/home/dongxu/.rustup',CARGO_HOME='/home/dongxu/.cargo',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='4',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(source.parent/'target'),TMPDIR='/tmp',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(source/'scripts'),GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=str(source))
assert sha(native/'kv9-batch-benchmark')==meta['binary_sha256']=='1b8060eb168610328c10a27480de16bd8b2d6805166d8169638f85ceef0992c4'
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source,env=env)==b''
for p,h in sources['sources'].items():assert sha(source/p)==h,p
(out/'client-inputs.json').write_text(json.dumps(dict(build=meta,source_pins=sources['sources'],binary_bytes=(native/'kv9-batch-benchmark').stat().st_size),indent=2)+'\n')
cases=[('benchmark-binary-tests',['cargo','test','--offline','--locked','-p','kv9-server','--bin','kv9-batch-benchmark','--release','--','--test-threads=4']),('client-library-tests',['cargo','test','--offline','--locked','-p','kv9-server','--lib','--release','client::','--','--test-threads=4']),('report-tests',['python3','-B','-m','unittest','discover','-s','scripts','-p','test_batch_benchmark_report.py'])]
for name,cmd in cases:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 record=dict(command=cmd,cwd=str(source),environment={k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_HOME','RUSTUP_HOME','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_TARGET_DIR','TMPDIR','PYTHONPATH','GIT_CONFIG_COUNT','GIT_CONFIG_KEY_0','GIT_CONFIG_VALUE_0']},exit_code=r.returncode,seconds=time.monotonic()-start)
 (out/(name+'-terminal.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(name,r.returncode,(out/(name+'.log')).read_text()[-2300:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for p,h in sources['sources'].items():assert sha(source/p)==h,p
assert sha(native/'kv9-batch-benchmark')==meta['binary_sha256']
(out/'test-qualification.json').write_text(json.dumps(dict(status='PASS',source_files_checked=len(sources['sources']),binary_sha256=meta['binary_sha256'],binary_unchanged=True,scope='Rebuilt client source-level benchmark/client/report tests only; actual ELF qualification still requires the eight complete retained smoke cohorts and independent dataset/report/lifetime audit.'),indent=2)+'\n')
