"""Finite path/client/root-filesystem derivation; no imports of runtime helpers."""
from pathlib import Path
import ast,difflib,hashlib,json,os,time
P=Path(__file__).resolve().parent
O=Path('/tmp/kv9-upper-bound-performance-preparation-20260915-first')
REC=Path('/mnt/data/kv9-work/performance-input-recovery-20260915-first')
CLIENT=REC/'rebuild-first/native';SOURCE=REC/'rebuild-first/source'
SMOKE='/mnt/data/kv9-work/upper-bound-requalified-smoke-20260915-first'
TIMING='/mnt/data/kv9-work/upper-bound-requalified-timing-20260915-first'
Q=P/'readiness';G=1024**3
def raw(p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and p.stat().st_size<=8*1024**2,str(p)
 return p.read_bytes()
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
def read(p):return json.loads(raw(p))
def pin(p):return dict(path=str(p),bytes=len(raw(p)),sha256=sha(p))
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb')as f:f.write(b.encode()if isinstance(b,str)else b)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
old_inventory=read(O/'inventory.json')
assert sha(O/'inventory.json')=='26e7e04e3b7a63e9d154f941f4b01593c50fb5951882d6661fe2ce04de38baa3'
assert len(old_inventory['files'])==136
for row in old_inventory['files']:
 p=O/row['path'];b=raw(p);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256'],str(p)
 write(P/'predecessor'/row['path'],b)
write(P/'predecessor/inventory.json',raw(O/'inventory.json'))
build=read(CLIENT/'build.json');sources=read(CLIENT/'sources.json')
assert build['binary_sha256']=='1b8060eb168610328c10a27480de16bd8b2d6805166d8169638f85ceef0992c4'
assert build['revision']=='0be806d9671e2c50701a64aa7889c8859b7648ba'and build['dirty']is False
assert len(sources['sources'])==581
assert sha(REC/'run_fixture.py')=='008c5bea0640a4a5a092feb6617798a84e9dd4889fd11bf8c6791cfe0852864a'
sub={str(O):str(P),'/tmp/kv9-point-write-measurement-v3':str(SOURCE),'/tmp/kv9-point-write-v3-release-first/native':str(CLIENT),
 '/tmp/kv9-redis-batch-reference-preparation/run_fixture.py':str(P/'run_fixture.py'),
 '/tmp/kv9-upper-bound-performance-smoke-20260915-first':SMOKE,
 '/tmp/kv9-upper-bound-performance-timing-20260915-first':TIMING,
 '8da9af469f962a938027d1970141bbe4622f7d42b2b795f720e288fb3f8d5957':build['binary_sha256'],
 'eb8b4e1421dd4e64dcca59fcc7829926d5789611f6b3748d07c4090f634f2c4c':sha(CLIENT/'build.json'),
 'kv9-upper-bound-write-ab-c1-c64-storage-v3':'kv9-upper-bound-requalified-client-data-volume-write-v1'}
def replace(s):
 for a,b in sorted(sub.items(),key=lambda x:-len(x[0])):s=s.replace(a,b)
 return s
names=['matched-driver.py','audit.py','compressed_retention.py','retention_audit.py','isolate-and-run.py',
 'driver-arguments.json','commands.json','protocol.json','storage-policy.json',
 'test_driver.py','test_audit_contract.py','test_smoke_schema.py','test_cleanup_metadata.py','test_compressed_retention.py',
 'readiness/bind-roles.py','readiness/check-smoke-v3.py','readiness/test_smoke_v3_bindings.py','readiness/test_source_bindings.py','readiness/runtime-commands.json']
texts={n:replace(raw(O/n).decode())for n in names}
policy=read(O/'storage-policy.json')
policy['policy_id']='kv9-local-benchmark-storage-v3-data-volume-root-guard-v1'
policy['additional_root_filesystem']=dict(path='/',pre_cohort_bytes=24*G,measurement_bytes=24*G,post_run_bytes=8*G,
 available_space='f_bavail * f_frsize',reservation='Output/restore bytes are reserved on the output filesystem only; root is separately observed, never counted twice.')
policy_text=json.dumps(policy,indent=2,sort_keys=True)+'\n';policy_sha=hashlib.sha256(policy_text.encode()).hexdigest()
texts['storage-policy.json']=policy_text
for n in ['matched-driver.py','audit.py','compressed_retention.py','retention_audit.py']:
 tree=ast.parse(texts[n]);node=next(x for x in tree.body if isinstance(x,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='STORAGE_POLICY'for t in x.targets))
 texts[n]=texts[n].replace(ast.get_source_segment(texts[n],node),'STORAGE_POLICY = '+repr(policy))
 texts[n]=texts[n].replace('cebdc41bbed8fd7000ef11fc5de29aa10722fc1112008366ef24e2e7d8924ba1',policy_sha)

# One additional observed filesystem; no measured trial or request-loop edit.
n='matched-driver.py';s=texts[n]
s=s.replace('"retention": 24 * 1024**3}', '"retention": 24 * 1024**3, "root": 24 * 1024**3}')
s=s.replace('(("tmpfs", Path("/dev/shm")), ("retention", directory))','(("tmpfs", Path("/dev/shm")), ("retention", directory), ("root", Path("/")))')
texts[n]=s
n='audit.py';s=texts[n]
s=s.replace("'retention':24*1024**3}","'retention':24*1024**3,'root':24*1024**3}")
s=s.replace("{'tmpfs','retention'}","{'tmpfs','retention','root'}")
s=s.replace("(('tmpfs','/dev/shm'),('retention',str(directory)))","(('tmpfs','/dev/shm'),('retention',str(directory)),('root','/'))")
s=s.replace("for name in ('tmpfs','retention')","for name in ('tmpfs','retention','root')")
texts[n]=s

# Independent implementations retain the same exact floor and f_bavail units.
# They do not reserve output bytes twice when the two paths share a device.
def root_function(check):return '''\ndef root_storage_observation(expected_device=None):
    value=os.statvfs('/');device=Path('/').stat().st_dev
    row=dict(path='/',device=device,fragment_bytes=value.f_frsize,blocks=value.f_blocks,
             free_blocks=value.f_bfree,available_blocks=value.f_bavail,
             available_bytes=value.f_bavail*value.f_frsize)
    CHECK(row['available_bytes']>=LIMITS['retention_floor_bytes'],'root filesystem retention floor')
    CHECK(expected_device is None or device==expected_device,'root filesystem device changed')
    return row
'''.replace('CHECK',check)
n='compressed_retention.py';s=texts[n]
s=s.replace('class Budget:',root_function('need')+'\nclass Budget:')
s=s.replace('self.samples=[];self.last_scan=0;self.physical=0','self.samples=[];self.last_scan=0;self.physical=0\n        self.root_device=None;self.root_minimum=None')
s=s.replace('now=time.monotonic();free=shutil.disk_usage(self.campaign).free','now=time.monotonic();free=shutil.disk_usage(self.campaign).free\n        host_root=root_storage_observation(self.root_device);self.root_device=host_root[\'device\']\n        self.root_minimum=host_root[\'available_bytes\']if self.root_minimum is None else min(self.root_minimum,host_root[\'available_bytes\'])')
s=s.replace('available_bytes=free,allocated_bytes=physical)', 'available_bytes=free,allocated_bytes=physical,root_filesystem=host_root)')
s=s.replace('return dict(minimum_available_bytes=self.minimum,samples=self.samples,complete=True)','return dict(minimum_available_bytes=self.minimum,samples=self.samples,complete=True,\n                    root_device=self.root_device,root_minimum_available_bytes=min(row[\'root_filesystem\'][\'available_bytes\']for row in self.samples)if self.samples else None)')
s=s.replace("    dst.mkdir();receipts=[];budget=Budget.__new__(Budget)","    root_storage_observation()\n    dst.mkdir();receipts=[];budget=Budget.__new__(Budget)")
s=s.replace('budget.samples=[];budget.last_scan=0;budget.physical=0','budget.samples=[];budget.last_scan=0;budget.physical=0\n    budget.root_device=None;budget.root_minimum=None')
texts[n]=s
n='retention_audit.py';s=texts[n]
s=s.replace('def full_decode(path,expected,observation):',root_function('check')+'''\ndef validate_root_budget(budget):
    check(type(budget.get('root_device'))is int and budget['root_device']>0,'missing root device')
    check(type(budget.get('root_minimum_available_bytes'))is int and budget['root_minimum_available_bytes']>=LIMITS['retention_floor_bytes'],'missing/below-floor root minimum')
    check(budget.get('samples'),'missing root budget samples')
    check(budget['root_minimum_available_bytes']==min(sample.get('root_filesystem',{}).get('available_bytes',-1)for sample in budget['samples']),'root budget minimum differs from samples')
    for sample in budget['samples']:
        row=sample.get('root_filesystem',{})
        check(set(row)=={'path','device','fragment_bytes','blocks','free_blocks','available_blocks','available_bytes'}and row['path']=='/','root budget schema/path')
        check(all(type(row[k])is int for k in row if k!='path'),'root budget integer schema')
        check(row['device']==budget['root_device']and row['fragment_bytes']>0,'root budget device')
        check(0<=row['available_blocks']<=row['free_blocks']<=row['blocks']and row['available_bytes']==row['available_blocks']*row['fragment_bytes'],'root budget arithmetic')
        check(row['available_bytes']>=budget['root_minimum_available_bytes'],'root budget floor/minimum')

def full_decode(path,expected,observation):''')
s=s.replace('    validate_frame(path)\n',"    root_initial=root_storage_observation();root_device=root_initial['device'];root_minimum=root_initial['available_bytes']\n    validate_frame(path)\n",1)
s=s.replace('            free=shutil.disk_usage(path.parent).free;minimum=min(minimum,free)',"            free=shutil.disk_usage(path.parent).free;minimum=min(minimum,free)\n            root=root_storage_observation(root_device);root_minimum=min(root_minimum,root['available_bytes'])")
s=s.replace('minimum_available_bytes=minimum)','minimum_available_bytes=minimum,root_path=\'/\',root_device=root_device,root_minimum_available_bytes=root_minimum)')
s=s.replace("    members=catalog['members'];", "    validate_root_budget(budget)\n    members=catalog['members'];")
texts[n]=s

def th(n):return hashlib.sha256(texts[n].encode()).hexdigest()
for upstream,downstream in [
 ('compressed_retention.py',['matched-driver.py','audit.py','readiness/check-smoke-v3.py','readiness/test_smoke_v3_bindings.py']),
 ('retention_audit.py',['audit.py']),('isolate-and-run.py',['audit.py']),('driver-arguments.json',['audit.py']),
 ('matched-driver.py',['audit.py','readiness/check-smoke-v3.py','commands.json','readiness/runtime-commands.json']),
 ('audit.py',['readiness/check-smoke-v3.py'])]:
 for target in downstream:texts[target]=texts[target].replace(sha(O/upstream),th(upstream))
for n in texts:
 if n.endswith('.py'):ast.parse(texts[n])
p=json.loads(texts['protocol.json']);p.update(driver_sha256=th('matched-driver.py'),auditor_sha256=th('audit.py'),
 storage_policy=policy,storage_policy_sha256=policy_sha,runtime_ready=False,capacity_qualified=False,contracts_executed=False,chaos_accepted=True,
 client_requalification='One new ELF 1b8060eb at unchanged 0be806d source; not historical 8da9 executable. Both server roles use this exact new client.',
 storage_scope='Original tmpfs voters. Retained outputs on /mnt/data; original root filesystem additionally observed. No physical-power-loss claim.')
p['storage_guards']={phase:dict(v,root=24*G)for phase,v in p['storage_guards'].items()}
for k,n in [('helper','compressed_retention.py'),('independent_reader','retention_audit.py')]:p['compressed_retention'][k]=dict(bytes=len(texts[n].encode()),sha256=th(n))
p['compressed_retention']['storage_policy']=policy;p['compressed_retention']['storage_policy_sha256']=policy_sha
texts['protocol.json']=json.dumps(p,indent=2,sort_keys=True)+'\n'
for n,s in texts.items():write(P/n,s)
write(P/'run_fixture.py',raw(REC/'run_fixture.py'))
# Preserve auxiliary inherited fixture inputs; do not replay their tests.
for folder in ['origins','v1-original']:
 for old in sorted((O/folder).iterdir()):write(P/folder/old.name,raw(old))
roles=json.loads(replace(raw(O/'readiness/role-inputs.json').decode()))
roles['roles']['client'].update(manifest=pin(CLIENT/'build.json'),source_files=581,source_tree_sha256=build['source_tree_sha256'],
 scope='Separately requalified rebuild. Exact source matches 0be806d; ELF differs from historical 8da9. One client ELF for both server roles.')
save(Q/'role-inputs.json',roles)
c=json.loads(replace(raw(O/'ROOT-COMMANDS.json').decode()))
for k,v in c.items():
 if isinstance(v,list):c[k]=[x.replace(sha(O/'matched-driver.py'),th('matched-driver.py'))if isinstance(x,str)else x for x in v]
c.update(candidate_chaos_pending=False,runtime_commands_released=False,fresh_capacity_pending=True,
 source_binding_required='Fresh existing source/binary/compiler/default-feature readers must pass for the ONE requalified client and both unchanged servers. Root must also bind actual client source/tests qualification.',
 serial_order=['actual_client_source_test_qualification','root_focused_changed_guard_controls','bind_current_source_and_retained_roles','root_fresh_full_capacity_and_exclusivity','smoke_root_only_after_contracts_and_capacity','smoke_readback_after_smoke_terminal','root_fresh_remaining_timing_capacity','timing_root_only_after_smoke_terminal_and_capacity','audit_root_only_after_timing_terminal'])
save(P/'ROOT-COMMANDS.json',c)
write(P/'actual-chaos-binding.json',raw(O/'actual-chaos-binding.json'))
save(P/'prerequisites.json',dict(runtime_ready=False,client_requalification_pending=True,client_build=pin(CLIENT/'build.json'),client_sources=pin(CLIENT/'sources.json'),
 original_helper_inventory=pin(O/'inventory.json'),completed_candidate_chaos_binding=pin(O/'actual-chaos-binding.json'),
 recovered_resp_helper=pin(REC/'run_fixture.py'),new_resp_copy=pin(P/'run_fixture.py'),
 pending=['root actual new-client source/test acceptance','focused changed guard controls','fresh full roles','root actual capacity/exclusivity'],
 scope='No repeat of accepted candidate full21. No historical client-ELF equivalence claim. Preparation is not launch release.'))
capacity=read(O/'capacity.json');observations={}
for n,path in [('root','/'),('output','/mnt/data/kv9-work'),('tmpfs','/dev/shm')]:
 v=os.statvfs(path);observations[n]=dict(path=path,device=os.stat(path).st_dev,available_bytes=v.f_bavail*v.f_frsize)
save(P/'capacity.json',dict(runtime_ready=False,observed_ns=time.time_ns(),observations=observations,original=pin(O/'capacity.json'),
 initial_output_required_bytes=79455850496,remaining_timing_output_required_bytes=73462044626,
 initial_root_required_bytes=24*G,runtime_root_floor_bytes=24*G,post_run_root_floor_bytes=8*G,
 original_envelope=capacity['retained_conservative_plan'],policy=policy,policy_sha256=policy_sha,
 scope='Historical whole-resident empirical envelope unchanged. Allocate output/restore envelope once on output device; root thresholds are independent requirements, not a second output charge. Shared device would use max, never sum. Fresh root release required; no reservation from this snapshot.'))
def funcs(s):return{n.name:ast.get_source_segment(s,n)for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
changes=[]
for n in names:
 before=raw(O/n).decode();after=raw(P/n).decode()
 write(P/'diffs'/(n+'.diff'),''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/n),tofile=str(P/n))))
 changed=[]
 if n.endswith('.py'):
  a,b=funcs(before),funcs(after);changed=[k for k in a if a[k]!=b[k]]
 changes.append(dict(original=pin(O/n),derived=pin(P/n),changed_functions=changed))
original_driver=funcs(raw(O/'matched-driver.py').decode());new_driver=funcs(texts['matched-driver.py'])
for n in ['native_trial','observe_client','fresh_drain','make_plan','verify_inputs','verify_client_cargo']:
 assert original_driver[n]==new_driver[n],n
for n in ['codec','single_frame','hash_original','tree_inventory','no_references','close_fixture']:
 assert funcs(raw(O/'compressed_retention.py').decode())[n]==funcs(texts['compressed_retention.py'])[n],n
for k in ['smoke_inventory','timed_inventory','expected_counts','configured_max_attempts','effective_server_limits']:
 assert p[k]==read(O/'protocol.json')[k],k
save(P/'substitutions.json',sub)
save(P/'source-delta.json',dict(complete=True,files=changes,original_inventory=pin(O/'inventory.json'),
 all_measured_trial_and_loop_bytes_unchanged=True,codec_and_original_hash_predicates_unchanged=True,
 root_guard_delta='Add root filesystem observations and independent 24/8 GiB root floors. Existing output/tmpfs floors, reservations, decoder/hash/lifetime/caps remain unchanged.',
 executable_requalification='One new 1b8060eb client, not 8da9 historical bytes; same source/protocol and actual Cargo attestations required.'))
print(json.dumps(dict(complete=True,driver_sha256=sha(P/'matched-driver.py'),audit_sha256=sha(P/'audit.py'),policy_sha256=policy_sha,prepared_runtime=False,observations=observations)))
