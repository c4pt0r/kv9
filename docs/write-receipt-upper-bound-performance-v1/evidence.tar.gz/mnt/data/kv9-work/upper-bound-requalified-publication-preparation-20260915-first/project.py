"""Exact finite member/tar size projection from accepted hash inventories; no codec."""
import argparse,hashlib,importlib.util,json,stat,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('publication_source',HERE/'package.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def main():
    a=argparse.ArgumentParser();a.add_argument('--execution-manifest',type=Path,required=True);a.add_argument('--execution-manifest-sha256',required=True);a.add_argument('--output',type=Path,required=True);args=a.parse_args()
    assert __debug__ and args.output.parent==HERE and not args.output.exists()
    rows={};metadata_read_bytes=0
    def add(path,pin=None):
        nonlocal metadata_read_bytes
        path=Path(path);s=path.lstat();assert stat.S_ISREG(s.st_mode)and s.st_size<=m.MEMBER_CAP
        if pin is None:
            b=path.read_bytes();metadata_read_bytes+=len(b);pin=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
        assert s.st_size==pin['bytes']
        name=str(path).lstrip('/');row=dict(member=name,source=str(path),bytes=pin['bytes'],sha256=pin['sha256'])
        assert name not in rows or rows[name]==row;rows[name]=row;return row
    def read(path,pin=None):
        nonlocal metadata_read_bytes
        path=Path(path);assert path.stat().st_size<=m.MEMBER_CAP;b=path.read_bytes();metadata_read_bytes+=len(b)
        actual=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
        if pin is not None:assert all(pin[k]==actual[k]for k in actual)
        add(path,actual);return json.loads(b)
    execution=read(args.execution_manifest);assert rows[str(args.execution_manifest).lstrip('/')]['sha256']==args.execution_manifest_sha256
    assert execution['complete']is True and execution['schema']==1 and execution['source_revision']==m.REV and execution['client_binary_sha256']==m.CLIENT_SHA
    assert set(execution['stage_terminals'])==m.STAGES and set(execution['audit_artifacts'])==m.ARTIFACTS and set(execution['report_outputs'])==m.REPORT_FILES
    for pin in execution['files']:assert Path(pin['path']).is_relative_to(m.EXEC);add(pin['path'],pin)
    terms={}
    for stage,pin in execution['stage_terminals'].items():terms[stage]=m.terminal_success(read(pin['path'],pin))
    for root,expected in [(m.PREP,'b5911e32c94289ae52a320d513aa3e81a8da320e635e876ba39031b491883e54'),(m.REPORT,'093c33024b41873fcd67e413e8eb704b4fd80255edba39bb53bcbd39094e92e6'),(HERE,None)]:
        inventory=read(root/'inventory.json')
        if expected:assert rows[str(root/'inventory.json').lstrip('/')]['sha256']==expected
        for rel,pin in inventory['files'].items():assert not Path(rel).is_absolute()and '..'not in Path(rel).parts;add(root/rel,pin)
    for name,pin in execution['audit_artifacts'].items():assert pin['path']==str(m.PREP/'results-first'/name);add(pin['path'],pin)
    audit_inputs=read(m.PREP/'results-first/input-inventory.json',execution['audit_artifacts']['input-inventory.json'])
    for name in ['after.json','before.json','invocation.json','isolation.json','kv9-chaos-ci-p0-20260908-control-plane-isolated.json','kv9-chaos-control-plane-isolated.json','kv9-minio-dev-isolated.json','summary.json']:
        path=m.TIMING/name;add(path,audit_inputs[str(path)])
    for root in [m.SMOKE,m.TIMING/'cohorts']:
        path=root/'matrix.json';add(path,audit_inputs[str(path)])
        for name in ['plan.json','host.json']:add(root/name)
    add(m.PREP/'readiness/role-bindings-first.json');add(m.PREP/'readiness/smoke-readback/result.json')
    roles=read(m.PREP/'readiness/role-inputs.json')
    for role in roles['roles'].values():add(role['manifest']['path'],role['manifest'])
    for name,pin in execution['report_outputs'].items():assert pin['path']==str(m.REPORT/'results-first'/name);add(pin['path'],pin)
    report_inputs=read(m.REPORT/'results-first/input-hashes.json',execution['report_outputs']['input-hashes.json'])
    for path,pin in report_inputs.items():add(path,pin)
    manifest=m.make_manifest(rows,terms,report_inputs,execution);blob=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    sizes={name:row['bytes']for name,row in rows.items()};sizes['members.json']=len(blob)
    for name,size in sizes.items():
        entry=tarfile.TarInfo(name);entry.size=size;entry.tobuf(format=tarfile.USTAR_FORMAT)
    total=sum(r['bytes']for r in rows.values());tar_bytes=((sum(512+((size+511)//512)*512 for size in sizes.values())+1024+10239)//10240)*10240
    assert len(rows)<512 and max(sizes.values())<=m.MEMBER_CAP and total<=m.TOTAL_CAP and tar_bytes<=m.DECODED_TAR_CAP
    result=dict(complete=True,metadata_projection_only=True,selected_original_files=len(rows),selected_original_bytes=total,largest_member_bytes=max(sizes.values()),members_json_bytes=len(blob),members_sha256=hashlib.sha256(blob).hexdigest(),exact_ustar_decoded_bytes=tar_bytes,selected_cap_bytes=m.TOTAL_CAP,selected_headroom_bytes=m.TOTAL_CAP-total,decoded_tar_cap_bytes=m.DECODED_TAR_CAP,decoded_tar_headroom_bytes=m.DECODED_TAR_CAP-tar_bytes,projected_old_64MiB_excess_bytes=total-64*1024**2,report_input_files=len(report_inputs),metadata_content_bytes_read=metadata_read_bytes,execution_manifest_path=str(args.execution_manifest),execution_manifest_sha256=args.execution_manifest_sha256,source_package_sha256=hashlib.sha256((HERE/'package.py').read_bytes()).hexdigest(),compressed_size_pending=True,scope='Exact sizes/member-manifest hash from existing accepted pins and lstat lengths. Raw reports/resources/WALs were not content-read. Real exporter must verify every selected original hash and match this member-manifest digest before gzip. No package or compression ran.')
    with args.output.open('x')as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
