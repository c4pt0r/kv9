#!/usr/bin/env python3
"""Finite completed-performance metadata exporter; no ELF/WAL/source-tree reads."""
import argparse,gzip,hashlib,io,json,os,re,stat,tarfile,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PREP=Path('/mnt/data/kv9-work/upper-bound-requalified-preparation-20260915-first')
REPORT=Path('/mnt/data/kv9-work/upper-bound-requalified-report-preparation-20260915-first')
EXEC=Path('/mnt/data/kv9-work/upper-bound-requalified-execution-20260915-first')
TIMING=Path('/mnt/data/kv9-work/upper-bound-requalified-timing-20260915-first')
SMOKE=Path('/mnt/data/kv9-work/upper-bound-requalified-smoke-20260915-first')
MEMBER_CAP=8*1024**2
TOTAL_CAP=64*1024**2
COMPRESSED_CAP=32*1024**2
DECODED_TAR_CAP=80*1024**2
REV='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
CLIENT_SHA='1b8060eb168610328c10a27480de16bd8b2d6805166d8169638f85ceef0992c4'
POLICY='kv9-upper-bound-requalified-client-data-volume-write-v1'
ARTIFACTS={'audit.json','input-inventory.json','retention-decoder-receipts.json','logical-original-inventory.json','combined-physical-retention.json'}
REPORT_FILES={'summary.json','input-hashes.json','README.md','PER-REPEAT.md','COMPARISONS.md'}
STAGES={'smoke','smoke_readback','timing','audit','report'}
SECRET=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
def ident(s):return(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
def terminal_success(d):
    if 'terminal'in d:
        assert type(d['session_id'])is int and d['session_id']>0
        t=d['terminal'];assert t['exit_code']==0 and type(t['chunk_id'])is str and t['chunk_id']
        return dict(session_id=d['session_id'],terminal_receipt=t['chunk_id'],exit_code=0)
    assert d['complete']is True and d['exit_code']==0 and type(d['terminal_receipt'])is str and d['terminal_receipt']
    assert d['session_id']is None or type(d['session_id'])is int and d['session_id']>0
    return {k:d[k]for k in ['session_id','terminal_receipt','exit_code']}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execution-manifest',type=Path,required=True);ap.add_argument('--execution-manifest-sha256',required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    assert __debug__ and set(os.sched_getaffinity(0))==set(range(6,16))|set(range(22,32))
    out=a.output.absolute();assert out.parent==HERE and not out.exists();out.mkdir()
    started=time.monotonic();contents={};rows={};result=dict(complete=False)
    def guard():
        v=os.statvfs(HERE);assert v.f_bavail*v.f_frsize>=8*1024**3 and time.monotonic()-started<=1200
    def add(path,expected=None):
        path=Path(path);assert path.is_absolute()and '..'not in path.parts
        assert path.suffix in ('.json','.py','.md','.diff','.log','.stdout','.stderr','.txt')
        assert not path.name.startswith('issue9')and path.name!='continuation.json'
        assert not any(n in path.parts for n in ['.git','target','retention-objects','credentials','.aws','.ssh'])
        name=str(path).lstrip('/')
        if name not in contents:
            guard();before=path.lstat();assert stat.S_ISREG(before.st_mode)and before.st_size<=MEMBER_CAP,('member cap',str(path),before.st_size,MEMBER_CAP)
            with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb')as f:
                assert ident(os.fstat(f.fileno()))==ident(before);data=f.read(MEMBER_CAP+1)
                assert len(data)==before.st_size and not f.read(1)and ident(os.fstat(f.fileno()))==ident(before)
            assert ident(path.lstat())==ident(before)
            assert not data.startswith((b'\x7fELF',b'\x1f\x8b',b'\x28\xb5\x2f\xfd'))and not SECRET.search(data),'non-metadata or secret pattern'
            contents[name]=data;rows[name]=dict(member=name,source=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
        if expected is not None:assert all(rows[name][k]==expected[k]for k in ['bytes','sha256']),str(path)
        total=sum(r['bytes']for r in rows.values());assert total<=TOTAL_CAP,('selected byte cap; explicit increase required',total,TOTAL_CAP,total-TOTAL_CAP)
        assert len(rows)<512,('original member count cap',len(rows))
        return json.loads(contents[name])if path.suffix=='.json'else None
    def add_pin(pin):return add(pin['path'],pin)
    try:
        assert a.execution_manifest.is_absolute()and a.execution_manifest.is_relative_to(EXEC)
        execution=add(a.execution_manifest)
        assert rows[str(a.execution_manifest).lstrip('/')]['sha256']==a.execution_manifest_sha256
        assert execution['schema']==1 and execution['complete']is True and execution['source_revision']==REV and execution['client_binary_sha256']==CLIENT_SHA
        assert set(execution['stage_terminals'])==STAGES and set(execution['audit_artifacts'])==ARTIFACTS and set(execution['report_outputs'])==REPORT_FILES
        assert len(execution['files'])<=128 and len({p['path']for p in execution['files']})==len(execution['files'])
        for pin in execution['files']:
            assert Path(pin['path']).is_relative_to(EXEC);add_pin(pin)
        terms={};term_docs={}
        for stage,pin in execution['stage_terminals'].items():
            assert Path(pin['path']).is_relative_to(EXEC);term_docs[stage]=add_pin(pin);terms[stage]=terminal_success(term_docs[stage])
        for root,digest in [(PREP,'b5911e32c94289ae52a320d513aa3e81a8da320e635e876ba39031b491883e54'),(REPORT,'093c33024b41873fcd67e413e8eb704b4fd80255edba39bb53bcbd39094e92e6')]:
            inventory=add(root/'inventory.json');assert rows[str(root/'inventory.json').lstrip('/')]['sha256']==digest
            for rel,pin in inventory['files'].items():
                assert not Path(rel).is_absolute()and '..'not in Path(rel).parts;add(root/rel,pin)
        # Exporter/checker source and original publisher lineage remain directly readable.
        own=add(HERE/'inventory.json')
        for rel,pin in own['files'].items():
            assert not Path(rel).is_absolute()and '..'not in Path(rel).parts;add(HERE/rel,pin)
        for name,pin in execution['audit_artifacts'].items():
            assert pin['path']==str(PREP/'results-first'/name);add_pin(pin)
        audit=add(PREP/'results-first/audit.json');audit_inputs=add(PREP/'results-first/input-inventory.json')
        assert audit['complete']is True and audit['matched_diagnostic_accepted']is True and audit['protocol_id']==POLICY
        assert audit['successful_arms']==audit['expected_successful_arms']==len(audit['cases'])==16 and audit['performance_promotion']is False
        assert audit['owned_lifetimes_exited']==64 and audit['qualifying_drains']==48 and audit['outer_restoration']['accepted']is True
        assert audit['parent_confirmed_session']==terms['timing']['session_id']and audit['parent_confirmed_exit_code']==0
        t=term_docs['audit']
        assert t['audit_path']==str(PREP/'results-first/audit.json')and t['audit_sha256']==execution['audit_artifacts']['audit.json']['sha256']
        assert t['input_inventory_path']==str(PREP/'results-first/input-inventory.json')and t['input_inventory_sha256']==execution['audit_artifacts']['input-inventory.json']['sha256']
        for name in ['after.json','before.json','invocation.json','isolation.json','kv9-chaos-ci-p0-20260908-control-plane-isolated.json','kv9-chaos-control-plane-isolated.json','kv9-minio-dev-isolated.json','summary.json']:
            path=TIMING/name;add(path,audit_inputs[str(path)])
        for root in [SMOKE,TIMING/'cohorts']:
            path=root/'matrix.json';matrix=add(path,audit_inputs[str(path)])
            assert matrix['complete']is True and matrix['protocol_id']==POLICY
            assert len(matrix['attempts'])==(8 if root==SMOKE else 16)and matrix['smoke']is(root==SMOKE)
            for name in ['plan.json','host.json']:add(root/name)
        add(PREP/'readiness/role-bindings-first.json');add(PREP/'readiness/smoke-readback/result.json')
        roles=add(PREP/'readiness/role-inputs.json')
        for role in roles['roles'].values():add_pin(role['manifest'])
        for name,pin in execution['report_outputs'].items():
            assert pin['path']==str(REPORT/'results-first'/name);add_pin(pin)
        report=add(REPORT/'results-first/summary.json');report_inputs=add(REPORT/'results-first/input-hashes.json')
        assert report['complete']is True and report['performance_promotion']is False and report['timed_cohorts']==16
        assert report['actual_timing_session']==terms['timing']['session_id']and report['audit_sha256']==execution['audit_artifacts']['audit.json']['sha256']
        assert report['source_roles']['client']['binary_sha256']==CLIENT_SHA
        rt=term_docs['report'];assert rt['result_path']==str(REPORT/'results-first/summary.json')and rt['result_sha256']==execution['report_outputs']['summary.json']['sha256']
        reports=[path for path in report_inputs if path.endswith('/run/report.json')]
        assert len(reports)==16 and all(Path(path).is_relative_to(TIMING/'cohorts')for path in reports)
        for path,pin in report_inputs.items():add(path,pin)
        manifest=dict(scope='Exact report/acceptance metadata only. Raw/compressed WAL objects, ELFs and full source trees are excluded. This is not standalone complete WAL replay. Original absolute paths are historical provenance.',
            source_revision=REV,client_binary_sha256=CLIENT_SHA,original_files=len(rows),original_bytes=sum(r['bytes']for r in rows.values()),member_cap_bytes=MEMBER_CAP,total_cap_bytes=TOTAL_CAP,
            compressed_cap_bytes=COMPRESSED_CAP,decoded_tar_cap_bytes=DECODED_TAR_CAP,report_inputs_included=len(report_inputs),actual_stage_terminals=terms,
            audit_sha256=execution['audit_artifacts']['audit.json']['sha256'],report_sha256=execution['report_outputs']['summary.json']['sha256'],members=[rows[n]for n in sorted(rows)])
        blob=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();assert len(blob)<=MEMBER_CAP
        # Manifest itself is included; original count/byte caps retain their original meaning.
        contents['members.json']=blob
        for name,data in contents.items():
            entry=tarfile.TarInfo(name);entry.size=len(data);entry.tobuf(format=tarfile.USTAR_FORMAT)
        planned_tar_bytes=((sum(512+((len(data)+511)//512)*512 for data in contents.values())+1024+10239)//10240)*10240
        assert planned_tar_bytes<=DECODED_TAR_CAP,('decoded tar cap; explicit increase required',planned_tar_bytes,DECODED_TAR_CAP,planned_tar_bytes-DECODED_TAR_CAP)
        with(out/'members.json').open('xb')as f:f.write(blob)
        class BoundedWriter:
            def __init__(self,f):self.f=f;self.bytes=0;self.digest=hashlib.sha256()
            def write(self,b):
                self.bytes+=len(b);assert self.bytes<=COMPRESSED_CAP,'compressed cap; explicit increase required'
                guard();self.digest.update(b);return self.f.write(b)
            def flush(self):self.f.flush()
        with(out/'evidence.tar.gz').open('xb')as raw:
            target=BoundedWriter(raw)
            with gzip.GzipFile(filename='',mode='wb',fileobj=target,compresslevel=6,mtime=0)as gz:
                with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT)as tf:
                    for name,data in sorted(contents.items()):
                        entry=tarfile.TarInfo(name);entry.size,entry.mode,entry.mtime=len(data),0o644,0;tf.addfile(entry,io.BytesIO(data))
            raw.flush();os.fsync(raw.fileno())
        for name in ['verify.py','README.md']:
            with(out/name).open('xb')as f:f.write((HERE/name).read_bytes())
        result.update(complete=True,planned_decoded_tar_bytes=planned_tar_bytes,original_files=len(rows),original_bytes=manifest['original_bytes'],archive_members=len(contents),report_inputs_included=len(report_inputs),archive_bytes=target.bytes,archive_sha256=target.digest.hexdigest(),members_sha256=hashlib.sha256(blob).hexdigest())
    except BaseException as e:result['failure']=repr(e);raise
    finally:
        result['elapsed_seconds']=time.monotonic()-started
        with(out/'package-result.json').open('x')as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
