#!/usr/bin/env python3
"""Publish a bounded, read-back-verified packet for the completed screen."""
import gzip
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

ROOT = Path('/mnt/data/kv9-work/isolated-outline-performance-20260916-first')
REPO = Path('/home/dongxu/kv9')
OUT = REPO / 'docs/isolated-outline-performance-v1'
OUT.mkdir(exist_ok=False)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

analysis = json.loads((ROOT / 'analysis.json').read_text())
allocation = json.loads((ROOT / 'allocation-analysis.json').read_text())
assert analysis['complete'] and analysis['processes'] == 136
assert analysis['timing_rows'] == 152 and analysis['counting_rows'] == 76
assert not analysis['component_gate_passed'] and not analysis['production_promoted']
assert allocation['complete'] and allocation['accepted']
assert len(list((ROOT / 'runs').glob('*-terminal.json'))) == 136

top = [
    'declared-plan.json', 'plan.json', 'plan-clarification.json',
    'harness-correspondence.json', 'harness-metadata.json', 'harness-metadata.stderr',
    'build-summary.json', 'prepare-summary.json', 'inputs-accepted.json',
    'counting-summary.json', 'allocation-analysis.json', 'timing-summary.json',
    'analysis.json', 'next-inline-key-plan.json', 'reference-inputs.py', 'package.py',
]
members = {f'experiment/{name}': ROOT / name for name in top}
for directory in ('runs', 'tools', 'source-counting-baseline', 'source-counting-candidate',
                  'build-counting-baseline', 'build-counting-candidate'):
    for path in sorted((ROOT / directory).rglob('*')):
        if path.is_file() and path.name != 'counting' and '__pycache__' not in path.parts:
            members['experiment/' + str(path.relative_to(ROOT))] = path
for directory in ('scripts/engine-interface-counting', 'scripts/isolated-outline-performance'):
    for path in sorted((REPO / directory).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            members['repo/' + str(path.relative_to(REPO))] = path
assert all(path.is_file() and not path.is_symlink() for path in members.values())

records = []
archive = OUT / 'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, path in sorted(members.items()):
                data = path.read_bytes()
                assert not data.startswith(b'\x7fELF'), name
                info = tar.gettarinfo(str(path), arcname=name)
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with path.open('rb') as source:
                    tar.addfile(info, source)
                records.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(archive, 'r:gz') as tar:
    assert tar.getnames() == [record['path'] for record in records]
    for record in records:
        data = tar.extractfile(record['path']).read()
        assert len(data) == record['bytes'] and sha(data) == record['sha256']
save(OUT / 'members.json', records)
build = json.loads((ROOT / 'build-summary.json').read_text())
manifest = {
    'complete': True, 'members': len(records),
    'expanded_bytes': sum(record['bytes'] for record in records),
    'compressed_bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
    'all_members_read_back': True, 'local_root': str(ROOT),
    'processes': 136, 'timing_rows': 152, 'allocation_rows': 76,
    'correctness_and_allocation_accepted': True, 'component_gate_passed': False,
    'production_promoted': False,
    'excluded': ['Executable binaries (retained locally and hashed)', 'Duplicate groups.bin',
                 'GitHub payloads, mutable progress/continuation and Python caches'],
    'external': {
        'corpus': '../outlined-mutation-path-v1/evidence.tar.gz:outlined/groups.bin',
        'corpus_sha256': sha((ROOT / 'groups.bin').read_bytes()),
        'qualification': '../isolated-outline-v1/evidence.tar.gz',
        'qualification_sha256': 'f449e30cb7dd14299e358eba94679e40c418dfc71d332a511bdbe0f4278427a3',
        'qualification_scope': 'Original/candidate dependency and timing-harness sources, build identities, conditional proof and correctness evidence',
    },
    'binaries': {arm: {kind: value[kind] for kind in ('timing', 'counting')}
                 for arm, value in build['arms'].items()},
}
save(OUT / 'manifest.json', manifest)
for name in ('declared-plan.json', 'plan.json', 'analysis.json', 'allocation-analysis.json',
             'next-inline-key-plan.json'):
    shutil.copyfile(ROOT / name, OUT / name)
(OUT / 'README.md').write_text(f'''# Isolated shared-clone performance evidence

See the [report](../ISOLATED-OUTLINE-PERFORMANCE.md). Correctness and allocator
accounting pass; the material-write and read gates fail. Production is unchanged.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['sha256']}`.
Every member size/hash passed readback; [members.json](members.json) and
[manifest.json](manifest.json) record the retained bytes and exclusions.

The packet retains all 136 process launch/terminal records and outputs, all
152 timing / 76 allocation rows and raw samples, independent input/statistics/
allocation analyses, source correspondence, counting builds, cache checks and
Clippy logs. Timing reuses the exact qualified uninstrumented release pair.
Counted processes emit no latency measurement. Snapshot, owned/resident,
first-probe/warm and per-call/512-query-pass scopes remain separate.

Dependency sources, timing-harness build inputs and prior conditional proof/test
qualification are in the [qualification packet](../isolated-outline-v1/README.md).
The original corpus is already published as `outlined/groups.bin` in the
[outlined packet](../outlined-mutation-path-v1/README.md). Exact hashes and local
executable identities are in the manifest. Binaries remain local. Reproduction
uses recorded absolute paths; restore those inputs or adapt a fresh experiment
without relabeling an existing result.

The [declared plan](declared-plan.json) and [executed plan](plan.json) retain the
same cases, binary identities, counts, windows and gates; the pre-execution
clarification is included in the archive. The [next inline-key plan](next-inline-key-plan.json)
is prospective, not implemented or measured. No database/Redis QPS, ordinary
recovery, actual Chaos acceptance or industrial checkbox closure is claimed.
''')
print(json.dumps(manifest, indent=2))
