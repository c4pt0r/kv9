#!/usr/bin/env python3
"""Preserve the actual development/proof inputs; never rerun a workload."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path('/home/dongxu/kv9')
BASE = Path('/mnt/data/kv9-work')
PUB = BASE / 'ledger-publication-20260915-first'
DEST = ROOT / 'docs/retention-ledger-v1'
DEST.mkdir(exist_ok=True)
ARCHIVE = DEST / 'development.tar.gz'
assert not ARCHIVE.exists()
entries = {}
excluded = []


def digest(b):
    return hashlib.sha256(b).hexdigest()


def add(path, member):
    assert path.is_file() and not path.is_symlink(), path
    assert member not in entries, member
    entries[member] = path


old = ['development-first', 'model-development-first', 'proof-preparation-first',
       'proof-preparation-second', 'proof-preparation-third',
       'runtime-development-first', 'runtime-development-second',
       'runtime-development-third', 'runtime-development-fourth']
roots = [Path('/tmp') / ('kv9-c04-ledger-' + x.rsplit('-', 1)[0] + '-20260915-' + x.rsplit('-', 1)[1])
         for x in old]
names = ['runtime-development-20260915-fifth', 'development-acceptance-20260915-first',
         'remaining-libraries-20260915-first', 'runtime-build-20260915-first',
         'runtime-inputs-20260915-first', 'proof-inventory-20260915-first',
         'proof-inventory-20260915-second', 'protocol-20260915-first',
         'protocol-20260915-second', 'protocol-launch-20260915-first',
         'protocol-launch-20260915-second', 'composition-launch-20260915-first',
         'composition-retention-20260915-first', 'composition-anchor-20260915-first',
         'composition-base-20260915-first', 'composition-publication-20260915-first',
         'source-artifacts-20260915-first', 'source-controls-20260915-first',
         'source-controls-launch-20260915-first', 'chaos-preflight-20260915-first']
roots += [BASE / ('ledger-' + n) for n in names]
for directory in roots:
    assert directory.is_dir(), directory
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(directory)
        with path.open('rb') as f:
            magic = f.read(4)
        reason = None
        if magic == b'\x7fELF':
            reason = 'Executable retained locally; digest only.'
        elif path.suffix in ('.class', '.fp', '.st') or path.name == 'fingerprints':
            reason = 'Generated proof cache/state, not a validation input.'
        if reason:
            excluded.append({'path': str(path), 'bytes': path.stat().st_size,
                             'sha256': digest(path.read_bytes()), 'reason': reason})
        else:
            add(path, 'runs/' + directory.name + '/' + str(relative))

inputs = json.loads((BASE / 'ledger-runtime-inputs-20260915-first/inputs.json').read_text())
for name, expected in inputs['source_pins'].items():
    path = ROOT / name
    assert digest(path.read_bytes()) == expected, name
    add(path, 'tested-source/' + name)
binary = BASE / 'ledger-runtime-inputs-20260915-first/kv9'
assert digest(binary.read_bytes()) == inputs['binary_sha256']
assert binary.stat().st_size == inputs['binary_bytes']
for pattern in ('proofs/tla/retention_ledger/*', 'proofs/tlaps/retention_ledger/*'):
    for path in sorted(ROOT.glob(pattern)):
        if path.is_file():
            add(path, 'tested-proof/' + str(path.relative_to(ROOT)))
for name in ('check-retention-ledger.py', 'check-retention-ledger-source-controls.py',
             'retention-ledger-chaos.py', 'checkpoint-publication-chaos.py',
             'test-checkpoint-publication-chaos-guard.py'):
    add(ROOT / 'scripts' / name, 'tested-runners/' + name)
for name, filename in [('proof-tools-20260915-first', 'installation.json'),
                       ('chaos-tools-20260915-first', 'restoration.json')]:
    add(BASE / name / filename, 'tools/' + name + '/' + filename)

note = {
    'status': 'preserved', 'roots': [str(p) for p in roots],
    'empty_run': 'ledger-proof-inventory-20260915-first: initial javac invocation failed because the old /tmp jar disappeared; no audit log was emitted.',
    'original_failures': ['Initial fake gRPC services lacked two new methods.',
                          'First planner test harness reacquired the catalog lock and required a scoped stop.',
                          'Second planner harness retained the same inappropriate wait helper.',
                          'First two proof drafts left actual obligations unproved.',
                          'First complete protocol reached an incomplete-state error in the stale-token mutation, not an accepted counterexample.',
                          'Full library attempt had six old runtime timeouts/election failures on data-volume TMPDIR.',
                          'Combined Chaos preflight had a local permission error after the ten guard controls had passed.'],
    'separate_packet': 'Environment diagnosis and actual Chaos payload/history audit are packaged by the runtime acceptance worker.',
    'excluded': excluded,
    'source_pins_checked': len(inputs['source_pins']),
    'no_workload_replayed': True,
}
(PUB / 'development-selection.json').write_text(json.dumps(note, indent=2) + '\n')
add(PUB / 'development-selection.json', 'selection.json')
add(Path(__file__), 'pack-development.py')
inventory = []
with tarfile.open(ARCHIVE, 'w:gz', compresslevel=9) as tar:
    for member, path in sorted(entries.items()):
        content = path.read_bytes()
        info = tarfile.TarInfo(member)
        info.size, info.mode, info.mtime = len(content), 0o644, 0
        tar.addfile(info, io.BytesIO(content))
        inventory.append({'member': member, 'original': str(path),
                          'bytes': len(content), 'sha256': digest(content)})
(DEST / 'development-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    assert tar.getnames() == [r['member'] for r in inventory]
    for record in inventory:
        data = tar.extractfile(record['member']).read()
        assert data == Path(record['original']).read_bytes(), record['member']
        assert len(data) == record['bytes'] and digest(data) == record['sha256']
summary = {'status': 'PASS', 'archive_sha256': digest(ARCHIVE.read_bytes()),
           'archive_bytes': ARCHIVE.stat().st_size, 'members': len(inventory),
           'decoded_bytes': sum(r['bytes'] for r in inventory),
           'inventory_sha256': digest((DEST / 'development-inventory.json').read_bytes()),
           'all_members_equal_original': True, 'frozen_source_pins_checked': len(inputs['source_pins']),
           'executable_bytes_excluded': True}
(DEST / 'development-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
