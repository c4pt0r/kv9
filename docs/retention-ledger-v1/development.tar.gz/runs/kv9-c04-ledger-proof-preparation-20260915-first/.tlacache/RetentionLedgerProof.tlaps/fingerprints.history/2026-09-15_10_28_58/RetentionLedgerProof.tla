------------------------ MODULE RetentionLedgerProof ------------------------
EXTENDS RetentionLedger, TLAPS
THEOREM LInvariantInit == LInit => LInvariant
BY LInputs, SMT DEF LInit, LInvariant, LType, LRecords, LAbsent, LExactLinks,
                   LShapes, LPublicationCovered
THEOREM LInvariantStep == ASSUME LInvariant, [LNext]_lVars PROVE LInvariant'
<1>1. ASSUME NEW o \in LOwners, NEW g \in 1..LMaxGeneration, LAcquire(o,g)
       PROVE LInvariant'
    BY LInputs, SMT DEF LAcquire, LSet, LPinsAfter, LRecord, LInvariant,
        LType, LRecords, LAbsent, LExactLinks, LShapes, LPublicationCovered
<1>2. ASSUME NEW o \in LOwners, NEW g \in 1..LMaxGeneration, LPublish(o,g)
       PROVE LInvariant'
    BY LInputs, SMT DEF LPublish, LSet, LPinsAfter, LRecord, LInvariant,
        LType, LRecords, LAbsent, LExactLinks, LShapes, LPublicationCovered
<1>3. ASSUME NEW o \in LOwners, NEW g \in 1..LMaxGeneration, LRelease(o,g)
       PROVE LInvariant'
    BY LInputs, SMT DEF LRelease, LSet, LPinsAfter, LRecord, LInvariant,
        LType, LRecords, LAbsent, LExactLinks, LShapes, LPublicationCovered
<1>4. ASSUME NEW from \in LOwners, NEW to \in LOwners,
              NEW g \in 1..LMaxGeneration, LShare(from,to,g)
       PROVE LInvariant'
    BY <1>1 DEF LShare
<1>5. ASSUME NEW from \in LOwners, NEW to \in LOwners,
              NEW g \in 1..LMaxGeneration, LQuiesce(from,to,g)
       PROVE LInvariant'
    BY LInputs, SMT DEF LQuiesce, LSet, LPinsAfter, LRecord, LInvariant,
        LType, LRecords, LAbsent, LExactLinks, LShapes, LPublicationCovered
<1>6. UNCHANGED lVars => LInvariant'
    BY DEF lVars, LInvariant, LType, LExactLinks, LShapes, LPublicationCovered
<1> QED BY <1>1, <1>2, <1>3, <1>4, <1>5, <1>6, SMT DEF LNext
THEOREM LInvariantAlways == LSpec => []LInvariant
BY LInvariantInit, LInvariantStep, PTL DEF LSpec
THEOREM LAtomicClosure == LInvariant => LExactLinks
BY DEF LInvariant
THEOREM LSuccessorCoverage == LInvariant => LPublicationCovered
BY DEF LInvariant
THEOREM LStaleTokenNeverApplied == LInvariant => ~lStale
BY DEF LInvariant
THEOREM LShareKeepsSource ==
    ASSUME NEW from \in LOwners, NEW to \in LOwners,
           NEW g \in 1..LMaxGeneration, LShare(from,to,g)
    PROVE lOwners'[from] = lOwners[from]
BY LInputs, SMT DEF LShare, LAcquire, LSet
=============================================================================
