"""Exact opt-in build graph; default/native fixture validators remain unchanged."""
import json
from pathlib import Path

from contract import require

SERVER_COMMAND = ['cargo', 'build', '--locked', '--bin', 'kv9', '--release',
                  '--features', 'kv9-raft/read-stage-timing',
                  '--message-format=json-render-diagnostics']
FEATURES = {'kv9': [], 'kv9_engine': [], 'kv9_raft': ['read-stage-timing'], 'kv9_server': []}


def validate_records(records, source):
    require(records and records[-1].get('reason') == 'build-finished' and
            records[-1].get('success') is True and
            sum(r.get('reason') == 'build-finished' for r in records) == 1,
            'diagnostic Cargo completion differs')
    selected = {}
    for name, features in FEATURES.items():
        rows = [r for r in records if r.get('reason') == 'compiler-artifact' and
                r.get('target', {}).get('name') == name]
        require(len(rows) == 1, 'ambiguous diagnostic artifact: ' + name)
        row = rows[0]
        require(row['features'] == features and row['profile']['opt_level'] == '3' and
                row['profile']['test'] is False, 'diagnostic artifact features/profile differ: ' + name)
        require(Path(row['target']['src_path']).is_relative_to(Path(source)) and
                (row['package_id'].startswith('path+file://' + str(source) + '/') or
                 row['package_id'].startswith('path+file://' + str(source) + '#')),
                'diagnostic artifact source differs: ' + name)
        selected[name] = row
    require(selected['kv9']['target']['kind'] == ['bin'] and selected['kv9']['executable'],
            'diagnostic server artifact is not executable')
    return selected


def cargo_server(path, source):
    return validate_records([json.loads(line) for line in path.read_text().splitlines()], source)
