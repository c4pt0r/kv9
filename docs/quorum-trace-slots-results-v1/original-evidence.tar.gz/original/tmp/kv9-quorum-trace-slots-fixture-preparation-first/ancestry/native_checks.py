"""Source-preserving native checks extracted from the accepted v3 auditor."""
import hashlib, stat
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from contract import check_config
STORAGE_GUARDS = {"preflight":{"tmpfs":32*1024**3,"retention":96*1024**3},"runtime":{"tmpfs":16*1024**3,"retention":64*1024**3}}
ZERO = ('public_rpc_in_flight', 'public_rpc_queued', 'public_rpc_running', 'public_rpc_encoded_bytes', 'raft_async_apply_queued', 'raft_async_apply_in_flight', 'raft_async_read_queued', 'raft_async_read_active', 'raft_async_read_in_flight', 'raft_async_read_active_groups')

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def histogram(populations):
    buckets = [0] * 3776
    count = total = 0
    for p in populations:
        raw = p['whole_call']['raw']
        count += raw['count']; total += raw['sum_ns']
        for i, n in enumerate(raw['buckets']):
            buckets[i] += n
    require(sum(buckets) == count, 'merged histogram count differs')
    def quantile(percent):
        if count==0:
            return None
        rank = (count * percent + 99) // 100
        seen = 0
        for i, n in enumerate(buckets):
            seen += n
            if seen >= rank:
                if i < 64:
                    return dict(lower_ns=i, upper_ns=i)
                shift = (i - 64) // 64
                lower = (64 + (i - 64) % 64) << shift
                return dict(lower_ns=lower, upper_ns=lower + (1 << shift) - 1)
        raise ValueError('missing quantile rank')
    return dict(count=count, sum_ns=total, mean_ns=total / count if count else None,
                **{f'p{p}': quantile(p) for p in (50, 95, 99)})

def mix(n):
    n = (n + 0x9e3779b97f4a7c15) % 2**64
    n = ((n ^ (n >> 30)) * 0xbf58476d1ce4e5b9) % 2**64
    n = ((n ^ (n >> 27)) * 0x94d049bb133111eb) % 2**64
    return n ^ (n >> 31)

def value(seed, size, index, nonce):
    result = index.to_bytes(8, 'big') + nonce.to_bytes(8, 'big')
    for word in range((size - 16 + 7) // 8):
        result += mix(seed ^ mix(index) ^ mix(nonce) ^ word).to_bytes(8, 'big')
    return result[:size]

def dataset_check(config, dataset):
    require(len(dataset) == config['keys'] + 1, 'final dataset cardinality differs')
    changed=0
    for index in range(config['keys'] + 1):
        actual = dataset[f'{config["run_id"]}:{index:016x}'.encode()]
        require(actual is not None and len(actual) == config['value_bytes'], 'final value length/missing differs')
        nonce = int.from_bytes(actual[8:16], 'big')
        require(nonce <= config['warmup_calls'] + config['max_calls'] and actual == value(config['seed'], config['value_bytes'], index, nonce), 'independent value body differs')
        require(index != config['keys'] or nonce == 0, 'sentinel changed')
        if nonce:
            require(mix(config['seed'] ^ nonce) % 100 >= config['read_percent'], 'final nonce selected a read')
            first=mix(config['seed'] ^ nonce ^ 0xc6275c213842315b) % config['keys']
            require((index-first) % config['keys'] < config['batch_size'], 'final write nonce/key membership differs')
            changed+=1
    return dict(keys=len(dataset),changed_keys=changed,all_nonce_zero=changed==0,sentinel_unchanged=True,
                deterministic_values_valid=True,deterministic_write_key_membership_checked=True,
                maximum_configured_nonce=config['warmup_calls']+config['max_calls'],
                exact_issued_nonce_set_checked=False,full_history_checked=False)

def validate_phase_apis(report, config, is_native):
    require(report['version']==config['version']==3 and report['workload_model']==
            ('bounded_native_api_performance' if is_native else 'bounded_redis_api_performance'),
            'genuine v3 workload identity differs')
    for phase in ('initialization','warmup','measurement','verification'):
        metrics=report['metrics'][phase]
        traffic=phase in ('warmup','measurement')
        expected=([config['read_api'].removeprefix('point_'),config['write_api'].removeprefix('point_')]
                  if traffic else ['batch_get','batch_put'] if is_native else ['mget','mset'])
        require(metrics['operations']==expected,'selected phase API vocabulary differs')
        calls=[sum(p['calls'] for p in op['populations']) for op in metrics['statistics']]
        if phase=='warmup':
            reads=sum(mix(config['seed'] ^ nonce)%100<config['read_percent']
                      for nonce in range(1,config['warmup_calls']+1))
            require(calls==[reads,config['warmup_calls']-reads],'warmup deterministic operation mix differs')
        elif phase=='measurement':
            require(sum(calls)==report['measured_issued']>0,'measurement population differs')
            if config['read_percent'] in (0,100):
                require(calls[0 if config['read_percent']==0 else 1]==0,'pure measurement mix differs')
            else:
                require(all(calls),'mixed measurement omitted an operation')

def operation_statistics(metrics, elapsed_ns, is_native):
    rows=[]
    for name,op in zip(metrics['operations'],metrics['statistics']):
        populations=op['populations'];calls=sum(p['calls'] for p in populations)
        items=sum(p['input_items'] for p in populations)
        attempts=sum(op['attempt_reasons']) if is_native else op['command_attempts']
        rows.append(dict(operation=name,calls=calls,input_items=items,
            completed_calls_per_second=calls*1e9/elapsed_ns,completed_input_items_per_second=items*1e9/elapsed_ns,
            successful_calls_per_second=populations[0]['calls']*1e9/elapsed_ns,
            successful_input_items_per_second=populations[0]['input_items']*1e9/elapsed_ns,
            attempts=attempts,outcomes={outcome:p['calls'] for outcome,p in zip(metrics['outcomes'],populations)},
            reasons={reason:n for reason,n in zip(metrics['reasons'],op['reasons'])},
            attempt_reasons={reason:n for reason,n in zip(metrics['reasons'],op['attempt_reasons'])} if is_native else None,
            terminal_rpc_codes=op['rpc_codes'] if is_native else None,
            connection_attempts=None if is_native else op['connection_attempts'],
            connection_failures=None if is_native else op['connection_failures'],
            populations=[dict(outcome=outcome,calls=p['calls'],input_items=p['input_items'],
                completed_before_cutoff=p['completed_before_cutoff'],whole_call_latency=histogram([p]))
                for outcome,p in zip(metrics['outcomes'],populations)],
            whole_call_latency=histogram(populations),successful_whole_call_latency=histogram([populations[0]])))
    return rows

def validate_storage(observation, directory, phase, devices=None):
    require(type(observation['started_unix_ns']) is int and type(observation['completed_unix_ns']) is int and
            0<observation['started_unix_ns']<=observation['completed_unix_ns'], 'invalid storage observation interval')
    require(set(observation['filesystems'])=={'tmpfs','retention'}, 'storage filesystem inventory differs')
    result={}
    for name,path in (('tmpfs','/dev/shm'),('retention',str(directory))):
        row=observation['filesystems'][name]
        require(set(row)=={'path','device','fragment_bytes','blocks','free_blocks','available_blocks','available_bytes'} and
                row['path']==path and all(type(row[k]) is int for k in row if k!='path'), 'storage record schema differs')
        require(row['device']>0 and row['fragment_bytes']>0 and
                0<=row['available_blocks']<=row['free_blocks']<=row['blocks'] and
                row['available_bytes']==row['available_blocks']*row['fragment_bytes'], 'invalid statvfs arithmetic')
        require(row['available_bytes']>=STORAGE_GUARDS[phase][name], 'storage guard intervened')
        if devices is not None:
            require(row['device']==devices[name], 'storage device identity changed')
        result[name]=row['device']
    return result

def qualify(s):
    return s['bootstrap_state'] == 'Serving' and s['fatal'] == '' and all(s[k] == '0' for k in ZERO) and s['raft_async_apply_stopped'] == s['raft_async_read_stopped'] == 'false' and s['applied_term'] == s['driver_applied_term'] and s['applied_index'] == s['driver_applied_index']

def retention_file(job):
    path, entry = job
    require(path.is_file() and not path.is_symlink() and path.stat().st_size == entry['bytes'], 'retained file identity/size differs: ' + str(path))
    require(sha(path) == entry['sha256'], 'retained data hash differs: ' + str(path))
    return str(path), entry

def check_native(d, attempt, desc, roles, read, records, native, lifetimes):
    server=desc["server_role"]; is_native=True
    PINS={k:(v["revision"],v["binary_sha256"])for k,v in roles.items()}
    matrix={"role_bindings":roles}
    resource_count=writer_bindings=drains=retained_files=retained_bytes=0
    summary=read(d/'summary.json');cleanup=read(d/'cleanup.json')
    require(not cleanup.get('errors') and not summary.get('cleanup_errors') and not summary.get('cleanup_failure'),
            'owned cleanup failed')
    identities={}
    for child in cleanup['children']:
        identity=child['identity'];pid=identity['pid']
        require(child['exit_code'] is not None and child.get('absent',child.get('pid_absent_after_reap')) and
                not Path('/proc',str(pid)).exists(),'owned lifetime remains')
        life=(pid,identity['start_ticks'],identity['boot_id']);require(life not in lifetimes,'duplicate owned lifetime');lifetimes.add(life)
        identities[pid]=identity
    require(attempt['complete'] and summary['complete'], 'expected successful arm incomplete')
    c=read(d/'requested-config.json');r=read(d/'run/report.json')
    check_config(desc,c,r,sha(d/'requested-config.json'))
    require(sha(d/'run/report.json')==attempt['report_sha256']==summary['report_sha256'],'original report changed')
    role='client' if is_native else 'redis';build=Path(matrix['role_bindings'][role]['build_directory'])
    validated=(native if is_native else redis).validate(d/'run',build,d/'requested-config.json',PINS[role][0],require_timing=False)
    require(validated['accepted'] and r['stop_reason']=='duration' and r['dropped_slots']==0,'report incomplete/capped')
    validate_phase_apis(r,c,is_native)
    require(read(d/'client-exit.json')['exit_code']==0,'actual client terminal status differs')
    for child in cleanup['children']:
        is_client=child['identity']['pid']==r['process_id']
        require(child['exit_code']==(0 if is_client or not is_native else -9),'owned exit status differs')
    client_pid=r['process_id'];require(client_pid in identities and len(identities)==(4 if is_native else 2),'owned client/backend set differs')
    for pid,identity in identities.items():
        mask=[0,1] if pid==client_pid else [2,3,4,5]
        require(identity.get('cpu_affinity',identity.get('affinity'))==mask,'owned startup mask differs')
        if is_native:
            expected_sha=PINS['client' if pid==client_pid else server][1]
            require(identity['executable_sha256']==expected_sha,'executing native role differs')
        else:
            expected_path=matrix['role_bindings']['redis']['binary'] if pid==client_pid else '/usr/bin/redis-server'
            require(identity['command_line'][0]==expected_path,'Redis original argv-zero identity differs')
            require(sha(identity['executable'])==(PINS['redis'][1] if pid==client_pid else matrix['redis_server_sha256']),
                    'Redis executable bytes differ')
    samples=read(d/'resource-samples.json');coverage=read(d/'resource-coverage.json')
    begin=r['measurement_start_unix_ns'];end=begin+r['cohort_elapsed_ns']
    inside=[sample for sample in samples if begin<=sample['unix_ns']<=end]
    require(len(inside)==coverage['samples']>=10 and inside[0]['unix_ns']-begin==coverage['first_gap_ns']<=150_000_000 and
            end-inside[-1]['unix_ns']==coverage['last_gap_ns']<=150_000_000,'diagnostic resource coverage differs')
    for sample in inside:
        require({x['pid']for x in sample['processes'].values()}==set(identities),'sample owned process set differs')
        for name,item in sample['processes'].items():
            require(item['start_ticks']==identities[item['pid']]['start_ticks'],'sample lifetime differs')
            mask=[0,1] if name=='client' else [2,3,4,5];placement=item['thread_placement']
            require(item['cpu_affinity']==placement['process']==placement['expected']==mask and placement['threads'] and
                    all(m==mask for m in placement['threads'].values()),'sample thread placement differs')
    resource_count+=len(inside)
    memory = {}
    for name in inside[0]['processes']:
        if name=='client': continue
        observations=[sample['processes'][name] for sample in inside]
        require(all(type(x[k])is int and x[k]>0 for x in observations for k in ('rss_bytes','peak_rss_bytes')),
                'missing/invalid sampled RSS/HWM')
        memory[name]=dict(pid=observations[0]['pid'], start_ticks=observations[0]['start_ticks'],
            samples=len(observations), rss_first_bytes=observations[0]['rss_bytes'],
            rss_last_bytes=observations[-1]['rss_bytes'], rss_min_bytes=min(x['rss_bytes']for x in observations),
            rss_max_bytes=max(x['rss_bytes']for x in observations),
            rss_mean_bytes=sum(x['rss_bytes']for x in observations)/len(observations),
            hwm_first_bytes=observations[0]['peak_rss_bytes'], hwm_last_bytes=observations[-1]['peak_rss_bytes'],
            hwm_max_bytes=max(x['peak_rss_bytes']for x in observations),
            scope='Sampled RSS during measurement; HWM is process-lifetime high water including setup, not interval-only peak')
    host=read(d/'host-resource-samples.json');require(host and all('proc_stat'in x and 'background'in x for x in host),'host observations absent')
    preflight=read(d/'storage-preflight.json')
    devices=validate_storage(preflight,d,'preflight')
    require(preflight['completed_unix_ns']<begin and not (d/'storage-guard-intervention.json').exists(),
            'storage preflight overlaps measurement or a guard intervened')
    storage=read(d/'storage-resource-samples.json')
    callbacks=[row for row in read(d/'sample-calls.json') if row['pid']==client_pid]
    require(storage and len(storage)==len(callbacks), 'storage observation missing from client callback')
    storage_by_callback={}
    for i,(observation,callback) in enumerate(zip(storage,callbacks)):
        validate_storage(observation,d,'runtime',devices)
        require(callback['observed_unix_ns']<=observation['started_unix_ns']<=observation['completed_unix_ns']<=
                read(d/'client-exit.json')['observed_unix_ns'], 'storage callback interval differs')
        if i+1<len(callbacks):
            require(observation['completed_unix_ns']<=callbacks[i+1]['observed_unix_ns'], 'storage callbacks reordered')
        key=(callback['pid'],callback['observed_monotonic_ns'])
        require(key not in storage_by_callback,'duplicate client storage observation')
        storage_by_callback[key]=observation
    require(all((sample['processes']['client']['pid'],sample['processes']['client']['observed_monotonic_ns'])
                in storage_by_callback for sample in inside),'measured client callback lacks storage observation')
    storage_summary=dict(observations=len(storage),measured_callbacks=len(inside),devices=devices,
        minimum_available_bytes={name:min(row['filesystems'][name]['available_bytes'] for row in storage)
                                 for name in ('tmpfs','retention')},
        scope='Observed free-space operational guards; call caps and smoke growth do not prove a worst-case storage bound')
    if is_native:
        # Bind the already captured endpoint envelopes for a separate
        # downstream stage reader. This is byte inventory, not acceptance
        # of endpoint metric semantics or an additive latency partition.
        for phase in ('before','after'):
            for name in ('metrics','status','resources'):
                read(d/f'{phase}-{name}.json')
        allocator_records = {}
        for label in ('before', 'post-client'):
            provenance = read(d/(label+'-allocator-provenance.json'))
            require(provenance['complete'] is True and provenance['label']==label and
                    set(provenance['voters'])=={'1','2','3'} and
                    provenance['started_unix_ns'] <= provenance['ended_unix_ns'], 'incomplete allocator observation')
            if label=='before':
                require(provenance['ended_unix_ns'] < begin, 'allocator preflight overlaps timing')
            else:
                require(provenance['started_unix_ns'] >= read(d/'client-exit.json')['observed_unix_ns'] >= end,
                        'allocator after observation precedes client exit')
            for node, sample in provenance['voters'].items():
                identity=identities[sample['pid']]
                require(sample['pid']!=client_pid and sample['start_ticks']==identity['start_ticks'] and
                        sample['boot_id']==sample['boot_after']==identity['boot_id'], 'allocator process identity differs')
                for raw in (sample['stat_before'],sample['stat_after']):
                    require(int(raw.split(' ',1)[0])==sample['pid'] and
                            int(raw.rsplit(')',1)[1].split()[19])==identity['start_ticks'], 'allocator raw stat identity differs')
                require(sample['checked_environment_names']==['_RJEM_MALLOC_CONF','MALLOC_CONF','LD_PRELOAD','LD_AUDIT','TOKIO_WORKER_THREADS'] and
                        sample['present_environment_names']==[], 'allocator environment override present/unchecked')
                config=sample['configuration_file']
                require(config['path']==f'/proc/{sample["pid"]}/root/etc/_rjem_malloc.conf' and
                        type(config['exists'])is bool and config['symlink']is False, 'allocator file observation differs')
                if config['exists']:
                    require(type(config['mode'])is int and not stat.S_ISLNK(config['mode']), 'allocator configuration symlink present')
            allocator_records[label]=provenance
        require(allocator_records['before']['voters'].keys()==allocator_records['post-client']['voters'].keys(),
                'allocator endpoint voter set differs')
        before=read(d/'listener-before.json');after=read(d/'listener-after.json')
        voters=read(d/'fixture/tmpfs-voters.json')['voters'];require(len(voters)==3,'three voter mount records missing')
        for node,listener in before.items():
            pid=listener['pid'];identity=identities[pid];later=after[node]
            require(all(provenance['voters'][node]['pid']==pid for provenance in allocator_records.values()),
                    'allocator observer voter/listener mapping differs')
            require(pid==later['pid'] and listener['advertised_endpoint']==later['advertised_endpoint'] and
                    listener['listener_inodes']==later['listener_inodes'] and listener['experimental_environment_absent'] and
                    later['experimental_environment_absent'],'ordinary listener binding differs')
            matches=[v for v in voters if v['pid']==pid];require(len(matches)==1,'voter mount owner differs');v=matches[0]
            require(v['mount']['filesystems'][0]['fstype']=='tmpfs' and v['executable_sha256']==identity['executable_sha256'] and
                    v['logical_data']==str(d/'fixture/data'/('n'+node)),'voter mount/source differs')
            require(v['command_line'][v['command_line'].index('--data-dir')+1]==v['logical_data'],'voter data path differs')
            writer_bindings+=1
        for label in ('before','post-client','post-readback'):
            drain=read(d/(label+'-fresh-drain.json'))
            require(0<=drain['completed_unix_ns']-drain['started_unix_ns']<=20_000_000_000,'fresh drain exceeded bound')
            require(set(drain['baseline'])==set(drain['first_advances'])==set(drain['final'])=={'1','2','3'},'drain voter set differs')
            for node,baseline in drain['baseline'].items():
                first=drain['first_advances'][node]['status'];last=drain['final'][node];identity=identities[int(baseline['pid'])]
                require(qualify(first) and qualify(last),'first/final drain was not empty and serving')
                for state in (baseline,first,last):
                    require(int(state['pid'])==identity['pid'] and int(state['process_start_ticks'])==identity['start_ticks'] and
                            state['process_boot_id']==identity['boot_id'],'drain writer identity differs')
                require(int(baseline['metrics_export_successes'])<int(first['metrics_export_successes'])<int(last['metrics_export_successes']),
                        'drain exports not strictly newer')
            require(len({(x['applied_term'],x['applied_index'])for x in drain['final'].values()})==1,'drain final positions differ')
            drains+=1
        dataset={}
        for page in sorted(d.glob('readback-*.txt')):
            raw=page.read_bytes();records[str(page)]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
            lines=raw.decode().splitlines();require(lines[-1]==f'count={len(lines)-1}','scan count differs')
            for line in lines[:-1]:
                fields=dict(part.split('=',1)for part in line.split());key=bytes.fromhex(fields['key_hex'])
                require(key not in dataset,'duplicate final scan key');dataset[key]=bytes.fromhex(fields['value_hex'])
        retention=read(d/'fixture/tmpfs-retention.json')
        require(retention['complete'] and retention['children_exited'] and retention['scratch_removed'] and
                not Path(retention['original_scratch']).exists(),'owned tmpfs cleanup incomplete')
        retained=Path(retention['retained_data']);require(retained==d/'fixture/data' and retained.is_dir() and not retained.is_symlink(),'retained directory differs')
        require({str(p.relative_to(retained))for p in retained.rglob('*')if p.is_file()}==set(retention['files']),'retained member set differs')
        with ThreadPoolExecutor(max_workers=2) as pool:
            for path,entry in pool.map(retention_file,[(retained/name,entry)for name,entry in retention['files'].items()]):
                records[path]=entry;retained_files+=1;retained_bytes+=entry['bytes']
    dataset_result=dataset_check(c,dataset)
    require(dataset_result['changed_keys'] > 0 if c['read_percent'] < 100 else dataset_result['changed_keys'] == 0, 'write/read final value population differs')
    metrics=r['metrics']['measurement']
    operations=operation_statistics(metrics,r['cohort_elapsed_ns'],True)
    outcomes={name:sum(op['populations'][i]['calls']for op in metrics['statistics'])for i,name in enumerate(metrics['outcomes'])}
    attempts=sum(op['attempts']for op in operations)
    return dict(complete=True,dataset=dataset_result,operations=operations,outcomes=outcomes,
        measured_calls=r['measured_completed'],attempts=attempts,
        healthy_single_attempt=outcomes['success']==r['measured_completed']==attempts,
        resource_samples=resource_count,listener_bindings=writer_bindings,fresh_drains=drains,
        retained_files=retained_files,retained_bytes=retained_bytes,memory=memory,storage=storage_summary)
