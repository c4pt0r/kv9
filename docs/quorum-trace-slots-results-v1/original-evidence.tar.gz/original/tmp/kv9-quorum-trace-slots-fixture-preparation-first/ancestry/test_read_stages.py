"""Finite synthetic schema/correlation/build contracts; no server or client run."""
import copy
import unittest

import diagnostic_build
import metrics26
import read_stages as stages


def hist(outcome='success', count=0, duration=0):
    buckets = [0] * 65
    buckets[duration.bit_length()] = count
    return dict(outcome=outcome, count=count, sum_ns=count * duration,
                min_ns=duration if count else None, max_ns=duration if count else None,
                buckets=buckets, count_saturated=False, sum_saturated=False,
                duration_clamped=False, **stages.quantiles(buckets))


def metric(name, count=0, duration=0):
    return dict(name=name, latency=dict(valid=True, outcomes=[hist(o, count if o == 'success' else 0, duration)
                                                            for o in stages.OUTCOMES]))


def document(count=0):
    values = dict(zip(stages.STAGES, [1, 2, 3, 4, 5, 15], strict=True))
    return dict(schema_version=2, bucket_count=65, clock='monotonic_instant', duration_unit='nanoseconds',
                reset='node_component_construction', snapshot_consistency='coherent_per_metric_independent_between_metrics',
                node_id=2, process_id=123, exporter_created_unix_ns='100', captured_unix_ns='200',
                metrics=[metric(n, count if n in values else 0, values.get(n, 0)) for n in stages.NAMES],
                apply_lag=dict(driver_applied_term=1, driver_applied_index=10, term_before=1, term_after=1,
                               committed_before=10, committed_after=10, lag_entries=0))


class ReadStages(unittest.TestCase):
    def test_population_coverage_rejects_equal_zero_truncated_and_unbounded_counts(self):
        before = {n: document() for n in ('1', '2', '3')}
        after = {n: document(4 if n == '2' else 0) for n in before}
        for side in (before, after):
            for n, doc in side.items(): doc['node_id'] = int(n)
        def set_count(doc, name, count):
            i = stages.NAMES.index(name); doc['metrics'][i] = metric(name, count, 1)
        set_count(after['2'], 'raft_read_establishment', 5)
        set_count(after['2'], 'public_raw_read_backend', 5)
        states = {n: dict(leader_id='2', term='1', role='leader' if n == '2' else 'follower') for n in before}
        report = dict(metrics={
            phase: dict(operations=[name], outcomes=stages.OUTCOMES,
                        statistics=[dict(populations=[dict(calls=count if o == 'success' else 0) for o in stages.OUTCOMES],
                                         attempt_reasons=[count])])
            for phase, name, count in [('initialization', 'batch_get', 1), ('warmup', 'get', 1),
                                       ('measurement', 'get', 2), ('verification', 'batch_get', 1)]})
        result = stages.population_coverage(before, after, states, states, report)
        self.assertEqual(result['all_client_point_get_successes'], 3)
        self.assertEqual(result['all_client_read_successes'], 5)
        for count in (0, 2, 6):
            bad = copy.deepcopy(after)
            for name in stages.STAGES: set_count(bad['2'], name, count)
            with self.assertRaises(ValueError): stages.population_coverage(before, bad, states, states, report)
        wrong_leader = copy.deepcopy(states); wrong_leader['2']['term'] = '2'
        with self.assertRaisesRegex(ValueError, 'leader/term changed'):
            stages.population_coverage(before, after, states, wrong_leader, report)

    def test_successful_partition_and_empty_follower(self):
        before, after = document(), document(3)
        rows = stages.delta(before, after)
        self.assertEqual([r['count_delta'] for r in rows], [3] * 6)
        self.assertEqual(sum(r['sum_ns_delta'] for r in rows[:-1]), rows[-1]['sum_ns_delta'])
        self.assertEqual(rows[-1]['p99'], dict(lower_ns=8, upper_ns=15))
        self.assertTrue(all(r['mean_ns'] is None and r['p99'] is None for r in stages.delta(before, before)))

    def test_default26_is_preserved_and_feature_requires32(self):
        full = document()
        base = dict(full, metrics=full['metrics'][:18] + full['metrics'][24:])
        metrics26.validate(base)
        with self.assertRaisesRegex(ValueError, 'inventory/order'):
            stages.validate(base)
        bad = copy.deepcopy(full); bad['metrics'][18:24] = reversed(bad['metrics'][18:24])
        with self.assertRaisesRegex(ValueError, 'inventory/order'):
            stages.validate(bad)

    def test_live_partial_chain_is_not_claimed_coherent(self):
        live = document(1)
        live['metrics'][18] = metric(stages.STAGES[0], 2, 1)
        stages.validate(live)  # Each metric is valid independently.
        with self.assertRaisesRegex(ValueError, 'populations differ'):
            stages.check_chain(live)  # Not valid as a drained endpoint.

    def test_wrong_partition_and_malformed_success_trace(self):
        bad = document(2); bad['metrics'][23] = metric(stages.STAGES[-1], 2, 16)
        with self.assertRaisesRegex(ValueError, 'partition total'):
            stages.check_chain(bad)
        bad = document(2)
        for row in bad['metrics'][18:24]:
            row['latency']['outcomes'][1] = hist('error', 1, 0)
        with self.assertRaisesRegex(ValueError, 'malformed success chain'):
            stages.check_chain(bad)

    def test_exporter_identity_and_counter_regression(self):
        for field in ('node_id', 'process_id', 'exporter_created_unix_ns'):
            before, after = document(), document(2); after[field] = 999
            with self.assertRaisesRegex(ValueError, 'identity changed'):
                stages.delta(before, after)
        before, after = document(), document(2)
        before['metrics'][0] = metric(stages.NAMES[0], 2, 10)
        after['metrics'][0] = metric(stages.NAMES[0], 1, 10)
        with self.assertRaisesRegex(ValueError, 'delta regressed'):
            stages.delta(before, after)

    def test_saturation_invalid_observer_and_histogram_controls(self):
        for flag in ('count_saturated', 'sum_saturated', 'duration_clamped'):
            bad = document(1); bad['metrics'][18]['latency']['outcomes'][0][flag] = True
            with self.assertRaises(AssertionError): stages.validate(bad)
        bad = document(1); bad['metrics'][18]['latency']['valid'] = False
        with self.assertRaises(AssertionError): stages.validate(bad)
        bad = document(1); bad['metrics'][18]['latency']['outcomes'][0]['count'] += 1
        with self.assertRaises(AssertionError): stages.validate(bad)
        bad = document(1); bad['metrics'][18]['latency']['outcomes'][0]['p99'] = dict(lower_ns=999, upper_ns=999)
        with self.assertRaises(AssertionError): stages.validate(bad)

    def test_exact_feature_graph_rejects_default_extra_or_wrong_source(self):
        source = '/tmp/kv9-read-stage-timing'
        records = [dict(reason='compiler-artifact', target=dict(name=n, src_path=source + '/src/lib.rs',
                        kind=['bin'] if n == 'kv9' else ['lib']), features=f[:],
                        profile=dict(opt_level='3', test=False), package_id='path+file://' + source + '#kv9@0.0.0',
                        executable='/tmp/owned-kv9' if n == 'kv9' else None)
                   for n, f in diagnostic_build.FEATURES.items()] + [dict(reason='build-finished', success=True)]
        diagnostic_build.validate_records(records, source)
        for index, field, value in [(2, 'features', []), (2, 'features', ['read-stage-timing', 'testing']),
                                    (0, 'package_id', 'path+file:///tmp/another-source#kv9@0.0.0')]:
            bad = copy.deepcopy(records); bad[index][field] = value
            with self.assertRaises(ValueError): diagnostic_build.validate_records(bad, source)
        bad = copy.deepcopy(records); bad[-1]['success'] = False
        with self.assertRaises(ValueError): diagnostic_build.validate_records(bad, source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
