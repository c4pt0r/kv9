"""Original outer isolation/readback predicates with the explicit lifecycle argv."""
from pathlib import Path
from contract import require
from common import HERE, sha

def check_outer(ROOT, matrix, read, driver_sha):
    outer=ROOT.parent
    final=read(outer/'summary.json');before=read(outer/'before.json');after=read(outer/'after.json')
    isolation=read(outer/'isolation.json');invocation=read(outer/'invocation.json')
    require(final['complete'] is True and final['restoration_complete'] is True and final['child_exit_code']==0 and
            not final['child_cleanup_errors'] and not final.get('forced_group_cleanup') and
            not final['deferred_cleanup_signals'] and not after['errors'],'outer terminal/cleanup/restoration differs')
    require(isolation['complete'] is True and isolation['exclusive_host'] is False and
            isolation['measured_client_cpus']==[0,1] and isolation['measured_server_cpus']==[2,3,4,5] and
            isolation['driver_sha256']==driver_sha,'outer isolation scope differs')
    require(matrix['isolation_snapshot']==isolation and sha(outer/'isolation.json')==matrix['isolation_snapshot_sha256'] and
            sha(ROOT/'isolation-snapshot.json')==sha(outer/'isolation.json'),'inner/outer snapshot binding differs')
    expected_argv=['/usr/bin/python3', str(HERE/'run.py'), '--output',str(ROOT),
        '--isolation-snapshot',str(outer/'isolation.json'),'--bindings',matrix['binding_file']]
    require(invocation['argv']==expected_argv and invocation['wrapper_sha256']==sha(HERE/'isolate-and-run.py') and
        invocation['driver_arguments_sha256']==sha(HERE/'driver-arguments.json'),
        'original wrapper/explicit diagnostic invocation differs')
    expected_containers={
      'kv9-chaos-ci-p0-20260908-control-plane':'ae9b27a77d14f295e35e112b31f5dce62ed6fd2d86a90e7b2a69b52798e17582',
      'kv9-chaos-control-plane':'d31317fe14d1d3344caa91ed45b4246e5e949d99b25cec5e28d9c6695fa43e8c',
      'kv9-minio-dev':'4b05c35453b87a409e7dd8a4dc935c782e282eb42cf14dd8c1ea6771efc0e042'}
    require(set(before['containers'])==set(after['containers'])==set(isolation['containers'])==set(expected_containers),
            'owned container scope differs')
    for name,cid in expected_containers.items():
        original=before['containers'][name];restored=after['containers'][name];isolated=read(outer/(name+'-isolated.json'))
        require(original['id']==cid and restored==original and original['configured_cpus']==original['effective_cpus']=='0-31',
                'container exact configured/effective restoration differs')
        for observed in (isolated,isolation['containers'][name]):
            require(all(observed[k]==original[k]for k in ('name','id','pid','start_ticks','started','cgroup')) and
                    observed['configured_cpus']==observed['effective_cpus']=='6-15,22-31','isolated container identity/cpuset differs')
        require(isolated['descendants']['tasks'] and all(set(task['cpus'])<=set(range(6,16))|set(range(22,32))
                for task in isolated['descendants']['tasks']),'owned background descendant affinity escaped')
    require(set(before['clusters'])==set(after['clusters']),'cluster inventory set differs')
    for name,initial in before['clusters'].items():
        final_cluster=after['clusters'][name]
        require(initial['namespaces']==final_cluster['namespaces'],'historical namespace UID changed')
        require([(f['kind'],f['metadata']['uid'])for f in initial['faults']]==
                [(f['kind'],f['metadata']['uid'])for f in final_cluster['faults']],'historical fault identity changed')
        for inventory in (initial,final_cluster):
            require(all(f['kind']=='PodChaos' and f['spec']['action']=='pod-kill' and
                        f['metadata']['uid']=='c3ededa7-0746-4864-bd95-4425ceb3d663'for f in inventory['faults']),
                    'unexpected fault in retained timing inventory')
            require(all(all(c.get('command')==['sleep','3600'] and not c.get('args')for c in p['spec']['containers'])
                        for p in inventory['project_running_pods']),'project workload was active')
    return dict(accepted=True,configured_and_effective_before_after='0-31',
                                     isolated='6-15,22-31',owned_containers=3,namespace_maps_preserved=True,
                                     original_summary_sha256=sha(outer/'summary.json'))
