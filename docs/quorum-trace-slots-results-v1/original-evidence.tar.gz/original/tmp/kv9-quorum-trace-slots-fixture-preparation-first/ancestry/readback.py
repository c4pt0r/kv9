#!/usr/bin/env python3
"""Independent non-CPU two-cohort runtime and local read-stage timing readback."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

from common import HERE, dependencies, modules, preflight, sha
from contract import OBSERVER_CPUS, check_protocol, descriptors, require, same
from stage_checks import check_lifecycle
from native_checks import check_native
from outer_checks import check_outer


def main():
    require(__debug__, 'assertions required')
    sys.dont_write_bytecode = True
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--bindings', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--root-session', type=int, required=True)
    parser.add_argument('--root-exit-code', type=int, choices=[0], required=True)
    args = parser.parse_args()
    require(sorted(os.sched_getaffinity(0)) == OBSERVER_CPUS, 'readback CPU mask differs')
    run, out = args.run.resolve(), args.output.resolve()
    require(args.root_session > 0 and out.is_relative_to(HERE) and
            not out.is_relative_to(run) and not run.is_relative_to(out), 'output/terminal scope differs')
    out.mkdir(exist_ok=False)
    records = {}
    def read(path):
        path = Path(path).resolve()
        raw = path.read_bytes()
        item = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        require(str(path) not in records or records[str(path)] == item, 'input changed during read')
        records[str(path)] = item
        return json.loads(raw)
    result = dict(complete=False, accepted=False, instrumented=True, throughput_acceptance=False,
        cpu_profiling=False, parent_confirmed_session=args.root_session,
        parent_confirmed_exit_code=args.root_exit_code, cohorts=[],
        scope='Successful matched async-read chain: five phase sums partition total on fresh drained endpoints only. Full native outcomes remain separate; not whole-client latency, pure-network, pure-scheduler, or performance-selection evidence')
    try:
        protocol = read(run / 'protocol.json')
        check_protocol(protocol)
        pins = read(args.bindings)
        require(same(pins, read(run / 'build-bindings.json')) and
                protocol['binding_file'] == str(args.bindings.resolve()) and
                protocol['binding_sha256'] == sha(args.bindings), 'root diagnostic binding differs')
        require(sha(run / 'driver.py') == sha(HERE / 'run.py'), 'executed runner differs')
        require(all(sha(path) == expected for path, expected in protocol['helper_hashes'].items()),
                'recorded helper inputs changed')
        driver = dependencies()
        roles = preflight(pins, driver)
        require(same(roles, protocol['role_bindings']), 'actual source/build role binding differs')
        loaded, _ = modules(roles, driver)
        for binding in roles.values():
            for path, expected in binding['evidence'].items():
                raw = Path(path).read_bytes()
                require(hashlib.sha256(raw).hexdigest() == expected, 'source/build evidence changed')
                records[path] = dict(bytes=len(raw), sha256=expected)
        result['outer_restoration'] = check_outer(run, protocol, read, sha(HERE / 'run.py'))
        summary = read(run / 'summary.json')
        require(summary['complete'] is True and summary['instrumented'] is True and
                summary['throughput_acceptance'] is False and summary['cpu_profiling'] is False and
                len(summary['cohorts']) == 2, 'recording incomplete or wrong scope')
        lifetimes = set()
        for ordinal, (expected, attempt) in enumerate(zip(descriptors(), summary['cohorts'], strict=True)):
            directory = run / f'{ordinal:03d}-{expected["arm"]}'
            require(attempt['index'] == ordinal and attempt['directory'] == str(directory) and
                    same(attempt['descriptor'], expected) and
                    same(read(directory / 'profile-plan.json'), expected), 'cohort descriptor/order/path differs')
            observed = check_native(directory, attempt, expected, roles, read, records, loaded[5], lifetimes)
            report = read(directory / 'run/report.json')
            transport = check_lifecycle(directory, read, report)
            for side in ['before', 'after']:
                states = read(directory / f'{side}-status.json')
                for state in states.values():
                    require(state['public_rpc_limit_requests'] == '64' and
                            state['public_rpc_limit_encoded_bytes'] == '16777216' and
                            state['raft_async_read_limit'] == '128' and state['raft_async_apply_limit'] == '128',
                            'fixed public/read/apply capacity differs')
            result['cohorts'].append(dict(index=ordinal, descriptor=expected, runtime=observed, read_stages=transport))
        require(len(lifetimes) == 8, 'owned lifetime count differs')
        require(all(Path(path).stat().st_size == item['bytes'] and sha(path) == item['sha256']
                    for path, item in records.items()), 'retained input changed during readback')
        result.update(complete=True, accepted=True, owned_lifetimes_exited=len(lifetimes),
            metric_documents=12, fresh_drain_documents=6, voter_listener_bindings=6,
            retained_files=sum(c['runtime']['retained_files'] for c in result['cohorts']),
            retained_bytes=sum(c['runtime']['retained_bytes'] for c in result['cohorts']))
        print(json.dumps(dict(accepted=True, instrumented=True, throughput_acceptance=False,
            cohorts=[dict(arm=c['descriptor']['arm'], nodes=c['read_stages']['nodes'], outcomes=c['runtime']['outcomes'],
                healthy_single_attempt=c['runtime']['healthy_single_attempt']) for c in result['cohorts']])))
    except BaseException as error:
        result['failure'] = repr(error)
        result['traceback'] = traceback.format_exc()
        raise
    finally:
        result['ended_unix_ns'] = time.time_ns()
        for name, value in [('analysis.json', result), ('input-inventory.json', records)]:
            with (out / name).open('x') as stream:
                json.dump(value, stream, indent=2, sort_keys=True)
                stream.write('\n')


if __name__ == '__main__':
    main()
