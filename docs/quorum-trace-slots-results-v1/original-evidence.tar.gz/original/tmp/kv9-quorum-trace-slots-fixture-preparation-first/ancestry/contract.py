"""Independent fixed two-cohort protocol; no runtime imports or side effects."""
import json
import re

PROTOCOL_ID = 'kv9-read-stage-c1-c64-v1'
OBSERVER_CPUS = list(range(6, 16)) + list(range(22, 32))
CLIENT_SOURCE = '/tmp/kv9-point-write-measurement-v3'
CLIENT_BUILD = '/tmp/kv9-point-write-v3-release-first/native'
CLIENT_REVISION = '0be806d9671e2c50701a64aa7889c8859b7648ba'
CLIENT_SHA = '8da9af469f962a938027d1970141bbe4622f7d42b2b795f720e288fb3f8d5957'
CLIENT_MANIFEST_SHA = 'eb8b4e1421dd4e64dcca59fcc7829926d5789611f6b3748d07c4090f634f2c4c'
CHECKER_SHA = '4c6b7dee7616052ebf533688e16025fb07c0e3383598fbd305a0cb484248ac43'
EXPECTED_SOURCE = '/tmp/kv9-read-stage-timing'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def same(a, b):
    return json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)


def descriptors():
    rows = []
    for workers, reads in [(1, 100), (64, 100)]:
        for role in ['crc']:
            rows.append(dict(arm=f'{role}-c{workers}', target='kv9', server_role=role,
                read_api='point_get', write_api='point_put', workload=f'point-r{reads:03d}',
                repeat=0, mix='read' if reads == 100 else 'mixed',
                shared=dict(run_id=f'rs{len(rows)}', seed=71, workers=workers, keys=4096,
                    batch_size=1, value_bytes=128, read_percent=reads, warmup_calls=128,
                    measure_ms=5000, max_calls=10000000, load={'kind': 'closed_loop'})))
    return rows


def check_bindings(bindings):
    require(type(bindings) is list and len(bindings) == 1, 'one diagnostic binding required')
    row = bindings[0]
    require(row['role'] == 'crc' and row['path'] == EXPECTED_SOURCE, 'diagnostic source/role differs')
    require(type(row['output']) is str and row['output'].startswith('/') and
            re.fullmatch('[0-9a-f]{40}', row['revision'] or '') is not None,
            'explicit diagnostic release/revision required')
    require(row['complete'] is True and row['exit_code'] == 0, 'original diagnostic build incomplete')
    require(all(re.fullmatch('[0-9a-f]{64}', row[k] or '') for k in
                ['binary_sha256', 'manifest_sha256', 'cache_receipt_sha256', 'source_checker_sha256']), 'missing exact artifact pin')
    require(type(row['first_observed_units']) is int and row['first_observed_units'] > 0 and
            type(row['source_count']) is int and row['source_count'] > 0, 'missing fresh/source population')


def check_protocol(protocol):
    require(protocol['version'] == 1 and protocol['protocol_id'] == PROTOCOL_ID and
            protocol['instrumented'] is True and protocol['throughput_acceptance'] is False and
            protocol['cpu_profiling'] is False, 'diagnostic scope differs')
    require(same(protocol['cohorts'], descriptors()), 'two-cohort inventory/config/order differs')
    require(protocol['placement'] == dict(client_cpus=[0, 1], server_cpus=[2, 3, 4, 5],
            separated=True, exclusive_host=False), 'diagnostic placement differs')
    require(protocol['observer_cpus'] == OBSERVER_CPUS and protocol['storage'] == 'tmpfs',
            'observer/storage scope differs')
    require(not set(protocol) & {'perf', 'event', 'frequency_hz', 'recording_seconds'},
            'CPU-profile scope is not supported')


def check_config(row, config, report, config_sha):
    require(any(same(row, expected) for expected in descriptors()), 'undeclared cohort')
    expected = dict(version=3, rpc_transport='tonic_stream', read_api='point_get', write_api='point_put',
                    **row['shared'])
    require(set(config) == set(expected) | {'client'} and
            same({k: config[k] for k in expected}, expected), 'requested v3 configuration differs')
    limits = dict(version=1, epoch_conf_ver=1, epoch_version=1,
        max_in_flight=row['shared']['workers'], max_attempts=6, deadline_ms=1500, retry_backoff_ms=5)
    require(set(config['client']) == set(limits) | {'peers', 'keyspace_id'} and
            same({k: config['client'][k] for k in limits}, limits), 'SDK limits differ')
    require(len(config['client']['peers']) == 3 and
            {p['node_id'] for p in config['client']['peers']} == {1, 2, 3}, 'three peers required')
    require(same(report['configuration'], config) and report['config_sha256'] == config_sha,
            'client report/configuration bytes differ')
    build = report['build']
    require(build['revision'] == CLIENT_REVISION and build['binary_sha256'] == CLIENT_SHA and
            build['profile'] == 'release' and build['dirty'] is False, 'fixed native client differs')
