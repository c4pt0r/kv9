"""Independent 32-metric schema/delta validator, retaining the original26 checker.

The ordinary schema is coherent per metric only. Cross-stage checks below are
separate and must be applied only after the caller proves fresh quiescent exports.
"""
import metrics26 as original

PHASES = ['registration', 'owner_queue', 'quorum', 'completion', 'resume', 'total']
STAGES = ['raft_async_read_' + phase for phase in PHASES]
NAMES = original.NAMES[:18] + STAGES + original.NAMES[18:]
OUTCOMES = original.OUTCOMES
histogram = original.histogram
identity = original.identity


def require(value, message):
    if not value:
        raise ValueError(message)


def validate(doc):
    require([m['name'] for m in doc['metrics']] == NAMES, 'diagnostic32 inventory/order differs')
    baseline = dict(doc, metrics=doc['metrics'][:18] + doc['metrics'][24:])
    original.validate(baseline)
    # Reuse every original outcome/histogram/lag/schema predicate for new rows.
    # No source validator or original document is mutated.
    for stage in doc['metrics'][18:24]:
        row = dict(stage, name=original.NAMES[0])
        original.validate(dict(baseline, metrics=[row] + baseline['metrics'][1:]))


def check_chain(doc):
    """Requires the caller's independently verified drained endpoint coverage."""
    validate(doc)
    successful = [histogram(doc, name) for name in STAGES]
    require(len({h['count'] for h in successful}) == 1, 'drained stage populations differ')
    require(sum(h['sum_ns'] for h in successful[:-1]) == successful[-1]['sum_ns'],
            'drained stage sums do not partition total')
    for name in STAGES:
        for outcome in OUTCOMES[1:]:
            h = histogram(doc, name, outcome)
            require(h['count'] == h['sum_ns'] == 0,
                    'malformed success chain or unexpected diagnostic outcome')


def quantiles(buckets):
    n = sum(buckets)
    result = {}
    for percentile in (50, 95, 99):
        value, seen = None, 0
        if n:
            rank = (n * percentile + 99) // 100
            for i, count in enumerate(buckets):
                seen += count
                if seen >= rank:
                    value = original.bounds(i)
                    break
        result['p' + str(percentile)] = value
    return result


def delta(before, after):
    require(identity(before) == identity(after), 'metric exporter/process identity changed')
    for doc in (before, after):
        check_chain(doc)
    rows = []
    for name in NAMES:
        for outcome in OUTCOMES:
            b, a = histogram(before, name, outcome), histogram(after, name, outcome)
            require(a['count'] >= b['count'] and a['sum_ns'] >= b['sum_ns'] and
                    all(y >= x for x, y in zip(b['buckets'], a['buckets'], strict=True)),
                    'monotonic histogram delta regressed')
        if name in STAGES:
            b, a = histogram(before, name), histogram(after, name)
            buckets = [y - x for x, y in zip(b['buckets'], a['buckets'], strict=True)]
            count, total = a['count'] - b['count'], a['sum_ns'] - b['sum_ns']
            require(sum(buckets) == count, 'delta bucket population differs')
            rows.append(dict(name=name, count_delta=count, sum_ns_delta=total,
                             buckets=buckets, mean_ns=total / count if count else None,
                             **quantiles(buckets)))
    require(len({r['count_delta'] for r in rows}) == 1 and
            sum(r['sum_ns_delta'] for r in rows[:-1]) == rows[-1]['sum_ns_delta'],
            'delta stages do not partition total')
    return rows


def population_coverage(before, after, states_before, states_after, report):
    """Source-mapped coverage at already validated drained endpoints.

    One successful prepared point read emits one chain. Extra setup, batch reads
    and external scans may enlarge the surrounding populations; equality to the
    measurement-only count would be incorrect.
    """
    nodes = {'1', '2', '3'}
    require(set(before) == set(after) == set(states_before) == set(states_after) == nodes,
            'coverage voter inventory differs')
    leaders = [n for n in nodes if states_before[n]['role'] == 'leader']
    require(len(leaders) == 1, 'coverage needs one observed leader')
    leader = leaders[0]
    term = states_before[leader]['term']
    for side in (states_before, states_after):
        require(all(s['leader_id'] == leader and s['term'] == term and
                    s['role'] == ('leader' if n == leader else 'follower')
                    for n, s in side.items()), 'leader/term changed during coverage envelope')
    phases = {}
    for phase, metric in report['metrics'].items():
        successes = metric['outcomes'].index('success')
        rows = []
        for name, op in zip(metric['operations'], metric['statistics'], strict=True):
            rows.append(dict(operation=name, calls=sum(p['calls'] for p in op['populations']),
                successful_calls=op['populations'][successes]['calls'], attempts=sum(op['attempt_reasons']),
                outcomes={o: p['calls'] for o, p in zip(metric['outcomes'], op['populations'], strict=True)}))
        phases[phase] = rows
    point_success = sum(r['successful_calls'] for rows in phases.values() for r in rows if r['operation'] == 'get')
    measured_success = sum(r['successful_calls'] for r in phases['measurement'] if r['operation'] == 'get')
    read_success = sum(r['successful_calls'] for rows in phases.values() for r in rows
                       if r['operation'] in ('get', 'batch_get'))
    require(measured_success > 0 and point_success >= measured_success,
            'no successful measured point GET coverage')
    populations = {}
    for n in sorted(nodes):
        def difference(name, outcome='success'):
            value = histogram(after[n], name, outcome)['count'] - histogram(before[n], name, outcome)['count']
            require(value >= 0, 'coverage population regressed')
            return value
        stage = difference(STAGES[-1])
        establishment = difference('raft_read_establishment')
        raw_success = difference('public_raw_read_backend')
        raw_all = sum(difference('public_raw_read_backend', outcome) for outcome in OUTCOMES)
        require(stage <= establishment and stage <= raw_all,
                'stage count exceeds enclosing read/barrier population')
        populations[n] = dict(stage_successes=stage, read_establishment_successes=establishment,
                              raw_read_successes=raw_success, raw_read_all_outcomes=raw_all)
    require(populations[leader]['stage_successes'] >= point_success,
            'leader stage population does not cover successful point GET calls')
    require(sum(r['raw_read_successes'] for r in populations.values()) >= read_success and
            sum(r['read_establishment_successes'] for r in populations.values()) >= read_success,
            'outer read populations do not cover successful client read phases')
    return dict(observed_leader_node=leader, observed_term=term, measured_point_get_successes=measured_success,
                all_client_point_get_successes=point_success, all_client_read_successes=read_success,
                all_client_phases=phases, nodes=populations,
                scope='Lower bound covers all successful point calls, including measurement; endpoint deltas also include setup/verification/external readback. No equality to measured-only calls or latency is asserted.')
