#!/usr/bin/env python3
"""Root-owned read-only source/default-release preflight; no fixture launch."""
import argparse
import json
from pathlib import Path
import time

from common import dependencies, modules, preflight, read, sha


def main():
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--bindings',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists():
        raise ValueError('preflight output must be fresh')
    result=dict(complete=False,started_ns=time.time_ns(),runtime_executed=False,
                bindings=str(args.bindings.resolve()),bindings_sha256=sha(args.bindings))
    try:
        driver=dependencies()
        roles=preflight(read(args.bindings),driver)
        _,helpers=modules(roles,driver)
        result.update(complete=True,roles=roles,helpers=helpers)
    except BaseException as error:
        result['failure']=repr(error)
        raise
    finally:
        result['ended_ns']=time.time_ns()
        with args.output.open('x') as stream:
            json.dump(result,stream,indent=2,sort_keys=True)
            stream.write('\n')
    print('PASS: control/diagnostic roles and fixed native client source/build bindings; no fixture launched')


if __name__=='__main__':main()
