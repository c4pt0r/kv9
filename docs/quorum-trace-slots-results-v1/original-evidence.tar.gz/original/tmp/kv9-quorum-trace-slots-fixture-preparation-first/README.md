# C1 quorum trace and instrumentation overhead campaign

Four native point GET cohorts run in control/trace/trace/control order, each
5 seconds, one worker, 4096 keys plus sentinel, 128-byte values, seed71,
128 warmups and the original 10M call cap. The source-qualified uninstrumented
ThinLTO server11113f6/dd028cb2 and diagnostic1875e74/fe19660e use the same pinned
v3 native client0be806d9/8da9af46, tonic streaming, ordinary three voters,
tmpfs WAL and unchanged SDK deadline/attempt limits. No Redis or loaded cohort
is added. This quantifies observer overhead and local stage populations;
it cannot qualify a runtime speedup or pure network latency.

The original v3_fixture, native_checks, outer_checks, isolation wrapper,
metrics26 and read_stages sources are byte-identical to the accepted prior
read-stage preparation. The private finish wrapper runs the tested export hook
after the original post-client/post-readback drains and after snapshots/report,
inside the existing finally-close boundary. It creates all three markers once,
uses the original runtime storage guard and an explicit10-second timeout,
retains original bytes and independently bound process identities, and does
not analyze traces while timed work is alive. Controls skip capture entirely.
No capture retry, restarted cohort or inferred zero is permitted.

The reader preserves all-four/native lifecycle/retention/outer restoration
checks. Both roles retain shared exporter/lifetime/drain/coverage predicates;
only six-stage requirements depend on instrumentation. Actual trace inputs
use the frozen bounded/non-symlink/duplicate-key reader, independently join to
accepted launch/status/metrics and original retained data, and keep every loss
and ambiguity. Each process analysis is capped at64MiB; the six-process combined
report is capped at6*64MiB+16MiB. Missing intermediates keep contexts incomplete.
Full trace prefixes include setup and verification, not measurement-only work;
no subtraction from client mean or addition of follower means is valid.

Root source/build preflight passed8d274e/0. Eight inherited metric/build controls
and four new campaign controls passed in the first13-test run. The remaining
negative control expected ValueError but the unchanged default metric validator
correctly raised AssertionError. Original057aaa/1 and all draft bytes remain;
only the test accepted both existing rejection types, and that one repaired
control passed8e328d/0. No runtime or acceptance predicate changed; the other12
passing controls were not rerun. The frozen export hook retains its original10
passing controls, and the frozen trace reader its17 passing controls.

A bounded independent source recheck found all five initial draft integration
issues resolved (fd63fd/0). The selected source hashes are recorded separately.
No actual trace or timing has run at freeze. Root alone launches the exact
retained command and records its terminal outcome before independent readback.
Original client0–1/server2–5/helper6–15,22–31 placement,32/96GiB preflight and
16/64GiB runtime floors,8GiB tmpfs snapshot bound and owned cleanup/restoration
remain. Shared-host/cache effects and post-capture gaps remain limits.
