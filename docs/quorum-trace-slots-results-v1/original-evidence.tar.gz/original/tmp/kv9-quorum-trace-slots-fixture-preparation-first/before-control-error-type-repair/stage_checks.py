"""Fresh drained endpoint identity/population/conservation checks for six successful read stages."""
from native_checks import require
import read_stages
import metrics26
PHASES = read_stages.PHASES
NODES = {'2', '1', '3'}
ZERO = ['public_rpc_in_flight', 'public_rpc_queued', 'public_rpc_running', 'public_rpc_encoded_bytes', 'raft_async_apply_in_flight', 'raft_async_apply_queued', 'raft_async_read_in_flight', 'raft_async_read_queued', 'raft_async_read_active', 'raft_async_read_active_groups']
IDENTITY = ['pid', 'node_id', 'process_start_ticks', 'process_boot_id', 'cluster_id', 'bootstrap_generation', 'store_incarnation']

def drained(state):
    require(state['bootstrap_state'] == 'Serving' and state['fatal'] == '', 'not healthy Serving')
    require(all(state[k] == '0' for k in ZERO), 'public/read/apply not drained')
    require(state['raft_async_apply_stopped'] == state['raft_async_read_stopped'] == 'false', 'registry stopped')
    require(state['applied_term'] == state['driver_applied_term'] and
            state['applied_index'] == state['driver_applied_index'], 'applied pair differs')


def check_lifecycle(directory, read, report, instrumented=True):
    checker = read_stages if instrumented else metrics26
    phases_inventory = PHASES if instrumented else []
    metrics = {side: read(directory / (side + '-metrics.json')) for side in ['before', 'after']}
    states = {side: read(directory / (side + '-status.json')) for side in ['before', 'after']}
    resources = {side: read(directory / (side + '-resources.json')) for side in ['before', 'after']}
    drains = {label: read(directory / (label + '-fresh-drain.json'))
              for label in ['before', 'post-client', 'post-readback']}
    client = read(directory / 'client-identity.json')
    exited = read(directory / 'client-exit.json')
    require(exited['exit_code'] == 0, 'client did not exit successfully')
    require(read(directory / 'fixture-result.json')['complete'] is True, 'fixture incomplete')
    for side in metrics:
        require(set(metrics[side]) == set(states[side]) == set(resources[side]['processes']) == NODES,
                'endpoint voter inventory differs')
    for label, drain in drains.items():
        require(set(drain['baseline']) == set(drain['first_advances']) == set(drain['final']) == NODES, 'drain voter inventory differs')
        require(0 <= drain['completed_unix_ns'] - drain['started_unix_ns'] <= 20_000_000_000, 'drain time exceeds bound')
        for node in sorted(NODES):
            first = drain['first_advances'][node]
            triple = [drain['baseline'][node], first['status'], drain['final'][node]]
            require(drain['started_unix_ns'] <= first['observed_unix_ns'] <= drain['completed_unix_ns'], 'drain observation outside bounds')
            require(int(triple[0]['metrics_export_successes']) < int(triple[1]['metrics_export_successes']) <
                    int(triple[2]['metrics_export_successes']), 'two serial export advances absent')
            for state in triple:
                require(all(state[k] == states['before'][node][k] for k in IDENTITY), 'drain lifetime changed')
                require(all(state[k] == states['before'][node][k] for k in ['leader_id', 'role', 'term']),
                        'drain leader/term changed during coverage envelope')
            drained(triple[1]); drained(triple[2])
        require(len({(s['applied_term'], s['applied_index']) for s in drain['final'].values()}) == 1, 'replica drain positions differ')
    require(exited['observed_unix_ns'] <= drains['post-client']['started_unix_ns'] <=
            drains['post-client']['completed_unix_ns'] <= drains['post-readback']['started_unix_ns'], 'post-exit drain ordering differs')
    nodes, coverage = [], []
    for node in sorted(NODES):
        before, after = metrics['before'][node], metrics['after'][node]
        sb, sa = states['before'][node], states['after'][node]
        require(all(sb[k] == sa[k] for k in IDENTITY), 'endpoint lifetime changed')
        require(checker.identity(before) == checker.identity(after), 'metrics process/exporter changed')
        require(int(before['captured_unix_ns']) < int(after['captured_unix_ns']) and
                before['exporter_uptime_ns'] < after['exporter_uptime_ns'], 'export time did not advance')
        for side, doc, state in [('before', before, sb), ('after', after, sa)]:
            checker.validate(doc)
            require(int(state['node_id']) == doc['node_id'] == int(node) and int(state['pid']) == doc['process_id'], 'status/metric identity mismatch')
            resource = resources[side]['processes'][node]
            require(resource['pid'] == int(state['pid']) and resource['start_ticks'] == int(state['process_start_ticks']), 'resource lifetime differs')
            require(doc['export_failures_before_capture'] == 0 and doc['export_failures_saturated'] is False and
                    state['metrics_export_failures'] == '0' and state['metrics_export_failures_saturated'] == 'false' and
                    state['metrics_export_last'] == 'success', 'export failure present')
            require(doc['apply_lag']['lag_entries'] == 0, 'endpoint apply lag')
            drained(state)
            if instrumented:
                checker.check_chain(doc)
                hs = [checker.histogram(doc, 'raft_async_read_' + phase) for phase in PHASES]
                require(len({h['count'] for h in hs}) == 1 and sum(h['sum_ns'] for h in hs[:-1]) == hs[-1]['sum_ns'], 'endpoint phase population/partition differs')
                for phase in phases_inventory:
                    for outcome in checker.OUTCOMES[1:]:
                        h = checker.histogram(doc, 'raft_async_read_' + phase, outcome)
                        require(h['count'] == h['sum_ns'] == 0, 'invalid trace or non-success profile outcome')
        bcap, acap = int(before['captured_unix_ns']), int(after['captured_unix_ns'])
        require(drains['before']['completed_unix_ns'] < bcap < client['observed_unix_ns'] < exited['observed_unix_ns'] <
                drains['post-readback']['completed_unix_ns'] < acap, 'capture does not bracket drained client envelope')
        require(int(sb['metrics_export_successes']) >= int(drains['before']['final'][node]['metrics_export_successes']) and
                int(sa['metrics_export_successes']) >= int(drains['post-readback']['final'][node]['metrics_export_successes']) >
                int(sb['metrics_export_successes']), 'endpoint export counters stale')
        for name in metrics26.NAMES:
            for outcome in metrics26.OUTCOMES:
                a, b = [metrics26.histogram(doc, name, outcome) for doc in [before, after]]
                require(b['count'] >= a['count'] and b['sum_ns'] >= a['sum_ns'] and
                        all(y >= x for x, y in zip(a['buckets'], b['buckets'])), 'base histogram regressed')
        if instrumented:
            checker.delta(before, after)
        else:
            require('quorum_trace_export_attempted' not in sb and 'quorum_trace_export_attempted' not in sa,
                    'control contains quorum observer')
        phases = []
        for phase in phases_inventory:
            a, b = [checker.histogram(doc, 'raft_async_read_' + phase) for doc in [before, after]]
            n, total = b['count'] - a['count'], b['sum_ns'] - a['sum_ns']
            require(n >= 0 and total >= 0 and all(y >= x for x, y in zip(a['buckets'], b['buckets'])), 'profile counters regressed')
            buckets = [y - x for x, y in zip(a['buckets'], b['buckets'], strict=True)]
            phases.append(dict(phase=phase, before_count=a['count'], after_count=b['count'], count_delta=n, sum_ns_delta=total, buckets=buckets, **checker.quantiles(buckets)))
        if instrumented:
            require(len({p['count_delta'] for p in phases}) == 1 and sum(p['sum_ns_delta'] for p in phases[:-1]) == phases[-1]['sum_ns_delta'], 'delta population/partition differs')
        nodes.append(dict(node_id=node, pid=sb['pid'], start_ticks=sb['process_start_ticks'], boot_id=sb['process_boot_id'],
                          exporter_created_unix_ns=before['exporter_created_unix_ns'], samples=phases[-1]['count_delta'] if instrumented else None, phases=phases))
        coverage.append(dict(node_id=node, before_capture_ns=bcap, after_capture_ns=acap,
                             before_drain_completed_ns=drains['before']['completed_unix_ns'],
                             after_drain_completed_ns=drains['post-readback']['completed_unix_ns'],
                             client_started_observed_ns=client['observed_unix_ns'], client_exit_ns=exited['observed_unix_ns']))
    if not instrumented:
        return dict(nodes=nodes, snapshot_coverage=coverage, metric_count=26, read_stage_metrics_enabled=False)
    totals = [dict(phase=phase, count_delta=sum(n['phases'][i]['count_delta'] for n in nodes),
                   sum_ns_delta=sum(n['phases'][i]['sum_ns_delta'] for n in nodes),
                   buckets=[sum(n['phases'][i]['buckets'][j] for n in nodes) for j in range(65)]) for i, phase in enumerate(PHASES)]
    require(totals[-1]['count_delta'] > 0, 'no successful lifecycle samples')
    for phase in totals:
        phase['mean_ns'] = phase['sum_ns_delta'] / phase['count_delta']
        phase['share_percent'] = 100 * phase['sum_ns_delta'] / totals[-1]['sum_ns_delta'] if totals[-1]['sum_ns_delta'] else None
        phase.update(checker.quantiles(phase['buckets']))
    population = checker.population_coverage(metrics['before'], metrics['after'],
        states['before'], states['after'], report)
    population['external_readback_pages'] = len(list(directory.glob('readback-*.txt')))
    return dict(nodes=nodes, samples=totals[-1]['count_delta'], phases=totals, snapshot_coverage=coverage,
                population_coverage=population)
