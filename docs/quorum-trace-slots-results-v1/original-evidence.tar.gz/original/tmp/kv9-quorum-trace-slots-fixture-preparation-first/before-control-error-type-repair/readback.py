#!/usr/bin/env python3
"""Independent four-cohort c1 runtime, overhead and local quorum trace readback."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

from common import HERE, dependencies, modules, preflight, sha
from contract import OBSERVER_CPUS, check_protocol, descriptors, require, same
from stage_checks import check_lifecycle, drained, IDENTITY
import metrics26
import read_trace
from native_checks import check_native
from outer_checks import check_outer


def check_trace_exports(directory, read, report, records):
    hook=read(directory/'trace-capture-hook.json')
    original=read(directory/'quorum-trace-exports/record.json')
    require(hook==original and hook['complete'] and hook['enabled'] and hook['requested'] and hook['retries']==0, 'hook record incomplete/differs')
    require(set(hook['nodes'])=={'1','2','3'}, 'trace voter inventory differs')
    exit=read(directory/'client-exit.json');drain=read(directory/'post-readback-fresh-drain.json')
    require(exit['exit_code']==0 and exit['observed_unix_ns']<=drain['started_unix_ns']<=drain['completed_unix_ns']<=hook['started_unix_ns']<=hook['ended_unix_ns'], 'trace overlaps client or drain')
    require(hook['ended_unix_ns']-hook['started_unix_ns']<=10_000_000_000, 'capture exceeded original timeout')
    after_status=read(directory/'after-status.json');after_metrics=read(directory/'after-metrics.json')
    cleanup=read(directory/'cleanup.json');listeners=read(directory/'listener-after.json')
    retention=read(directory/'fixture/tmpfs-retention.json')
    before_poll=min(row['observed_unix_ns'] for row in hook['observations'])
    nodes=[]
    for node,row in sorted(hook['nodes'].items()):
        require(row['complete'] and row['marker_created'] and row['marker_identity']['bytes']==0, 'voter capture incomplete')
        require(hook['started_unix_ns']<=row['marker_started_unix_ns']<=row['marker_created_unix_ns']<=before_poll, 'all markers must precede polling')
        folder=directory/'quorum-trace-exports'/('n'+node)
        identity, identity_pin=read_trace.read_bounded(folder/'expected-identity.json')
        document, document_pin=read_trace.read_bounded(folder/'quorum-trace.json')
        for pin in [identity_pin,document_pin]:
            bound={k:pin[k] for k in ['bytes','sha256']}
            require(pin['path'] not in records or records[pin['path']]==bound, 'trace input changed during readback')
            records[pin['path']]=bound
        require(identity==row['expected_identity'] and document['node_id']==int(node), 'retained expected identity differs')
        require(sha(folder/'quorum-trace.json')==row['export']['sha256'] and (folder/'quorum-trace.json').stat().st_size==row['export']['bytes'], 'original retained trace bytes differ')
        require(row['marker_started_unix_ns']<=int(document['captured_unix_ns'])<=row['export_observed_unix_ns']<=hook['ended_unix_ns'], 'trace capture outside marker/readback interval')
        state=after_status[node];metrics=after_metrics[node]
        launches=[p['identity'] for p in cleanup['children'] if p['identity']['pid']==int(state['pid'])]
        require(len(launches)==1 and launches[0]['pid']==listeners[node]['pid'], 'trace launch/listener binding differs')
        launch=launches[0]
        independent=dict(node_id=int(node),process_id=launch['pid'],process_start_ticks=launch['start_ticks'],
                         boot_id=launch['boot_id'],exporter_created_unix_ns=metrics['exporter_created_unix_ns'])
        require(identity==independent and identity['process_id']==metrics['process_id']==int(state['pid']) and
                identity['process_start_ticks']==int(state['process_start_ticks']) and identity['boot_id']==state['process_boot_id'],
                'trace expected identity differs from accepted launch/status/metric evidence')
        original_path=directory/'fixture/data'/('n'+node)/'quorum-trace.json'
        original_entry=retention['files']['n'+node+'/quorum-trace.json']
        require(original_entry['bytes']==row['export']['bytes'] and original_entry['sha256']==row['export']['sha256'] and
                sha(original_path)==sha(folder/'quorum-trace.json'), 'copied trace differs from retained original')
        for label in ['before','after']:
            raw=(folder/('status-'+label+'.txt')).read_bytes()
            records[str(folder/('status-'+label+'.txt'))]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
            saved=dict(line.split('=',1) for line in raw.decode().splitlines())
            require(len(raw)==row['status_'+label]['bytes'] and hashlib.sha256(raw).hexdigest()==row['status_'+label]['sha256'] and
                    saved==row['status_'+label]['state'], 'retained export status differs')
            require(int(saved['pid'])==identity['process_id'] and int(saved['process_start_ticks'])==identity['process_start_ticks'] and
                    saved['process_boot_id']==identity['boot_id'], 'retained export status identity differs')
            require(saved['quorum_trace_export_attempted']==('false' if label=='before' else 'true') and
                    saved['quorum_trace_export_last']==('not_attempted' if label=='before' else 'success'), 'export status sequence differs')
        fresh=read(folder/'metrics-before.json')
        require((folder/'metrics-before.json').stat().st_size==row['metrics_before']['bytes'] and
                sha(folder/'metrics-before.json')==row['metrics_before']['sha256'], 'fresh exporter bytes differ')
        require(fresh['node_id']==int(node) and fresh['process_id']==identity['process_id'] and
                fresh['exporter_created_unix_ns']==identity['exporter_created_unix_ns'] and
                int(metrics['captured_unix_ns'])<=int(fresh['captured_unix_ns'])<=row['marker_started_unix_ns'], 'fresh exporter identity/order differs')
        result=read_trace.analyze(document,independent)
        require(len((json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode())<=read_trace.MAX_BYTES,
                'per-process trace analysis exceeds original output bound')
        nodes.append(dict(node=int(node),analysis=result))
    return dict(accepted=True,nodes=nodes,scope='Independent finite-prefix trace accounting; observation loss can prohibit context attribution. Not a performance optimization.')

def main():
    require(__debug__, 'assertions required')
    sys.dont_write_bytecode = True
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--bindings', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--root-session', type=int, required=True)
    parser.add_argument('--root-exit-code', type=int, choices=[0], required=True)
    args = parser.parse_args()
    require(sorted(os.sched_getaffinity(0)) == OBSERVER_CPUS, 'readback CPU mask differs')
    run, out = args.run.resolve(), args.output.resolve()
    require(args.root_session > 0 and out.is_relative_to(HERE) and
            not out.is_relative_to(run) and not run.is_relative_to(out), 'output/terminal scope differs')
    out.mkdir(exist_ok=False)
    records = {}
    def read(path):
        path = Path(path).resolve()
        raw = path.read_bytes()
        item = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        require(str(path) not in records or records[str(path)] == item, 'input changed during read')
        records[str(path)] = item
        return json.loads(raw)
    result = dict(complete=False, accepted=False, instrumented=True, throughput_acceptance=False,
        cpu_profiling=False, parent_confirmed_session=args.root_session,
        parent_confirmed_exit_code=args.root_exit_code, cohorts=[],
        scope='Successful matched async-read chain: five phase sums partition total on fresh drained endpoints only. Full native outcomes remain separate; not whole-client latency, pure-network, pure-scheduler, or performance-selection evidence')
    try:
        protocol = read(run / 'protocol.json')
        check_protocol(protocol)
        pins = read(args.bindings)
        require(same(pins, read(run / 'build-bindings.json')) and
                protocol['binding_file'] == str(args.bindings.resolve()) and
                protocol['binding_sha256'] == sha(args.bindings), 'root diagnostic binding differs')
        require(sha(run / 'driver.py') == sha(HERE / 'run.py'), 'executed runner differs')
        require(all(sha(path) == expected for path, expected in protocol['helper_hashes'].items()),
                'recorded helper inputs changed')
        driver = dependencies()
        roles = preflight(pins, driver)
        require(same(roles, protocol['role_bindings']), 'actual source/build role binding differs')
        loaded, _ = modules(roles, driver)
        for binding in roles.values():
            for path, expected in binding['evidence'].items():
                raw = Path(path).read_bytes()
                require(hashlib.sha256(raw).hexdigest() == expected, 'source/build evidence changed')
                records[path] = dict(bytes=len(raw), sha256=expected)
        result['outer_restoration'] = check_outer(run, protocol, read, sha(HERE / 'run.py'))
        summary = read(run / 'summary.json')
        require(summary['complete'] is True and summary['instrumented'] is True and
                summary['throughput_acceptance'] is False and summary['cpu_profiling'] is False and
                len(summary['cohorts']) == 4, 'recording incomplete or wrong scope')
        lifetimes = set()
        for ordinal, (expected, attempt) in enumerate(zip(descriptors(), summary['cohorts'], strict=True)):
            directory = run / f'{ordinal:03d}-{expected["arm"]}'
            require(attempt['index'] == ordinal and attempt['directory'] == str(directory) and
                    same(attempt['descriptor'], expected) and
                    same(read(directory / 'profile-plan.json'), expected), 'cohort descriptor/order/path differs')
            observed = check_native(directory, attempt, expected, roles, read, records, loaded[5], lifetimes)
            report = read(directory / 'run/report.json')
            transport = check_lifecycle(directory, read, report, instrumented=expected['server_role']=='trace')
            trace = check_trace_exports(directory, read, report, records) if expected['server_role']=='trace' else None
            if trace is None:
                require(read(directory/'trace-capture-hook.json')==dict(enabled=False,requested=False,reason='uninstrumented control') and not (directory/'quorum-trace-exports').exists(), 'control attempted trace capture')
            for side in ['before', 'after']:
                states = read(directory / f'{side}-status.json')
                for state in states.values():
                    require(state['public_rpc_limit_requests'] == '64' and
                            state['public_rpc_limit_encoded_bytes'] == '16777216' and
                            state['raft_async_read_limit'] == '128' and state['raft_async_apply_limit'] == '128',
                            'fixed public/read/apply capacity differs')
            result['cohorts'].append(dict(index=ordinal, descriptor=expected, runtime=observed, read_stages=transport,quorum_trace=trace))
        require(len(lifetimes) == 16, 'owned lifetime count differs')
        require(all(Path(path).stat().st_size == item['bytes'] and sha(path) == item['sha256']
                    for path, item in records.items()), 'retained input changed during readback')
        result.update(complete=True, accepted=True, owned_lifetimes_exited=len(lifetimes),
            metric_documents=24, fresh_drain_documents=12, voter_listener_bindings=12,
            retained_files=sum(c['runtime']['retained_files'] for c in result['cohorts']),
            retained_bytes=sum(c['runtime']['retained_bytes'] for c in result['cohorts']))
        print(json.dumps(dict(accepted=True, instrumented=True, throughput_acceptance=False,
            cohorts=[dict(arm=c['descriptor']['arm'], nodes=c['read_stages'].get('nodes',[]), outcomes=c['runtime']['outcomes'],
                healthy_single_attempt=c['runtime']['healthy_single_attempt']) for c in result['cohorts']])))
    except BaseException as error:
        result['failure'] = repr(error)
        result['traceback'] = traceback.format_exc()
        raise
    finally:
        result['ended_unix_ns'] = time.time_ns()
        for name, value in [('analysis.json', result), ('input-inventory.json', records)]:
            with (out / name).open('x') as stream:
                encoded=json.dumps(value,sort_keys=True,separators=(',',':'))+'\n'
                require(len(encoded.encode())<=6*read_trace.MAX_BYTES+16*1024**2, 'combined reporting bound exceeded')
                stream.write(encoded)


if __name__ == '__main__':
    main()
