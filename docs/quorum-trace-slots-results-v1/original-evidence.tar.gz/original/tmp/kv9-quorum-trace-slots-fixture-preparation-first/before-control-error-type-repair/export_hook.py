"""One-shot, post-client quorum export for an already owned three-voter fixture.

This is an in-process hook, not a launcher or a trace-analysis CLI. The caller
must keep it inside native_trial's existing try/finally fixture.close boundary.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import time

MAX_TRACE_BYTES = 64 * 1024**2
MAX_METRICS_BYTES = 512 * 1024
MAX_METADATA_BYTES = 2 * 1024**2
MAX_STATUS_BYTES = 64 * 1024
POLL_SECONDS = 0.05
MAX_TIMEOUT_SECONDS = 20
IDENTITY = ('node_id', 'process_id', 'exporter_created_unix_ns',
            'process_start_ticks', 'boot_id')
STATUS_IDENTITY = ('pid', 'process_start_ticks', 'process_boot_id')
FAILURES = {'capture_unavailable', 'invalid_marker', 'marker_error',
            'identity_error', 'encode_error', 'size_limit', 'create_error',
            'write_error', 'rename_error'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity_bytes(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def bounded_bytes(path, maximum):
    """Read only a stable regular final component; never follow its symlink."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= maximum,
                'non-regular or oversized reporting input: ' + str(path))
        data = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    require(len(data) <= maximum and len(data) == before.st_size and
            (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
            'reporting input changed during read: ' + str(path))
    return data


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def decode(data):
    return json.loads(data, object_pairs_hook=unique_object)


def save(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    require(len(data) <= MAX_METADATA_BYTES, 'hook reporting metadata exceeds bound')
    path.write_bytes(data)


def decimal(value, name):
    require(type(value) is str and value.isascii() and value.isdigit() and
            0 < len(value) <= 39 and int(value) > 0, 'invalid ' + name)
    return int(value)


def status_fields(data):
    pairs = [line.split('=', 1) for line in data.decode().splitlines()]
    require(all(len(pair) == 2 for pair in pairs), 'malformed status')
    return unique_object(pairs)


def directory_identity(path):
    info = path.lstat()
    require(stat.S_ISDIR(info.st_mode), 'voter directory is not a real directory')
    return dict(device=info.st_dev, inode=info.st_ino)


def capture_after_drain(fixture, directory, *, enabled, guard,
                        timeout_seconds=20, clock=time):
    """Collect all three exports once; propagate failure to existing cleanup.

    `guard` is the existing runtime storage guard callback. `clock` is injectable
    only to make finite fake-filesystem controls independent of real sleeps.
    Enabled must come from root's independently bound diagnostic build role.
    """
    require(type(enabled) is bool, 'explicit diagnostic enablement required')
    if not enabled:
        return dict(enabled=False, requested=False, reason='uninstrumented control')
    require(callable(guard), 'existing storage guard callback required')
    require(type(timeout_seconds) in (int, float) and
            0 < timeout_seconds <= MAX_TIMEOUT_SECONDS, 'capture timeout exceeds bound')
    directory = Path(directory)
    output = directory / 'quorum-trace-exports'
    output.mkdir(exist_ok=False)
    record = dict(complete=False, enabled=True, requested=False, retries=0,
                  started_unix_ns=clock.time_ns(), timeout_seconds=timeout_seconds,
                  nodes={}, inputs={}, workload_children=[], observations=[],
                  scope='Post-client finite observer prefix; no trace analysis, shutdown or client-success inference.')
    nodes = dict(fixture.nodes)
    deadline = clock.monotonic() + timeout_seconds

    def retain_input(name, maximum=MAX_METADATA_BYTES):
        path = directory / name
        data = bounded_bytes(path, maximum)
        record['inputs'][name] = dict(path=str(path), **identity_bytes(data))
        return decode(data)

    def check_lifetimes():
        require(set(fixture.nodes) == set(nodes) and
                all(fixture.nodes[n] is process for n, process in nodes.items()),
                'voter roster changed during capture')
        require(all(process.poll() is None for process in nodes.values()),
                'voter exited before capture completed')
        children = list(fixture.children)
        require(len({p.pid for p in children}) == len(children), 'duplicate child PID')
        require(all(any(p is child for child in children) for p in nodes.values()),
                'voter absent from owned children')
        require(fixture.workloads and all(any(p is child for child in children)
                                         for p in fixture.workloads),
                'workload ownership missing')
        require(not any(any(p is voter for voter in nodes.values()) for p in fixture.workloads),
                'workload/voter ownership overlaps')
        terminal = []
        for process in children:
            if any(process is voter for voter in nodes.values()):
                continue
            code = process.poll()  # Popen.poll reaps an exited owned child.
            require(code is not None, 'workload/helper child still active')
            require(process.pid in fixture.identities, 'terminal child has no launch identity')
            terminal.append(dict(pid=process.pid, exit_code=code,
                                 launch_identity=fixture.identities[process.pid]))
        return terminal

    def observe(node):
        row = record['nodes'][str(node)]
        physical = Path(row['physical_data'])
        require((fixture.out / 'data' / f'n{node}').resolve() == physical and
                directory_identity(physical) == row['directory_identity'],
                'owned voter data directory changed')
        raw = bounded_bytes(physical / 'status', MAX_STATUS_BYTES)
        state = status_fields(raw)
        live = fixture.state(node)  # Existing StreamingFixture checks live /proc start+boot.
        expected = row['expected_identity']
        wanted = (str(expected['process_id']), str(expected['process_start_ticks']), expected['boot_id'])
        require(live and tuple(live.get(k) for k in STATUS_IDENTITY) == wanted and
                tuple(state.get(k) for k in STATUS_IDENTITY) == wanted,
                'fresh status/live lifetime differs from launch and snapshot')
        require(state.get('bootstrap_state') == 'Serving' and state.get('fatal') == '',
                'voter no longer serving during capture')
        require(state.get('quorum_trace_export_attempted') in ('true', 'false') and
                state.get('quorum_trace_export_last') in ({'not_attempted', 'capturing', 'success'} | FAILURES),
                'diagnostic export status absent or unknown')
        return state, raw

    def copy_export(node, state, status_raw):
        row = record['nodes'][str(node)]
        source = Path(row['physical_data']) / 'quorum-trace.json'
        node_output = output / f'n{node}'
        raw = bounded_bytes(source, MAX_TRACE_BYTES)
        # Retain bytes before even envelope validation; malformed exports stay original.
        with (node_output / 'quorum-trace.json').open('xb') as stream:
            stream.write(raw)
        row['export'] = dict(original_path=str(source), retained_path=str(node_output / 'quorum-trace.json'),
                             **identity_bytes(raw))
        (node_output / 'status-after.txt').write_bytes(status_raw)
        row['status_after'] = dict(state=state, **identity_bytes(status_raw))
        document = decode(raw)
        require(type(document) is dict and set(document) == set(IDENTITY) | {'captured_unix_ns', 'trace'},
                'trace export envelope differs')
        require(all(type(document[k]) is type(row['expected_identity'][k]) and
                    document[k] == row['expected_identity'][k] for k in IDENTITY),
                'trace export identity differs')
        require(row['marker_started_unix_ns'] <= decimal(document['captured_unix_ns'], 'capture time') <= clock.time_ns(),
                'trace capture timestamp not bracketed by request/readback')
        require(type(document['trace']) is dict and document['trace'].get('node') == node and
                document['trace'].get('process_id') == nodes[node].pid,
                'inner trace process identity differs')
        row['export_observed_unix_ns'] = clock.time_ns()
        row['complete'] = True

    try:
        guard()
        require(len(nodes) == 3 and all(type(n) is int and n > 0 for n in nodes) and
                len({p.pid for p in nodes.values()}) == 3, 'exactly three unique owned voters required')
        record['workload_children'] = check_lifetimes()
        drain = retain_input('post-readback-fresh-drain.json')
        after_metrics = retain_input('after-metrics.json')
        after_status = retain_input('after-status.json')
        mounts = retain_input('storage-mounts.json')
        client_exit = retain_input('client-exit.json')
        client_identity = retain_input('client-identity.json')
        clients = [p for p in fixture.workloads if p.pid == client_identity['pid']]
        require(len(clients) == 1 and client_identity == fixture.identities[clients[0].pid] and
                clients[0].poll() == client_exit['exit_code'] and
                type(client_exit['observed_unix_ns']) is int and
                client_exit['observed_unix_ns'] <= drain['started_unix_ns'],
                'timed client terminal identity/order differs from existing drain')
        wanted_nodes = set(map(str, nodes))
        require(all(set(value) == wanted_nodes for value in
                    (drain['baseline'], drain['first_advances'], drain['final'], after_metrics, after_status, mounts)),
                'drain/snapshot/mount voter coverage differs')
        completed = drain['completed_unix_ns']
        require(type(completed) is int and drain['started_unix_ns'] <= completed <= record['started_unix_ns'],
                'existing post-readback drain is not completed before hook')
        for node, process in sorted(nodes.items()):
            key = str(node)
            launch = fixture.identities[process.pid]
            expected = dict(node_id=node, process_id=process.pid,
                            exporter_created_unix_ns=after_metrics[key]['exporter_created_unix_ns'],
                            process_start_ticks=launch['start_ticks'], boot_id=launch['boot_id'])
            require(type(expected['process_start_ticks']) is int and expected['process_start_ticks'] > 0 and
                    type(expected['boot_id']) is str and expected['boot_id'] == fixture.boot_id and expected['boot_id'],
                    'launch OS identity missing')
            decimal(expected['exporter_created_unix_ns'], 'exporter creation time')
            states = [drain['baseline'][key], drain['first_advances'][key]['status'], drain['final'][key], after_status[key]]
            wanted = (str(process.pid), str(launch['start_ticks']), launch['boot_id'])
            require(all(tuple(s.get(k) for k in STATUS_IDENTITY) == wanted for s in states),
                    'drain/after-snapshot identity differs')
            counts = [int(s['metrics_export_successes']) for s in states]
            require(counts[0] < counts[1] < counts[2] <= counts[3], 'existing fresh drain advances absent')
            require(after_metrics[key]['node_id'] == node and after_metrics[key]['process_id'] == process.pid and
                    decimal(after_metrics[key]['captured_unix_ns'], 'after snapshot time') >= completed,
                    'after metric snapshot missing or stale')
            physical = (fixture.out / 'data' / f'n{node}').resolve()
            require(str(physical) == mounts[key]['path'], 'data directory differs from original mount binding')
            row = dict(complete=False, physical_data=str(physical), directory_identity=directory_identity(physical),
                       expected_identity=expected, marker_created=False)
            record['nodes'][key] = row
            for name in ('quorum-trace.capture', 'quorum-trace.json', 'quorum-trace.tmp'):
                require(not os.path.lexists(physical / name), 'prior capture path exists: ' + str(physical / name))
            state, raw = observe(node)
            require(state['quorum_trace_export_attempted'] == 'false' and state['quorum_trace_export_last'] == 'not_attempted',
                    'capture was already attempted')
            metrics_raw = bounded_bytes(physical / 'metrics.json', MAX_METRICS_BYTES)
            metrics = decode(metrics_raw)
            require(metrics['node_id'] == node and metrics['process_id'] == process.pid and
                    metrics['exporter_created_unix_ns'] == expected['exporter_created_unix_ns'] and
                    decimal(after_metrics[key]['captured_unix_ns'], 'after time') <=
                    decimal(metrics['captured_unix_ns'], 'fresh metric time') <= clock.time_ns() and
                    int(state['metrics_export_successes']) >= counts[3],
                    'fresh metrics/exporter identity or progress differs')
            node_output = output / f'n{node}'
            node_output.mkdir()
            (node_output / 'status-before.txt').write_bytes(raw)
            (node_output / 'metrics-before.json').write_bytes(metrics_raw)
            save(node_output / 'expected-identity.json', expected)
            row.update(status_before=dict(state=state, **identity_bytes(raw)), metrics_before=identity_bytes(metrics_raw))
        # All identities/absence checks precede ALL marker creations. No polling
        # occurs until all three creations succeeded. A partial failure is final.
        record['workload_children'] = check_lifetimes()
        guard()
        for node in sorted(nodes):
            row = record['nodes'][str(node)]
            require(clock.monotonic() < deadline, 'capture preparation exhausted bounded deadline')
            row['marker_started_unix_ns'] = clock.time_ns()
            marker = Path(row['physical_data']) / 'quorum-trace.capture'
            directory_fd = os.open(row['physical_data'], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                directory_stat = os.fstat(directory_fd)
                require(dict(device=directory_stat.st_dev, inode=directory_stat.st_ino) == row['directory_identity'],
                        'voter directory changed before marker creation')
                fd = os.open(marker.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             0o600, dir_fd=directory_fd)
                try:
                    info = os.fstat(fd)
                finally:
                    os.close(fd)
            finally:
                os.close(directory_fd)
            row.update(marker_created=True, marker_created_unix_ns=clock.time_ns(),
                       marker_identity=dict(device=info.st_dev, inode=info.st_ino, bytes=info.st_size))
            require(stat.S_ISREG(info.st_mode) and info.st_size == 0, 'capture marker is not empty regular file')
            save(output / 'record.json', record)
        record['requested'] = True
        for _ in range(int(timeout_seconds / POLL_SECONDS) + 2):
            require(clock.monotonic() < deadline, 'bounded trace capture timed out; no retry')
            guard()
            check_lifetimes()
            for node in sorted(nodes):
                row = record['nodes'][str(node)]
                state, raw = observe(node)
                observation = dict(node=node, observed_unix_ns=clock.time_ns(),
                                   attempted=state['quorum_trace_export_attempted'], last=state['quorum_trace_export_last'])
                record['observations'].append(observation)
                attempted, last = observation['attempted'], observation['last']
                if attempted == 'true' and last in FAILURES:
                    (output / f'n{node}' / 'status-failure.txt').write_bytes(raw)
                    raise ValueError(f'node {node} one-shot trace export failed: {last}')
                require((attempted == 'false' and last == 'not_attempted') or
                        (attempted == 'true' and last in {'capturing', 'success'}),
                        'inconsistent trace export status')
                if row['complete']:
                    require(attempted == 'true' and last == 'success', 'successful export status regressed')
                elif last == 'success':
                    copy_export(node, state, raw)
            save(output / 'record.json', record)
            if all(row['complete'] for row in record['nodes'].values()):
                guard()
                check_lifetimes()
                record['complete'] = True
                break
            clock.sleep(POLL_SECONDS)
        require(record['complete'], 'bounded capture observation limit exhausted; no retry')
        return record
    except BaseException as error:
        record['failure'] = repr(error)
        raise
    finally:
        record['ended_unix_ns'] = clock.time_ns()
        save(output / 'record.json', record)
