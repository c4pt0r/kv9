"""Small fake-process/filesystem controls; no server, /proc, sockets or sleeps."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import export_hook as hook

HERE = Path(__file__).resolve().parent


class Child:
    def __init__(self, pid, code=None):
        self.pid, self.code = pid, code

    def poll(self):
        return self.code


class Clock:
    def __init__(self):
        self.now = 10.0
        self.sleeps = 0
        self.on_sleep = lambda: None

    def monotonic(self):
        return self.now

    def time_ns(self):
        return int(self.now * 1_000_000_000)

    def sleep(self, duration):
        self.sleeps += 1
        self.now += duration
        self.on_sleep()


class Fixture:
    def __init__(self, root):
        self.directory = root
        self.out = root / 'fixture'
        self.boot_id = 'synthetic-boot'
        self.nodes = {n: Child(100 + n) for n in (1, 2, 3)}
        self.workloads = [Child(200, 0)]
        self.children = list(self.nodes.values()) + self.workloads
        self.identities = {p.pid: dict(pid=p.pid, start_ticks=p.pid + 1000,
                                     boot_id=self.boot_id, executable_sha256='synthetic')
                           for p in self.children}
        self.closed = False
        self.status = {}
        self.metrics = {}
        for n, process in self.nodes.items():
            self.data(n).mkdir(parents=True)
            self.status[n] = dict(pid=str(process.pid), process_start_ticks=str(process.pid + 1000),
                                  process_boot_id=self.boot_id, bootstrap_state='Serving', fatal='',
                                  metrics_export_successes='4', quorum_trace_export_attempted='false',
                                  quorum_trace_export_last='not_attempted')
            self.metrics[n] = dict(node_id=n, process_id=process.pid,
                                   exporter_created_unix_ns='1000000000', captured_unix_ns='9000000000')
            self.write_status(n)
            self.write(self.data(n) / 'metrics.json', self.metrics[n])
        self.write(root / 'after-metrics.json', {str(n): m for n, m in self.metrics.items()})
        self.write(root / 'after-status.json', {str(n): s for n, s in self.status.items()})
        self.write(root / 'storage-mounts.json', {str(n): dict(path=str(self.data(n))) for n in self.nodes})
        self.write(root / 'client-exit.json', dict(exit_code=0, observed_unix_ns=6_000_000_000))
        self.write(root / 'client-identity.json', self.identities[200])
        self.write(root / 'post-readback-fresh-drain.json', dict(
            started_unix_ns=7_000_000_000, completed_unix_ns=8_000_000_000,
            baseline={str(n): dict(s, metrics_export_successes='1') for n, s in self.status.items()},
            first_advances={str(n): dict(status=dict(s, metrics_export_successes='2')) for n, s in self.status.items()},
            final={str(n): dict(s, metrics_export_successes='3') for n, s in self.status.items()}))

    def write(self, path, value):
        path.write_text(json.dumps(value) + '\n')

    def data(self, node):
        return self.out / 'data' / f'n{node}'

    def write_status(self, node):
        (self.data(node) / 'status').write_text(''.join(f'{k}={v}\n' for k, v in self.status[node].items()))

    def state(self, node):
        return dict(self.status[node])

    def publish(self, clock):
        # This callback runs only on a synthetic sleep, never in another thread.
        assert all((self.data(n) / 'quorum-trace.capture').is_file() for n in self.nodes)
        for n, process in self.nodes.items():
            doc = dict(node_id=n, process_id=process.pid, exporter_created_unix_ns='1000000000',
                       process_start_ticks=process.pid + 1000, boot_id=self.boot_id,
                       captured_unix_ns=str(clock.time_ns()),
                       trace=dict(node=n, process_id=process.pid, synthetic_only=True))
            self.write(self.data(n) / 'quorum-trace.json', doc)
            self.status[n].update(quorum_trace_export_attempted='true', quorum_trace_export_last='success')
            self.write_status(n)

    def close(self):
        # Model existing finally cleanup without deleting any synthetic evidence.
        self.closed = True
        for child in self.children:
            child.code = 0


class Controls(unittest.TestCase):
    def fixture(self):
        directory = HERE / 'synthetic-fixtures-first'
        directory.mkdir(exist_ok=True)
        fixture = Fixture(Path(tempfile.mkdtemp(prefix=self._testMethodName + '-', dir=directory)))
        clock = Clock()
        clock.on_sleep = lambda: fixture.publish(clock)
        return fixture, clock

    def run_hook(self, fixture, clock, **kwargs):
        try:
            return hook.capture_after_drain(fixture, fixture.directory, enabled=True,
                                            guard=kwargs.pop('guard', lambda: None), clock=clock, **kwargs)
        finally:
            fixture.close()

    def record(self, fixture):
        return json.loads((fixture.directory / 'quorum-trace-exports' / 'record.json').read_text())

    def markers(self, fixture):
        return [n for n in fixture.nodes if (fixture.data(n) / 'quorum-trace.capture').exists()]

    def test_success_three_markers_before_poll_exact_bytes_and_cleanup(self):
        fixture, clock = self.fixture()
        result = self.run_hook(fixture, clock)
        self.assertTrue(result['complete'])
        self.assertEqual(self.markers(fixture), [1, 2, 3])
        self.assertEqual(clock.sleeps, 1)
        self.assertTrue(fixture.closed)
        for n in fixture.nodes:
            original = (fixture.data(n) / 'quorum-trace.json').read_bytes()
            retained = fixture.directory / 'quorum-trace-exports' / f'n{n}'
            self.assertEqual((retained / 'quorum-trace.json').read_bytes(), original)
            self.assertEqual(result['nodes'][str(n)]['export']['sha256'], hook.identity_bytes(original)['sha256'])
            self.assertEqual(json.loads((retained / 'expected-identity.json').read_text())['process_id'], 100 + n)
            self.assertEqual((fixture.data(n) / 'quorum-trace.capture').stat().st_size, 0)

    def test_default_control_does_nothing(self):
        self.assertEqual(hook.capture_after_drain(None, None, enabled=False, guard=None),
                         dict(enabled=False, requested=False, reason='uninstrumented control'))

    def test_live_workload_or_extra_helper_refused_before_marker(self):
        for extra in (False, True):
            with self.subTest(extra=extra):
                fixture, clock = self.fixture()
                if extra:
                    fixture.children.append(Child(201))
                else:
                    fixture.workloads[0].code = None
                with self.assertRaisesRegex(ValueError, 'child still active'):
                    self.run_hook(fixture, clock)
                self.assertEqual(self.markers(fixture), [])
                self.assertTrue(fixture.closed)
                self.assertFalse(self.record(fixture)['complete'])

    def test_prior_capture_or_symlink_refused_without_new_markers(self):
        for name in ('quorum-trace.capture', 'quorum-trace.tmp', 'quorum-trace.json'):
            with self.subTest(name=name):
                fixture, clock = self.fixture()
                path = fixture.data(3) / name
                path.symlink_to(fixture.data(3) / 'does-not-exist')
                with self.assertRaisesRegex(ValueError, 'prior capture path'):
                    self.run_hook(fixture, clock)
                self.assertTrue(path.is_symlink())
                self.assertFalse((fixture.data(1) / 'quorum-trace.capture').exists())
                self.assertEqual(clock.sleeps, 0)

    def test_partial_creation_failure_is_final_and_preserved(self):
        fixture, clock = self.fixture()
        real_open = hook.os.open
        calls = []
        def fail_second(path, flags, *args, **kwargs):
            if path == 'quorum-trace.capture':
                calls.append(path)
                if len(calls) == 2:
                    raise PermissionError('synthetic second-marker refusal')
            return real_open(path, flags, *args, **kwargs)
        with patch.object(hook.os, 'open', fail_second):
            with self.assertRaisesRegex(PermissionError, 'second-marker refusal'):
                self.run_hook(fixture, clock)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.markers(fixture), [1])
        self.assertEqual(clock.sleeps, 0)
        self.assertFalse(self.record(fixture)['requested'])
        self.assertTrue(self.record(fixture)['nodes']['1']['marker_created'])
        self.assertTrue(fixture.closed)

    def test_identity_freshness_and_client_order_fail_closed(self):
        for variant in ('boot', 'start', 'exporter', 'stale', 'advances', 'feature', 'client_order'):
            with self.subTest(variant=variant):
                fixture, clock = self.fixture()
                if variant == 'boot':
                    fixture.status[1]['process_boot_id'] = 'another-boot'
                    fixture.write_status(1)
                elif variant == 'start':
                    fixture.identities[101]['start_ticks'] += 1
                elif variant == 'exporter':
                    fixture.metrics[1]['exporter_created_unix_ns'] = '2000000000'
                    fixture.write(fixture.data(1) / 'metrics.json', fixture.metrics[1])
                elif variant == 'stale':
                    fixture.metrics[1]['captured_unix_ns'] = '7000000000'
                    fixture.write(fixture.directory / 'after-metrics.json', {str(n): m for n, m in fixture.metrics.items()})
                elif variant == 'advances':
                    path = fixture.directory / 'post-readback-fresh-drain.json'
                    value = json.loads(path.read_text())
                    value['first_advances']['1']['status']['metrics_export_successes'] = '1'
                    fixture.write(path, value)
                elif variant == 'feature':
                    del fixture.status[1]['quorum_trace_export_last']
                    fixture.write_status(1)
                else:
                    fixture.write(fixture.directory / 'client-exit.json', dict(exit_code=0, observed_unix_ns=9_000_000_000))
                with self.assertRaises(ValueError):
                    self.run_hook(fixture, clock)
                self.assertEqual(self.markers(fixture), [])
                self.assertTrue(fixture.closed)

    def test_one_shot_failure_status_and_timeout_retain_markers(self):
        for failure in ('capture_unavailable', 'size_limit', 'timeout'):
            with self.subTest(failure=failure):
                fixture, clock = self.fixture()
                def fail():
                    if failure != 'timeout':
                        fixture.status[1].update(quorum_trace_export_attempted='true', quorum_trace_export_last=failure)
                        fixture.write_status(1)
                clock.on_sleep = fail
                with self.assertRaises(ValueError):
                    self.run_hook(fixture, clock, timeout_seconds=0.2)
                self.assertEqual(self.markers(fixture), [1, 2, 3])
                self.assertFalse(self.record(fixture)['complete'])
                self.assertEqual(self.record(fixture)['retries'], 0)
                self.assertTrue(fixture.closed)
                self.assertLessEqual(clock.sleeps, 5)

    def test_export_identity_malformed_and_bound_failure_preserve_original(self):
        for variant in ('identity', 'malformed', 'oversized'):
            with self.subTest(variant=variant):
                fixture, clock = self.fixture()
                def corrupt():
                    fixture.publish(clock)
                    path = fixture.data(1) / 'quorum-trace.json'
                    if variant == 'identity':
                        value = json.loads(path.read_text())
                        value['process_start_ticks'] += 1
                        fixture.write(path, value)
                    elif variant == 'malformed':
                        path.write_text('{invalid')
                    else:
                        path.write_bytes(b'x' * 513)
                clock.on_sleep = corrupt
                with patch.object(hook, 'MAX_TRACE_BYTES', 512):
                    with self.assertRaises(ValueError):
                        self.run_hook(fixture, clock)
                original = fixture.data(1) / 'quorum-trace.json'
                self.assertTrue(original.exists())
                copied = fixture.directory / 'quorum-trace-exports' / 'n1' / 'quorum-trace.json'
                if variant != 'oversized':
                    self.assertEqual(original.read_bytes(), copied.read_bytes())
                self.assertFalse(self.record(fixture)['complete'])
                self.assertTrue(fixture.closed)

    def test_lifetime_change_after_marker_does_not_become_new_capture(self):
        fixture, clock = self.fixture()
        def changed():
            fixture.publish(clock)
            fixture.nodes[2] = Child(102)
        clock.on_sleep = changed
        with self.assertRaisesRegex(ValueError, 'roster changed'):
            self.run_hook(fixture, clock)
        self.assertEqual(self.markers(fixture), [1, 2, 3])
        self.assertFalse(self.record(fixture)['complete'])
        self.assertTrue(fixture.closed)

    def test_storage_intervention_preserves_partial_capture_and_cleanup(self):
        fixture, clock = self.fixture()
        calls = []
        def guard():
            calls.append(1)
            if len(calls) == 3:
                raise ValueError('synthetic original storage guard intervention')
        with self.assertRaisesRegex(ValueError, 'storage guard intervention'):
            self.run_hook(fixture, clock, guard=guard)
        self.assertEqual(self.markers(fixture), [1, 2, 3])
        self.assertEqual(clock.sleeps, 0)
        self.assertFalse(self.record(fixture)['complete'])
        self.assertTrue(fixture.closed)


if __name__ == '__main__':
    unittest.main()
