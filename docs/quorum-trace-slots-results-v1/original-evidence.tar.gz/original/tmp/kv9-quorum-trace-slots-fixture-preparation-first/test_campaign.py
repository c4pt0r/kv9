"""Finite campaign/reader integration controls; no database, network or /proc."""
import copy,hashlib,json,tempfile,unittest
from pathlib import Path
import contract,diagnostic_build,export_hook,read_trace,readback,stage_checks
from test_export_hook import Fixture,Clock
from test_read_trace import fixture as trace_fixture
from test_read_stages import document,metric

HERE=Path(__file__).resolve().parent

def write(path,value):path.write_text(json.dumps(value)+'\n')
def load(path):return json.loads(path.read_text())

class Campaign(unittest.TestCase):
    def directory(self):
        parent=HERE/'campaign-synthetic-first';parent.mkdir(exist_ok=True)
        return Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=parent))

    def test_four_fixed_c1_cohorts_use_both_orders_and_original_limits(self):
        rows=contract.descriptors()
        self.assertEqual([r['server_role'] for r in rows],['control','trace','trace','control'])
        self.assertEqual([r['repeat'] for r in rows],[0,0,1,1])
        shared=[{k:v for k,v in r['shared'].items() if k!='run_id'} for r in rows]
        self.assertTrue(all(s==shared[0] for s in shared))
        self.assertEqual(shared[0],dict(seed=71,workers=1,keys=4096,batch_size=1,value_bytes=128,read_percent=100,warmup_calls=128,measure_ms=5000,max_calls=10000000,load={'kind':'closed_loop'}))
        pins=load(HERE/'root-build-bindings.json');contract.check_bindings(pins)
        for bad in [pins[:1],pins[::-1],[pins[0],pins[0]]]:
            with self.assertRaises(ValueError):contract.check_bindings(bad)

    def test_control_feature_graph_requires_same_source_and_no_observer(self):
        source='/synthetic/source';features={k:[] for k in diagnostic_build.FEATURES}
        records=[dict(reason='compiler-artifact',target=dict(name=n,src_path=source+'/src/lib.rs',kind=['bin'] if n=='kv9' else ['lib']),features=[],profile=dict(opt_level='3',test=False),package_id='path+file://'+source+'#kv9@0.0.0',executable='/synthetic/kv9' if n=='kv9' else None) for n in features]+[dict(reason='build-finished',success=True)]
        diagnostic_build.validate_records(records,source,features)
        for field,value in [('features',['quorum-trace']),('package_id','path+file:///wrong#kv9@0.0.0'),('target',dict(name='kv9',src_path='/wrong/src/lib.rs',kind=['bin']))]:
            bad=copy.deepcopy(records);bad[0][field]=value
            with self.assertRaises(ValueError):diagnostic_build.validate_records(bad,source,features)

    def exports(self):
        directory=self.directory();f=Fixture(directory);clock=Clock()
        def publish():
            f.publish(clock)
            for n,p in f.nodes.items():
                envelope,identity=trace_fixture([],node=n)
                envelope.update(node_id=n,process_id=p.pid,process_start_ticks=p.pid+1000,boot_id=f.boot_id,
                    exporter_created_unix_ns='1000000000',captured_unix_ns=str(clock.time_ns()))
                envelope['trace'].update(node=n,process_id=p.pid)
                write(f.data(n)/'quorum-trace.json',envelope)
        clock.on_sleep=publish
        hook=export_hook.capture_after_drain(f,directory,enabled=True,guard=lambda:None,clock=clock,timeout_seconds=10)
        write(directory/'trace-capture-hook.json',hook)
        write(directory/'cleanup.json',dict(children=[dict(identity=i) for i in f.identities.values()]))
        write(directory/'listener-after.json',{str(n):dict(pid=p.pid) for n,p in f.nodes.items()})
        files={f'n{n}/quorum-trace.json':export_hook.identity_bytes((f.data(n)/'quorum-trace.json').read_bytes()) for n in f.nodes}
        write(directory/'fixture/tmpfs-retention.json',dict(files=files))
        return directory

    def test_complete_export_binds_original_bytes_and_actual_launch_identity(self):
        directory=self.exports();records={}
        result=readback.check_trace_exports(directory,load,{},records)
        self.assertTrue(result['accepted']);self.assertEqual(len(result['nodes']),3)
        self.assertTrue(all(n['analysis']['total_events']==0 for n in result['nodes']))
        self.assertGreaterEqual(len(records),12)
        bad=load(directory/'after-metrics.json');bad['1']['exporter_created_unix_ns']='2';write(directory/'after-metrics.json',bad)
        with self.assertRaisesRegex(ValueError,'accepted launch/status/metric'):
            readback.check_trace_exports(directory,load,{}, {})

    def test_trace_copy_corruption_and_duplicate_json_keys_are_rejected(self):
        directory=self.exports();original=directory/'fixture/data/n1/quorum-trace.json';original.write_bytes(original.read_bytes()+b' ')
        with self.assertRaisesRegex(ValueError,'retained original'):
            readback.check_trace_exports(directory,load,{}, {})
        directory=self.exports();p=directory/'quorum-trace-exports/n1/quorum-trace.json';p.write_text('{"trace":{},"trace":{}}')
        with self.assertRaisesRegex(ValueError,'duplicate JSON'):
            readback.check_trace_exports(directory,load,{}, {})

    def control_lifecycle(self):
        directory=self.directory();nodes=['1','2','3'];states={};metrics={};resources={}
        def state(n,exports):
            return dict(pid=str(100+int(n)),node_id=n,process_start_ticks=str(1000+int(n)),process_boot_id='boot',cluster_id='cluster',bootstrap_generation='generation',store_incarnation='store'+n,
                leader_id='1',role='leader' if n=='1' else 'follower',term='7',bootstrap_state='Serving',fatal='',
                raft_async_apply_stopped='false',raft_async_read_stopped='false',applied_term='7',driver_applied_term='7',applied_index='9',driver_applied_index='9',metrics_export_successes=str(exports),metrics_export_failures='0',metrics_export_failures_saturated='false',metrics_export_last='success',**dict.fromkeys(stage_checks.ZERO,'0'))
        for label,start,end,counts in [('before',100,102,[1,2,3]),('post-client',210,212,[4,5,6]),('post-readback',220,222,[7,8,9])]:
            write(directory/(label+'-fresh-drain.json'),dict(started_unix_ns=start,completed_unix_ns=end,baseline={n:state(n,counts[0]) for n in nodes},first_advances={n:dict(observed_unix_ns=start+1,status=state(n,counts[1])) for n in nodes},final={n:state(n,counts[2]) for n in nodes}))
        for side,at,count in [('before',103,3),('after',223,9)]:
            states[side]={n:state(n,count) for n in nodes};metrics[side]={}
            for n in nodes:
                doc=document();doc.update(node_id=int(n),process_id=100+int(n),exporter_created_unix_ns='1',captured_unix_ns=str(at),exporter_uptime_ns=at,export_failures_before_capture=0,export_failures_saturated=False)
                doc['metrics']=[m for m in doc['metrics'] if m['name'] in readback.metrics26.NAMES]
                metrics[side][n]=doc
            resources[side]=dict(processes={n:dict(pid=100+int(n),start_ticks=1000+int(n)) for n in nodes})
            write(directory/(side+'-status.json'),states[side]);write(directory/(side+'-metrics.json'),metrics[side]);write(directory/(side+'-resources.json'),resources[side])
        write(directory/'client-identity.json',dict(observed_unix_ns=110));write(directory/'client-exit.json',dict(exit_code=0,observed_unix_ns=200));write(directory/'fixture-result.json',dict(complete=True))
        return directory

    def test_default_branch_retains_shared_lifetime_and_capture_checks(self):
        directory=self.control_lifecycle();result=stage_checks.check_lifecycle(directory,load,{},instrumented=False)
        self.assertEqual(result['metric_count'],26);self.assertEqual(len(result['snapshot_coverage']),3)
        for name,mutate in [
            ('after-metrics.json',lambda r:r['1']['apply_lag'].update(lag_entries=1)),
            ('after-status.json',lambda r:r['1'].update(process_start_ticks='9999')),
            ('after-metrics.json',lambda r:r['1'].update(captured_unix_ns='221')),
            ('after-status.json',lambda r:r['1'].update(metrics_export_failures_saturated='true'))]:
            path=directory/name;original=path.read_bytes();data=load(path);mutate(data);write(path,data)
            with self.assertRaises((ValueError, AssertionError)):stage_checks.check_lifecycle(directory,load,{},instrumented=False)
            path.write_bytes(original)

if __name__=='__main__':unittest.main(verbosity=2)
