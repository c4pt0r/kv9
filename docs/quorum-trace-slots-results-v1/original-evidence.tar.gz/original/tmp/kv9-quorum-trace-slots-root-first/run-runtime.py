import hashlib,json,os,signal,subprocess,time
from pathlib import Path
root=Path('/tmp/kv9-quorum-trace-slots-root-first');prep=Path('/tmp/kv9-quorum-trace-slots-fixture-preparation-first')
binding=json.loads((root/'preparation-binding.json').read_text())
def verify():
 data=(prep/'inventory.json').read_bytes();assert hashlib.sha256(data).hexdigest()==binding['inventory_sha256']
 for n,row in json.loads(data)['files'].items():
  p=prep/n;assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],n
verify();out=root/'runtime-first';out.mkdir();command=json.loads((root/'commands.json').read_text())['runtime'];r=dict(complete=False,argv=command,started_ns=time.time_ns(),preparation=binding);child=None
try:
 with (out/'output.log').open('x') as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0'));r['pid']=child.pid
  (out/'invocation.json').write_text(json.dumps(r,indent=2)+'\n');r['exit_code']=child.wait(timeout=900)
 assert r['exit_code']==0,'Original runtime failed; preserve outcome and do not rerun'
 verify();r['complete']=True
except BaseException as error:
 r['failure']=repr(error)
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 raise
finally:r['ended_ns']=time.time_ns();(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: four original control/trace cohorts terminal; independent readback pending')
