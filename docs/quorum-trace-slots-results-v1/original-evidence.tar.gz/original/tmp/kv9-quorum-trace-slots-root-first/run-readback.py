import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/kv9-quorum-trace-slots-root-first');prep=Path('/tmp/kv9-quorum-trace-slots-fixture-preparation-first')
binding=json.loads((root/'preparation-binding.json').read_text())
def verify():
 data=(prep/'inventory.json').read_bytes();assert hashlib.sha256(data).hexdigest()==binding['inventory_sha256']
 for n,row in json.loads(data)['files'].items():
  p=prep/n;assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],n
verify();runtime=json.loads((root/'runtime-first/result.json').read_text());assert runtime['complete'] and runtime['exit_code']==0
receipt={'session_id':69144,'exit_code':0,'chunk_id':'153abe','output':'PASS: four original control/trace cohorts terminal; independent readback pending'}
(root/'runtime-first/terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
out=root/'readback-first';out.mkdir()
command=['taskset','-c','6-15,22-31','/usr/bin/python3','-B',str(prep/'readback.py'),'--run','/tmp/kv9-quorum-trace-slots-isolation-first/cohorts','--bindings',str(prep/'root-build-bindings.json'),'--output',str(prep/'results-first'),'--root-session','69144','--root-exit-code','0']
r={'complete':False,'argv':command,'started_ns':time.time_ns(),'preparation':binding}
try:
 (out/'invocation.json').write_text(json.dumps(r,indent=2)+'\n')
 with (out/'output.log').open('x') as log:
  child=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0'),timeout=180)
 r['exit_code']=child.returncode
 assert child.returncode==0,'Preserve original readback failure'
 verify();r['complete']=True
except BaseException as error:r['failure']=repr(error);raise
finally:r['ended_ns']=time.time_ns();(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: independent readback and preparation binding verified')
