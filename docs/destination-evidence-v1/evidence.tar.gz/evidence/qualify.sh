#!/bin/zsh
set -u
W=/mnt/data/kv9-work/destination-evidence-20260917
LEAN=/mnt/data/kv9-work/lean-toolchain-restoration-20260915-first/installation/lean-4.33.1-linux/bin/lean
JAR=/mnt/data/kv9-work/proof-tools-20260915-first/tla2tools.jar
TLAPM=/mnt/data/kv9-work/proof-tools-20260915-first/tlapm/bin/tlapm
CREDS=/mnt/data/kv9-work/joint-install-20260916/minio-first/private-credentials.json
export KV9_OBJECT_STORE_ENDPOINT=http://172.21.0.4:9000
export KV9_OBJECT_STORE_BUCKET=kv9-joint-install-cbc8bed9c73d
export KV9_OBJECT_STORE_ACCESS_KEY=$(python3 -c "import json;print(json.load(open('$CREDS'))['access_key'])")
export KV9_OBJECT_STORE_SECRET_KEY=$(python3 -c "import json;print(json.load(open('$CREDS'))['secret_key'])")
cd /home/dongxu/kv9

cargo test --workspace --features kv9-raft/testing -- --test-threads=1 > $W/workspace-serial.log 2>&1
echo "serial exit=$?"
python3 - <<'PY'
import re
text=open('/mnt/data/kv9-work/destination-evidence-20260917/workspace-serial.log').read()
tallies=[(int(a),int(b),int(c)) for a,b,c in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)]
print(len(tallies), {'passed':sum(t[0] for t in tallies),'failed':sum(t[1] for t in tallies),'ignored':sum(t[2] for t in tallies)})
PY

cargo test -p kv9-raft --lib real_minio -- --ignored --test-threads=1 > $W/minio-focused.log 2>&1
echo "minio exit=$? $(grep -o '[0-9]* passed; [0-9]* failed' $W/minio-focused.log | tail -1)"

for model in data-range group-activation group-control group-preparation joint-install learner-attach migration-authority protocol-snapshot routed-client source-capture runtime-adoption install-evidence; do
  rm -rf $W/$model-proof
  python3 scripts/prove-$model.py --lean $LEAN --output $W/$model-proof > $W/$model-proof.log 2>&1
  tail -1 $W/$model-proof.log
done

rm -rf $W/retention-ledger-recheck
python3 scripts/check-retention-ledger.py --jar $JAR --tlapm $TLAPM --output $W/retention-ledger-recheck > $W/retention-ledger-recheck.log 2>&1
echo "retention exit=$?"
tail -1 $W/retention-ledger-recheck.log
