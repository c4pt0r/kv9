# Destination-install evidence + committed release decision — design

## Committed rows
- New TASKS kind 104 (`KV9EVD01`, meta::data_groups::evidence::InstallEvidence):
  root, operation[16], task, migration_task, region, destination
  InitialReplica, generation StoreIncarnation, image_digest RootDigest,
  subject[32] (= sha256(manifest.encode()), the retention owner subject),
  cut AppliedPosition. Exactly one evidence row per operation; exact retry
  is a confirmation (changed=false); any divergence refuses; row immutable.
  plan_install_evidence validates against the committed migration row
  (operation/region/destination node+incarnation/migration task) and the
  committed activation, same shape as plan_migration.

## Ledger fence lift (crates/meta/src/retention.rs)
- QuiesceAfterTransfer arm, Snapshot|Migration kinds: instead of the
  unconditional refusal, consult committed evidence THROUGH THE SAME VIEW
  (bounded raw scan of the TASKS row range, ≤256 rows, decoded with the
  catalog codec — no MetaStore needed). Require: evidence row committed
  with matching root, operation digest (sha256("kv9-migration-operation-v1"
  ++ root ++ operation) equals BOTH owners' descriptor.operation) and
  subject equal to both owners' subject. Absent/mismatched → same refusal.
- Release needs no new seam: Released still requires Quiesced, which now
  requires evidence. Destination (Migration-kind) owner stays Published —
  quiescing IT still needs a published successor and stays refused (its pin
  is the live replica's protection).

## Destination-side receipt (server)
- AdoptedGeneration gains the parsed manifest subject (sha256 of manifest
  bytes) — parse_image already runs during verification/adoption.
- RegionManager keeps the adoption receipt (operation, generation,
  image_digest, subject, cut) for adopted groups.
- New admin RPC + CLI verb `install-evidence` (destination): return the
  canonical KV9EVD01 payload derived from local durable adopted state +
  the committed migration. Read-only.
- New admin RPC + CLI verb `record-install-evidence` (metadata leader):
  catalog txn → plan_install_evidence → commit; idempotent.

## e2e extension (runtime-install-e2e.py → destination-evidence-e2e.py)
After catchup: emit evidence at node 4 → record at metadata leader →
retry idempotent → quiesce source owner (QuiesceAfterTransfer from source
to destination token) now ACCEPTED; before evidence it must REFUSE
(negative control) → release source owner accepted; destination owner
quiesce still refused (no successor) → owners readback shows
source=Released, destination=Published; bounded safe-direction retries
after committed rows.

## Proofs
- Lean model proofs/lean/install-evidence: states over
  {migrationCommitted, adopted, evidenceCommitted, sourceQuiesced,
  sourceReleased, destinationPinned(bool), foreignQuiesce} with theorems:
  evidence requires adoption+migration; quiesce requires evidence;
  release requires quiesce; destination pin never drops; no step serves
  or promotes. Mutation controls: quiesce-without-evidence,
  evidence-without-adoption, release-without-quiesce,
  destination-unpinned, evidence-rebinds-subject, etc.
- retention.rs is pinned by retention TLA/TLAPS inventory → refresh +
  rerun; sibling Lean contracts pinning runtime.rs etc. → refresh + rerun.
