#!/usr/bin/env python3
"""Before/after measurement for deferred engine-apply sync (#20, task #32),
against the PREDECLARED targets in the workdir progress.md (fixed before
any timed run): T1 C=32 throughput >= 1.3x; T2 engine_wal_record_sync per
op reduced >= 1.5x; T3 C=1 p99 <= strict p99 + 5ms. Identical single-host
fixtures; only KV9_DATA_SYNC_DEFER_BYTES differs. Acknowledged writes
rest on the synced raft log either way. A missed target is published as
failed, never re-aimed. No scaling claims.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def fields(text):
    return dict(line.split('=', 1) for line in text.splitlines() if '=' in line)


class Cluster:
    def __init__(self, binary, base, base_port, env):
        self.binary, self.base, self.base_port = binary, base, base_port
        self.env = env
        self.addresses = {i: f'127.0.0.1:{base_port+i}' for i in (1, 2, 3)}
        self.processes = {}
        self.handles = []

    def command(self, label, *arguments, retries=0):
        for attempt in range(retries + 1):
            result = subprocess.run([str(self.binary), *map(str, arguments)], env=self.env,
                                    text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    timeout=300)
            (self.base / f'{label}.log').write_text(result.stdout)
            if result.returncode == 0:
                return dict(word.split('=', 1) for word in result.stdout.split() if '=' in word)
            if attempt < retries and 'unconfirmed' in result.stdout:
                time.sleep(2)
                continue
            break
        require(False, f'{label}: {result.stdout[-400:]}')

    def start(self, node):
        log = (self.base / f'node-{node}.log').open('a')
        self.handles.append(log)
        process = subprocess.Popen(
            [str(self.binary), 'start', '--node-id', str(node), '--addr', self.addresses[node],
             '--data-dir', str(self.base / f'n{node}')],
            env=self.env, stdout=log, stderr=subprocess.STDOUT)
        self.processes[node] = process

    def status(self, node):
        path = self.base / f'n{node}/status'
        if not path.exists() or node not in self.processes:
            return {}
        value = fields(path.read_text())
        return value if value.get('pid') == str(self.processes[node].pid) else {}

    def wait(self, label, predicate, seconds=90):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            value = predicate()
            if value:
                return value
            time.sleep(0.05)
        raise RuntimeError(f'timed out: {label}')

    def boot(self):
        incarnations = []
        for node in (1, 2, 3):
            guard = socket.socket()
            guard.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            guard.bind(('127.0.0.1', self.base_port + node))
            prepared = self.command(f'prepare-{node}', 'store-prepare', '--node-id', node,
                                    '--data-dir', self.base / f'n{node}')
            incarnations.append(f"{node}={prepared['store_incarnation']}")
            guard.close()
        root_file = self.base / 'root.bin'
        self.command('root-create', 'root-create', '--output', root_file,
                     '--voters', ','.join(f'{n}@{self.addresses[n]}' for n in (1, 2, 3)),
                     '--store-incarnations', ','.join(incarnations))
        for node in (1, 2, 3):
            self.command(f'init-{node}', 'init', '--root', root_file, '--node-id', node,
                         '--data-dir', self.base / f'n{node}')
        for node in (1, 2, 3):
            self.start(node)
        leader = self.wait('leader', lambda: next(
            (n for n in self.processes if self.status(n).get('role') == 'leader'
             and self.status(n).get('endpoint_ready') == 'true'), None))
        return leader

    def sync_counts(self):
        # DATA-GROUP engine apply syncs from the status aggregate (the
        # node-level metrics export carries the catalog engine only).
        counts = {}
        for node in (1, 2, 3):
            value = self.status(node).get('data_engine_io')
            counts[node] = int(json.loads(value)['record_sync_success']) if value else 0
        return counts

    def shutdown(self):
        for node in list(self.processes):
            process = self.processes.pop(node)
            if process.poll() is None:
                process.kill()
            process.wait(timeout=10)
        for handle in self.handles:
            handle.close()


REPEATS = 3


def run_side(name, binary, workload, build_manifest, out, base_port, batch_env, measure_ms):
    # The host disk's run-to-run variance dominates single windows; every
    # trial repeats and the MEDIAN row is the side's published figure. All
    # raw repeats are retained.
    results = {}
    for offset, (trial, workers, ms) in enumerate(
            (('c32', 32, measure_ms), ('c1', 1, max(measure_ms // 2, 2000)))):
        repeats = []
        for r in range(REPEATS):
            repeats.append(run_trial(f'{name}-r{r}', trial, workers, ms, binary, workload,
                                     build_manifest, out, base_port + offset * 10 + r * 40,
                                     batch_env))
        rates = sorted(repeats, key=lambda x: x['report']['cohort_success_ops_per_second'])
        median = rates[len(rates) // 2]
        median = dict(median)
        median['repeats'] = [dict(rate=x['report']['cohort_success_ops_per_second'],
                                  sync_delta=x['raft_sync_delta'],
                                  ops=x['report']['measured_successful']) for x in repeats]
        results[trial] = median
    return results


def run_trial(name, trial, workers, ms, binary, workload, build_manifest, out,
              base_port, batch_env):
    # One FRESH cluster per trial: no cross-trial state, and the sync
    # counters cover exactly this trial's window from a clean boot.
    base = out / name / trial
    base.mkdir(parents=True)
    env = dict(os.environ, KV9_CLUSTER_TOKEN=f'bench-{name}-{trial}-cluster',
               KV9_CLIENT_TOKENS=f'admin=bench-{name}-client',
               KV9_CLIENT_TOKEN=f'bench-{name}-client',
               KV9_BOOTSTRAP_TOKEN=f'bench-{name}-bootstrap', **batch_env)
    cluster = Cluster(binary, base, base_port, env)
    try:
        leader = cluster.boot()
        # DATA-GROUP keyspace: the deferral (and any apply-path feature)
        # lives on data-group engines; the legacy create-keyspace path
        # never touches them (fixture correction #2).
        root = cluster.status(leader)['root_digest']
        created = cluster.command('create-group', 'client', 'create-data-group',
                                  '--addr', cluster.addresses[leader],
                                  '--root-digest', root, '--operation-id', f'{1:032x}',
                                  '--voters', '1,2,3', retries=5)
        receipt = cluster.command('create-keyspace', 'client', 'create-data-keyspace',
                                  '--addr', cluster.addresses[leader],
                                  '--root-digest', root, '--creation-task', created['task_id'],
                                  '--name', f'bench-{name}-{trial}', retries=5)
        keyspace = int(receipt['keyspace_id'])
        region = int(created['region_id'])
        def group_ready():
            for n in (1, 2, 3):
                groups = json.loads(cluster.status(n).get('data_groups', '[]'))
                for g in groups:
                    if g.get('region') == region and g.get('role') == 'Leader':
                        return True
            return False
        cluster.wait('data group elected', group_ready, 120)
        def routable():
            result = subprocess.run(
                [str(binary), 'client', 'raw-get', '--addr', cluster.addresses[leader],
                 '--keyspace', str(keyspace), '--key-hex', '70726f6265'],
                env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
            return result.returncode == 0 or 'not_leader=true' in result.stdout
        cluster.wait('route resolves', routable, 120)
        if True:
            directory = base
            config = dict(
                version=1, rpc_transport='tonic_stream',
                client=dict(version=1,
                            peers=[dict(node_id=n, address=a)
                                   for n, a in cluster.addresses.items()],
                            keyspace_id=keyspace, epoch_conf_ver=1, epoch_version=1,
                            max_in_flight=workers, max_attempts=6, deadline_ms=1500,
                            retry_backoff_ms=5),
                mode='performance', run_id=f'{name}-{trial}', keyspace_name=f'bench-{name}',
                seed=41, workers=workers, keys=8, value_bytes=128,
                mix=dict(get=0, put=100, delete=0), warmup_operations=32,
                max_operations=1_000_000, measure_ms=ms, interval_ms=0, history_bytes=0)
            (directory / 'config.json').write_text(json.dumps(config, indent=2))
            before = cluster.sync_counts()
            log = (directory / 'workload.log').open('w')
            process = subprocess.Popen(
                [str(workload), '--config', directory / 'config.json',
                 '--build-manifest', build_manifest, '--output', directory / 'run'],
                env=env, stdout=log, stderr=subprocess.STDOUT)
            code = process.wait(timeout=ms / 1000 + 360)
            log.close()
            require(code == 0, f'{name}/{trial} workload failed')
            after_deadline = time.monotonic() + 15
            after = cluster.sync_counts()
            while time.monotonic() < after_deadline:
                nxt = cluster.sync_counts()
                if nxt == after:
                    break
                after = nxt
                time.sleep(1)
            report = json.loads((directory / 'run/report.json').read_text())
            return dict(report=report,
                        raft_sync_before=before, raft_sync_after=after,
                        raft_sync_delta=sum(after.values()) - sum(before.values()))
    finally:
        cluster.shutdown()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin', type=Path, required=True)
    parser.add_argument('--workload-dir', type=Path, required=True,
                        help='build-workload.py output (kv9-workload + build.json)')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--measure-ms', type=int, default=8000)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    binary = args.bin.resolve()
    workload = args.workload_dir.resolve() / 'kv9-workload'
    manifest = args.workload_dir.resolve() / 'build.json'
    record = dict(
        schema=1,
        binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
        workload_sha256=hashlib.sha256(workload.read_bytes()).hexdigest(),
        revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        dirty=bool(subprocess.check_output(['git', 'status', '--porcelain'])),
        measure_ms=args.measure_ms,
        predeclared_targets=dict(
            t1_throughput_ratio_min=1.3,
            t2_engine_sync_reduction_min=1.5,
            t3_p99_overhead_ms_max=5.0),
    )
    sides = {}
    sides['unbatched'] = run_side(
        'strict', binary, workload, manifest, out, 27200,
        dict(KV9_DATA_SYNC_DEFER_BYTES='0'), args.measure_ms)
    sides['batched'] = run_side(
        'deferred', binary, workload, manifest, out, 27220,
        dict(KV9_DATA_SYNC_DEFER_BYTES='4194304'), args.measure_ms)

    def throughput(side, trial):
        report = sides[side][trial]['report']
        rate = report.get('cohort_success_ops_per_second')
        require(rate, f'{side}/{trial}: missing success rate')
        return rate

    def p99(side, trial):
        # Measurement-phase logical latency for the put operation, success
        # outcome; the p99 bucket's upper bound in milliseconds.
        report = sides[side][trial]['report']
        metrics = report['metrics']
        put = next(i for i, op in enumerate(metrics['operations'])
                   if 'put' in str(op).lower())
        phase = metrics['logical_latency'][2][put]
        require(phase.get('valid'), f'{side}/{trial}: latency snapshot invalid')
        histogram = next(h for h in phase['outcomes'] if str(h.get('outcome', '')).lower() == 'success')
        bounds = histogram.get('p99')
        require(bounds, f'{side}/{trial}: missing p99 population')
        return bounds['upper_ns'] / 1e6

    t1_ratio = throughput('batched', 'c32') / max(throughput('unbatched', 'c32'), 1e-9)
    unbatched_sync = max(sides['unbatched']['c32']['raft_sync_delta'], 1)
    batched_sync = max(sides['batched']['c32']['raft_sync_delta'], 1)
    # Normalize per operation: sync count per completed op, then the ratio.
    per_op_unbatched = unbatched_sync / max(sides['unbatched']['c32']['report']['measured_successful'], 1)
    per_op_batched = batched_sync / max(sides['batched']['c32']['report']['measured_successful'], 1)
    t2_ratio = per_op_unbatched / max(per_op_batched, 1e-9)
    t3_overhead = p99('batched', 'c1') - p99('unbatched', 'c1')
    verdicts = dict(
        t1=dict(ratio=t1_ratio, target=1.4, passed=t1_ratio >= 1.3),
        t2=dict(per_op_unbatched=per_op_unbatched, per_op_batched=per_op_batched,
                ratio=t2_ratio, target=1.5, passed=t2_ratio >= 1.5),
        t3=dict(overhead_ms=t3_overhead, target_ms=5.0, passed=t3_overhead <= 5.0),
    )
    record.update(sides={k: v for k, v in sides.items()}, verdicts=verdicts,
                  accepted=all(v['passed'] for v in verdicts.values()))
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    for name, verdict in verdicts.items():
        print(f'{name}: {"PASS" if verdict["passed"] else "FAIL"} {verdict}')
    print(f'BENCH_{"ACCEPTED" if record["accepted"] else "FAILED"}')


if __name__ == '__main__':
    main()
