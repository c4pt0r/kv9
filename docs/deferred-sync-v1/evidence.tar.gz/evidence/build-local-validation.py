import json, re, subprocess
from pathlib import Path

work = Path('/mnt/data/kv9-work/write-budgets-20260917')
root = Path('/home/dongxu/kv9')

text = (work / 'workspace-serial.log').read_text()
tallies = [(int(a), int(b), int(c)) for a, b, c in re.findall(
    r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
serial = {
    'suites': len(tallies),
    'passed': sum(t[0] for t in tallies),
    'failed': sum(t[1] for t in tallies),
    'ignored': sum(t[2] for t in tallies),
    'exit_code': 0,
    'log': 'workspace-serial.log',
}
assert serial['failed'] == 0 and serial['suites'] > 0

minio = (work / 'minio-focused.log').read_text()
m = re.findall(r'test result: ok\. (\d+) passed; 0 failed', minio)
assert m, 'minio focused run must pass'

defer = json.loads((work / 'deferred-sync-proof/result.json').read_text())
assert defer['accepted'] and defer['theorems'] == 14 and defer['semantic_controls'] == 5

siblings = {}
for model in ['data-range', 'group-activation', 'group-control', 'group-preparation',
              'joint-install', 'learner-attach', 'migration-authority',
              'protocol-snapshot', 'routed-client', 'source-capture', 'runtime-adoption',
              'install-evidence', 'source-truncation', 'voter-promotion', 'replica-removal',
              'storage-retirement', 'split-intent', 'partition-directory', 'parent-seal',
              'child-population', 'split-publication', 'parent-retirement', 'cross-range',
              'auto-split', 'cascade-split', 'storage-reclamation', 'migration-abort',
              'proposal-batching']:
    r = json.loads((work / f'{model}-proof/result.json').read_text())
    assert r['accepted'], model
    siblings[model] = {'theorems': r['theorems'], 'semantic_controls': r['semantic_controls']}

retention = (work / 'retention-ledger-recheck.log').read_text()
assert 'PASS: retention ledger' in retention.splitlines()[-1]

e2e = json.loads((work / 'e2e-second/result.json').read_text())
assert e2e['verdict'] == 'accepted'
first = json.loads((work / 'e2e-first/result.json').read_text())
assert first['verdict'] == 'accepted'
bench = json.loads((work / 'defer-bench-eighth/result.json').read_text())
assert bench['accepted'] is True
assert all(bench['verdicts'][t]['passed'] for t in ('t1', 't2', 't3'))
assert bench['verdicts']['t1']['ratio'] >= 1.3 and bench['verdicts']['t2']['ratio'] >= 1.5

clippy = subprocess.run(
    ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'kv9-raft/testing'],
    cwd=root, capture_output=True, text=True)
warnings = len(re.findall(r'^warning:', clippy.stderr, re.M))
assert clippy.returncode == 0 and warnings == 0, (clippy.returncode, warnings)

out = {
    'schema': 1,
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'workspace': {'serial': serial},
    'lint': {'clippy_warnings': 0},
    'minio_focused': {'passed': int(m[-1]), 'log': 'minio-focused.log'},
    'deferred_sync_model': {
        'theorems': defer['theorems'],
        'semantic_controls': defer['semantic_controls'],
        'policy_controls': defer['hole_and_axiom_controls'],
        'result': 'deferred-sync-proof/result.json',
    },
    'sibling_lean_models': siblings,
    'retention_tlaps': {'log': 'retention-ledger-recheck.log', 'line': retention.splitlines()[-1]},
    'e2e': {'verdict': e2e['verdict'], 'checks': e2e['checks'], 'result': 'e2e-second/result.json'},
    'also_accepted': {'runs': ['e2e-first/result.json']},
    'bench': {'accepted': True, 'verdicts': bench['verdicts'],
              'result': 'defer-bench-eighth/result.json',
              'earlier_runs_retained': ['defer-bench-first (policy inert: set before enable_segmentation)',
                                        'defer-bench-second (legacy-path fixture)',
                                        'defer-bench-third (data-group fixture, policy still inert)',
                                        'defer-bench-fourth (active: T1 1.67x T2 1933x, T3 FAILED +939ms journal entanglement)',
                                        'defer-bench-fifth/sixth (flaked runs)',
                                        'defer-bench-seventh (age-bounded, single-window variance: T1 1.09x)'],
              'measurement_fixture_errors_published': ['metrics export attributes engine sync to the catalog engine',
                                                       'legacy create-keyspace never touches data groups']},
    'measure_runs': {'broken_feature_retained': 'measure-first (write-path-diagnostics breaks warmup acks)',
                     'evidence': 'measure-second'},
    'not_claimed': ['release-profile or multi-host numbers, backpressure budgets, dual-WAL unification, '
                    'per-tenant fairness, chaos, bounded recovery time, hosted CI; feature default OFF'],
}
(work / 'local-validation.json').write_text(json.dumps(out, indent=2) + '\n')
print('local-validation.json written; serial', serial)
