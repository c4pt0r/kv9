# Write-path measurement + apply-side group commit — task #32

Baseline: e5a675a. Ports 27180 (measure), next 27200. Serial suite 943.

## Phase A: MEASUREMENT (done, decisive)
Fixture: traced binary (write-stage-tracing ONLY — the
write-path-diagnostics feature BREAKS warmup acks, retained as
measure-first), 3 voters, C=32 puts 8s (measure-second).

Client: 414.5 ops/s; put p50 67ms, p95 268ms, p99 537ms.
Server stage medians (all 3 nodes agree):
- lock 0.004ms, wait-for-apply-slot 0.03ms, APPLY 6.9-7.8ms (max
  278-340ms), receipts 0.014ms. ~25 commands per applied entry.
- raft_wal_record_sync: p50 8.4ms p99 134ms (~550 syncs).
- engine_wal_record_sync: p50 8.4ms p99 134-268ms (~370 syncs).
- prepare queue negligible (p50 0.016ms). registration age median 46ms.

CONCLUSION: proposals already coalesce (~25 cmds/entry via Ready-level
grouping); the write path's serial per-entry cost is APPLY (engine WAL
record write + sync per committed entry, ~7-8ms median on this disk's
8.4ms-median fsync) stacked after the raft-log sync. The lever is
APPLY-SIDE GROUP COMMIT: drain ALL queued committed entries and apply
them as ONE engine WAL batch + ONE sync, preserving per-entry receipts
and the exact applied positions. (This is #20 item 1's third leg,
"engine apply group commit", now evidence-selected.)

## PREDECLARED targets for the apply-group-commit feature
(fixed HERE before any timed run of the feature; never revise)
Same fixture as measure-second (C=32 8s, C=1 4s), plain binary:
- T1 C=32 throughput >= 1.3x the no-feature side.
- T2 engine_wal_record_sync count per successful op reduced >= 1.5x.
- T3 C=1 p99 <= no-feature p99 + 5ms.
Failure -> publish as failed, feature default-off (KV9_APPLY_GROUP_OPS
or similar gate), never re-aim.

## Phase B plan
1. Survey driver apply loop (driver.rs: committed entries -> engine
   apply one-by-one?) and the engine's atomic batch+position API
   (wal.rs:491 'Persist the batch and its exact apply position under a
   single CRC and fsync' — currently ONE position per batch; grouped
   apply needs either one batch per entry WITHOUT intermediate sync +
   final sync, or a multi-position record. Prefer: apply each entry's
   batch unsynced, sync ONCE after the drained set, with the LAST
   position durable — crash semantics must equal today's (positions
   below the synced one must be replay-safe: WAL records exist
   unsynced... crash before sync loses tail records -> replay from
   raft log re-applies: SAFE because raft log is durable ahead).
2. Bounded: drain cap by entries/bytes; env-gated default OFF.
3. Lean model (apply-group-commit): receipts only after the covering
   sync; replay covers unsynced tail; order preserved; bounded drain.
4. Unit tests + e2e (crash between batch write and sync -> replay
   equivalence) + bench vs predeclared targets + qualify + packet.

## Status
- [x] Phase A measurement (measure-first retained broken-feature run;
      measure-second the evidence)
- [x] predeclared targets fixed
- [x] Phase B survey:
  * APPLY-SIDE GROUP COMMIT ALREADY EXISTS: driver.rs step_inner
    coalesces a raw prefix into apply groups (state_machine/raw_group,
    caps 128 entries/1MiB — NOT binding: measured groups top at 31 =
    the closed-loop concurrency). One engine WAL record+sync per GROUP.
  * The bottleneck is the DISK (8.4ms median fsync) x TWO serial layers
    (raft-log sync then engine-apply sync) per group: ~30 groups/s x
    ~14 avg cmds = the observed 414 ops/s.
  * CHOSEN LEVER: deferred engine-apply sync under raft-log durability
    (acks already rest on the SYNCED raft log + deterministic replay;
    crash-between-syncs replay machinery is exercised today; deferral
    only widens the replayed window).
  * WAL layers: persist.rs WalBacking::{Legacy(wal.rs append_record:
    write_all+sync_all per record), Segmented(wal_segment.rs append:
    sync per append at :281)}. Data groups use SEGMENTED (data.segments)
    — implement deferral in wal_segment.rs (and surface via WalEngine),
    env KV9_DATA_SYNC_DEFER_BYTES (0=off default), plumbed ONLY to
    data-group engines in RegionManager.
  * Barriers that force sync_now(): truncate_source_log before
    compact_retained_prefix (keep log-above-durable invariant airtight);
    nothing else strictly required (capture/population read snapshot
    views; replay is deterministic).
  * e2e MUST kill -9 mid-load with deferral on and prove every ACKED
    write survives via replay (ack = raft-committed).
- [ ] impl + tests + Lean + e2e + bench + qualify + packet + publish

## Measurement correction (recorded BEFORE the re-run; targets unchanged)
defer-bench-first exposed a MIS-ATTRIBUTION: the exported
`engine_wal_record_sync` metric reads the METADATA CATALOG engine
(`self.node.store.engine`), never the data-group engines — so T2 in
BOTH the proposal-batching increment and defer-bench-first measured the
wrong engine. Correction: the status body now carries `data_engine_io=`
(success write/sync counts summed across the node's data-group
engines); T2 is computed from ITS before/after delta. The predeclared
RATIOS are unchanged (T1 1.3x, T2 1.5x on data-group apply syncs per
op, T3 +5ms). defer-bench-first is retained (T1 1.24x observed, T3
-134ms, T2 invalid-by-attribution).

## Fixture correction #2 (recorded BEFORE the re-run; targets unchanged)
defer-bench-second exposed the deeper error: `client create-keyspace`
is the LEGACY path — the workload wrote to the METADATA node's primary
engine, never to a data group (data-engine syncs ~0.0003/op strict).
Consequences, published honestly: (a) defer-bench-first/second T1/T3
deltas were run-to-run noise on an unaffected path; (b) the
proposal-batching increment's bench ALSO measured the legacy path and
never exercised the aggregator (its published FAILED verdicts stand,
but their diagnosis line "Ready-persist already amortizes" applied to
the legacy engine; the packet's numbers remain what they are — raw and
retained). Correction: the bench fixture now creates a DATA-GROUP
keyspace (create-data-group 1,2,3 + create-data-keyspace) exactly like
the e2es, and the workload targets it. Predeclared ratios unchanged.
Also fixed: measure-second's stage-trace conclusions were about the
DATA-GROUP path all along? NO — measure-second also used legacy
create-keyspace... its write_stage_trace lives on drivers of ALL groups
including the metadata driver; the sampled groups WERE the metadata
group's applies. The disk-bound two-serial-fsync conclusion holds for
the legacy path; the data-group path shares the same driver/apply/WAL
machinery, so the lever transfers — but the corrected bench must prove
it ON the data-group path.

## Methodology refinement (before the accepted run; ratios unchanged)
- 100ms unsynced-age bound added to the deferral (bench-fourth showed
  4MiB-window dirty accumulation entangling OTHER files' fsyncs in one
  journal commit: c1 p99 +939ms; the age bound restored T3 to 0ms).
- Median-of-3 repeats per trial (observed single-window throughput
  swings 0.82x-1.67x on this disk). All raw repeats retained.
- Setup retries for idempotent create verbs (metadata apply can stall
  10s under disk pressure). Runs retained: defer-bench-first (inactive
  policy: set before enable_segmentation), -second (legacy-path fixture
  error), -third (policy ordering fixed? no — third WAS the data-group
  fixture with inert policy), -fourth (active, T1 1.67x T2 1933x T3
  FAIL +939ms), -fifth/-sixth (flaked runs), -seventh (age-bounded: T1
  1.09x T2 8.47x T3 0ms).
