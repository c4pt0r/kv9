#!/usr/bin/env python3
"""Write-path measurement (task #32 phase A): where does C=32 write latency
go? Runs one 3-voter fixture on the TRACED binary (write-stage-tracing +
write-path-diagnostics), drives the standard C=32 put workload, and
captures every node's write_stage_trace, write_path_diagnostics, queue
metrics and the client-side report. Observation only: no acceptance, no
targets — this run SELECTS the next increment's scope.
"""
import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import time


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def fields(text):
    return dict(line.split('=', 1) for line in text.splitlines() if '=' in line)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin', type=Path, required=True)
    parser.add_argument('--workload-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--base-port', type=int, default=27180)
    parser.add_argument('--measure-ms', type=int, default=8000)
    args = parser.parse_args()
    binary = args.bin.resolve()
    workload = args.workload_dir.resolve() / 'kv9-workload'
    manifest = args.workload_dir.resolve() / 'build.json'
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    addresses = {i: f'127.0.0.1:{args.base_port+i}' for i in (1, 2, 3)}
    env = dict(os.environ, KV9_CLUSTER_TOKEN='measure-cluster',
               KV9_CLIENT_TOKENS='admin=measure-client', KV9_CLIENT_TOKEN='measure-client',
               KV9_BOOTSTRAP_TOKEN='measure-bootstrap')
    processes, handles = {}, []

    def command(label, *arguments):
        result = subprocess.run([str(binary), *map(str, arguments)], env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        (out / f'{label}.log').write_text(result.stdout)
        require(result.returncode == 0, f'{label}: {result.stdout[-300:]}')
        return dict(word.split('=', 1) for word in result.stdout.split() if '=' in word)

    def start(node):
        log = (out / f'node-{node}.log').open('w')
        handles.append(log)
        processes[node] = subprocess.Popen(
            [str(binary), 'start', '--node-id', str(node), '--addr', addresses[node],
             '--data-dir', str(out / f'n{node}')], env=env, stdout=log, stderr=subprocess.STDOUT)

    def status(node):
        path = out / f'n{node}/status'
        if not path.exists() or node not in processes:
            return {}
        value = fields(path.read_text())
        return value if value.get('pid') == str(processes[node].pid) else {}

    def wait(label, predicate, seconds=90):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            value = predicate()
            if value:
                return value
            time.sleep(0.05)
        raise RuntimeError(f'timed out: {label}')

    try:
        incarnations = []
        for node in (1, 2, 3):
            guard = socket.socket()
            guard.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            guard.bind(('127.0.0.1', args.base_port + node))
            prepared = command(f'prepare-{node}', 'store-prepare', '--node-id', node,
                               '--data-dir', out / f'n{node}')
            incarnations.append(f"{node}={prepared['store_incarnation']}")
            guard.close()
        root_file = out / 'root.bin'
        command('root-create', 'root-create', '--output', root_file,
                '--voters', ','.join(f'{n}@{addresses[n]}' for n in (1, 2, 3)),
                '--store-incarnations', ','.join(incarnations))
        for node in (1, 2, 3):
            command(f'init-{node}', 'init', '--root', root_file, '--node-id', node,
                    '--data-dir', out / f'n{node}')
        for node in (1, 2, 3):
            start(node)
        leader = wait('leader', lambda: next(
            (n for n in processes if status(n).get('role') == 'leader'
             and status(n).get('endpoint_ready') == 'true'), None))
        receipt = command('create-keyspace', 'client', 'create-keyspace',
                          '--addr', addresses[leader], '--name', 'measure', '--api-type', 'raw')
        keyspace = int(receipt['keyspace_id'])
        config = dict(
            version=1, rpc_transport='tonic_stream',
            client=dict(version=1,
                        peers=[dict(node_id=n, address=a) for n, a in addresses.items()],
                        keyspace_id=keyspace, epoch_conf_ver=1, epoch_version=1,
                        max_in_flight=32, max_attempts=6, deadline_ms=1500,
                        retry_backoff_ms=5),
            mode='performance', run_id='measure-c32', keyspace_name='measure',
            seed=41, workers=32, keys=8, value_bytes=128,
            mix=dict(get=0, put=100, delete=0), warmup_operations=32,
            max_operations=1_000_000, measure_ms=args.measure_ms, interval_ms=0,
            history_bytes=0)
        (out / 'config.json').write_text(json.dumps(config, indent=2))
        log = (out / 'workload.log').open('w')
        process = subprocess.Popen(
            [str(workload), '--config', out / 'config.json',
             '--build-manifest', manifest, '--output', out / 'run'],
            env=env, stdout=log, stderr=subprocess.STDOUT)
        code = process.wait(timeout=args.measure_ms / 1000 + 360)
        log.close()
        require(code == 0, 'workload failed')
        # Capture every node's full status (write_stage_trace,
        # write_path_diagnostics live there) and metrics.json.
        time.sleep(1)
        for node in (1, 2, 3):
            (out / f'status-{node}.txt').write_text((out / f'n{node}/status').read_text())
            (out / f'metrics-{node}.json').write_text((out / f'n{node}/metrics.json').read_text())
        print('MEASURE_CAPTURED')
    finally:
        for node in list(processes):
            process = processes.pop(node)
            if process.poll() is None:
                process.kill()
            process.wait(timeout=10)
        for handle in handles:
            handle.close()


if __name__ == '__main__':
    main()
