"""Check that benchmark role binding refuses unintended production features."""
from pathlib import Path
import copy
import importlib.util
import json
import tempfile
import unittest

P = Path(__file__).resolve().parent
R = Path('/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first/build')
spec = importlib.util.spec_from_file_location('current_write_driver', P / 'matched-driver.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)

class FeatureBindingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=P)
        self.path = Path(self.temp.name) / 'cargo.jsonl'
        self.addCleanup(self.temp.cleanup)

    def rows(self, variant):
        return [json.loads(line) for line in (R / variant / 'kv9-cargo.jsonl').read_text().splitlines()]

    def check(self, rows, role):
        self.path.write_text(''.join(json.dumps(row) + '\n' for row in rows))
        return driver.cargo_server(self.path, expected_features=driver.SERVER_FEATURES[role])

    def test_both_real_builds_match_only_their_intended_role(self):
        for role, variant, other in [('old', 'default', 'new'), ('new', 'preallocated', 'old')]:
            with self.subTest(role=role):
                rows = self.rows(variant)
                self.check(rows, role)
                with self.assertRaisesRegex(ValueError, 'unexpected-feature'):
                    self.check(rows, other)

    def test_unintended_feature_combinations_are_rejected(self):
        for variant, role, crate, features in [
            ('preallocated', 'new', 'kv9_engine', []),
            ('preallocated', 'new', 'kv9', []),
            ('preallocated', 'new', 'kv9', ['wal-payload-preallocation', 'write-stage-tracing']),
            ('preallocated', 'new', 'kv9_raft', ['experimental-leader-lease']),
            ('preallocated', 'new', 'kv9_server', ['rpc-experiment']),
            ('default', 'old', 'kv9_engine', ['wal-payload-preallocation']),
        ]:
            with self.subTest(variant=variant, crate=crate, features=features):
                rows = self.rows(variant)
                selected = [r for r in rows if r.get('reason') == 'compiler-artifact' and r.get('target', {}).get('name') == crate]
                self.assertEqual(len(selected), 1)
                selected[0]['features'] = features
                with self.assertRaisesRegex(ValueError, 'unexpected-feature'):
                    self.check(rows, role)

    def test_ambiguous_or_incomplete_cargo_artifacts_are_rejected(self):
        for mode in ['duplicate-artifact', 'missing-artifact', 'unsuccessful', 'duplicate-completion']:
            with self.subTest(mode=mode):
                rows = self.rows('preallocated')
                index = next(i for i, row in enumerate(rows) if row.get('target', {}).get('name') == 'kv9_engine')
                if mode == 'duplicate-artifact':
                    rows.insert(index, copy.deepcopy(rows[index]))
                elif mode == 'missing-artifact':
                    del rows[index]
                elif mode == 'unsuccessful':
                    rows[-1]['success'] = False
                else:
                    rows.append(copy.deepcopy(rows[-1]))
                with self.assertRaises(ValueError):
                    self.check(rows, 'new')

if __name__ == '__main__':
    unittest.main(verbosity=2)
