"""Derive a matching current-source/default-feature comparison from the accepted write screen."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

P = Path(__file__).resolve().parent
O = Path('/mnt/data/kv9-work/upper-bound-requalified-preparation-20260915-first')
R = Path('/mnt/data/kv9-work/wal-preallocation-runtime-20260915-first')
SMOKE = '/mnt/data/kv9-work/wal-preallocation-performance-smoke-20260915-first'
TIMING = '/mnt/data/kv9-work/wal-preallocation-performance-timing-20260915-first'
REV = '86aa6fc07d82f4d49b43fbfe309e0e5c20276da5'

def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def write(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert p.read_text() == value, 'refusing to overwrite different retained input: ' + str(p)
        return
    with p.open('x') as f:
        f.write(value)

def save(p, value):
    write(p, json.dumps(value, indent=2, sort_keys=True) + '\n')

builds = {role: read(R / 'build' / variant / 'build.json') for role, variant in [('old', 'default'), ('new', 'preallocated')]}
assert all(b['complete'] and not b['dirty'] and b['revision'] == REV for b in builds.values())
assert builds['old']['sources'] == builds['new']['sources']
assert read(R / 'recovery-audit.json')['complete']
subs = {
    str(O): str(P),
    '/mnt/data/kv9-work/upper-bound-requalified-smoke-20260915-first': SMOKE,
    '/mnt/data/kv9-work/upper-bound-requalified-timing-20260915-first': TIMING,
    '/tmp/kv9-crc-main-bd42-baseline-20260914-first': str(R / 'source'),
    '/tmp/kv9-receipt-upper-bound-20260915-first': str(R / 'source'),
    '/tmp/kv9-crc-main-integration-release-20260914-first': str(R / 'build/default'),
    '/tmp/kv9-upper-bound-release-20260915-first': str(R / 'build/preallocated'),
    'bd42e60f84657e22e36e34924a5c80a08eac623a': REV,
    'e2e23cca5e70a9ea0cc241877b3b35b5b6433d27': REV,
    '106f517c84fabe790ea139f3c18661e14447abd9e257fdd6ba82bfabe6796eb9': builds['old']['binary_sha256'],
    '6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49': builds['new']['binary_sha256'],
    '9005c064129e4a70b9de881e46074c4b7b5ec493e482095dd6fa7884fccdfb4a': sha(R / 'build/default/build.json'),
    'e6f3ebab9510cdf87c1e521d5b64578c224a08842956998cb2c9690f67498cb7': sha(R / 'build/preallocated/build.json'),
    'kv9-upper-bound-requalified-client-data-volume-write-v1': 'kv9-wal-preallocation-current-source-write-v1',
}

def replace(s):
    for a, b in sorted(subs.items(), key=lambda pair: -len(pair[0])):
        s = s.replace(a, b)
    return s

names = ['matched-driver.py', 'audit.py', 'run_fixture.py', 'compressed_retention.py', 'retention_audit.py',
         'isolate-and-run.py', 'driver-arguments.json', 'storage-policy.json', 'protocol.json',
         'ROOT-COMMANDS.json', 'readiness/bind-roles.py', 'readiness/check-smoke-v3.py',
         'readiness/runtime-commands.json', 'readiness/role-inputs.json']
texts = {name: replace((O / name).read_text()) for name in names}
for name in names:
    write(P / 'original' / name, (O / name).read_text())

commands = {role: b['command'] for role, b in builds.items()}
features = {'old': {name: [] for name in ['kv9', 'kv9_engine', 'kv9_raft', 'kv9_server']},
            'new': {'kv9': ['wal-payload-preallocation'], 'kv9_engine': ['wal-payload-preallocation'],
                    'kv9_raft': [], 'kv9_server': []}}
s = texts['matched-driver.py']
tree = ast.parse(s)
command = next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SERVER_COMMAND' for t in n.targets))
s = s.replace(ast.get_source_segment(s, command), 'SERVER_COMMANDS = ' + repr(commands) + '\nSERVER_FEATURES = ' + repr(features))
edits = {
    'def cargo_server(path, retained=None):': 'def cargo_server(path, retained=None, expected_features=None):',
    '    selected = {}\n    for name in ("kv9", "kv9_engine", "kv9_raft", "kv9_server"):\n':
        '    selected = {}\n    expected_features = SERVER_FEATURES["old"] if expected_features is None else expected_features\n    require(set(expected_features) == set(SERVER_FEATURES["old"]), "unexpected server feature graph")\n    for name in ("kv9", "kv9_engine", "kv9_raft", "kv9_server"):\n',
    'rows[0]["features"] == []': 'rows[0]["features"] == expected_features[name]',
    'declaration["command"] == SERVER_COMMAND': 'declaration["command"] == SERVER_COMMANDS[name]',
    'selected = cargo_server(cargo)': 'selected = cargo_server(cargo, expected_features=SERVER_FEATURES[name])',
    'rustc=manifest["rustc"], command=SERVER_COMMAND,': 'rustc=manifest["rustc"], command=SERVER_COMMANDS[name],',
    'ambiguous/nondefault/nonrelease server artifact: ': 'ambiguous/unexpected-feature/nonrelease server artifact: ',
}
for before, after in edits.items():
    assert s.count(before) == 1, before
    s = s.replace(before, after)
texts['matched-driver.py'] = s

# The independent reader derives its expected feature graph independently.
s = texts['audit.py']
before = "selected[0]['features']==[] and selected[0]['profile']['opt_level']=='3'"
assert s.count(before) == 1
s = s.replace(before, "selected[0]['features']==(['wal-payload-preallocation'] if role=='new' and name in ('kv9','kv9_engine') else []) and selected[0]['profile']['opt_level']=='3'")
texts['audit.py'] = s

def content_hash(name):
    return hashlib.sha256(texts[name].encode()).hexdigest()

# Update each downstream pin after its input is final; the graph is acyclic.
for upstream, downstream in [
    ('compressed_retention.py', ['matched-driver.py', 'audit.py', 'readiness/check-smoke-v3.py']),
    ('retention_audit.py', ['audit.py']),
    ('isolate-and-run.py', ['audit.py']), ('driver-arguments.json', ['audit.py']),
    ('matched-driver.py', ['audit.py', 'readiness/check-smoke-v3.py', 'ROOT-COMMANDS.json', 'readiness/runtime-commands.json']),
    ('audit.py', ['readiness/check-smoke-v3.py'])]:
    for target in downstream:
        texts[target] = texts[target].replace(sha(O / upstream), content_hash(upstream))

protocol = json.loads(texts['protocol.json'])
protocol.update(protocol_id='kv9-wal-preallocation-current-source-write-v1',
                driver_sha256=content_hash('matched-driver.py'), auditor_sha256=content_hash('audit.py'),
                runtime_ready=False, capacity_qualified=False, chaos_accepted=False, contracts_executed=False,
                role_labels={'old': 'current source, default features', 'new': 'same source, WAL payload preallocation'},
                control_revision=REV, candidate_revision=REV,
                decision_scope='Same-source default versus preallocation only. Prior recovery is complete; actual candidate Chaos must pass before timing. No new Redis run is included in this unchanged native eight-smoke/sixteen-timed screen.',
                prior_source_proof='docs/WAL-PAYLOAD-PREALLOCATION.md at fb9d390; unchanged Rust/Cargo/proof inputs',
                server_feature_graph=features, server_commands=commands)
for role in ['old', 'new']:
    protocol['server_pins'][role].update(revision=REV, binary_sha256=builds[role]['binary_sha256'],
        manifest_sha256=sha(R / 'build' / ('default' if role == 'old' else 'preallocated') / 'build.json'))
for key, name in [('helper', 'compressed_retention.py'), ('independent_reader', 'retention_audit.py')]:
    protocol['compressed_retention'][key] = {'bytes': len(texts[name].encode()), 'sha256': content_hash(name)}
texts['protocol.json'] = json.dumps(protocol, indent=2, sort_keys=True) + '\n'
roles = json.loads(texts['readiness/role-inputs.json'])
roles.update(fresh_role_gate_executed=False, runtime_ready=False, source_revision=REV)
for role, variant in [('old', 'default'), ('new', 'preallocated')]:
    b = builds[role]
    roles['roles'][role].update(revision=REV, source_files=len(b['sources']), source_tree_sha256=b['source_tree_sha256'],
        manifest={'path': str(R / 'build' / variant / 'build.json'), 'bytes': (R / 'build' / variant / 'build.json').stat().st_size,
                  'sha256': sha(R / 'build' / variant / 'build.json')},
        scope='Original retained same-source release; exact role-specific command and feature graph required.')
texts['readiness/role-inputs.json'] = json.dumps(roles, indent=2, sort_keys=True) + '\n'
root_commands = json.loads(texts['ROOT-COMMANDS.json'])
root_commands.update(candidate_chaos_pending=True, runtime_commands_released=False,
    source_binding_required='Current same-source default/feature servers and unchanged already qualified fixed client. Exact role-specific graph required.',
    serial_order=['current_role_feature_controls_and_readback', 'actual_candidate_chaos_acceptance', 'fresh_capacity_and_exclusivity',
                  'eight_smokes', 'smoke_independent_readback', 'fresh_remaining_capacity', 'sixteen_timed_cohorts', 'full_independent_audit'])
# Old focused checks target a different preparation and are not launch dependencies here.
root_commands.pop('targeted_changed_source_controls', None)
texts['ROOT-COMMANDS.json'] = json.dumps(root_commands, indent=2, sort_keys=True) + '\n'

def functions(s):
    return {n.name: ast.get_source_segment(s, n) for n in ast.parse(s).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}

unchanged = ['native_trial', 'observe_client', 'fresh_drain', 'make_plan', 'verify_client_cargo']
old_functions = functions((O / 'matched-driver.py').read_text())
new_functions = functions(texts['matched-driver.py'])
assert all(old_functions[name] == new_functions[name] for name in unchanged)
for name in ['run_fixture.py', 'compressed_retention.py', 'retention_audit.py', 'isolate-and-run.py', 'storage-policy.json']:
    assert texts[name] == replace((O / name).read_text()), name
for name in ['codec', 'single_frame', 'hash_original', 'tree_inventory', 'no_references', 'close_fixture']:
    assert functions(texts['compressed_retention.py'])[name] == functions((O / 'compressed_retention.py').read_text())[name], name
for key in ['smoke_inventory', 'timed_inventory', 'expected_counts', 'configured_max_attempts', 'effective_server_limits', 'storage_guards']:
    assert protocol[key] == read(O / 'protocol.json')[key], key
for name, text in texts.items():
    if name.endswith('.py'):
        ast.parse(text)
    write(P / name, text)
    write(P / 'diffs' / (name + '.diff'), ''.join(difflib.unified_diff((O / name).read_text().splitlines(True), text.splitlines(True), fromfile=str(O / name), tofile=str(P / name))))
save(P / 'derivation.json', {'complete': True, 'runtime_ready': False, 'substitutions': subs,
    'unchanged_driver_functions': unchanged, 'unchanged_workload_and_storage_guards': True,
    'scope': 'Paths, original current role pins and explicit candidate-only feature/command graph. No builds, clients, servers or codecs executed.',
    'files': {name: {'original_sha256': sha(O / name), 'derived_sha256': sha(P / name)} for name in names}})
print(json.dumps({'complete': True, 'driver_sha256': sha(P / 'matched-driver.py'),
                  'audit_sha256': sha(P / 'audit.py'), 'runtime_ready': False}))
