#!/usr/bin/env python3
"""Publish selected original performance metadata after terminal acceptance."""
import gzip,hashlib,io,json,os,re,stat,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=Path('/mnt/data/kv9-work')
P=BASE/'wal-preallocation-performance-preparation-20260915-first'
E=BASE/'wal-preallocation-performance-execution-20260916-first'
R=BASE/'wal-preallocation-performance-report-20260916-first'
T=BASE/'wal-preallocation-performance-timing-20260915-first'
S=BASE/'wal-preallocation-performance-smoke-20260915-first'
OUT=HERE/'packet-first'
CAP=8*1024**2
TOTAL=80*1024**2
SECRET=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
def read(p):return json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 assert __debug__ and not OUT.exists()
 assert set(os.sched_getaffinity(0))==set(range(6,16))|set(range(22,32))
 timing=read(E/'timing-tool-terminal.json');audit=read(P/'results-first/audit.json');report=read(R/'results-first/summary.json')
 assert timing['session_id']==3737 and timing['exit_code']==0 and timing['complete'] is True
 assert audit['complete'] is True and audit['matched_diagnostic_accepted'] is True and audit['parent_confirmed_session']==3737
 assert audit['successful_arms']==16 and audit['owned_lifetimes_exited']==64 and audit['qualifying_drains']==48
 assert report['complete'] is True and report['timed_cohorts']==16 and report['actual_timing_session']==3737
 assert report['audit_sha256']==pin(P/'results-first/audit.json')['sha256']
 inputs=read(R/'results-first/input-hashes.json');contents={};rows={}
 def add(p,expected=None):
  p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.is_file()
  assert p.suffix in ('.json','.py','.md','.diff','.stdout','.stderr','.txt','.log')
  assert not any(x in p.parts for x in ('.git','target','retention-objects','.aws','.ssh'))
  assert not p.name.startswith('issue') and 'kubeconfig' not in p.name and p.name!='continuation.json'
  st=p.stat();assert stat.S_ISREG(st.st_mode) and st.st_size<=CAP
  b=p.read_bytes();after=p.stat();assert len(b)==st.st_size and all(getattr(after,k)==getattr(st,k)for k in ('st_dev','st_ino','st_size','st_mode','st_mtime_ns','st_ctime_ns')) and not SECRET.search(b)
  assert not b.startswith((b'\x7fELF',b'\x1f\x8b',b'\x28\xb5\x2f\xfd'))
  record=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  if expected is not None: assert record==expected,(str(p),record,expected)
  name=str(p).lstrip('/');contents[name]=b;rows[name]=dict(member=name,source=str(p),**record)
  assert len(rows)<512 and sum(v['bytes']for v in rows.values())<=TOTAL
 for p,b in inputs.items():add(p,b)
 for root in (P/'results-first',R/'results-first'):
  for p in sorted(root.iterdir()):
   if p.is_file():add(p)
 for p in sorted(P.iterdir()):
  if p.is_file() and p.suffix in ('.py','.json','.stdout','.stderr'):add(p)
 for name in ('role-inputs.json','role-binding-current.json','smoke-readback/result.json','runtime-commands.json'):
  add(P/'readiness'/name)
 for root in (E,R):
  for p in sorted(root.iterdir()):
   if p.is_file() and p.suffix in ('.py','.json','.diff','.stdout','.stderr'):
    add(p)
 for p in sorted(T.glob('*.json')):add(p)
 for name in ('matrix.json','plan.json','host.json'):add(S/name)
 for attempt in read(S/'matrix.json')['attempts']:
  add(Path(attempt['directory'])/'run/report.json')
 add(HERE/'package.py');add(HERE/'verify.py')
 manifest=dict(scope='Original reporting and acceptance metadata. Large WAL objects, executables and full source trees remain local; this is not standalone WAL replay.',source_revision='86aa6fc07d82f4d49b43fbfe309e0e5c20276da5',client_binary_sha256='1b8060eb168610328c10a27480de16bd8b2d6805166d8169638f85ceef0992c4',original_files=len(rows),original_bytes=sum(r['bytes']for r in rows.values()),member_cap_bytes=CAP,total_cap_bytes=TOTAL,compressed_cap_bytes=32*1024**2,decoded_tar_cap_bytes=TOTAL,report_inputs_included=len(inputs),members=[rows[n]for n in sorted(rows)])
 blob=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();assert len(blob)<=CAP
 contents['members.json']=blob
 planned=((sum(512+((len(b)+511)//512)*512 for b in contents.values())+1024+10239)//10240)*10240
 assert planned<=TOTAL
 OUT.mkdir();(OUT/'members.json').write_bytes(blob)
 with (OUT/'evidence.tar.gz').open('xb')as target:
  with gzip.GzipFile(filename='',fileobj=target,mode='wb',compresslevel=6,mtime=0)as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT)as archive:
    for name,b in sorted(contents.items()):
     info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(b))
 assert (OUT/'evidence.tar.gz').stat().st_size<=32*1024**2
 for n in ('summary.json','input-hashes.json','PER-REPEAT.md','COMPARISONS.md'):(OUT/n).write_bytes((R/'results-first'/n).read_bytes())
 (OUT/'ANALYSIS.md').write_bytes((R/'results-first/README.md').read_bytes())
 (OUT/'verify.py').write_bytes((HERE/'verify.py').read_bytes())
 for row in rows.values():assert pin(Path(row['source']))=={k:row[k]for k in ('bytes','sha256')}
 result=dict(complete=True,original_files=len(rows),original_bytes=manifest['original_bytes'],archive_members=len(contents),report_inputs_included=len(inputs),archive=pin(OUT/'evidence.tar.gz'),members=pin(OUT/'members.json'))
 (OUT/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
