"""One-shot exact generated-cache retirement; no Cargo or payload operations."""
import collections,fcntl,hashlib,importlib.util,json,os,shutil,stat,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
PLAN=Path('/tmp/kv9-write-release-capacity-tranche-20260915-first/post-dev-cache-plan')
TARGET=Path('/home/dongxu/kv9/target')
LOCKS=[TARGET/'.kv9-retained-build.lock',TARGET/'debug/.cargo-lock',Path('/home/dongxu/.cargo/.package-cache'),Path('/home/dongxu/.cargo/.package-cache-mutate')]
PIN='9f1d7752594e9561cefd4c8750a7cf9fc757aa6e57e4fcb58f084e2ddc322c77'
def need(x,m):
 if not x:raise RuntimeError(m)
def h(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(n,v):
 with (OUT/n).open('x')as f:json.dump(v,f,sort_keys=True,separators=(',',':'));f.write('\n');f.flush();os.fsync(f.fileno())
def sync(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def meta(p):
 s=p.lstat();return dict(path=str(p),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,nlink=s.st_nlink,uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def available():
 s=os.statvfs(OUT);return s.f_bavail*s.f_frsize
need(os.geteuid()==0,'root required');need(set(os.sched_getaffinity(0))==set(range(6,16))|set(range(22,32)),'helper CPUs required')
need(h(OUT/'inputs.json')==PIN,'frozen inputs changed')
inv=json.loads((OUT/'inputs.json').read_text())
for n,pin in inv['files'].items():need(Path(n).stat().st_size==pin['bytes'] and h(n)==pin['sha256'],'plan input changed: '+n)
q=json.loads((PLAN/'qualification.json').read_text());obs=json.loads((PLAN/'observations.json').read_text())
old=load('qualified_reference_reader',Path('/tmp/kv9-published-directory-capacity-actions-preparation-20260915-first/cache-v6/retire.py'))
source=load('current_source_inventory',Path('/home/dongxu/kv9/scripts/build-workload.py'))
heads=json.loads((OUT/'source-heads.json').read_text())
def snapshots():
 result={}
 for name,binding in heads.items():
  source.ROOT=Path(name);row=source.snapshot()
  need(row['revision']==binding['revision'] and not row['dirty'],'exact clean source head changed: '+name)
  result[name]=row
 return result
source_before=snapshots();save('source-before.json',source_before)
protected=json.loads(Path('/tmp/kv9-published-directory-capacity-actions-preparation-20260915-first/cache-v6/scope.json').read_text())['protected']
protected.update({'/tmp/kv9-write-diagnostics-release-default-20260915-second/kv9':'58385b184e3ccac4edd98664620a29cae33b5726bdebb11800ac3b12b7efaef6','/tmp/kv9-write-diagnostics-release-instrumented-20260915-second/kv9':'e8ec4396b9b419c1f3401884bc50fd15a331aa5830fc16c9130ca2513aa6602b'})
protect_before={}
for name,expected in protected.items():
 p=Path(name);m=meta(p);need(h(p)==expected and meta(p)==m,'protected binary changed: '+name);protect_before[name]=dict(identity=m,sha256=expected)
save('protected-before.json',protect_before)
fds=[];locked=[];deleted=[];removed_dirs=[];failure=None;started=time.monotonic();before=None
try:
 for p in LOCKS:
  need(p.is_file() and not p.is_symlink(),'existing lock required: '+str(p))
  fd=os.open(p,os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);fds.append(fd);locked.append(meta(p))
 save('locks.json',locked)
 need(snapshots()==source_before,'source changed before mutation')
 roots=[Path(r['path']) for r in q['main_candidates']]
 groups={};directory_meta={};seen=set();per_path=[]
 for root,expected in zip(roots,q['main_candidates']):
  need(root.resolve()==root and root.is_relative_to(TARGET) and root.parts[len(TARGET.parts)] in ['debug','doc'],'exact generated scope escaped')
  paths=[root]
  if root.is_dir():paths += [Path(d)/n for d,ds,fs in os.walk(root,followlinks=False) for n in ds+fs]
  allocation=0
  for p in paths:
   m=meta(p);need(p.resolve()==p and m['uid']==1000 and (stat.S_ISREG(m['mode']) or stat.S_ISDIR(m['mode'])),'unsafe generated inode')
   key=m['device'],m['inode']
   if key not in seen:allocation+=m['blocks']*512;seen.add(key)
   if stat.S_ISDIR(m['mode']):directory_meta[str(p)]=m
   else:groups.setdefault(key,[]).append(m)
  need(allocation==expected['allocated_bytes'],'frozen allocated selection changed: '+str(root))
  per_path.append(dict(path=str(root),allocated_bytes=allocation))
 named=json.loads((PLAN/'named-targets.json').read_text())
 need(named['complete'] and len(named['rows'])==18 and not named['excluded'],'exact reviewed 18 named target set required')
 for item in named['rows']:
  for field in ['fingerprint','dependency']:
   p=Path(item[field]['path']);need(p.stat().st_size==item[field]['bytes'] and h(p)==item[field]['sha256'],'named Cargo provenance changed')
  for frozen in item['aliases']:
   p=Path(frozen['path']);m=meta(p)
   expected=dict(frozen);expected['blocks']=expected.pop('allocated_bytes')//512
   need(m==expected and p.resolve()==p and p.parent in [TARGET/'debug/deps',TARGET/'debug/examples'] and stat.S_ISREG(m['mode']) and m['uid']==1000,'named alias identity/scope changed')
   key=m['device'],m['inode'];need(key not in seen,'named alias overlaps base scope')
   groups.setdefault(key,[]).append(m)
  key=item['aliases'][0]['device'],item['aliases'][0]['inode'];seen.add(key)
 exclusions=q['external_link_exceptions'];excluded={m['paths'][0] for m in exclusions};selected=[]
 for key,aliases in groups.items():
  aliases={m['path']:m for m in aliases};rows=list(aliases.values())
  need(all(m['nlink']==rows[0]['nlink'] for m in rows),'link race')
  if rows[0]['nlink']!=len(rows):
   need(set(aliases)==excluded and len(rows)==1,'new external hard link')
   e=exclusions[0];m=rows[0];need((m['device'],m['inode'],m['bytes'],m['blocks']*512,m['nlink'])==(e['device'],e['inode'],e['bytes'],e['allocated_bytes'],e['nlink']),'external exception changed');continue
  need(key not in {(r['identity']['device'],r['identity']['inode'])for r in protect_before.values()},'protected binary alias')
  selected.append(rows)
 total=sum(g[0]['blocks']*512 for g in selected);need(total==named['combined_regular_allocated_ceiling_bytes']==6539509760,'regular-file allocation changed')
 selection=dict(plan_inventory_sha256=PIN,paths=per_path,groups=selected,retained_external_exception=exclusions,regular_allocated_bytes=total,selected_file_count=sum(len(g) for g in selected),directories=list(directory_meta.values()))
 data=json.dumps(selection,sort_keys=True,separators=(',',':')).encode();need(len(data)<24*1024**2,'selection metadata cap before unlink')
 save('selection.json',selection)
 fp=[m for g in selected for m in g if '/.fingerprint/' in m['path']]
 # Preserve the exact small dep-info supporting each newly selected named binary.
 for item in named['rows']:
  p=Path(item['dependency']['path']);d=OUT/'named-dep-info'/p.name;d.parent.mkdir(exist_ok=True);shutil.copyfile(p,d)
  need(d.stat().st_size==item['dependency']['bytes'] and h(d)==item['dependency']['sha256'],'retained dep-info differs')
  with d.open('rb')as f:os.fsync(f.fileno())
 need(sum(m['bytes'] for m in fp)<4*1024**2,'fingerprint preservation cap')
 for m in fp:
  p=Path(m['path']);d=OUT/'fingerprints'/p.relative_to(TARGET);d.parent.mkdir(parents=True,exist_ok=True);need(meta(p)==m,'fingerprint changed');shutil.copyfile(p,d);need(h(p)==h(d) and meta(p)==m,'fingerprint preservation readback differs')
  with d.open('rb')as f:os.fsync(f.fileno())
 for d,ds,fs in os.walk(OUT,topdown=False):sync(Path(d))
 keys={(g[0]['device'],g[0]['inode'],stat.S_IFREG)for g in selected}
 refs=old.references([str(TARGET)],keys);save('references-before.json',refs);need(refs['complete'] and not refs['hits'],'live compiler/cache reference')
 for g in selected:
  for m in g:need(meta(Path(m['path']))==m,'selected inode changed before unlink')
 need(snapshots()==source_before,'source changed before first unlink')
 for p,r in protect_before.items():need(meta(Path(p))==r['identity'],'protected identity changed before unlink')
 before=available();need(before>=8*1024**3,'8 GiB floor');save('pre-unlink.json',dict(available_bytes=before,selected_regular_allocated_bytes=total,files=selection['selected_file_count'],maximum_selection_json_bytes=24*1024**2,maximum_fingerprint_bytes=4*1024**2))
 # Invalidate only selected first-party Cargo fingerprints before compiled artifacts.
 selected.sort(key=lambda g:(0 if '/.fingerprint/' in g[0]['path'] else 1,g[0]['path']))
 with (OUT/'deletions.jsonl').open('x')as log:
  for group in selected:
   need(time.monotonic()-started<900 and available()>=8*1024**3,'cleanup time/floor guard')
   left=len(group)
   for m in group:
    p=Path(m['path']);now=meta(p)
    need(all(now[k]==m[k] for k in ['device','inode','mode','bytes','blocks','uid','gid','mtime_ns']) and now['nlink']==left,'inode/link changed during group unlink')
    if left==len(group):need(now['ctime_ns']==m['ctime_ns'],'inode ctime changed before group unlink')
    p.unlink();deleted.append(str(p));left-=1
    log.write(json.dumps(dict(path=str(p),device=m['device'],inode=m['inode'],remaining_links=left,observed_ns=time.time_ns()),sort_keys=True)+'\n')
   log.flush();os.fsync(log.fileno())
 for p in sorted(map(Path,directory_meta),key=lambda p:len(p.parts),reverse=True):
  # Remove only known, now-empty generated directories; never their parent profile.
  try:p.rmdir();removed_dirs.append(str(p))
  except OSError:pass
 sync(TARGET/'debug');sync(TARGET)
 save('removed-directories.json',removed_dirs)
 source_after=snapshots();save('source-after.json',source_after);need(source_after==source_before,'source changed after cleanup')
 after_protected={}
 for name,r in protect_before.items():
  p=Path(name);need(meta(p)==r['identity'] and h(p)==r['sha256'],'protected source/binary changed');after_protected[name]=r
 save('protected-after.json',after_protected)
 need(all(not Path(p).exists() for p in deleted),'selected path recreated')
 for e in exclusions:
  p=Path(e['paths'][0]);m=meta(p);need((m['device'],m['inode'],m['bytes'],m['blocks']*512,m['nlink'])==(e['device'],e['inode'],e['bytes'],e['allocated_bytes'],e['nlink']),'external exception changed after cleanup')
 refs=old.references([str(TARGET)],keys);save('references-after.json',refs);need(refs['complete'] and not refs['hits'],'new target owner during cleanup')
except BaseException as e:
 failure=repr(e);raise
finally:
 after=available()
 for fd in reversed(fds):os.close(fd)
 record=dict(complete=failure is None,lock_released=True,lock_paths=[str(p)for p in LOCKS],failure=failure,deleted_files=len(deleted),removed_directories=len(removed_dirs),available_before=before,available_after=after,observed_available_increase=None if before is None else after-before,elapsed_seconds=time.monotonic()-started,scope='Exact generated cache only; original evidence/source/offline dependencies/retained binaries preserved.')
 save('result.json',record);print(json.dumps(record),flush=True)
