"""Read-only finite 056..060 metadata eligibility and capacity proposal."""
import hashlib,json,os,stat,time
from pathlib import Path
O=Path(__file__).parent;P=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first');E=Path('/tmp/kv9-cross-voter-multicohort-execution-20260915-first')
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p.stat().st_size<4*1024**2
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,v):
 with (O/n).open('x')as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def meta(p):
 s=Path(p).lstat();return dict(allocated_bytes=s.st_blocks*512,bytes=s.st_size,ctime_ns=s.st_ctime_ns,device=s.st_dev,gid=s.st_gid,inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns,nlink=s.st_nlink,uid=s.st_uid)
rows=[];seen=set()
for i in range(56,61):
 f=P/'selections'/f'{i:03}.json';s=json.loads(f.read_text());assert s['group_ordinal']==i
 assert not os.path.lexists(s['root']) and not os.path.lexists(E/f'{i:03}'),'already-started selected ordinal'
 targets={v['target']for v in s['pairs']};observed=[];allocated=0
 for m in s['members']:
  p=Path(m['path']);now=meta(p);assert now==m['identity'] and p.resolve()==p and stat.S_ISREG(now['mode'])
  key=now['device'],now['inode'];assert key not in seen;seen.add(key)
  if m['id']in targets:allocated+=now['allocated_bytes']
  observed.append(dict(id=m['id'],path=str(p),identity=now,target=m['id']in targets))
 assert len(observed)==s['original_object_count']==72 and len(targets)==s['target_count']==28 and allocated==s['target_allocated_bytes']
 pins=[]
 for bound in s['metadata']:
  if Path(bound['path']).name in ['retention-catalog.json','retention-original.json','summary.json','cleanup.json']:
   actual=pin(bound['path']);assert actual==bound;pins.append(actual)
 rows.append(dict(ordinal=i,selection=pin(f),screen=s['screen'],root=s['root'],cohort=s['cohort'],transaction_and_execution_absent=True,original_object_count=len(observed),target_count=len(targets),eligible_target_allocated_bytes=allocated,logical_cohort_bytes=s['logical_cohort_bytes'],encoded_cohort_bytes=s['encoded_cohort_bytes'],limits=s['limits'],metadata_authorities=pins,original_reader=s['legacy_reader'],current_readback_reader=s['readback_reader'],objects=observed))
free=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize;launch=25778192384;target=launch+1024**3;gap=max(0,target-free);ceil=0;minimum=None;prefix=[]
for row in rows:
 ceil+=row['eligible_target_allocated_bytes'];prefix.append(dict(last=row['ordinal'],target_allocation_ceiling=ceil,ceiling_minus_current_margin_gap=ceil-gap))
 if minimum is None and ceil>=gap:minimum=row['ordinal']
old=json.loads(Path('/tmp/kv9-write-next-cache-cleanup-20260915-first/retention-tranche-proposal.json').read_text())
commands={}
for name,argv in old['existing_command_templates'].items():
 argv=list(argv);argv[argv.index('--ordinal')+1]='56';commands[name.replace('040','056')]=argv
history=Path('/tmp/kv9-write-release-capacity-tranche-20260915-first');result_files=list(history.glob('result-*.json'));assert len(result_files)==1
prior=json.loads(result_files[0].read_text());assert prior['next_ordinal']==56
proposal=dict(complete=True,planning_only=True,observed_ns=time.time_ns(),payload_read_or_hash=False,codecs_or_retirement_executed=False,prior_terminal_prefix=dict(tool=pin(history/'tool-terminal.json'),accepted_summary=pin(history/'accepted-summary.json'),prefix_integration=pin(result_files[0])),actual_cleanup_result=pin(O/'result.json'),fresh_available_bytes=free,release_launch_bytes=launch,release_gap_bytes=max(0,launch-free),reporting_build_prep_margin_bytes=1024**3,actual_space_stop_bytes=target,gap_including_margin_bytes=gap,minimum_contiguous_prefix_by_impossible_zero_cost_ceiling=None if minimum is None else list(range(56,minimum+1)),proposed_finite_ordinals=list(range(56,61)),prefix_ceilings=prefix,total_target_allocation_ceiling_bytes=ceil,overhead_allowance_at_ceiling_bytes=ceil-gap,rows=rows,exact_existing_templates=commands,required_execution_boundary='Separate future retained tranche only; bind actual completed000..055, its existing prefix receipt and every original selection/helper/reader pin; run existing stage/verify, independent verify_release, exact restore/full corrected readback/final COLD serially. Use actual free-space stop at a complete COLD boundary; no061, no old85GB controller resume, no successful cohort replay.',preservation='All original caps, child/identity/hash/receipt/time/accounting gates stay.8GiB floor; each selected launch10,754,195,456B plus existing controller metadata allowance. Charge new reporting root separately. No original payload mutation in this proposal.',capacity_limit='Ceilings are not predicted or reclaimed savings.056..059 is mathematically insufficient for the current release-plus-margin gap even at zero patch/metadata cost.056..060 is the smallest eligible contiguous scope; actual patch/retained-codec/report allocation must fit its remaining allowance, otherwise stop and report actual space without expanding scope.')
save('retention-056-060-proposal.json',proposal)
print(json.dumps({k:proposal[k]for k in ['fresh_available_bytes','release_gap_bytes','gap_including_margin_bytes','total_target_allocation_ceiling_bytes','overhead_allowance_at_ceiling_bytes','minimum_contiguous_prefix_by_impossible_zero_cost_ceiling']}));print('validated_exact_object_metadata',len(seen))
