from pathlib import Path
import json,hashlib
p=Path(__file__).parent;old=Path('/tmp/kv9-cross-voter-multicohort-continuation-root-20260915-first');prep=Path('/tmp/kv9-cross-voter-multicohort-continuation-preparation-20260915-first');pub=Path('/tmp/kv9-retention-continuation-terminal-publication-20260915-first');g=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first')
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();pin=lambda f:dict(bytes=f.stat().st_size,sha256=h(f))
files=[prep/'campaign.py',prep/'inventory.json',old/'status.json',old/'binding.json',pub/'tool-terminal.json',pub/'completion.json',pub/'child-terminal.json',pub/'controller-result.json',g/'group-plan.json',g/'code-pins.json']
for i in range(14,40):files += [old/f'{i:03d}'/'complete.json',old/f'{i:03d}'/'release.json']
for i in range(40,56):files.append(g/'selections'/f'{i:03d}.json')
files += [Path('/tmp/kv9-cross-voter-multicohort-campaign-root-20260915-first/status.json'),Path('/tmp/kv9-cross-voter-multicohort-campaign-failure-013-20260915-first/tool-terminal.json')]
with (p/'inputs.json').open('x')as f:json.dump(dict(schema=1,files={str(f):pin(f)for f in files},own_sources={n:pin(p/n)for n in ['tranche.py','test_tranche.py','controls-terminal.json']},scope='Exact successful000..039 authority; fresh finite040..055 only.',first=40,last=55,actual_available_stop_bytes=26851934208),f,indent=2,sort_keys=True);f.write('\n')
argv=['sudo','-n','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','taskset','-c','6-15,22-31','python3',str(p/'tranche.py'),'--inputs-sha256',h(p/'inputs.json')]
(p/'invocation.json').write_text(json.dumps(dict(argv=argv,source_sha256=h(p/'tranche.py'),inputs_sha256=h(p/'inputs.json'),controls_terminal='eeff2d/0',scope='Authorized serial capacity tranche; no main source or old controller edits.'),indent=2)+'\n')
print(json.dumps(dict(source_sha256=h(p/'tranche.py'),inputs_sha256=h(p/'inputs.json'),files=len(files),stop_bytes=26851934208)))
