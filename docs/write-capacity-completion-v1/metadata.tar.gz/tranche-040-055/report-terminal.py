"""Summarize actual completed tranche metadata; no codec or payload readback."""
import json,hashlib,os,time
from pathlib import Path
P=Path(__file__).parent
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
pin=lambda f:dict(path=str(f),bytes=f.stat().st_size,sha256=h(f))
read=lambda f:json.loads(f.read_text())
status=read(P/'status.json');assert status['state']=='COMPLETE'
result_files=sorted(P.glob('result-*.json'));assert len(result_files)==1
result=read(result_files[0]);records=[read(P/f'{i:03d}'/'complete.json')for i in result['new_completed_ordinals']]
assert result['complete'] and result['next_ordinal']<=56 and result['new_completed_ordinals']==list(range(40,result['next_ordinal']))
inputs=read(P/'inputs.json')
for path,expected in inputs['files'].items():
 f=Path(path);assert f.stat().st_size==expected['bytes'] and h(f)==expected['sha256']
for name,expected in inputs['own_sources'].items():
 f=P/name;assert f.stat().st_size==expected['bytes'] and h(f)==expected['sha256']
g=read(Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first/group-plan.json'))
cohorts=[];objects=logical=targets=codec_receipts=0
for r in records:
 i=r['ordinal'];row=g['rows'][i];s=read(Path(row['selection']['path']));root=Path(row['root']);accept=r['acceptance'];reader=Path(accept['readback_path']);rb=read(reader)
 assert accept['state']=='COLD' and r['complete'] and h(reader)==accept['readback_sha256'] and h(root/'retire-2/result.json')==accept['cold_sha256']
 assert len(rb['decoder_receipts'])==s['original_object_count']
 assert all(x['complete'] and x['exit_code']==0 and x['absent'] for x in rb['decoder_receipts'])
 objects+=s['original_object_count'];logical+=s['logical_cohort_bytes'];targets+=s['target_count'];codec_receipts+=9*s['target_count']+len(rb['decoder_receipts'])
 cohorts.append(dict(ordinal=i,complete_record=pin(P/f'{i:03d}'/'complete.json'),release=pin(P/f'{i:03d}'/'release.json'),acceptance=accept,objects=s['original_object_count'],logical_bytes=s['logical_cohort_bytes'],targets=s['target_count']))
base=result['baseline_accounting'];last=result['current_accounting'];v=os.statvfs(P);free=v.f_bavail*v.f_frsize
summary=dict(complete=True,reason=result['reason'],new_completed_ordinals=result['new_completed_ordinals'],next_ordinal=result['next_ordinal'],historical_prefix_unchanged=True,source_inputs_unchanged=True,old_controller_files_unchanged=True,no_056_started=not Path(g['rows'][56]['root']).exists(),cohorts=cohorts,original_objects=objects,logical_bytes_full_readback=logical,engine_wal_targets=targets,successful_fresh_codec_receipts=codec_receipts,codec_scope='Existing accepted stage/verify/restore and full corrected reader receipts; no new decode or lifetime replay.',prefix_integration_receipt=pin(result_files[0]),baseline_available_bytes=base['actual_available_bytes'],final_boundary_available_bytes=last['actual_available_bytes'],fresh_available_bytes=free,release_launch_bytes=25778192384,release_gap_bytes=max(0,25778192384-free),margin_stop_bytes=26851934208,margin_stop_gap_bytes=max(0,26851934208-free),new_conservative_net_allocated_reduction_bytes=last['conservative_net_allocated_change_bytes']-base['conservative_net_allocated_change_bytes'],historical_accounting_scope_preserved=True,new_reporting_allocation_after_final_boundary_not_included=True,scope='Finite040..055 completed transaction acceptance; release capacity readiness remains a separate fresh gate.')
with (P/'accepted-summary.json').open('x')as f:json.dump(summary,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:summary[k]for k in ['complete','reason','new_completed_ordinals','next_ordinal','original_objects','logical_bytes_full_readback','engine_wal_targets','successful_fresh_codec_receipts','fresh_available_bytes','release_gap_bytes','margin_stop_gap_bytes','new_conservative_net_allocated_reduction_bytes']}))
