import copy,unittest
from types import SimpleNamespace
import tranche as t

class TrancheControls(unittest.TestCase):
 def test_exact_new_stop_boundary(self):
  self.assertIsNone(t.stop_reason(t.STOP-1,40));self.assertEqual(t.stop_reason(t.STOP,40),'actual_release_envelope_plus_margin');self.assertEqual(t.STOP,25778192384+1024**3)
 def test_finite_exhaustion_never_adds056(self):
  self.assertEqual(t.stop_reason(t.STOP-1,56),'finite_040_055_exhaustion')
  for i in [39,57,True]:
   with self.assertRaises(RuntimeError):t.stop_reason(1,i)
 def test_zero_and_contiguous_completed_prefix(self):
  self.assertEqual(t.prefix({},set()),([],40));r=dict(complete=True,ordinal=40,acceptance={'state':'COLD'})
  self.assertEqual(t.prefix({40:r},{40}),([r],41))
 def test_missing_failed_restored_gap_and_future_refuse(self):
  bad=[({}, {40}),({40:dict(complete=False,ordinal=40,acceptance={'state':'COLD'})},{40}),({40:dict(complete=True,ordinal=40,acceptance={'state':'RESTORED'})},{40}),({41:dict(complete=True,ordinal=41,acceptance={'state':'COLD'})},{41}),({}, {56})]
  for args in bad:
   with self.subTest(args=args),self.assertRaises(RuntimeError):t.prefix(*args)
 def test_actual_space_target_not_theoretical_savings(self):
  old=dict(target_reached=True,actual_available_bytes=t.STOP-1,scope='qualified',conservative_net_allocated_change_bytes=10**15)
  c=SimpleNamespace(accounting=lambda original,group:copy.deepcopy(old))
  r=t.scoped_accounting(c,None,None);self.assertFalse(r['target_reached']);self.assertTrue(r['prior_continuation_85gb_target_reached']);self.assertEqual(r['conservative_net_allocated_change_bytes'],old['conservative_net_allocated_change_bytes'])
 def test_original_source_and_additional_root_accounting(self):
  c=t.load_controller();self.assertEqual(c.P,t.PREP);self.assertEqual(c.OUT,t.HERE)
  rows=c.extra_accounting_roots();self.assertEqual(len(rows),10);self.assertEqual(len({str(p) for p,cap in rows}),10);self.assertIn((t.OLD_OUT,c.CAP),rows);self.assertIn((t.HERE,c.CAP),rows)
  self.assertEqual(c.invoke.__code__.co_filename,str(t.PREP/'campaign.py'));self.assertEqual(c.verify_release.__code__.co_filename,str(t.PREP/'campaign.py'));self.assertEqual(c.completed.__code__.co_filename,str(t.PREP/'campaign.py'))
if __name__=='__main__':unittest.main(verbosity=2)
