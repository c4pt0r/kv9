import json,hashlib,os,stat
from pathlib import Path
O=Path(__file__).parent;D=Path('/home/dongxu/kv9/target/debug');q=json.loads((O/'qualification.json').read_text())
existing={x['path'] for x in q['main_candidates']};protected={(r['device'],r['inode'])for r in json.loads((O/'observations.json').read_text())['protected_binary_metadata'] if 'device'in r}
def meta(p):
 s=p.lstat();return dict(path=str(p),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,bytes=s.st_size,allocated_bytes=s.st_blocks*512,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def pin(p):
 assert p.stat().st_size<=2*1024**2
 return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
rows=[];seen=set();excluded=[]
for unit in sorted((D/'.fingerprint').iterdir()):
 if not unit.name.startswith('kv9'):continue
 for f in sorted(unit.glob('*.json')):
  prefixes=['test-integration-test-','test-bin-','test-example-','example-','bin-']
  kind=next((x for x in prefixes if f.name.startswith(x)),None)
  if kind is None:continue
  name=f.stem[len(kind):].replace('-','_');suffix=unit.name.rsplit('-',1)[1];folder=D/('examples'if'example-'in kind else'deps');p=folder/(name+'-'+suffix)
  if not p.exists() or str(p) in existing:continue
  m=meta(p);key=m['device'],m['inode']
  if key in seen:continue
  assert p.resolve()==p and stat.S_ISREG(m['mode']) and m['uid']==1000 and m['mode']&0o111 and key not in protected
  aliases=[meta(x)for x in folder.iterdir() if x.is_file()and(x.stat().st_dev,x.stat().st_ino)==key]
  if len(aliases)!=m['nlink']:
   excluded.append(dict(path=str(p),reason='external/incomplete hard-link scope',aliases=aliases));continue
  document=json.loads(f.read_text());assert all(k in document for k in ['rustc','features','target','profile','deps','local'])
  dep=p.with_suffix('.d');assert dep.is_file();text=dep.read_text();assert len(text)<2*1024**2
  roots=[x for x in ['/home/dongxu/kv9/','/tmp/kv9-receipt-upper-bound-20260915-first/'] if x in text]
  assert roots,'first-party dep-info source root missing'
  rows.append(dict(kind=kind,package_unit=unit.name,aliases=aliases,allocated_bytes=m['allocated_bytes'],fingerprint=pin(f),dependency=pin(dep),source_roots=roots,features=document['features'],profile=document['profile']))
  seen.add(key)
extra=sum(r['allocated_bytes']for r in rows);free=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize
result=dict(complete=True,scope='Read-only exact Cargo fingerprint/dep-info qualification of additional named first-party dev tests/examples; no artifact hashing or deletion.',rows=rows,excluded=excluded,additional_allocated_bytes=extra,base_regular_fully_selected_bytes=q['main_regular_fully_selected_allocated_bytes'],combined_regular_allocated_ceiling_bytes=extra+q['main_regular_fully_selected_allocated_bytes'],fresh_available_bytes=free,release_launch_bytes=25778192384,remaining_gap_after_ceiling=max(0,25778192384-free-extra-q['main_regular_fully_selected_allocated_bytes']),future_cleanup='Recheck all metadata/links/source/locks; preserve Cargo fingerprint metadata and remove only these exact aliases. Never retained copies or source inputs.')
(O/'named-targets.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({k:result[k]for k in ['additional_allocated_bytes','combined_regular_allocated_ceiling_bytes','fresh_available_bytes','remaining_gap_after_ceiling']}));print('named_targets',len(rows),'excluded',len(excluded))
