import json,os,stat,collections,time
from pathlib import Path
O=Path(__file__).parent;r=json.loads((O/'observations.json').read_text())
selected=[Path(x['path']) for x in r['candidates']];seenpaths=set();inodes={}
for p in selected:
 paths=[p]
 if p.is_dir():paths += [Path(d)/n for d,dirs,files in os.walk(p,followlinks=False) for n in dirs+files]
 for f in paths:
  if str(f) in seenpaths:continue
  seenpaths.add(str(f));s=f.lstat();key=(s.st_dev,s.st_ino)
  item=inodes.setdefault(key,dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,allocated_bytes=s.st_blocks*512,nlink=s.st_nlink,regular=stat.S_ISREG(s.st_mode),paths=[]))
  item['paths'].append(str(f))
external=[v for v in inodes.values() if v['regular'] and v['nlink']!=len(v['paths'])]
protected={(x['device'],x['inode']) for x in r['protected_binary_metadata'] if 'device' in x}
aliases=[v for k,v in inodes.items() if k in protected]
old=[]
for row in r['known_old_profile_sizes']:
 p=Path(row['path']);tot=collections.Counter();eligible=[];seen=set()
 for d,ds,fs in os.walk(p,followlinks=False):
  for n in fs:
   f=Path(d)/n;s=f.lstat();key=(s.st_dev,s.st_ino)
   if key in seen:continue
   seen.add(key);a=s.st_blocks*512
   if stat.S_ISLNK(s.st_mode):kind='symlink_excluded'
   elif n.endswith(('.rlib','.rmeta','.a','.o','.d','.bc')):kind='generated_compiler_intermediate'
   elif s.st_mode & 0o111:kind='executable_preserved'
   elif '/.fingerprint/' in str(f):kind='fingerprint_metadata'
   else:kind='other_preserved'
   tot[kind]+=a
   if kind=='generated_compiler_intermediate':eligible.append(dict(path=str(f),allocated_bytes=a,device=s.st_dev,inode=s.st_ino,nlink=s.st_nlink,uid=s.st_uid,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns))
 old.append(dict(path=str(p),categories=dict(tot),intermediates=eligible))
result={'complete':True,'scope':'Metadata-only link closure for the finite observed generated-cache candidates; no cleanup authority/execution.','main_unique_allocated_bytes':sum(v['allocated_bytes'] for v in inodes.values()),'main_regular_fully_selected_allocated_bytes':sum(v['allocated_bytes'] for v in inodes.values() if v['regular'] and len(v['paths'])==v['nlink']),'external_link_exceptions':external,'protected_binary_aliases':aliases,'main_candidates':r['candidates'],'old_roots':old,'old_generated_intermediate_unique_bytes_per_root':sum(x['categories'].get('generated_compiler_intermediate',0) for x in old),'old_generated_intermediate_single_link_bytes':sum(f['allocated_bytes'] for x in old for f in x['intermediates'] if f['nlink']==1),'not_counted_as_saving':'Old executable/unknown contents, preserved evidence under target, offline downloads and all existing cold data.'}
(O/'qualification.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ['main_unique_allocated_bytes','main_regular_fully_selected_allocated_bytes','external_link_exceptions','protected_binary_aliases','old_generated_intermediate_unique_bytes_per_root','old_generated_intermediate_single_link_bytes']}))
