import os,json,stat,subprocess,time
from pathlib import Path
OUT=Path(__file__).parent
scope=json.loads(Path('/tmp/kv9-published-directory-capacity-actions-preparation-20260915-first/cache-v6/scope.json').read_text())
roots=[Path('/home/dongxu/kv9/target')]
main=Path('/home/dongxu/kv9/target')
candidates=[p for p in [main/'debug/incremental',main/'doc'] if p.exists()]
candidates += [p for sub in ['debug/deps','debug/build','debug/.fingerprint'] for p in (main/sub).iterdir() if p.name.startswith(('kv9','libkv9'))]
rows=[];seen=set()
for p in candidates:
 paths=[p]
 if p.is_dir(): paths += [Path(d)/n for d,dirs,files in os.walk(p,followlinks=False) for n in dirs+files]
 count=allocated=logical=links=0
 for f in paths:
  s=f.lstat(); key=(s.st_dev,s.st_ino)
  if key in seen:continue
  seen.add(key);allocated+=s.st_blocks*512;logical+=s.st_size;count+=1
  if stat.S_ISREG(s.st_mode) and s.st_nlink>1:links+=1
 rows.append({'path':str(p),'allocated_bytes':allocated,'logical_bytes':logical,'entries':count,'multiply_linked_files':links,'uid':p.lstat().st_uid,'kind':'generated_incremental' if p.name=='incremental' else 'generated_rustdoc' if p.name=='doc' else 'first_party_dev_artifact'})
known=[]
for root in roots:
 if root==main:continue
 for profile in ['debug','release','doc']:
  p=root/profile
  if p.is_dir():
   r=subprocess.run(['du','-x','-s','-B1','--',str(p)],capture_output=True,text=True,timeout=20)
   known.append({'path':str(p),'returncode':r.returncode,'allocated_bytes':int(r.stdout.split()[0]) if r.returncode==0 else None,'errors':r.stderr})
protected=[]
pp=[Path(x) for x in scope['protected']]
pp += [Path('/tmp/kv9-write-diagnostics-release-default-20260915-second/kv9'),Path('/tmp/kv9-write-diagnostics-release-instrumented-20260915-second/kv9'),Path('/tmp/kv9-point-write-v3-release-first/native/kv9-batch-benchmark')]
for p in pp:
 try:
  s=p.stat();protected.append({'path':str(p),'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'nlink':s.st_nlink})
 except FileNotFoundError:protected.append({'path':str(p),'absent':True})
active=[];references=[];errors=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  comm=(proc/'comm').read_text().strip()
  if comm in ['cargo','rustc','rustdoc','cc','cc1','cc1plus','ld','ld.lld','clang','clang++','gcc','g++','rust-analyzer','rust-analyzer-p']:
   active.append({'pid':int(proc.name),'comm':comm,'exe':os.readlink(proc/'exe'),'cwd':os.readlink(proc/'cwd')})
  links=[]
  for kind in ['exe','cwd']:
   try:links.append((kind,os.readlink(proc/kind)))
   except FileNotFoundError:pass
  for fd in (proc/'fd').iterdir():
   try:links.append(('fd',os.readlink(fd)))
   except FileNotFoundError:pass
  for line in (proc/'maps').read_text().splitlines():
   pieces=line.split(None,5)
   if len(pieces)==6:links.append(('map',pieces[5]))
  for kind,path in links:
   if any(path==str(r) or path.startswith(str(r)+'/') for r in roots):references.append({'pid':int(proc.name),'comm':comm,'kind':kind,'path':path})
 except (FileNotFoundError,ProcessLookupError):pass
 except PermissionError:errors.append({'pid':int(proc.name),'kind':'permission'})
s=os.statvfs('/tmp')
report={'observed_ns':time.time_ns(),'available_bytes':s.f_bavail*s.f_frsize,'candidates':rows,'candidate_allocated_bytes':sum(x['allocated_bytes'] for x in rows),'candidate_link_exceptions':sum(x['multiply_linked_files'] for x in rows),'known_old_profile_sizes':known,'protected_binary_metadata':protected,'active_build_tool_names':active,'known_target_process_references':references,'process_scan_errors':errors,'no_payload_read_or_hash':True,'no_mutation':True}
(OUT/'observations.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'candidate_bytes':report['candidate_allocated_bytes'],'link_exceptions':report['candidate_link_exceptions'],'known_old_profiles':len(known),'old_profile_bytes':sum(x['allocated_bytes'] or 0 for x in known),'active':active,'references':references,'errors':errors,'available_bytes':report['available_bytes']}))
