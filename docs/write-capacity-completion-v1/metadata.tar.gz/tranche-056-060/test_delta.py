import copy,unittest
from pathlib import Path
from types import SimpleNamespace
import tranche as t
class NewPrefixControls(unittest.TestCase):
 def fixture(self):
  db={};pins={};calls=[]
  proof_path=t.PREVIOUS/'result-original.json';binding={'previous_prefix_path':str(proof_path)}
  accept=lambda i:dict(state='COLD',ordinal=i)
  history=[dict(ordinal=i)for i in range(40)]
  proof=dict(complete=True,historical_completed_ordinals=list(range(40)),new_completed_ordinals=list(range(40,56)),next_ordinal=56,reason='finite_040_055_exhaustion',completed=[])
  db[str(t.PREVIOUS/'tool-terminal.json')]=dict(complete=True,session_id=87032,terminal_receipt='825382',exit_code=0,result_path=str(t.PREVIOUS/'status.json'),result_sha256='status')
  db[str(t.PREVIOUS/'launch-child-terminal.json')]=dict(complete=True,exit_code=0)
  db[str(t.PREVIOUS/'status.json')]=dict(state='COMPLETE',reason='finite_040_055_exhaustion',next_ordinal=56,completed_ordinals=list(range(40,56)))
  pins[str(t.PREVIOUS/'status.json')]={'sha256':'status'}
  for i in range(40,56):
   cp=t.PREVIOUS/f'{i:03d}'/'complete.json';rp=t.PREVIOUS/f'{i:03d}'/'release.json';pins[str(cp)]={'sha256':f'c{i}'};pins[str(rp)]={'sha256':f'r{i}'}
   r=dict(complete=True,ordinal=i,verified_sha256=f'v{i}',acceptance=accept(i),release_pin=pins[str(rp)]);db[str(cp)]=r
   proof['completed'].append(dict(ordinal=i,verified_sha256=f'v{i}',acceptance=accept(i),complete_record=pins[str(cp)]))
  db[str(proof_path)]=proof
  def check(p,b):
   if pins[str(p)]!=b:raise RuntimeError('pin changed')
   calls.append(str(p))
  c=SimpleNamespace(js=lambda p:db[str(p)],pin=lambda p:pins[str(p)],check=check,completed=lambda g,i,v:accept(i))
  return c,db,pins,binding,history,calls
 def test_actual_prefix_extends_only_to055(self):
  c,db,pins,b,h,calls=self.fixture();r=t.extend_history(c,None,b,h);self.assertEqual([x['ordinal']for x in r],list(range(56)));self.assertEqual(len(calls),16)
 def test_bad_original_terminal_or_population_refused(self):
  for field,value in [('exit_code',1),('terminal_receipt','unknown'),('complete',False)]:
   c,db,pins,b,h,calls=self.fixture();db[str(t.PREVIOUS/'tool-terminal.json')][field]=value
   with self.assertRaises(RuntimeError):t.extend_history(c,None,b,h)
  c,db,pins,b,h,calls=self.fixture();db[b['previous_prefix_path']]['completed'].pop()
  with self.assertRaises(RuntimeError):t.extend_history(c,None,b,h)
 def test_old_release_changed_and_restored_refuse(self):
  c,db,pins,b,h,calls=self.fixture();pins[str(t.PREVIOUS/'050/release.json')]={'sha256':'changed'}
  with self.assertRaises(RuntimeError):t.extend_history(c,None,b,h)
  c,db,pins,b,h,calls=self.fixture();c.completed=lambda g,i,v:dict(state='RESTORED',ordinal=i)
  with self.assertRaises(RuntimeError):t.extend_history(c,None,b,h)
 def test_exact_new_range_and_stop(self):
  self.assertEqual((t.FIRST,t.END),(56,61));self.assertEqual(t.prefix({},set()),([],56));self.assertIsNone(t.stop_reason(t.STOP-1,60));self.assertEqual(t.stop_reason(t.STOP-1,61),'finite_056_060_exhaustion');self.assertEqual(t.stop_reason(t.STOP,56),'actual_release_envelope_plus_margin')
  with self.assertRaises(RuntimeError):t.prefix({}, {61})
 def test_new_and_both_prior_reporting_roots_charged(self):
  c=t.load_controller();rows=c.extra_accounting_roots();self.assertEqual(len(rows),11);self.assertEqual(len({str(p)for p,cap in rows}),11)
  for p in [t.HERE,t.OLD_OUT,t.PREVIOUS]:self.assertIn((p,c.CAP),rows)
  for f in [c.invoke,c.verify_release,c.completed]:self.assertEqual(f.__code__.co_filename,str(t.PREP/'campaign.py'))
if __name__=='__main__':unittest.main(verbosity=2)
