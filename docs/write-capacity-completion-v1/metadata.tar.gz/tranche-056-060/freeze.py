from pathlib import Path
import json,hashlib,os
p=Path(__file__).parent;prev=Path('/tmp/kv9-write-release-capacity-tranche-20260915-first');g=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first');cleanup=Path('/tmp/kv9-write-post-dev-cache-cleanup-20260915-first')
def pin(f):
 f=Path(f);b=f.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,v):
 with (p/n).open('x')as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
save('controls-terminal.json',dict(complete=True,execution_kind='direct_tool_terminal',terminal_receipt='9bf5d2',exit_code=0,tests=5,source_pins={n:pin(p/n)for n in ['tranche.py','test_delta.py']},scope='Only new prior040..055 prefix, exact056..060 boundary and reporting-root accounting; no codec, payload or old controls.'))
old=json.loads((prev/'inputs.json').read_text());files=dict(old['files'])
for name,expected in files.items():assert pin(name)==expected,'old prerequisite changed: '+name
prefix=list(prev.glob('result-*.json'));assert len(prefix)==1
extra=[prev/n for n in ['tranche.py','test_tranche.py','controls-terminal.json','inputs.json','invocation.json','tool-terminal.json','launch-child-terminal.json','status.json','accepted-summary.json']]+prefix
for i in range(40,56):extra += [prev/f'{i:03d}'/'complete.json',prev/f'{i:03d}'/'release.json']
for i in range(56,61):extra.append(g/'selections'/f'{i:03d}.json')
extra += [cleanup/n for n in ['inventory.json','tool-terminal.json','result.json','retention-056-060-proposal.json','source-heads.json','source-before.json','source-after.json','protected-before.json','protected-after.json']]
files.update({str(f):pin(f)for f in extra})
save('inputs.json',dict(schema=1,files=files,own_sources={n:pin(p/n)for n in ['tranche.py','tranche.original.py','tranche.diff','test_delta.py','controls-terminal.json','freeze.py']},previous_prefix_path=str(prefix[0]),scope='Exact completed000..055 authority; fresh finite056..060 only. No061 or historical controller mutation.',first=56,last=60,actual_available_stop_bytes=26851934208))
argv=['sudo','-n','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','taskset','-c','6-15,22-31','python3','-u',str(p/'tranche.py'),'--inputs-sha256',pin(p/'inputs.json')['sha256']]
save('invocation.json',dict(argv=argv,source_sha256=pin(p/'tranche.py')['sha256'],inputs_sha256=pin(p/'inputs.json')['sha256'],controls_terminal='9bf5d2/0',scope='Authorized serial056..060 only; no main source or old controller edits.'))
frozen={str(f.relative_to(p)):pin(f)for f in p.iterdir()if f.is_file()};save('preparation-inventory.json',dict(files=frozen,complete=True,runtime_executed=False))
free=os.statvfs(p).f_bavail*os.statvfs(p).f_frsize
print(json.dumps(dict(source_sha256=pin(p/'tranche.py')['sha256'],inputs_sha256=pin(p/'inputs.json')['sha256'],inventory_sha256=pin(p/'preparation-inventory.json')['sha256'],files=len(files),fresh_available=free,original_first_selected_launch_plus_existing_metadata_bytes=10754195456+512*1024**2,stop_bytes=26851934208)))
