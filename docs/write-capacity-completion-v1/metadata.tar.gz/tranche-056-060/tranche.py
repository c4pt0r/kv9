"""Finite 056..060 adapter over the frozen qualified migration controller."""
import argparse,fcntl,hashlib,importlib.util,json,os,re,signal,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PREP=Path('/tmp/kv9-cross-voter-multicohort-continuation-preparation-20260915-first')
OLD_OUT=Path('/tmp/kv9-cross-voter-multicohort-continuation-root-20260915-first')
PUBLIC=Path('/tmp/kv9-retention-continuation-terminal-publication-20260915-first')
SOURCE_SHA='1d89dd9f019a870e16854b4112179635382731c7619ffcd92abc951ca3ec015f'
PREVIOUS=Path('/tmp/kv9-write-release-capacity-tranche-20260915-first')
FIRST=56;END=61;STOP=26851934208

def need(ok,message):
 if not ok:raise RuntimeError(message)
def digest(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load_controller():
 need(digest(PREP/'campaign.py')==SOURCE_SHA,'qualified controller source changed')
 spec=importlib.util.spec_from_file_location('qualified_tranche_controller',PREP/'campaign.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 c.OUT=HERE
 inherited_roots=c.extra_accounting_roots
 c.extra_accounting_roots=lambda:inherited_roots()+[(OLD_OUT,c.CAP),(PREVIOUS,c.CAP)]
 return c

def stop_reason(free,next_ordinal):
 need(type(free)is int and type(next_ordinal)is int and FIRST<=next_ordinal<=END,'finite stop inputs')
 if free>=STOP:return 'actual_release_envelope_plus_margin'
 if next_ordinal==END:return 'finite_056_060_exhaustion'
 return None

def prefix(records,existing):
 """Never adopt an incomplete/unknown attempt, a gap, or ordinal061+."""
 need(set(existing)<=set(range(FIRST,END)),'unexpected ordinal outside finite tranche')
 done=[]
 for i in range(FIRST,END):
  if i not in existing:
   need(not any(j>i for j in existing),'noncontiguous tranche prefix');return done,i
  r=records.get(i);need(r is not None and r.get('complete')is True and r.get('ordinal')==i and r.get('acceptance',{}).get('state')=='COLD','incomplete/unknown tranche attempt; no automatic retry')
  done.append(r)
 return done,END

def scoped_accounting(c,original,group):
 a=c.accounting(original,group)
 a['prior_continuation_85gb_target_reached']=a['target_reached']
 a['target_reached']=a['actual_available_bytes']>=STOP
 a['release_tranche_stop_bytes']=STOP;a['tranche_range']=[FIRST,END-1]
 a['scope']+=' New finite tranche, prior040..055 tranche and original completed continuation root are all charged; actual host availability includes concurrent dev work.'
 return a

def historical_before040(c,group,binding):
 for p,pin in binding['files'].items():c.check(p,pin)
 summary=c.js(PUBLIC/'completion.json');tool=c.js(PUBLIC/'tool-terminal.json');child=c.js(PUBLIC/'child-terminal.json');status=c.js(OLD_OUT/'status.json')
 need(summary['complete'] and summary['completed_plan_cohorts']==40 and summary['raw_controller_completed_ordinals']==39 and tool['session_id']==85630 and tool['terminal']['exit_code']==0 and tool['terminal']['chunk_id']=='b96c6f','actual completed040 predecessor authority')
 need(child['complete'] and child['exit_code']==0 and child['result_sha256']==c.pin(OLD_OUT/'status.json')['sha256'] and status['state']=='COMPLETE' and status['next_ordinal']==40,'old terminal/status binding')
 oldbinding=c.js(OLD_OUT/'binding.json');records=[dict(ordinal=0,verified_sha256=c.ZERO_VERIFIED,acceptance=oldbinding['cohort_zero'])]+oldbinding['historical_prefix']
 previous,next_i=c.resume_prefix(OLD_OUT);need(next_i==40,'predecessor039 boundary changed');records+=previous
 need([r['ordinal']for r in records]==list(range(40)),'exact historical completed prefix')
 for r in records:need(c.completed(group,r['ordinal'],r['verified_sha256'])==r['acceptance'],'historical COLD identity/receipt changed')
 return records

def extend_history(c,group,binding,records):
 """Accept only the actual complete040..055 terminal and exact immutable prefix."""
 tool=c.js(PREVIOUS/'tool-terminal.json');child=c.js(PREVIOUS/'launch-child-terminal.json');status=c.js(PREVIOUS/'status.json')
 need(tool['complete'] is True and tool['session_id']==87032 and tool['terminal_receipt']=='825382' and tool['exit_code']==0,'previous tranche actual tool terminal')
 need(child['complete'] is True and child['exit_code']==0,'previous tranche child not successful')
 need(tool['result_path']==str(PREVIOUS/'status.json') and tool['result_sha256']==c.pin(PREVIOUS/'status.json')['sha256'],'previous terminal/status hash')
 need(status['state']=='COMPLETE' and status['reason']=='finite_040_055_exhaustion' and status['next_ordinal']==56 and status['completed_ordinals']==list(range(40,56)),'previous exact completed boundary')
 proof_path=Path(binding['previous_prefix_path']);need(proof_path.parent==PREVIOUS and proof_path.name.startswith('result-'),'previous immutable prefix path')
 proof=c.js(proof_path)
 need(proof['complete'] is True and proof['historical_completed_ordinals']==list(range(40)) and proof['new_completed_ordinals']==list(range(40,56)) and proof['next_ordinal']==56 and proof['reason']=='finite_040_055_exhaustion','previous prefix authority')
 need([r['ordinal']for r in records]==list(range(40)) and [r['ordinal']for r in proof['completed']]==list(range(40,56)),'previous exact prefix population')
 for bound in proof['completed']:
  i=bound['ordinal'];path=PREVIOUS/f'{i:03d}'/'complete.json';need(bound['complete_record']==c.pin(path),'previous completion binding')
  r=c.js(path);need(r['complete'] is True and r['ordinal']==i and r['verified_sha256']==bound['verified_sha256'] and r['acceptance']==bound['acceptance'],'previous completed/verification authority')
  c.check(PREVIOUS/f'{i:03d}'/'release.json',r['release_pin'])
  need(c.completed(group,i,r['verified_sha256'])==r['acceptance'],'previous COLD changed/restored')
  records.append(r)
 need([r['ordinal']for r in records]==list(range(FIRST)),'exact historical000..055 required')
 return records

def historical(c,group,binding):
 return extend_history(c,group,binding,historical_before040(c,group,binding))

def save_prefix(c,done,baseline,accounting,reason=None):
 """New immutable receipt; old completed/failed controller files are never written."""
 proof=dict(complete=True,scope='Prefix integration authority for separately executed finite tranche; old controller remains immutable.',historical_completed_ordinals=list(range(FIRST)),new_completed_ordinals=[r['ordinal']for r in done],next_ordinal=FIRST+len(done),completed=[dict(ordinal=r['ordinal'],complete_record=c.pin(HERE/f"{r['ordinal']:03d}"/'complete.json'),verified_sha256=r['verified_sha256'],acceptance=r['acceptance'])for r in done],baseline_accounting=baseline,current_accounting=accounting,actual_release_envelope_plus_margin_met=accounting['actual_available_bytes']>=STOP,stop_bytes=STOP,reason=reason,legacy_controller_resume_requires_explicit_integration=True)
 c.save(HERE/f'prefix-through-{FIRST+len(done)-1:03d}-{time.time_ns()}.json',proof)
 return proof

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--inputs-sha256',required=True);a=ap.parse_args()
 need(digest(HERE/'inputs.json')==a.inputs_sha256,'frozen tranche inputs changed');binding=json.loads((HERE/'inputs.json').read_text())
 c=load_controller();need(os.geteuid()==0 and set(os.sched_getaffinity(0))==c.CPUS,'root/helper CPUs required')
 for name,pin in binding['own_sources'].items():c.check(HERE/name,pin)
 original=c.original_modules();c.repair_modules();group=c.js(c.OLD/'group-plan.json')
 fds=[];started=time.monotonic();done=[];baseline=None
 try:
  for p in [HERE/'campaign.lock',OLD_OUT/'campaign.lock',PREVIOUS/'campaign.lock',c.PRIOR_OUT/'campaign.lock']:
   fd=os.open(p,os.O_RDWR|os.O_NOFOLLOW|(os.O_CREAT if p.parent==HERE else 0),0o600);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);fds.append(fd)
  def interrupt(signum,frame):raise InterruptedError('tranche signal '+str(signum))
  signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
  with c.dispatcher_read_lock():history=historical(c,group,binding)
  names={int(p.name)for p in HERE.iterdir()if re.fullmatch('[0-9]{3}',p.name)}
  records={i:c.js(HERE/f'{i:03d}'/'complete.json')for i in names if (HERE/f'{i:03d}'/'complete.json').is_file()}
  done,next_i=prefix(records,names)
  for r in done:
   need(c.completed(group,r['ordinal'],r['verified_sha256'])==r['acceptance'],'completed tranche changed/restored');c.check(HERE/f"{r['ordinal']:03d}"/'release.json',r['release_pin'])
  with c.dispatcher_read_lock():
   c.global_prefix(group,FIRST-1+len(done));current=scoped_accounting(c,original,group)
  need(not current['incomplete_or_restored_cohorts'],'unknown incomplete/restored state')
  if not (HERE/'baseline-accounting.json').exists():c.save(HERE/'baseline-accounting.json',current)
  baseline=c.js(HERE/'baseline-accounting.json')
  for i in range(next_i,END+1):
   c.resource_guard(started,c.CAMPAIGN_SECONDS)
   with c.dispatcher_read_lock():c.global_prefix(group,FIRST-1+len(done));account=scoped_accounting(c,original,group)
   need(not account['incomplete_or_restored_cohorts'],'unknown partial cohort')
   reason=stop_reason(account['actual_available_bytes'],i)
   if reason:
    proof=save_prefix(c,done,baseline,account,reason);c.save(HERE/f'result-{time.time_ns()}.json',proof);c.event(dict(state='COMPLETE',reason=reason,next_ordinal=i,completed_ordinals=[r['ordinal']for r in done],available_bytes=c.available(),target_reached=account['actual_available_bytes']>=STOP));print(json.dumps(dict(complete=True,reason=reason,next_ordinal=i,completed_ordinals=[r['ordinal']for r in done],available_bytes=c.available(),target_reached=account['actual_available_bytes']>=STOP)),flush=True);return 0
   row,s=c.selected(group,i)
   need(c.absent(Path(s['root']))and c.absent(c.EXEC/f'{i:03d}'),'new ordinal has existing handle')
   launch=s['limits']['launch_available_bytes']+512*c.MIB
   if c.available()<launch:
    proof=save_prefix(c,done,baseline,account,'fresh_launch_capacity_short');c.save(HERE/f'capacity-stop-{time.time_ns()}.json',dict(**proof,required_launch_bytes=launch));c.event(dict(state='STOPPED_AT_COMPLETED_BOUNDARY',reason='fresh_launch_capacity_short',next_ordinal=i,required_bytes=launch,available_bytes=c.available()));print(json.dumps(dict(complete=True,reason='fresh_launch_capacity_short',completed_ordinals=[r['ordinal']for r in done],next_ordinal=i,required_bytes=launch,available_bytes=c.available(),target_reached=False)),flush=True);return 0
   c.mkdir(HERE/f'{i:03d}');c.event(dict(state='RUNNING',ordinal=i,phase='stage-verify',available_bytes=c.available()));c.invoke(i,'stage-verify')
   with c.dispatcher_read_lock():release=c.verify_release(group,i)
   c.save(HERE/f'{i:03d}'/'release.json',dict(release,root_preauthorized_deterministic_release=True,observed_ns=time.time_ns()));release_pin=c.pin(HERE/f'{i:03d}'/'release.json')
   c.event(dict(state='RUNNING',ordinal=i,phase='finish',verified_sha256=release['verified_sha256'],available_bytes=c.available()));c.invoke(i,'finish',release['verified_sha256'])
   acceptance=c.completed(group,i,release['verified_sha256']);account=scoped_accounting(c,original,group)
   r=dict(complete=True,ordinal=i,verified_sha256=release['verified_sha256'],acceptance=acceptance,release_pin=release_pin,accounting=account)
   c.save(HERE/f'{i:03d}'/'complete.json',r);done.append(r);save_prefix(c,done,baseline,account)
   c.event(dict(state='COHORT_COMPLETE',ordinal=i,completed_ordinals=[r['ordinal']for r in done],available_bytes=c.available()));print(json.dumps(dict(completed=i,available_bytes=c.available())),flush=True)
 except BaseException as exc:
  c.save(HERE/f'failure-{time.time_ns()}.json',dict(complete=False,error=repr(exc),completed_ordinals=[r['ordinal']for r in done],scope='Original outcomes and all partial objects retained; no unknown handle restart.'))
  c.event(dict(state='FAILED',error=repr(exc),completed_ordinals=[r['ordinal']for r in done],available_bytes=c.available()));raise
 finally:
  for fd in reversed(fds):os.close(fd)
if __name__=='__main__':sys.exit(main())
