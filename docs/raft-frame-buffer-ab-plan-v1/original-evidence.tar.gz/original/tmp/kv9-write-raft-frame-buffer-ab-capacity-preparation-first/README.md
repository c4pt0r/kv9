# Frame matched-write screen: capacity remains unqualified

Root supplied 120,132,231,168 available bytes (111.882 GiB), observation 79001f/0. This leaves only 17,053,016,064 bytes (15.882 GiB) above the unchanged 96 GiB retention floor. This review did not refresh df or inspect other disks/caches.

The accepted CRC campaign is the matching eight 2-second smoke and sixteen 10-second timed point Put/BatchPut64, c1/c64, two-role write reference. Actual root smoke 97839/6ff43c/0, timing 97690/5063f4/0, audit 40042/1e3734/0 and summary 50f90b/0 are retained and bound. This frame candidate has not run that screen. The following numbers are arithmetic over accepted inventory metadata, not another WAL decode or audit.

| Phase | Logical original bytes | Compressed object file bytes | Resident allocated bytes under cohorts |
|---|---:|---:|---:|
| smoke (8 cohorts) | 7,576,967,137 | 5,311,723,007 | 5,385,760,768 |
| timing (16 cohorts) | 61,670,158,132 | 43,189,307,846 | 43,429,339,136 |

An additional 4,341,760 allocated bytes belong to the campaign roots outside individual cohorts. Combined physical residency is **48,819,441,664 bytes (45.467 GiB)**: 48,508,096,512 bytes allocated to 2,796 compressed objects, plus 311,345,152 bytes of other resident files/directories. Object file lengths total 48,501,030,853 bytes; allocation differs from file length. The original logical population is 69,247,125,269 bytes. Those original paths are absent and represented by verified objects/catalogs; their historical tmpfs device/inode/block metadata is not current disk residency.

| Planning quantity | Bytes | GiB |
|---|---:|---:|
| Resident footprint + unchanged floor | 151,898,656,768 | 141.467 |
| Shortfall before restore/final margin | 31,766,425,600 | 29.585 |
| One maximum-size cohort restore reserve | 17,179,869,184 | 16.000 |
| Metadata/final margin | 1,073,741,824 | 1.000 |
| Updated empirical required available | 170,152,267,776 | 158.467 |
| Additional empirical headroom needed | 50,020,036,608 | 46.585 |

The updated scenario is `96 GiB + actual 48,819,441,664-byte residency + 16 GiB restore reserve + 1 GiB final margin = 170,152,267,776 bytes`. Against current available space, the gap is **50,020,036,608 bytes (46.585 GiB)**. Even the earlier, lower baseline-derived reserve of 166,426,083,882 bytes would be short by 46,293,852,714 bytes. No previous cache cleanup, cold conversion or saved originals are credited again: their effects are already inside the root-supplied available-space observation.

Sequential execution is already the qualified method. Each cohort keeps its originals on tmpfs until all owned writers exit; it then compresses directly to retained disk objects, validates full decoded bytes, removes the owned tmpfs originals and starts the next cohort. It does not remove prior compressed objects. An exact replay of the accepted allocation order would be below 96 GiB by completion of timed cohort ordinal 006 (c64 selected BatchPut64), at 100,627,992,576 available bytes; per-member reservation or other current allocation may stop it earlier. This is a replay calculation, not a prediction of the unmeasured frame candidate.

The retention helper still requires `free >= 96 GiB + reserve` during compression. Before each member, reserve is `original_bytes + original_bytes//128 + 1 MiB + 8 MiB metadata`; for the unchanged 8 GiB member cap this is 8,666,480,640 bytes. The reviewed 16 GiB restore reserve plus 1 GiB final margin covers that temporary output reservation as a maximum when restoration and cohort compression do not overlap; it is not added twice. The largest observed member was 1,780,093,260 bytes and the largest observed cohort was 10,656,683,223 bytes, both below their unchanged caps.

Restoration is explicit and exclusive to a fresh ordinary destination. A maximum-size 16 GiB cohort requires actual free space at least `96 GiB + 16 GiB + 8 MiB`; object files stay retained. Rehydrating all observed originals simultaneously would additionally require at least 69,255,513,877 bytes including that metadata allowance, plus existing residency/floor and directory effects. Ordinary independent acceptance streams decoded bytes and does not require this whole-campaign materialization. These restore requirements are not waived by the screen capacity model.

All original 32/96 GiB cohort preflight, 16/64 GiB runtime tmpfs/disk guards, 96 GiB codec/restore floor, 8 GiB member, 16 GiB cohort and independently enforced 128 GiB combined logical/physical campaign caps remain unchanged. The caps are fail-closed bounds; they do not prove a successful full-campaign fit. Ten million maximum calls and observed compression ratios are likewise not a storage guarantee. Faster closed-loop writes or different compression may increase bytes. No scope/rate/duration reduction is proposed.

The current environment cannot qualify the full sequential screen using this empirical scenario. Root needs additional available capacity and a fresh measurement after any separately authorized capacity action; the pending user storage-location question remains with root. No additional storage question or cleanup is initiated here.

`derive.py` is a small metadata-only reproducer; `result-first.json` contains all 24 rows, arithmetic, original input SHA/size bindings and scope. Command: `env PYTHONOPTIMIZE=0 PYTHONDONTWRITEBYTECODE=1 taskset -c 6-15,22-31 python3 -B derive.py --available-bytes 120132231168 --observation-receipt 79001f/0 --output <fresh-result.json>`. Its first execution 3efc2d/0 completed in 2.55 seconds. No payload/object/executable was opened, no data-tree/shared-target traversal or codec/runtime/test occurred.
