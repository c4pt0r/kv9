"""Metadata-only storage arithmetic; never opens a WAL/object/binary or traverses a data tree."""
from pathlib import Path
import argparse,hashlib,json,stat
P=Path('/tmp/kv9-write-crc-slicing8-ab-preparation-first')
R=Path('/tmp/kv9-write-crc-slicing8-ab-campaign-root-second')
GIB=1024**3
seen_inputs={}
def read(path):
 path=Path(path); data=path.read_bytes();assert len(data)<=3*1024**2,path
 seen_inputs[str(path)]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 return json.loads(data)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--available-bytes',type=int,required=True);ap.add_argument('--observation-receipt',required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 protocol=read(P/'protocol.json');audit=read(P/'results-first/audit.json');physical=read(P/'results-first/combined-physical-retention.json');logical=read(P/'results-first/logical-original-inventory.json')
 terminals={k:read(R/k/'terminal.json')for k in ['smoke','timing','audit','summary']}
 assert all(x['complete'] and x['exit_code']==0 for x in terminals.values())
 assert seen_inputs[str(P/'results-first/audit.json')]['sha256']==terminals['audit']['audit_sha256']
 assert audit['complete'] and audit['matched_diagnostic_accepted'] and audit['outer_restoration']['accepted']
 assert len(audit['cases'])==16 and len(audit['smoke']['cases'])==8
 assert len(protocol['timed_inventory'])==16 and len(protocol['smoke_inventory'])==8
 limits=protocol['compressed_retention']['limits'];assert limits['member_bytes']==8*GIB and limits['cohort_bytes']==16*GIB and limits['campaign_bytes']==128*GIB and limits['retention_floor_bytes']==96*GIB
 retention=audit['compressed_retention'];assert retention['independently_decoded_all_bytes'] and retention['resident_original_paths'] is False
 smoke_roots=[Path(x['directory'])for x in audit['smoke']['cases']];timing_roots=[Path(x['cohort'])for x in retention['cohorts']];roots=smoke_roots+timing_roots
 rows=[]
 for stage,cohorts,descriptors,observations in [('smoke',smoke_roots,protocol['smoke_inventory'],retention['smoke_byte_retention']),('timing',timing_roots,protocol['timed_inventory'],retention['cohorts'])]:
  for ordinal,(root,desc,obs)in enumerate(zip(cohorts,descriptors,observations,strict=True)):
   items=[v for k,v in logical.items()if Path(k).is_relative_to(root)]
   assert len(items)==obs['files'] and sum(x['bytes']for x in items)==obs['logical_bytes']
   rows.append(dict(stage=stage,ordinal=ordinal,directory=str(root),arm=desc['arm'],workers=desc['shared']['workers'],batch_size=desc['shared']['batch_size'],repeat=desc['repeat'],measure_ms=desc['shared']['measure_ms'],logical_files=len(items),logical_bytes=obs['logical_bytes'],compressed_bytes=obs['compressed_bytes'],largest_original_member_bytes=max(x['bytes']for x in items),object_allocated_bytes=0,other_allocated_bytes=0,object_count=0))
 keys=set();other=0;object_paths={x['physical_object']for x in logical.values()};assert len(object_paths)==len(logical)
 object_bytes=0;objects=0;dirs=0;regular=0
 for name,item in physical['metadata'].items():
  key=(item['device'],item['inode']);allocation=0 if key in keys else item['blocks']*512;keys.add(key)
  isobj=name in object_paths
  if isobj:assert stat.S_ISREG(item['mode']);object_bytes+=item['bytes'];objects+=1
  regular+=stat.S_ISREG(item['mode']);dirs+=stat.S_ISDIR(item['mode'])
  matching=[row for row in rows if Path(name).is_relative_to(Path(row['directory']))]
  if matching:
   assert len(matching)==1;row=matching[0];row['object_allocated_bytes'if isobj else 'other_allocated_bytes']+=allocation
   if isobj:row['object_count']+=1
  else:assert not isobj;other+=allocation
 assert set(object_paths)<=set(physical['metadata']) and objects==len(logical)
 for row in rows:
  row['resident_allocated_bytes']=row['object_allocated_bytes']+row['other_allocated_bytes']
  assert row['object_count']==row['logical_files']
 total=sum(row['resident_allocated_bytes']for row in rows)+other
 assert total==physical['allocated_bytes']==retention['combined_independent_allocated_bytes']
 assert object_bytes==sum(row['compressed_bytes']for row in rows)
 assert sum(x['logical_bytes']for x in rows)==retention['combined_smoke_timing_logical_bytes']
 groups={}
 for stage in ['smoke','timing']:
  selected=[x for x in rows if x['stage']==stage]
  groups[stage]={k:sum(x[k]for x in selected)for k in ['logical_files','logical_bytes','compressed_bytes','object_allocated_bytes','other_allocated_bytes','resident_allocated_bytes']}
  groups[stage]['cohorts']=len(selected)
 floor=limits['retention_floor_bytes'];restore=limits['cohort_bytes'];margin=GIB
 maxmember=limits['member_bytes'];max_codec_reserve=maxmember+maxmember//128+1024**2+limits['metadata_bytes']
 observed_maxmember=max(x['bytes']for x in logical.values());observed_maxcohort=max(x['logical_bytes']for x in rows)
 cumulative=other;crossing=None
 for row in rows:
  cumulative+=row['resident_allocated_bytes'];row['empirical_replay_cumulative_resident_bytes']=cumulative;row['empirical_replay_available_after_bytes']=args.available_bytes-cumulative
  if crossing is None and args.available_bytes-cumulative<floor:crossing={k:row[k]for k in ['stage','ordinal','directory','arm','workers','empirical_replay_cumulative_resident_bytes','empirical_replay_available_after_bytes']}
 old=read(P/'capacity.json');old_smoke=read(R/'smoke-capacity-release.json');old_timing=read(R/'timing-capacity-release.json')
 result=dict(complete=True,metadata_only=True,actual_available_input=dict(bytes=args.available_bytes,parent_observation_receipt=args.observation_receipt,independently_refreshed_here=False),reference=dict(audit=seen_inputs[str(P/'results-first/audit.json')],terminals=terminals,source_pins=protocol['server_pins'],client_pins=protocol['client_pins'],scope='Accepted CRC eight2s-smoke/sixteen10s-timed write campaign; empirical comparison for a new frame candidate, not a guaranteed volume bound.'),limits_unchanged=limits,storage_guards=protocol['storage_guards'],phase_totals=groups,other_campaign_root_allocated_bytes=other,combined=dict(logical_original_files=len(logical),logical_original_bytes=sum(x['bytes']for x in logical.values()),compressed_object_files=objects,compressed_object_logical_bytes=object_bytes,compressed_object_allocated_bytes=sum(x['object_allocated_bytes']for x in rows),other_resident_allocated_bytes=sum(x['other_allocated_bytes']for x in rows)+other,total_resident_allocated_bytes=total,physical_inventory_regular_files=regular,physical_inventory_directories=dirs,resident_original_paths=False),capacity=dict(current_above_floor_bytes=args.available_bytes-floor,empirical_resident_plus_floor_bytes=floor+total,empirical_resident_only_gap_bytes=max(0,floor+total-args.available_bytes),one_cohort_restore_reserve_bytes=restore,metadata_and_final_margin_bytes=margin,empirical_required_available_bytes=floor+total+restore+margin,empirical_additional_gap_bytes=max(0,floor+total+restore+margin-args.available_bytes),maximum_member_codec_reserve_bytes=max_codec_reserve,restore_minimum_excluding_existing_residency_bytes=floor+restore+limits['metadata_bytes'],maximum_observed_member_bytes=observed_maxmember,maximum_observed_cohort_logical_bytes=observed_maxcohort,full_logical_campaign_rehydrate_additional_bytes=sum(x['bytes']for x in logical.values())+limits['metadata_bytes'],first_completed_cohort_crossing_in_same_allocation_replay=crossing,prior_prelaunch_empirical_required_bytes=old['scenario_required_available_bytes'],prior_scenario_gap_at_current_available=max(0,old['scenario_required_available_bytes']-args.available_bytes),qualified_for_new_runtime=False,worst_case_fit_guarantee=False),prior_launch_scope=dict(smoke_required=old_smoke['required_available_bytes'],timing_required_after_smoke=old_timing['required_available_bytes'],prior_reclaimed_bytes_credited_again=0),cohorts=rows,caveats=['Finished compressed objects and non-object files remain resident across sequential cohorts; serialization removes codec overlap, not cumulative retention.','The benchmark writes current originals to tmpfs; it compresses directly to disk only after every writer exits. No second full disk-original copy is part of ordinary retention.','Compression reserve per member is original_bytes+floor(original_bytes/128)+1MiB+8MiB metadata. Existing object allocation is already part of current disk usage.','The reviewed16GiB restore reserve plus1GiB margin covers the8GiB-member worst output reservation as a planning maximum, not an added second reserve; restore and cohort codec do not overlap in this scenario.','Independent audit streams decoded bytes rather than materializing69GiB of originals. A requested restore creates a fresh destination and needs its own actual floor+logical+metadata check.','Logical original sizes are historical absent original paths, never current resident/inode claims. Metadata inventory allocation is an accepted historical snapshot, not a fresh disk traversal.','A faster frame writer or changed compressibility can retain more;10M call cap and128GiB combined cap are enforced abort bounds, not a successful-fit guarantee.','Current free space already includes previous archival/cache effects; zero old cleanup savings credited. No runtime release, guard/rate/duration/scope changes or new storage request.'],input_bindings=seen_inputs)
 args.output.parent.mkdir(parents=True,exist_ok=True)
 with args.output.open('x')as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps({k:result[k]for k in ['phase_totals','other_campaign_root_allocated_bytes','combined','capacity']},indent=2))
if __name__=='__main__':main()
