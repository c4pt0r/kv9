#!/usr/bin/env python3
"""Write static preparation metadata; never import a driver/auditor or run tests."""
from pathlib import Path
import ast, difflib, hashlib, json, os, time
H=Path(__file__).resolve().parent
BASE=Path('/tmp/kv9-thin-lto-compressed-performance-preparation-first')
SMOKE=Path('/tmp/kv9-write-crc-slicing8-ab-smoke-first')
TIMING=Path('/tmp/kv9-write-crc-slicing8-ab-timing-first')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(name,x):(H/name).write_text(json.dumps(x,indent=2)+'\n')
def record(p):return dict(bytes=Path(p).stat().st_size,sha256=sha(p))
def funcs(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
def constants(p,names):
    # Literal-only extraction; no AST expressions or runtime bodies execute.
    out={}
    for n in ast.parse(Path(p).read_text()).body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in names:
            out[n.targets[0].id]=ast.literal_eval(n.value)
    return out

protocol=read(BASE/'protocol.json')
protocol.update(protocol_id='kv9-write-crc-slicing8-ab-c1-c64-v1',
    control_revision='11113f68f6a5df77da1ffb4fcec850953716ffa3',
    candidate_revision='e748620a7b0ba326ac5f4fa8e3a6b1ff48553c6a',
    general_baseline_revision='11113f68f6a5df77da1ffb4fcec850953716ffa3',
    decision_scope='Initial native-only point Put/BatchPut64 c1/c64 write screen. Two opposite complete orders. Retain all outcomes, attempts and both repetitions. Whole-call histograms, call/key rates and per-process CPU; no read/mixed regression, full Chaos or default promotion acceptance.',
    durability='Both roles: three-voter tmpfs WAL with unchanged sync/quorum behavior; no power-loss durability claim.',
    runtime_ready=False,capacity_qualified=False,contracts_executed=False,
    large_synthetic_qualified='Inherited qualified retention code, functions unchanged; no new large qualification run',
    server_pins={},client_pins={'client':protocol['client_pins']['client']},
    workload_cells=[['point',1,0],['batch64',64,0]],
    expected_counts=dict(smoke_cohorts=8,timed_cohorts=16,smoke_lifetimes=32,timed_lifetimes=64,
        smoke_fresh_drains=24,timed_fresh_drains=48,timed_writer_bindings=48,paired_timed_cells=8),
    role_labels={'old':'selected ThinLTO main integration 11113f68','new':'isolated CRC slicing8 e748620a'},
    cpu_scope='Unchanged measured resource samples contain client and all three voters with exact PID/start and TID affinity. resource-coverage.json contains existing cpu_summary output; original samples remain authoritative. Core percentages refer to sampled CPU time, not additive request stage latency.')
for k in ['redis_client_revision','redis_client_sha256']:
    protocol.pop(k,None)
role_paths={
 'old':('/tmp/kv9-thin-lto-main-integration-first','/tmp/kv9-thin-lto-main-integration-release-verbose-first'),
 'new':('/tmp/kv9-write-crc-slicing8-thinlto-first','/tmp/kv9-write-crc-slicing8-release-first'),
 'client':('/tmp/kv9-point-write-measurement-v3','/tmp/kv9-point-write-v3-release-first/native')}
inputs={};binding={}
for role,(source,build) in role_paths.items():
    build=Path(build);manifest=read(build/'build.json')
    inputs[str(build/'build.json')]=record(build/'build.json')
    executable=build/('kv9-batch-benchmark' if role=='client' else 'kv9')
    executable_sha=manifest['binary_sha256'] if role=='client' else manifest['binaries']['kv9']['sha256']
    paths=[build/'sources.json',build/'cargo.jsonl'] if role=='client' else [build/'kv9-cargo.jsonl',build/'kv9-build.log']
    for p in paths:inputs[str(p)]=record(p)
    binding[role]=dict(source=source,build=str(build),revision=manifest['revision'],dirty=manifest['dirty'],
        source_tree_sha256=manifest['source_tree_sha256'],manifest_sha256=sha(build/'build.json'),
        executable=str(executable),executable_sha256=executable_sha,rustc=manifest['rustc'],profile=manifest['profile'],
        observation='Original manifest/log metadata only here; exact current source/executable/Cargo validation is in the inherited root-only driver contract and runtime pre/post checks.')
    if role!='client':protocol['server_pins'][role]=dict(revision=manifest['revision'],binary_sha256=executable_sha,manifest_sha256=sha(build/'build.json'))
for p in [Path('/tmp/kv9-thin-lto-main-integration-root-first/release-verbose-readback.json'),
          Path('/tmp/kv9-thin-lto-main-integration-root-first/production-codegen-verbose.json'),
          Path('/tmp/kv9-write-crc-slicing8-recovery-preparation-first/release-readback.json')]:
    inputs[str(p)]=record(p)
save('build-bindings.json',dict(roles=binding,compiler_scope='Same rustc1.94 identity; both original server builds verbose ThinLTO/codegen-units1/opt3/default features, portable target/unwind. Fixed native v3 client bytes are identical between roles.',
    original_readback_inputs={p:v for p,v in inputs.items() if p.endswith('readback.json') or 'codegen-verbose' in p}))
save('original-input-pins.json',inputs)

forward=[(c,name,batch,role) for c in [1,64] for name,batch in [('point',1),('batch64',64)] for role in ['old','new']]
def descriptors(smoke):
    result=[]
    for repeat in range(1 if smoke else 2):
        for c,name,batch,role in (forward if repeat==0 else list(reversed(forward))):
            workload=name+'-r000'
            result.append(dict(repeat=repeat,arm=role+'-'+workload,server_role=role,workload=workload,
                read_api='point_get' if batch==1 else 'batch_get',write_api='point_put' if batch==1 else 'batch_put',
                mix='write',target='kv9',shared=dict(run_id=f'p{repeat}{c:04d}',seed=71,workers=c,keys=4096,
                batch_size=batch,value_bytes=128,read_percent=0,warmup_calls=128,measure_ms=2000 if smoke else 10000,
                max_calls=10000000,load=dict(kind='closed_loop'))))
    return result
protocol['smoke_inventory']=descriptors(True);protocol['timed_inventory']=descriptors(False)
for k in list(protocol):
    if k in ['smoke_descriptors','timed_descriptors','timing_inventory']:protocol.pop(k)
protocol['driver_sha256']=sha(H/'matched-driver.py');protocol['auditor_sha256']=sha(H/'audit.py')
protocol['compressed_retention'].update(helper=record(H/'compressed_retention.py'),independent_reader=record(H/'retention_audit.py'),
    logical_campaign_roots=[str(SMOKE),str(TIMING/'cohorts')])
save('protocol.json',protocol)
save('expected-descriptors.json',dict(smoke=descriptors(True),timed=descriptors(False),
    scope='Independent finite protocol description. Actual make_plan descriptor equality must be executed by root in test_driver.py; no driver function was invoked by preparation.'))

prefix=['sudo','-n','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','taskset','-c','6-15,22-31','/usr/bin/python3','-B']
arguments=read(H/'driver-arguments.json')
commands=dict(runtime_commands_released=False,
    contracts_root_only=[prefix+[str(H/f)] for f in ['test_driver.py','test_audit_contract.py','test_smoke_schema.py']],
    smoke_root_only_after_contracts_and_capacity=prefix+[str(H/'matched-driver.py'),'--output',str(SMOKE),'--smoke']+arguments,
    timing_root_only_after_smoke_terminal_and_capacity=prefix+[str(H/'isolate-and-run.py'),'--driver',str(H/'matched-driver.py'),'--output',str(TIMING),'--driver-arguments-file',str(H/'driver-arguments.json')],
    audit_root_only_after_timing_terminal=prefix+[str(H/'audit.py'),'--run',str(TIMING/'cohorts'),'--output',str(H/'results-first'),
        '--expected-driver-sha256',sha(H/'matched-driver.py'),'--root-session','ACTUAL_TERMINAL_TIMING_SESSION','--root-exit-code','0','--successful-arms','16'],
    restore_root_only_after_reviewed_capacity=prefix+[str(H/'compressed_retention.py'),'--restore-catalog','EXACT_REVIEWED_FIXTURE/retention-catalog.json',
        '--expected-catalog-sha256','EXACT_REVIEWED_CATALOG_SHA256','--destination','FRESH_ABSOLUTE_RESTORE_DIRECTORY'])
save('commands.json',commands)

audit_path=Path('/tmp/kv9-write-redis3-audit-repair-first/results-first/audit.json')
accepted=read(audit_path);r=accepted['compressed_retention']
assert accepted['complete'] is True and accepted['matched_diagnostic_accepted'] is True
assert len(r['cohorts'])==8 and len(r['smoke_byte_retention'])==4
timed=sum(x['compressed_bytes'] for x in r['cohorts']);smoke=sum(x['compressed_bytes'] for x in r['smoke_byte_retention'])
logical=sum(x['logical_bytes'] for x in r['cohorts']+r['smoke_byte_retention'])
space={p:dict(available_bytes=os.statvfs(p).f_bavail*os.statvfs(p).f_frsize,device=os.stat(p).st_dev) for p in ['/tmp','/dev/shm']}
floor=96*1024**3;cohort=16*1024**3;reserve=1024**3
scenario=2*(timed+smoke)
save('capacity.json',dict(observed_unix_ns=time.time_ns(),space=space,unchanged_retention_floor_bytes=floor,
    available_above_floor_bytes=space['/tmp']['available_bytes']-floor,
    accepted_reference=dict(path=str(audit_path),**record(audit_path),timed_native_cohorts=8,smoke_native_cohorts=4,
        timed_compressed_bytes=timed,smoke_compressed_bytes=smoke,combined_logical_bytes=logical,
        cohort_compressed_bytes=[x['compressed_bytes'] for x in r['cohorts']]),
    two_role_same_observed_volume_scenario_bytes=scenario,
    one_full_cohort_restore_reservation_bytes=cohort,metadata_and_final_headroom_scenario_bytes=reserve,
    scenario_required_available_bytes=floor+scenario+cohort+reserve,
    scenario_additional_headroom_bytes=max(0,floor+scenario+cohort+reserve-space['/tmp']['available_bytes']),
    capacity_ready=False,guaranteed_full_run_fit=False,
    limits_unchanged=protocol['compressed_retention']['limits'],
    caveats=['The replay-volume scenario is empirical, not an upper bound. A faster writer may retain more.',
      'Member8GiB/cohort16GiB/combined logical128GiB and per-member compression reservation remain enforced. A cap hit retains failure; it does not authorize rerun or omission.',
      'The existing independent reader verifies decoded original SHA/size and independently sums physical inventory and combined smoke/timing logical prefixes.',
      'Current space cannot support the reference-volume scenario. No historical cache or cold tranche is counted without new exact verified savings.',
      'Fresh root capacity release must cover retained smoke/timing, maximum in-progress member reservation and reviewed restore/final margin before launch.'],
    next_action='Root capacity owner must freeze a finite additional recovery proposal using only positively identified rebuildable cache or separately authorized exact-byte cold/staging-duplicate retirement, independently verify originals/object catalog and actual savings, then re-read df. Do not count previously reclaimed caches, already-cold originals or current/fault evidence. This preparation does not authorize any unlink/conversion.'))

changes={}
for original in sorted((H/'origins').glob('*.py')):
    current=H/original.name
    if not current.exists():continue
    old=original.read_text();new=current.read_text();ast.parse(new,filename=str(current))
    (H/(original.name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(BASE/original.name),tofile=str(current))))
    before,after=funcs(old),funcs(new)
    changes[original.name]=dict(unchanged=[n for n in before if n in after and before[n]==after[n]],
        changed=[n for n in before if n in after and before[n]!=after[n]],removed=sorted(set(before)-set(after)),added=sorted(set(after)-set(before)))
save('function-delta.json',changes)
for p in H.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
test_counts={p.name:sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse(p.read_text()))) for p in H.glob('test_*.py')}
save('STATIC.json',dict(complete=True,scope='AST syntax and finite text/function comparison only; no helper/contract/runtime execution',
    contract_counts=test_counts,driver_unchanged_native_trial=changes['matched-driver.py']['unchanged'].count('native_trial')==1,
    wrapper_byte_identical=sha(H/'isolate-and-run.py')==sha(BASE/'isolate-and-run.py'),
    helper_functions_unchanged=all(not changes[n]['changed'] for n in ['compressed_retention.py','retention_audit.py']),
    original_smoke_repair_sha256=sha(H/'origins/repaired-redis3-audit.py'),
    root_acceptance_provenance='Repaired baseline audit root59024/0, toolb37127 supplied by root; accepted original read-only metadata bound in capacity.json. No candidate acceptance transfer.'))
save('READINESS.json',dict(preparation_complete=True,runtime_ready=False,tests_executed=False,
    pending=['Root finite 8 driver +15 auditor +5 native smoke-schema contracts, preserve all first outputs.',
      'Root current source/executable/compiler/input inventory readback (driver source contract performs exact three-role preflight).',
      'Root reviewed additional capacity, fresh environment/isolation/no-active-codec-or-workload release.',
      'First original 8 smoke, terminal review, then first original16 timing, terminal independent audit.'],
    driver_sha256=sha(H/'matched-driver.py'),audit_sha256=sha(H/'audit.py'),arguments_sha256=sha(H/'driver-arguments.json'),
    commands_sha256=sha(H/'commands.json'),protocol_sha256=sha(H/'protocol.json')))
print(json.dumps(dict(static_metadata_complete=True,contracts_executed=False,counts=test_counts,
    same_observed_volume_bytes=scenario,available_above_floor=space['/tmp']['available_bytes']-floor,
    scenario_additional_bytes=max(0,floor+scenario+cohort+reserve-space['/tmp']['available_bytes'])),indent=2))
