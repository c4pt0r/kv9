#!/usr/bin/env python3
"""Synthetic controls for the exact repaired smoke blocks; no audit/codec import."""
import ast
import copy
import unittest
from pathlib import Path
H=Path(__file__).resolve().parent
SOURCE=(H/'audit.py').read_text()
TREE=ast.parse(SOURCE)

def require(ok,message):
    if not ok:raise ValueError(message)

def cleanup_block():
    loops=[n for n in ast.walk(TREE) if isinstance(n,ast.For) and any(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cleanup_ok' for t in x.targets) for x in n.body)]
    assert len(loops)==1
    body=loops[0].body
    i=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cleanup_ok' for t in n.targets))
    return compile(ast.Module(body=body[i:i+2],type_ignores=[]),'<exact-repaired-cleanup>','exec')

def binary_block():
    candidates=[n for n in ast.walk(TREE) if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='native_smoke' and "identity['executable_sha256']" in ast.get_source_segment(SOURCE,n)]
    assert len(candidates)==1
    return compile(ast.Module(body=candidates,type_ignores=[]),'<exact-repaired-binary>','exec')

def check_cleanup(cl,native,exit_code=0):
    exec(cleanup_block(),{'cl':cl,'native_smoke':native,'read':lambda _: {'exit_code':exit_code},'sd':Path('/synthetic'), 'require':require})

def check_binary(identity,native,actual='a'*64):
    calls=[]
    def sha(path):calls.append(path);return actual
    exec(binary_block(),{'identity':identity,'native_smoke':native,'expected_sha':'a'*64,'sha':sha,'require':require})
    return calls

class SmokeSchemaRepair(unittest.TestCase):
    def test_both_original_cleanup_shapes_accept(self):
        native={'complete':True,'children':[{} for _ in range(4)],'storage':'tmpfs'}
        redis={'errors':[],'children':[{} for _ in range(4)]}
        check_cleanup(native,True);check_cleanup(redis,False)
        self.assertNotIn('errors',native);self.assertNotIn('complete',redis)

    def test_cleanup_failure_incomplete_wrong_storage_and_missing_schema_refuse(self):
        native={'complete':True,'children':[{} for _ in range(4)],'storage':'tmpfs'}
        redis={'errors':[],'children':[{} for _ in range(4)]}
        for field,value in [('complete',False),('complete',1),('storage','wal')]:
            bad=copy.deepcopy(native);bad[field]=value
            with self.subTest(native_field=field,value=value),self.assertRaises(ValueError):check_cleanup(bad,True)
        for value in ([{'failure':'owned child'}],None,False):
            bad=copy.deepcopy(redis);bad['errors']=value
            with self.subTest(errors=value),self.assertRaises(ValueError):check_cleanup(bad,False)
        for cl,native_role in [(native,True),(redis,False)]:
            bad=copy.deepcopy(cl);bad['children'].pop()
            with self.assertRaises(ValueError):check_cleanup(bad,native_role)
            with self.assertRaises(ValueError):check_cleanup(cl,native_role,exit_code=1)
        with self.assertRaises(KeyError):check_cleanup(redis,True)
        with self.assertRaises(KeyError):check_cleanup(native,False)

    def test_native_hash_and_redis_path_positive(self):
        self.assertEqual(check_binary({'executable_sha256':'a'*64},True),[])
        self.assertEqual(check_binary({'executable':'/synthetic/redis'},False),['/synthetic/redis'])

    def test_wrong_or_missing_executable_identity_refuses(self):
        with self.assertRaises(ValueError):check_binary({'executable_sha256':'b'*64},True)
        with self.assertRaises(ValueError):check_binary({'executable':'/synthetic/redis'},False,actual='b'*64)
        with self.assertRaises(KeyError):check_binary({'executable':'/synthetic/native'},True)
        with self.assertRaises(KeyError):check_binary({'executable_sha256':'a'*64},False)

    def test_executed_producer_paths_and_all_functions_remain_original(self):
        old=(H/'originals/audit.py').read_text()
        def functions(text):return {n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        self.assertEqual(functions(old),functions(SOURCE))
        for name in ('matched-driver.py','compressed_retention.py'):
            self.assertIn("matrix['helper_hashes']['/tmp/kv9-write-redis3-timing-preparation-first/"+name+"']",SOURCE)
            self.assertNotIn("matrix['helper_hashes'][str(Path(__file__).with_name('"+name+"'))]",SOURCE)
        for text in ["life not in smoke_lifetimes", "child.get('absent',child.get('pid_absent_after_reap'))", "not Path('/proc',str(identity['pid'])).exists()", "child['exit_code']==(0 if client or not native_smoke else -9)"]:
            self.assertIn(text,old);self.assertIn(text,SOURCE)

if __name__=='__main__':unittest.main(verbosity=2)
