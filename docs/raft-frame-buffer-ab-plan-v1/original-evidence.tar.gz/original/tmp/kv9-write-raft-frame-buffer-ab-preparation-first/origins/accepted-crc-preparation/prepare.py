#!/usr/bin/env python3
"""One-time finite text/AST derivative; does not execute any fixture or contract."""
from pathlib import Path
import ast, difflib, hashlib, json
HERE=Path(__file__).resolve().parent
BASE=Path('/tmp/kv9-thin-lto-compressed-performance-preparation-first')
REPAIR=Path('/tmp/kv9-write-redis3-audit-repair-first')
PROTO='kv9-write-crc-slicing8-ab-c1-c64-v1'
SMOKE='/tmp/kv9-write-crc-slicing8-ab-smoke-first'
TIMING='/tmp/kv9-write-crc-slicing8-ab-timing-first'
REPLACEMENTS={
 'ca0002c7f8e9ee6f595efcc9f4151085ccce87cb':'11113f68f6a5df77da1ffb4fcec850953716ffa3',
 '02d0c01024b65a84b220c6948ff2224bfa7900bc':'e748620a7b0ba326ac5f4fa8e3a6b1ff48553c6a',
 'b33b5d302f901aac5cf6a95449b9bb5dd68473747e011220dbed7aed2e591d13':'dd028cb2f61633dda133b05d814a6d173a79a83145d8ced2f81dc0cf8e0f33bc',
 'dd028cb2f61633dda133b05d814a6d173a79a83145d8ced2f81dc0cf8e0f33bc':'616eed1b823dfaa192a22b2b03a3e7d778bf71efdad7d2b875a49c4bfc94e476',
 '8c2ea115afc1ec8b6c82224dc6449d1d2439f5f27b5758e45090589752d186e8':'582ee4f5840aa8cf04168ee8aeffe92250ed0807ee3f53aea93b25d3494b809d',
 'f336886f07cd42dd1bd37388351e1c93c41ed828d6da31c23e4e87726a2075a0':'32cf899d55b7160f5c3aacfff24da0d145d381e5082b2a6925b94b4cedcf1463',
 '/tmp/kv9-wal-crc32-table':'/tmp/kv9-thin-lto-main-integration-first',
 '/tmp/kv9-wal-crc32-release-first':'/tmp/kv9-thin-lto-main-integration-release-verbose-first',
 '/tmp/kv9-release-thin-lto-release-first':'/tmp/kv9-write-crc-slicing8-release-first',
 '/tmp/kv9-release-thin-lto':'/tmp/kv9-write-crc-slicing8-thinlto-first',
 str(BASE):str(HERE),
 '/tmp/kv9-thin-lto-compressed-performance-smoke-first':SMOKE,
 '/tmp/kv9-thin-lto-compressed-performance-timing-first':TIMING,
 'kv9-thin-lto-compressed-broad-workloads-c1-c64-v1':PROTO,
}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,x): (HERE/name).write_text(json.dumps(x,indent=2)+'\n')
def replace_all(s):
    # Simultaneous replacement: the new control SHA is the old candidate SHA.
    import re
    return re.sub('|'.join(re.escape(k) for k in sorted(REPLACEMENTS,key=len,reverse=True)),lambda m:REPLACEMENTS[m[0]],s)
def one(s,a,b):
    assert s.count(a)==1,(a,s.count(a))
    return s.replace(a,b)
def funcs(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
def replace_func(s,name,fn):return one(s,funcs(s)[name],fn)
original={}
for name in ['matched-driver.py','audit.py','isolate-and-run.py','compressed_retention.py','retention_audit.py','test_driver.py','test_audit_contract.py']:
    original[name]=(BASE/name).read_text()
    (HERE/'origins'/name).write_bytes((BASE/name).read_bytes())
(HERE/'origins/repaired-redis3-audit.py').write_bytes((REPAIR/'audit.py').read_bytes())
(HERE/'origins/test_smoke_schema_repair.py').write_bytes((REPAIR/'test_smoke_schema_repair.py').read_bytes())
for name in ['compressed_retention.py','retention_audit.py']:
    (HERE/name).write_text(replace_all(original[name]))
(HERE/'isolate-and-run.py').write_text(original['isolate-and-run.py'])
ret_sha=sha(HERE/'compressed_retention.py');reader_sha=sha(HERE/'retention_audit.py')
d=replace_all(original['matched-driver.py'])
d=d.replace('Matched v3 point and native batch64 read/write/mixed diagnostic.','Matched native v3 point Put and BatchPut64 diagnostic screening.')
d=one(d,'WORKLOAD_CELLS = [(name, batch, reads) for name, batch in (("point", 1), ("batch64", 64))\n                  for reads in (0, 50, 100)]','WORKLOAD_CELLS = [("point", 1, 0), ("batch64", 64, 0)]')
d=d.replace('for role in ("old", "new", "redis")','for role in ("old", "new")')
d=d.replace('(36 if smoke else 72)','(8 if smoke else 16)')
d=d.replace('        ("client", args.client_source, args.client_build, args.expected_client_revision, "kv9-batch-benchmark"),\n        ("redis", args.redis_client_source, args.redis_client_build, REDIS_REVISION, "kv9-redis-batch-reference")):',
'''        ("client", args.client_source, args.client_build, args.expected_client_revision, "kv9-batch-benchmark"),):''')
d=one(d,'    require(roles["client"]["source"]["sources"][common] == roles["redis"]["source"]["sources"][common],\n            "native/Redis deterministic payload or scheduling source differs")\n','')
d=one(d,'(("client", args.client_build, args.expected_client_revision, False),\n                                            ("redis", args.redis_client_build, REDIS_REVISION, True))','(("client", args.client_build, args.expected_client_revision, False),)')
d=d.replace('    parser.add_argument("--redis-client-source", type=Path, default=Path("/tmp/kv9-point-write-measurement-v3"))\n','')
d=d.replace('    parser.add_argument("--redis-client-build", type=Path, default=Path("/tmp/kv9-point-write-v3-release-first/redis"))\n','')
d=d.replace('    parser.add_argument("--redis-server", type=Path, default=Path("/usr/bin/redis-server"))\n','')
d=d.replace('"new_server_build", "redis_client_source", "redis_client_build", "output", "redis_server", "resp_helper"','"new_server_build", "output", "resp_helper"')
d=d.replace(', args.redis_client_source)',')').replace(', args.redis_client_build)',')')
d=d.replace('args.redis_client_source / "scripts/redis_batch_report.py"','args.client_source / "scripts/redis_batch_report.py"')
d=d.replace('    args.redis_server_sha256 = digest(args.redis_server)\n','')
d=d.replace('(("client", args.client_source), ("redis", args.redis_client_source))','(("client", args.client_source),)')
d=d.replace('(("client", args.client_source), ("redis"))','(("client", args.client_source),)')
d=d.replace('1d7cc22cb071516504832822dcc01b7f132ee768671584eda1087844846ac8cf',ret_sha)
d=d.replace('36-cohort v3 c1/c64 correctness smoke only; no timing acceptance','8-cohort native v3 point Put/BatchPut64 c1/c64 correctness smoke only; no timing acceptance')
d=d.replace('72-cohort shared-host v3 point/batch64 read/write/mixed diagnostic; no exclusive host or equivalent durability','16-cohort shared-host native v3 point Put/BatchPut64 c1/c64 diagnostic screen; no promotion, read/mixed regression or Chaos acceptance')
d=d.replace('                redis_durability="Standalone memory; save/AOF disabled; no replicas", comparable_durability=False,\n','                comparable_durability=True,\n')
d=d.replace('                redis_server_sha256=args.redis_server_sha256, helper_hashes=helper_hashes,','                helper_hashes=helper_hashes,')
d=d.replace('        require(digest(args.redis_server) == args.redis_server_sha256, "Redis server executable changed during matrix")\n','')
# The existing reference configuration oracle and unused Redis function remain
# byte-identical; no Redis executable role is admitted or launched by this plan.
(HERE/'matched-driver.py').write_text(d)
argv=json.loads((BASE/'driver-arguments.json').read_text());argv=[replace_all(x) for x in argv]
for flag in ['--redis-client-source','--redis-client-build']:
    i=argv.index(flag);del argv[i:i+2]
save('driver-arguments.json',argv)
a=replace_all(original['audit.py'])
a=a.replace('Independent 72-cohort v3 read/write diagnostic readback','Independent 16-cohort native v3 write-only diagnostic readback')
a=a.replace('choices=(72,)','choices=(16,)')
a=one(a,"WORKLOADS = (('point-r000',1,0), ('point-r050',1,50), ('point-r100',1,100),\n             ('batch64-r000',64,0), ('batch64-r050',64,50), ('batch64-r100',64,100))","WORKLOADS = (('point-r000',1,0), ('batch64-r000',64,0))")
a=a.replace("ROLES = ('old', 'new', None)","ROLES = ('old', 'new')")
a=a.replace(" 'redis': (REDIS_REV, '5a8ac274b8cc6548a072f5305b04936a08cc4d1ba84d50150f675bab563049af'),\n",'')
a=a.replace(" 'redis': ('/tmp/kv9-point-write-measurement-v3', '/tmp/kv9-point-write-v3-release-first/redis', 'kv9-redis-batch-reference'),\n",'')
a=a.replace("                   '--redis-client-source','/tmp/kv9-point-write-measurement-v3',\n                   '--redis-client-build','/tmp/kv9-point-write-v3-release-first/redis','--storage','tmpfs']","                   '--storage','tmpfs']")
a=a.replace('0ac09dc9577eff4cd866cfbfdbbf76a52adb8943e3ac558bf2a0f395deecc7c2',sha(HERE/'driver-arguments.json'))
a=a.replace("for role,reference in (('client',False),('redis',True)):","for role,reference in (('client',False),):")
a=a.replace('5efc08b0a73a2ce02138822899b9765e6b66a49df936eb2f526a3987c1050c4b',reader_sha)
a=a.replace('1d7cc22cb071516504832822dcc01b7f132ee768671584eda1087844846ac8cf',ret_sha)
a=a.replace('==72','==16').replace('seventy-two','sixteen')
a=a.replace('len(smoke_retention)==24','len(smoke_retention)==8')
a=a.replace('len(retention_summaries)==48','len(retention_summaries)==16')
a=a.replace('len(lifetimes)==240 and drains==144 and writer_bindings==144','len(lifetimes)==64 and drains==48 and writer_bindings==48')
a=a.replace('def validate_requested_config(config, repeat, concurrency, workload, server):','def validate_requested_config(config, repeat, concurrency, workload, server, smoke=False):')
a=one(a,"    expected=dict(descriptor['shared'])\n","    expected=dict(descriptor['shared'])\n    if smoke: expected['measure_ms']=2000\n")
paired="""    for repeat in (0,1):
        for concurrency in CONCURRENCIES:
            for workload,_,_ in WORKLOADS:
                for server in ('old','new'):
                    redis.paired_configuration(configs[(repeat,concurrency,'redis-'+workload)],
                                               configs[(repeat,concurrency,server+'-'+workload)])
"""
a=one(a,paired,"""    for repeat in (0,1):
        for concurrency in CONCURRENCIES:
            for workload,_,_ in WORKLOADS:
                old_config=configs[(repeat,concurrency,'old-'+workload)]
                new_config=configs[(repeat,concurrency,'new-'+workload)]
                excluded={'client'}  # peer addresses/keyspace IDs are owned per fixture
                require(same_json({k:v for k,v in old_config.items() if k not in excluded},
                                  {k:v for k,v in new_config.items() if k not in excluded}),
                        'native paired workload bytes differ')
""")
# Import the exact accepted native smoke schema correction into this native-only
# derivative. Its report/exit/identity predicates are preserved, not inferred.
r=(REPAIR/'audit.py').read_text();block=r[r.index('    smoke_root='):r.index('    prior_smoke_bytes=')]
block=block.replace('==12','==8').replace('[:12]','[:8]').replace('==48','==32').replace('exited=48','exited=32')
block=block.replace("native_smoke=target=='kv9'","native_smoke=target is not None")
block=block.replace("'client' if client else 'selected'","'client' if client else target")
block=block.replace("        if not native_smoke:\n            dataset,observation=redis3_checks.validate(sd,sc,sr,cl,read,read_text,server_cpus=list(range(8,16))+list(range(22,32)))\n            dataset_check(sc,dataset)\n",'')
# Unreachable Redis branch in the copied smoke fragment is removed explicitly.
block=block.replace("        sv=(native if native_smoke else redis).validate", "        sv=native.validate")
block=block.replace("native_smoke=target is not None;role='client' if native_smoke else 'redis'", "native_smoke=True;role='client'")
block=block.replace("        cleanup_ok = (cl['complete'] is True and cl['storage']=='tmpfs') if native_smoke else cl['errors']==[]", "        cleanup_ok = cl['complete'] is True and cl['storage']=='tmpfs'")
block=block.replace("            expected_sha=PINS['client' if client else target][1] if native_smoke else (PINS['redis'][1] if client else REDIS_SERVER_SHA)\n            if native_smoke:\n                require(identity['executable_sha256']==expected_sha,'smoke executing binary differs')\n            else:\n                require(sha(identity['executable'])==expected_sha,'smoke executing binary differs')", "            expected_sha=PINS['client' if client else target][1]\n            require(identity['executable_sha256']==expected_sha,'smoke executing binary differs')")
a=a[:a.index('    smoke_root=')]+block+a[a.index('    prior_smoke_bytes='):]
a=a.replace("scope='Shared-host short diagnostic only; not exclusive-host or production acceptance'","scope='Native point Put/BatchPut64 c1/c64 write-only screening; no read/mixed regression, Chaos or promotion acceptance'")
(HERE/'audit.py').write_text(a)

t=replace_all(original['test_driver.py'])
t=t.replace('test_independent_72_order_and_exact_36_smoke','test_independent_16_order_and_exact_8_smoke')
t=t.replace('for reads in [0, 50, 100] for role in [\'old\', \'new\', \'redis\']',"for reads in [0] for role in ['old', 'new']")
t=t.replace('len(plan), 72','len(plan), 16').replace('repeat*36:(repeat+1)*36','repeat*8:(repeat+1)*8').replace('len(smoke), 36','len(smoke), 8').replace('plan[:36]','plan[:8]')
t=t.replace("'verify_client_cargo','fresh_drain'","'fresh_drain'")
t=t.replace("        row=next(r for r in d.make_plan(False) if r['server_role']=='old' and r['shared']['read_percent']==50)","        row=copy.deepcopy(d.make_plan(False)[0]);row['shared']['read_percent']=50  # unchanged generic population contract")
t=t.replace("{'old','new','client','redis'}","{'old','new','client'}")
t=t.replace("        self.assertEqual(roles['client']['source'],roles['redis']['source'])\n",'')
t=t.replace("[cargo[k]['features'] for k in ('client','redis')],[[],[]]","[cargo[k]['features'] for k in ('client',)],[[]]")
(HERE/'test_driver.py').write_text(t)

t=replace_all(original['test_audit_contract.py'])
# Generic oracle configs retain all old mix cases; the independently enumerated
# accepted matrix is the strict write-only subset.
t=t.replace("workloads=WORKLOAD_ROWS if repeat==0 else list(reversed(WORKLOAD_ROWS))","writes=[r for r in WORKLOAD_ROWS if r[2]==0]\n            workloads=writes if repeat==0 else list(reversed(writes))")
t=t.replace("(('old','new','redis') if repeat==0 else ('redis','new','old'))","(('old','new') if repeat==0 else ('new','old'))")
t=t.replace("for name,batch,reads in WORKLOAD_ROWS],","for name,batch,reads in WORKLOAD_ROWS if reads==0],")
t=t.replace('test_exact_72_entire_reverse_order_and_run_ids','test_exact_16_entire_reverse_order_and_run_ids')
t=t.replace('len(expected),72','len(expected),16')
t=t.replace('(0,18,36,54,71)','(0,4,8,12,15)')
t=t.replace("(1,'redis-batch64-r100','p10064'),(1,'redis-batch64-r100','p10001')","(1,'new-batch64-r000','p10064'),(1,'new-batch64-r000','p10001')")
t=t.replace('[36:]','[8:]').replace('[54:]','[12:]').replace('[36:54]','[8:12]').replace('[18:36]','[4:8]').replace('[:18]','[:4]').replace('[:36]','[:8]').replace('[{}]*36','[{}]*8').replace('[{}]*48','[{}]*12')
t=t.replace("for workload,_,_ in WORKLOAD_ROWS:\n                    for server in ('old','new',None):","for workload,_,_ in [r for r in WORKLOAD_ROWS if r[2]==0]:\n                    for server in ('old','new'):")
# Config failure control stays native; absent Redis role is never used as an
# accepted requested configuration.
t=t.replace("c=config(0,1,'point-r000',None);c[field]=value","c=config(0,1,'point-r000','old');c[field]=value")
t=t.replace("(c,0,1,'point-r000',None)","(c,0,1,'point-r000','old')")
t=t.replace("{'old','new','client','redis'}","{'old','new','client'}")
(HERE/'test_audit_contract.py').write_text(t)

changes={}
for name,s in original.items():
    updated=(HERE/name).read_text();ast.parse(updated,filename=str(HERE/name))
    (HERE/(name+'.diff')).write_text(''.join(difflib.unified_diff(s.splitlines(True),updated.splitlines(True),fromfile=str(BASE/name),tofile=str(HERE/name))))
    before,after=funcs(s),funcs(updated)
    changes[name]=dict(unchanged=[n for n in before if n in after and before[n]==after[n]],
                      changed=[n for n in before if n in after and before[n]!=after[n]],
                      removed=sorted(set(before)-set(after)),added=sorted(set(after)-set(before)))
save('function-delta.json',changes)
save('preparation-read-observation.json',dict(first_read_failure=dict(tool_chunk='52749d',exit_code=1,
    reason='bounded text reader searched for class Contracts; actual original class is AuditContract',
    scope='preparation text lookup only; no contract, fixture, audit or input mutation'),
    corrected_read=dict(tool_chunk='f30593',exit_code=0)))
print(json.dumps({'prepared':str(HERE),'driver':sha(HERE/'matched-driver.py'),'audit':sha(HERE/'audit.py'),'argument_file':sha(HERE/'driver-arguments.json'),'contracts_executed':False},indent=2))
