#!/usr/bin/env python3
"""Publish bounded preparation metadata; never launch the benchmark."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

REPO = Path('/home/dongxu/kv9')
OUT = REPO / 'docs/raft-frame-buffer-ab-plan-v1'
PREP = Path('/tmp/kv9-write-raft-frame-buffer-ab-preparation-first')
CAP = Path('/tmp/kv9-write-raft-frame-buffer-ab-capacity-preparation-first')
CONTROLS = Path('/tmp/kv9-write-raft-frame-buffer-ab-contract-root-first')
LIMIT = 64 * 1024 * 1024
inputs = {}


def include(path, expected=None):
    path = Path(path)
    assert path.is_absolute() and path.is_file() and not path.is_symlink(), path
    assert path.stat().st_size <= 8 * 1024 * 1024, path
    data = path.read_bytes()
    actual = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if expected is not None:
        assert actual == {k: expected[k] for k in actual}, path
    inputs[str(path)] = actual


for root, pin, key in [
    (PREP, 'd949a45598b4a15e3db387c02d8d99a4262efe962f78306e0768e656bcd80a98', 'files'),
    (CAP, '93831f17cb6c7e4df40f724d83eb0782836a6420b8917fe8efe4e022d1316780', 'entries'),
]:
    inv = root / 'inventory.json'
    assert hashlib.sha256(inv.read_bytes()).hexdigest() == pin
    include(inv)
    for relative, expected in json.loads(inv.read_text())[key].items():
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        include(root / relative, expected)

for path in sorted(CONTROLS.iterdir()):
    include(path)
for path, expected in json.loads((CAP / 'result-first.json').read_text())['input_bindings'].items():
    include(path, expected)
include(Path(__file__).resolve())

total = sum(row['bytes'] for row in inputs.values())
assert total <= 20 * 1024 * 1024
existing = sum(p.stat().st_size for p in (REPO / 'docs').rglob('original-evidence.tar.gz'))
assert shutil.disk_usage(REPO).free >= 96 * 1024**3 + 32 * 1024**2
OUT.mkdir(exist_ok=False)
archive = OUT / 'original-evidence.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as tar:
            for source, expected in sorted(inputs.items()):
                data = Path(source).read_bytes()
                assert len(data) == expected['bytes']
                assert hashlib.sha256(data).hexdigest() == expected['sha256']
                info = tarfile.TarInfo('original/' + source.lstrip('/'))
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
assert existing + archive.stat().st_size <= LIMIT
manifest = {
    'scope': 'Frozen preparation, local control receipts and capacity metadata; no frame performance run',
    'inputs': inputs,
    'member_count': len(inputs),
    'decoded_bytes': total,
    'archive_bytes': archive.stat().st_size,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'main_original_evidence_bytes_after': existing + archive.stat().st_size,
    'main_original_evidence_allowance_bytes': LIMIT,
    'runtime_executed': False,
    'capacity_qualified': False,
}
(OUT / 'inventory.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'inputs'}))
