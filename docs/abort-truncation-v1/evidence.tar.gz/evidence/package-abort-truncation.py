import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

root = Path('/home/dongxu/kv9')
work = Path('/mnt/data/kv9-work/abort-truncation-20260917')
out = root / 'docs/abort-truncation-v1'
e2e = json.loads((work / 'e2e-fifth/result.json').read_text())
assert e2e['verdict'] == 'accepted' and not e2e['chaos_mesh']
local = json.loads((work / 'local-validation.json').read_text())
assert local['schema'] == 1
out.mkdir(exist_ok=False)
files, excluded = {}, []
for p in sorted(work.rglob('*')):
    if not p.is_file() or p.is_symlink():
        continue
    r = p.relative_to(work)
    if '__pycache__' in r.parts or p.suffix in ('.olean', '.ilean', '.pyc'):
        continue
    if p.name.startswith('issue') or 'issues' in r.parts or p.name in ('publication.json', 'handoff-in.md'):
        continue
    if p.name in ('kubeconfig', 'token', 'credentials', 'root.bin') or p.suffix in ('.key', '.pem'):
        excluded.append(str(r))
        continue
    with p.open('rb') as stream:
        magic = stream.read(4)
    if magic == b'\x7fELF':
        excluded.append(str(r))
        continue
    files['evidence/' + str(r)] = p
names = set()
for model in ['abort-truncation', 'admission-floor', 'deferred-sync', 'proposal-batching', 'migration-abort', 'storage-reclamation', 'cascade-split', 'auto-split', 'cross-range', 'parent-retirement', 'split-publication',
              'child-population', 'parent-seal', 'partition-directory', 'split-intent',
              'storage-retirement', 'replica-removal', 'voter-promotion', 'source-truncation',
              'install-evidence', 'runtime-adoption', 'learner-attach', 'source-capture',
              'migration-authority', 'joint-install', 'protocol-snapshot', 'group-preparation',
              'group-activation', 'group-control', 'data-range', 'routed-client']:
    c = root / 'proofs/lean' / model / 'source-contract.json'
    names.add(str(c.relative_to(root)))
    names.update(json.loads(c.read_text())['source_sha256'])
names.update(['scripts/prove-abort-truncation.py', 'scripts/abort-truncation-e2e.py',
              'scripts/check-retention-ledger.py',
              'proofs/tlaps/retention_ledger/inventory.json',
              'docs/ABORT-TRUNCATION.md', 'docs/MIGRATION-ABORT.md',
              'docs/HORIZONTAL-SCALING-PLAN.md',
              'Cargo.toml', 'Cargo.lock'])
for command in [['git', 'diff', '--name-only'], ['git', 'ls-files', '--others', '--exclude-standard']]:
    for name in subprocess.check_output(command, cwd=root, text=True).splitlines():
        if name not in ('scripts/checkpoint-publication-chaos.py', 'scripts/checkpoint-owned-crash.py') \
                and not name.startswith('docs/abort-truncation-v1/'):
            names.add(name)
for name in names:
    if (root / name).is_file():
        files['source/' + name] = root / name
members, total = [], 0
with (out / 'evidence.tar.gz').open('wb') as raw, \
        gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as gz, \
        tarfile.open(fileobj=gz, mode='w|') as tar:
    for name, p in sorted(files.items()):
        data = p.read_bytes()
        total += len(data)
        assert total <= 256 * 1024 ** 2
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
        members.append({'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert (out / 'evidence.tar.gz').stat().st_size <= 60 * 1024 ** 2
with tarfile.open(out / 'evidence.tar.gz', 'r:gz') as tar:
    actual = []
    for m in tar:
        assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
        d = tar.extractfile(m).read()
        actual.append({'name': m.name, 'bytes': len(d), 'sha256': hashlib.sha256(d).hexdigest()})
assert actual == members
artifact = out / 'evidence.tar.gz'
summary = {
    'schema': 1,
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'archive_sha256': hashlib.sha256(artifact.read_bytes()).hexdigest(),
    'archive_bytes': artifact.stat().st_size,
    'decoded_bytes': total,
    'members': members,
    'excluded_files': excluded,
    'accepted': {
        'local': 'evidence/local-validation.json',
        'abort_truncation_proof': 'evidence/abort-truncation-proof/result.json',
        'sibling_lean_models': [f'evidence/{m}-proof.log' for m in [
            'data-range', 'group-activation', 'group-control', 'group-preparation', 'joint-install',
            'learner-attach', 'migration-authority', 'protocol-snapshot', 'routed-client',
            'source-capture', 'runtime-adoption', 'install-evidence', 'source-truncation',
            'voter-promotion', 'replica-removal', 'storage-retirement', 'split-intent',
            'partition-directory', 'parent-seal', 'child-population', 'split-publication',
            'parent-retirement', 'cross-range', 'auto-split', 'cascade-split', 'storage-reclamation', 'migration-abort', 'proposal-batching', 'deferred-sync', 'admission-floor']],
        'retention_tlaps': 'evidence/retention-ledger-recheck.log',
        'minio_focused': 'evidence/minio-focused.log',
        'e2e': 'evidence/e2e-fifth/result.json',
        'also_accepted': ['evidence/e2e-third/result.json'],
        'failed_e2e_retained': ['evidence/e2e-first', 'evidence/e2e-second', 'evidence/e2e-fourth'],
    },
    'not_claimed': ['healthy-group (non-migration) log compaction',
                    'bounded log growth in general',
                    'physical reclamation of compacted segments',
                    'Chaos Mesh for this increment', 'performance claims',
                    'general concurrent linearizability', 'verified Rust extraction',
                    'hosted CI'],
}
(out / 'validation.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ['archive_sha256', 'archive_bytes', 'decoded_bytes']}))
print('members', len(members))
