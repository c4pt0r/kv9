# Abort-settled truncation — task #34

Baseline: 2c09a2e. Port 27340. Serial 947.

## Design (surveyed)
- truncate_source_log (raft level) is ALREADY safe independent of
  evidence: leader-only + ALL-MATCHED >= floor + REC_COMPACTION +
  deferred-sync barrier; compaction is LOCAL prefix only (followers
  keep their logs; matched => appended+synced locally, so no follower
  ever re-fetches <= floor; disk-loss = new incarnation = abort story).
- The evidence requirement in plan_truncation is the CATALOG settlement
  gate. Change: settlement = committed EVIDENCE (floor <= cut, as
  today) OR committed ABORT (region binding; no cut bound — the raft
  all-matched gate is the floor's guard). Row field evidence_task
  becomes the settlement task (points at kind-104 OR kind-108; readback
  resolves and validates whichever).
- runtime record_source_truncation: derive owner ids from evidence OR
  abort (destination incarnation from the abort row); Released-pin
  check identical (abort settlement releases the pin).
- e2e: full abort flow (from migration-abort-e2e) + record-truncation
  (floor = leader applied) + truncate at source leader + restart all
  voters + group keeps serving/writing.
- Lean: new model proofs/lean/abort-truncation (~12 theorems:
  truncation requires exactly one committed settlement; the abort path
  still requires the released pin and the all-matched floor; local
  prefix only; a lagging voter blocks).

## Status
- [ ] truncation.rs settlement alternative + tests
- [ ] runtime owner derivation + tests
- [ ] e2e + Lean + prover + contract + qualify (31 models) + packet
