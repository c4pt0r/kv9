# FNV write-tail host observations

All16 original timed cohorts are included. This is descriptive analysis of hash-bound accepted inputs, not a rerun or a causal attribution of request tails. Old is selected CRC bd42e60; new is FNV12f44d.

## Four c64 BatchPut64 cohorts

| # / role / order | cell | calls/s | p99 bucket ms | CPU2–5 busy / iowait % | host CPU PSI some % | host IO PSI some / full % | max resource gap ms |
|---|---|---:|---|---|---:|---|---:|
| 06 old forward | c64 batch64 | 16355.6 | [7.864, 7.930] | 83.91 / 0.000 | 42.204 | 0.1343 / 0.1283 | 53.81 |
| 07 new forward | c64 batch64 | 16578.8 | [12.059, 12.190] | 82.46 / 0.000 | 42.221 | 0.4933 / 0.4851 | 53.49 |
| 08 new reverse | c64 batch64 | 17688.4 | [6.685, 6.750] | 84.18 / 0.000 | 45.204 | 0.0968 / 0.0948 | 54.55 |
| 09 old reverse | c64 batch64 | 16552.2 | [7.340, 7.406] | 83.94 / 0.000 | 42.903 | 0.1134 / 0.1113 | 54.30 |

CPU busy is averaged over the observed CPU2–5 counter interval. Host PSI is global stalled wall time, not CPU utilization or exclusive voter pressure.

| # / voter | RSS first → last MiB | RSS min–max MiB | threads first → last (min–max) | sampled process CPU cores |
|---|---|---|---|---:|
| 06 voter-1 | 27.6 → 1986.4 | 27.6–1986.4 | 4 → 4 (4–4) | 0.719 |
| 06 voter-2 | 46.4 → 2589.5 | 46.4–2589.5 | 56 → 71 (56–71) | 1.900 |
| 06 voter-3 | 26.9 → 1987.0 | 26.9–1987.0 | 4 → 4 (4–4) | 0.716 |
| 07 voter-1 | 28.1 → 2015.9 | 28.1–2015.9 | 4 → 4 (4–4) | 0.684 |
| 07 voter-2 | 50.4 → 2629.2 | 50.4–2629.2 | 53 → 71 (53–71) | 1.912 |
| 07 voter-3 | 29.0 → 2015.4 | 29.0–2015.4 | 4 → 4 (4–4) | 0.681 |
| 08 voter-1 | 29.8 → 2139.0 | 29.8–2139.0 | 4 → 4 (4–4) | 0.681 |
| 08 voter-2 | 48.1 → 2791.5 | 48.1–2791.5 | 48 → 89 (48–89) | 1.988 |
| 08 voter-3 | 30.4 → 2140.0 | 30.4–2140.0 | 4 → 4 (4–4) | 0.683 |
| 09 voter-1 | 27.3 → 2013.1 | 27.3–2013.1 | 4 → 4 (4–4) | 0.719 |
| 09 voter-2 | 46.6 → 2627.4 | 46.6–2627.4 | 59 → 72 (59–72) | 1.913 |
| 09 voter-3 | 28.5 → 2016.0 | 28.5–2016.0 | 4 → 4 (4–4) | 0.721 |

## All16 cohorts

| # / role / order | cell | calls/s | p99 bucket ms | CPU2–5 busy / iowait % | host CPU PSI some % | host IO PSI some / full % | max resource gap ms |
|---|---|---:|---|---|---:|---|---:|
| 00 old forward | c1 point | 19225.3 | [0.069, 0.070] | 64.43 / 0.000 | 8.259 | 0.0751 / 0.0725 | 52.08 |
| 01 new forward | c1 point | 19544.2 | [0.066, 0.067] | 64.54 / 0.000 | 8.287 | 0.0703 / 0.0662 | 52.36 |
| 02 old forward | c1 batch64 | 6245.0 | [0.203, 0.205] | 42.49 / 0.000 | 5.525 | 0.1315 / 0.1285 | 52.48 |
| 03 new forward | c1 batch64 | 6143.1 | [0.207, 0.209] | 42.36 / 0.000 | 5.497 | 0.1591 / 0.1571 | 52.19 |
| 04 old forward | c64 point | 139071.5 | [0.737, 0.745] | 89.67 / 0.000 | 49.477 | 0.0806 / 0.0766 | 53.55 |
| 05 new forward | c64 point | 141143.6 | [0.729, 0.737] | 89.56 / 0.000 | 49.087 | 0.1585 / 0.1532 | 53.83 |
| 06 old forward | c64 batch64 | 16355.6 | [7.864, 7.930] | 83.91 / 0.000 | 42.204 | 0.1343 / 0.1283 | 53.81 |
| 07 new forward | c64 batch64 | 16578.8 | [12.059, 12.190] | 82.46 / 0.000 | 42.221 | 0.4933 / 0.4851 | 53.49 |
| 08 new reverse | c64 batch64 | 17688.4 | [6.685, 6.750] | 84.18 / 0.000 | 45.204 | 0.0968 / 0.0948 | 54.55 |
| 09 old reverse | c64 batch64 | 16552.2 | [7.340, 7.406] | 83.94 / 0.000 | 42.903 | 0.1134 / 0.1113 | 54.30 |
| 10 new reverse | c64 point | 138613.1 | [0.762, 0.770] | 89.49 / 0.000 | 48.257 | 0.0909 / 0.0849 | 53.68 |
| 11 old reverse | c64 point | 139705.7 | [0.737, 0.745] | 89.82 / 0.000 | 49.546 | 0.0814 / 0.0796 | 62.00 |
| 12 new reverse | c1 batch64 | 6272.0 | [0.201, 0.203] | 42.73 / 0.000 | 5.569 | 0.1562 / 0.1552 | 52.50 |
| 13 old reverse | c1 batch64 | 6177.5 | [0.203, 0.205] | 41.93 / 0.000 | 5.511 | 0.7102 / 0.6943 | 52.36 |
| 14 new reverse | c1 point | 19438.2 | [0.066, 0.067] | 64.53 / 0.000 | 8.320 | 0.1798 / 0.1731 | 55.02 |
| 15 old reverse | c1 point | 19584.9 | [0.066, 0.067] | 64.56 / 0.000 | 8.312 | 0.1721 / 0.1680 | 52.30 |

## Measurement limits

- All16 accepted cohorts retained. Only recorded metadata files are read; no WAL/object/ELF payloads are read, decoded or rehashed.
- Host deltas use the first and last host snapshots whose timestamp lies inside the report measurement window. The edges are not interpolated.
- CPU busy=(user+nice+system+irq+softirq+steal)/first-eight-field total; idle and iowait reported separately. Guest fields are excluded from the sum to avoid double counting.
- CPU2-5 counters include every task executing there; they are not exclusive server attribution. Host PSI is machine-wide and is not a CPU2-5 measurement.
- PSI percentages here are total counter delta microseconds / sampled elapsed wall time. avg10 values are retained as context only and include earlier time.
- proc_stat, pressure and process files are read sequentially, not atomically. Samples are coarse; a host sample timestamp precedes its proc-file reads.
- RSS is sampled current resident memory, not cumulative allocation; peak RSS can include setup. Thread ranges include observed transient/blocking threads; they do not identify request ownership.
- The retained per-call distributions have no call timestamps, so global pressure, sample gaps and aggregate p99 buckets cannot be causally correlated to individual slow calls.
- Observed iowait or PSI cannot identify sync_namespace, a WAL rotation, a filesystem, or the task responsible. Zero sampled/delta pressure cannot prove absence of short I/O stalls.
- No p99 values are averaged or treated as exact: original histogram bucket lower/upper limits are retained. No new benchmark acceptance or selection is inferred.

The complete per-voter memory/thread/IO counters, per-core deltas, host sampling edge gaps and pressure totals are in `summary.json`. `intervals.json` retains every adjacent in-window host interval; `input-hashes.json` binds the exact original metadata. Original results remain unchanged.
