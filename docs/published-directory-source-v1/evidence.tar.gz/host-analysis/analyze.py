#!/usr/bin/env python3
"""Offline, authority-bound observation of the completed 16-cohort campaign."""
import hashlib
import json
import math
from pathlib import Path
import time

H=Path(__file__).parent
A=Path('/tmp/kv9-fnv-writer-performance-budget-v2-preparation-20260914-first/results-first')
R=Path('/tmp/kv9-fnv-writer-performance-budget-v2-root-20260914-first')
RUN=Path('/tmp/kv9-fnv-writer-performance-budget-v2-timing-20260914-first/cohorts')
S=Path('/tmp/kv9-fnv-writer-budget-v2-reporting-20260914-first/results-first/summary.json')
MAX_FILE=8*1024**2
MAX_INPUT=256*1024**2
inputs={};total=0
started=time.time_ns()
def raw(path,expected=None):
    global total
    path=Path(path);n=path.stat().st_size
    assert path.is_file() and not path.is_symlink() and n<=MAX_FILE,path
    b=path.read_bytes();row=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    if expected is not None:assert row==expected,(str(path),row,expected)
    if str(path) not in inputs:total+=len(b)
    assert total<=MAX_INPUT,total
    inputs[str(path)]=row
    return b
def read(path,expected=None):return json.loads(raw(path,expected))
def save(name,value):
    path=H/name;assert not path.exists(),path
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def gaps(rows,key,begin,end):
    ts=[r[key] for r in rows];ds=[b-a for a,b in zip(ts,ts[1:])]
    assert len(ts)>=2 and all(x>0 for x in ds)
    ordered=sorted(ds)
    return dict(samples=len(ts),first_ns=ts[0],last_ns=ts[-1],first_edge_gap_ns=ts[0]-begin,
                last_edge_gap_ns=end-ts[-1],covered_span_ns=ts[-1]-ts[0],
                interior_gaps=len(ds),minimum_gap_ns=min(ds),maximum_gap_ns=max(ds),
                mean_gap_ns=sum(ds)/len(ds),median_gap_ns=ordered[len(ordered)//2],
                gaps_over_75ms=sum(x>75000000 for x in ds),gaps_over_100ms=sum(x>100000000 for x in ds))
def stat_cpu(text):
    rows={}
    for line in text.splitlines():
        fields=line.split()
        if fields and (fields[0]=='cpu' or fields[0][3:].isdigit() and fields[0].startswith('cpu')):
            rows[fields[0]]=list(map(int,fields[1:9]))
    assert all(len(v)==8 for v in rows.values())
    return rows
FIELDS=['user','nice','system','idle','iowait','irq','softirq','steal']
def cpu_delta(a,b,names):
    values=[sum(b[name][i]-a[name][i] for name in names) for i in range(8)]
    d=dict(zip(FIELDS,values));den=sum(values)
    valid=all(x>=0 for x in values) and den>0
    return dict(tick_deltas=d,total_ticks=den,counter_valid=valid,
                busy_percent=(100*(den-d['idle']-d['iowait'])/den if valid else None),
                iowait_percent=(100*d['iowait']/den if valid else None),
                idle_percent=(100*d['idle']/den if valid else None))
def psi(text):
    rows={}
    for line in text.splitlines():
        kind,*tokens=line.split();items=dict(x.split('=',1) for x in tokens)
        rows[kind]={k:int(v) if k=='total' else float(v) for k,v in items.items()}
    assert set(rows)=={'some','full'}
    return rows
def pressure_delta(a,b,span_ns):
    delta=b['total']-a['total']
    return dict(total_delta_us=delta,elapsed_ns=span_ns,
        stalled_wall_percent=delta*100000/span_ns if delta>=0 else None,
        first_avg10_percent=a['avg10'],last_avg10_percent=b['avg10'],
        counter_valid=delta>=0)

terminal=read(R/'audit-terminal.json')
assert terminal['complete'] is True and terminal['exit_code']==0
assert terminal['audit_sha256']=='58635dc25e4efcd4007b54e4e0565398966e2083d1152c8a52566a3afcb04807'
for path,key in [(A/'audit.json','audit_sha256'),(A/'input-inventory.json','input_inventory_sha256'),
                 (R/'audit-result.json','result_sha256')]:
    b=raw(path);assert hashlib.sha256(b).hexdigest()==terminal[key]
authority=json.loads((A/'input-inventory.json').read_text())
audit=json.loads((A/'audit.json').read_text())
assert audit['complete'] is True and audit['matched_diagnostic_accepted'] is True and len(audit['cases'])==16
accepted_summary=read(S);assert inputs[str(S)]['sha256']=='078764594cbbd2b84b78f38a426e9806378fb67883b365366adcb144327b5168'
read('/tmp/kv9-fnv-writer-budget-v2-reporting-root-20260914-first/terminal.json')
read(R/'timing-terminal.json')
def bound(path):
    assert Path(path).is_relative_to(RUN),path
    return read(path,authority[str(path)])
driver=Path('/tmp/kv9-fnv-writer-performance-budget-v2-preparation-20260914-first/matched-driver.py')
raw(driver);assert inputs[str(driver)]['sha256']=='48d93eb24d73ba33721efa5c6053d32c703d126c5842471fa50e081794e86708'
matrix=bound(RUN/'matrix.json');assert matrix['complete'] is True and len(matrix['attempts'])==16
all_cases=[];all_intervals=[]
for ordinal,case in enumerate(audit['cases']):
    assert ordinal==case['ordinal'];directory=Path(case['directory'])
    report=bound(directory/'run/report.json')
    assert case['report_sha256']==inputs[str(directory/'run/report.json')]['sha256']
    samples=bound(directory/'resource-samples.json')
    coverage=bound(directory/'resource-coverage.json')
    hosts=bound(directory/'host-resource-samples.json')
    begin=report['measurement_start_unix_ns'];end=begin+report['cohort_elapsed_ns']
    inside=[s for s in samples if begin<=s['unix_ns']<=end]
    host=[s for s in hosts if begin<=s['unix_ns']<=end]
    assert len(inside)==coverage['samples']>=10 and len(host)>=10
    g=gaps(inside,'unix_ns',begin,end);hg=gaps(host,'unix_ns',begin,end)
    assert g['first_edge_gap_ns']==coverage['first_gap_ns'] and g['last_edge_gap_ns']==coverage['last_gap_ns']
    stat=[stat_cpu(s['proc_stat']) for s in host]
    pressures=[{name:psi(s[name+'_pressure']) for name in ('cpu','io')} for s in host]
    dt=host[-1]['monotonic_ns']-host[0]['monotonic_ns'];assert dt>0
    cpu={name:cpu_delta(stat[0],stat[-1],[name]) for name in ('cpu','cpu2','cpu3','cpu4','cpu5')}
    cpu['cpu2-5']=cpu_delta(stat[0],stat[-1],['cpu2','cpu3','cpu4','cpu5'])
    pressure={name:{kind:pressure_delta(pressures[0][name][kind],pressures[-1][name][kind],dt)
                    for kind in ('some','full')} for name in ('cpu','io')}
    intervals=[]
    for i in range(1,len(host)):
        span=host[i]['monotonic_ns']-host[i-1]['monotonic_ns'];assert span>0
        q=dict(first_unix_ns=host[i-1]['unix_ns'],last_unix_ns=host[i]['unix_ns'],span_ns=span,
               cpu2_5=cpu_delta(stat[i-1],stat[i],['cpu2','cpu3','cpu4','cpu5']),
               host_cpu=cpu_delta(stat[i-1],stat[i],['cpu']),
               pressure={name:{kind:pressure_delta(pressures[i-1][name][kind],pressures[i][name][kind],span)
                         for kind in ('some','full')} for name in ('cpu','io')})
        intervals.append(q)
    voters={}
    for name in ('voter-1','voter-2','voter-3'):
        rows=[s['processes'][name] for s in inside]
        assert len({(r['pid'],r['start_ticks']) for r in rows})==1
        rss=[r['rss_bytes'] for r in rows];threads=[len(r['threads']) for r in rows]
        audited=case['server_memory'][name]
        assert (min(rss),max(rss),rss[0],rss[-1])==(audited['rss_min_bytes'],audited['rss_max_bytes'],audited['rss_first_bytes'],audited['rss_last_bytes'])
        ticks=dict(user=rows[-1]['user_ticks']-rows[0]['user_ticks'],system=rows[-1]['system_ticks']-rows[0]['system_ticks'])
        io={k:rows[-1]['io'][k]-rows[0]['io'][k] for k in rows[0]['io']}
        voters[name]=dict(pid=rows[0]['pid'],start_ticks=rows[0]['start_ticks'],samples=len(rows),
            observed_first_unix_ns=rows[0]['observed_unix_ns'],observed_last_unix_ns=rows[-1]['observed_unix_ns'],
            rss_first_bytes=rss[0],rss_last_bytes=rss[-1],rss_min_bytes=min(rss),rss_max_bytes=max(rss),
            rss_mean_bytes=sum(rss)/len(rss),threads_first=threads[0],threads_last=threads[-1],
            threads_min=min(threads),threads_max=max(threads),distinct_observed_tids=len(set(t for r in rows for t in r['threads'])),
            process_tick_deltas=ticks,process_io_counter_deltas=io,
            accepted_resource_cpu_cores=coverage['cpu'][name]['cpu_cores'])
    max_cpu=max(q['pressure']['cpu']['some']['stalled_wall_percent'] for q in intervals)
    max_io=max(q['pressure']['io']['some']['stalled_wall_percent'] for q in intervals)
    r=dict(ordinal=ordinal,repeat=case['repeat'],order='forward' if case['repeat']==0 else 'reverse',
        role=case['arm'].split('-')[0],workload=case['workload'],concurrency=case['concurrency'],directory=str(directory),
        measurement_start_unix_ns=begin,measurement_end_unix_ns=end,measurement_elapsed_ns=end-begin,
        calls=case['calls'],calls_per_second=case['completed_calls_per_second'],outcomes=case['outcomes'],
        whole_call_latency=case['whole_call_latency'],resource_coverage=g,host_coverage=hg,
        host_monotonic_interval_ns=dt,host_cpu=cpu,host_pressure=pressure,
        interval_summary=dict(intervals=len(intervals),max_cpu_some_stalled_wall_percent=max_cpu,
            max_io_some_stalled_wall_percent=max_io,
            invalid_cpu2_5_intervals=sum(not q['cpu2_5']['counter_valid'] for q in intervals)),voters=voters)
    all_cases.append(r);all_intervals.append(dict(ordinal=ordinal,intervals=intervals))
focus=[c for c in all_cases if c['concurrency']==64 and c['workload']=='batch64-r000'];assert len(focus)==4
limitations=[
    'All16 accepted cohorts retained. Only recorded metadata files are read; no WAL/object/ELF payloads are read, decoded or rehashed.',
    'Host deltas use the first and last host snapshots whose timestamp lies inside the report measurement window. The edges are not interpolated.',
    'CPU busy=(user+nice+system+irq+softirq+steal)/first-eight-field total; idle and iowait reported separately. Guest fields are excluded from the sum to avoid double counting.',
    'CPU2-5 counters include every task executing there; they are not exclusive server attribution. Host PSI is machine-wide and is not a CPU2-5 measurement.',
    'PSI percentages here are total counter delta microseconds / sampled elapsed wall time. avg10 values are retained as context only and include earlier time.',
    'proc_stat, pressure and process files are read sequentially, not atomically. Samples are coarse; a host sample timestamp precedes its proc-file reads.',
    'RSS is sampled current resident memory, not cumulative allocation; peak RSS can include setup. Thread ranges include observed transient/blocking threads; they do not identify request ownership.',
    'The retained per-call distributions have no call timestamps, so global pressure, sample gaps and aggregate p99 buckets cannot be causally correlated to individual slow calls.',
    'Observed iowait or PSI cannot identify sync_namespace, a WAL rotation, a filesystem, or the task responsible. Zero sampled/delta pressure cannot prove absence of short I/O stalls.',
    'No p99 values are averaged or treated as exact: original histogram bucket lower/upper limits are retained. No new benchmark acceptance or selection is inferred.']
result=dict(complete=True,scope='Offline descriptive host/resource analysis of the original accepted16 timed cohorts',
    timing_protocol=audit['protocol_id'],audit_sha256=inputs[str(A/'audit.json')]['sha256'],
    input_inventory_sha256=inputs[str(A/'input-inventory.json')]['sha256'],accepted_summary_sha256=inputs[str(S)]['sha256'],
    role_bindings=matrix['role_bindings'],cases=all_cases,focus_ordinals=[c['ordinal'] for c in focus],limitations=limitations,
    input_bytes=total,started_unix_ns=started,ended_unix_ns=time.time_ns())
save('summary.json',result);save('intervals.json',all_intervals);save('input-hashes.json',inputs)
def table(cases):
    lines=['| # / role / order | cell | calls/s | p99 bucket ms | CPU2–5 busy / iowait % | host CPU PSI some % | host IO PSI some / full % | max resource gap ms |',
           '|---|---|---:|---|---|---:|---|---:|']
    for c in cases:
        p99=c['whole_call_latency']['p99'];cpu=c['host_cpu']['cpu2-5'];p=c['host_pressure']
        lines.append(f"| {c['ordinal']:02d} {c['role']} {c['order']} | c{c['concurrency']} {c['workload'].split('-')[0]} | {c['calls_per_second']:.1f} | [{p99['lower_ns']/1e6:.3f}, {p99['upper_ns']/1e6:.3f}] | {cpu['busy_percent']:.2f} / {cpu['iowait_percent']:.3f} | {p['cpu']['some']['stalled_wall_percent']:.3f} | {p['io']['some']['stalled_wall_percent']:.4f} / {p['io']['full']['stalled_wall_percent']:.4f} | {c['resource_coverage']['maximum_gap_ns']/1e6:.2f} |")
    return '\n'.join(lines)
lines=['# FNV write-tail host observations','',
    'All16 original timed cohorts are included. This is descriptive analysis of hash-bound accepted inputs, not a rerun or a causal attribution of request tails. Old is selected CRC bd42e60; new is FNV12f44d.','',
    '## Four c64 BatchPut64 cohorts','',table(focus),'',
    'CPU busy is averaged over the observed CPU2–5 counter interval. Host PSI is global stalled wall time, not CPU utilization or exclusive voter pressure.','',
    '| # / voter | RSS first → last MiB | RSS min–max MiB | threads first → last (min–max) | sampled process CPU cores |',
    '|---|---|---|---|---:|']
for c in focus:
    for name,v in c['voters'].items():
        lines.append(f"| {c['ordinal']:02d} {name} | {v['rss_first_bytes']/2**20:.1f} → {v['rss_last_bytes']/2**20:.1f} | {v['rss_min_bytes']/2**20:.1f}–{v['rss_max_bytes']/2**20:.1f} | {v['threads_first']} → {v['threads_last']} ({v['threads_min']}–{v['threads_max']}) | {v['accepted_resource_cpu_cores']:.3f} |")
lines += ['', '## All16 cohorts','',table(all_cases),'','## Measurement limits','']+['- '+x for x in limitations]
lines += ['', 'The complete per-voter memory/thread/IO counters, per-core deltas, host sampling edge gaps and pressure totals are in `summary.json`. `intervals.json` retains every adjacent in-window host interval; `input-hashes.json` binds the exact original metadata. Original results remain unchanged.','']
(H/'REPORT.md').write_text('\n'.join(lines))
save('result-first.json',dict(complete=True,exit_code=0,cases=16,focus_cases=4,selected_input_files=len(inputs),selected_input_bytes=total,
    summary_sha256=hashlib.sha256((H/'summary.json').read_bytes()).hexdigest(),report_sha256=hashlib.sha256((H/'REPORT.md').read_bytes()).hexdigest(),
    interval_sha256=hashlib.sha256((H/'intervals.json').read_bytes()).hexdigest(),started_unix_ns=started,ended_unix_ns=time.time_ns()))
print(json.dumps(json.loads((H/'result-first.json').read_text())))
