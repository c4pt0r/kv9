import sys, os, json, hashlib, subprocess, shutil, time
from pathlib import Path
ROOT=Path('/tmp/kv9-wal-published-directory-20260914-first')
OUT=Path('/tmp/kv9-published-directory-source-20260914-first')
OUT.mkdir()
os.environ.update(CARGO_TARGET_DIR='/home/dongxu/kv9/target', CARGO_BUILD_JOBS='4', CARGO_NET_OFFLINE='true')
sys.path.insert(0,str(ROOT/'scripts'))
from build_cache import BuildCache

def save(name, data):
    (OUT/name).write_text(json.dumps(data, indent=2)+'\n')
def snapshot():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0')
    return {n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(set(names)-{''}) if (ROOT/n).is_file()}
before=snapshot()
save('source-before.json',before)
compiler_before={n:h for n,h in before.items() if n.endswith(('.rs','.toml','.lock','.proto'))}
save('compiler-inputs-before.json',compiler_before)
commands=[
 ('format',['cargo','fmt','--all','--','--check'],False),
 ('compile-tests',['cargo','test','--locked','--offline','--workspace','--no-run','--message-format=json-render-diagnostics'],True),
 ('workspace-tests',['cargo','test','--locked','--offline','--workspace','--','--test-threads=4'],False),
 ('compile-probe',['cargo','build','--locked','--offline','-p','kv9-engine','--example','published_directory_probe','--message-format=json-render-diagnostics'],True),
 ('clippy',['cargo','clippy','--locked','--offline','--workspace','--all-targets','--','-D','warnings'],False),
]
save('commands.json',commands)
result={'complete':False,'started_ns':time.time_ns(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
try:
    with BuildCache(ROOT,OUT,False,before) as cache:
        for label,argv,artifacts in commands:
            print('START '+label,flush=True)
            with (OUT/(label+'.stdout')).open('x') as stdout,(OUT/(label+'.stderr')).open('x') as stderr:
                cache.run(argv,stdout=stdout,stderr=stderr,timeout=900)
            if artifacts: cache.check_artifacts(OUT/(label+'.stdout'))
            print('PASS '+label,flush=True)
        rows=[json.loads(line) for line in (OUT/'compile-probe.stdout').read_text().splitlines()]
        paths={r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='published_directory_probe' and r.get('executable')}
        assert len(paths)==1
        shutil.copy2(paths.pop(),OUT/'published_directory_probe')
        result['probe_sha256']=hashlib.sha256((OUT/'published_directory_probe').read_bytes()).hexdigest()
        after=snapshot()
        save('source-after.json',after)
        compiler_after={n:h for n,h in after.items() if n.endswith(('.rs','.toml','.lock','.proto'))}
        save('compiler-inputs-after.json',compiler_after)
        assert compiler_before==compiler_after,'compiler input changed during qualification'
        changed=sorted(n for n in set(before)|set(after) if before.get(n)!=after.get(n))
        assert set(changed)<= {'scripts/published_directory_check.py','scripts/published_directory_shim.c'}, 'unexpected source mutation during qualification'
        result['concurrent_harness_only_changes']=changed
        result['complete']=True
except BaseException as error:
    result['error']=repr(error)
    raise
finally:
    result['ended_ns']=time.time_ns()
    save('result.json',result)
