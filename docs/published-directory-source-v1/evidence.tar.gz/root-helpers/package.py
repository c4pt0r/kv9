from pathlib import Path
import hashlib,json,tarfile,gzip,io
ROOT=Path('/tmp/kv9-wal-published-directory-20260914-first')
OUT=ROOT/'docs/published-directory-source-v1'
OUT.mkdir()
groups={
 'source-checks':Path('/tmp/kv9-published-directory-source-20260914-first'),
 'root-helpers':Path('/tmp/kv9-published-directory-source-preparation-20260914-first'),
 'proof-validated':Path('/tmp/kv9-published-directory-proof-20260914-validated'),
 'proof-first':Path('/tmp/kv9-published-directory-proof-20260914-first'),
 'proof-draft':Path('/tmp/kv9-published-directory-proof-draft-20260914-first'),
 'syscalls':Path('/tmp/kv9-published-directory-fsync-20260914-first'),
 'host-analysis':Path('/tmp/kv9-fnv-tail-host-analysis-20260914-first'),
}
entries=[];excluded=[]
for group,root in groups.items():
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink()
  if not path.is_file():continue
  record={'path':group+'/'+str(path.relative_to(root)),'original':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
  if group=='source-checks' and path.name=='published_directory_probe':excluded.append(record)
  else:entries.append(record)
assert sum(r['bytes'] for r in entries)<64*1024**2
archive=OUT/'evidence.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for row in entries:
  data=Path(row['original']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
  item=tarfile.TarInfo(row['path']);item.size=len(data);item.mode=0o644;item.mtime=0
  tar.addfile(item,io.BytesIO(data))
seen=[]
with tarfile.open(archive,'r:gz') as tar:
 for item in tar:
  row=entries[len(seen)];assert item.name==row['path'] and item.isfile() and item.size==row['bytes']
  assert hashlib.sha256(tar.extractfile(item).read()).hexdigest()==row['sha256'];seen.append(item.name)
assert len(seen)==len(entries)
manifest={'complete':True,'files':entries,'decoded_bytes':sum(r['bytes'] for r in entries),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'excluded_local_probe':excluded,'scope':'Original local source/proof/syscall evidence and descriptive analysis; no new database benchmark or Chaos campaign.'}
(OUT/'inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'README.md').write_text(f'''# Published-directory source qualification

The archive contains {len(entries)} original files / {manifest['decoded_bytes']:,} decoded bytes,
in {manifest['archive_bytes']:,} compressed bytes. Every member was independently
read back and SHA256-checked after packing. The retained debug probe remains
local with its exact path, size and hash in `inventory.json`.

Included: full source inventories, first-party build invalidation and compiler
records; 793 passing workspace tests/doctests with 23 existing ignored tests;
formatting and Clippy; 12 conditional TLAPS statements and 24 fresh obligations;
original draft/first/corrected proof reporter records; five syscall cases and
four refusal controls with original WAL files/traces; the all-16 FNV host sample
analysis and exact input references. The FNV original measurement metadata is
already published separately in `evidence/fnv-writer-performance-v2`.

Tool terminal receipts are in `root-helpers/tool-terminals.json`. Mainline remains
selected CRC. No database timing, physical power cut, or actual Chaos Mesh result
is claimed for this candidate. The host analysis is descriptive and does not
identify the cause of an individual slow write.

Inspect `inventory.json` and compare archive SHA256 before opening the archive.
The manifest lists every member and hash; extraction is not needed to verify it.
''')
print(json.dumps({k:v for k,v in manifest.items() if k not in ('files','excluded_local_probe')}))
