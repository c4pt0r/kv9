import ctypes, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path

OUT=Path('/tmp/kv9-upper-bound-diagnostic-release-root-20260915-first')
PRE=json.loads((OUT/'preflight.json').read_text())
assert __debug__ and PRE['complete']
assert PRE['source_revision']=='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
assert PRE['floor_bytes']==8*1024**3 and PRE['maximum_available_decrease_bytes']==16*1024**3 and PRE['metadata_launch_allowance_bytes']==8*1024**2
for name, expected in PRE['script_sha256'].items():
 assert hashlib.sha256((Path(__file__).resolve().parent/name).read_bytes()).hexdigest()==expected
BOOT=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
def save(value):(OUT/'supervisor-result.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def available():
 s=os.statvfs('/tmp');return s.f_bavail*s.f_frsize
def ident(pid):
 try:
  s=Path('/proc',str(pid),'stat').read_text();fields=s[s.rindex(')')+2:].split()
  return {'pid':pid,'ppid':int(fields[1]),'pgrp':int(fields[2]),'start_ticks':int(fields[19]),'boot_id':BOOT,'state':fields[0]}
 except FileNotFoundError:return None
def group(pgid):
 rows=[]
 for path in Path('/proc').iterdir():
  if path.name.isdigit():
   try:r=ident(int(path.name))
   except (OSError,ValueError):continue
   if r and r['pgrp']==pgid:rows.append(r)
 return rows
PARENT=os.getpid()
def child_guard():
 if ctypes.CDLL(None).prctl(1,signal.SIGKILL,0,0,0)!=0:os._exit(127)
 if os.getppid()!=PARENT:os._exit(127)
def stopped(signum,frame):raise RuntimeError('supervisor received signal '+str(signum))
signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGINT,stopped)
script=Path('/tmp/kv9-upper-bound-release-preparation-20260915-first/build-diagnostic.py');cmd=[sys.executable,'-B',str(script)]
r={'complete':False,'argv':cmd,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'started_ns':time.time_ns(),'initial_available_bytes':PRE['initial_available_bytes'],
   'floor_bytes':PRE['floor_bytes'],'maximum_available_decrease_bytes':PRE['maximum_available_decrease_bytes'],'samples':[],'observed_lifetimes':{},'process_scope':'Owned worker process group observed every5 seconds; short-lived children need not appear in samples. No unrelated process cleanup.'}
p=None
def sample():
 free=available();rows=group(p.pid) if p else []
 r['samples'].append({'observed_ns':time.time_ns(),'available_bytes':free,'owned_processes':rows})
 for x in rows:r['observed_lifetimes'][f"{x['boot_id']}:{x['pid']}:{x['start_ticks']}"]=x
 save(r)
 if free<r['floor_bytes'] or r['initial_available_bytes']-free>r['maximum_available_decrease_bytes']:raise RuntimeError('build space guard exceeded')
 if time.time_ns()-r['started_ns']>2500*10**9:raise RuntimeError('paired release deadline exceeded')
try:
 sample()
 assert available()>=24*1024**3+8*1024**2,'fresh launch guard after detached source creation'
 with (OUT/'worker.stdout').open('x') as stdout,(OUT/'worker.stderr').open('x') as stderr:
  p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=child_guard)
  r['child_identity']=ident(p.pid);save(r)
  while True:
   sample()
   if any((OUT/n).stat().st_size>128*1024**2 for n in ('worker.stdout','worker.stderr')):raise RuntimeError('supervisor output cap')
   try:r['exit_code']=p.wait(timeout=5);break
   except subprocess.TimeoutExpired:pass
  sample();assert r['exit_code']==0,'build worker failed'
  assert not group(p.pid),'owned build descendants remain'
  assert json.loads((OUT/'build-result.json').read_text())['complete']
 r['complete']=True
except BaseException as e:
 r['failure']=repr(e)
 if p:
  for sig in (signal.SIGTERM,signal.SIGKILL):
   if group(p.pid):
    try:os.killpg(p.pid,sig)
    except ProcessLookupError:pass
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:pass
 raise
finally:
 if p:r.update(exit_code=p.poll(),remaining_owned_group=group(p.pid),worker_reaped=p.poll() is not None)
 r['ended_ns']=time.time_ns();save(r)
print(json.dumps({'complete':True,'exit_code':r['exit_code'],'result_path':str(OUT/'supervisor-result.json')}))
