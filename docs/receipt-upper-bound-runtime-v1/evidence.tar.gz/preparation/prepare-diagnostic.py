"""Fresh metadata preflight after the standard default/native release is accepted."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

from default_binding import verify

HERE = Path(__file__).resolve().parent
SOURCE = Path('/tmp/kv9-receipt-upper-bound-20260915-first')
OUT = Path('/tmp/kv9-upper-bound-diagnostic-release-root-20260915-first')
BUILD = Path('/tmp/kv9-upper-bound-diagnostic-release-20260915-first')
assert __debug__
assert not OUT.exists() and not BUILD.exists(), 'fresh diagnostic outputs required'
OUT.mkdir(exist_ok=False)
result = dict(complete=False, started_ns=time.time_ns())
try:
    spec = importlib.util.spec_from_file_location('standard_builder', SOURCE/'scripts/build-workload.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    snapshot = builder.snapshot()
    standard = verify(snapshot)
    stat = os.statvfs('/tmp')
    available = stat.f_bavail * stat.f_frsize
    assert available >= 24*1024**3 + 8*1024**2, 'fresh diagnostic launch reservation cannot fit'
    result.update(complete=True, source_revision=snapshot['revision'],
                  initial_available_bytes=available, floor_bytes=8*1024**3,
                  maximum_available_decrease_bytes=16*1024**3,
                  metadata_launch_allowance_bytes=8*1024**2,
                  standard_default_binding=standard,
                  script_sha256={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()
                                 for name in ('build-diagnostic.py', 'run-diagnostic.py',
                                              'readback-diagnostic.py', 'default_binding.py')},
                  allocation_scope='Fresh diagnostic-only phase baseline; retained standard release is preserved. No duplicate default build.')
except BaseException as error:
    result['failure'] = repr(error)
    raise
finally:
    result['ended_ns'] = time.time_ns()
    with (OUT/'preflight.json').open('x') as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True)+'\n')
print(json.dumps(dict(complete=True, output=str(OUT/'preflight.json'), available_bytes=available)))
