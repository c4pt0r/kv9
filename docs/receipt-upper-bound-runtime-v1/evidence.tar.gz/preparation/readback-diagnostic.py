import hashlib,importlib.util,json,time
from pathlib import Path
from default_binding import verify as verify_default

ROOT=Path('/tmp/kv9-receipt-upper-bound-20260915-first')
OUT=Path('/tmp/kv9-upper-bound-diagnostic-release-root-20260915-first')
def read(path):return json.loads(path.read_text())
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(path):return {'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)}
def main():
 result={'complete':False,'started_ns':time.time_ns(),'scope':'Independent original source/manifest/Cargo graph/codegen and retained binary readback; no server or workload execution.'}
 try:
  supervisor=read(OUT/'supervisor-result.json');build=read(OUT/'build-result.json');cache=read(OUT/'cache-safety.json');metadata=read(OUT/'cache-metadata.json')
  assert supervisor['complete'] and supervisor['exit_code']==0 and not supervisor['remaining_owned_group']
  assert build['complete'] and cache['complete'] and cache['invalidation_complete']
  assert all(c['exit_code']==0 for c in cache['commands'])
  spec=importlib.util.spec_from_file_location('release_reader',ROOT/'scripts/build-workload.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
  source=builder.snapshot();assert source==read(OUT/'source-before.json') and not source['dirty'] and source['revision']=='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
  packages={r['id']:r['name'] for r in metadata['packages'] if r['id'] in metadata['workspace_members']}
  standard_default=verify_default(source)
  assert standard_default==build['standard_default_binding']
  assert len(build['variants'])==1 and build['variants'][0]['variant']=='instrumented'
  rows=[]
  for variant in build['variants']:
   dest=Path(variant['output']);manifest=read(dest/'build.json');assert manifest['complete'] and manifest['profile']=='release'
   assert manifest['revision']==source['revision'] and manifest['dirty']==source['dirty'] and manifest['sources']==source['sources']
   assert read(dest/'source-after.json')==source and manifest['source_tree_sha256']==builder.sha(builder.canonical(source['sources']))
   assert digest(dest/'kv9')==variant['binary_sha256']==manifest['binary_sha256']==manifest['binaries']['kv9']['sha256']
   assert digest(dest/'build.json')==variant['build_sha256']
   assert manifest['standard_default_binding']==standard_default
   assert manifest['command']==variant['argv']==manifest['binaries']['kv9']['command']
   instrumented=variant['variant']=='instrumented';assert manifest['diagnostics_enabled']==instrumented
   assert ('--features' in variant['argv'])==instrumented
   if instrumented:assert variant['argv'][-2:]==['--features','write-path-diagnostics']
   cargo=[json.loads(x) for x in (dest/'kv9-cargo.jsonl').read_text().splitlines()]
   assert cargo[-1]=={'reason':'build-finished','success':True}
   actual=[]
   for r in cargo:
    if r.get('reason')!='compiler-artifact' or r['package_id'] not in packages:continue
    package=packages[r['package_id']];features=['write-path-diagnostics'] if instrumented and package in ('kv9','kv9-raft','kv9-server') else []
    assert r['features']==features and not r['profile']['test']
    actual.append({'package':package,**{k:r[k] for k in ('target','profile','features','fresh','filenames')}})
   assert actual==manifest['cargo_features']
   log=(dest/'build.log').read_text()
   assert {r['crate'] for r in manifest['actual_codegen']}=={'kv9','kv9_raft','kv9_server'}
   for r in manifest['actual_codegen']:
    line=r['actual_rustc_invocation'];assert line in log
    assert '-C opt-level=3' in line and '-C codegen-units=1' in line and 'panic=abort' not in line
    assert ('-C lto=thin' if r['crate']=='kv9' else '-C linker-plugin-lto') in line
   assert digest(dest/'build.log')==manifest['build_log_sha256'] and digest(dest/'kv9-cargo.jsonl')==manifest['cargo_jsonl_sha256']
   rows.append({'variant':variant['variant'],'binary':pin(dest/'kv9'),'build':pin(dest/'build.json'),'cargo_jsonl':pin(dest/'kv9-cargo.jsonl'),'features':{p:sorted({f for r in actual if r['package']==p for f in r['features']}) for p in ('kv9','kv9-raft','kv9-server')}})
  boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
  for lifetime in supervisor['observed_lifetimes'].values():
   try:
    stat=Path('/proc',str(lifetime['pid']),'stat').read_text();ticks=int(stat[stat.rindex(')')+2:].split()[19])
   except FileNotFoundError:continue
   assert (boot,ticks)!=(lifetime['boot_id'],lifetime['start_ticks']),'same observed build lifetime still live'
  result.update(complete=True,revision=source['revision'],source_files=len(source['sources']),source_tree_sha256=builder.sha(builder.canonical(source['sources'])),
                variants=rows,standard_default_binding=standard_default,cache_safety=pin(OUT/'cache-safety.json'),supervisor=pin(OUT/'supervisor-result.json'),build_result=pin(OUT/'build-result.json'),
                observed_build_lifetimes_absent=len(supervisor['observed_lifetimes']),minimum_available_bytes=min(r['available_bytes'] for r in supervisor['samples']),
                initial_available_bytes=supervisor['initial_available_bytes'])
 except BaseException as e:result['failure']=repr(e);raise
 finally:
  result['ended_ns']=time.time_ns();(OUT/'independent-readback.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
