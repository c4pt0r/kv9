import hashlib, importlib.util, json, os, shutil, subprocess, time
from pathlib import Path
from default_binding import verify as verify_default

ROOT=Path('/tmp/kv9-receipt-upper-bound-20260915-first')
OUT=Path('/tmp/kv9-upper-bound-diagnostic-release-root-20260915-first')
REV='e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
TARGET='/home/dongxu/kv9/target'
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def digest(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def version(argv):
 p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,timeout=30)
 assert p.returncode==0,(argv,p.stderr)
 return dict(argv=argv,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)

def main():
 for k,v in os.environ.items():
  if k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET') or k.startswith('CARGO_PROFILE_RELEASE_'):
   assert not v,('Unexpected compilation override',k)
 os.environ.update(CARGO_TARGET_DIR=TARGET,CARGO_BUILD_JOBS='4',CARGO_NET_OFFLINE='true',CARGO_TERM_VERBOSE='true',RUSTUP_TOOLCHAIN='stable-x86_64-unknown-linux-gnu',CARGO_INCREMENTAL='0')
 spec=importlib.util.spec_from_file_location('builder',ROOT/'scripts/build-workload.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
 before=builder.snapshot();assert before['revision']==REV and not before['dirty']
 save(OUT/'source-before.json',before)
 standard_default=verify_default(before)
 preflight=json.loads((OUT/'preflight.json').read_text());assert preflight['complete'] and preflight['standard_default_binding']==standard_default
 toolchain={k:version(v) for k,v in {'rustc':['rustc','-vV'],'cargo':['cargo','-V'],'protoc':['protoc','--version'],'cc':['cc','--version']}.items()}
 assert 'rustc 1.94.0 (4a4ef493e ' in toolchain['rustc']['stdout']
 assert 'cargo 1.94.0 (85eff7c80 ' in toolchain['cargo']['stdout']
 save(OUT/'toolchain.json',toolchain)
 result={'complete':False,'revision':REV,'source_root':str(ROOT),'variants':[],'standard_default_binding':standard_default,'started_ns':time.time_ns()}
 try:
  with builder.cache.BuildCache(ROOT,OUT,True,before) as cache:
   assert str(cache.target)==TARGET
   for name,feature in [('instrumented',True)]:
    dest=Path('/tmp/kv9-upper-bound-diagnostic-release-20260915-first');dest.mkdir(exist_ok=False)
    cmd=['cargo','build','--offline','--locked','--release','--bin','kv9','--message-format=json-render-diagnostics','-v']
    if feature:cmd+=['--features','write-path-diagnostics']
    row={'variant':name,'output':str(dest),'argv':cmd,'started_ns':time.time_ns(),'complete':False};result['variants'].append(row)
    save(OUT/'build-result.json',result);save(dest/'invocation.json',row)
    with (dest/'kv9-cargo.jsonl').open('x') as stdout,(dest/'build.log').open('x') as stderr:
     row['exit_code']=cache.run(cmd,stdout=stdout,stderr=stderr,timeout=1200).returncode
    assert (dest/'kv9-cargo.jsonl').stat().st_size<=128*1024**2 and (dest/'build.log').stat().st_size<=128*1024**2
    cache.check_artifacts(dest/'kv9-cargo.jsonl')
    records=[json.loads(x) for x in (dest/'kv9-cargo.jsonl').read_text().splitlines()]
    owned=[r for r in records if r.get('reason')=='compiler-artifact' and r['package_id'] in cache.packages]
    feature_rows=[]
    for r in owned:
     package=cache.packages[r['package_id']]
     expected=['write-path-diagnostics'] if feature and package in ('kv9','kv9-raft','kv9-server') else []
     assert r['features']==expected,(package,r['target'],r['features'],expected)
     assert not r['profile']['test']
     feature_rows.append({'package':package,**{k:r[k] for k in ('target','profile','features','fresh','filenames')}})
    assert {r['package'] for r in feature_rows}>={'kv9','kv9-raft','kv9-server'}
    lines=(dest/'build.log').read_text().splitlines();codegen=[]
    for crate in ('kv9','kv9_raft','kv9_server'):
     matches=[line for line in lines if 'Running `' in line and 'rustc --crate-name '+crate+' ' in line]
     assert len(matches)==1,(crate,len(matches))
     line=matches[0]
     assert '-C opt-level=3' in line and '-C codegen-units=1' in line and 'panic=abort' not in line
     assert ('-C lto=thin' if crate=='kv9' else '-C linker-plugin-lto') in line
     codegen.append({'crate':crate,'actual_rustc_invocation':line})
    paths={r['executable'] for r in owned if r.get('executable') and r['target']['name']=='kv9'};assert len(paths)==1
    binary=Path(paths.pop());assert 0<binary.stat().st_size<=builder.MAX_BINARY
    shutil.copy2(binary,dest/'kv9')
    with (dest/'kv9').open('rb') as f:os.fsync(f.fileno())
    assert digest(binary)==digest(dest/'kv9')
    after=builder.snapshot();save(dest/'source-after.json',after);assert after==before
    manifest={'complete':True,**before,'source_root':str(ROOT),'source_tree_sha256':builder.sha(builder.canonical(before['sources'])),'source_identity_sha256':builder.sha(builder.canonical(before)),
              'profile':'release','rustc':toolchain['rustc']['stdout'],'diagnostics_enabled':feature,'binaries':{'kv9':{'sha256':digest(dest/'kv9'),'command':cmd}},'variant':name,'command':cmd,'binary_path':str(dest/'kv9'),'binary_bytes':(dest/'kv9').stat().st_size,'binary_sha256':digest(dest/'kv9'),
              'cargo_features':feature_rows,'actual_codegen':codegen,'toolchain':toolchain,'target_directory':TARGET,'jobs':4,'offline':True,'source_before_equals_after':True,
              'standard_default_binding':standard_default,'build_cache_path':str(OUT/'cache-safety.json'),'cargo_jsonl_sha256':digest(dest/'kv9-cargo.jsonl'),'build_log_sha256':digest(dest/'build.log')}
    save(dest/'build.json',manifest)
    row.update(complete=True,ended_ns=time.time_ns(),binary_sha256=manifest['binary_sha256'],build_sha256=digest(dest/'build.json'))
    save(OUT/'build-result.json',result);print(json.dumps(row),flush=True)
   for row in result['variants']:
    assert digest(Path(row['output'])/'kv9')==row['binary_sha256']
   assert builder.snapshot()==before
   assert verify_default(before)==standard_default
  result['complete']=True
 except BaseException as e:
  result['failure']=repr(e);raise
 finally:
  result['ended_ns']=time.time_ns();save(OUT/'build-result.json',result)
 print('PASS: exact-source diagnostic release retained; existing standard default/native release preserved',flush=True)

if __name__=='__main__':main()
