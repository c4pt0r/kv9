"""Bind the completed standard default/native release without rebuilding it."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/tmp/kv9-upper-bound-release-root-20260915-first')
BUILD = Path('/tmp/kv9-upper-bound-release-20260915-first')
REVISION = 'e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
SNAPSHOT_SHA = '6a7e125b7a380a732ea105fe6bdd4955b5a797196d226c8b7f9d24fb86965bab'


def digest(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def pin(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))


def verify(snapshot):
    assert digest(HERE/'source-snapshot.json') == SNAPSHOT_SHA
    assert snapshot == json.loads((HERE/'source-snapshot.json').read_text())
    assert snapshot['revision'] == REVISION and snapshot['dirty'] is False
    readback_path = ROOT/'readback-first/result.json'
    readback = json.loads(readback_path.read_text())
    terminal = json.loads((ROOT/'terminal.json').read_text())
    outer = json.loads((ROOT/'source-result.json').read_text())
    assert terminal['complete'] and terminal['exit_code'] == 0 and terminal['session_id'] > 0
    assert terminal['result_sha256'] == digest(ROOT/'source-result.json')
    assert outer['complete'] and outer['exit_code'] == 0 and outer['reaped'] and outer['pid_absent']
    assert readback['complete'] and readback['runtime_checkpoint'] == readback['revision'] == REVISION
    assert readback['source_files'] == len(snapshot['sources'])
    assert readback['cache_lock_and_first_party_invalidation_checked'] and readback['protected_releases_unchanged']
    manifest = json.loads((BUILD/'build.json').read_text())
    assert manifest['sources'] == snapshot['sources'] and manifest['revision'] == REVISION and not manifest['dirty']
    assert readback['source_tree_sha256'] == manifest['source_tree_sha256']
    assert readback['manifest_sha256'] == digest(BUILD/'build.json')
    assert readback['server_sha256'] == digest(BUILD/'kv9')
    assert readback['workload_sha256'] == digest(BUILD/'workload/kv9-batch-workload')
    # The accepted independent reader inventories the exact source, default
    # graph/codegen/cache evidence, protected ELFs and helper inputs. Recheck
    # those bytes on both sides of the diagnostic build; do not hash mutable
    # output directories or reinterpret either manifest schema.
    inventory_path = ROOT/'readback-first/input-hashes.json'
    inputs = json.loads(inventory_path.read_text())
    assert inputs and str(BUILD/'kv9') in inputs and str(BUILD/'workload/kv9-batch-workload') in inputs
    for name, expected in inputs.items():
        path = Path(name)
        assert path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'], name
    return dict(complete=True, revision=REVISION, source_tree_sha256=manifest['source_tree_sha256'],
                readback=pin(readback_path), input_hashes=pin(inventory_path),
                terminal=pin(ROOT/'terminal.json'), server=pin(BUILD/'kv9'),
                native=pin(BUILD/'workload/kv9-batch-workload'), verified_input_count=len(inputs))
