#!/usr/bin/env python3
"""Bind the completed upper-bound source gates to a fresh default release launch."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time

SOURCE = Path('/tmp/kv9-receipt-upper-bound-20260915-first')
REVISION = 'e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
PROOF = Path('/tmp/kv9-upper-bound-proof-acceptance-20260915-first')
REPORT = Path('/tmp/kv9-upper-bound-source-publication-20260915-first')
OLD = Path('/tmp/kv9-receipt-tail-release-root-20260915-first/preflight.json')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def available():
    s = os.statvfs(SOURCE)
    return s.f_bavail * s.f_frsize


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--supervisor', type=Path, required=True)
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    assert __debug__
    assert args.root.is_absolute() and args.supervisor.is_absolute()
    assert not (args.root / 'preflight.json').exists()
    started = time.time_ns()
    minimum = 24 * 1024**3 + 8 * 1024**2
    assert available() >= minimum, 'fresh release launch capacity is insufficient'
    for key, value in os.environ.items():
        if key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
                   'RUSTC_WORKSPACE_WRAPPER', 'CARGO_BUILD_TARGET') or key.startswith('CARGO_PROFILE_RELEASE_'):
            assert not value, 'unexpected compiler override: ' + key
    toolchain_path = Path('/tmp/kv9-write-diagnostics-release-root-20260915-second/toolchain.json')
    reference_toolchain = json.loads(toolchain_path.read_text())
    toolchain = {}
    for name in ('rustc', 'cargo', 'protoc', 'cc'):
        expected = reference_toolchain[name]
        actual = subprocess.run(expected['argv'], cwd=SOURCE, capture_output=True,
                                text=True, timeout=30)
        assert actual.returncode == 0 and actual.stdout == expected['stdout'], \
            'toolchain differs from the retained reference: ' + name
        toolchain[name] = dict(argv=expected['argv'], exit_code=actual.returncode,
                               stdout=actual.stdout, stderr=actual.stderr)
    builder = load('upper_bound_release_builder', SOURCE / 'scripts/build-workload.py')
    snapshot = builder.snapshot()
    assert snapshot['revision'] == REVISION and snapshot['dirty'] is False
    requirements = json.loads((args.supervisor.parent / 'required-inputs.json').read_text())
    assert sha(args.supervisor) == requirements['preflight_schema']['supervisor_sha256']
    assert snapshot == json.loads((args.supervisor.parent / 'source-snapshot.json').read_text())
    contract = json.loads((SOURCE / 'proofs/tlaps/receipt-upper-bound/source-contract.json').read_text())
    proof_checker = load('upper_bound_proof_binding', SOURCE / 'scripts/check-receipt-upper-bound-proof.py')
    proof = json.loads((PROOF / 'result.json').read_text())
    assert proof['complete'] and proof['source_unchanged']
    assert proof['cases'][0] == {'theorems': 14, 'obligations': 82, 'output_rejection_controls': 3}
    assert proof_checker.source_binding(contract) == proof['source_binding']
    blobs = json.loads((REPORT / 'git-blob-readback.json').read_text())
    assert blobs['complete'] and blobs['revision'] == REVISION and blobs['files'] == contract['files']
    for name, digest in contract['files'].items():
        content = subprocess.check_output(['git', 'show', REVISION + ':' + name], cwd=SOURCE)
        assert hashlib.sha256(content).hexdigest() == digest == snapshot['sources'][name]

    inputs = {}
    for directory in [PROOF, REPORT,
                      Path('/tmp/kv9-upper-bound-development-20260915-second'),
                      Path('/tmp/kv9-upper-bound-development-20260915-third')]:
        for name in ('result.json', 'runtime-inputs.json', 'git-blob-readback.json', 'tool-observations.json'):
            p = directory / name
            if p.exists():
                inputs[str(p)] = sha(p)
    for suffix in ('second', 'third'):
        root = Path('/tmp/kv9-upper-bound-development-20260915-' + suffix)
        result = json.loads((root / 'result.json').read_text())
        assert result['complete'] and all(x['exit_code'] == 0 and x['runtime_inputs_unchanged']
                                          for x in result['commands'])
        pins = json.loads((root / 'runtime-inputs.json').read_text())
        assert all(snapshot['sources'][name] == digest for name, digest in pins.items())
    # Keep the failed diagnostic run failed and bind its exact isolated recheck.
    for directory in ('/tmp/kv9-upper-bound-development-20260915-first',
                      '/tmp/kv9-upper-bound-transport-check-20260915-first'):
        for name in ('result.json', 'runtime-inputs.json'):
            p = Path(directory) / name
            if p.exists():
                inputs[str(p)] = sha(p)
    old = json.loads(OLD.read_text())
    protected = dict(old['protected_release_hashes'])
    protected.update({
        '/tmp/kv9-write-diagnostics-release-default-20260915-second/kv9':
            '58385b184e3ccac4edd98664620a29cae33b5726bdebb11800ac3b12b7efaef6',
        '/tmp/kv9-write-diagnostics-release-instrumented-20260915-second/kv9':
            'e8ec4396b9b419c1f3401884bc50fd15a331aa5830fc16c9130ca2513aa6602b',
        '/tmp/kv9-receipt-tail-release-20260915-first/kv9':
            'd83b4e2ede7bcd81e4a6c4adbc407d2fbd6790d9fcab5851314ed907a6fb0a8c',
        '/tmp/kv9-receipt-tail-release-20260915-first/workload/kv9-batch-workload':
            '64aa434166ce05deac8fa6e3d6359c8b13d3dbbc432280ca275701feb499429c',
    })
    for name, digest in protected.items():
        p = Path(name)
        assert p.is_file() and not p.is_symlink() and p.stat().st_nlink == 1
        assert not p.resolve().is_relative_to(Path('/home/dongxu/kv9/target'))
        assert sha(p) == digest
    helpers = {name: sha(SOURCE / 'scripts' / name) for name in old['source_helper_sha256']}
    names = re.findall(r"storage_policy='([^']+)'", args.supervisor.read_text())
    assert len(names) == 1
    policy_path = args.supervisor.parent / 'storage-policy.json'
    policy = json.loads(policy_path.read_text())
    assert policy['name'] == names[0]
    assert sha(policy_path) == requirements['preflight_schema']['policy_sha256']
    for key in ('continuous_floor_bytes', 'launch_available_minimum_bytes',
                'maximum_sampled_available_decrease_bytes', 'metadata_allowance_bytes',
                'sample_seconds', 'timeout_seconds', 'accounting'):
        assert policy[key] == old['policy'][key], 'original release policy changed: ' + key
    assert policy['launch_available_minimum_bytes'] == minimum
    assert builder.snapshot() == snapshot
    assert all(sha(Path(name)) == digest for name, digest in inputs.items())
    free = available()
    assert free >= minimum, 'release capacity changed during source qualification'
    result = dict(complete=True, started_ns=started, ended_ns=time.time_ns(), revision=REVISION,
                  runtime_checkpoint=REVISION, source_root=str(SOURCE), source_snapshot=snapshot,
                  source_helper_sha256=helpers, supervisor_sha256=sha(args.supervisor),
                  protected_release_hashes=protected, storage_policy=names[0], policy=policy,
                  policy_sha256=sha(policy_path), policy_path=str(policy_path),
                  source_gate_inputs=inputs, proof_bound_files=len(contract['files']),
                  reconstructed_parent_driver=True, available_bytes=free,
                  original_policy_path=str(OLD), original_policy_sha256=sha(OLD),
                  toolchain=toolchain, reference_toolchain_path=str(toolchain_path),
                  reference_toolchain_sha256=sha(toolchain_path),
                  qualification_script_sha256=sha(Path(__file__)))
    args.root.mkdir(exist_ok=True)
    with (args.root / 'preflight.json').open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'complete': True, 'revision': REVISION, 'source_files': len(snapshot['sources']),
                      'proof_bound_files': len(contract['files']), 'available_bytes': free}))


if __name__ == '__main__':
    main()
