#!/usr/bin/env python3
"""Archive completed upper-bound release/recovery evidence without replaying it."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path('/tmp/kv9-upper-bound-runtime-publication-20260915-first')
DEST = Path('/home/dongxu/kv9/docs/receipt-upper-bound-runtime-v1')
REV = 'e2e23cca5e70a9ea0cc241877b3b35b5b6433d27'
ROOTS = {
    'authority': '/tmp/kv9-upper-bound-release-authority-20260915-first',
    'preparation': '/tmp/kv9-upper-bound-release-preparation-20260915-first',
    'default-root': '/tmp/kv9-upper-bound-release-root-20260915-first',
    'default-build': '/tmp/kv9-upper-bound-release-20260915-first',
    'diagnostic-root': '/tmp/kv9-upper-bound-diagnostic-release-root-20260915-first',
    'diagnostic-build': '/tmp/kv9-upper-bound-diagnostic-release-20260915-first',
    'recovery-root': '/tmp/kv9-upper-bound-recovery-root-20260915-first',
    'recovery': '/tmp/kv9-upper-bound-recovery-20260915-first',
    'audit': '/tmp/kv9-upper-bound-recovery-audit-20260915-first',
}
EXCLUDED = {'default-build/kv9', 'default-build/workload/kv9-batch-workload',
            'diagnostic-build/kv9'}


def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def read(label, name):
    return json.loads((Path(ROOTS[label]) / name).read_text())


def save(path, obj):
    with path.open('x') as f:
        f.write(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def main():
    assert __debug__ and not DEST.exists()
    default = read('default-root', 'readback-first/result.json')
    diagnostic = read('diagnostic-root', 'independent-readback.json')
    audit = read('audit', 'audit.json')
    assert all(r['complete'] and r['revision'] == REV for r in (default, diagnostic, audit))
    assert audit['accepted'] and audit['owned_lifetimes_exited']
    assert audit['source_unchanged'] and audit['original_inputs_unchanged']
    assert all(r['source_files'] == 1116 for r in (default, diagnostic, audit))
    terminals = {}
    for label, name, session, receipt in (
        ('default-root', 'source-result.json', 3119, '78ef53'),
        ('diagnostic-root', 'supervisor-result.json', 56645, 'df82cf'),
        ('recovery-root', 'source-result.json', 81788, '4be379'),
    ):
        term = read(label, 'terminal.json')
        result = read(label, name)
        assert term['complete'] and result['complete'] and term['exit_code'] == result['exit_code'] == 0
        assert term['session_id'] == session and term['terminal_receipt'] == receipt
        assert term['result_sha256'] == sha(Path(ROOTS[label]) / name)
        terminals[label] = term
    observations = {
        'default_preflight': {'receipt': 'bc4df6', 'exit_code': 0},
        'default_readback': {'receipt': 'debafc', 'exit_code': 0},
        'diagnostic_preflight': {'receipt': 'f06773', 'exit_code': 0},
        'diagnostic_readback': {'receipt': '0bd207', 'exit_code': 0},
        'recovery_preflight': {'receipt': '2e6fac', 'exit_code': 0},
        'recovery_audit': {'receipt': 'e09584', 'exit_code': 0},
        'scope': 'Actual tool observations recorded by the executing root agent; no commands replayed.',
    }
    save(ROOT / 'tool-observations.json', observations)
    members = {}
    excluded = {}
    for label, name in ROOTS.items():
        root = Path(name)
        for p in sorted(root.rglob('*')):
            assert not p.is_symlink(), 'unexpected input symlink: ' + str(p)
            if not p.is_file():
                continue
            rel = label + '/' + str(p.relative_to(root))
            row = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
            if rel in EXCLUDED:
                excluded[rel] = row
            else:
                assert row['bytes'] <= 2 * 1024**2
                members[rel] = row
    assert set(excluded) == EXCLUDED
    for name in ('tool-observations.json', 'pack.py'):
        p = ROOT / name
        members['publication/' + name] = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
    total = sum(r['bytes'] for r in members.values())
    assert total < 16 * 1024**2 and len(members) < 512
    DEST.mkdir()
    archive = DEST / 'evidence.tar.gz'
    with archive.open('xb') as raw, tarfile.open(fileobj=raw, mode='w:gz') as tar:
        for name, row in sorted(members.items()):
            data = Path(row['path']).read_bytes()
            assert hashlib.sha256(data).hexdigest() == row['sha256']
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        entries = tar.getmembers()
        assert len(entries) == len(members) and {x.name for x in entries} == set(members)
        for info in entries:
            assert info.isfile() and not info.name.startswith('/') and '..' not in Path(info.name).parts
            data = tar.extractfile(info).read()
            row = members[info.name]
            assert len(data) == info.size == row['bytes']
            assert hashlib.sha256(data).hexdigest() == row['sha256']
    for row in list(members.values()) + list(excluded.values()):
        assert Path(row['path']).stat().st_size == row['bytes'] and sha(row['path']) == row['sha256']
    cases = [{k: c[k] for k in ('transport', 'operations', 'outcomes', 'history_sha256',
                               'fresh_drained_voters', 'point_batch_overlap_count')}
             for c in audit['cases']]
    summary = {
        'complete': True, 'created_ns': time.time_ns(), 'revision': REV, 'source_files': 1116,
        'server_sha256': default['server_sha256'], 'native_workload_sha256': default['workload_sha256'],
        'diagnostic_sha256': diagnostic['variants'][0]['binary']['sha256'],
        'archive': {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                    'members': len(members), 'decoded_bytes': total},
        'actual_terminals': terminals, 'cases': cases,
        'operations': sum(c['operations'] for c in cases),
        'ok': sum(c['outcomes'].get('ok', 0) for c in cases),
        'unknown': sum(c['outcomes'].get('unknown', 0) for c in cases),
        'fresh_drains': sum(c['fresh_drained_voters'] for c in cases),
        'server_lifetimes': audit['server_lifetimes'], 'client_lifetimes': audit['client_lifetimes'],
        'original_inputs_unchanged': True, 'every_archive_member_read_back': True,
        'scope': 'Default/native and diagnostic release provenance plus ordinary three-voter recovery only. No actual Chaos Mesh, performance, physical power-loss, cross-host or whole-Raft proof claim.',
        'pending': ['actual full21 Chaos Mesh', 'original 8-smoke/16-ten-second matched performance screen',
                    'separate live schema-2 observer capture', 'promotion decision'],
    }
    save(DEST / 'inventory.json', {'complete': True, 'members': members, 'retained_excluded_binaries': excluded})
    save(DEST / 'summary.json', summary)
    save(ROOT / 'result.json', summary)
    print(json.dumps({k: summary[k] for k in ('complete', 'archive', 'operations', 'ok', 'unknown', 'fresh_drains')}))


if __name__ == '__main__':
    main()
