#!/usr/bin/env python3
"""Retain all completed stage-one samples without duplicate corpus or executables."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

R=Path('/home/dongxu/kv9');S=Path(__file__).resolve().parent
O=R/'docs/entry-buffer-performance-v1';O.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
analysis=json.loads((S/'analysis.json').read_text());assert analysis['complete'] and not analysis['stage_one_gate_passed']
assert analysis['processes']==52 and len(list((S/'runs').glob('*-terminal.json')))==52
members={};excluded=[]
for p in sorted(S.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=str(p.relative_to(S))
    if p.name=='groups.bin' or p.name.endswith('-progress.json') or p.name.startswith('issue9'):continue
    with p.open('rb') as f:magic=f.read(4)
    if magic==b'\x7fELF':excluded.append(relative);continue
    members['experiment/'+relative]=p
for p in sorted((R/'scripts/entry-buffer-performance').glob('*')):
    if p.is_file():members['repo/'+str(p.relative_to(R))]=p
members['repo/scripts/build_cache.py']=R/'scripts/build_cache.py'
records=[];archive=O/'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,p in sorted(members.items()):
                assert not p.is_symlink();data=p.read_bytes();info=tar.gettarinfo(str(p),arcname=name)
                info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
                with p.open('rb') as f:tar.addfile(info,f)
                records.append(dict(path=name,bytes=len(data),sha256=sha(data)))
with tarfile.open(archive,'r:gz') as tar:
    assert tar.getnames()==[r['path'] for r in records]
    for r in records:
        data=tar.extractfile(r['path']).read();assert len(data)==r['bytes'] and sha(data)==r['sha256']
manifest=dict(complete=True,members=len(records),expanded_bytes=sum(r['bytes'] for r in records),compressed_bytes=archive.stat().st_size,
              sha256=sha(archive.read_bytes()),all_members_read_back=True,local_root=str(S),processes=52,timing_rows=32,allocation_rows=16,
              stage_one_gate_passed=False,stage_two='not run; stopped by declared write gate',production_promoted=False,
              excluded_binaries=excluded,other_exclusions=['Duplicate groups.bin','Mutable progress/GitHub payloads and Python cache'],
              external=dict(corpus='../outlined-mutation-path-v1/evidence.tar.gz:outlined/groups.bin',corpus_sha256='d978ba9e49131f6277f975ecd333c33854845cc03bd14ee57a22fff915a08350',
                            qualified_sources='../entry-buffer-qualification-v1/evidence.tar.gz',qualification_sha256='401e3194629ef3138736df1d2b08f12067a9cb2d523a3613fe4b6e92a50cb2fa'),
              binaries=json.loads((S/'build-summary.json').read_text())['arms'],
              codegen_control=json.loads((S/'key-clamp-codegen/result.json').read_text()))
for name,data in [('manifest.json',manifest),('members.json',records)]:
    (O/name).write_text(json.dumps(data,indent=2)+'\n')
for name in ('plan.json','declared-plan.json','analysis.json','allocation-analysis.json','next-key-clamp-plan.json','post-screen-audit.json'):
    shutil.copyfile(S/name,O/name)
(O/'README.md').write_text(f"""# Single-buffer write-screen evidence

See the [report](../ENTRY-BUFFER-PERFORMANCE.md). Correctness and allocation
accounting pass; the declared write gate fails. Read/range timing is not run.
Production remains unchanged.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['sha256']}`.
Every member size/hash passed readback; [members.json](members.json) and
[manifest.json](manifest.json) record all retained bytes and exclusions.

The packet contains four identified screen release builds, generated harnesses,
source correspondence, all 52 workload launch/terminal records and outputs,
32 timing / 16 allocation rows and every raw window, independent dataset,
allocation, statistic and final-footprint analysis, and both declared/executable
plans. The corpus and qualified source packet below are external, hash-pinned
inputs. Exact binaries remain local with identities in their build records.

The [qualification packet](../entry-buffer-qualification-v1/README.md) supplies
the measured baseline/candidate engine/common sources and prior proof/models.
The original corpus is `outlined/groups.bin` in the
[outlined packet](../outlined-mutation-path-v1/README.md). Reproduction uses source
base `e17d1b3` and recorded paths; otherwise identify a fresh attempt without
relabeling existing results.

A fifth release build is a **codegen-only** safe key-accessor control, with its
source copy, exact one-expression change, compiler outputs and disassembly.
It executes zero workloads and has no new proof/model qualification or timing.
The initial inspector newline-hash mismatch is retained separately with its
correction; no measured output or gate changed. The
[next plan](next-key-clamp-plan.json) requires qualification before any timing.

No database/Redis result, new MinIO/recovery/actual Chaos acceptance or industrial
checklist closure follows. Keep the failed write gate and skipped read stage.
""")
print(json.dumps(manifest))
