import argparse,hashlib,io,json,tarfile,gzip
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--chaos-manifest',type=Path,required=True)
parser.add_argument('--failure-manifest',type=Path,action='append',default=[])
args=parser.parse_args()
repo=Path('/home/dongxu/kv9')
root=Path(__file__).resolve().parent
out=repo/'docs/checkpoint-base-v1'
out.mkdir(exist_ok=True)
archive=out/'evidence.tar.gz'
assert not archive.exists(), 'archive already exists'
entries={}
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(name,path,expected=None):
 path=Path(path)
 assert path.is_file() and not path.is_symlink(),path
 b=path.read_bytes()
 if expected:assert sha(b)==expected,path
 assert len(b)<=64*1024**2,path
 assert name not in entries,name
 entries[name]=(path,b)
source_names=list(json.loads(Path('/tmp/kv9-c04-checkpoint-base-runtime-inputs-20260915-first/source-tree.json').read_text()))
source_names += ['scripts/check-checkpoint-base.py','scripts/check-checkpoint-publication.py',
 'scripts/checkpoint-publication-chaos.py','scripts/check-tlaps.py','scripts/check-tla.py',
 'scripts/ProofAudit.java','scripts/minio-kv-e2e.py','scripts/root_provision.py','scripts/wal_layout.py',
 'docs/CHECKPOINT-BASE-IDENTITY.md','docs/RECOVERY-RETENTION-CONTRACT.md']
source_names.extend(str(p.relative_to(repo)) for d in ['proofs/tla/checkpoint_base','proofs/tlaps/checkpoint_base','proofs/tla/checkpoint_publication','proofs/tlaps/checkpoint_publication'] for p in (repo/d).rglob('*') if p.is_file())
for name in sorted(set(source_names)):add('source/'+name,repo/name)
for run in sorted(Path('/tmp').glob('kv9-c04-checkpoint-base-*')):
 if not run.is_dir() or run==root or 'chaos-' in run.name:continue
 for p in sorted(run.rglob('*')):
  rel=p.relative_to(run)
  if not p.is_file() or p.is_symlink() or any(x in ('cache','states','auditor','target','__pycache__','.tlacache') for x in rel.parts):continue
  if p.suffix not in ('.json','.jsonl','.py','.log','.rs','.tla','.cfg','.java','.md'):continue
  add('runs/'+run.name+'/'+str(rel),p)
# Exact process fixture selection is supplied separately after actual acceptance.
selection=root/'process-public-files.json'
if selection.exists():
 for row in json.loads(selection.read_text())['files']:add('process-fixture/'+row['name'],row['path'],row['sha256'])
fixture=Path('/tmp/kv9-c04-minio-tmpfs-fixture-20260915-first')
chaos=json.loads(args.chaos_manifest.read_text())
for row in chaos['files']:
 p=Path(row['path']);add('chaos/'+str(p.relative_to(args.chaos_manifest.parent)),p,row['sha256'])
add('chaos/public-evidence.json',args.chaos_manifest)
for manifest in args.failure_manifest:
 prior=json.loads(manifest.read_text())
 for row in prior['files']:
  p=Path(row['path']);add('chaos-prior/'+manifest.parent.name+'/'+str(p.relative_to(manifest.parent)),p,row['sha256'])
 add('chaos-prior/'+manifest.parent.name+'/public-evidence.json',manifest)
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in ('.json','.py'):add('publication/'+p.name,p)
secrets=[]
for p in fixture.rglob('credentials.env'):
 secrets.extend(line.split('=',1)[1].encode() for line in p.read_text().splitlines() if line.split('=',1)[0] in ('MINIO_ROOT_USER','MINIO_ROOT_PASSWORD'))
for manifest in [args.chaos_manifest,*args.failure_manifest]:
 secret_path=manifest.parent/'credentials.json'
 if secret_path.exists():secrets.extend(v.encode() for v in json.loads(secret_path.read_text()).values())
for name,(_,b) in entries.items():
 assert all(s not in b for s in secrets if s),'secret value detected; refusing archive: '+name
rows=[]
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
 for name,(p,b) in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(b));rows.append({'name':name,'bytes':len(b),'sha256':sha(b),'original':str(p)})
# Independent complete decode after close, against each retained original.
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  assert member.isfile() and member.name==row['name']
  b=tar.extractfile(member).read();assert b==Path(row['original']).read_bytes()
  assert len(b)==row['bytes'] and sha(b)==row['sha256']
result={'status':'PASS','members':len(rows),'decoded_bytes':sum(r['bytes'] for r in rows),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'complete_original_readback':True,'known_fixture_secrets_absent':True,'files':rows}
(out/'inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
