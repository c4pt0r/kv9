import hashlib,json,os,signal,shutil,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/dongxu/kv9')
binary=Path('/tmp/kv9-c04-checkpoint-publication-runtime-inputs-20260915-first/kv9')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(binary)=='bf6099efb05d8143747b7994e3ffd72847fede1e1310757c3b3adca7a8f16c32'
creds=dict(line.split('=',1) for line in Path('/tmp/kv9-c04-minio-tmpfs-fixture-20260915-first/attempt-second/credentials.env').read_text().splitlines())
env=os.environ.copy()
env.update(KV9_BIN=str(binary),KV9_BASE_PORT='23400',KV9_MINIO_EXTERNAL='1',KV9_OBJECT_STORE_ENDPOINT='http://127.0.0.1:32789',KV9_OBJECT_STORE_BUCKET='kv9-c04-tmpfs-6b7478a538',KV9_OBJECT_STORE_REGION='us-east-1',KV9_OBJECT_STORE_ACCESS_KEY=creds['MINIO_ROOT_USER'],KV9_OBJECT_STORE_SECRET_KEY=creds['MINIO_ROOT_PASSWORD'])
command=['python3','scripts/minio-kv-e2e.py']
record={'command':command,'binary':str(binary),'binary_sha256':sha(binary),'inputs':{s:sha(repo/s) for s in ['scripts/minio-kv-e2e.py','scripts/root_provision.py','scripts/wal_layout.py']},'minio_container':'0a5e647045482e1d3eaf650d9480fd946c8dbc9e76fa7b536ba67ba70eaa96c0','object_store_scope':'Actual S3 protocol and process recovery; tmpfs object store does not test object-store power-loss durability.','free_space_floor_bytes':8*2**30,'fresh_local_allocation_limit_bytes':2**30,'free_before':shutil.disk_usage('/tmp').free}
assert record['free_before']>8*2**30
started=time.monotonic();proc=None;artifact=None
try:
 with (root/'process.log').open('w') as log:
  proc=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  record['pid']=proc.pid
  while proc.poll() is None:
   time.sleep(1)
   if artifact is None:
    lines=(root/'process.log').read_text().splitlines()
    if lines and lines[0].startswith('Artifacts: '): artifact=Path(lines[0][11:]);record['artifacts']=str(artifact)
   assert time.monotonic()-started<300,'process E2E exceeded 300 seconds'
   assert shutil.disk_usage('/tmp').free>=8*2**30,'free space floor reached'
   if artifact:
    allocated=sum(p.stat().st_blocks*512 for p in artifact.rglob('*') if p.is_file())
    record['peak_observed_local_allocation_bytes']=max(record.get('peak_observed_local_allocation_bytes',0),allocated)
    assert allocated<=2**30,'fresh allocation cap exceeded'
  record['exit_code']=proc.returncode
  assert proc.returncode==0,'process E2E returned nonzero'
 record['status']='PASS'
except Exception as error:
 record.update(status='FAIL',reason=str(error))
finally:
 if proc is not None and proc.poll() is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
 record.update(seconds=time.monotonic()-started,free_after=shutil.disk_usage('/tmp').free)
 (root/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
raise SystemExit(0 if record['status']=='PASS' else 1)
