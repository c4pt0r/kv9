import hashlib,json,os,signal,shutil,subprocess,time,secrets,socket,ctypes
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/dongxu/kv9')
binary=Path('/tmp/kv9-c04-checkpoint-base-runtime-inputs-20260915-first/kv9')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(binary)=='70a61b09c72d0e3e79717ee7f84f7d87c7c77ad6b347013aa8678ad656ce3966'
inputs=json.loads(binary.with_name('inputs.json').read_text())
assert inputs['binary_sha256']==sha(binary) and inputs['binary_bytes']==binary.stat().st_size
for name,digest in inputs['source_pins'].items():assert sha(repo/name)==digest
for port in (23401,23402,23403):
 with socket.socket() as probe:probe.bind(('127.0.0.1',port))
bucket='kv9-c04-base-process-'+secrets.token_hex(5)
creds=dict(line.split('=',1) for line in Path('/tmp/kv9-c04-minio-tmpfs-fixture-20260915-first/attempt-second/credentials.env').read_text().splitlines())
env=os.environ.copy()
env['TMPDIR']=str(root)
env.pop('KV9_TEST_PENDING_CRASHES',None)
env.update(KV9_BIN=str(binary),KV9_BASE_PORT='23400',KV9_MINIO_EXTERNAL='1',KV9_OBJECT_STORE_ENDPOINT='http://127.0.0.1:32789',KV9_OBJECT_STORE_BUCKET=bucket,KV9_OBJECT_STORE_REGION='us-east-1',KV9_OBJECT_STORE_ACCESS_KEY=creds['MINIO_ROOT_USER'],KV9_OBJECT_STORE_SECRET_KEY=creds['MINIO_ROOT_PASSWORD'])
command=['python3','scripts/minio-kv-e2e.py']
record={'command':command,'binary':str(binary),'binary_sha256':sha(binary),'inputs':{s:sha(repo/s) for s in ['scripts/minio-kv-e2e.py','scripts/root_provision.py','scripts/wal_layout.py']},'minio_container':'0a5e647045482e1d3eaf650d9480fd946c8dbc9e76fa7b536ba67ba70eaa96c0','object_store_scope':'Actual S3 protocol and process recovery; tmpfs object store does not test object-store power-loss durability.','free_space_floor_bytes':8*2**30,'fresh_local_allocation_limit_bytes':2**30,'free_before':shutil.disk_usage('/tmp').free,'source_inputs':sha(binary.with_name('inputs.json')),'bucket':bucket,'default_feature_pending_controls_disabled':True}
assert record['free_before']>8*2**30
(root/'preflight.json').write_text(json.dumps(record,indent=2)+'\n')
started=time.monotonic();proc=None;artifact=None
try:
 # The existing fixture credentials stay inside the container environment.
 container_id=record['minio_container']
 obj=json.loads(subprocess.check_output(['docker','inspect',container_id]))[0]
 assert obj['Id']==container_id and obj['State']['Running'] and obj['Image']=='sha256:69b2ec208575b69597784255eec6fa6a2985ee9e1a47f4411a51f7f5fdd193a9'
 argv=['docker','exec',container_id,'/bin/sh','-c','export MC_HOST_local="http://${MINIO_ROOT_USER}:${MINIO_ROOT_PASSWORD}@127.0.0.1:9000"; mc mb "local/$1"','command',bucket]
 made=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 (root/'bucket.stdout').write_bytes(made.stdout);(root/'bucket.stderr').write_bytes(made.stderr)
 (root/'bucket-terminal.json').write_text(json.dumps({'argv':argv,'exit_code':made.returncode},indent=2)+'\n');assert made.returncode==0
 with (root/'process.log').open('w') as log:
  proc=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  record['pid']=proc.pid
  fields=Path(f'/proc/{proc.pid}/stat').read_text().rsplit(')',1)[1].split()
  record['start_ticks']=int(fields[19]);record['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
  (root/'child-start.json').write_text(json.dumps({'pid':proc.pid,'start_ticks':record['start_ticks'],'boot_id':record['boot_id'],'command':command},indent=2)+'\n')
  while proc.poll() is None:
   time.sleep(1)
   if artifact is None:
    lines=(root/'process.log').read_text().splitlines()
    if lines and lines[0].startswith('Artifacts: '): artifact=Path(lines[0][11:]);record['artifacts']=str(artifact)
   assert time.monotonic()-started<300,'process E2E exceeded 300 seconds'
   free=shutil.disk_usage('/tmp').free
   record['minimum_available_bytes']=min(record.get('minimum_available_bytes',record['free_before']),free)
   assert free>=8*2**30,'free space floor reached'
   assert record['free_before']-free<=2**30,'1 GiB sampled host decrease cap'
   with (root/'resources.jsonl').open('a')as resource:resource.write(json.dumps({'observed_ns':time.time_ns(),'available_bytes':free})+'\n')
   if artifact:
    allocated=sum(p.stat().st_blocks*512 for p in artifact.rglob('*') if p.is_file())
    record['peak_observed_local_allocation_bytes']=max(record.get('peak_observed_local_allocation_bytes',0),allocated)
    assert allocated<=2**30,'fresh allocation cap exceeded'
  record['exit_code']=proc.returncode
  assert proc.returncode==0,'process E2E returned nonzero'
 assert sha(binary)==inputs['binary_sha256']
 for name,digest in inputs['source_pins'].items():assert sha(repo/name)==digest
 for name,digest in record['inputs'].items():assert sha(repo/name)==digest
 members=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:fields=(entry/'stat').read_text().rsplit(')',1)[1].split()
  except (FileNotFoundError,ProcessLookupError):continue
  if int(fields[2])==proc.pid:members.append(int(entry.name))
 assert not members,'owned process group remains'
 record['owned_process_group_absent']=True
 record['status']='PASS'
except Exception as error:
 record.update(status='FAIL',reason=str(error))
finally:
 if proc is not None and proc.poll() is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
 record.update(seconds=time.monotonic()-started,free_after=shutil.disk_usage('/tmp').free)
 (root/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
raise SystemExit(0 if record['status']=='PASS' else 1)
