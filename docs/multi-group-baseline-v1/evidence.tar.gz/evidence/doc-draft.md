# Multi-group throughput baseline (draft; round-2 numbers pending)

Single host, 32 cores, three voter processes, tmpfs stores: a development
diagnostic under the benchmark contract, never 3/6/9-host evidence.

## Round-1 findings (30 s cells, put, 128 B values, 2048 keys/group)

Fixed aggregate 64 workers: 147.8k -> 200.8k (2 groups) -> 210.6k (4) ->
181.3k (8; 8-deep per-group pipelines are too thin).
Equal 32 workers/group, default admission: 123.2k -> 164.6k -> 243.0k at 4
groups; 8 groups collapsed against the default KV9_PUBLIC_MAX_REQUESTS=64/node
admission budget (0.55M refusals in 30 s) - first measured ceiling.
With admission raised to 1024/node (two reps each, spread in brackets):
126.1k (1.0) -> 203.6k (S=1.61, +-0.2%) -> 270.4k (S=2.14, +-0.9%) ->
292.2k (S=2.32, 272k/312k) at 8 groups; p99 0.5-1ms at g1-2 rising to 2-4ms
at g8. dw=1 tracks slightly below dw=2 at the same cells (250.4k, 280.0k).
Data-worker sweep at g8/aggregate-64: dw1 190.0k > dw2 181.3k > dw4 161.7k >
dw8 127.8k - at unsaturated load, more workers only shrink per-turn batches
and add wakeups. At g4x32 the two workers reach 88% utilization on two of
three nodes - saturation begins; round 2 tests whether dw>2 helps there.

## Bottleneck ledger (evidence-backed)

1. Admission budget (64 concurrent/node, env-configurable): binds first.
2. Per-group pipeline depth: fixed aggregate load thins per-group batching.
3. Shared 2-worker pool: efficient below saturation (per-turn batching),
   ~88% busy at 4 groups x 32 workers; dw knob now configurable (1..=32).
4. Physical-disk panel (RAID5 HDD, per-append fsync, no group commit yet,
   #20 open): 0.86k/s single group, 0.73k/s two groups - fsync-bound, the
   dominant real-durability ceiling; recorded, not pooled with tmpfs.

## Non-claims

No 3/6/9-host scaling, no online expansion, no p99-budget sustained-load
acceptance (30 s cells, closed loop), no durability-panel improvement.
