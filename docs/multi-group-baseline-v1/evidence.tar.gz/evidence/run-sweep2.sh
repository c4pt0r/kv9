#!/bin/bash
set -uo pipefail
cd /home/dongxu/kv9
W=/mnt/data/kv9-work/multi-group-baseline-20260916
B=(--server target/release/kv9 --workload "$W/build/kv9-workload" --build-manifest "$W/build/build.json" --store-root /dev/shm/kv9-sweep)
rm -rf /dev/shm/kv9-sweep
python3 scripts/multi-group-sweep.py "${B[@]}" --output "$W/panel-a2" --groups 1,2,4,8,16 --mixes put,mixed,get --reps 2 --measure-ms 30000 --warmup 2000 || echo "PANEL-A2 FAILED"
python3 scripts/multi-group-sweep.py "${B[@]}" --output "$W/panel-b2" --groups 1,2,4,8 --mixes put --reps 2 --aggregate-workers 32 --scale-load --max-requests 1024 --measure-ms 30000 --warmup 2000 || echo "PANEL-B2 FAILED"
python3 scripts/multi-group-sweep.py "${B[@]}" --output "$W/panel-c2-dw1" --groups 4,8 --mixes put --reps 2 --aggregate-workers 32 --scale-load --max-requests 1024 --data-workers 1 --measure-ms 30000 --warmup 2000 || echo "PANEL-C2 FAILED"
echo SWEEP2-ALL-DONE
