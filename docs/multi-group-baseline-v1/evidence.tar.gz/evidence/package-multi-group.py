import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/dongxu/kv9');work=Path('/mnt/data/kv9-work/multi-group-baseline-20260916');out=root/'docs/multi-group-baseline-v1'
local=json.loads((work/'local-validation.json').read_text())
assert local['schema']==1
out.mkdir(exist_ok=False)
files={};excluded=[]
for p in sorted(work.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 r=p.relative_to(work)
 if '__pycache__' in r.parts or p.suffix in ('.olean','.ilean','.pyc'):continue
 if p.name.startswith('issue') or 'issues' in r.parts or p.name in ('publication.json','handoff-in.md'):continue
 if p.name in ('kubeconfig','token','credentials','root.bin') or p.suffix in ('.key','.pem'):excluded.append(str(r));continue
 if r.parts[0]=='build' and p.name!='build.json':excluded.append(str(r));continue
 with p.open('rb') as stream:magic=stream.read(4)
 if magic==b'\x7fELF':excluded.append(str(r));continue
 files['evidence/'+str(r)]=p
names=set()
for model in ['migration-authority','joint-install','protocol-snapshot','group-preparation','group-activation','group-control','data-range','routed-client']:
 c=root/'proofs/lean'/model/'source-contract.json';names.add(str(c.relative_to(root)));names.update(json.loads(c.read_text())['source_sha256'])
names.update(['scripts/multi-group-sweep.py','scripts/build-workload.py','docs/MULTI-GROUP-THROUGHPUT.md','docs/HORIZONTAL-SCALING-PLAN.md','crates/common/src/config.rs','crates/server/src/region_manager.rs','proofs/tlaps/retention_ledger/inventory.json','Cargo.toml','Cargo.lock'])
for command in [['git','diff','--name-only'],['git','ls-files','--others','--exclude-standard']]:
 for name in subprocess.check_output(command,cwd=root,text=True).splitlines():
  if name not in ('scripts/checkpoint-publication-chaos.py','scripts/checkpoint-owned-crash.py') and not name.startswith('docs/multi-group-baseline-v1/'):
   names.add(name)
for name in names:
 if (root/name).is_file():files['source/'+name]=root/name
members=[];total=0
with (out/'evidence.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,p in sorted(files.items()):
  data=p.read_bytes();total+=len(data);assert total<=512*1024**2,'decoded cap'
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  members.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert (out/'evidence.tar.gz').stat().st_size<=60*1024**2,'compressed archive must stay under the 64 MiB documentation file bound'
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 actual=[]
 for m in tar:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  d=tar.extractfile(m).read();actual.append({'name':m.name,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
assert actual==members
artifact=out/'evidence.tar.gz'
summary={'schema':1,'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'archive_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'archive_bytes':artifact.stat().st_size,'decoded_bytes':total,'decoded_cap_bytes':512*1024**2,'members':members,'excluded_files':excluded,'accepted':{'local':'evidence/local-validation.json','sweep_summary':'evidence/sweep-summary.json'},'not_claimed':['3/6/9-host or any multi-host scaling','online expansion or split/placement','p99-budget sustained-load acceptance','durability-panel improvement','proposal batching or group commit','Chaos Mesh acceptance for this increment','verified Rust extraction','hosted CI']}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['archive_sha256','archive_bytes','decoded_bytes']}));print('members',len(members))
