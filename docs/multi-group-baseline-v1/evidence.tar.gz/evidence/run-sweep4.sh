#!/bin/bash
set -uo pipefail
cd /home/dongxu/kv9
W=/mnt/data/kv9-work/multi-group-baseline-20260916
B=(--server target/release/kv9 --workload "$W/build/kv9-workload" --build-manifest "$W/build/build.json" --store-root /dev/shm/kv9-sweep)
rm -rf /dev/shm/kv9-sweep
# Deciding experiment: the exact failing g16 cell shape with only data workers raised.
python3 scripts/multi-group-sweep.py "${B[@]}" --output "$W/panel-d-g16-dw4" --groups 16 --mixes put --reps 2 --data-workers 4 --measure-ms 30000 --warmup 2000 || echo "D-dw4 FAILED"
python3 scripts/multi-group-sweep.py "${B[@]}" --output "$W/panel-d-g16-dw8" --groups 16 --mixes put --reps 2 --data-workers 8 --measure-ms 30000 --warmup 2000 || echo "D-dw8 FAILED"
python3 scripts/multi-group-sweep.py "${B[@]}" --output "$W/panel-d-g16-dw8-hi" --groups 16 --mixes put --reps 2 --data-workers 8 --aggregate-workers 32 --scale-load --max-requests 1024 --measure-ms 30000 --warmup 2000 || echo "D-dw8-hi FAILED"
echo SWEEP4-ALL-DONE
