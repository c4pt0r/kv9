# Multi-group throughput sweep: predeclared methodology (draft)

Status: predeclared BEFORE any timed run. Single host (32 cores, 123 GiB,
NVMe), three voter processes — a development diagnostic by the benchmark
contract's own terms, never 3/6/9-host scaling evidence. Its purpose is to
(1) prove the multi-group runtime actually converts added groups into added
throughput on fixed hardware, and (2) locate the first saturating bound
(data workers, inboxes, scheduler, WAL, gRPC) with direct evidence.

## Panels (fixed before timing)

- Group counts: 1, 2, 4, 8, 16 active groups, each its own Raw keyspace,
  one full-keyspace range per group (current D02 mapping).
- Workloads: uniform 128-byte-value Put; linearizable GET; 50/50 mix.
  Within-range BatchPut(64) as a secondary panel, calls/s and items/s
  reported separately.
- Keys: fixed seeded dataset per group; identical per-group key count and
  working set across panels. Load spread evenly over groups; per-group
  offered load = aggregate / groups.
- Duration: 30 s warmup + 120 s measurement per cell (dev-diagnostic
  shortening of the contract's 60/300; stated, not hidden).
- Repetitions: 3 independently seeded runs per cell; report each run;
  merge histogram counts for percentiles; never average percentiles.
- Latency: from intended (scheduled) arrival where the harness offers load
  at a fixed rate; report scheduling delay separately from service latency.
  Sweep offered load to the maximum sustainable under a fixed per-workload
  p99 budget declared after one excluded pilot, then held for every cell.
- Primary metric: S(g) = Q(g) / Q(1) at unchanged p99 budget. Secondary:
  per-process CPU seconds/op, RSS, data-worker utilization, inbox
  saturation counters, WAL fsync latency, Raft apply lag per group.
- All attempts retained, including failures and the excluded pilot.

## Controls

- Same binary hash, configuration and host for every cell; record both.
- One-group cell is the baseline; a separate single-group run with the
  pre-increment binary guards against tooling-induced regression.
- tmpfs and physical-disk WAL panels are separate; never pooled.
- Outcome accounting: every request success/refusal/unknown counted; no
  hidden retries; post-run readback per group.

## Explicit non-claims

No 3/6/9-host scaling, no online expansion, no split/placement, no Redis
parity, no durability-panel change. Same-CPU processes are not added nodes.
