#!/usr/bin/env python3
"""Summarize sweep cells: S(g), merged p99, worker-thread utilization."""
import json
import sys
from collections import defaultdict
from pathlib import Path

W = Path(__file__).parent


def merged_p99(cell_dir, mix):
    ops = {'put': ['put'], 'get': ['get'], 'mixed': ['get', 'put']}[mix]
    merged = defaultdict(lambda: [0] * 65)
    for report_path in sorted(cell_dir.glob('run-*/report.json')):
        m = json.loads(report_path.read_bytes())['metrics']
        mi = m['phases'].index('measure')
        for op in ops:
            oi = m['operations'].index(op)
            for entry in m['logical_latency'][mi][oi]['outcomes']:
                if entry['outcome'] == 'success':
                    for i, c in enumerate(entry['buckets']):
                        merged[op][i] += c
    out = {}
    for op, buckets in merged.items():
        total = sum(buckets)
        if not total:
            continue
        acc = 0
        for i, c in enumerate(buckets):
            acc += c
            if acc >= total * 0.99:
                out[op] = (2 ** i / 1e6, 2 ** (i + 1) / 1e6)  # ms interval
                break
    return out


def worker_cpu(record):
    """Per-node raft-data thread busy fraction over the harness window."""
    window = record.get('harness_elapsed_seconds') or 1
    busy = defaultdict(float)
    threads = defaultdict(int)
    for name, seconds in record.get('server_thread_cpu_seconds', {}).items():
        node, comm = name.split('/')[0], name.split('/')[1]
        if comm.startswith('raft-data'):
            busy[node] += seconds
            threads[node] += 1
    return {node: dict(busy_seconds=round(busy[node], 1), threads=threads[node],
                       utilization=round(busy[node] / (threads[node] * window), 3)
                       if threads[node] else None)
            for node in busy}


def main():
    panels = sys.argv[1:] or ['panel-a', 'panel-b', 'panel-c-dw1', 'panel-c-dw4', 'panel-c-dw8']
    summary = {}
    for panel in panels:
        root = W / panel
        if not (root / 'sweep.json').exists():
            continue
        sweep = json.loads((root / 'sweep.json').read_bytes())
        cells = defaultdict(list)
        for cell in sweep['cells']:
            if cell['verdict'] != 'accepted':
                continue
            key = (cell['mix'], cell['data_workers'], cell['groups'], cell['workers_per_group'])
            cells[key].append(cell)
        rows = []
        for (mix, dw, groups, wpg), reps in sorted(cells.items()):
            rates = [c['aggregate_success_ops_per_second'] for c in reps]
            p99s = [merged_p99(root / c['name'], mix) for c in reps]
            cpus = [worker_cpu(c) for c in reps]
            rows.append(dict(mix=mix, data_workers=dw, groups=groups, workers_per_group=wpg,
                             rates=[round(r) for r in rates],
                             mean_rate=round(sum(rates) / len(rates)),
                             overlap_seconds=[round(c['measurement_overlap_seconds'], 1) for c in reps],
                             p99_ms_interval=p99s[0], worker_cpu=cpus[0]))
        base = {(r['mix'], r['data_workers']): r['mean_rate']
                for r in rows if r['groups'] == 1}
        for r in rows:
            b = base.get((r['mix'], r['data_workers']))
            if b:
                r['speedup_vs_one_group'] = round(r['mean_rate'] / b, 2)
        summary[panel] = rows
        print(f'== {panel}')
        for r in rows:
            print(f"  {r['mix']:5} dw={r['data_workers']} g={r['groups']:2} wpg={r['workers_per_group']:3} "
                  f"rate={r['mean_rate']:>8} S={r.get('speedup_vs_one_group','-'):>5} "
                  f"p99={r['p99_ms_interval']} reps={r['rates']}")
    (W / 'sweep-summary.json').write_text(json.dumps(summary, indent=2) + '\n')


if __name__ == '__main__':
    main()
