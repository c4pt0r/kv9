"""Execute one frozen, root-owned gate and retain the original outcome."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--prep', type=Path, required=True)
p.add_argument('--inventory', type=Path, required=True)
p.add_argument('--inventory-sha', required=True)
p.add_argument('--key', required=True)
p.add_argument('--label', required=True)
p.add_argument('--session')
args = p.parse_args()

def verify():
    data = args.inventory.read_bytes()
    assert hashlib.sha256(data).hexdigest() == args.inventory_sha
    manifest = json.loads(data)
    for name, expected in manifest.get('files', manifest).items():
        value = (args.prep / name).read_bytes()
        assert len(value) == expected['bytes'], name
        assert hashlib.sha256(value).hexdigest() == expected['sha256'], name

verify()
command = json.loads((args.prep / 'commands.json').read_text())[args.key]
placeholders = ('ROOT_ACTUAL_TERMINAL_SESSION', 'ROOT_TERMINAL_TIMING_SESSION')
if any(value in command for value in placeholders):
    assert args.session
    command = [args.session if item in placeholders else item for item in command]
out = ROOT / args.label
out.mkdir()
record = dict(complete=False, argv=command, started_ns=time.time_ns(),
              inventory=str(args.inventory), inventory_sha256=args.inventory_sha)
try:
    with (out / 'output.log').open('x') as log:
        child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
        record['child_pid'] = child.pid
        (out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
        record['exit_code'] = child.wait()
    record['ended_ns'] = time.time_ns()
    if record['exit_code'] != 0:
        raise RuntimeError('Gate failed; original outcome retained: ' + str(out))
    verify()
    record['complete'] = True
finally:
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print('PASS:', args.label, 'terminal; preparation unchanged', flush=True)
