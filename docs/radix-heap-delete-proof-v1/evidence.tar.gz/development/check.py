from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, time

root = Path(__file__).resolve().parent
repo = Path('/home/dongxu/kv9')
out = root / sys.argv[1]
out.mkdir(exist_ok=False)
basis = Path('/mnt/data/kv9-work/radix-heap-insert-proof-20260916-first/positive')
contract = json.loads((repo / 'proofs/lean/radix/heap-insert-contract.json').read_text())
lean = Path('/mnt/data/kv9-work/lean-toolchain-restoration-20260915-first/installation/lean-4.33.1-linux/bin/lean')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(lean.read_bytes()) == contract['lean_sha256']
assert json.loads((basis.parent / 'result.json').read_text())['accepted']
copied = {}
for name in contract['modules']:
    assert (basis / name).read_bytes() == (repo / 'proofs/lean/radix' / name).read_bytes()
    for path in [basis / name, *basis.glob(Path(name).stem + '.olean*')]:
        shutil.copyfile(path, out / path.name)
        copied[path.name] = sha(path.read_bytes())
modules = sys.argv[2:]
names = []
for name in modules:
    data = (repo / 'proofs/lean/radix' / name).read_text()
    (out / name).write_text(data)
    names += re.findall(r'^\s*theorem\s+(\w+)', data, re.M)
(out / 'Audit.lean').write_text('import ' + Path(modules[-1]).stem + '\n' +
    '\n'.join('#print axioms Kv9.Radix.' + name for name in names) + '\n')
result = {'basis': str(basis), 'basis_compiler_outputs_reused': copied,
          'new_modules': modules, 'commands': [], 'started_ns': time.time_ns(), 'accepted': False}
for name in [*modules, 'Audit.lean']:
    argv = [str(lean), '-DwarningAsError=true', '-o', name.replace('.lean', '.olean'), name]
    with (out / (name + '.log')).open('x') as log:
        proc = subprocess.run(argv, cwd=out, env=dict(os.environ, LEAN_PATH=str(out)),
                              stdout=log, stderr=subprocess.STDOUT, timeout=120)
    result['commands'].append({'argv': argv, 'exit_code': proc.returncode})
    if proc.returncode:
        print((out / (name + '.log')).read_text())
        break
else:
    audit = (out / 'Audit.lean.log').read_text()
    axioms = {}
    for name in names:
        qualified = 'Kv9.Radix.' + name
        matches = list(re.finditer(re.escape("'" + qualified + "'") +
            r' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)', audit))
        assert len(matches) == 1, name
        used = {x.strip() for x in (matches[0][1] or '').split(',') if x.strip()}
        assert used <= {'propext', 'Classical.choice', 'Quot.sound'}, (name, used)
        axioms[qualified] = sorted(used)
    result['axioms'] = axioms
    result['accepted'] = True
result['ended_ns'] = time.time_ns()
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'attempt': str(out), 'accepted': result['accepted'], 'new_theorems': len(names),
                  'new_compiler_commands': len(result['commands'])}))
sys.exit(0 if result['accepted'] else 1)
