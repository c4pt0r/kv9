#!/usr/bin/env python3
"""Read back retained qualification independently of the test/build supervisors."""
import hashlib
import json
from pathlib import Path
import re
import struct
import tomllib

S = Path(__file__).resolve().parent
R = Path('/home/dongxu/kv9')
P = Path('/mnt/data/kv9-work/resident-selected-profile-20260916-first')
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda name: json.loads((S / name).read_text())
tests = load('tests-summary.json')
assert tests['complete'] and len(tests['cases']) == 3
for row, expected in zip(tests['cases'], (58, 58, 276)):
    directory = Path(row['output'])
    assert row['complete'] and row['test_exit_code'] == row['resolve_exit_code'] == 0
    assert sha((directory / 'tests').read_bytes()) == row['binary']['sha256']
    lines = (directory / 'tests.stdout').read_text().splitlines()
    assert len([line for line in lines if line.startswith('test ') and line.endswith(' ... ok')]) == expected
    if row['name'].endswith('archery'):
        added = [line for line in lines if '::callback_tests::' in line and line.endswith(' ... ok')]
        assert len(added) == 9
    assert load(directory.relative_to(S) / 'cache-safety.json')['complete']
    for path, digest in load(directory.relative_to(S) / 'sources.json').items():
        assert sha(Path(path).read_bytes()) == digest

proof = load('proof/result.json')
assert proof['accepted'] and proof['complete'] and len(proof['theorems']) == 18
assert len(proof['controls']) == 8 and all(c['rejected'] for c in proof['controls'])
assert all(set(axioms) <= {'propext', 'Classical.choice', 'Quot.sound'} for axioms in proof['theorems'].values())
for path, digest in load('proof/source-inputs.json').items():
    assert sha(Path(path).read_bytes()) == digest
callers = []
for kind in ('rc', 'arc', 'arct'):
    path = S / 'candidate-archery/src/shared_pointer/kind' / kind / 'mod.rs'
    assert path.read_bytes() == (S / 'baseline-archery/src/shared_pointer/kind' / kind / 'mod.rs').read_bytes()
    lines = [line.strip() for line in path.read_text().splitlines() if '.map_owned::' in line]
    assert len(lines) == 2
    callers.extend({'kind': kind, 'call': line} for line in lines)

build = load('codegen-build-summary.json')
assert build['complete'] and len(build['cases']) == 2
for row in build['cases']:
    directory = S / ('build-codegen-' + row['arm'])
    assert row['complete'] and sha((directory / 'resident-selected-profile').read_bytes()) == row['binary']['sha256']
    assert load(directory.relative_to(S) / 'cache-safety.json')['complete']
    for path, digest in load(directory.relative_to(S) / 'sources.json').items():
        assert sha(Path(path).read_bytes()) == digest
    assert (S / ('codegen-' + row['arm']) / 'src/main.rs').read_bytes() == (R / 'scripts/resident-selected-profile/src/main.rs').read_bytes()
registry = lambda path: {(p['name'], p['version'], p['source']): p['checksum'] for p in tomllib.loads(path.read_text())['package'] if p.get('source', '').startswith('registry+')}
assert registry(S / 'codegen-baseline/Cargo.lock') == registry(S / 'codegen-candidate/Cargo.lock')
codegen = load('codegen-summary.json')
assert len(codegen['baseline']['as_ptr_symbols']) == 1 and not codegen['candidate']['as_ptr_symbols']
assert codegen['baseline']['symbol_reference_instructions'] == 21 and codegen['candidate']['symbol_reference_instructions'] == 0

# Independent byte decoder reconstructs the two final maps and their digests.
data = (P / 'groups.bin').read_bytes()
assert sha(data) == 'd978ba9e49131f6277f975ecd333c33854845cc03bd14ee57a22fff915a08350'
assert data[:8] == b'KV9GRP01'
offset = 8
ordinal = 0
groups = 0
models = {'overwrite': {}, 'unique_insert': {}}
while offset < len(data):
    previous, last, term, size = struct.unpack_from('<QQQI', data, offset)
    assert last > previous and term == 1
    offset += 28
    end = offset + size
    count, = struct.unpack_from('<I', data, offset)
    offset += 4
    for _ in range(count):
        assert data[offset:offset + 2] == b'\x00\x00'
        offset += 2
        size, = struct.unpack_from('<I', data, offset)
        offset += 4
        key = data[offset:offset + size]
        offset += size
        size, = struct.unpack_from('<I', data, offset)
        offset += 4
        value = data[offset:offset + size]
        offset += size
        ordinal += 1
        models['overwrite'][key] = value
        models['unique_insert'][key + ordinal.to_bytes(8, 'big')] = value
    assert offset == end
    groups += 1
assert groups == 106 and ordinal == 100096
digests = {}
for workload, model in models.items():
    digest = hashlib.sha256()
    digest.update(len(model).to_bytes(8, 'little'))
    for key, value in sorted(model.items()):
        for part in (key, value):
            digest.update(len(part).to_bytes(8, 'little'))
            digest.update(part)
    digests[workload] = digest.hexdigest()
smokes = load('release-smokes-summary.json')
assert smokes['complete'] and len(smokes['cases']) == 8
for row in smokes['cases']:
    assert row['complete'] and row['exit_code'] == 0
    assert row['final_sha256'] == digests[row['workload']]
    assert row['final_keys'] == len(models[row['workload']])
    directory = S / ('smoke-' + row['arm'] + '-' + row['workload'] + '-' + row['mode'])
    done = json.loads((directory / 'result.json').read_text())
    assert done['complete'] and len(done['spans']) == 106
    assert all(p == 0 and g == index and start < end for index, (p, g, start, end) in enumerate(done['spans']))
    assert done['final_state_sha256'] == row['final_sha256'] and done['mutations'] == 100096
assert smokes['prefix_states'] == 848 and smokes['old_views'] == 424 and smokes['mutations'] == 800768

result = {'complete': True, 'dependency_tests': [58, 58, 276], 'reviewed_callers': callers,
          'theorems': 18, 'rejected_controls': 8, 'release_smokes': 8, 'prefix_states': 848,
          'old_views': 424, 'mutations_after_prefix_checks': 800768, 'independent_final_digests': digests,
          'codegen_callback_references': [21, 0], 'performance_result': False, 'production_promotion': False}
(S / 'independent-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
