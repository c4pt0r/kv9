#!/usr/bin/env python3
"""Check release semantics only; these one-pass spans are not a timing comparison."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

S = Path(__file__).resolve().parent
CORPUS = Path('/mnt/data/kv9-work/resident-selected-profile-20260916-first')
build = json.loads((S / 'codegen-build-summary.json').read_text())
assert build['complete']
result = {'complete': False, 'started_ns': time.time_ns(), 'cases': [], 'performance_acceptance': False}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
try:
    for arm in ('baseline', 'candidate'):
        elf = S / ('build-codegen-' + arm) / 'resident-selected-profile'
        assert sha(elf) == next(c['binary']['sha256'] for c in build['cases'] if c['arm'] == arm)
        for workload in ('overwrite', 'unique_insert'):
            for mode in ('unpinned', 'pinned'):
                output = S / ('smoke-' + arm + '-' + workload + '-' + mode)
                output.mkdir(exist_ok=False)
                (output / 'go').touch()
                command = ['taskset', '-c', '4', str(elf), str(CORPUS), str(output), workload, mode, '1']
                with (output / 'stdout').open('x') as out, (output / 'stderr').open('x') as err:
                    p = subprocess.run(command, stdout=out, stderr=err, timeout=60)
                row = {'arm': arm, 'workload': workload, 'mode': mode, 'argv': command, 'exit_code': p.returncode}
                result['cases'].append(row)
                assert p.returncode == 0
                ready = json.loads((output / 'ready.json').read_text())
                done = json.loads((output / 'result.json').read_text())
                assert done['complete'] and done['passes'] == 1 and done['mutations'] == 100096
                assert ready['prefix_states_checked'] == 106 and ready['old_views_checked'] == (106 if mode == 'pinned' else 0)
                assert ready['final_state_sha256'] == done['final_state_sha256'] and ready['final_keys'] == done['final_keys']
                assert len(done['spans']) == 106 and all(p == 0 and g == i and a < b for i, (p, g, a, b) in enumerate(done['spans']))
                row.update(complete=True, final_sha256=done['final_state_sha256'], final_keys=done['final_keys'],
                           prefix_states=ready['prefix_states_checked'], old_views=ready['old_views_checked'])
                print(json.dumps(row), flush=True)
    for workload in ('overwrite', 'unique_insert'):
        cases = [c for c in result['cases'] if c['workload'] == workload]
        assert len(cases) == 4 and len({c['final_sha256'] for c in cases}) == 1
    result.update(complete=True, prefix_states=sum(c['prefix_states'] for c in result['cases']),
                  old_views=sum(c['old_views'] for c in result['cases']), mutations=8 * 100096)
except BaseException as error:
    result['failure'] = repr(error)
    raise
finally:
    result['ended_ns'] = time.time_ns()
    (S / 'release-smokes-summary.json').write_text(json.dumps(result, indent=2) + '\n')
