#![allow(clippy::cast_possible_wrap)]

use criterion::{Criterion, criterion_group, criterion_main};
use rpds::HashTrieMap;
use std::hint::black_box;

fn rpds_hash_trie_map_insert(c: &mut Criterion) {
    let limit = 100_000;

    c.bench_function("rpds hash trie map insert", move |b| {
        b.iter(|| {
            let mut map = HashTrieMap::new();

            for i in 0..limit {
                map = map.insert(i, -(i as isize));
            }

            map
        });
    });
}

fn rpds_hash_trie_map_insert_mut(c: &mut Criterion) {
    let limit = 50_000;

    c.bench_function("rpds hash trie map insert mut", move |b| {
        b.iter(|| {
            let mut map = HashTrieMap::new();

            for i in 0..limit {
                map.insert_mut(i, -(i as isize));
            }

            map
        });
    });
}

fn rpds_hash_trie_map_remove(c: &mut Criterion) {
    let limit = 50_000;

    c.bench_function("rpds hash trie map remove", move |b| {
        b.iter_with_setup(
            || {
                let mut map = HashTrieMap::new();

                for i in 0..limit {
                    map.insert_mut(i, -(i as isize));
                }

                map
            },
            |mut map| {
                for i in 0..limit {
                    map = map.remove(&i);
                }

                map
            },
        );
    });
}

fn rpds_hash_trie_map_remove_mut(c: &mut Criterion) {
    let limit = 100_000;

    c.bench_function("rpds hash trie map remove mut", move |b| {
        b.iter_with_setup(
            || {
                let mut map = HashTrieMap::new();

                for i in 0..limit {
                    map.insert_mut(i, -(i as isize));
                }

                map
            },
            |mut map| {
                for i in 0..limit {
                    map.remove_mut(&i);
                }

                map
            },
        );
    });
}

fn rpds_hash_trie_map_get(c: &mut Criterion) {
    let limit = 100_000;
    let mut map = HashTrieMap::new();

    for i in 0..limit {
        map.insert_mut(i, -(i as isize));
    }

    c.bench_function("rpds hash trie map get", move |b| {
        b.iter(|| {
            for i in 0..limit {
                black_box(map.get(&i));
            }
        });
    });
}

fn rpds_hash_trie_map_iterate_impl(c: &mut Criterion, limit: usize, bench_name: &str) {
    let mut map = HashTrieMap::new();

    for i in 0..limit {
        map.insert_mut(i, -(i as isize));
    }

    c.bench_function(bench_name, move |b| {
        b.iter(|| {
            for kv in map.iter() {
                black_box(kv);
            }
        });
    });
}

fn rdps_hash_trie_map_iterate_big(c: &mut Criterion) {
    rpds_hash_trie_map_iterate_impl(c, 100_000, "rpds hash trie map iterate big");
}

fn rpds_hash_trie_map_iterate_small(c: &mut Criterion) {
    rpds_hash_trie_map_iterate_impl(c, 10, "rpds hash trie map iterate small");
}

criterion_group!(
    benches,
    rpds_hash_trie_map_insert,
    rpds_hash_trie_map_insert_mut,
    rpds_hash_trie_map_remove,
    rpds_hash_trie_map_remove_mut,
    rpds_hash_trie_map_get,
    rdps_hash_trie_map_iterate_big,
    rpds_hash_trie_map_iterate_small
);
criterion_main!(benches);
