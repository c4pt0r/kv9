#!/usr/bin/env python3
"""Finite statistics from the accepted 24-cohort bounded-owner-poll screen."""
if not __debug__:
    raise SystemExit('Python assertions must be enabled')
import argparse
import hashlib
import json
from pathlib import Path
from core import aggregate, add_maps, compare, merge_histograms, phase_accounting, qtext

HERE=Path(__file__).parent
AUDIT=Path('/tmp/kv9-owner-poll-fixture-preparation-first/results-first')
parser=argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
parser.add_argument('--timing-receipt',type=Path,required=True)
parser.add_argument('--audit-receipt',type=Path,required=True)
parser.add_argument('--root-session',type=int,required=True)
args=parser.parse_args()
inputs={}
def read(path):
    raw=path.read_bytes()
    inputs[str(path)]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    return json.loads(raw)
def save(name, value):
    with (HERE/name).open('x') as f:
        json.dump(value,f,indent=2);f.write('\n')

gate=read(args.audit_receipt)
timing=read(args.timing_receipt)
assert gate['complete'] and timing['complete'] and gate['exit_code']==timing['exit_code']==0
assert gate['argv'][gate['argv'].index('--root-session')+1]==str(args.root_session)
assert timing['ended_ns']<=gate['started_ns']
audit=read(AUDIT/'audit.json');inventory=read(AUDIT/'input-inventory.json')
assert audit['complete'] and audit['matched_diagnostic_accepted']
assert audit['parent_confirmed_session']==args.root_session and audit['parent_confirmed_exit_code']==0
assert audit['protocol_id']=='kv9-bounded-owner-poll-point-read-mixed-c1-c64-v1'
assert len(audit['cases'])==24 and audit['successful_arms']==24
reports={};cases=[]
for case in audit['cases']:
    path=Path(case['directory'])/'run/report.json';report=read(path)
    assert inputs[str(path)]==inventory[str(path)]
    assert inputs[str(path)]['sha256']==case['report_sha256']
    coverage=Path(case['directory'])/'resource-coverage.json'
    report['_accepted_cpu']=read(coverage)['cpu'];assert inputs[str(coverage)]==inventory[str(coverage)]
    for i,operation in enumerate(report['metrics']['measurement']['statistics']):
        assert merge_histograms(p['whole_call']['raw'] for p in operation['populations'])==case['operations'][i]['whole_call_latency']
    assert merge_histograms(p['whole_call']['raw'] for o in report['metrics']['measurement']['statistics'] for p in o['populations'])==case['whole_call_latency']
    reports[case['ordinal']]=report
    row={k:case[k] for k in ['ordinal','repeat','concurrency','arm','workload','read_api','write_api','batch_size','read_percent','directory','report_sha256','all_success_single_attempt']}
    row['role']=case['arm'].split('-',1)[0]
    row.update(aggregate([case],[report]))
    row['phases']={name:phase_accounting(metric,row['role']!='redis') for name,metric in report['metrics'].items()}
    row['connection_attempts']=case['connection_attempts'];row['connection_failures']=case['connection_failures']
    row['terminal_rpc_codes']=case['terminal_rpc_codes']
    cases.append(row)

pooled=[];pairs=[];pooled_pairs=[]
def comparisons(selected):
    result={}
    for baseline in ['old','redis']:
        reference,candidate=selected[baseline],selected['new']
        result[baseline]=dict(combined=compare(reference,candidate),
            candidate_qps_divided_by_reference=candidate['completed_calls_per_second']/reference['completed_calls_per_second'],
            operations=[dict(api_class='read' if i==0 else 'write',
                             reference_api=reference['operations'][i]['operation'],
                             candidate_api=candidate['operations'][i]['operation'],
                             comparison=compare(reference['operations'][i],candidate['operations'][i])) for i in (0,1)])
    return result
for c in [1,64]:
    for w in ['point-r050','point-r100']:
        for role in ['old','new','redis']:
            selected=[row for row in cases if (row['concurrency'],row['workload'],row['role'])==(c,w,role)]
            assert len(selected)==2 and {r['repeat'] for r in selected}=={0,1}
            indices=[r['ordinal'] for r in selected]
            row={k:selected[0][k] for k in ['concurrency','workload','role','read_api','write_api','batch_size','read_percent']}
            row.update(aggregate([audit['cases'][i] for i in indices],[reports[i] for i in indices]))
            row['source_ordinals']=indices;pooled.append(row)
        for repeat in [0,1]:
            selected={r['role']:r for r in cases if (r['concurrency'],r['workload'],r['repeat'])==(c,w,repeat)}
            assert set(selected)=={'old','new','redis'}
            pairs.append(dict(concurrency=c,workload=w,repeat=repeat,candidate_vs=comparisons(selected)))
        selected={r['role']:r for r in pooled if (r['concurrency'],r['workload'])==(c,w)}
        pooled_pairs.append(dict(concurrency=c,workload=w,candidate_vs=comparisons(selected)))

totals={k:sum(row[k] for row in cases) for k in ['calls','input_items','issued','attempts','dropped_slots']}
for key in ['outcomes','reasons','attempt_reasons']:
    totals[key]=add_maps(row[key] for row in cases)
totals['connection_attempts']=sum(r['connection_attempts'] or 0 for r in cases)
totals['connection_failures']=sum(r['connection_failures'] or 0 for r in cases)
totals['terminal_rpc_codes']=[sum((r['terminal_rpc_codes'] or [0]*17)[i] for r in cases) for i in range(17)]
phase_totals={}
for phase in ['initialization','warmup','measurement','verification']:
    selected=[row['phases'][phase] for row in cases]
    phase_totals[phase]={key:sum(r[key] for r in selected) for key in ['calls','input_items','attempts','extra_attempts']}
    for key in ['outcomes','reasons','attempt_reasons']:
        phase_totals[phase][key]=add_maps(r[key] for r in selected)
checks={k:audit[k] for k in ['successful_arms','owned_lifetimes_exited','role_source_file_checks','resource_samples','qualifying_drains','voter_writer_listener_bindings','retained_files','retained_bytes','outer_restoration']}
result=dict(complete=True,protocol_id=audit['protocol_id'],cases=cases,pooled=pooled,pairs=pairs,pooled_pairs=pooled_pairs,
    totals=totals,phase_totals=phase_totals,checks=checks,performance_promotion=False,
    scope='24 point-read/mixed c1/c64 diagnostic cohorts; two 10-second forward/reverse repetitions. Not full72, significance, equal durability or sustained capacity.',
    original_audit_scope=audit['scope'],scope_wording_note='The derivative auditor and this summary cover only point read50/read100. Original accepted audit bytes are retained unchanged.',
    method='Pooled QPS = summed calls / summed complete cohort elapsed seconds; pooled mean = summed whole-call nanoseconds / count. p50/p95/p99 merge original histogram buckets and use ceil(count*percent/100). Mixed read and write each use their own histogram population and the full cohort duration as rate denominator. No percentile averages.',
    source_revisions={'control-11113':'11113f68f6a5df77da1ffb4fcec850953716ffa3','bounded-owner-poll':'2ca5fccb157b26b6c3c79eb52f7c7838f10a5c8c','native_redis_clients':'0be806d9671e2c50701a64aa7889c8859b7648ba'},
    parent_terminal_receipts={'timing':{'path':str(args.timing_receipt),'record':timing},'audit':{'path':str(args.audit_receipt),'record':gate}})
save('summary.json',result)
save('input-hashes.json',dict(inputs=inputs,arithmetic_core_sha256=hashlib.sha256((HERE/'core.py').read_bytes()).hexdigest(),reader_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))

def table(rows,operations=False,repeat=False):
    lines=['| c | Mix | Role | '+('Repeat | ' if repeat else '')+('API | ' if operations else '')+'QPS | Mean µs | p50 µs | p95 µs | p99 µs |',
           '|---:|---|---|'+('---:|' if repeat else '')+('---|' if operations else '')+'---:|---:|---|---|---|']
    for r in rows:
        if operations and r['read_percent']!=50:continue
        for item in r['operations'] if operations else [r]:
            h=item['whole_call_latency']
            cells=[str(r['concurrency']),'50%' if r['read_percent']==50 else '100%',{'old':'Control11113','new':'bounded-owner-poll','redis':'Redis'}[r['role']]]
            if repeat:cells.append(str(r['repeat']))
            if operations:cells.append(item['operation'])
            cells += [f"{item['completed_calls_per_second']:.3f}",f"{h['mean_ns']/1000:.3f}",qtext(h,50),qtext(h,95),qtext(h,99)]
            lines.append('| '+' | '.join(cells)+' |')
    return lines
lines=['# Bounded owner poll point-read/mixed screen','',result['scope'],'',
       'Both repeats are retained. Control11113 means the selected uninstrumented ThinLTO server; bounded-owner-poll is the separately bound fixed-budget candidate. Redis uses actual GET/SET with the same v3 dataset/configuration. KV9 retains quorum/sync calls on tmpfs WAL; Redis is standalone memory. The workloads do not have equal durability.','',
       'All quantiles below are merged raw histogram bucket intervals. Mixed combined means/quantiles weight actual read/write counts; the separate-operation table pools GET and PUT/SET independently. Operation QPS uses complete cohort elapsed time, not only time spent in that operation.','',
       '## Pooled over both repetitions','',*table(pooled),'',
       '## Mixed operations, separately pooled','',*table(pooled,operations=True),'',
       '## Candidate changes versus Control11113 and Redis','',
       '| c | Mix | QPS vs Control11113 | Mean vs Control11113 | QPS vs Redis | Mean vs Redis |','|---:|---|---:|---:|---:|---:|']
for r in pooled_pairs:
    old=r['candidate_vs']['old']['combined'];redis=r['candidate_vs']['redis']['combined']
    lines.append(f"| {r['concurrency']} | {r['workload']} | {old['completed_qps_change_percent']:+.3f}% | {old['mean_change_percent']:+.3f}% | {redis['completed_qps_change_percent']:+.3f}% | {redis['mean_change_percent']:+.3f}% |")
lines += ['',f"Measured totals: **{totals['calls']:,} calls / {totals['issued']:,} issued / {totals['attempts']:,} attempts**; success={totals['outcomes'].get('success',0):,}, dropped slots={totals['dropped_slots']:,}. Every outcome population is retained in summary.json. Full phase accounting also retains initialization routing attempts rather than applying measurement-only single-attempt claims to setup.",'',
          'Per-repeat combined and mixed-operation rows are in PER-REPEAT.md and summary.json. Pooled and per-repeat candidate-vs-Control11113/Redis comparisons also preserve both p95/p99 intervals and per-operation deltas. No percentile is averaged.','',
          f"The accepted audit records {checks['owned_lifetimes_exited']} exited lifetimes, {checks['qualifying_drains']} qualifying drains, {checks['voter_writer_listener_bindings']} voter writer/listener bindings, {checks['resource_samples']} resource samples, and {checks['retained_files']} retained files / {checks['retained_bytes']:,} bytes. Exact configured/effective CPU restoration and namespace preservation passed for all three owned containers. These original acceptance checks were not rerun.",'',
          result['scope_wording_note'],'',
          'The arithmetic core is copied byte-identically from the accepted v3/de37 statistics preparation; the bounded reader binds all 24 raw reports and their retained resource coverage to the accepted input inventory, and checks each original combined/per-operation histogram against the accepted audit before pooling. No runtime, build, test or profiling campaign is part of this derivation. Native SDK attempt-reason maps cover native calls only; Redis command attempts remain included in aggregate attempt counts.']
with (HERE/'README.md').open('x') as f:f.write('\n'.join(lines)+'\n')
with (HERE/'PER-REPEAT.md').open('x') as f:f.write('\n'.join(['# Every original repetition','',*table(cases,repeat=True),'','## Mixed GET and PUT/SET separately','',*table(cases,operations=True,repeat=True)])+'\n')
print(json.dumps({'totals':totals,'phase_totals':phase_totals,'pooled_pairs':pooled_pairs},indent=2))
