#!/usr/bin/env python3
"""Finite metadata and placeholder binding only; execute no fixture/checker."""
import difflib, hashlib, json, re, shutil
from pathlib import Path
P=Path(__file__).resolve().parent
R=Path('/tmp/kv9-owner-poll-root-first')
SRC=Path('/tmp/kv9-bounded-owner-poll')
def read(p):return json.loads(p.read_bytes())
def h(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
pending=read(P/'inventory.pending.json')
(P/'pending-first').mkdir();(P/'finalization-diffs').mkdir();(P/'root-bindings').mkdir()
for rel in [*pending,'inventory.pending.json']:
    dest=P/'pending-first'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(P/rel,dest)
r=read(R/'release-readback.json')
subs={'PENDING_CANDIDATE_REVISION':r['revision'],
      'PENDING_CANDIDATE_SERVER_SHA256':r['server_sha256'],
      'PENDING_CANDIDATE_MANIFEST_SHA256':r['manifest_sha256'],
      '/tmp/PENDING_BOUNDED_OWNER_POLL_BUILD':'/tmp/kv9-owner-poll-release-first'}
def sub(text):
    regex=re.compile('|'.join(map(re.escape,sorted(subs,key=len,reverse=True))))
    return regex.sub(lambda m:subs[m[0]],text)
for name in ('matched-driver.py','driver-arguments.json'):
    (P/name).write_text(sub((P/name).read_text()))
for name in ('matched-driver.py','driver-arguments.json'):
    subs[h(P/'pending-first'/name)['sha256']]=h(P/name)['sha256']
for name in ('audit.py','test_driver.py','test_audit_contract.py','protocol.json','commands.json'):
    (P/name).write_text(sub((P/name).read_text()))
protocol=read(P/'protocol.json')
protocol['preparation_status']='Actual root clean default release metadata supplied; no observer/testing features. Root helper/source-binding/recovery/storage gates and separately released runtime remain pending.'
save(P/'protocol.json',protocol)
commands=read(P/'commands.json')
for k in ('candidate_pins_observed','candidate_revision_supplied_by_root','candidate_source_and_release_bound','candidate_source_revision_bound'):
    commands[k]=True
commands.update(templates_only=False,note='Actual clean candidate and original release bound from root records; no source validator, contract, fixture, audit or statistics ran in this preparation. Root must complete all helper gates before any runtime release.')
save(P/'commands.json',commands)
inputs={n:R/n for n in ('release-readback.json','release-terminal.json','release-result.json','production-codegen-verbose.json')}
inputs['source-qualification.json']=SRC/'docs/owner-poll-source-v1/qualification.json'
for name,path in inputs.items():shutil.copyfile(path,P/'root-bindings'/name)
pins={name:dict(path=str(path),copy='root-bindings/'+name,**h(path)) for name,path in inputs.items()}
binding=read(P/'binding.pending.json')
binding.update(revision=r['revision'],build='/tmp/kv9-owner-poll-release-first',
    server_sha256=r['server_sha256'],binary_sha256=r['server_sha256'],manifest_sha256=r['manifest_sha256'],
    cache_receipt_sha256=r['cache_receipt_sha256'],source_count=r['source_count'],source_tree_sha256=r['source_tree_sha256'],
    root_readback=pins['release-readback.json'],root_release_terminal=pins['release-terminal.json'],
    source_qualification=pins['source-qualification.json'],production_codegen=pins['production-codegen-verbose.json'],
    ready=False,runtime_ready=False,root_metadata_supplied=True,source_validator_executed=False,
    budget_scope='Root qualified fixed 32-us owner polling candidate; unchanged screen contracts and runtime acceptance still required.')
save(P/'binding.source-release.json',binding)
derivation=read(P/'derivation.json')
derivation['substitutions']={k:sub(v) for k,v in derivation['substitutions'].items()}
for name,row in derivation['files'].items():
    row['derived']=h(P/name)
    (P/'diffs'/(name+'.diff')).write_text(''.join(difflib.unified_diff(
        (P/'originals'/name).read_text().splitlines(True),(P/name).read_text().splitlines(True),
        fromfile=row['original_path'],tofile=str(P/name))))
derivation['candidate_revision']=r['revision']
derivation['late_binding_scope']='Finite candidate identities and consequent pins; old pending files/diffs/inventory retained under pending-first. No runtime or validator execution.'
save(P/'derivation.json',derivation)

S=P/'statistics'
for name in ('derive.py','command.pending.json','frozen-screen-inputs.json'):
    (S/name).write_text(sub((S/name).read_text()))
frozen=read(S/'frozen-screen-inputs.json')
for name,row in frozen['files'].items():
    shutil.copyfile(P/name,S/'frozen-screen'/name)
    row.update(h(P/name),original_path=str(P/name))
frozen['scope']='Actual root source/build identities and final helper bytes. Root contracts and complete fresh timing/audit terminal receipts remain mandatory; no result or session is invented.'
save(S/'frozen-screen-inputs.json',frozen)
sd=read(S/'derivation.json')
sd['substitutions']={k:sub(v) for k,v in sd['substitutions'].items()}
sd['candidate_revision']=r['revision']
for name,row in sd['files'].items():
    row['derived']=h(S/name)
    (S/'diffs'/(name+'.diff')).write_text(''.join(difflib.unified_diff(
        (S/'originals'/name).read_text().splitlines(True),(S/name).read_text().splitlines(True),
        fromfile=str(Path(sd['parent'])/name),tofile=str(S/name))))
save(S/'derivation.json',sd)
save(S/'READINESS.json',dict(preparation_frozen=True,source_revision=r['revision'],
    core=h(S/'core.py'),reader=h(S/'derive.py'),contracts_executed=False,statistics_executed=False,
    required='Root inherited preparation contract, then complete fresh 24/24 accepted terminal audit and actual timing/audit receipts. Outputs absent.'))
(S/'PREPARATION.md').write_text('# Owner-poll statistics: exact candidate bound\n\n'
    f'Candidate `{r["revision"]}` and original root release are bound. The pending state is retained in `../pending-first/statistics/`. '
    '`core.py` remains byte-identical; `derive.py` has only declared identity/path/display substitutions. Frozen screen copies and all consequent hashes are refreshed. '
    'The unchanged finite `contract-command.json` remains unexecuted; root runs it before timing. `command.pending.json` still requires actual accepted 24-case audit/timing terminals and a real `ROOT_TERMINAL_TIMING_SESSION`. '
    'No reports, results or statistics were read or executed. Means, count/time rates, merged raw histogram quantile intervals, per-repeat mixed GET/PUT outcomes and sample-duration-weighted process CPU remain unchanged. CPU is not exclusive request-service or measurement-window attribution.\n')
(P/'README.md').write_text('# Bounded owner polling: bound screen preparation\n\n'
    f'Clean candidate `{r["revision"]}` at `/tmp/kv9-bounded-owner-poll` uses original `/tmp/kv9-owner-poll-release-first`. '
    'Root build 86339/0 (78beb1) and independent readback 761fa1/0 supply 716 source files, 11 rebuilt first units and 20 default artifact observations. '
    'Original root receipts and source qualification are copied verbatim under `root-bindings/`; both recorded first source failures remain in qualification. Only five documentation files changed after checks, as recorded by root; no source validator was repeated here. '
    'Actual ThinLTO/codegen1/opt3/unwind remains bound and optional observers/testing features are absent. Control is selected 11113 with its original verbose release; fixed v3 native/Redis clients remain unchanged.\n\n'
    'The exact accepted contract is unchanged: four c1/c64 point read50/read100 cells, old/new/Redis, 24 timed cohorts of 10 seconds in full forward/reverse orders and 12 smoke cohorts of 2 seconds. The primary cells remain c1 GET, c64 GET and c64 mixed; c1 mixed is retained. '
    'All 4,096-key-plus-sentinel/128B/seed71/warmup128/max10M/closed-loop/6-attempt/1,500ms settings, per-operation outcomes and whole-call histograms, deterministic mutable readback, three-voter drains, executable/PID/start/boot/listener identities, CPU isolation/restoration and complete original retention remain unchanged. '
    'No storage floor changes: tmpfs/retention 32/96 GiB preflight and 16/64 GiB runtime, plus original endpoint checks.\n\n'
    '`commands.json` contains concrete root 7+17 contract, smoke, timing and terminal-audit argv. `statistics/contract-command.json` and `statistics/command.pending.json` retain the inherited finite preparation check and terminal-gated reader. '
    'Only the actual future timing session replaces `ROOT_TERMINAL_TIMING_SESSION`. Runtime roots are `/tmp/kv9-owner-poll-screen-{smoke,timing}-first`; proposed root stage receipts are `/tmp/kv9-owner-poll-root-first/{timing-first,audit-first}/result.json`. '
    'No tests, finalizer, source validator, fixture, auditor, stats, Cargo or runtime ran here. Root must run helper gates, ordinary recovery, current storage/isolation checks and smoke before separately releasing timing.\n\n'
    'Whole-call and per-operation rates use summed counts/complete elapsed time; means use integer sums/counts; p99 merges original raw histogram buckets and reports intervals, never average percentiles. All individual repeats, outcomes/attempts/drops and client phases remain. '
    'CPU is derived from accepted source-bound process resource intervals and pooled by sample_seconds; sequential sampling, omitted edges and all process work prevent exclusive measurement-window or per-request service attribution. The host is shared. Redis RAM writes and three-voter tmpfs WAL/sync writes do not have equal durability. No performance or promotion conclusion is implied.\n\n'
    'The original pending inventory is unchanged and all pending versions/diffs are preserved under `pending-first/`. `finalization.json` and `finalization-diffs/` record finite late binding. `inventory.final.json` is a flat relative-path bytes/SHA map excluding itself; nested statistics has its own final inventory. '
    'The complete original pending reuse/scope explanation remains in `pending-first/README.md`, with dependency pins in `retained-helper-reuse.json`.\n')
old=read(P/'pending-first/READINESS.json')
old.update(pending_preparation_complete=False,preparation_complete=True,candidate_revision=r['revision'],
    candidate_build='/tmp/kv9-owner-poll-release-first',source_count=r['source_count'],root_release_metadata_supplied=True,
    remaining=['Root 7+17 and inherited statistics contracts plus current exact source/build-role validation',
        'Root ordinary recovery and actual storage/isolation/capacity release',
        'Root smoke, timing, independent accepted terminal audit and statistics with actual receipts only'])
old['hashes']={name:h(P/name) for name in old['hashes']}
save(P/'READINESS.json',old)
for rel in pending:
    f=P/rel
    if f.is_file() and f.suffix in ('.py','.json','.md') and f.read_bytes()!=(P/'pending-first'/rel).read_bytes():
        dest=P/'finalization-diffs'/(rel+'.diff');dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(''.join(difflib.unified_diff((P/'pending-first'/rel).read_text().splitlines(True),f.read_text().splitlines(True),fromfile='pending-first/'+rel,tofile=rel)))
save(P/'finalization.json',dict(candidate_revision=r['revision'],root_records=pins,substitutions=subs,
    pending_inventory=dict(path=str(P/'inventory.pending.json'),**h(P/'inventory.pending.json')),
    core_byte_identical_to_pending=True,default_production_features=True,
    workload_and_all_predicates_unchanged=True,contracts_executed=False,source_validation_executed=False,
    runtime_executed=False,statistics_executed=False))
print(json.dumps(dict(complete_metadata_binding=True,driver=h(P/'matched-driver.py'),auditor=h(P/'audit.py'),
    protocol=h(P/'protocol.json'),arguments=h(P/'driver-arguments.json'),commands=h(P/'commands.json'),
    statistics_reader=h(S/'derive.py'),core=h(S/'core.py')),indent=2))
