#!/usr/bin/env python3
"""Finite byte/substitution contract only; never reads runtime reports or imports derive."""
import ast
import hashlib
import json
from pathlib import Path
import re

if not __debug__:
    raise SystemExit('assertions required')
p = Path(__file__).resolve().parent

def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

derivation = json.loads((p / 'derivation.json').read_text())
subs = derivation['substitutions']
pattern = re.compile('|'.join(re.escape(k) for k in sorted(subs, key=len, reverse=True)))
for name, expected in derivation['files'].items():
    original = p / 'originals' / name
    actual = p / name
    assert identity(original) == expected['original'], 'retained original changed: ' + name
    assert identity(actual) == expected['derived'], 'derived reader changed: ' + name
    assert actual.read_text() == pattern.sub(lambda m: subs[m.group()], original.read_text()), 'non-substitution change: ' + name
assert (p / 'core.py').read_bytes() == (p / 'originals/core.py').read_bytes(), 'arithmetic core changed'
for name in ('derive.py', 'core.py'):
    ast.parse((p / name).read_text(), filename=name)
binding = json.loads((p / 'frozen-screen-inputs.json').read_text())
for name, row in binding['files'].items():
    expected = dict(bytes=row['bytes'], sha256=row['sha256'])
    assert identity(p / row['copy']) == expected, 'frozen copy changed: ' + name
    assert identity(Path(row['original_path'])) == expected, 'root frozen screen changed: ' + name
protocol = json.loads((p / 'frozen-screen/protocol.json').read_text())
assert protocol['protocol_id'] == binding['expected_protocol_id']
assert protocol['candidate_revision'] == binding['candidate_revision']
assert protocol['driver_sha256'] == binding['files']['matched-driver.py']['sha256']
command = json.loads((p / 'command.pending.json').read_text())
assert command['expected_run'] == binding['expected_cohort_root']
assert command['accepted_audit_path'] == binding['expected_audit_directory']
assert [command['argv'][command['argv'].index(flag)+1] for flag in ('--timing-receipt', '--audit-receipt')] == binding['root_terminal_receipts']
assert command['argv'][command['argv'].index('--root-session')+1] == 'ROOT_TERMINAL_TIMING_SESSION'
assert binding['files']['driver-arguments.json']['sha256'] in (p / 'frozen-screen/audit.py').read_text()
assert all(not (p / name).exists() for name in command['outputs']), 'statistics output already exists'
print('PASS: exact finite substitutions, unchanged arithmetic, frozen screen pins, fresh outputs')
