# Pending owner-poll statistics

`core.py` is byte-identical to the accepted ThinLTO 24-case statistics core, SHA `827110ec99b2ae82f042e40fc81844263eefe4c484680ef6d8ab54653515b17f`. `derive.py` changes only declared source identities, paths, protocol and display labels. Original sources and exact diffs are retained. No results were copied or read and no contract or derivation was executed.

After final candidate binding, root must refresh `frozen-screen/`, `frozen-screen-inputs.json`, the derivation hashes and inventories. `contract-command.json` runs the inherited small static preparation check only when root releases it. `command.pending.json` requires the actual complete timing and subsequent accepted 24-case audit receipts; only a real timing session may replace its session placeholder. The four output names remain fresh and absent.

All counts, attempts, dropped slots, outcomes, phases and both repeats remain separate before pooling. Rates use complete elapsed time, means use sums/counts, and per-operation quantiles merge original histogram buckets. CPU uses accepted source-bound coverage intervals weighted by observed sample seconds; it is not exclusive measurement-window CPU or per-request service time. See the parent README for exact scope and blockers.
