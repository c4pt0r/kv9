#!/usr/bin/env python3
"""Construct pending helper copies only; never import or execute fixture code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil

P = Path(__file__).resolve().parent
O = Path('/tmp/kv9-release-thin-lto-screen-preparation-first')
ROOT = '/tmp/kv9-owner-poll-root-first'
READBACK = Path('/tmp/kv9-thin-lto-main-integration-root-first/release-verbose-readback.json')
H = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write_json(p, value):
    p.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

control = json.loads(READBACK.read_text())
assert control['complete'] and control['revision'] == '11113f68f6a5df77da1ffb4fcec850953716ffa3'
assert control['instrumentation_enabled'] is False
substitutions = {
    str(O): str(P),
    '/tmp/kv9-release-thin-lto-screen-timing-first': '/tmp/kv9-owner-poll-screen-timing-first',
    '/tmp/kv9-release-thin-lto-screen-smoke-first': '/tmp/kv9-owner-poll-screen-smoke-first',
    '/tmp/kv9-release-thin-lto-root-first': ROOT,
    '/tmp/kv9-wal-crc32-table': '/tmp/kv9-thin-lto-main-integration-first',
    '/tmp/kv9-wal-crc32-release-first': '/tmp/kv9-thin-lto-main-integration-release-verbose-first',
    '/tmp/kv9-release-thin-lto': '/tmp/kv9-bounded-owner-poll',
    '/tmp/kv9-release-thin-lto-release-first': '/tmp/PENDING_BOUNDED_OWNER_POLL_BUILD',
    'ca0002c7f8e9ee6f595efcc9f4151085ccce87cb': control['revision'],
    'b33b5d302f901aac5cf6a95449b9bb5dd68473747e011220dbed7aed2e591d13': control['server_sha256'],
    '8c2ea115afc1ec8b6c82224dc6449d1d2439f5f27b5758e45090589752d186e8': control['manifest_sha256'],
    '02d0c01024b65a84b220c6948ff2224bfa7900bc': 'PENDING_CANDIDATE_REVISION',
    'dd028cb2f61633dda133b05d814a6d173a79a83145d8ced2f81dc0cf8e0f33bc': 'PENDING_CANDIDATE_SERVER_SHA256',
    'f336886f07cd42dd1bd37388351e1c93c41ed828d6da31c23e4e87726a2075a0': 'PENDING_CANDIDATE_MANIFEST_SHA256',
    'kv9-release-thin-lto-point-read-mixed-c1-c64-v1': 'kv9-bounded-owner-poll-point-read-mixed-c1-c64-v1',
}
def substitute(text, extra=None):
    selected = dict(substitutions, **(extra or {}))
    regex = re.compile('|'.join(map(re.escape, sorted(selected, key=len, reverse=True))))
    return regex.sub(lambda m: selected[m[0]], text)

(P/'originals').mkdir()
(P/'diffs').mkdir()
for name in ('matched-driver.py', 'driver-arguments.json', 'isolate-and-run.py'):
    shutil.copyfile(O/name, P/'originals'/name)
    (P/name).write_text(substitute((O/name).read_text()))
substitutions[H(O/'matched-driver.py')['sha256']] = H(P/'matched-driver.py')['sha256']
substitutions[H(O/'driver-arguments.json')['sha256']] = H(P/'driver-arguments.json')['sha256']
for name in ('audit.py', 'test_driver.py', 'test_audit_contract.py', 'protocol.json', 'commands.json', 'binding.pending.json'):
    shutil.copyfile(O/name, P/'originals'/name)
    (P/name).write_text(substitute((O/name).read_text()))

protocol = json.loads((P/'protocol.json').read_text())
protocol['preparation_status'] = 'Pending candidate commit/original build and root readback. Templates only; no contract, preflight or runtime execution.'
write_json(P/'protocol.json', protocol)
commands = json.loads((P/'commands.json').read_text())
for name in ('candidate_pins_observed', 'candidate_revision_supplied_by_root', 'candidate_source_and_release_bound', 'candidate_source_revision_bound'):
    commands[name] = False
commands['templates_only'] = True
commands['note'] = 'Control identity copied from its original 11113 release readback; candidate pins and all new execution results remain pending. Do not execute even pure contracts until root releases that work.'
commands['root_execution_receipt_directory_proposed'] = True
write_json(P/'commands.json', commands)
pending = json.loads((P/'binding.pending.json').read_text())
pending.update(build=None, source='/tmp/kv9-bounded-owner-poll', server_sha256=None,
               runtime_ready=False, fixed_owner_poll_budget_us=32,
               budget_scope='Root implementation hypothesis; not inspected or qualified by this preparation.')
write_json(P/'binding.pending.json', pending)
shutil.copyfile(READBACK, P/'control-release-readback.json')
write_json(P/'control-binding.json', dict(
    source='/tmp/kv9-thin-lto-main-integration-first',
    build='/tmp/kv9-thin-lto-main-integration-release-verbose-first',
    original_readback=dict(path=str(READBACK), **H(READBACK)), record=control,
    scope='Original accepted root readback copied verbatim; no current binary/source rebuild or payload hash performed by this preparer. Root revalidates all four roles before execution.'))

files = {}
function_changes = {}
for original in sorted((P/'originals').iterdir()):
    updated = P/original.name
    (P/'diffs'/(original.name+'.diff')).write_text(''.join(difflib.unified_diff(
        original.read_text().splitlines(True), updated.read_text().splitlines(True),
        fromfile=str(O/original.name), tofile=str(updated))))
    files[original.name] = dict(original_path=str(O/original.name), original=H(original), derived=H(updated))
    if original.suffix == '.py':
        def funcs(text):
            return {n.name: ast.get_source_segment(text, n) for n in ast.parse(text).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        before, after = funcs(original.read_text()), funcs(updated.read_text())
        assert before.keys() == after.keys()
        changed = [name for name in before if before[name] != after[name]]
        assert all(substitute(before[name]) == after[name] for name in changed)
        function_changes[original.name] = changed
assert (P/'isolate-and-run.py').read_bytes() == (O/'isolate-and-run.py').read_bytes()
assert protocol['timed_inventory'] == json.loads((O/'protocol.json').read_text())['timed_inventory']
assert protocol['smoke_inventory'] == json.loads((O/'protocol.json').read_text())['smoke_inventory']
assert len(protocol['timed_inventory']) == 24 and len(protocol['smoke_inventory']) == 12
assert H(P/'driver-arguments.json')['sha256'] in (P/'audit.py').read_text()
write_json(P/'derivation.json', dict(parent=str(O), substitutions=substitutions, files=files,
    changed_top_level_functions=function_changes,
    extra_metadata_only_changes=['protocol preparation_status', 'commands pending flags/note/proposed receipt directory', 'binding.pending null fields and stated hypothesis'],
    scope='Path, role identity, protocol name and resulting argument/driver hashes only in executable helpers. Wrapper byte-identical. Existing workload/native/Redis/data, lifecycle, resource, retention and audit predicates unchanged.',
    runtime_executed=False, contracts_executed=False, source_readback_executed=False))

S = P/'statistics'
S.mkdir(); (S/'originals').mkdir(); (S/'diffs').mkdir(); (S/'frozen-screen').mkdir()
T = O/'statistics'
stat_subs = dict(substitutions)
stat_subs.update({
    'CRC means the accepted byte-table server; thin-lto is the clean thin-lto candidate.': 'Control11113 means the selected uninstrumented ThinLTO server; bounded-owner-poll is the separately bound fixed-budget candidate.',
    "'crc':": "'control-11113':", 'CRC': 'Control11113',
    'ThinLTO release': 'Bounded owner poll', 'thin-lto': 'bounded-owner-poll',
})
def stat_sub(text):
    regex = re.compile('|'.join(map(re.escape, sorted(stat_subs, key=len, reverse=True))))
    return regex.sub(lambda m: stat_subs[m[0]], text)
stat_files = {}
for name in ('derive.py', 'core.py', 'command.pending.json'):
    shutil.copyfile(T/name, S/'originals'/name)
    (S/name).write_text(stat_sub((T/name).read_text()))
    (S/'diffs'/(name+'.diff')).write_text(''.join(difflib.unified_diff(
        (T/name).read_text().splitlines(True), (S/name).read_text().splitlines(True),
        fromfile=str(T/name), tofile=str(S/name))))
    stat_files[name] = dict(original=H(T/name), derived=H(S/name))
assert (S/'core.py').read_bytes() == (T/'core.py').read_bytes()
shutil.copyfile(T/'check_preparation.py', S/'check_preparation.py')
(S/'contract-command.json').write_text(stat_sub((T/'contract-command.json').read_text()))
frozen = json.loads(stat_sub((T/'frozen-screen-inputs.json').read_text()))
for name, row in frozen['files'].items():
    shutil.copyfile(P/name, S/'frozen-screen'/name)
    row.update(H(P/name), original_path=str(P/name))
frozen['scope'] = 'Pending candidate template bytes only. Root must supply source/build pins and refreeze after exact role checks; actual timing/audit terminals and fresh 24-case acceptance remain mandatory.'
write_json(S/'frozen-screen-inputs.json', frozen)
write_json(S/'derivation.json', dict(parent=str(T), substitutions=stat_subs, files=stat_files,
    arithmetic_core_byte_identical=True, candidate_label='bounded-owner-poll',
    candidate_revision=None, statistics_executed=False, contracts_executed=False))
write_json(S/'READINESS.json', dict(pending_template_frozen=True, runtime_ready=False,
    core=H(S/'core.py'), reader=H(S/'derive.py'),
    required='Final candidate pins and refreshed screen-input copies/hashes; then root contracts, complete 24/24 terminal audit and real timing/audit receipts. No outputs exist.'))

# Direct fixture/validator/resource imports are retained small source inputs,
# never executable binaries or result payloads. Runtime keeps its full dynamic
# verified source closure; this explicit map is a reuse aid, not a substitute.
deps = [Path('/tmp/kv9-point-write-measurement-v3/scripts')/name for name in (
    'benchmark.py', 'batch_benchmark_report.py', 'redis_batch_report.py',
    'native-batch-e2e.py', 'tmpfs-redis-diagnostic.py', 'redis-comparison.py', 'workload_report.py')]
deps += [Path('/tmp/kv9-redis-batch-reference-preparation/run_fixture.py'),
         Path('/tmp/kv9-work-signal-comparison-preparation/matched-driver.py')]
write_json(P/'retained-helper-reuse.json', dict(
    accepted_screen=str(O), direct_external_sources=[dict(path=str(p), **H(p)) for p in deps],
    dynamic_source_closure='Driver imports remain within fixed 0be source inventory; existing runtime and independent auditor bind all actual imported source paths. This map does not replace those checks.',
    statistics_core=dict(path=str(T/'core.py'), **H(T/'core.py')),
    sample_scope='Resource sample envelopes are selected within the client measurement interval; each CPU denominator is the first-to-last matching process monotonic observation span. Sequential observation skew, omitted edges, background work within the process and a shared host prevent exclusive measurement-window/request-service/causal CPU attribution. Pooled CPU weights each retained estimate by sample_seconds.',
    quantities='Whole-call and per-operation counts/time rates; integer sum/count means; raw merged p99 bucket intervals; both individual repeats, all outcomes/attempts/drops and phase accounting. Original resource coverage keeps process CPU/RSS even where pooled core reports CPU only.'))
print(json.dumps(dict(prepared=True, contracts_executed=False, runtime_executed=False,
    candidate_bound=False, changed_functions=function_changes, driver=H(P/'matched-driver.py'),
    auditor=H(P/'audit.py'), statistics_core=H(S/'core.py')), indent=2))
