"""Publish accepted screen reports; retain all original local fixture trees."""
from pathlib import Path
import hashlib,json,shutil,tarfile

ROOT=Path('/tmp/kv9-owner-poll-root-first')
PREP=Path('/tmp/kv9-owner-poll-fixture-preparation-first')
MAIN=Path('/home/dongxu/kv9')
OUT=MAIN/'docs/owner-poll-screen-v1'
SKIP={'host-resource-samples.json','sample-calls.json','before-metrics.json','after-metrics.json','final-dataset.json'}
def read(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')

for label in ['smoke-first','timing-first','audit-first','statistics-first']:
    assert read(ROOT/label/'result.json')['complete'],label
summary=read(PREP/'statistics/summary.json')
assert summary['complete'] and summary['checks']['successful_arms']==24
assert summary['performance_promotion'] is False
assert summary['totals']['calls']==summary['totals']['issued']==summary['totals']['attempts']==49184881
assert summary['totals']['dropped_slots']==0
for pair in summary['pairs']:
    comparison=pair['candidate_vs']['old']['combined']
    assert comparison['successful_qps_change_percent']<0 and comparison['mean_change_percent']>0
    assert comparison['new_p99']['lower_ns']>comparison['old_p99']['upper_ns']
for row in summary['pooled']:
    if row['role']=='new':
        old=next(x for x in summary['pooled'] if x['role']=='old' and x['concurrency']==row['concurrency'] and x['read_percent']==row['read_percent'])
        assert row['server_cpu_cores']>old['server_cpu_cores']

OUT.mkdir()
for name in ['summary.json','input-hashes.json','README.md','PER-REPEAT.md']:
    shutil.copyfile(PREP/'statistics'/name,OUT/name)
shutil.copyfile(PREP/'results-first/input-inventory.json',OUT/'accepted-input-inventory.json')
cpu=[{key:row[key] for key in ['concurrency','read_percent','role','server_cpu_cores','client_cpu_cores','cpu']} for row in summary['pooled']]
save(OUT/'cpu.json',dict(rows=cpu,scope='Process CPU estimates use each retained observation interval and are weighted by sample seconds. All process work within those intervals is included; this is not exclusive request service time.'))
inputs={};omitted=[]
for label,directory in [('smoke',Path('/tmp/kv9-owner-poll-screen-smoke-first')),
                        ('timing',Path('/tmp/kv9-owner-poll-screen-timing-first'))]:
    for p in sorted(directory.rglob('*')):
        assert not p.is_symlink(),str(p)
        if not p.is_file():continue
        rel=str(p.relative_to(directory))
        if '/fixture/data/' in '/'+rel or p.name in SKIP or (p.name.startswith('readback-') and p.suffix=='.txt'):
            omitted.append(dict(original_path=str(p),bytes=p.stat().st_size))
        else:inputs[label+'/'+rel]=p
for p in sorted(PREP.rglob('*')):
    assert not p.is_symlink(),str(p)
    if p.is_file():inputs['preparation-and-results/'+str(p.relative_to(PREP))]=p
for label in ['screen-driver-contracts-first','screen-role-contract-first','screen-auditor-contracts-first',
              'screen-statistics-contract-first','smoke-first','timing-first','audit-first','statistics-first']:
    for p in sorted((ROOT/label).rglob('*')):
        if p.is_file():inputs['root/'+label+'/'+str(p.relative_to(ROOT/label))]=p
for name in ['run-stage.py','publish-screen.py']:
    inputs['root/'+name]=ROOT/name
rows=[dict(path=name,original_path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(inputs.items())]
assert len(rows)<4000 and sum(x['bytes'] for x in rows)<256*1024**2
archive=OUT/'original-evidence.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=9) as tar:
    for row in rows:tar.add(row['original_path'],arcname=row['path'],recursive=False)
assert archive.stat().st_size<32*1024**2
assert sum(p.stat().st_size for p in (MAIN/'docs').rglob('original-evidence.tar.gz'))<=64*1024**2
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(rows)
    for member,row in zip(members,rows):
        assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']==sha(Path(row['original_path']))
save(OUT/'archive-inventory.json',dict(files=rows,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
    original_bytes=sum(x['bytes'] for x in rows),scope='Original reports/configuration, raw process resource samples/coverage, source/execution/cleanup records, accepted audit and complete statistics. High-volume host/call/dataset diagnostics and database files remain at their original local paths; no local fixture is changed or removed.',
    excluded_names=sorted(SKIP),excluded_patterns=['*/fixture/data/*','readback-*.txt'],
    locally_retained_omitted_files=omitted,omitted_bytes=sum(x['bytes'] for x in omitted),
    omitted_inventory_scope='Local path/size enumeration only; authoritative accepted timed data hashes remain in accepted-input-inventory.json. No new acceptance audit is claimed.'))
save(OUT/'decision.json',dict(candidate='2ca5fccb157b26b6c3c79eb52f7c7838f10a5c8c',decision='rejected',
    reason='All eight matched workload/repetition comparisons regress throughput, mean and p99; every pooled workload uses more server CPU.',
    selected_runtime='11113f68f6a5df77da1ffb4fcec850953716ffa3',cohorts_rerun=False,poll_budget_retuned=False,
    timing_terminal=dict(session=53149,receipt='7d34ec',exit_code=0),
    audit_terminal=dict(session=39270,receipt='acb34b',exit_code=0),statistics_terminal=dict(receipt='e4c8df',exit_code=0),
    actual_chaos_on_rejected_candidate=False))
print(json.dumps(dict(files=len(rows),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),locally_retained_omitted_bytes=sum(x['bytes'] for x in omitted),decision='rejected')))
