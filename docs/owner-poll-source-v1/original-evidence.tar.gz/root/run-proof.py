from pathlib import Path
import hashlib,json,os,signal,subprocess,time
root=Path('/tmp/kv9-owner-poll-root-first');source=Path('/tmp/kv9-bounded-owner-poll');out=root/'proof-first';out.mkdir()
cmd=['taskset','-c','6-15,22-31','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','python3','-B',str(source/'scripts/check-owner-poll.py'),'--jar','/tmp/kv9-p0-tools/tla2tools-v1.7.4.jar','--tlapm','/tmp/kv9-p0-tools/tlapm-1.6.0-pre-20260731/bin/tlapm','--output','/tmp/kv9-owner-poll-proof-first']
sources=[source/'scripts/check-owner-poll.py',source/'scripts/check-tlaps.py',source/'scripts/check-tla.py',source/'scripts/ProofAudit.java',*sorted((source/'proofs/tla/owner_poll').iterdir()),*sorted((source/'proofs/tlaps/owner_poll').iterdir())]
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources if p.is_file()}
r={'complete':False,'argv':cmd,'started_ns':time.time_ns(),'sources':pins};child=None
try:
 with (out/'output.log').open('x') as log:
  child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=child.pid;(out/'invocation.json').write_text(json.dumps(r,indent=2)+'\n');r['exit_code']=child.wait(timeout=900)
 assert r['exit_code']==0,'Retain original qualification failure'
 assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in pins.items()),'Proof source changed during qualification'
 r['complete']=True
except BaseException as e:
 r['failure']=repr(e)
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 raise
finally:r['ended_ns']=time.time_ns();(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS: owner-poll proof/model/control qualification terminal')
