"""Retain the original proof/source attempts after explicit terminal readback."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shutil
import tarfile

ROOT = Path('/tmp/kv9-owner-poll-root-first')
SOURCE = Path('/tmp/kv9-bounded-owner-poll')
DEFAULT = Path('/tmp/kv9-owner-poll-source-after-inventory-fix-first')
STAGE = Path('/tmp/kv9-owner-poll-read-stage-corrected-first')
PROOF = Path('/tmp/kv9-owner-poll-proof-first')
OUT = SOURCE / 'docs/owner-poll-source-v1'


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def counts(path):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', path.read_text())
    if not rows or any(int(row[1]) for row in rows):
        raise RuntimeError('missing successful test results')
    return dict(passed=sum(int(row[0]) for row in rows), ignored=sum(int(row[2]) for row in rows), suites=len(rows))


def main():
    assert read(ROOT / 'proof-first/result.json')['complete']
    assert read(ROOT / 'read-stage-corrected-result.json')['complete']
    assert read(ROOT / 'read-stage-terminal.json')['exit_code'] == 0
    default = read(DEFAULT / 'result.json')
    assert default['complete'] is False
    assert [row['name'] for row in default['commands']] == [
        'format', 'default-compile', 'owner-poll-focused-tests', 'default-tests',
        'default-clippy', 'read-stage-compile']
    assert all(row['exit_code'] == 0 for row in default['commands'][:-1])
    assert (DEFAULT / 'read-stage-compile.stderr').read_text() == (
        'error: none of the selected packages contains this feature: kv9-server/read-stage-timing\n'
        'selected packages: kv9-raft, kv9-server\n')
    stage = read(STAGE / 'result.json')
    assert stage['complete'] and all(row['exit_code'] == 0 for row in stage['commands'])
    before = read(DEFAULT / 'sources-before.json')
    assert before == read(STAGE / 'sources-before.json') == read(STAGE / 'sources-after.json')
    spec = importlib.util.spec_from_file_location('snapshot_builder', SOURCE / 'scripts/build-workload.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    assert before == builder.snapshot()
    proof = read(PROOF / 'summary.json')
    assert proof['complete'] and proof['new_theorems'] == 14 and proof['new_obligations'] == 49
    for path, digest in read(ROOT / 'proof-first/result.json')['sources'].items():
        assert sha(Path(path)) == digest
    result = dict(complete=True, source_base_revision=before['revision'],
                  checked_draft_identity=before, default=counts(DEFAULT / 'default-tests.stdout'),
                  focused=counts(DEFAULT / 'owner-poll-focused-tests.stdout'),
                  read_stage=counts(STAGE / 'read-stage-tests.stdout'),
                  proof=dict(new_theorems=14, new_obligations=49, dependency_theorems=33,
                             dependency_obligations=294, summary_sha256=sha(PROOF / 'summary.json')),
                  failures=[dict(stage='initial source inventory', before_cargo=True,
                                 cause='published archives exceeded legacy source bounds', repair='2ccb478'),
                            dict(stage='initial diagnostic feature selection', before_diagnostic_compile=True,
                                 cause='feature named under kv9-server instead of kv9-raft',
                                 repair='only the three diagnostic commands repeated with the correct package')],
                  populations_overlap=True, default_checks_repeated=False,
                  runtime_performance_recovery_or_chaos_accepted=False)
    assert result['default']['passed'] == 714 and result['focused']['passed'] == 5
    OUT.mkdir()
    save(OUT / 'qualification.json', result)
    shutil.copyfile(PROOF / 'summary.json', OUT / 'proof-summary.json')
    archive_inputs = {}
    for label, directory in [('proof', PROOF), ('default-source', DEFAULT), ('read-stage-source', STAGE),
                             ('draft-first', ROOT / 'proof-draft-first'),
                             ('draft-second', ROOT / 'proof-draft-second'),
                             ('draft-third', ROOT / 'proof-draft-third'),
                             ('proof-root', ROOT / 'proof-first')]:
        for path in sorted(directory.rglob('*')):
            if path.is_symlink():
                raise RuntimeError('archive input is a symlink')
            if path.is_file():
                archive_inputs[label + '/' + str(path.relative_to(directory))] = path
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and (path.name.startswith(('source-', 'read-stage-', 'check-source', 'run-source',
                                                     'check-read-stage', 'run-read-stage', 'commands-',
                                                     'pending-feature-', 'run-proof', 'publish-source'))):
            archive_inputs['root/' + path.name] = path
    rows = [dict(path=name, original_path=str(path), bytes=path.stat().st_size, sha256=sha(path))
            for name, path in sorted(archive_inputs.items())]
    assert len(rows) < 2000 and sum(row['bytes'] for row in rows) < 32 * 1024**2
    archive = OUT / 'original-evidence.tar.gz'
    with tarfile.open(archive, 'x:gz') as stream:
        for row in rows:
            stream.add(row['original_path'], arcname=row['path'], recursive=False)
    with tarfile.open(archive, 'r:gz') as stream:
        members = stream.getmembers()
        assert len(members) == len(rows)
        for member, row in zip(members, rows):
            assert member.isfile() and member.name == row['path'] and member.size == row['bytes']
            data = stream.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest() == row['sha256'] == sha(Path(row['original_path']))
    save(OUT / 'archive-inventory.json', dict(files=rows, archive_bytes=archive.stat().st_size,
                                             archive_sha256=sha(archive), original_bytes=sum(r['bytes'] for r in rows)))
    print(json.dumps(dict(default=result['default'], focused=result['focused'], read_stage=result['read_stage'],
                          archive_files=len(rows), archive_bytes=archive.stat().st_size, archive_sha256=sha(archive))))


if __name__ == '__main__':
    main()
