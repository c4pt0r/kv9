import Preparation
#print axioms Kv9.GroupPreparation.initial_safe
#print axioms Kv9.GroupPreparation.step_preserves
#print axioms Kv9.GroupPreparation.reachable_safe
#print axioms Kv9.GroupPreparation.report_requires_durable_binding
#print axioms Kv9.GroupPreparation.ready_never_initializes
#print axioms Kv9.GroupPreparation.failed_never_initializes
#print axioms Kv9.GroupPreparation.failed_has_no_report
#print axioms Kv9.GroupPreparation.ready_is_monotone
#print axioms Kv9.GroupPreparation.restart_discards_report
