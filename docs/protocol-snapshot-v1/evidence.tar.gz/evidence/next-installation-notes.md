# Next D03 implementation boundary

Authoritative base before this checkpoint: 1feb64f. This checkpoint's protocol
snapshot primitive is deliberately not a remote installation capability.

Required next implementation: a sealed data-group snapshot/source bundle plus a
destination-bound engine/protocol installation journal. Review and retain the
existing exclusive parent/group locks and incarnation checks. Extend recovery
through a separately versioned install state; do not weaken fixed creation
validation globally or turn decoded snapshot bytes into a serving capability.

Current concrete integration gaps from source inspection:

- `RegionManager` owns per-group `DiskRaftStorage` and `WalEngine`, but its durable
  record has only IntentDurable/StorageReady/Active and exactly the original
  immutable creation replicas. Its recovered engine must match retained Raft
  history. Add a separately validated installation/membership authority rather
  than passing a snapshot through the empty-group preparation path.
- `RecoveryAnchor` v1 and `open_initial_checkpoint_engine` describe the initial
  whole metadata engine, require local retained protocol history from index 1,
  and are not a per-data-group transferable authority. A data-group bundle must
  bind root, creation digest, full DataRange, historical configuration, exact
  image cut, publication/ownership evidence and resource closure. Do not relabel
  the existing whole-engine anchor.
- `WalEngine::checkpoint_applied` assumes a local applied manifest and preserves
  its own WAL. It cannot authorize initializing an empty receiver. Recovery
  currently restores all checkpoint SSTs into MemEngine; a lightweight-attach
  claim needs an on-demand SST read path and separately measured object reads.
- The retention ledger has durable Share/Publish/QuiesceAfterTransfer, but it is
  tracking-only, with no complete legacy-reference certificate or physical GC.
  Use exact snapshot/migration owners and incarnation-bound destination evidence;
  retain source owners until destination install is durable. The current
  CheckpointOwners helper explicitly handles META_REGION_0 only.
- Existing data Raft transport admission and fixed-voter store checks bind the
  creation intent. Learner attach needs a committed migration intent, current
  exact target incarnation and recovery-compatible membership authority.
- `install_protocol_snapshot` stores one whole protocol tuple, advances its
  configuration replay boundary and preserves term/vote. Current constructors
  refuse any first_index != 1, and receive drops MsgSnapshot before RawNode.
  Replace those guards only with the coordinated installer and its proofs/tests.
  Keep the fixed-configuration experimental lease exclusion.

Installation must select engine generation and protocol base together after
both are durable. Crash recovery must select the complete old or new generation,
never image-new/protocol-old or the reverse. Preserve old source files and all
pins before the destination selection record is durable. Do not resume the old
writer after an uncertain selector publication. Check exact group/root/scope,
image digest, target store incarnation, durable election term/vote, full
ConfState and applied cut before creating any peer or serving handle.

After installation works: implement snapshot Ready coordination, retained-tail
catchup, promotion based on actual durable application/configuration evidence,
safe removal, source-log physical truncation and retirement. Test empty receiver
after truncation; copying an existing complete data directory is not attach.
Then durable manual/automatic split, coordinator takeover and placement.

User acceptance remains actual Chaos Mesh at install/migration cuts, no
indispensable database node, rigorous core proofs, and effective scaling IN
BENCHMARKS: independent 3/6/9 hosts, fixed three voters, durability and p99
budgets, resource costs and online 3-to-6-to-9 expansion. No scaling measurements
or new QPS exist yet. Local CI only; user-facing Chinese, all repo/GitHub English.
