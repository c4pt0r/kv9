import pathlib,subprocess,json,os
root=pathlib.Path('/home/dongxu/kv9');out=pathlib.Path('/mnt/data/kv9-work/protocol-snapshot-20260916/rust-controls');out.mkdir(exist_ok=False)
raw=root/'crates/raft/src/rawnode.rs';storage=root/'crates/raft/src/storage.rs';impl=root/'crates/raft/src/storage/snapshot.rs'
start='''        if g.alive && msg.get_msg_type() == raft::eraftpb::MessageType::MsgSnapshot {
            g.step_errors = g.step_errors.saturating_add(1);
            return;
        }
'''
method='''        self.snapshot
            .lock()
            .expect("snapshot poisoned")
            .as_ref()
            .filter(|snapshot| snapshot.get_metadata().index >= request_index)
            .cloned()
            .ok_or(raft::Error::Store(
                raft::StorageError::SnapshotTemporarilyUnavailable,
            ))'''
vote='        || (hs.term == old.term && old.vote != 0 && hs.vote != old.vote)\n'
controls=[('step-before-install',raw,start,'','receiver_drops_snapshot_before_rawnode_can_change_commit_or_membership','uninstalled image advanced local term'),('invent-empty-image',storage,method,'        self.mem.snapshot(request_index, _to)','snapshot_pair_survives_recovery_without_synthesizing_later_images','invented an empty image'),('forget-existing-vote',impl,vote,'','invalid_snapshot_and_vote_rollback_refuse_before_any_io','assertion failed: store.install_protocol_snapshot')]
results=[]
for label,path,before,after,test,marker in controls:
 original=path.read_bytes();source=original.decode();assert source.count(before)==1,(label,source.count(before))
 candidate=source.replace(before,after);(out/(label+'.rs')).write_text(candidate)
 command=['cargo','test','-p','kv9-raft','--lib','storage::snapshot::tests::'+test,'--','--exact','--nocapture']
 try:
  path.write_text(candidate)
  r=subprocess.run(command,cwd=root,env=dict(os.environ,KV9_TEST_DATA_DIR='/mnt/data/kv9-work/test-data'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
 finally:
  path.write_bytes(original)
 (out/(label+'.log')).write_text(r.stdout)
 assert r.returncode==101 and marker in r.stdout and 'could not compile' not in r.stdout,(label,r.stdout)
 results.append({'label':label,'command':command,'exit_code':r.returncode,'intended_failure':marker})
(out/'result.json').write_text(json.dumps({'accepted':True,'controls':results},indent=2)+'\n')
print('RUST_SNAPSHOT_CONTROLS_ACCEPTED',len(results))
