#!/usr/bin/env python3
"""Bind/build/read back/load the two new correctness ELFs, without starting a database."""
import hashlib,json,os,signal,subprocess,time
from pathlib import Path
B=Path('/mnt/data/kv9-work/protocol-snapshot-20260916');BIN=B/'chaos-binaries-third';OUT=B/'chaos-image'
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def save(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def pin(p):
    p=Path(p)
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
r=json.loads((BIN/'result.json').read_text());need(r['complete'] is True,'binary build acceptance')
for v in r['binaries'].values():need(pin(v['path'])==v,'retained binary changed')
OUT.mkdir();started=time.monotonic();base={str(p):(p.stat().st_dev,os.statvfs(p).f_bavail*os.statvfs(p).f_frsize) for p in [Path('/'),OUT]}
def guard():
    need(time.monotonic()-started<600,'image deadline');decline=0;seen=set()
    for name,(device,free) in base.items():
        p=Path(name);now=os.statvfs(p).f_bavail*os.statvfs(p).f_frsize;need(p.stat().st_dev==device and now>=8*1024**3,'image space/device')
        if device not in seen:decline+=max(0,free-now);seen.add(device)
    need(decline<=12*1024**3,'image allocation decline')
def run(label,argv,timeout=300):
    guard();start=time.time_ns()
    with (OUT/(label+'.stdout')).open('xb') as stdout,(OUT/(label+'.stderr')).open('xb') as stderr:
        p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            end=time.monotonic()+timeout
            while p.poll() is None:guard();need(time.monotonic()<end,'image child timeout');time.sleep(.5)
        finally:
            if p.poll() is None:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
            save(OUT/(label+'.terminal.json'),{'argv':argv,'pid':p.pid,'started_ns':start,'finished_ns':time.time_ns(),'exit_code':p.returncode})
    need(p.returncode==0,label+' failed');return (OUT/(label+'.stdout')).read_text()
try:
    image='kv9-protocol-snapshot:d03-20260916-'+r['binaries']['kv9']['sha256'][:12]
    dockerfile='FROM ubuntu@sha256:224a1869083a311ef3f13648a154ba79832fbef6364d31493642ca03082da254\nCOPY kv9 kv9-routed-workload /usr/local/bin/\nENTRYPOINT ["/usr/local/bin/kv9"]\n'
    # Small context links are separate ordinary copies; immutable retained originals stay in BIN.
    context=OUT/'context';context.mkdir()
    import shutil
    for name in ('kv9','kv9-routed-workload'):shutil.copyfile(BIN/name,context/name);os.chmod(context/name,0o755)
    (context/'Dockerfile').write_text(dockerfile)
    run('base-inspect',['docker','image','inspect','ubuntu@sha256:224a1869083a311ef3f13648a154ba79832fbef6364d31493642ca03082da254'],30)
    run('build',['docker','build','--network=none','--pull=false','-t',image,str(context)])
    inspect=json.loads(run('inspect',['docker','image','inspect',image],30));need(len(inspect)==1,'image inspect');image_id=inspect[0]['Id']
    probe_name='kv9-protocol-snapshot-image-readback-20260916'
    observed=run('elf-readback',['docker','run','--rm','--name',probe_name,'--network=none','--entrypoint','sha256sum',image,'/usr/local/bin/kv9','/usr/local/bin/kv9-routed-workload'],30)
    need([x.split()[0] for x in observed.splitlines()]==[r['binaries'][x]['sha256'] for x in ('kv9','kv9-routed-workload')],'image ELF readback')
    listing=run('probe-absence',['docker','ps','-a','--filter','name=^/'+probe_name+'$','--format','{{.ID}}'],30);need(not listing.strip(),'image probe container remains')
    run('kind-load',['/mnt/data/kv9-work/chaos-tools-20260915-first/kind','load','docker-image',image,'--name','kv9-chaos-ci-p0-20260908'])
    cri=json.loads(run('cri-readback',['docker','exec','kv9-chaos-ci-p0-20260908-control-plane','crictl','images','-o','json'],30))
    selected=[x for x in cri['images'] if any(t.removeprefix('docker.io/library/')==image for t in x.get('repoTags',[]))]
    need(len(selected)==1 and selected[0]['id']==image_id,'Kind loaded image identity')
    for v in r['binaries'].values():need(pin(v['path'])==v,'retained binary changed')
    save(OUT/'result.json',{'complete':True,'image':image,'image_id':image_id,'binaries':r['binaries'],'build':pin(BIN/'result.json'),'source':r['source'],'context':[pin(context/n) for n in ('kv9','kv9-routed-workload','Dockerfile')],'cri':selected[0],'probe_absent':True,'scope':'New default-feature debug correctness image; no snapshot installation acceptance.'})
except BaseException as error:
    save(OUT/'failure.json',{'complete':False,'error':repr(error)});raise
