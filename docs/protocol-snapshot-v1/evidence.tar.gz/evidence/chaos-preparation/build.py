#!/usr/bin/env python3
"""One bounded default-feature correctness build; execute only after root source freeze."""
import argparse,fcntl,hashlib,json,os,signal,subprocess,time,traceback
from pathlib import Path
ROOT=Path('/home/dongxu/kv9');BASE=Path('/mnt/data/kv9-work/protocol-snapshot-20260916');OUT=BASE/'chaos-binaries';TARGET=ROOT/'target'
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def save(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def pin(path):
    p=Path(path)
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def snapshot():
    raw=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],cwd=ROOT)
    files=sorted(set(x.decode() for x in raw.split(b'\0') if x))
    names=[n for n in files if n.endswith(('.rs','.proto')) or Path(n).name in ('Cargo.toml','Cargo.lock','rust-toolchain.toml') or n.startswith('.cargo/')]
    return {'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),'dirty':bool(subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)),'source_sha256':{n:pin(ROOT/n)['sha256'] for n in names}}
a=argparse.ArgumentParser();a.add_argument('--freeze',type=Path,required=True);args=a.parse_args()
freeze=json.loads(args.freeze.read_text());need(freeze['source_frozen'] is True,'root freeze required')
OUT.mkdir();os.chmod(OUT,0o700);start=time.monotonic();commands=[];child=None
baseline={str(p):(p.stat().st_dev,os.statvfs(p).f_bavail*os.statvfs(p).f_frsize) for p in [Path('/'),OUT]}
def guard():
    need(time.monotonic()-start<1200,'build deadline')
    seen=set();decline=0
    for name,(dev,available) in baseline.items():
        p=Path(name);now=os.statvfs(p).f_bavail*os.statvfs(p).f_frsize;need(p.stat().st_dev==dev and now>=8*1024**3,'device/floor')
        if dev not in seen:decline+=max(0,available-now);seen.add(dev)
    need(decline<=16*1024**3,'build allocation decline')
def run(label,argv,env):
    global child
    guard();receipt={'argv':argv,'started_ns':time.time_ns()}
    with (OUT/(label+'.stdout')).open('xb') as stdout,(OUT/(label+'.stderr')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True,pass_fds=(lock.fileno(),));receipt['pid']=child.pid
        try:
            while child.poll() is None:guard();time.sleep(.5)
        finally:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
            receipt.update(exit_code=child.returncode,finished_ns=time.time_ns());save(OUT/(label+'.terminal.json'),receipt);commands.append(receipt)
    need(child.returncode==0,label+' failed')
try:
    before=snapshot();need(before['base_revision']==freeze['base_revision'],'base revision changed')
    need(before['source_sha256']==freeze['source_sha256'],'frozen source differs');save(OUT/'source-before.json',before)
    env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='4',CARGO_NET_OFFLINE='true')
    need(not any(k.startswith(('KV9_TESTING_','KV9_OBJECT_STORE_')) for k in env),'testing env')
    need(not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS'),'unqualified Rust flags')
    lock=(TARGET/'.kv9-retained-build.lock').open('a+b');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    save(OUT/'lock.json',{'path':str(TARGET/'.kv9-retained-build.lock'),'device':os.fstat(lock.fileno()).st_dev,'inode':os.fstat(lock.fileno()).st_ino,'pid':os.getpid(),'inherited_by_children':True})
    run('cargo-version',['cargo','--version','--verbose'],env);run('rustc-version',['rustc','--version','--verbose'],env)
    run('metadata',['cargo','metadata','--offline','--locked','--format-version','1'],env)
    meta=json.loads((OUT/'metadata.stdout').read_text());members=set(meta['workspace_members']);features={r['id']:r['features'] for r in meta['resolve']['nodes'] if r['id'] in members}
    need(features and all(not fs for fs in features.values()),'nondefault first-party feature graph');save(OUT/'first-party-features.json',features)
    run('cargo-build',['cargo','build','--offline','--locked','-j','4','--bin','kv9','--bin','kv9-routed-workload','--message-format=json-render-diagnostics'],env)
    artifacts={}
    for line in (OUT/'cargo-build.stdout').read_text().splitlines():
        event=json.loads(line)
        if event.get('reason')=='compiler-artifact' and event.get('executable') and event['target']['name'] in ('kv9','kv9-routed-workload'):
            need(event['features']==[],'binary feature graph');artifacts[event['target']['name']]=event
    need(set(artifacts)=={'kv9','kv9-routed-workload'},'both binary artifacts required');save(OUT/'cargo-artifacts.json',artifacts)
    for name,event in artifacts.items():
        source=Path(event['executable']);need(source==TARGET/'debug'/name,'unexpected artifact path')
        run('strip-'+name,['strip','--strip-all','-o',str(OUT/name),str(source)],env);os.chmod(OUT/name,0o755)
    after=snapshot();save(OUT/'source-after.json',after);need(before==after,'source changed during build')
    source=dict(before,profile='debug',stripped=True,default_features=[]);save(OUT/'source.json',source)
    save(OUT/'result.json',{'complete':True,'scope':'Default-feature stripped debug correctness binaries; no protocol snapshot installation or throughput claim.','freeze':pin(args.freeze),'source':pin(OUT/'source.json'),'binaries':{name:pin(OUT/name) for name in artifacts},'commands':commands,'features':features})
except BaseException as error:
    save(OUT/'failure.json',{'complete':False,'error':repr(error),'traceback':traceback.format_exc()});raise
finally:
    if 'lock' in globals():lock.close()
