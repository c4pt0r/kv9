import json,subprocess,time,hashlib,os,signal
from pathlib import Path
B=Path('/mnt/data/kv9-work/protocol-snapshot-20260916');c=json.loads((B/'chaos-command.json').read_text())
for row in c['inputs']:
 p=Path(row['path'])
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 assert p.stat().st_size==row['bytes'] and h==row['sha256']
assert not (B/'chaos-first').exists()
start=time.time_ns();record={'argv':c['runtime'],'started_ns':start}
with (B/'chaos-first-wrapper.log').open('xb') as log:
 child=subprocess.Popen(c['runtime'],cwd=c['cwd'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['pid']=child.pid
 try:code=child.wait(timeout=1500)
 except BaseException as error:
  record['outer_failure']=repr(error);os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=15)
  code=child.returncode
 record.update(finished_ns=time.time_ns(),exit_code=code)
 with (B/'chaos-first-wrapper.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
raise SystemExit(code)
