# Protocol snapshot source: normal routing/failover qualification

One fresh four-fault campaign passed on the newly built default-feature debug binaries. This tests ordinary scoped routing and failover while the changed source rejects uncoordinated snapshot reception/startup. It does not exercise protocol snapshot installation.

The two complete serial, unique-key histories contain 46 calls: 43 successes, one UnknownWrite, and two lookup failures. The uncertain mutation was not replayed; every submitted mutation key was read after healing. Actual discovery-seed isolation, data-leader container kill, two-way leader isolation with direct minority refusal, and client-to-data-leader isolation were retained. Discovery-seed selection deliberately preserves reachability of the current metadata and data leaders; it is not exhaustive endpoint-loss coverage.

The independent checker accepted the complete histories, exact fault effects, fresh group drains, stopped-store archive hashes and members, client exits, known server PID/start/boot absence, final namespace deletion, and preservation of all eight historical namespace UIDs and the historical fault. Garbage-collected CRI records do not invent exit codes. The pre-cleanup result.json remains unchanged; accepted.json and cleanup.json record the final stage.

Actual tool terminals: build 73584/659e0d/0, image/readback/load 7940/48ccfb/0, runtime 60069/cd0d10/0, independent reader 797f49/0. Two preparation failures are preserved: a dev-inclusive metadata feature check and missing explicit workload package selection; neither started a runtime campaign.

chaos-publication-inventory.json lists the exact retained publication inputs and omissions. ELF binaries remain local with hashes, as do their image-context copies. No credentials, kubeconfig, or issue snapshots are selected. Three small stopped-store tar archives are included for the original full-member readback. Absolute paths are original execution provenance, not a portable runnable installation. Existing harness controls are inherited; they were not rerun. Runtime/build sources and results were not edited to obtain acceptance.
