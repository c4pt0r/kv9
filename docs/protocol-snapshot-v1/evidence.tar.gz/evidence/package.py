import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/dongxu/kv9');work=Path('/mnt/data/kv9-work/protocol-snapshot-20260916');out=root/'docs/protocol-snapshot-v1'
# The caller supplies independently checked campaign receipts after cleanup.
accept=json.loads((work/'accepted-campaign.json').read_text())
assert accept['complete'] and accept['independent_reader_exit_code']==0 and accept['cleanup_checked']
out.mkdir(exist_ok=False)
files={};excluded=[]
for p in work.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 r=p.relative_to(work)
 if '__pycache__' in r.parts or p.suffix in ('.olean','.ilean','.pyc'):continue
 if p.name.startswith('issue') or p.name in ('publication.json','continuation-before-publication.json'):continue
 if p.name in ('kubeconfig','token','credentials') or p.suffix in ('.key','.pem'):excluded.append(str(r));continue
 with p.open('rb') as stream:magic=stream.read(4)
 if magic==b'\x7fELF':excluded.append(str(r));continue
 files['evidence/'+str(r)]=p
names=set()
for model in ['protocol-snapshot','group-preparation','group-activation']:
 c=root/'proofs/lean'/model/'source-contract.json';names.add(str(c.relative_to(root)));names.update(json.loads(c.read_text())['source_sha256'])
names.update(['scripts/routed-client-chaos.py','scripts/check-routed-client-chaos.py','docs/PROTOCOL-SNAPSHOT.md','docs/HORIZONTAL-SCALING-PLAN.md','Cargo.toml','Cargo.lock'])
for command in [['git','diff','--name-only'],['git','ls-files','--others','--exclude-standard']]:
 for name in subprocess.check_output(command,cwd=root,text=True).splitlines():
  if name not in ('scripts/checkpoint-publication-chaos.py','scripts/checkpoint-owned-crash.py') and not name.startswith('docs/protocol-snapshot-v1/'):
   names.add(name)
for name in names:files['source/'+name]=root/name
members=[];total=0
with (out/'evidence.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,p in sorted(files.items()):
  data=p.read_bytes();total+=len(data);assert total<=128*1024**2
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  members.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 actual=[]
 for m in tar:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  d=tar.extractfile(m).read();actual.append({'name':m.name,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
assert actual==members
artifact=out/'evidence.tar.gz'
summary={'schema':1,'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'archive_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'archive_bytes':artifact.stat().st_size,'decoded_bytes':total,'members':members,'excluded_files':excluded,'accepted':{'local':'evidence/local-validation.json','snapshot_proof':'evidence/proof-accepted/result.json','preparation_proof':'evidence/preparation-proof/result.json','activation_proof':'evidence/activation-proof/result.json','rust_controls':'evidence/rust-controls/result.json','chaos':'evidence/accepted-campaign.json'},'not_claimed':['coordinated engine installation','remote snapshot admission','learner attach after truncation','complete S05 or D03','physical Raft log reclamation','general concurrent linearizability','all-voter or IO Chaos matrix','verified Rust extraction','split or migration','new throughput','independent-host scaling','hosted CI']}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['archive_sha256','archive_bytes','decoded_bytes']}));print('members',len(members))
