# D03 joint installer: bounded actual-MinIO / Chaos proposal

This is read-only environment discovery and an interface proposal. No installer, workload, fault, image build, cluster mutation, or existing-service mutation ran.

## Available infrastructure

The accepted cluster is `kv9-chaos-ci-p0-20260908`, using `/mnt/data/kv9-work/chaos-tools-20260915-first/{kind,kubeconfig}` and `/usr/local/bin/kubectl`. Its single Ready node is `kv9-chaos-ci-p0-20260908-control-plane` (Kubernetes v1.35.5). Chaos Mesh v2.8.4 controller/daemon/DNS are Running; one daemon is Ready. The same eight historical namespace UIDs and original `store-loss-kill` PodChaos UID remain. Fresh namespaces must have `chaos-mesh.org/inject=enabled`.

`kv9-minio-dev` (container `4b05c35453b87...`) is running and answers HTTP 200 at host `http://127.0.0.1:19000/minio/health/live`. Its actual image is `sha256:69b2ec208575b69597784255eec6fa6a2985ee9e1a47f4411a51f7f5fdd193a9`, pinned by `quay.io/minio/minio@sha256:14cea493d9a34af32f524e538b8346cf79f3321eff8e708c1e2960462bd8936e`. That image already exists locally and contains MinIO RELEASE.2025-09-07T16-13-09Z and mc RELEASE.2025-08-13T08-35-41Z. Both root credential fields exist in the service's configuration; no inherited KV9 object-store credentials are set. Only presence was recorded, never values.

This service uses Docker's `bridge` network (172.17.0.3) and a root-filesystem Docker volume. The active Kind node is on the separate `kind` network (172.21.0.3). A bounded HTTP GET from that node to 172.17.0.3:9000 timed out after two seconds (curl exit 28). Its published host port is loopback-only. Thus current credentials and host health do not establish a usable Pod endpoint. Existing C04 MinIO containers, including the separate running tmpfs fixture and Created failed container, remain protected and are not proposed for reuse.

## Smallest applicable setup

Reuse the installed tools, pinned MinIO image, existing Kind network, Chaos controller and historical resource baseline. Create only after interface agreement:

1. One fresh MinIO Docker container on network `kind`, with fresh credentials, a unique bucket and a unique bind-mounted data directory beneath `/mnt/data/kv9-work/joint-install-20260916/minio-*`. No existing MinIO configuration or contents change. The destination uses `http://<new-container-IP>:9000`; both actual host and Pod health/object round trips must be checked before installation. Credentials enter the container through a private env file and the Pod through Secret references; neither is included in public commands/evidence.
2. One uniquely owned namespace, one destination Pod with a named installer container, and one retained target PVC. This is an offline installation cell, not three live voters or another routing campaign. Keep the destination Pod's ordinary command as a bounded idle process; invoke the installer using a retained `kubectl exec` child. Actual PodChaos `container-kill` kills that exact container and its installer child. On restart the same Pod/PVC returns to idle, so recovery is explicitly invoked once rather than accidentally replaying installation.
3. An uncut installation control and three sequential crash cells, each with a fresh target subdirectory/store incarnation and a complete old selected generation. Use two distinguishable exact engine images (old A/new B), a nontrivial matching protocol term/index/configuration, and one verified MinIO source object set. This makes both old/new generation selection observable. All cells and partial directories remain charged to one allocation baseline.

Storage caveat: current Kind only binds `/lib/modules` and its Docker `/var` volume; it has no host `/mnt/data` bind. `standard` PVCs use rancher.io/local-path under that node storage. MinIO objects and all exported evidence can be on the data volume now. A small explicitly bounded target PVC would still occupy root-backed Docker storage. If every target-store byte must be on the data volume, an additional separately agreed volume mapping is required; the existing PVC must not be mislabeled data-volume storage. No existing Kind mount or cluster is changed in this proposal.

## Required implementation interface

The new probe/CLI needs commands or equivalent bounded modes for: preparing a source image using production encoding; PUT then GET/readback of its actual objects through MinioObjectStore; initializing a destination's old selected generation; invoking the real joint installer with an exact destination identity and expected source image; and opening/recovering the selected generation without reissuing installation. A local path is fine for the source descriptor, but all referenced remote objects must be actually fetched/verified from MinIO. Merely uploading a fixture and then installing from an unrelated local cache would not exercise the required path.

The installer must expose narrow deterministic observations at actual coordinator boundaries:

- `engine-prepared`: the new engine generation is fully prepared at the implementation's durable boundary; protocol preparation and selector replacement have not occurred.
- `protocol-prepared`: matching engine and protocol generation bytes are durably prepared, but the old selector remains selected.
- `selector-published`: the atomic selector replacement and its required directory sync have completed, but the caller has not yet received successful completion.

Each arrival record binds run/cell ID, exact source image digest, destination/store identity, old/new generation IDs, protocol term/index, and installer PID/start ticks/boot ID. Record the precise source location and whether its preceding sync returned. The marker is an observation, not a recovery authority. The recovered selector and complete referenced bytes decide the result. These are new joint-installer hooks; no old checkpoint pre-upload hook or rejected action is reused.

For each cut, retain the actual arrival and exact Pod/PVC/container/installer identities, apply an owned container-kill, and require AllInjected plus the targeted old container's exit 137. Require old installer and container identities absent, same Pod/PVC/store identity, and a new container/process before the explicit recovery invocation. Before-selector cuts must recover old complete pair A; after-durable-publication must recover new complete pair B. If an additional pre-directory-sync cut is desired, define its acceptable old/new outcome separately; do not infer power-loss behavior from process kill.

Recovery must compare the complete selected descriptor, generation and engine/protocol digests and enumerate expected keys/values/tombstones. It must reject mixed generations, missing or corrupt referenced files, wrong destination identity, and an unverified source. Preserve unselected/partial artifacts instead of deleting them to make recovery pass. The returned terminal record and all readback values must remain separately attributable to the actual recovered process. This does not establish remote-image authority, learner RPC/attachment, Raft membership change, or snapshot installation into a live quorum.

## Reusable code and bounds

`scripts/routed-client-chaos.py` supplies already exercised Kind/image checks, exact namespace/fault ownership, PID/start/boot and CRI-GC handling, stopped-store archive streaming, independent member/EOF verification, and protected-UID cleanup. Reuse those pieces, not its four-fault routing scenario or its route-history checker as installer acceptance. `scripts/root_provision.py` has the correct whitespace-token parsing for store identities. `scripts/wal_layout.py` can inspect existing engine WAL/checkpoint format where applicable; it knows nothing about the new joint selector.

`scripts/minio-kv-e2e.py` documents actual KV9_STORAGE=minio and KV9_OBJECT_STORE_{ENDPOINT,BUCKET,ACCESS_KEY,SECRET_KEY} wiring, source writes, remote checkpoint recovery and MinIO image pin. Do not run its shell wrapper (it builds the workspace), its full three-voter scenario, its auto-temp /tmp placement, or its historical pause cases for this task. A MinioObjectStore constructor alone performs no request and is not connectivity evidence.

Prospective limits for this small fixture: one installer process and one Chaos fault at a time; at most three crash cells plus one uncut control; 1200 seconds overall; 120 seconds per arrival/recovery; three finite object/data sets whose exact measured size is frozen before launch; at most 1 GiB additional retained bytes with at least 8 GiB free on every distinct root/data filesystem. Keep each stopped-store archive at the existing 128 MiB cap and total evidence at 512 MiB. These are a proposed ceiling, not proof the unknown final image fits. A small dataset should fit comfortably; freeze actual byte algebra after the source-image interface exists.

Before exact cleanup, stop all owned writers, retain full source/target descriptors and failed attempts, GET/read back the selected MinIO object bytes, and independently verify complete stopped-store archives. Delete only the owned fault/namespace/container/bucket after exact UID/ID checks and historical-resource comparison. Leave the original shared MinIO and both historical C04 fixtures untouched.

## Remaining concrete decisions

Agree the probe/CLI schema and source-image creation/readback API; expose the three real pause boundaries; define read-only recovery outputs for old/new selected pairs; and choose the bounded root-backed target PVC versus a new data-volume mapping. No runnable installer harness is claimed before these interfaces exist. The current machinery can perform actual PodChaos container-kill and safe evidence retention once they are supplied.
