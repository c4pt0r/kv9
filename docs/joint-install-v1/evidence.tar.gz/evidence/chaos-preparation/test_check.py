import copy,json,unittest
from pathlib import Path
import check
class Controls(unittest.TestCase):
 def setUp(self):
  self.f={'metadata':{'uid':'fault-id','namespace':'owned'},'spec':{'action':'container-kill','mode':'all','containerNames':['installer'],'selector':{'namespaces':['owned'],'pods':{'owned':['destination']}}},'status':{'conditions':[{'type':'AllInjected','status':'True'}]}}
  self.d={'uid':'fault-id','absent':True}
  self.before={'pod_uid':'p','container_id':'old','kind_process':{'pid':1,'start_ticks':1,'boot_id':'b'}}
  self.after={'pod_uid':'p','container_id':'new','kind_process':{'pid':1,'start_ticks':2,'boot_id':'b'},'last_terminated':{'containerID':'old','exitCode':137}}
  self.seed={'target_incarnation':'2'*32}
  self.value={'status':'selected','serving':False,'values_verified':True,'index':20,'term':3,'target_node':4,'records':5,'target_incarnation':'2'*32,'generation':'1'*32,'image_digest':'3'*64}
 def test_valid_evidence(self):
  check.fault_observed(self.f,self.f,self.d,'owned');check.same_destination(self.before,self.after,'pvc','pvc');check.selected(self.value,self.seed,20)
 def test_missing_actual_injection(self):
  self.f['status']['conditions']=[]
  with self.assertRaises(ValueError):check.fault_observed(self.f,self.f,self.d,'owned')
 def test_fault_wrong_scope(self):
  self.f['spec']['selector']['namespaces']=['historical']
  with self.assertRaises(ValueError):check.fault_observed(self.f,self.f,self.d,'owned')
 def test_missing_transition(self):
  self.after['container_id']='old'
  with self.assertRaises(ValueError):check.same_destination(self.before,self.after,'pvc','pvc')
 def test_wrong_exit(self):
  self.after['last_terminated']['exitCode']=0
  with self.assertRaises(ValueError):check.same_destination(self.before,self.after,'pvc','pvc')
 def test_replaced_store(self):
  with self.assertRaises(ValueError):check.same_destination(self.before,self.after,'old','new')
 def test_unverified_values(self):
  self.value['values_verified']=False
  with self.assertRaises(ValueError):check.selected(self.value,self.seed,20)
 def test_wrong_cut(self):
  with self.assertRaises(ValueError):check.selected(self.value,self.seed,10)
 def test_missing_cleanup(self):
  clean={'complete':True,'namespace_absent':False,'namespace_uid':'u','protected_namespaces':{},'protected_faults':{}}
  with self.assertRaises(ValueError):check.clean_checked(clean,{'cleanup_complete':True},{'namespace_uid':'u'},{'namespaces':{},'faults':{}})
 def test_checksum_corruption(self):
  b=b'KV9SEL01'+bytes(80);good=b+check.digest(b);check.envelope(good,b'KV9SEL01',120)
  with self.assertRaises(ValueError):check.envelope(good[:-1]+bytes([good[-1]^1]),b'KV9SEL01',120)
if __name__=='__main__':unittest.main(verbosity=2)
