#!/usr/bin/env python3
"""Independent retained-evidence reader for seven bounded non-serving install cells."""
import argparse,hashlib,json,re,tarfile
from pathlib import Path
import os

def require(ok,message):
 if not ok:raise ValueError(message)
def unique(pairs):
 d={}
 for k,v in pairs:
  require(k not in d,'duplicate JSON key');d[k]=v
 return d
def R(p):
 p=Path(p);require(p.is_file() and not p.is_symlink() and p.stat().st_size<=16*1024**2,'bounded regular JSON');return json.loads(p.read_bytes(),object_pairs_hook=unique)
def pin(p):
 p=Path(p);require(p.is_file() and not p.is_symlink(),'regular input');return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
def save(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def same_destination(before,after,pvc_before,pvc_after):
 require(before['pod_uid']==after['pod_uid'] and pvc_before==pvc_after,'Pod/PVC identity changed')
 require(before['container_id']!=after['container_id'] and before['kind_process']!=after['kind_process'],'target process did not change')
 old=after['last_terminated'];require(old and old['containerID']==before['container_id'] and old['exitCode']==137,'actual killed container exit')
def verify_archive(path,expected):
 require(pin(path)['sha256']==expected['sha256'] and Path(path).stat().st_size==expected['bytes'],'archive identity')
 seen={};total=0;end=0
 with tarfile.open(path,'r:') as archive:
  for m in archive:
   end=((m.offset_data+m.size+511)//512)*512;name=m.name.removeprefix('./')
   require(name not in seen and not name.startswith('/') and '..' not in Path(name).parts and (m.isdir() or m.isfile()),'unsafe tar member')
   if m.isfile():
    total+=m.size;require(0<=m.size<=128*1024**2 and total<=128*1024**2,'archive decode cap')
    seen[name]={'bytes':m.size,'sha256':hashlib.file_digest(archive.extractfile(m),'sha256').hexdigest()}
   else:seen[name]={'directory':True}
 with Path(path).open('rb') as f:
  f.seek(end);trailer=f.read(11264);require(len(trailer)>=1024 and len(trailer)%512==0 and not any(trailer) and not f.read(1),'complete tar EOF')
 require(seen==expected['members'],'archive member closure')
def fault_observed(fault,created,deleted,namespace):
 require(fault['metadata']['uid']==created['metadata']['uid']==deleted['uid'] and deleted['absent'] is True and fault['metadata']['namespace']==namespace,'fault identity')
 spec=fault['spec'];require(spec['action']=='container-kill' and spec['mode']=='all' and spec['containerNames']==['installer'] and spec['selector']['namespaces']==[namespace] and spec['selector']['pods']=={namespace:['destination']},'exact fault scope')
 require(any(x['type']=='AllInjected' and x['status']=='True' for x in fault['status']['conditions']),'actual injection absent')
def clean_checked(clean,accepted,setup,protected):
 require(clean['complete'] is True and clean['namespace_absent'] is True and clean['namespace_uid']==setup['namespace_uid'] and clean['protected_namespaces']==protected['namespaces'] and clean['protected_faults']==protected['faults'] and accepted['cleanup_complete'] is True,'exact cleanup/historical preservation')
STEPS=[None,'after-engine','after-protocol','before-selector','after-selector-rename','after-selector-sync','before-selector']
def digest(b):return hashlib.sha256(b).digest()
def envelope(b,magic,n):
 require(len(b)==n and b[:8]==magic and digest(b[:-32])==b[-32:],'checksum record envelope');return b[8:-32]
def selected(v,seed,index):
 require(v['status']=='selected' and v['serving'] is False and v['values_verified'] is True and type(v['index']) is int and v['index']==index and v['term']==3 and v['target_node']==4 and v['records']==(4 if index==10 else 5) and v['target_incarnation']==seed['target_incarnation'],'recovery destination/cut/data')
 require(re.fullmatch('[0-9a-f]{32}',v['generation']) and re.fullmatch('[0-9a-f]{64}',v['image_digest']),'generation/image digest encoding')
def audit(out,cleanup=True):
 out=Path(out);setup=R(out/'setup.json');runtime=R(out/'runtime-result.json');archive=R(out/'archive.json');protected=R(out/'protected.json')
 require(runtime['complete'] is True and len(runtime['cells'])==7 and setup['serving'] is False and setup['test_only'] is True,'runtime completion/scope')
 require(R(out/'before-source-check.json')['complete'] and R(out/'after-source-check.json')['complete'],'source changed')
 verify_archive(out/archive['file'],archive)
 inputs=[out/'setup.json',out/'runtime-result.json',out/'archive.json',out/'protected.json',out/'before-source-check.json',out/'after-source-check.json'];cuts=[];objects={};container_ids=set()
 with tarfile.open(out/archive['file'],'r:') as tar:
  members={m.name.removeprefix('./'):m for m in tar}
  def file(name):
   require(name in members and members[name].isfile() and members[name].size<=2**20,'missing/bounded physical file');return tar.extractfile(members[name]).read()
  for n,pause in enumerate(STEPS):
   name=f'{n:02d}-'+(pause or 'uncut')+('-initial-empty' if n==6 else '');c=out/name;result=R(c/'result.json');seed=R(c/'seed.json');recovery=R(c/'recovery.json');expected=None if n==6 else 20 if pause in (None,'after-selector-rename','after-selector-sync') else 10
   require(result==runtime['cells'][n] and result['complete'] is True and result['pause']==pause and result['expected_index']==expected and result['recovered']==recovery,'cell identity/expectation')
   require(seed['status']=='seeded' and seed['old_cut']==10 and seed['new_cut']==20 and seed['target_node']==4,'seed scope')
   manifests=R(c/'source-manifests.json');require(len(manifests)==2 and [m['index'] for m in manifests]==[10,20] and all(m['term']==3 for m in manifests) and manifests[0]['scope']==manifests[1]['scope'],'source image cuts/scope')
   rows=R(c/'objects.json');bykey={r['key']:r for r in rows};require(len(bykey)==len(rows),'duplicate object row')
   expected_keys={f['key'] for m in manifests for f in m['files']};require(set(bykey)==expected_keys,'object closure')
   for m in manifests:
    for f in m['files']:
     row=bykey[f['key']];require(all(row[k]==v for k,v in f.items()),'object manifest identity')
     require(f['key']==f"clusters/{m['scope']['cluster']}/regions/{m['scope']['region']}/sst/{f['sha256']}",'unscoped object key')
     q=out/row['path'];require(q.is_relative_to(out) and pin(q)['sha256']==f['sha256'] and q.stat().st_size==f['size'],'complete MinIO object SHA/size');objects[row['key']]=f['size'];inputs.append(q)
   require(file(name+'/snapshot.old')==(c/'old.bundle').read_bytes() and file(name+'/snapshot.new')==(c/'new.bundle').read_bytes(),'retained source bundles changed')
   root=name+'/store/data-groups/100/';selector=root+'installed-generation'
   if expected is None:
    require(recovery=={'status':'pending','serving':False} and selector not in members,'initial pending selector state')
   else:
    selected(recovery,seed,expected);require(R(c/'same-bundle-retry.json')==recovery,'idempotence generation/image changed')
    old=R(c/'old-install.json');selected(old,seed,10)
    if expected==10:require(recovery['generation']==old['generation'],'old generation not selected')
    fields=envelope(file(selector),b'KV9SEL01',120);record=file(root+'group-record');require(fields[:32]==digest(record),'selector destination binding')
    require(fields[32:48].hex()==recovery['generation'] and fields[48:80].hex()==recovery['image_digest'],'selector generation/image')
    generation=root+'install-'+recovery['generation']+'/';image=file(generation+'image');require(digest(image).hex()==recovery['image_digest'],'selected image digest')
    ready=envelope(file(generation+'ready'),b'KV9PAIR1',168);require(ready[:32]==fields[:32],'ready destination binding')
    for j,path in enumerate(['data.wal','data.checkpoint','raft/raft.log']):require(digest(file(generation+path))==ready[32+j*32:64+j*32],'sealed generation file changed')
    checkpoint=file(generation+'data.checkpoint');magic=b'KV9CHECKPOINT\x01';require(checkpoint.startswith(magic) and json.loads(checkpoint[len(magic):])==manifests[0 if expected==10 else 1],'engine checkpoint source mismatch')
    require(recovery['object_bytes']==sum(f['size'] for f in manifests[0 if expected==10 else 1]['files']),'object byte total')
   if pause:
    event=R(c/'pause.json');fault=R(c/'fault-injected.json');created=R(c/'fault-created.json');deleted=R(c/'fault-deleted.json');restart=R(c/'restart.json');terminal=R(c/'install-terminal.json')
    require(event['step']==pause and event['bundle_sha256']==pin(c/'new.bundle')['sha256'] and event['target_incarnation']==seed['target_incarnation'] and event['term']==3 and event['index']==20 and event['process']['pid']==event['pid'],'pause bound to exact bundle/process')
    fault_observed(fault,created,deleted,setup['namespace'])
    require(terminal['exit_code']==137 and restart['old_kind_process_absent'] is True and restart['old_probe_process_absent'] is True and restart['pvc_uid']==setup['pvc_uid'],'kill process evidence')
    same_destination(restart['before'],restart['after'],restart['pvc_uid'],setup['pvc_uid']);require(restart['before']['pod_uid']==setup['pod_uid'],'destination Pod changed')
    container_ids.update([restart['before']['container_id'],restart['after']['container_id']])
    if expected==20:require(event['generation']==recovery['generation'],'new published generation differs')
    require(file(name+'/store/observations/pause.json')==json.dumps({k:v for k,v in event.items() if k!='process'},separators=(',',':'),sort_keys=True).encode() or json.loads(file(name+'/store/observations/pause.json'))=={k:v for k,v in event.items() if k!='process'},'retained marker changed')
   cuts.append({'cell':name,'expected_index':expected,'selected':recovery,'fault':pause is not None});inputs.extend(p for p in c.iterdir() if p.is_file())
 if cleanup:
  clean=R(out/'cleanup.json');accepted=R(out/'accepted.json');owned=R(out/'final-owned.json')
  clean_checked(clean,accepted,setup,protected)
  lifetimes=clean['recorded_server_containers'];require({r['id'] for r in lifetimes}=={x.removeprefix('containerd://') for x in owned['container_processes']},'lifetime closure')
  for r in lifetimes:
   require(r['process_absent'] is True and r['process']==owned['container_processes']['containerd://'+r['id']],'process identity exit')
   if r['state']=='GARBAGE_COLLECTED':require(r['exitCode'] is None and r['cri_absent'] and r['task_absent'],'GC exit fabrication')
   else:require(r['state']=='CONTAINER_EXITED','live container')
  inputs.extend([out/'cleanup.json',out/'accepted.json',out/'final-owned.json'])
 return {'complete':True,'cells':cuts,'actual_faults':6,'objects':len(objects),'object_bytes':sum(objects.values()),'archive_bytes':archive['bytes'],'archive_sha256':archive['sha256'],'cleanup_checked':cleanup,'scope':'Actual single-host process kills with persistent target; no power-loss, serving, learner or network-install acceptance','inputs':[pin(p) for p in sorted(set(inputs))]}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();save(a.output,audit(a.run));print(json.dumps({'complete':True,'output':str(a.output)}))
