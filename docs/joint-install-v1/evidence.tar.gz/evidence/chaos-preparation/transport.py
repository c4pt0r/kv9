"""D03-owned transport helpers; no operation runs at import time."""
import hashlib,importlib.util,json,os,subprocess,time
from pathlib import Path
BASE=Path('/mnt/data/kv9-work/joint-install-20260916')
PREP=BASE/'chaos-preparation'
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
source=load_module('routed_transport_origin',PREP/'routed-client-chaos.py')
checker=load_module('routed_archive_origin',PREP/'check-routed-client-chaos.py')
require=source.require
save=source.save

def identity_for(gate,pod,pid):
    """Bind exact PID/start/boot inside the target Pod; never raw PID alone."""
    return gate.remote_identity(pod,pid)

def current_container(gate,pod,container):
    p=gate.get('pod',pod)
    rows=[c for c in p['status'].get('containerStatuses',[]) if c['name']==container]
    require(len(rows)==1,'target container status population');c=rows[0]
    if not c.get('state',{}).get('running'):return None
    info=gate.inspect_container(c['containerID'])
    if info is None:return None
    pid=info['info'].get('pid')
    # A just-restarted container can report pid 0 before the runtime fills it
    # in; within a bounded wait that is "not ready yet", not corrupt identity.
    if type(pid) is not int or not 0<pid<2**31:return None
    process=gate.host_process(pid)
    if process is None:return None
    return {'pod':pod,'pod_uid':p['metadata']['uid'],'container_id':c['containerID'],'container_name':container,'kind_process':process,'restart_count':c['restartCount'],'last_terminated':c.get('lastState',{}).get('terminated')}

def complete_archive_readback(path,expected):
    return checker.verify_archive(path,expected)

def scoped_kill_manifest(namespace,pod,container,name):
    return {'apiVersion':'chaos-mesh.org/v1alpha1','kind':'PodChaos','metadata':{'name':name,'namespace':namespace},'spec':{'action':'container-kill','mode':'all','containerNames':[container],'selector':{'namespaces':[namespace],'pods':{namespace:[pod]}}}}

def require_same_destination(before,after,pvc_before,pvc_after):
    require(before['pod_uid']==after['pod_uid'] and pvc_before==pvc_after,'destination Pod/PVC replaced')
    require(before['container_id']!=after['container_id'] and before['kind_process']!=after['kind_process'],'no new destination process')
    old=after['last_terminated'];require(old and old['containerID']==before['container_id'] and old['exitCode']==137,'exact Chaos-killed container exit absent')

# Per-cell installer JSON/selection assertions intentionally await the finalized root CLI contract.
# This module supplies no runnable acceptance command and cannot grant acceptance on its own.
