#!/usr/bin/env python3
"""Finite test-only offline destination installation; no serving/learner admission."""
import argparse,hashlib,json,os,secrets,selectors,signal,subprocess,tarfile,time,urllib.parse
from pathlib import Path
from types import SimpleNamespace
import transport as T
P=T.BASE; PREP=T.PREP; require=T.require; save=T.save; sha=T.source.sha
GIB=1024**3; MIB=1024**2
STEPS=[None,'after-engine','after-protocol','before-selector','after-selector-rename','after-selector-sync','before-selector']

def pin(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def allocated(p): return sum(x.lstat().st_blocks*512 for x in p.rglob('*') if x.is_file())
def bundle_manifest(b):
    # Snapshot protobuf data field 1; tolerate other supported protobuf wire fields.
    def varint(i):
        n=0
        for s in range(0,70,7):
            require(i<len(b),'truncated protobuf');v=b[i];i+=1;n|=(v&127)<<s
            if not v&128:return n,i
        raise ValueError('oversized protobuf varint')
    i=0;data=[]
    while i<len(b):
        tag,i=varint(i);wire=tag&7
        if wire==2:
            n,i=varint(i);require(i+n<=len(b),'protobuf bounds');part=b[i:i+n];i+=n
            if tag>>3==1:data.append(part)
        elif wire==0: _,i=varint(i)
        elif wire in (1,5): i+=8 if wire==1 else 4
        else:raise ValueError('unexpected protobuf wire')
    require(len(data)==1 and data[0][:8]==b'KV9DIMG1','snapshot image framing')
    d=data[0];n=int.from_bytes(d[8:12],'big');m=d[12+n:];magic=b'KV9CHECKPOINT\x01'
    require(m.startswith(magic),'checkpoint framing');return json.loads(m[len(magic):])

class Gate(T.source.Gate):
    def __init__(self,out):
        self.a=SimpleNamespace(kubectl=Path('/usr/local/bin/kubectl'),kubeconfig=Path('/mnt/data/kv9-work/chaos-tools-20260915-first/kubeconfig'))
        self.out=out;out.mkdir(exist_ok=False);os.chmod(out,0o700)
        self.started=time.monotonic();self.commands=0;self.samples=[];self.clients=[];self.cids=set();self.host_processes={};self.faults=[];self.cells=[];self.uid=None
        self.ns='kv9-joint-install-'+str(int(time.time()))+'-'+secrets.token_hex(3)
        self.kind_node='kv9-chaos-ci-p0-20260908-control-plane';self.baselines=self.space();self.target_bytes=0
        self.minio=json.loads((P/'minio-first/identity.json').read_text());self.image=json.loads((P/'chaos-image-third/result.json').read_text())
        self.source_before=json.loads((P/'chaos-image-third/source-after.json').read_text());self.checker=T.checker;self.child=None
        self.guard()
    def guard(self,launch=False):
        now=self.space();seen=set();decline=0
        for k,v in now.items():
            require(v['device']==self.baselines[k]['device'] and v['available_bytes']>=8*GIB,'filesystem floor/device')
            if v['device'] not in seen:decline+=max(0,self.baselines[k]['available_bytes']-v['available_bytes']);seen.add(v['device'])
        local=allocated(self.out);remote=allocated(P/'minio-first/data')
        require(local<=512*MIB and remote<=256*MIB and self.target_bytes<=128*MIB,'component allocation cap')
        require(local+remote+self.target_bytes<=GIB and decline<=GIB,'combined allocation/decrease cap')
        require(time.monotonic()-self.started<=1200,'campaign deadline')
        self.samples.append({'observed_ns':time.time_ns(),'filesystems':now,'local_bytes':local,'minio_bytes':remote,'target_bytes':self.target_bytes,'combined_decline':decline})
    def source_check(self,label):
        changes=[]
        for name,row in self.source_before.items():
            if name=='crates/raft/src/snapshot_install/tests.rs':continue
            p=Path('/home/dongxu/kv9')/name
            if not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:changes.append(name)
        save(self.out/(label+'-source-check.json'),{'complete':not changes,'changes':changes,'excluded_concurrent_cfg_test_file':'crates/raft/src/snapshot_install/tests.rs'})
        require(not changes,'production/probe source changed; requalification required')
    def current(self,pod='destination',container='installer'):
        row=T.current_container(self,pod,container)
        if row:self.cids.add(row['container_id']);self.host_processes[row['container_id']]=row['kind_process']
        return row
    def remember(self,label):
        save(self.out/(label+'-owned.json'),{'namespace':self.ns,'namespace_uid':self.uid,'pvc_uid':getattr(self,'pvc',None),'container_processes':self.host_processes,'faults':self.faults})
    def prepare(self):
        self.source_check('before')
        require(sha(Path(self.image['probe']['path']))==self.image['probe']['sha256'],'probe changed')
        self.protected={x['metadata']['name']:x['metadata']['uid'] for x in self.get('namespaces',ns=False)['items']}
        require(len(self.protected)==8,'historical namespace count changed')
        self.protected_faults=self.k(['get','podchaos,networkchaos,iochaos','-A','-o','json']).stdout
        save(self.out/'protected.json',{'namespaces':self.protected,'faults':self.fault_ids(json.loads(self.protected_faults))})
        self.apply({'apiVersion':'v1','kind':'Namespace','metadata':{'name':self.ns,'annotations':{'chaos-mesh.org/inject':'enabled'},'labels':{'kv9-fixture':'joint-install-d03'}}})
        self.uid=self.get('namespace',self.ns,ns=False)['metadata']['uid'];self.remember('namespace')
        creds=json.loads((P/'minio-first/private-credentials.json').read_text())
        self.apply({'apiVersion':'v1','kind':'Secret','metadata':{'name':'object-store','namespace':self.ns},'stringData':{'KV9_OBJECT_STORE_ENDPOINT':self.minio['endpoint'],'KV9_OBJECT_STORE_BUCKET':self.minio['bucket'],'KV9_OBJECT_STORE_ACCESS_KEY':creds['access_key'],'KV9_OBJECT_STORE_SECRET_KEY':creds['secret_key']}},secret=True)
        self.apply({'apiVersion':'v1','kind':'PersistentVolumeClaim','metadata':{'name':'target-store','namespace':self.ns},'spec':{'accessModes':['ReadWriteOnce'],'storageClassName':'standard','resources':{'requests':{'storage':'256Mi'}}}})
        self.apply(self.pod('destination','installer'))
        self.k(['wait','-n',self.ns,'--for=condition=Ready','pod/destination','--timeout=60s'],timeout=65)
        self.pvc=self.get('pvc','target-store')['metadata']['uid'];self.pod_uid=self.get('pod','destination')['metadata']['uid']
        self.initial=self.wait('destination process',self.current)
        image=self.get('pod','destination')['status']['containerStatuses'][0]
        require(image['image'] in (self.image['image'],'docker.io/library/'+self.image['image']),'Pod image role')
        probe_sum=self.exec('destination',['sha256sum','/usr/local/bin/joint-install-probe']).stdout.decode().split()[0]
        require(probe_sum==self.image['probe']['sha256'],'Pod probe ELF differs')
        self.remember('prepared');save(self.out/'setup.json',{'namespace':self.ns,'namespace_uid':self.uid,'pvc_uid':self.pvc,'pod_uid':self.pod_uid,'initial':self.initial,'image':self.image,'minio':self.minio,'test_only':True,'serving':False})
    def pod(self,name,container):
        return {'apiVersion':'v1','kind':'Pod','metadata':{'name':name,'namespace':self.ns,'labels':{'kv9-fixture':'joint-install-d03'}},'spec':{'restartPolicy':'Always','terminationGracePeriodSeconds':1,'containers':[{'name':container,'image':self.image['image'],'imagePullPolicy':'Never','command':['sleep','1200'],'envFrom':[{'secretRef':{'name':'object-store'}}],'resources':{'limits':{'memory':'512Mi','cpu':'1'},'requests':{'memory':'64Mi','cpu':'100m'}},'volumeMounts':[{'name':'store','mountPath':'/data'}]}],'volumes':[{'name':'store','persistentVolumeClaim':{'claimName':'target-store'}}]}}
    def call(self,cell,label,mode,store,bundle):
        p=self.exec('destination',['/usr/local/bin/joint-install-probe',mode,store,bundle],timeout=120)
        lines=p.stdout.splitlines();require(len(lines)==1,'probe output framing');v=json.loads(lines[0]);save(cell/(label+'.json'),v);return v
    def selected(self,v,seed,index):
        require(v['status']=='selected' and v['term']==3 and v['index']==index and v['target_node']==4 and v['target_incarnation']==seed['target_incarnation'] and v['records']==(4 if index==10 else 5) and v['values_verified'] is True and v['serving'] is False,'selected destination/cut/data mismatch')
    def manifest_and_objects(self,cell,bundle):
        old=self.exec('destination',['cat',bundle.rsplit('.',1)[0]+'.old']).stdout;new=self.exec('destination',['cat',bundle]).stdout
        (cell/'old.bundle').write_bytes(old);(cell/'new.bundle').write_bytes(new)
        manifests=[bundle_manifest(old),bundle_manifest(new)];save(cell/'source-manifests.json',manifests)
        require([x['index'] for x in manifests]==[10,20] and all(x['term']==3 for x in manifests),'seed manifest cuts')
        require(manifests[0]['scope']==manifests[1]['scope'],'seed manifest source scope')
        creds=json.loads((P/'minio-first/private-credentials.json').read_text())
        parsed=urllib.parse.urlsplit(self.minio['endpoint']);env=os.environ.copy();env['MC_HOST_joint']=parsed.scheme+'://'+urllib.parse.quote(creds['access_key'],safe='')+':'+urllib.parse.quote(creds['secret_key'],safe='')+'@'+parsed.netloc
        objects={};(cell/'objects').mkdir()
        for m in manifests:
            for f in m['files']:
                key=f['key'];require(key.startswith(m['scope']['cluster']+'/') or m['scope']['cluster'] in key,'object source prefix')
                if key in objects:continue
                require(0<f['size']<=48*MIB,'object length cap')
                r=self.command(['docker','exec','--env','MC_HOST_joint',self.minio['id'],'mc','cat','joint/'+self.minio['bucket']+'/'+key],env=env)
                require(len(r.stdout)==f['size'] and hashlib.sha256(r.stdout).hexdigest()==f['sha256'],'MinIO complete object hash/length')
                path=cell/'objects'/f['sha256'];path.write_bytes(r.stdout);objects[key]=dict(f,path=str(path.relative_to(self.out)))
        save(cell/'objects.json',list(objects.values()));return old,new
    def tree(self,cell,label,store):
        r=self.exec('destination',['/bin/bash','-c','cd "$1" && find . -type f -print0 | sort -z | xargs -0 sha256sum','tree',store]);(cell/(label+'-files.sha256')).write_bytes(r.stdout)
        size=self.exec('destination',['du','-s','-B1','/data']).stdout;self.target_bytes=int(size.split()[0]);self.guard()
    def run_cell(self,n,pause):
        self.guard();name=f'{n:02d}-'+(pause or 'uncut')+('-initial-empty' if n==6 else '');cell=self.out/name;cell.mkdir();store='/data/'+name+'/store';bundle='/data/'+name+'/snapshot.new'
        self.exec('destination',['mkdir','-p',store]);seed=self.call(cell,'seed','seed',store,bundle)
        require(seed['status']=='seeded' and seed['old_cut']==10 and seed['new_cut']==20 and seed['target_node']==4,'seed schema')
        empty=n==6;old=None
        if not empty:old=self.call(cell,'old-install','install',store,bundle.rsplit('.',1)[0]+'.old');self.selected(old,seed,10)
        oldbytes,newbytes=self.manifest_and_objects(cell,bundle);self.tree(cell,'before-new',store)
        self.exec('destination',['test','!','-e',store+'/observations/pause.json'])
        before=self.wait('current destination process',self.current);pvc=self.get('pvc','target-store')['metadata']['uid']
        if pause:
            argv=self.kargs(['exec','-n',self.ns,'destination','--','/usr/local/bin/joint-install-probe','install',store,bundle,pause])
            stdout=(cell/'install.stdout').open('xb');stderr=(cell/'install.stderr').open('xb');self.child=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True)
            save(cell/'install-invocation.json',{'argv':argv,'pid':self.child.pid,'started_ns':time.time_ns()})
            def marker():
                require(self.child.poll() is None,'installer ended before pause')
                r=self.exec('destination',['/bin/bash','-c','test ! -f "$1" || cat "$1"','marker',store+'/observations/pause.json'])
                return json.loads(r.stdout) if r.stdout else None
            event=self.wait('fsynced pause marker',marker,120)
            require(event['step']==pause and event['bundle_sha256']==hashlib.sha256(newbytes).hexdigest() and event['target_incarnation']==seed['target_incarnation'] and event['term']==3 and event['index']==20,'pause authority mismatch')
            event['process']=self.remote_identity('destination',event['pid']);save(cell/'pause.json',event)
            self.tree(cell,'paused',store)
            faultname='kill-'+str(n);self.apply(T.scoped_kill_manifest(self.ns,'destination','installer',faultname));fault=self.get('podchaos',faultname);self.faults.append({'name':faultname,'uid':fault['metadata']['uid']});save(cell/'fault-created.json',fault);self.remember('fault-'+str(n))
            def injected():
                f=self.get('podchaos',faultname)
                return f if any(c['type']=='AllInjected' and c['status']=='True' for c in f.get('status',{}).get('conditions',[])) else None
            observed=self.wait('actual Chaos injection',injected,45);save(cell/'fault-injected.json',observed)
            rc=self.child.wait(timeout=30);stdout.close();stderr.close();save(cell/'install-terminal.json',{'pid':self.child.pid,'exit_code':rc,'finished_ns':time.time_ns()});require(rc==137,'killed installer transport must report 137');self.child=None
            def restarted():
                v=self.current()
                return v if v and v['container_id']!=before['container_id'] else None
            # Six kills on one persistent Pod grow kubelet's crash backoff to
            # minutes; the bounded wait must cover it (campaign deadline still applies).
            after=self.wait('new target container lifetime',restarted,360);T.require_same_destination(before,after,pvc,self.get('pvc','target-store')['metadata']['uid'])
            require(self.host_process(before['kind_process']['pid'])!=before['kind_process'],'old exact container process alive')
            require(not self.remote_same('destination',event['process']),'old exact probe process alive')
            save(cell/'restart.json',{'before':before,'after':after,'pvc_uid':pvc,'old_kind_process_absent':True,'old_probe_process_absent':True})
            require(self.get('podchaos',faultname)['metadata']['uid']==fault['metadata']['uid'],'fault UID replaced')
            self.k(['delete','podchaos',faultname,'-n',self.ns,'--wait=true','--timeout=30s'],timeout=35)
            absent=self.k(['get','podchaos',faultname,'-n',self.ns,'-o','json'],allow=(1,));require(absent.returncode==1 and b'NotFound' in absent.stderr,'fault absence missing');save(cell/'fault-deleted.json',{'uid':fault['metadata']['uid'],'absent':True})
        else:
            installed=self.call(cell,'new-install','install',store,bundle);self.selected(installed,seed,20)
        recovered=self.call(cell,'recovery','recover',store,bundle)
        expected=None if empty else 20 if pause in (None,'after-selector-rename','after-selector-sync') else 10
        if expected is None:require(recovered=={'status':'pending','serving':False},'initial empty recovered a selector')
        else:
            self.selected(recovered,seed,expected)
            if expected==10:require(recovered['generation']==old['generation'],'prepublication generation changed')
            if pause and expected==20:require(recovered['generation']==event['generation'],'published generation mismatch')
            retry=self.call(cell,'same-bundle-retry','install',store,bundle if expected==20 else bundle.rsplit('.',1)[0]+'.old')
            require(retry==recovered,'same bundle retry changed generation/image/cut/data')
        self.tree(cell,'recovered',store)
        result={'complete':True,'cell':name,'pause':pause,'initial_empty':empty,'expected_index':expected,'recovered':recovered,'scope':'process kill on one persistent destination; no host power loss or serving'};save(cell/'result.json',result);self.cells.append(result);print(json.dumps(result),flush=True)
    def archive(self):
        before=self.current();require(self.get('pod','destination')['metadata']['uid']==self.pod_uid,'stop Pod UID mismatch')
        self.k(['delete','pod','destination','-n',self.ns,'--wait=true','--timeout=40s'],timeout=45)
        self.wait('last destination process stopped',lambda:self.host_process(before['kind_process']['pid'])!=before['kind_process'],15)
        self.apply(self.pod('archive','archive'));self.k(['wait','-n',self.ns,'--for=condition=Ready','pod/archive','--timeout=45s'],timeout=50);self.wait('archive process',lambda:self.current('archive','archive'))
        output=self.out/'store.tar';argv=self.kargs(['exec','-n',self.ns,'archive','--','tar','-C','/data','-cf','-','.']);err=(self.out/'archive.stderr').open('xb');child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=err,start_new_session=True);total=0;start=time.monotonic();selector=selectors.DefaultSelector();selector.register(child.stdout,selectors.EVENT_READ)
        try:
            with output.open('xb') as f:
                while selector.get_map():
                    self.guard();require(time.monotonic()-start<=120,'archive deadline')
                    for key,_ in selector.select(.5):
                        b=os.read(key.fileobj.fileno(),MIB)
                        if not b:selector.unregister(key.fileobj);continue
                        total+=len(b);require(total<=128*MIB,'archive size cap');f.write(b)
                f.flush();os.fsync(f.fileno())
            require(child.wait(timeout=10)==0,'archive transport failed')
        finally:
            if child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
            err.close();child.stdout.close();selector.close();save(self.out/'archive-terminal.json',{'argv':argv,'pid':child.pid,'exit_code':child.returncode,'bytes':total})
        members={}
        with tarfile.open(output,'r:') as t:
            for m in t:
                key=m.name.removeprefix('./');require(key not in members and (m.isdir() or m.isfile()) and not key.startswith('/') and '..' not in Path(key).parts,'unsafe archive member')
                members[key]={'directory':True} if m.isdir() else {'bytes':m.size,'sha256':hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()}
        entry={'file':output.name,'pvc_uid':self.pvc,'bytes':total,'sha256':sha(output),'members':members,'child_exit_code':child.returncode};T.complete_archive_readback(output,entry);save(self.out/'archive.json',entry)
    def run(self):
        try:
            self.prepare()
            for n,pause in enumerate(STEPS):self.run_cell(n,pause)
            self.source_check('after');self.archive();save(self.out/'runtime-result.json',{'complete':True,'cells':self.cells,'cleanup_complete':False})
            import check
            save(self.out/'independent-before-cleanup.json',check.audit(self.out,False))
            self.cleanup();save(self.out/'accepted.json',{'complete':True,'cells':len(self.cells),'cleanup_complete':True,'serving':False})
        except BaseException as e:
            if self.child and self.child.poll() is None:
                os.killpg(self.child.pid,signal.SIGTERM)
                try:self.child.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(self.child.pid,signal.SIGKILL);self.child.wait()
            save(self.out/'failure.json',{'complete':False,'error':repr(e),'namespace':self.ns,'namespace_uid':self.uid,'completed_cells':self.cells,'resources_retained':True});raise
        finally:
            self.remember('final');save(self.out/'resource-samples.json',self.samples)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();Gate(a.output).run()
