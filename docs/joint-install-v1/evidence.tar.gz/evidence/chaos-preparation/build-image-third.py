import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
P=Path('/mnt/data/kv9-work/joint-install-20260916'); R=Path('/home/dongxu/kv9'); O=P/'chaos-image-third';O.mkdir()
def pin(p):
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
def save(n,v): (O/n).write_text(json.dumps(v,indent=2)+'\n')
def sources():
 paths=[p for p in R.rglob('*.rs') if 'target' not in p.parts and '.git' not in p.parts]
 paths += [R/'Cargo.toml',R/'Cargo.lock',*R.glob('crates/*/Cargo.toml')]
 return {str(p.relative_to(R)):pin(p) for p in sorted(paths)}
source=sources();save('source-before.json',source)
context=O/'context';context.mkdir();(context/'usr/local/bin').mkdir(parents=True)
probe=P/'chaos-image-first/context/usr/local/bin/joint-install-probe'; original=pin(probe)
shutil.copy2(probe,context/'usr/local/bin/joint-install-probe')
ldd=subprocess.run(['ldd',str(probe)],capture_output=True,check=True,text=True);(O/'ldd.txt').write_text(ldd.stdout)
libs=['/lib/x86_64-linux-gnu/libgcc_s.so.1','/lib/x86_64-linux-gnu/libm.so.6','/lib/x86_64-linux-gnu/libc.so.6','/lib64/ld-linux-x86-64.so.2','/etc/ssl/certs/ca-certificates.crt']
for name in libs:
 dest=context/name.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(name,dest)
(context/'Dockerfile').write_text('FROM ubuntu@sha256:224a1869083a311ef3f13648a154ba79832fbef6364d31493642ca03082da254\nCOPY usr /usr\nCOPY lib /lib\nCOPY lib64 /lib64\nCOPY etc /etc\nCMD ["sleep", "1200"]\n')
retained=pin(context/'usr/local/bin/joint-install-probe'); image='kv9-joint-install:d03-'+retained['sha256'][:12]
save('binding.json',{'test_only':True,'features':['testing'],'original_probe':original,'retained_probe':retained,'libs':[pin(Path(x)) for x in libs],'image':image,'context':[pin(x) for x in sorted(context.rglob('*')) if x.is_file()]})
commands=[['docker','build','--network=none','--pull=false','-t',image,str(context)],['/mnt/data/kv9-work/chaos-tools-20260915-first/kind','load','docker-image','--name','kv9-chaos-ci-p0-20260908',image],['docker','image','inspect','--format','{{.Id}}',image]]
for i,argv in enumerate(commands):
 start=time.time_ns()
 with (O/f'command-{i}.stdout').open('xb') as out,(O/f'command-{i}.stderr').open('xb') as err:
  p=subprocess.Popen(argv,stdout=out,stderr=err);rc=p.wait(timeout=180)
 save(f'command-{i}.json',{'argv':argv,'pid':p.pid,'exit_code':rc,'started_ns':start,'finished_ns':time.time_ns()})
 if rc:raise RuntimeError(f'image command{i} failed')
after=sources();save('source-after.json',after);changes=[k for k in source.keys()|after.keys() if source.get(k)!=after.get(k)]
assert all(x=='crates/raft/src/snapshot_install/tests.rs' for x in changes),changes
assert pin(probe)==original
save('result.json',{'complete':True,'image':image,'image_id':(O/'command-2.stdout').read_text().strip(),'probe':retained,'source_changes':changes,'test_only':True,'source_contract':'Production and probe byte-identical; concurrently qualified cfg(test) fixture tracked separately.'})
print(json.dumps({'complete':True,'image':image,'output':str(O)}))
