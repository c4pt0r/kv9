#!/usr/bin/env python3
"""Create only a fresh bounded D03 MinIO fixture; no destination process or fault."""
import hashlib,json,os,secrets,subprocess,time,urllib.request
from pathlib import Path
BASE=Path('/mnt/data/kv9-work/joint-install-20260916');OUT=BASE/'minio-first';IMAGE='quay.io/minio/minio@sha256:14cea493d9a34af32f524e538b8346cf79f3321eff8e708c1e2960462bd8936e'
EXPECTED='sha256:69b2ec208575b69597784255eec6fa6a2985ee9e1a47f4411a51f7f5fdd193a9'
def save(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def need(x,m):
    if not x:raise RuntimeError(m)
OUT.mkdir();os.chmod(OUT,0o700);data=OUT/'data';data.mkdir(mode=0o700)
started=time.monotonic();count=0
baseline={str(p):(p.stat().st_dev,os.statvfs(p).f_bavail*os.statvfs(p).f_frsize) for p in [Path('/'),OUT]}
def guard():
    need(time.monotonic()-started<180,'setup deadline');delta=0;seen=set()
    for name,(dev,free) in baseline.items():
        p=Path(name);now=os.statvfs(p).f_bavail*os.statvfs(p).f_frsize;need(p.stat().st_dev==dev and now>=8*1024**3,'device/free space')
        if dev not in seen:delta+=max(0,free-now);seen.add(dev)
    need(delta<=1024**3,'setup allocation envelope')
def cmd(argv,env=None,timeout=30):
    global count
    guard();count+=1;prefix=OUT/f'command-{count:03d}';start=time.time_ns();r=subprocess.run(argv,capture_output=True,env=env,timeout=timeout)
    need(len(r.stdout)<=8*1024**2 and len(r.stderr)<=1024**2,'command output bound');prefix.with_suffix('.stdout').write_bytes(r.stdout);prefix.with_suffix('.stderr').write_bytes(r.stderr)
    save(prefix.with_suffix('.json'),{'argv':argv,'exit_code':r.returncode,'started_ns':start,'finished_ns':time.time_ns(),'secret_environment_values_omitted':env is not None});need(r.returncode==0,'command failed');return r.stdout
try:
    im=json.loads(cmd(['docker','image','inspect',IMAGE]))[0];need(im['Id']==EXPECTED,'MinIO image pin')
    old=json.loads(cmd(['docker','ps','-a','--format','json']).decode().replace('}\n{','},\n{').join(['[',']'])) if False else None
    before=cmd(['docker','ps','-a','--format','{{.ID}} {{.Names}} {{.Status}}']).decode();save(OUT/'existing-containers.json',{'rows':before.splitlines()})
    nonce=secrets.token_hex(6);name='kv9-joint-install-minio-'+nonce;bucket='kv9-joint-install-'+nonce
    access='kv9'+secrets.token_hex(12);secret=secrets.token_hex(32)
    private=OUT/'private.env'
    with private.open('x') as f:f.write('MINIO_ROOT_USER='+access+'\nMINIO_ROOT_PASSWORD='+secret+'\n')
    private.chmod(0o600)
    argv=['docker','run','--detach','--name',name,'--label','kv9.fixture=joint-install-d03','--label','kv9.owner='+nonce,'--network','kind','--mount','type=bind,source='+str(data)+',target=/data','--env-file',str(private),'--memory','512m','--memory-swap','512m','--cpus','1','--pids-limit','128',IMAGE,'server','/data']
    cid=cmd(argv).decode().strip();need(len(cid)==64,'container ID');save(OUT/'created.json',{'container':name,'id':cid,'owner':nonce,'image_id':EXPECTED,'data':str(data),'bucket':bucket})
    # Inspect contains credentials. Retain selected identity/network fields only.
    q=subprocess.run(['docker','inspect',cid],capture_output=True,timeout=15);need(q.returncode==0,'container inspect');d=json.loads(q.stdout)[0]
    need(d['Id']==cid and d['Config']['Labels']['kv9.owner']==nonce and d['Image']==EXPECTED,'created container binding')
    ip=d['NetworkSettings']['Networks']['kind']['IPAddress'];endpoint='http://'+ip+':9000'
    identity={'container':name,'id':cid,'owner':nonce,'image_id':EXPECTED,'endpoint':endpoint,'bucket':bucket,'data':str(data),'host_pid':d['State']['Pid'],'memory_limit':d['HostConfig']['Memory'],'cpu_nanos':d['HostConfig']['NanoCpus'],'pids_limit':d['HostConfig']['PidsLimit'],'started_at':d['State']['StartedAt']};save(OUT/'identity.json',identity)
    with (OUT/'private-credentials.json').open('x') as f:json.dump({'access_key':access,'secret_key':secret},f);f.write('\n')
    (OUT/'private-credentials.json').chmod(0o600)
    health=[];end=time.monotonic()+30
    while time.monotonic()<end:
        guard()
        try:
            with urllib.request.urlopen(endpoint+'/minio/health/live',timeout=2) as r:status=r.status
            health.append({'observed_ns':time.time_ns(),'http_status':status})
            if status==200:break
        except Exception as e:health.append({'observed_ns':time.time_ns(),'error_type':type(e).__name__})
        time.sleep(.3)
    else:raise RuntimeError('new MinIO health deadline')
    save(OUT/'host-health.json',health)
    cmd(['docker','exec','kv9-chaos-ci-p0-20260908-control-plane','curl','--fail','--silent','--show-error','--connect-timeout','2','--max-time','3',endpoint+'/minio/health/live'])
    # CLI sees only the env variable name. Secret-bearing value is never part of argv/logs.
    env=dict(os.environ,MC_HOST_joint='http://'+access+':'+secret+'@127.0.0.1:9000')
    cmd(['docker','exec','--env','MC_HOST_joint',cid,'mc','mb','joint/'+bucket],env=env)
    listing=json.loads(cmd(['docker','exec','--env','MC_HOST_joint',cid,'mc','stat','--json','joint/'+bucket],env=env));need(listing['status']=='success','bucket stat');save(OUT/'bucket-readback.json',listing)
    save(OUT/'result.json',{'complete':True,'scope':'Fresh bounded MinIO service readiness only; no installer/Pod/fault acceptance.','identity':identity,'host_health':True,'kind_node_health':True,'new_bucket_exists':True,'credential_availability':'Two private mode0600 files retained locally; never select them for publication.','existing_containers_untouched':True,'target_store':'Not created; future PVC explicitly Docker-/var backed.'})
except BaseException as e:
    save(OUT/'failure.json',{'complete':False,'error':repr(e),'owned_container_may_remain':True});raise
