import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import time

SOURCE = Path('/home/dongxu/kv9')
OUT = Path('/tmp/kv9-lease-vote-binding-source-first')
os.environ.update(CARGO_TARGET_DIR='/home/dongxu/kv9/target', CARGO_BUILD_JOBS='4',
                  CARGO_NET_OFFLINE='true')

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def main():
    OUT.mkdir()
    spec = importlib.util.spec_from_file_location('lease_builder', SOURCE / 'scripts/build-workload.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    before = builder.snapshot()
    save(OUT / 'sources-before.json', before)
    result = {'complete': False, 'source_root': str(SOURCE), 'commands': []}
    commands = [
        ('format', ['cargo', 'fmt', '--all', '--', '--check'], False),
        ('default-compile', ['cargo', 'test', '--locked', '-p', 'kv9-raft', '--lib', '--no-run',
                             '--message-format=json-render-diagnostics'], True),
        ('default-tests', ['cargo', 'test', '--locked', '-p', 'kv9-raft', '--lib', '--', '--test-threads=4'], False),
        ('experimental-check', ['cargo', 'check', '--locked', '-p', 'kv9-raft', '--features',
                                 'experimental-leader-lease', '--message-format=json-render-diagnostics'], True),
        ('experimental-clippy', ['cargo', 'clippy', '--locked', '-p', 'kv9-raft', '--all-targets',
                                  '--features', 'experimental-leader-lease', '--', '-D', 'warnings'], False),
    ]
    save(OUT / 'commands.json', commands)
    try:
        with builder.cache.BuildCache(SOURCE, OUT, False, before) as cache:
            for name, command, artifact_check in commands:
                row = {'name': name, 'argv': command, 'started_ns': time.time_ns()}
                result['commands'].append(row)
                save(OUT / 'result.json', result)
                print(name, 'started', flush=True)
                with (OUT / (name + '.stdout')).open('x') as stdout, (OUT / (name + '.stderr')).open('x') as stderr:
                    code = cache.run(command, stdout=stdout, stderr=stderr, timeout=1200).returncode
                row.update(exit_code=code, ended_ns=time.time_ns())
                if artifact_check:
                    cache.check_artifacts(OUT / (name + '.stdout'))
                if name == 'default-compile':
                    artifacts = [json.loads(line) for line in (OUT / (name + '.stdout')).read_text().splitlines()]
                    binaries = [r['executable'] for r in artifacts if r.get('reason') == 'compiler-artifact'
                                and r.get('executable') and r['target']['name'] == 'kv9_raft']
                    assert len(binaries) == 1, binaries
                    binary = Path(binaries[0])
                    assert binary.stat().st_size <= 512 * 1024**2
                    shutil.copy2(binary, OUT / 'raft-tests')
                    assert builder.sha(binary.read_bytes()) == builder.sha((OUT / 'raft-tests').read_bytes())
                    row['test_binary_sha256'] = builder.sha(binary.read_bytes())
                if name == 'default-tests':
                    output = (OUT / (name + '.stdout')).read_text()
                    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
                    assert len(matches) == 1 and int(matches[0][0]) > 25 and matches[0][1] == '0', matches
                    row['test_result'] = matches[0]
                    assert matches[0] == ('219', '0', '0'), matches
                    assert len(re.findall(r'^test rawnode::lease_gate::tests::\w+ \.\.\. ok$', output, re.M)) == 10
                    assert len(re.findall(r'^test lease::tests::\w+ \.\.\. ok$', output, re.M)) == 25
                if builder.snapshot() != before:
                    raise RuntimeError('Lease vote binding source changed during checks')
                save(OUT / 'result.json', result)
                print(name, 'passed', flush=True)
        result['complete'] = True
        save(OUT / 'sources-after.json', builder.snapshot())
    except BaseException as error:
        result['failure'] = repr(error)
        raise
    finally:
        save(OUT / 'result.json', result)

if __name__ == '__main__':
    main()
