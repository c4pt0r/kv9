# Exact cold preservation of eleven retained test executables

The one authorized conversion completed: **session 36872, exit 0, terminal receipt 3c472a**. PID 3280601 was absent after the actual tool terminal. All commands were restricted to helper CPUs 6–7. No Cargo, tests, benchmarks, repository edits or target/cache mutations occurred. No command failed and no conversion was repeated.

Eleven originals total **215,435,984 logical bytes / 215,461,888 allocated bytes**. Retained gzip archives total **67,360,853 logical bytes / 67,395,584 allocated bytes**. Exclusive payload allocation saving is **148,066,304 bytes**. Observed filesystem free rose **147,890,176 bytes**, from 102,949,576,704 to **103,097,466,880 bytes**. That observation exceeds the unchanged required 96 GiB by **18,251,776 bytes**; root must still use its own fresh source-build preflight. Concurrent filesystem activity is not assigned to this conversion.

The guard retained at least 80 GiB free during sampled reads/writes and refused compressed writes that would cross that floor or the 4 GiB preparation/archive cap, including write margin. Final preparation allocation was 67,592,192 bytes. All current and earlier unrelated cold archives remain retained.

Two privileged process-reference scans bracketed archival and eviction. They checked matching executable/open-file inodes and mapped paths, found no live references or visibility errors, and excluded inspected selected runtime server/client inode aliases. Every original had one hardlink, matched the original census identity, and matched its existing test-binary SHA. Each controller `src/lease.rs` also matched its retained `source_sha256`; the 219-test binary matches the original default-compile receipt.

Each gzip was independently decoded through EOF with exact original length/hash, then the original file and archive were rehashed before any removal. Original identities were rechecked immediately before unlink. All protected sibling source/log/config/result files and the controls summary were hash/identity checked before and after. Mutation failures remain recorded as their original expected or actual outcomes; this retention operation claims no new correctness acceptance. Only the eleven selected executables were removed.

| Original path | Archive | Original SHA-256 | Archive SHA-256 |
|---|---|---|---|
| `/tmp/kv9-lease-vote-binding-source-first/raft-tests` | `executable-00.gz` | `1c1bdf360062256b2300a0f4d92027989280ba5c6d7559cb592fc92b2b40092c` | `07b911e84e9501345e3e6ab2ca88fe2193c0682c60a0d9235f635d23aef629ba` |
| `/tmp/kv9-lease-controller-controls-first/early-view/controller-tests` | `executable-01.gz` | `bb70152feffeb79fa8707b36f2dc7015c6e2fddc4b44147256403f64b52d49ab` | `e8d77f0196f00e15af8d4aee21e6e25d8e3b3c6edc991b648e5bc7fbb3d6525d` |
| `/tmp/kv9-lease-controller-controls-first/extend-ticket-expiry/controller-tests` | `executable-02.gz` | `fbec0de9bd1cd2bf3828a4ed61490bcc36309b6b124798cb3515a49a8910fb07` | `b97aa06e762851d59e6eed86fe97b2ab54595a139672621f654b825605137056` |
| `/tmp/kv9-lease-controller-controls-first/lost-quarantine/controller-tests` | `executable-03.gz` | `37be82740688d4c59edf57435e3bbcd68f190901a5a23ad37f495c6fb20077a6` | `af9f8d077391ecb23acda3a0ce285795bab773ba8a7d8116fe69df40b35cf21e` |
| `/tmp/kv9-lease-controller-controls-first/missing-generation/controller-tests` | `executable-04.gz` | `3029032b38c791714872356bd0ef263f3be54c6c983d561220b0a3ba785d6ed3` | `890b6bffc28d1963c6bccfcfed3f34177d13bc5e32468ad4ca41006101a25441` |
| `/tmp/kv9-lease-controller-controls-first/mix-round-acks/controller-tests` | `executable-05.gz` | `7e6844e0b8c5f0e06f52312cc02b7c25109b3655372a737b9eccc91774d66f80` | `9ed1252dc711de4c8a16e52bd52218ab91abc96be43d5b72c3739924540bed49` |
| `/tmp/kv9-lease-controller-controls-first/publish-without-quorum/controller-tests` | `executable-06.gz` | `4f1764eb14f68f1031af7dbac52cbfb4942af02eeea2f16ecfef6ccd899e2233` | `349586b72102a89d35ded5a5baefab156177d260f8e1762bf94812c6a07a54db` |
| `/tmp/kv9-lease-controller-controls-first/rust-baseline/controller-tests` | `executable-07.gz` | `79cf7bcb91d11923848d414acc4f195461e70cf342ebf3f35f6db81c99d5262c` | `e96713f79c84616fc2635aa2501d590831c11ea14867b70e45e350d75fc50c51` |
| `/tmp/kv9-lease-controller-controls-first/rust-restored/controller-tests` | `executable-08.gz` | `79cf7bcb91d11923848d414acc4f195461e70cf342ebf3f35f6db81c99d5262c` | `e96713f79c84616fc2635aa2501d590831c11ea14867b70e45e350d75fc50c51` |
| `/tmp/kv9-lease-controller-controls-first/stale-frontier/controller-tests` | `executable-09.gz` | `be1abe1dabfd9d6078709e59021aa179055701cc79f1c40836e82b40c5d14467` | `5408601976c60fe29dd887cab645cf32aa146eb23bb1b0d5c070f7e8699b0181` |
| `/tmp/kv9-lease-controller-controls-first/vote-before-hold-expiry/controller-tests` | `executable-10.gz` | `4239fb034e07d3a6565ba328f886d166ff529011ea3bad27fb686628a3eb5d09` | `1ee57e5b54be4ec252c3a8bde261f04b670576c1c3279eca9dd2016bf78e1641` |

`verified-00.json` through `verified-10.json` retain per-file original path/device/inode/size/mode/owner/timestamps, original result, source hash, archive hash and independently decoded hash/count. `invocation-first.json` binds protected source/evidence neighbors. `eviction-authority.json` precedes the individual unlink log. `terminal-first.json` binds actual terminal status to `result-first.json`; `live-handle-first.json` is historical launch metadata only.

No restore was executed. To restore a selected file:

1. Choose its `verified-NN.json` record. Recheck the protected source/result bindings, no live process references, absence of the original path and enough free space for the exact recorded original size while retaining the applicable floor. Verify the archive SHA-256.
2. Decompress that gzip into a new exclusive-created temporary file beside the original (for example `controller-tests.restore-first` or `raft-tests.restore-first`). Refuse an existing temporary path. Consume gzip through EOF, require the recorded exact original byte count/hash, and independently rehash the resulting file. Preserve any failure and partial output.
3. Apply the catalogued mode (0775), UID/GID (1000/1000), and exact original mtime from `identity.mtime_ns`; fsync the verified file. The new inode and ctime are new identities, not reproductions of the removed inode.
4. Publish without overwriting by hardlinking the verified temporary file to the exact original path (`ln` refuses an existing destination). Verify the final path bytes/mode/owner before removing only the temporary hardlink. Keep the gzip/catalog/evidence; record actual restore independently. Do not execute the restored test binary merely to establish byte identity.

The final reporting inventory references the already verified archive identities. No payload codec or original-source read was repeated while preparing this report.
