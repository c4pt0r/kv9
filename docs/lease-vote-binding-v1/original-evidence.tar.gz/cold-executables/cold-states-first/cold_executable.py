"""One authorized retained executable cold conversion; no build or test execution."""
import gzip,hashlib,json,os,stat,subprocess,sys,time,traceback
from pathlib import Path

OUT=Path('/tmp/kv9-lease-vote-binding-cold-states-first')
SOURCE=Path('/tmp/kv9-lease-controller-source-first/raft-tests')
ARCHIVE=OUT/'raft-tests.original.gz'
CAP=4*1024**3
FLOOR=80*1024**3
CHUNK=1024**2

def require(value,reason):
    if not value:raise RuntimeError(reason)

def save(name,value):
    with (OUT/name).open('x')as f:
        json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())

def ident(p):
    s=p.lstat()
    return dict(dev=s.st_dev,ino=s.st_ino,bytes=s.st_size,allocated_bytes=s.st_blocks*512,
                mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)

def guard(extra=0):
    v=os.statvfs(OUT);free=v.f_bavail*v.f_frsize
    allocation=sum(p.lstat().st_blocks*512 for p in OUT.iterdir()if p.is_file())
    require(free-extra>=FLOOR,'80 GiB free floor would be crossed')
    require(allocation+extra<=CAP,'4 GiB archive/preparation storage cap would be exceeded')
    return dict(free_bytes=free,owned_allocated_bytes=allocation,observed_ns=time.time_ns())

def sha(p):
    h=hashlib.sha256()
    with p.open('rb')as f:
        while b:=f.read(CHUNK):guard();h.update(b)
    return h.hexdigest()

def ownership(label):
    subprocess.run([sys.executable,str(OUT/f'check-executable-{label}.py')],check=True)
    result=json.loads((OUT/f'executable-use-{label}.json').read_text())
    require(result['complete']and not result['hits']and not result['errors']and result['no_selected_inode_alias'],
            'ambiguous/live/selected executable reference; deletion prohibited')

class Writer:
    def __init__(self,f):self.f=f
    def write(self,b):guard(len(b)+CHUNK);return self.f.write(b)
    def flush(self):self.f.flush()

def main():
    require(os.geteuid()==0 and set(os.sched_getaffinity(0))<={6,7},'root read-only /proc visibility and CPUs6-7 required')
    before=guard();original=ident(SOURCE)
    require(SOURCE.resolve()==SOURCE and stat.S_ISREG(original['mode'])and original['nlink']==1 and original['uid']==1000,'original executable path/ownership invalid')
    known=json.loads((OUT/'executable-census-first.json').read_text())['files']
    require(len(known)==1 and known[0]['path']==str(SOURCE),'original selection differs')
    require(all(original[k]==known[0][k]for k in ['dev','ino','bytes','allocated_bytes','nlink','uid','gid','mtime_ns','ctime_ns']),'original census identity changed')
    receipt=json.loads((SOURCE.parent/'result.json').read_text())
    expected=next(c['test_binary_sha256']for c in receipt['commands']if c['name']=='default-compile')
    require(receipt['complete']and expected=='195cf99fb917c70dba01d06ab0b1fc61afb9a58083bf26b69a1ce854d04d3cbb','original test build receipt differs')
    protected=[]
    for p in sorted(SOURCE.parent.iterdir()):
        if p==SOURCE:continue
        require(p.is_file()and not p.is_symlink()and p.stat().st_size<2*CHUNK,'unexpected source-evidence neighbor')
        protected.append(dict(path=str(p),identity=ident(p),sha256=sha(p)))
    save('binary-invocation-first.json',dict(argv=sys.argv,pid=os.getpid(),started_ns=time.time_ns(),before=before,script_sha256=sha(Path(__file__)),original_path=str(SOURCE),original_identity=original,expected_sha256=expected,protected=protected,max_archive_storage_bytes=CAP,min_free_bytes=FLOOR,cpu_affinity=sorted(os.sched_getaffinity(0))))
    ownership('before-archive')
    h=hashlib.sha256();count=0
    with SOURCE.open('rb')as src,ARCHIVE.open('xb')as raw:
        with gzip.GzipFile(filename='',mode='wb',compresslevel=1,mtime=0,fileobj=Writer(raw))as gz:
            while b:=src.read(CHUNK):guard();h.update(b);count+=len(b);gz.write(b)
        raw.flush();os.fsync(raw.fileno())
    require(count==original['bytes']and h.hexdigest()==expected and ident(SOURCE)==original,'original build binary/hash/identity mismatch')
    decoded=hashlib.sha256();decoded_count=0
    with gzip.open(ARCHIVE,'rb')as stream:
        while b:=stream.read(CHUNK):
            guard();decoded_count+=len(b);require(decoded_count<=original['bytes'],'decoded output exceeds original size');decoded.update(b)
    require(decoded_count==count and decoded.hexdigest()==expected,'exact independent decompressed byte/hash check failed')
    archive=dict(path=str(ARCHIVE),bytes=ARCHIVE.stat().st_size,allocated_bytes=ARCHIVE.stat().st_blocks*512,sha256=sha(ARCHIVE))
    require(sha(SOURCE)==expected and ident(SOURCE)==original,'original changed before eviction')
    for row in protected:require(ident(Path(row['path']))==row['identity']and sha(Path(row['path']))==row['sha256'],'protected evidence changed')
    ownership('before-eviction')
    save('binary-verified-first.json',dict(complete=True,original_path=str(SOURCE),original_identity=original,original_sha256=expected,
         archive=archive,decoded_bytes=decoded_count,decoded_sha256=decoded.hexdigest(),gzip_consumed_to_eof=True,original_rehashed_before_eviction=True,
         all_protected_evidence_unchanged=True,guard=guard(),scope='One binary, no extra archive members.'))
    require(ident(SOURCE)==original,'identity changed at unlink boundary');SOURCE.unlink()
    for row in protected:require(ident(Path(row['path']))==row['identity']and sha(Path(row['path']))==row['sha256'],'protected evidence changed after eviction')
    after=guard()
    save('binary-result-first.json',dict(complete=True,exit_code=0,ended_ns=time.time_ns(),source_absent=not SOURCE.exists(),original_path=str(SOURCE),
         original_identity=original,original_sha256=expected,archive=archive,before=before,after=after,
         observed_free_delta_bytes=after['free_bytes']-before['free_bytes'],exclusive_payload_allocation_saving=original['allocated_bytes']-archive['allocated_bytes'],
         protected_evidence_unchanged=True,required96GiB_met=after['free_bytes']>=96*1024**3,scope='Exact cold storage of one retained test executable. No test/build rerun or new correctness verdict. Observed free change may include unrelated activity.'))
    print(json.dumps(dict(complete=True,free_bytes=after['free_bytes'],archive_bytes=archive['bytes'],result=str(OUT/'binary-result-first.json'))),flush=True)

if __name__=='__main__':
    try:main()
    except BaseException as error:
        save('binary-first-failure.json',dict(complete=False,error=repr(error),traceback=traceback.format_exc(),observed_ns=time.time_ns()))
        raise
