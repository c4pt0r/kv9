# Cold preservation and restore of the retained Raft test executable

The separately authorized sole-file transaction completed once: session **51911**, exit **0**, terminal tool receipt **2ff10a**. PID 3219279 was absent afterward. The earlier no-TLC-payload and insufficient-capacity reports are retained unchanged; this later action follows root's separate cache maintenance and explicit one-binary authorization.

Original path: `/tmp/kv9-lease-controller-source-first/raft-tests`.
Original bytes: **151,077,200**; SHA-256 **195cf99fb917c70dba01d06ab0b1fc61afb9a58083bf26b69a1ce854d04d3cbb**. This hash matches the original `default-compile` record in the retained source-check `result.json`.

Archive: `/tmp/kv9-lease-vote-binding-cold-states-first/raft-tests.original.gz`.
Archive bytes: **45,367,693**; SHA-256 **afc0b01526ccd06c4f74f03ebd017f0a0877d8184a0e1f729dadd4d6188ddf3d**.

Fresh privileged ownership scans before archival and before eviction found no executable, open-file or mapped reference and no visibility errors. The inspected selected server/client executable inodes differ. The original stat identity matched the earlier census. The gzip stream was independently consumed through EOF, and the exact decoded count/hash matched the original receipt. The source binary was rehashed again before removal, with original inode/size/timestamp/owner identity unchanged. All other source-check files were hash/identity checked before and after; only this original binary was unlinked. No tests, builds, Cargo/target or repository changes occurred.

The payload allocation saving is **105,709,568 bytes**. Observed filesystem free increased **105,672,704 bytes**, from 103,004,340,224 to **103,110,012,928 bytes**. That final observation exceeds the unchanged 96 GiB preflight by **30,797,824 bytes**. Concurrent filesystem changes are not attributed to this task. All sampled free-space checks retained the 80 GiB floor; final owned preparation allocation was 45,469,696 bytes, below the unchanged 4 GiB cap.

Restore is not executed. A future exact restore should use these steps:

1. Recheck that the original path is absent and no process is using this source-check run. Check enough free space for the 151,077,200-byte restored executable while retaining the required floor. Keep the archive; verify its exact SHA-256 above. Recheck the protected source-check neighbor hashes recorded in `binary-invocation-first.json`.
2. Decompress the gzip into a **new, exclusive-created** temporary file `/tmp/kv9-lease-controller-source-first/raft-tests.restore-first`. Refuse an existing file. Do not stream directly over the original path. Consume gzip through EOF and require exactly 151,077,200 bytes and SHA-256 `195cf99fb917c70dba01d06ab0b1fc61afb9a58083bf26b69a1ce854d04d3cbb`; independently rehash the written temporary file. Preserve any first failure and its temporary file.
3. Restore mode **0775**, UID/GID **1000/1000** and original `mtime_ns` **1789238386205905726** from `binary-verified-first.json`. Flush/fsync the verified file. Original inode/device/ctime need not and cannot be recreated as an identity claim.
4. Publish without overwriting: hardlink the verified temporary file to the original `raft-tests` path (`ln` fails if the destination exists). Only after matching the final path's size/hash/mode/owner may the temporary hardlink be removed. Retain the gzip archive, catalog and receipts. Record the new identity and actual restore result separately. Restoring bytes does not rerun or enlarge the original correctness claims.

`binary-terminal-first.json` binds the actual terminal to `binary-result-first.json`. `binary-verified-first.json` records source/archive/decode identities and verification before deletion. `binary-live-handle-first.json` is the earlier launch observation, not an outstanding runtime. No command failed and no conversion was repeated.
