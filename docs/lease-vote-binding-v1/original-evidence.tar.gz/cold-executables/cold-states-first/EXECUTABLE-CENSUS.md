# Retained source-check executable census

The explicitly requested `/tmp/kv9-*-source-*/**/raft-tests` census found one retained executable copy:

| Path | Logical bytes | Allocated bytes | Identity |
|---|---:|---:|---|
| `/tmp/kv9-lease-controller-source-first/raft-tests` | 151,077,200 | 151,085,056 | device 66306, inode 119422271, UID 1000, one hardlink |

The scan covered 48 matching source-check roots and 225 directories. It inspected names and stat metadata only, pruning Cargo target, `.git`, states/data/WAL and symlink directories. No executable payload was read or hashed. The candidate's identity, size and modification/change timestamps stayed unchanged.

A privileged read-only scan checked 636 current processes for matching executable/open-file identities and mapped paths. It found no match and no visibility error. Its inode differs from the inspected retained selected ThinLTO/owner-poll server and fixed-v3 native/Redis executable files; the exact metadata set is in `executable-use-first.json`. This is an observation of inactivity, not authority to delete retained evidence.

Even reclaiming this entire 151,085,056-byte allocation would not close the preceding 659,902,464-byte gap to the required **96 GiB** preflight. A retained compressed archive would reduce the net saving further. The desired 98 GiB headroom remains a preference, not the required floor.

No files were compressed or deleted. No archive worker ran; no live handle remains. Original empty-TLC census, report, result and inventory stay unchanged. Actual metadata terminals: executable census `497759/0`; executable-use check `879bb1/0`. There were no command failures. Root's subsequently selected locked first-party debug cache maintenance is outside this task; no Cargo, shared-target operation or further archive search was performed here.
