# Lease vote-binding state-store capacity census

No eligible state payload remains in the authorized paths. The primary `/tmp/kv9-lease-authority-acceptance-scheduled-witness-first` contains 14 empty `states` directories. The permitted fallback census across `/tmp/kv9-lease-authority-*` found **29 states directories, all empty**: zero regular files, zero logical payload bytes and zero file allocation.

No archive, codec, payload hash, process/fault/test/build, or deletion was launched. Empty directories were retained. Existing cold archives and catalogs, previously removed state roots, model/config/log/result/proof files, Cargo caches and repository files were not changed. There is no archive-worker or eviction runtime handle and no restore operation to perform for this task. Because no file was selected, no process-ownership assurance is asserted.

Current observed filesystem free: **102,419,312,640 bytes**. The requested 98 GiB target is **2,807,386,112 bytes** away. The unchanged 80 GiB + 16 GiB source preflight is **659,902,464 bytes** away. This task recovered **zero bytes**; unrelated concurrent filesystem changes are not attributed to it. The prior 4 GiB archive cap and 80 GiB free floor were not changed.

`census-first.json` records every discovered state directory and exact metadata totals. `result.json` records the negative result and actual terminal metadata receipts: primary census `45afb1/0`, allowed fallback census `851071/0`. No first command failed. Further reclamation would require a different explicitly selected resource; no other files were searched or deleted to meet the target.
