from pathlib import Path
import gzip, hashlib, io, json, shutil, tarfile

repo = Path('/home/dongxu/kv9')
work = Path(__file__).resolve().parent
cargo = Path('/tmp/kv9-lease-vote-binding-source-first')
control = Path('/tmp/kv9-lease-vote-binding-controls-repaired-first')
out = repo / 'docs/lease-vote-binding-v1'
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
source_result = read(cargo / 'result.json')
controls = read(control / 'result.json')
assert source_result['complete'] and all(r['exit_code'] == 0 for r in source_result['commands'])
assert source_result['commands'][2]['test_result'] == ['219', '0', '0']
assert controls['complete'] and len(controls['controls']) == 8
assert all(c['expected_failure_observed'] for c in controls['controls'])
assert all(c['exit_code'] == c['expected_exit_code'] for c in controls['commands'])
before = read(cargo / 'sources-before.json')
assert before == read(cargo / 'sources-after.json')
for name, digest in before['sources'].items():
    if name.endswith(('.rs', '.toml', '.lock')) and digest is not None:
        assert sha((repo / name).read_bytes()) == digest, name
for name, digest in read(control / 'source-inputs.json').items():
    assert sha((repo / name).read_bytes()) == digest, name
    assert sha((control / 'source' / name).read_bytes()) == digest, name
for root in ['/tmp/kv9-lease-vote-binding-root-first', '/tmp/kv9-lease-vote-binding-controls-repaired-root-first']:
    r = read(Path(root) / 'source-result.json')
    assert r['complete'] and r['exit_code'] == 0
    assert r['initial_available_bytes'] >= 96 * 1024**3
    assert min(s['available_bytes'] for s in r['samples']) >= 80 * 1024**3
    assert r['initial_available_bytes'] - min(s['available_bytes'] for s in r['samples']) <= 16 * 1024**3
failed = read(Path('/tmp/kv9-lease-vote-binding-controls-first/result.json'))
assert not failed['complete'] and failed['commands'][0]['exit_code'] == 101 and not failed['controls']

files = {}
def add(name, path):
    assert path.is_file() and not path.is_symlink() and name not in files, name
    data = path.read_bytes()
    assert len(data) <= 2 * 1024**2, name
    files[name] = data
def tree(directory, prefix, skip=()):
    for path in directory.rglob('*'):
        relative = path.relative_to(directory)
        if any(part in skip for part in relative.parts): continue
        if path.is_file(): add(prefix + '/' + str(relative), path)
for path in [repo/'crates/raft/src/lib.rs', repo/'crates/raft/src/rawnode.rs',
             repo/'crates/raft/src/storage.rs', repo/'crates/raft/src/storage/persistence_model.rs',
             repo/'crates/raft/src/lease_policy.rs', repo/'crates/raft/src/lease_policy/tests.rs',
             repo/'crates/raft/src/rawnode/lease_gate.rs', repo/'crates/raft/src/rawnode/lease_gate/tests.rs',
             repo/'crates/raft/tests/lease_restart.rs', repo/'scripts/check-lease-vote-binding.py',
             repo/'scripts/build_cache.py', repo/'scripts/build-workload.py']:
    add('source/' + str(path.relative_to(repo)), path)
tree(cargo, 'cargo', {'raft-tests'})
tree(control, 'controls', {'source'})
tree(Path('/tmp/kv9-lease-vote-binding-root-first'), 'cargo-supervisor')
tree(Path('/tmp/kv9-lease-vote-binding-controls-repaired-root-first'), 'controls-supervisor')
tree(Path('/tmp/kv9-lease-vote-binding-controls-root-first'), 'first-controls-supervisor')
tree(Path('/tmp/kv9-lease-vote-binding-controls-first'), 'first-controls', {'source'})
for name in ['cache-first', 'cache-second', 'failed-cache-clean-first']:
    tree(Path('/tmp/kv9-lease-vote-binding-' + name), 'cache-maintenance/' + name)
for name in ['cold-states-first', 'more-cold-first']:
    base = Path('/tmp/kv9-lease-vote-binding-' + name)
    for path in base.iterdir():
        if path.is_file() and path.suffix in {'.json', '.md', '.py'}:
            add('cold-executables/' + name + '/' + path.name, path)
for name in ['publish.py', 'format.stdout', 'format.stderr', 'format-result.json']:
    add('publication/' + name, work / name)

out.mkdir()
archive = out / 'original-evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|') as tar:
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name); entry.size = len(data); entry.mode = 0o644
            tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files) and {m.name for m in members} == set(files)
    for member in members:
        assert member.isfile() and tar.extractfile(member).read() == files[member.name]
inventory = {'archive': archive.name, 'archive_bytes': archive.stat().st_size,
    'archive_sha256': sha(archive.read_bytes()), 'files': len(files),
    'members': [{'name': n, 'bytes': len(d), 'sha256': sha(d)} for n,d in sorted(files.items())],
    'scope': 'Actual Rust source, Cargo outputs, fault controls, initial failed capsule and maintenance metadata. Reproducible full workspace copies, compiler caches and cold executable payloads excluded.'}
(out/'inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
shutil.copyfile(cargo/'result.json', out/'source-summary.json')
shutil.copyfile(control/'result.json', out/'controls-summary.json')
total = sum(p.stat().st_size for p in (repo/'docs').rglob('original-evidence.tar.gz'))
assert total < 64 * 1024**2, total
receipt = {k:v for k,v in inventory.items() if k != 'members'}
receipt['aggregate_archive_bytes'] = total
(work/'readback.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
