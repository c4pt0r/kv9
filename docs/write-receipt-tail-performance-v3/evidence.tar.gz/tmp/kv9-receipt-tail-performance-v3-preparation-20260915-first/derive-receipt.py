"""Finite owned metadata/helper adaptation only; no source gate, codec or workload execution."""
from pathlib import Path
import ast,copy,difflib,hashlib,json
P=Path(__file__).resolve().parent
Q=Path('/tmp/kv9-receipt-tail-performance-v3-readiness-preparation-20260915-first')
O=Path('/tmp/kv9-published-directory-performance-v3-preparation-20260915-first')
OR=Path('/tmp/kv9-published-directory-performance-v3-readiness-preparation-20260915-first')
B=Path('/tmp/kv9-receipt-tail-release-20260915-first');S=Path('/tmp/kv9-receipt-tail-release-source-20260915-first')
REV='a6ac335ef4567f2e1a2b33da1a723d694cd5b7d9'
SMOKE='/tmp/kv9-receipt-tail-performance-v3-smoke-20260915-first';TIMING='/tmp/kv9-receipt-tail-performance-v3-timing-20260915-first'
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 p=Path(p);assert p.stat().st_size<=2*1024**2;return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,t):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t)
def save(p,d):write(p,json.dumps(d,indent=2,sort_keys=True)+'\n')
sub={str(O):str(P),str(OR):str(Q),'/tmp/kv9-published-directory-release-source-20260914-first':str(S),'/tmp/kv9-published-directory-release-20260914-first':str(B),'483b8c3629b033734f5d7a2b8653a1352304a4b5':REV,'43d8bcb2d852d6fcbebb7f528808e53b3eb93588e2637195e9053cd91e8d5450':'d83b4e2ede7bcd81e4a6c4adbc407d2fbd6790d9fcab5851314ed907a6fb0a8c','849aab333f8fbaa3014c204c150ed0200aa043d5de9fef6ed8d05b31655e2c8e':sha(B/'build.json'),'kv9-published-directory-write-ab-c1-c64-storage-v3':'kv9-receipt-tail-write-ab-c1-c64-storage-v3','/tmp/kv9-published-directory-performance-v3-smoke-20260915-first':SMOKE,'/tmp/kv9-published-directory-performance-v3-timing-20260915-first':TIMING}
def replace(t):
 for a,b in sorted(sub.items(),key=lambda x:-len(x[0])):t=t.replace(a,b)
 return t
names=['matched-driver.py','audit.py','compressed_retention.py','retention_audit.py','isolate-and-run.py','test_driver.py','test_audit_contract.py','test_smoke_schema.py','test_storage_policy.py','test_cleanup_metadata.py','test_compressed_retention.py','driver-arguments.json','commands.json','protocol.json','storage-policy.json']
for n in names:
 write(P/'predecessor'/n,(O/n).read_text());write(P/n,replace((O/n).read_text()))
# Preserve finite reference files used by unchanged inherited controls.
for n in ['matched-driver.py','compressed_retention.py','retention_audit.py']:
 write(P/'v1-original'/n,(O/'v1-original'/n).read_text())
for n in ['accepted-controls.json','first-derivation-failure.json','second-derivation-failure.json','third-derivation-failure.json']:
 write(P/'predecessor'/n,(O/n).read_text())
for n in ['check-smoke-v3.py','test_smoke_v3_bindings.py','smoke-reader.diff','original-check-smoke-corrected.py']:
 write(Q/'predecessor'/n,(OR/n).read_text())
 if n in ['check-smoke-v3.py','test_smoke_v3_bindings.py']:write(Q/n,replace((OR/n).read_text()))
# Close exact source helper pins in producer -> driver -> auditor -> smoke order.
for upstream,downstream in [
 ('compressed_retention.py',[P/'matched-driver.py',P/'audit.py',Q/'check-smoke-v3.py',Q/'test_smoke_v3_bindings.py']),
 ('retention_audit.py',[P/'audit.py']),('isolate-and-run.py',[P/'audit.py']),('driver-arguments.json',[P/'audit.py']),
 ('matched-driver.py',[P/'audit.py',Q/'check-smoke-v3.py',P/'commands.json']),('audit.py',[Q/'check-smoke-v3.py'])]:
 for q in downstream:q.write_text(q.read_text().replace(sha(O/upstream),sha(P/upstream)))
p=read(P/'protocol.json');p.update(driver_sha256=sha(P/'matched-driver.py'),auditor_sha256=sha(P/'audit.py'),runtime_ready=False,capacity_qualified=False,contracts_executed=False)
p['role_labels']['new']='Receipt-tail hint exact a6ac335';p['large_synthetic_qualified']='Prior qualified codec functions and bounds unchanged; exact root paths and helper identities are new, current controls unexecuted.'
for k,n in [('helper','compressed_retention.py'),('independent_reader','retention_audit.py')]:p['compressed_retention'][k]=dict(bytes=(P/n).stat().st_size,sha256=sha(P/n))
save(P/'protocol.json',p)
# Use the actual accepted command-scoped safe.directory fix, not global Git configuration.
r=read('/tmp/kv9-published-directory-performance-v3-root-20260915-second/commands.json');r=json.loads(replace(json.dumps(r)))
for row in r.values():
 row['argv']=[x.replace(sha(O/'matched-driver.py'),sha(P/'matched-driver.py'))for x in row['argv']]
save(Q/'runtime-commands.json',r)
safe=['GIT_CONFIG_COUNT=3','GIT_CONFIG_KEY_0=safe.directory','GIT_CONFIG_VALUE_0=/tmp/kv9-crc-main-bd42-baseline-20260914-first','GIT_CONFIG_KEY_1=safe.directory','GIT_CONFIG_VALUE_1='+str(S),'GIT_CONFIG_KEY_2=safe.directory','GIT_CONFIG_VALUE_2=/tmp/kv9-point-write-measurement-v3']
def scoped(x):
 if isinstance(x,list):
  if x[:3]==['sudo','-n','env']:return x[:3]+safe+x[3:]
  return[scoped(v)for v in x]
 if isinstance(x,dict):return{k:scoped(v)for k,v in x.items()}
 return x
c=scoped(read(P/'commands.json'))
for phase,key in [('smoke','smoke_root_only_after_contracts_and_capacity'),('smoke_readback','smoke_readback_after_smoke_terminal'),('timing','timing_root_only_after_smoke_terminal_and_capacity'),('audit','audit_root_only_after_timing_terminal')]:c[key]=r[phase]['argv']
save(P/'commands.json',c)
q=replace((OR/'ROOT-COMMANDS.json').read_text());d=json.loads(q)
for phase,key in [('smoke','smoke_root_only_after_contracts_and_capacity'),('smoke_readback','smoke_readback_after_smoke_terminal'),('timing','timing_root_only_after_smoke_terminal_and_capacity'),('audit','audit_root_only_after_timing_terminal')]:d[key]=r[phase]['argv']
for k in ['focused_smoke_reader_controls','restore_root_only_after_reviewed_capacity']:d[k]=scoped(d[k])
d['runtime_commands_released']=False;d['source_binding_required']='Root must verify all three actual source maps and original retained binary/feature/compiler inputs with bind-roles.py before launch. No rebuilt binary.'
save(Q/'ROOT-COMMANDS.json',d)
# Prove execution functions and codec classes are identical to the accepted directory v3 implementation.
def functions(q):
 text=q.read_text();return{n.name:ast.get_source_segment(text,n)for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
protected={}
for n in ['matched-driver.py','compressed_retention.py','retention_audit.py','isolate-and-run.py']:
 a,b=functions(O/n),functions(P/n);changed=[k for k in a if a[k]!=b[k]]
 assert changed==(['main']if n=='matched-driver.py'else[]),(n,changed)
 protected[n]={'unchanged_functions_and_classes':[k for k in a if k not in changed],'changed':changed}
changes=[]
for root,origin,names2 in [(P,O,names),(Q,OR,['check-smoke-v3.py','test_smoke_v3_bindings.py'])]:
 for n in names2:
  before=(origin/n).read_text();after=(root/n).read_text();dest=root/'diffs'/Path(n+'.diff');write(dest,''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(origin/n),tofile=str(root/n))))
  if n.endswith('.py'):
   a=ast.parse(before);b=ast.parse(after)
   for tree in (a,b):
    for node in ast.walk(tree):
     if isinstance(node,ast.Constant)and isinstance(node.value,str):node.value='<string>'
   assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),n
  changes.append(dict(path=str(root/n),sha256=sha(root/n),ancestor=str(origin/n),ancestor_sha256=sha(origin/n)))
assert (P/'storage-policy.json').read_bytes()==(O/'storage-policy.json').read_bytes()
assert p['smoke_inventory']==read(O/'protocol.json')['smoke_inventory'] and p['timed_inventory']==read(O/'protocol.json')['timed_inventory']
save(P/'substitutions.json',sub);save(P/'source-delta.json',dict(complete=True,static_only=True,files=changes,protected=protected,policy_sha256=sha(P/'storage-policy.json'),scope='Exact source/build/output/protocol/helper string substitutions only; complete8+16 inventories, every codec/decode/restore class/function and every measured lifecycle function unchanged.'))
print(json.dumps(dict(prepared=True,driver_sha256=sha(P/'matched-driver.py'),auditor_sha256=sha(P/'audit.py'),retention_sha256=sha(P/'compressed_retention.py'),reader_sha256=sha(P/'retention_audit.py'),protocol_sha256=sha(P/'protocol.json'),runtime_ready=False)))
