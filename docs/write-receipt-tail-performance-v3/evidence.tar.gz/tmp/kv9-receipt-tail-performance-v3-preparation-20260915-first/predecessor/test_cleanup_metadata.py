"""Execute only the real native_trial finally body with synthetic ownership."""
import ast
import errno
from pathlib import Path
import types
import unittest

H=Path(__file__).parent
source=(H/'matched-driver.py').read_text()
function=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='native_trial')
outer=next(n for n in function.body if isinstance(n,ast.Try) and n.finalbody)
at=function.body.index(outer)
completion=function.body[at+1]
assert isinstance(completion,ast.Assign) and 'result["complete"]' in ast.get_source_segment(source,completion)
code=compile(ast.Module(body=outer.finalbody+[completion],type_ignores=[]),'native_trial:actual-finally','exec')
def require(ok,message):
    if not ok:raise ValueError(message)

class CleanupMetadata(unittest.TestCase):
    def exercise(self,number,cleanup_error=None,earlier_failure=False):
        events=[];saved=[]
        original=OSError(number,'injected pre-cleanup metadata write')
        result=dict(workload_complete=True)
        if earlier_failure:result['failure']='original workload failure'
        class Fixture:
            children=[]
            identities={}
            def close(self):
                events.append('close')
                if cleanup_error:raise cleanup_error
        def save(path,value):
            events.append(path.name)
            if path.name=='pre-cleanup.json':raise original
            saved.append((path.name,dict(value)))
        env=dict(save=save,directory=Path('/synthetic'),result=result,fixture=Fixture(),
                 args=types.SimpleNamespace(storage='tmpfs'),Path=Path,require=require)
        exec(code,env)
        self.assertEqual(events[:2],['pre-cleanup.json','close'])
        self.assertEqual(events.count('close'),1)
        self.assertEqual(result['pre_cleanup_failure'],repr(original))
        self.assertFalse(result['complete'])
        if cleanup_error:
            self.assertEqual(result['cleanup_failure'],repr(cleanup_error))
            self.assertNotIn('cleanup_complete',result)
        else:
            self.assertTrue(result['cleanup_complete'])
            self.assertEqual(saved,[('cleanup.json',dict(complete=True,children=[],storage='tmpfs'))])
        if earlier_failure:self.assertEqual(result['failure'],'original workload failure')
    def test_enospc_and_eio_still_close_and_retain_original_error(self):
        for number in (errno.ENOSPC,errno.EIO):
            with self.subTest(errno=number):self.exercise(number)
    def test_cleanup_error_and_workload_error_do_not_overwrite_metadata_error(self):
        for number in (errno.ENOSPC,errno.EIO):
            with self.subTest(errno=number):self.exercise(number,OSError(errno.EIO,'injected close failure'),True)

if __name__=='__main__':unittest.main(verbosity=2)
