"""Tiny synthetic originals only. No DB, old payload or large-file qualification."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import time
import types
import unittest
from unittest.mock import patch
import compressed_retention as producer
import retention_audit as independent

HERE=Path(__file__).parent
RUN=HERE/'synthetic-first'/str(time.time_ns());RUN.mkdir(parents=True)
FREE=types.SimpleNamespace(free=1024**4,total=2*1024**4,used=1024**4)
class Dead:
    pid=1073741824
    def poll(self):return 0

class Retention(unittest.TestCase):
    def setUp(self):
        self.root=RUN/self._testMethodName;self.root.mkdir()
        self.campaign=self.root/'campaign';self.campaign.mkdir()
        self.fixture=self.campaign/'000-cell'/'fixture';self.fixture.mkdir(parents=True)
        self.scratch=self.root/'scratch';self.scratch.mkdir()
        (self.scratch/'n1').mkdir();(self.scratch/'n1'/'raft.log').write_bytes(b'wal\x00\xff'*4096)
        (self.scratch/'empty').write_bytes(b'');self.link=self.fixture/'data';self.link.symlink_to(self.scratch)
        self.child=Dead();self.identities={self.child.pid:dict(pid=self.child.pid,start_ticks=1,boot_id='synthetic-dead')}
        self.reference=lambda root:dict(complete=True,references=[],errors=[],checked_unix_ns=time.time_ns())
        self.space=patch.object(shutil,'disk_usage',return_value=FREE);self.space.start();self.addCleanup(self.space.stop)
    def produce(self,**kwargs):
        return producer.retain_tree(self.scratch,self.link,self.fixture,self.campaign,[self.child],self.identities,
               reference_check=self.reference,test_root=self.root,**kwargs)
    def audit(self):
        original=json.loads((self.fixture/'retention-original.json').read_text())
        records={};logical={};decoders=[]
        result=independent.verify(self.fixture,original['children'],records,logical,decoders,allow_synthetic=True)
        self.assertTrue(all(x['complete'] and x['absent'] and x['exit_code']==0 for x in decoders))
        self.assertTrue(all(not Path(x).is_relative_to(self.fixture/'data') for x in records))
        self.assertTrue(all(x['resident_original_path'] is False for x in logical.values()))
        return result
    def change_catalog(self,change):
        file=self.fixture/'retention-catalog.json';data=json.loads(file.read_text())
        (self.fixture/'catalog-before-control.json').write_bytes(file.read_bytes());change(data)
        file.write_text(json.dumps(data));h=producer.sha(file)
        for name,field in [('tmpfs-retention.json','catalog_sha256'),('retention-cleanup-intent.json','catalog_sha256')]:
            p=self.fixture/name;x=json.loads(p.read_text());x[field]=h;p.write_text(json.dumps(x))
    def test_roundtrip_empty_nested_and_full_independent_decode(self):
        self.produce();r=self.audit();self.assertEqual(r['files'],2);self.assertEqual(r['logical_bytes'],20480)
        self.assertFalse(self.scratch.exists());self.assertFalse(self.link.is_symlink())
        result=producer.restore(self.fixture/'retention-catalog.json',self.root/'restored')
        self.assertTrue(result['byte_exact']);self.assertFalse(result['original_inode_identity'])
        self.assertEqual((self.root/'restored'/'n1'/'raft.log').read_bytes(),b'wal\x00\xff'*4096)
        self.assertEqual((self.root/'restored'/'empty').read_bytes(),b'')
    def test_corruption_with_rebound_physical_hash_is_rejected(self):
        self.produce()
        def corrupt(c):
            row=next(x for x in c['members'] if x['original']['bytes']);p=self.fixture/row['object']
            raw=bytearray(p.read_bytes());raw[-1]^=1;p.write_bytes(raw);row['compressed_sha256']=producer.sha(p)
        self.change_catalog(corrupt)
        with self.assertRaisesRegex(ValueError,'decoder failure'):self.audit()
    def test_truncation(self):
        self.produce();obj=next((self.fixture/'retention-objects').iterdir());obj.write_bytes(obj.read_bytes()[:-1])
        with self.assertRaisesRegex(ValueError,'compressed hash/size'):self.audit()
    def test_concatenated_second_frame_rebound_is_rejected(self):
        self.produce()
        def concat(c):
            row=c['members'][0];p=self.fixture/row['object'];p.write_bytes(p.read_bytes()*2)
            row['compressed_sha256']=producer.sha(p);row['compressed_bytes']=p.stat().st_size
        self.change_catalog(concat)
        with self.assertRaisesRegex(ValueError,'concatenated/trailing'):self.audit()
    def test_missing_object(self):
        self.produce();next((self.fixture/'retention-objects').iterdir()).unlink()
        with self.assertRaises(FileNotFoundError):self.audit()
    def test_wrong_decoded_hash(self):
        self.produce()
        def bad(c):c['members'][0]['original']['sha256']='0'*64
        self.change_catalog(bad)
        with self.assertRaisesRegex(ValueError,'original member inventory'):self.audit()
    def test_wrong_size_direct_independent_decoder(self):
        self.produce();obj=next((self.fixture/'retention-objects').iterdir())
        with self.assertRaises(ValueError):independent.full_decode(obj,dict(bytes=1,sha256='0'*64),{})
    def test_unsafe_path(self):
        self.produce();self.change_catalog(lambda c:c['members'][0].update(name='../escape'))
        with self.assertRaisesRegex(ValueError,'unsafe'):self.audit()
    def test_duplicate_member(self):
        self.produce();self.change_catalog(lambda c:c['members'].append(copy.deepcopy(c['members'][0])))
        with self.assertRaisesRegex(ValueError,'duplicate/colliding'):self.audit()
    def test_extra_object(self):
        self.produce();(self.fixture/'retention-objects'/'foreign.zst').write_bytes(b'foreign')
        with self.assertRaisesRegex(ValueError,'unexpected/missing'):self.audit()
    def test_post_wait_compression_cap_cannot_escape_polling(self):
        source=self.scratch/'empty';destination=self.root/'over-limit.zst';rows=[]
        real_popen=producer.subprocess.Popen;real_fstat=producer.os.fstat;state={'waited':False,'fd':None}
        def launch(*args,**kwargs):
            state['fd']=kwargs['stdout'].fileno();child=real_popen(*args,**kwargs);real_wait=child.wait
            def wait(*args,**kwargs):
                value=real_wait(*args,**kwargs);state['waited']=True;return value
            child.wait=wait;return child
        def final_stat(fd):
            if state['waited'] and fd==state['fd']:return types.SimpleNamespace(st_size=1024**2+1)
            return real_fstat(fd)
        with patch.object(producer.subprocess,'Popen',side_effect=launch),patch.object(producer.os,'fstat',side_effect=final_stat):
            with self.assertRaisesRegex(ValueError,'final compressed output size cap'):
                producer.codec('compress',source,destination,producer.Budget(self.campaign),0,rows)
        self.assertTrue(state['waited']);self.assertTrue(rows[0]['absent']);self.assertFalse(rows[0]['complete'])
    def test_restore_symlink_ancestor_refused(self):
        self.produce();real=self.root/'real';real.mkdir();alias=self.root/'alias';alias.symlink_to(real,target_is_directory=True)
        with self.assertRaisesRegex(ValueError,'noncanonical restore paths'):
            producer.restore(self.fixture/'retention-catalog.json',alias/'restored')
        self.assertFalse((real/'restored').exists())
    def test_noncanonical_synthetic_scope(self):
        with self.assertRaisesRegex(ValueError,'noncanonical synthetic root'):
            producer.retain_tree(self.scratch,self.link,self.fixture,self.campaign,[self.child],self.identities,
                reference_check=self.reference,test_root=self.root/'..'/self.root.name)
    def test_wrong_reviewed_restore_catalog_rejected_before_creation(self):
        self.produce();dst=self.root/'restore-wrong-hash'
        with self.assertRaisesRegex(ValueError,'reviewed restore catalog changed'):
            producer.restore(self.fixture/'retention-catalog.json',dst,'0'*64)
        self.assertFalse(dst.exists())
    def test_source_symlink(self):
        (self.scratch/'escape').symlink_to('/dev/null')
        with self.assertRaisesRegex(ValueError,'unsupported original'):self.produce()
        self.assertTrue(self.scratch.exists())
    def test_source_hardlink(self):
        os.link(self.scratch/'empty',self.scratch/'other')
        with self.assertRaisesRegex(ValueError,'unsupported original'):self.produce()
    def test_live_writer_identity(self):
        self.child.pid=os.getpid()
        with self.assertRaisesRegex(ValueError,'writer not reaped'):self.produce()
        self.assertFalse((self.fixture/'retention-objects').exists())
    def test_live_reference_refusal(self):
        def refusal(root):raise ValueError('live reference control')
        self.reference=refusal
        with self.assertRaisesRegex(ValueError,'live reference'):self.produce()
        self.assertTrue((self.scratch/'n1'/'raft.log').exists())
    def test_changed_source_is_not_evicted(self):
        actual=producer.codec
        def changed(mode,source,*args,**kwargs):
            result=actual(mode,source,*args,**kwargs)
            if mode=='compress' and Path(source).name=='raft.log':Path(source).write_bytes(b'changed')
            return result
        with patch.object(producer,'codec',side_effect=changed):
            with self.assertRaisesRegex(ValueError,'metadata changed'):self.produce()
        self.assertTrue(self.scratch.exists());self.assertTrue((self.fixture/'retention-failure-first.json').exists())
    def test_destination_collision(self):
        (self.fixture/'retention-objects').mkdir()
        with self.assertRaisesRegex(ValueError,'destination collision'):self.produce()
    def test_restore_collision(self):
        self.produce();dst=self.root/'restored';dst.mkdir();(dst/'precious').write_bytes(b'keep')
        with self.assertRaisesRegex(ValueError,'destination collision'):producer.restore(self.fixture/'retention-catalog.json',dst)
        self.assertEqual((dst/'precious').read_bytes(),b'keep')
    def test_space_refusal_before_object_creation(self):
        with patch.object(shutil,'disk_usage',return_value=types.SimpleNamespace(free=8*1024**3-1)):
            with self.assertRaisesRegex(ValueError,'floor/space'):self.produce()
        self.assertFalse((self.fixture/'retention-objects').exists())
    def test_interrupted_mixed_state_preserves_catalog_and_restores_fresh(self):
        unlink=Path.unlink;count=[0]
        def interrupted(path,*args,**kwargs):
            if path.is_relative_to(self.scratch):
                count[0]+=1
                if count[0]==2:raise OSError('synthetic interruption after first unlink')
            return unlink(path,*args,**kwargs)
        with patch.object(Path,'unlink',interrupted):
            with self.assertRaisesRegex(OSError,'synthetic interruption'):self.produce()
        self.assertTrue(self.scratch.exists());self.assertTrue((self.fixture/'retention-cleanup-intent.json').exists())
        producer.restore(self.fixture/'retention-catalog.json',self.root/'recovered')
        self.assertEqual((self.root/'recovered'/'n1'/'raft.log').read_bytes(),b'wal\x00\xff'*4096)
    def test_decoder_timeout_reaps_child(self):
        self.produce();obj=next((self.fixture/'retention-objects').iterdir());observed={}
        with patch.dict(independent.LIMITS,codec_seconds=-1):
            with self.assertRaisesRegex(ValueError,'deadline'):independent.full_decode(obj,dict(bytes=0,sha256=hashlib.sha256(b'').hexdigest()),observed)
        self.assertTrue(observed['absent']);self.assertIsNotNone(observed['exit_code'])
    def test_synthetic_cannot_be_promoted_to_runtime(self):
        self.produce();children=json.loads((self.fixture/'retention-original.json').read_text())['children']
        with self.assertRaisesRegex(ValueError,'synthetic/runtime'):independent.verify(self.fixture,children,{},{},[])
    def test_independent_combined_physical_census_and_boundary(self):
        self.produce();peer=self.root/'other-run';peer.mkdir();(peer/'metadata.json').write_text('{}')
        result=independent.combined_physical([self.campaign,peer])
        self.assertGreater(result['allocated_bytes'],0)
        with patch.dict(independent.LIMITS,campaign_bytes=result['allocated_bytes']):
            independent.combined_physical([self.campaign,peer])
        with patch.dict(independent.LIMITS,campaign_bytes=result['allocated_bytes']-1):
            with self.assertRaisesRegex(ValueError,'independent physical cap'):
                independent.combined_physical([self.campaign,peer])
    def test_combined_logical_cap_is_checked_before_object_creation(self):
        peer=self.root/'peer';f=peer/'000-cell'/'fixture';f.mkdir(parents=True)
        (f/'tmpfs-retention.json').write_text(json.dumps({'files':{'previous':{'bytes':128*1024**3}}}))
        with patch.object(producer,'logical_roots',return_value=[self.campaign,peer]):
            with self.assertRaisesRegex(ValueError,'campaign logical retention cap'):self.produce()
        self.assertFalse((self.fixture/'retention-objects').exists())
    def test_combined_physical_reservation_refuses_cap(self):
        with patch.dict(producer.LIMITS,campaign_bytes=1):
            with self.assertRaisesRegex(ValueError,'physical retention cap'):self.produce()
    def test_codec_cannot_precede_retention_interval(self):
        self.produce()
        self.change_catalog(lambda c:c['codecs'][0].update(started_unix_ns=c['started_unix_ns']-1))
        with self.assertRaisesRegex(ValueError,'codec interval'):self.audit()
    def test_original_shutdown_precedes_retention_and_failure_stops_it(self):
        events=[];fixture=types.SimpleNamespace(scratch=self.scratch,link=self.link,out=self.fixture,
                                               children=[self.child],identities=self.identities)
        def base(f):events.append('original shutdown')
        with patch.object(producer,'retain_tree',side_effect=lambda *a:events.append('retain')):
            producer.close_fixture(fixture,base,self.campaign)
        self.assertEqual(events,['original shutdown','retain'])
        def failed(f):raise ValueError('shutdown failure')
        with patch.object(producer,'retain_tree') as call:
            with self.assertRaisesRegex(ValueError,'shutdown failure'):producer.close_fixture(fixture,failed,self.campaign)
            call.assert_not_called()
    def test_boundaries_use_finite_large_file_limits_without_running_large_case(self):
        self.assertEqual(producer.LIMITS,independent.LIMITS)
        self.assertEqual(producer.LIMITS['member_bytes'],8*1024**3)
        with patch.dict(producer.LIMITS,member_bytes=16):
            with self.assertRaisesRegex(ValueError,'member size cap'):self.produce()
        self.assertTrue(self.scratch.exists())

    def test_v2_independent_decoder_floor_equal_and_one_byte_below(self):
        self.produce()
        catalog=json.loads((self.fixture/'retention-catalog.json').read_text())
        row=next(x for x in catalog['members'] if x['original']['bytes'])
        obj=self.fixture/row['object'];expected={k:row['original'][k] for k in ('bytes','sha256')}
        observed={}
        with patch.object(shutil,'disk_usage',return_value=types.SimpleNamespace(free=8*1024**3)):
            independent.full_decode(obj,expected,observed)
        self.assertTrue(observed['complete'] and observed['absent'])
        self.assertEqual(observed['minimum_available_bytes'],8*1024**3)
        refused={}
        with patch.object(shutil,'disk_usage',return_value=types.SimpleNamespace(free=8*1024**3-1)):
            with self.assertRaisesRegex(ValueError,'decode retention floor'):independent.full_decode(obj,expected,refused)
        self.assertTrue(refused['absent'])
        self.assertFalse(refused['complete'])

    def test_v2_restore_floor_total_and_metadata_boundary(self):
        self.produce();self.audit()
        catalog=self.fixture/'retention-catalog.json'
        floor=8*1024**3+20480+8*1024**2
        refused=self.root/'below-reserve'
        with patch.object(shutil,'disk_usage',return_value=types.SimpleNamespace(free=floor-1)):
            with self.assertRaisesRegex(ValueError,'restore space refusal'):producer.restore(catalog,refused,producer.sha(catalog))
        self.assertFalse(refused.exists())
        with patch.object(shutil,'disk_usage',return_value=types.SimpleNamespace(free=floor)):
            result=producer.restore(catalog,self.root/'exact-reserve',producer.sha(catalog))
        self.assertTrue(result['complete'] and result['byte_exact'])
        self.assertEqual(result['storage_policy'],producer.STORAGE_POLICY)
        self.assertEqual((self.root/'exact-reserve/n1/raft.log').read_bytes(),b'wal\x00\xff'*4096)

    def test_v2_foreign_catalog_policy_rejected_before_decoder_or_restore(self):
        self.produce()
        self.change_catalog(lambda c:c['storage_policy']['post_run'].update(host_floor_bytes=96*1024**3))
        with patch.object(independent,'full_decode') as decoder:
            with self.assertRaisesRegex(ValueError,'storage policy'):self.audit()
            decoder.assert_not_called()
        with patch.object(producer,'codec') as codec:
            with self.assertRaisesRegex(ValueError,'storage policy'):producer.restore(self.fixture/'retention-catalog.json',self.root/'foreign')
            codec.assert_not_called()
        self.assertFalse((self.root/'foreign').exists())

if __name__=='__main__':unittest.main(verbosity=2)
