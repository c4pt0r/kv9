#!/usr/bin/env python3
"""Post-reap, byte-exact tmpfs retention. No database or live-data entry point."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import selectors
import shutil
import stat
import subprocess
import time

if not __debug__:
    raise RuntimeError('retention requires assertions enabled')
CODEC = '/usr/bin/zstd'
CODEC_SHA = '7c5468b370f7c47eda07281e3437fafc568f95d10420051e3aa522709f9342c5'
CPUS = list(range(6,16)) + list(range(22,32))
COHORT_ROOTS = [Path('/tmp/kv9-receipt-tail-performance-v3-smoke-20260915-first'),
                Path('/tmp/kv9-receipt-tail-performance-v3-timing-20260915-first/cohorts')]
LIMITS = dict(member_bytes=8*1024**3, cohort_bytes=16*1024**3,
              campaign_bytes=128*1024**3, metadata_bytes=8*1024**2,
              files=65536, codec_seconds=600, cohort_seconds=1800,
              io_bytes=1024**2, decode_memory_bytes=64*1024**2,
              retention_floor_bytes=8*1024**3)

STORAGE_POLICY = {'available_space': 'f_bavail * f_frsize', 'measurement': {'host_bytes': 25769803776, 'tmpfs_bytes': 17179869184}, 'policy_id': 'kv9-local-benchmark-storage-v3', 'post_run': {'fresh_restore_reserve_bytes': 17179869184, 'host_floor_bytes': 8589934592, 'metadata_margin_bytes': 1073741824}, 'pre_cohort': {'host_bytes': 25769803776, 'tmpfs_bytes': 34359738368}, 'representation': 'zstd-files-v1'}
STORAGE_POLICY_SHA = 'cebdc41bbed8fd7000ef11fc5de29aa10722fc1112008366ef24e2e7d8924ba1'

def check_storage_policy(document):
    need(json.dumps(document.get('storage_policy'),sort_keys=True,separators=(',',':')) ==
            json.dumps(STORAGE_POLICY,sort_keys=True,separators=(',',':')) and
            document.get('storage_policy_sha256') == STORAGE_POLICY_SHA, 'storage policy binding differs')

def need(ok, message):
    if not ok: raise ValueError(message)

def sha(path):
    with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def safe_name(name):
    need(isinstance(name,str) and name and '\\' not in name and '\0' not in name,'unsafe name')
    p=PurePosixPath(name)
    need(not p.is_absolute() and all(x not in ('','.','..') for x in name.split('/')) and str(p)==name,'unsafe name')
    return p

def meta(path):
    s=Path(path).lstat()
    return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,
                nlink=s.st_nlink,bytes=s.st_size,blocks=s.st_blocks,
                atime_ns=s.st_atime_ns,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)

def stable(m):
    return {k:v for k,v in m.items() if k!='atime_ns'}

def exclusive_json(path,value,limit=LIMITS['metadata_bytes']):
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
    need(len(raw)<=limit,'metadata size cap')
    with Path(path).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    fsync_dir(Path(path).parent)

def fsync_dir(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:os.fsync(fd)
    finally:os.close(fd)

def file_fd(path):
    return os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)

def hash_original(path, expected=None, check=lambda:None):
    m=meta(path)
    need(stat.S_ISREG(m['mode']) and not(m['mode']&0o111) and m['nlink']==1,'unsupported original file')
    need(not os.listxattr(path,follow_symlinks=False),'unsupported original xattrs')
    if expected is not None:need(stable(m)==stable(expected),'original metadata changed')
    h=hashlib.sha256();n=0
    fd=file_fd(path)
    try:
        need(os.fstat(fd).st_ino==m['inode'] and os.fstat(fd).st_dev==m['device'],'source open identity')
        while True:
            check();b=os.read(fd,LIMITS['io_bytes'])
            if not b:break
            n+=len(b);need(n<=m['bytes'],'source grew');h.update(b)
    finally:os.close(fd)
    need(n==m['bytes'] and stable(meta(path))==stable(m),'source changed while hashing')
    return dict(bytes=n,sha256=h.hexdigest(),metadata=m)

def tree_inventory(root,check=lambda:None):
    root=Path(root);m=meta(root)
    need(stat.S_ISDIR(m['mode']) and not os.listxattr(root,follow_symlinks=False),'unsupported original root')
    directories={'':m};files={};total=0
    for base,dirs,names in os.walk(root,followlinks=False):
        dirs.sort();names.sort()
        for name in dirs:
            p=Path(base)/name;rel=str(p.relative_to(root));safe_name(rel)
            x=meta(p);need(stat.S_ISDIR(x['mode']) and not os.listxattr(p,follow_symlinks=False),'unsafe original directory')
            directories[rel]=x
        for name in names:
            p=Path(base)/name;rel=str(p.relative_to(root));safe_name(rel)
            x=meta(p);need(x['bytes']<=LIMITS['member_bytes'],'member size cap')
            total+=x['bytes'];need(total<=LIMITS['cohort_bytes'],'cohort logical cap')
            need(len(files)<LIMITS['files'],'member count cap')
            files[rel]=hash_original(p,check=check)
    return dict(files=files,directories=directories,logical_bytes=total)

def no_references(root):
    """Selected inode/subtree census; inaccessible /proc entries fail closed."""
    need(os.geteuid()==0,'privileged reference census required')
    root=Path(root);roots=str(root);hits=[];errors=[];vanished=0
    identities={(p.lstat().st_dev,p.lstat().st_ino) for p in [root,*root.rglob('*')]}
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        for section in ('exe','cwd','maps','fd'):
            try:
                pairs=[]
                if section in ('exe','cwd'):
                    link=proc/section;s=link.stat();pairs=[(os.readlink(link),(s.st_dev,s.st_ino))]
                elif section=='maps':
                    for line in (proc/'maps').read_text().splitlines():
                        row=line.split(None,5)
                        if len(row)==6:
                            major,minor=row[3].split(':');pairs.append((row[5],(os.makedev(int(major,16),int(minor,16)),int(row[4]))))
                else:
                    for fd in (proc/'fd').iterdir():
                        try:
                            s=fd.stat();pairs.append((os.readlink(fd),(s.st_dev,s.st_ino)))
                        except (FileNotFoundError,ProcessLookupError):vanished+=1
                for target,identity in pairs:
                    target=target.removesuffix(' (deleted)')
                    if target==roots or target.startswith(roots+'/') or identity in identities:
                        hits.append([int(proc.name),section])
            except (FileNotFoundError,ProcessLookupError):vanished+=1
            except OSError as e:errors.append([int(proc.name),section,type(e).__name__])
    need(not hits and not errors,'live reference or incomplete privileged reference census')
    return dict(complete=True,references=hits,errors=errors,vanished=vanished,checked_unix_ns=time.time_ns())

def logical_roots(campaign):
    campaign=Path(campaign)
    if campaign in COHORT_ROOTS:return COHORT_ROOTS
    need(campaign.is_relative_to(Path(__file__).parent/'synthetic-first'),'unbound campaign root')
    return [campaign]

class Budget:
    def __init__(self,campaign):
        self.campaign=Path(campaign);self.roots=[x.parent if x.name=='cohorts' else x for x in logical_roots(campaign)];self.started=time.monotonic();self.minimum=None
        self.samples=[];self.last_scan=0;self.physical=0
    def check(self,reserve=0):
        now=time.monotonic();free=shutil.disk_usage(self.campaign).free
        self.minimum=free if self.minimum is None else min(self.minimum,free)
        need(free>=LIMITS['retention_floor_bytes']+reserve,'retention 8 GiB floor/space reservation')
        need(now-self.started<=LIMITS['cohort_seconds'],'cohort retention deadline')
        if reserve or now-self.last_scan>=0.25:
            physical=0
            for root in self.roots:
                if not root.exists():continue
                for base,dirs,names in os.walk(root,followlinks=False):
                    physical+=Path(base).lstat().st_blocks*512
                    physical+=sum((Path(base)/d).lstat().st_blocks*512 for d in dirs if (Path(base)/d).is_symlink())
                    dirs[:]=[d for d in dirs if not (Path(base)/d).is_symlink()]
                    for name in names:
                        st=(Path(base)/name).lstat()
                        if stat.S_ISREG(st.st_mode):physical+=st.st_blocks*512
            self.physical=physical;self.last_scan=now
            need(physical+reserve<=LIMITS['campaign_bytes'],'combined smoke/timing physical retention cap')
            if len(self.samples)<7201:self.samples.append(dict(unix_ns=time.time_ns(),available_bytes=free,allocated_bytes=physical))
    def report(self):
        return dict(minimum_available_bytes=self.minimum,samples=self.samples,complete=True)

def single_frame(path):
    """Read only frame headers/block extents; reject extra frames/trailing bytes."""
    size=Path(path).stat().st_size
    with open(path,'rb') as f:
        def take(n):
            b=f.read(n);need(len(b)==n,'truncated zstd frame');return b
        need(take(4)==b'\x28\xb5\x2f\xfd','zstd standard frame required')
        flag=take(1)[0];need(not(flag&0x18) and flag&4,'reserved flags/checksum missing')
        single=bool(flag&32);content=flag>>6
        if not single:
            w=take(1)[0];base=1<<(10+(w>>3));window=base+(base//8)*(w&7)
            need(window<=LIMITS['decode_memory_bytes'],'zstd window exceeds decoder memory')
        dictionary=(0,1,2,4)[flag&3];need(not dictionary,'unexpected zstd dictionary')
        n=(1 if single else 0,2,4,8)[content]
        field=take(n)
        if single:
            window=int.from_bytes(field,'little')+(256 if content==1 else 0)
            need(window<=LIMITS['decode_memory_bytes'],'single-segment window cap')
        while True:
            h=int.from_bytes(take(3),'little');kind=(h>>1)&3;payload=h>>3
            need(kind!=3 and payload<=128*1024,'invalid zstd block')
            skip=1 if kind==1 else payload
            need(f.tell()+skip<=size,'truncated zstd block');f.seek(skip,1)
            if h&1:break
        take(4);need(f.tell()==size and not f.read(1),'extra zstd frames/trailing bytes')

def codec(mode,source,destination,budget,expected_bytes,receipts):
    need(sha(CODEC)==CODEC_SHA,'codec executable changed')
    src=Path(source);need(not src.is_symlink() and src.is_file(),'codec input type')
    command=[CODEC,'-q','--no-progress','--single-thread']
    command+=['-3','--check','--zstd=wlog=26','-c'] if mode=='compress' else ['-d','--memory=64MB','-c']
    fd=file_fd(src);out=None;p=None;selector=None;h=hashlib.sha256();count=0;error=bytearray()
    record=dict(mode=mode,argv=command,launched_executable_sha256=CODEC_SHA,
                cpu_affinity=CPUS,source=str(src),destination=str(destination) if destination else None,
                started_unix_ns=time.time_ns(),complete=False)
    receipts.append(record)
    try:
        if destination is not None:out=Path(destination).open('xb')
        p=subprocess.Popen(command,stdin=fd,stdout=out if mode=='compress' else subprocess.PIPE,stderr=subprocess.PIPE,
                           preexec_fn=lambda:os.sched_setaffinity(0,CPUS),start_new_session=True)
        fields=Path(f'/proc/{p.pid}/stat').read_text().rsplit(')',1)[1].split()
        record.update(pid=p.pid,start_ticks=int(fields[19]),observed_cpu_affinity=sorted(os.sched_getaffinity(p.pid)),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())
        selector=selectors.DefaultSelector()
        selector.register(p.stderr,selectors.EVENT_READ,'stderr')
        if mode!='compress':selector.register(p.stdout,selectors.EVENT_READ,'stdout')
        start=time.monotonic()
        while selector.get_map() or p.poll() is None:
            budget.check();need(time.monotonic()-start<=LIMITS['codec_seconds'],'codec deadline')
            if mode=='compress':
                count=os.fstat(out.fileno()).st_size
                need(count<=expected_bytes+expected_bytes//128+1024**2,'compressed output size cap')
            for key,_ in selector.select(0.05):
                chunk=os.read(key.fileobj.fileno(),LIMITS['io_bytes'])
                if not chunk:selector.unregister(key.fileobj);continue
                if key.data=='stderr':
                    error.extend(chunk);need(len(error)<=65536,'codec stderr cap')
                else:
                    count+=len(chunk);need(count<=expected_bytes,'decoded byte cap');h.update(chunk)
                    if out:out.write(chunk)
        status=p.wait();record['exit_code']=status
        if mode=='compress':
            count=os.fstat(out.fileno()).st_size
            need(count<=expected_bytes+expected_bytes//128+1024**2,'final compressed output size cap')
        need(status==0,'codec returned failure: '+error.decode(errors='replace'))
        if out:out.flush();os.fsync(out.fileno())
        if mode!='compress':need(count==expected_bytes,'decoded size differs')
        need(sha(CODEC)==CODEC_SHA,'codec changed during execution')
        record.update(complete=True,bytes=count,sha256=None if mode=='compress' else h.hexdigest())
        return dict(bytes=count,sha256=None if mode=='compress' else h.hexdigest())
    finally:
        if p:
            if p.poll() is None:p.kill()
            p.wait(timeout=10)
            record.update(exit_code=p.returncode,absent=not Path(f'/proc/{p.pid}').exists())
            for stream in (p.stdout,p.stderr):
                if stream:stream.close()
        if out:out.close()
        if selector:selector.close()
        os.close(fd);record['ended_unix_ns']=time.time_ns()


def retain_tree(scratch,link,fixture,campaign,children,identities,*,reference_check=no_references,budget=None,test_root=None):
    scratch=Path(scratch);link=Path(link);fixture=Path(fixture);campaign=Path(campaign)
    need(scratch==scratch.resolve() and fixture==fixture.resolve() and campaign==campaign.resolve(), 'noncanonical source/fixture root')
    need(link==fixture/'data', 'exact logical data path required')
    if test_root is not None:need(Path(test_root)==Path(test_root).resolve(), 'noncanonical synthetic root')
    if test_root is None:
        need(scratch.parent==Path('/dev/shm') and scratch.name.startswith('kv9-ready-tmpfs-'),'unowned scratch')
        need(fixture.is_relative_to(campaign) and link==fixture/'data','fixture path binding')
    else:
        need(Path(test_root).is_relative_to(Path(__file__).parent/'synthetic-first') and
             scratch.is_relative_to(test_root) and fixture.is_relative_to(test_root),'synthetic scope escape')
    need(link.is_symlink() and link.resolve()==scratch and not scratch.is_symlink(),'source link binding')
    need(children and all(p.poll() is not None and not Path(f'/proc/{p.pid}').exists() for p in children),'writer not reaped/absent')
    owner_rows=[dict(pid=p.pid,exit_code=p.poll(),identity=identities[p.pid],absent=True) for p in children]
    destination=fixture/'retention-objects';need(not destination.exists(),'retention destination collision')
    budget=budget or Budget(campaign);budget.check(LIMITS['metadata_bytes'])
    refs=reference_check(scratch);initial=tree_inventory(scratch,budget.check)
    logical_before=0
    for root in logical_roots(campaign):
        for prior in root.glob('*/fixture/tmpfs-retention.json'):
            value=json.loads(prior.read_text());logical_before+=sum(x['bytes'] for x in value['files'].values())
    need(logical_before+initial['logical_bytes']<=LIMITS['campaign_bytes'],'campaign logical retention cap')
    destination.mkdir();fsync_dir(fixture)
    receipts=[];started=time.time_ns();catalog=None
    try:
        original=dict(schema=1,original_scratch=str(scratch),logical_data=str(link),started_unix_ns=started,
                      children=owner_rows,reference_check=refs,inventory=initial)
        exclusive_json(fixture/'retention-original.json',original)
        members=[]
        for ordinal,(name,item) in enumerate(initial['files'].items()):
            budget.check(item['bytes']+item['bytes']//128+1024**2+LIMITS['metadata_bytes'])
            path=scratch/name;need(stable(meta(path))==stable(item['metadata']),'changed source before codec')
            obj=destination/f'{ordinal:06d}.zst'
            codec('compress',path,obj,budget,item['bytes'],receipts)
            single_frame(obj)
            decoded=codec('decode',obj,None,budget,item['bytes'],receipts)
            need(decoded=={k:item[k] for k in ('bytes','sha256')},'decoded original hash differs')
            current=hash_original(path,item['metadata'],budget.check)
            need(current['sha256']==item['sha256'],'source changed after compression')
            members.append(dict(name=name,original_path=str(link/name),original=item,
                                object=str(obj.relative_to(fixture)),compressed_bytes=obj.stat().st_size,
                                compressed_sha256=sha(obj)))
        after=tree_inventory(scratch,budget.check)
        need({k:{x:stable(y) for x,y in v.items()} if k=='directories' else v for k,v in after.items()}==
             {k:{x:stable(y) for x,y in v.items()} if k=='directories' else v for k,v in initial.items()},'original tree changed')
        refs_final=reference_check(scratch)
        need(all(p.poll() is not None and not Path(f'/proc/{p.pid}').exists() for p in children),'writer reappeared')
        catalog=dict(schema=1,storage_policy=STORAGE_POLICY,storage_policy_sha256=STORAGE_POLICY_SHA,representation='zstd-files-v1',resident_original_paths=False,synthetic_only=test_root is not None,
                     fixture=str(fixture),logical_data=str(link),original_scratch=str(scratch),
                     limits=LIMITS,logical_campaign_roots=[str(x) for x in logical_roots(campaign)],
                     prior_logical_bytes=logical_before,codec=dict(path=CODEC,sha256=CODEC_SHA),members=members,
                     directories=initial['directories'],original_inventory_sha256=sha(fixture/'retention-original.json'),
                     children=owner_rows,reference_check=refs_final,codecs=receipts,
                     started_unix_ns=started,verified_unix_ns=time.time_ns())
        exclusive_json(fixture/'retention-catalog.json',catalog)
        fsync_dir(destination)
        exclusive_json(fixture/'retention-cleanup-intent.json',dict(catalog_sha256=sha(fixture/'retention-catalog.json'),
                       source_inventory_sha256=sha(fixture/'retention-original.json'),started_unix_ns=time.time_ns()))
        need(link.is_symlink() and link.resolve()==scratch,'source link changed before cleanup')
        for name,item in initial['files'].items():
            path=scratch/name;need(stable(meta(path))==stable(item['metadata']),'source changed before unlink')
            path.unlink()
        for name,m in sorted(initial['directories'].items(),key=lambda x:len(PurePosixPath(x[0]).parts),reverse=True):
            path=scratch/name;x=meta(path)
            need((x['device'],x['inode'])==(m['device'],m['inode']) and stat.S_ISDIR(x['mode']),'directory identity changed')
            path.rmdir()
        link.unlink();fsync_dir(fixture);budget.last_scan=0;budget.check()
        value=dict(schema=2,storage_policy=STORAGE_POLICY,storage_policy_sha256=STORAGE_POLICY_SHA,representation='zstd-files-v1',complete=True,children_exited=True,
                   original_scratch=str(scratch),scratch_removed=not scratch.exists(),resident_original_paths=False,
                   logical_data=str(link),retained_objects=str(destination),catalog_sha256=sha(fixture/'retention-catalog.json'),
                   original_inventory_sha256=sha(fixture/'retention-original.json'),
                   original_runtime_storage='volatile tmpfs',
                   retained_copy_storage='post-run compressed evidence; no runtime durability claim',
                   files={name:{k:item[k] for k in ('bytes','sha256')} for name,item in initial['files'].items()},
                   started_unix_ns=started,completed_unix_ns=time.time_ns(),budget=budget.report())
        exclusive_json(fixture/'tmpfs-retention.json',value)
        return value
    except BaseException as error:
        exclusive_json(fixture/'retention-failure-first.json',dict(failure=repr(error),codecs=receipts,
            original_scratch=str(scratch),scratch_present=scratch.exists(),catalog_committed=(fixture/'retention-catalog.json').exists(),
            cleanup_may_be_partial=(fixture/'retention-cleanup-intent.json').exists(),ended_unix_ns=time.time_ns()))
        raise


def close_fixture(fixture,base_close,campaign):
    # This is exactly benchmark.Fixture.close; do not call TmpfsFixture.close,
    # which would create the old full uncompressed disk copy first.
    base_close(fixture)
    return retain_tree(fixture.scratch,fixture.link,fixture.out,campaign,fixture.children,fixture.identities)


def restore(catalog_path,destination,expected_catalog_sha256=None):
    """Fresh-destination-only byte and metadata restoration, never old inode identity."""
    catalog_path=Path(catalog_path);fixture=catalog_path.parent;dst=Path(destination)
    need(catalog_path==catalog_path.resolve() and dst.is_absolute() and dst.parent==dst.parent.resolve(), 'noncanonical restore paths')
    for ancestor in [dst.parent,*dst.parent.parents]:
        need(stat.S_ISDIR(ancestor.lstat().st_mode), 'restore ancestor must be an ordinary non-symlink directory')
    if expected_catalog_sha256 is not None:need(sha(catalog_path)==expected_catalog_sha256,'reviewed restore catalog changed')
    catalog=json.loads(catalog_path.read_text());need(catalog['representation']=='zstd-files-v1','catalog schema')
    check_storage_policy(catalog)
    need(not dst.exists() and not dst.is_symlink(),'restore destination collision')
    need(catalog['limits']==LIMITS and catalog['codec']==dict(path=CODEC,sha256=CODEC_SHA),'restore codec/budget differs')
    seen=set();objects=set();total=0
    for row in catalog['members']:
        safe_name(row['name']);safe_name(row['object'])
        need(row['name'] not in seen and row['object'] not in objects,'duplicate restore member/object')
        seen.add(row['name']);objects.add(row['object'])
        need(len(PurePosixPath(row['object']).parts)==2 and row['object'].startswith('retention-objects/') and
             0<=row['original']['bytes']<=LIMITS['member_bytes'],'restore member binding')
        total+=row['original']['bytes']
    dirs=catalog['directories'];need('' in dirs,'restore root metadata absent')
    for name,m in dirs.items():
        if name:safe_name(name)
        need(stat.S_ISDIR(m['mode']) and name not in seen,'restore directory collision')
    need(total<=LIMITS['cohort_bytes'],'restore total cap')
    need(shutil.disk_usage(dst.parent).free>=LIMITS['retention_floor_bytes']+total+LIMITS['metadata_bytes'],'restore space refusal')
    dst.mkdir();receipts=[];budget=Budget.__new__(Budget)
    budget.campaign=dst;budget.roots=[dst];budget.started=time.monotonic();budget.minimum=None
    budget.samples=[];budget.last_scan=0;budget.physical=0
    try:
        for name in sorted(dirs,key=lambda x:len(PurePosixPath(x).parts)):
            if name:(dst/name).mkdir()
        for row in catalog['members']:
            obj=fixture/row['object'];need(not obj.is_symlink() and obj.is_file(),'missing restore object')
            need(not obj.parent.is_symlink() and obj.parent==fixture/'retention-objects','restore object parent')
            need(obj.stat().st_size==row['compressed_bytes'] and sha(obj)==row['compressed_sha256'],'restore object hash/size')
            single_frame(obj)
            target=dst/row['name']
            verified=codec('decode',obj,target,budget,row['original']['bytes'],receipts)
            need(verified=={k:row['original'][k] for k in ('bytes','sha256')},'restore original hash/size')
            m=row['original']['metadata'];os.chown(target,m['uid'],m['gid']);os.chmod(target,stat.S_IMODE(m['mode']))
            os.utime(target,ns=(m['atime_ns'],m['mtime_ns']),follow_symlinks=False)
            need(hash_original(target)['sha256']==row['original']['sha256'],'restored final hash')
        for name,m in sorted(dirs.items(),key=lambda x:len(PurePosixPath(x[0]).parts),reverse=True):
            target=dst/name;os.chown(target,m['uid'],m['gid']);os.chmod(target,stat.S_IMODE(m['mode']))
            os.utime(target,ns=(m['atime_ns'],m['mtime_ns']),follow_symlinks=False);fsync_dir(target)
        receipt=dict(complete=True,storage_policy=STORAGE_POLICY,storage_policy_sha256=STORAGE_POLICY_SHA,catalog_sha256=sha(catalog_path),destination=str(dst),files=len(seen),
                     logical_bytes=total,codecs=receipts,byte_exact=True,original_inode_identity=False,
                     metadata_fields_restored=['mode','uid','gid','atime_ns','mtime_ns'],
                     metadata_fields_observational_only=['device','inode','ctime_ns','blocks','nlink'],
                     ended_unix_ns=time.time_ns())
        exclusive_json(dst.parent/(dst.name+'-restore-receipt.json'),receipt)
        return receipt
    except BaseException as e:
        exclusive_json(dst.parent/(dst.name+'-restore-failure-first.json'),dict(failure=repr(e),codecs=receipts));raise

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--restore-catalog',type=Path,required=True)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--expected-catalog-sha256',required=True)
    a=parser.parse_args();restore(a.restore_catalog,a.destination,a.expected_catalog_sha256)
