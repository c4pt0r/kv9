#!/usr/bin/env python3
"""Finite metadata extraction for the completed receipt-tail write screen."""
import hashlib, importlib.util, json, math, os
from pathlib import Path

P = Path(__file__).resolve().parent
RUN = Path('/tmp/kv9-receipt-tail-performance-v3-timing-20260915-first/cohorts')
PREP = Path('/tmp/kv9-receipt-tail-performance-v3-preparation-20260915-first')
HELPER = Path('/tmp/kv9-fnv-writer-budget-v2-reporting-20260914-first/summarize.py')
used = {}
def read(p):
    p = Path(p)
    assert p.is_file() and not p.is_symlink() and p.stat().st_size < 32 * 1024**2
    b = p.read_bytes()
    pin = dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
    assert str(p) not in used or used[str(p)] == pin
    used[str(p)] = pin
    return b
def js(p): return json.loads(read(p))
def save(name, value):
    with (P/name).open('x') as f: json.dump(value, f, indent=2); f.write('\n')
def change(old, new): return (new/old - 1)*100

assert __debug__ and set(os.sched_getaffinity(0)) == set(range(6,16)) | set(range(22,32))
read(__file__); read(HELPER)
spec = importlib.util.spec_from_file_location('accepted_histogram', HELPER)
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
audit = js(PREP/'results-first/audit.json')
inventory = js(PREP/'results-first/input-inventory.json')
EVIDENCE = Path('/tmp/kv9-receipt-tail-performance-v3-execution-evidence-20260915-first')
term = js(EVIDENCE/'audit-terminal.json')
assert term['session_id'] == 16800 and term['terminal']['chunk_id'] == '8faaea' and term['terminal']['exit_code'] == 0
assert used[str(PREP/'results-first/audit.json')]['sha256'] == '9d87ba394620f4bdca9c8ce5a86efb7f0615b88bc3123ff5f5ffc1c3b59b7a36'
for name in ('audit-invocation.json','audit-acceptance.json','timing-terminal.json','smoke-terminal.json','smoke-readback-terminal.json'): js(EVIDENCE/name)
def bound(p):
    d = js(p); assert inventory[str(p)] == used[str(p)], str(p); return d
assert audit['complete'] and audit['matched_diagnostic_accepted']
assert audit['parent_confirmed_session'] == 84770 and audit['parent_confirmed_exit_code'] == 0
assert audit['successful_arms'] == audit['expected_successful_arms'] == len(audit['cases']) == 16
assert audit['outer_restoration']['accepted'] and not audit['performance_promotion']
matrix = bound(RUN/'matrix.json'); protocol = js(PREP/'protocol.json')
assert matrix['complete'] and not matrix['smoke']
assert matrix['cohort_inventory'] == protocol['timed_inventory']
assert matrix['protocol_id'] == protocol['protocol_id'] == audit['protocol_id'] == 'kv9-receipt-tail-write-ab-c1-c64-storage-v3'
assert len(matrix['attempts']) == 16
roles = {}
for role in ('old', 'new', 'client'):
    r = matrix['role_bindings'][role]
    roles[role] = dict(source_path=r['source']['path'], revision=r['source']['revision'], source_tree_sha256=r['source']['source_tree_sha256'], binary=r['binary'], binary_sha256=r['binary_sha256'])
assert roles['old']['revision'].startswith('bd42e60') and roles['new']['revision'].startswith('a6ac335')
assert roles['client']['revision'] == matrix['client_revision'] == '0be806d9671e2c50701a64aa7889c8859b7648ba'
rows, populations = [], {}
for ordinal, (case, desc, attempt) in enumerate(zip(audit['cases'], matrix['cohort_inventory'], matrix['attempts'])):
    folder = Path(case['directory']); assert folder.parent == RUN and attempt['directory'] == str(folder)
    assert case['ordinal'] == attempt['index'] == ordinal and desc == attempt['descriptor']
    assert case['repeat'] == desc['repeat'] and case['concurrency'] == desc['shared']['workers']
    report = bound(folder/'run/report.json'); cfg = bound(folder/'requested-config.json'); coverage = bound(folder/'resource-coverage.json')
    assert all(cfg[k] == v for k,v in desc['shared'].items())
    assert used[str(folder/'run/report.json')]['sha256'] == case['report_sha256'] == attempt['report_sha256']
    assert report['complete'] and report['timing_eligible'] and report['failure'] is None
    metrics = report['metrics']['measurement']; assert metrics['valid'] and metrics['histogram_subdivisions'] == 64
    assert sum(p['calls'] for p in metrics['statistics'][0]['populations']) == 0
    ps = metrics['statistics'][1]['populations']; populations[ordinal] = ps
    lat = h.latency(ps); assert lat == case['whole_call_latency']
    outcomes = {k:p['calls'] for k,p in zip(metrics['outcomes'], ps)}
    assert outcomes == case['outcomes'] and sum(outcomes.values()) == case['calls'] == report['measured_completed']
    assert sum(p['input_items'] for p in ps) == case['input_items']
    elapsed = report['cohort_elapsed_ns']; assert elapsed == case['cohort_elapsed_ns']
    attempts = sum(sum(s['attempt_reasons']) for s in metrics['statistics'])
    assert attempts == case['attempts'] and report['dropped_slots'] == case['dropped_slots']
    batch = desc['shared']['batch_size']; assert batch in (1,64) and desc['shared']['read_percent'] == 0
    api = 'Put' if batch == 1 else 'BatchPut64'
    assert metrics['operations'][1] == ('put' if batch == 1 else 'batch_put')
    memory = case['server_memory']; assert set(memory) == {'voter-1','voter-2','voter-3'}
    assert all(v['samples'] == coverage['samples'] for v in memory.values())
    assert all(v['rss_max_bytes'] == coverage['cpu'][k]['peak_rss_bytes'] for k,v in memory.items())
    row = dict(ordinal=ordinal, directory=str(folder), api=api, role=desc['server_role'], concurrency=case['concurrency'], repeat=case['repeat'], elapsed_ns=elapsed, successful_calls=ps[0]['calls'], successful_items=ps[0]['input_items'], completed_calls=case['calls'], issued=report['measured_issued'], attempts=attempts, dropped_slots=report['dropped_slots'], outcomes=outcomes, whole_call_latency=lat, successful_calls_per_second=ps[0]['calls']*1e9/elapsed, successful_items_per_second=ps[0]['input_items']*1e9/elapsed, report_pin=used[str(folder/'run/report.json')], server_memory=memory, sum_sampled_voter_mean_rss_bytes=sum(v['rss_mean_bytes'] for v in memory.values()), sum_separate_voter_rss_max_bytes=sum(v['rss_max_bytes'] for v in memory.values()))
    assert math.isclose(row['successful_calls_per_second'], case['successful_calls_per_second'], rel_tol=1e-12)
    row['healthy'] = row['successful_calls'] == row['completed_calls'] == row['issued'] == attempts and not row['dropped_slots'] and all(k == 'success' or v == 0 for k,v in outcomes.items())
    rows.append(row)

def pool(rs):
    elapsed = sum(r['elapsed_ns'] for r in rs)
    return dict(ordinals=[r['ordinal'] for r in rs], elapsed_ns=elapsed, successful_calls=sum(r['successful_calls'] for r in rs), successful_items=sum(r['successful_items'] for r in rs), successful_calls_per_second=sum(r['successful_calls'] for r in rs)*1e9/elapsed, successful_items_per_second=sum(r['successful_items'] for r in rs)*1e9/elapsed, whole_call_latency=h.latency([p for r in rs for p in populations[r['ordinal']]]), mean_run_voter_sampled_rss_bytes=sum(r['sum_sampled_voter_mean_rss_bytes']*r['elapsed_ns'] for r in rs)/elapsed, largest_run_sum_separate_voter_rss_max_bytes=max(r['sum_separate_voter_rss_max_bytes'] for r in rs))
comparisons=[]
for api in ('Put', 'BatchPut64'):
    for c in (1,64):
        for repeat in (0,1,None):
            selected = {role:[r for r in rows if r['api'] == api and r['concurrency'] == c and r['role'] == role and (repeat is None or r['repeat'] == repeat)] for role in ('old','new')}
            assert all(len(v) == (2 if repeat is None else 1) for v in selected.values())
            old, new = [pool(selected[role]) for role in ('old','new')]
            rate = 'successful_calls_per_second' if api == 'Put' else 'successful_items_per_second'
            comparisons.append(dict(api=api,concurrency=c,repeat=repeat,scope='pooled' if repeat is None else ('old-first' if repeat == 0 else 'new-first'),rate_unit='calls/s' if api == 'Put' else 'items/s',old=old,new=new,throughput_change_percent=change(old[rate],new[rate]),mean_change_percent=change(old['whole_call_latency']['mean_ns'],new['whole_call_latency']['mean_ns']),p99_direction=h.bucket_direction(old['whole_call_latency']['p99'],new['whole_call_latency']['p99']),sampled_rss_mean_change_percent=change(old['mean_run_voter_sampled_rss_bytes'],new['mean_run_voter_sampled_rss_bytes']),max_voter_rss_sum_change_percent=change(old['largest_run_sum_separate_voter_rss_max_bytes'],new['largest_run_sum_separate_voter_rss_max_bytes'])))
result=dict(complete=True,analysis_only=True,audit_accepted=True,actual_audit_receipt='16800/8faaea/0 (parent-reported actual tool terminal)',actual_timing_receipt='84770/38c0ab/0',audit_pin=used[str(PREP/'results-first/audit.json')],audit_inventory_pin=used[str(PREP/'results-first/input-inventory.json')],protocol_id=matrix['protocol_id'],roles=roles,all_16_healthy=all(r['healthy'] for r in rows),successful_calls=sum(r['successful_calls'] for r in rows),successful_items=sum(r['successful_items'] for r in rows),comparisons=comparisons,cohorts=rows,scope=audit['scope'],latency_method='Unchanged accepted histogram helper; merge integer counts/sums and percentile ranks; whole logical call, never divide batch latency by64 or average per-run percentiles.',rate_method='Sum successful work / sum actual cohort_elapsed_ns, including completed in-flight calls as the original report does.',memory_method='Audited in-measurement sampled RSS. Mean of run voter sums weighted by actual cohort duration; separate voter maxima are not necessarily simultaneous. HWM retained per voter is process-lifetime, not measurement-only.',selection_changed=False)
for path,pin in list(used.items()):read(path);assert used[path] == pin
result['actual_audit_receipt'] = '16800/8faaea/0'
result['actual_audit_terminal'] = dict(path=str(EVIDENCE/'audit-terminal.json'), **used[str(EVIDENCE/'audit-terminal.json')])
save('summary.json',result);save('input-hashes.json',used)
print(json.dumps(dict(complete=True,audit_pin=result['audit_pin'],successful_calls=result['successful_calls'],successful_items=result['successful_items'],all_16_healthy=result['all_16_healthy'],comparisons=[{k:v for k,v in c.items() if k not in ('old','new')}for c in comparisons]),indent=2))
