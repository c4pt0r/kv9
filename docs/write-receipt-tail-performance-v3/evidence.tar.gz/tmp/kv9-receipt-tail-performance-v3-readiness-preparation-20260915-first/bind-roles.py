"""Root-only existing role/source/Cargo readers. No builds, workloads or codecs."""
import argparse,hashlib,importlib.util,json,os,sys,time,types
from pathlib import Path
Q=Path(__file__).resolve().parent
P=Path('/tmp/kv9-receipt-tail-performance-v3-preparation-20260915-first')
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
a=argparse.ArgumentParser(description=__doc__);a.add_argument('--expected-driver-sha256',required=True);a.add_argument('--output',type=Path,required=True);args=a.parse_args()
assert __debug__
assert sha(P/'matched-driver.py')==args.expected_driver_sha256
out=args.output.absolute();assert out.parent==Q and not out.exists()
manifest=json.loads((Q/'role-inputs.json').read_text());values=manifest['arguments'];kwargs={k:Path(v)if k.endswith(('_source','_build'))else v for k,v in values.items()}
spec=importlib.util.spec_from_file_location('receipt_matched_driver',P/'matched-driver.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
started=time.time_ns();roles=d.verify_inputs(types.SimpleNamespace(**kwargs))
sys.path.insert(0,str(kwargs['client_source']/'scripts'));import batch_benchmark_report as native
cargo=d.verify_client_cargo(types.SimpleNamespace(**kwargs),native)
assert set(roles)=={'old','new','client'} and cargo['client']['features']==[]
r=dict(complete=True,started_ns=started,ended_ns=time.time_ns(),driver_sha256=args.expected_driver_sha256,role_inputs_sha256=sha(Q/'role-inputs.json'),roles=roles,client_cargo=cargo,runtime_ready=False,scope='Fresh original role/source/binary/compiler/default-feature readers passed. No capacity release, build or workload executed.')
raw=(json.dumps(r,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<=8*1024**2
with out.open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
print(json.dumps(dict(complete=True,roles={k:dict(source_files=len(v['source']['sources']),revision=v['source']['revision'],binary_sha256=v['binary_sha256'])for k,v in roles.items()},result_sha256=sha(out),runtime_ready=False)))
