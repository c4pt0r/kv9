"""Focused actual-reader source/pin refusals using tiny synthetic metadata; no process or payload execution."""
import ast,copy,hashlib,importlib.util,json,types,unittest
from pathlib import Path
from unittest.mock import patch
Q=Path(__file__).resolve().parent;P=Path('/tmp/kv9-receipt-tail-performance-v3-preparation-20260915-first')
spec=importlib.util.spec_from_file_location('receipt_driver_controls',P/'matched-driver.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
class SourceBindings(unittest.TestCase):
 def manifest(self):
  sources={'runtime.rs':'a'*64}
  return dict(revision=d.NEW_REVISION,dirty=False,profile='release',sources=sources,source_tree_sha256=hashlib.sha256(json.dumps(sources,sort_keys=True,separators=(',',':')).encode()).hexdigest())
 def test_current_source_positive_without_filesystem_or_git(self):
  with patch.object(d.subprocess,'check_output',side_effect=[d.NEW_REVISION+'\n','']),patch.object(d,'digest',return_value='a'*64):
   row=d.source_binding(Path('/synthetic/receipt'),self.manifest(),d.NEW_REVISION)
  self.assertEqual(row['revision'],'a6ac335ef4567f2e1a2b33da1a723d694cd5b7d9')
 def test_prior_candidate_and_default_production_revision_refused(self):
  for revision in ['483b8c3629b033734f5d7a2b8653a1352304a4b5','12f44d35590ede5f89337fe731dd950162865154',d.OLD_REVISION]:
   m=self.manifest();m['revision']=revision
   with self.subTest(revision=revision),patch.object(d.subprocess,'check_output')as call,self.assertRaisesRegex(ValueError,'expected clean release'):
    d.source_binding(Path('/synthetic/receipt'),m,d.NEW_REVISION)
   call.assert_not_called()
 def test_wrong_tree_digest_refused_before_git(self):
  m=self.manifest();m['source_tree_sha256']='0'*64
  with patch.object(d.subprocess,'check_output')as call,self.assertRaisesRegex(ValueError,'inventory digest'):
   d.source_binding(Path('/synthetic/receipt'),m,d.NEW_REVISION)
  call.assert_not_called()
 def test_wrong_checkout_revision_and_dirty_checkout_refused(self):
  for responses,message in [([d.OLD_REVISION+'\n'],'checkout revision'),([d.NEW_REVISION+'\n',' M runtime.rs\n'],'checkout is dirty')]:
   with patch.object(d.subprocess,'check_output',side_effect=responses),self.assertRaisesRegex(ValueError,message):
    d.source_binding(Path('/synthetic/receipt'),self.manifest(),d.NEW_REVISION)
 def test_modified_runtime_bytes_refused(self):
  with patch.object(d.subprocess,'check_output',side_effect=[d.NEW_REVISION+'\n','']),patch.object(d,'digest',return_value='b'*64),self.assertRaisesRegex(ValueError,'source bytes differ'):
   d.source_binding(Path('/synthetic/receipt'),self.manifest(),d.NEW_REVISION)
 def test_actual_driver_auditor_protocol_and_source_role_pins(self):
  raw=(P/'audit.py').read_text();tree=ast.parse(raw);wanted={'CLIENT_REV','OLD_REV','NEW_REV','PINS','ROLE_PATHS','SERVER_MANIFESTS','PROTOCOL_ID'}
  nodes=[n for n in tree.body if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)and n.targets[0].id in wanted]
  env={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual audit constant pins>','exec'),env)
  protocol=json.loads((P/'protocol.json').read_text());roles=json.loads((Q/'role-inputs.json').read_text())
  self.assertEqual(protocol['protocol_id'],d.PROTOCOL_ID);self.assertEqual(env['PROTOCOL_ID'],d.PROTOCOL_ID)
  for role,pin in d.SERVER_PINS.items():
   self.assertEqual(env['PINS'][role],(pin['revision'],pin['binary_sha256']))
   self.assertEqual(env['SERVER_MANIFESTS'][role],pin['manifest_sha256']);self.assertEqual(protocol['server_pins'][role],pin)
   self.assertEqual(env['ROLE_PATHS'][role][:2],(roles['arguments'][role+'_server_source'],roles['arguments'][role+'_server_build']))
  self.assertEqual(env['CLIENT_REV'],d.REDIS_REVISION);self.assertEqual(protocol['client_sha256'],d.CLIENT_PINS['client']['binary_sha256'])
  self.assertEqual(env['ROLE_PATHS']['new'][0],'/tmp/kv9-receipt-tail-release-source-20260915-first')
 def test_actual_manifest_and_binary_mismatch_refusal(self):
  args=types.SimpleNamespace(**{k:Path(v)if k.endswith(('_source','_build'))else v for k,v in json.loads((Q/'role-inputs.json').read_text())['arguments'].items()})
  common='crates/server/src/bin/kv9-batch-benchmark/common.rs';source={common:'b98d4a49f9ee2199e183204b72fd52813907574a03c1cf3376cf5d281d7902fd'}
  documents={};hashes={}
  for role in ['old','new']:
   build=getattr(args,role+'_server_build');pin=d.SERVER_PINS[role]
   documents[build/'build.json']=dict(revision=pin['revision'],dirty=False,profile='release',rustc='same compiler',binaries={'kv9':dict(command=d.SERVER_COMMAND,sha256=pin['binary_sha256'])})
   hashes.update({build/'build.json':pin['manifest_sha256'],build/'kv9':pin['binary_sha256'],build/'kv9-cargo.jsonl':'c'*64})
  build=args.client_build;pin=d.CLIENT_PINS['client'];m=dict(revision=args.expected_client_revision,dirty=False,profile='release',rustc='same compiler',source_tree_sha256='d'*64,binary_sha256=pin['binary_sha256'])
  documents[build/'build.json']=m;documents[build/'sources.json']=dict(m,sources=source)
  hashes.update({build/'build.json':pin['manifest_sha256'],build/'kv9-batch-benchmark':pin['binary_sha256'],build/'sources.json':'e'*64,build/'cargo.jsonl':'f'*64})
  def bound(source_path,manifest,revision):return dict(path=str(source_path),revision=revision,sources=source)
  with patch.object(d,'read',side_effect=lambda p:copy.deepcopy(documents[p])),patch.object(d,'source_binding',side_effect=bound),patch.object(d,'cargo_server',return_value={}):
   with patch.object(d,'digest',side_effect=lambda p:hashes[p]):self.assertEqual(set(d.verify_inputs(args)),{'old','new','client'})
   for suffix,message in [('build.json','frozen server manifest'),('kv9','frozen server binary')]:
    bad=dict(hashes);bad[args.new_server_build/suffix]='0'*64
    with self.subTest(suffix=suffix),patch.object(d,'digest',side_effect=lambda p:bad[p]),self.assertRaisesRegex(ValueError,message):d.verify_inputs(args)
 def test_safe_directory_is_exact_three_command_scoped_sources(self):
  c=json.loads((Q/'runtime-commands.json').read_text());wanted={'/tmp/kv9-crc-main-bd42-baseline-20260914-first','/tmp/kv9-receipt-tail-release-source-20260915-first','/tmp/kv9-point-write-measurement-v3'}
  for phase,row in c.items():
   argv=row['argv'];self.assertEqual(argv[:3],['sudo','-n','env'])
   self.assertIn('GIT_CONFIG_COUNT=3',argv)
   self.assertEqual({v.split('=',1)[1]for v in argv if v.startswith('GIT_CONFIG_VALUE_')},wanted)
   self.assertEqual([v for v in argv if v.startswith('GIT_CONFIG_KEY_')],[f'GIT_CONFIG_KEY_{i}=safe.directory'for i in range(3)])
if __name__=='__main__':unittest.main(verbosity=2)
