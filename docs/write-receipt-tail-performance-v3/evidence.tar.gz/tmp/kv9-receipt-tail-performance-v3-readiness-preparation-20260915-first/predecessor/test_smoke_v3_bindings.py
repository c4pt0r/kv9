"""Focused assertions from the actual corrected smoke reader; no workload or codec."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
PREP = Path('/tmp/kv9-published-directory-performance-v3-preparation-20260915-first')
SMOKE = Path('/tmp/kv9-published-directory-performance-v3-smoke-20260915-first')
TIMING = '/tmp/kv9-published-directory-performance-v3-timing-20260915-first/cohorts'
HELPER = '1f87075106081831d689ddcb5d21ad744f2a1ea3c8554e1d048045ff74fdec6a'
POLICY = 'cebdc41bbed8fd7000ef11fc5de29aa10722fc1112008366ef24e2e7d8924ba1'
SOURCE = (HERE / 'check-smoke-v3.py').read_text()
TREE = ast.parse(SOURCE)
ASSERTIONS = [n for n in TREE.body if isinstance(n, ast.Assert)
              and "matrix['compressed_retention']" in ast.get_source_segment(SOURCE, n)]
assert len(ASSERTIONS) == 4
DRIVER_SOURCE = (PREP / 'matched-driver.py').read_text()
DRIVER_TREE = ast.parse(DRIVER_SOURCE)
DEFINITIONS = [n for n in DRIVER_TREE.body if
              (isinstance(n, ast.FunctionDef) and n.name in {'require', 'check_storage_policy'}) or
              (isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
               and n.targets[0].id in {'STORAGE_POLICY', 'STORAGE_POLICY_SHA'})]
assert len(DEFINITIONS) == 4
policy_scope = {'json': json}
exec(compile(ast.Module(body=DEFINITIONS, type_ignores=[]), '<original-v3-policy>', 'exec'), policy_scope)


def original_v3():
    limits = dict(member_bytes=8*1024**3, cohort_bytes=16*1024**3,
                  campaign_bytes=128*1024**3, metadata_bytes=8*1024**2,
                  files=65536, codec_seconds=600, cohort_seconds=1800,
                  io_bytes=1024**2, decode_memory_bytes=64*1024**2,
                  retention_floor_bytes=8*1024**3)
    return dict(compressed_retention=dict(helper_sha256=HELPER, limits=limits,
                logical_campaign_roots=[str(SMOKE), TIMING],
                storage_policy=json.loads((PREP / 'storage-policy.json').read_text()),
                storage_policy_sha256=POLICY),
                helper_hashes={str(PREP / 'compressed_retention.py'): HELPER})


def check(matrix):
    policy_scope['check_storage_policy'](matrix['compressed_retention'])
    exec(compile(ast.Module(body=ASSERTIONS, type_ignores=[]), '<actual-smoke-v3-assertions>', 'exec'),
         dict(matrix=matrix, PREP=PREP, SMOKE=SMOKE))


class SmokeV3Bindings(unittest.TestCase):
    def test_current_v3_exact_positive(self):
        self.assertEqual(hashlib.sha256((PREP / 'compressed_retention.py').read_bytes()).hexdigest(), HELPER)
        self.assertEqual(hashlib.sha256((PREP / 'storage-policy.json').read_bytes()).hexdigest(), POLICY)
        check(original_v3())

    def test_old_retention_helper_rejected(self):
        m=original_v3(); m['compressed_retention']['helper_sha256']='b7aeea4c08d20d18bc3866d5511be2f1eaa65c16feef75cee18f07ffdd595b13'
        with self.assertRaises(AssertionError): check(m)

    def test_old_48_gib_floor_rejected(self):
        m=original_v3(); m['compressed_retention']['limits']['retention_floor_bytes']=48*1024**3
        with self.assertRaises(AssertionError): check(m)

    def test_executed_helper_mismatch_rejected(self):
        m=original_v3(); m['helper_hashes'][str(PREP / 'compressed_retention.py')]='0'*64
        with self.assertRaises(AssertionError): check(m)

    def test_v2_policy_rejected(self):
        m=original_v3(); m['compressed_retention']['storage_policy']['policy_id']='kv9-local-benchmark-storage-v2'
        with self.assertRaises(ValueError): check(m)

    def test_wrong_policy_hash_rejected(self):
        m=original_v3(); m['compressed_retention']['storage_policy_sha256']='0'*64
        with self.assertRaises(ValueError): check(m)

    def test_missing_combined_root_rejected(self):
        m=original_v3(); m['compressed_retention']['logical_campaign_roots'].pop()
        with self.assertRaises(AssertionError): check(m)

    def test_other_caps_unchanged(self):
        good=original_v3()
        for key in ('member_bytes','cohort_bytes','campaign_bytes','metadata_bytes','files','codec_seconds','cohort_seconds','io_bytes','decode_memory_bytes'):
            m=copy.deepcopy(good);m['compressed_retention']['limits'][key]+=1
            with self.subTest(key=key), self.assertRaises(AssertionError): check(m)


if __name__ == '__main__':
    unittest.main(verbosity=2)
