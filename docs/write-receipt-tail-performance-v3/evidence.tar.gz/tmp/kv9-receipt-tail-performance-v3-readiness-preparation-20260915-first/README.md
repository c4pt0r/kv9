# Root handoff

Preparation is frozen; runtime readiness is false. Exact current release, recovery and full21 Chaos/post acceptance are bound in `completed-prerequisites.json`. Historical controls are authority for unchanged code only; they are not current benchmark acceptance.

Execute these three arrays from `ROOT-COMMANDS.json`, in order, retaining each actual tool terminal and output:

1. `targeted_changed_source_controls` (eight small metadata/source refusal controls).
2. `focused_smoke_reader_controls` (eight corrected v3 policy/helper binding controls).
3. `bind_current_source_and_retained_roles` (original source-map, binary, compiler and default-feature readers; no build).

All arrays use helper CPUs 6-15,22-31 and command-scoped safe.directory for exactly the three frozen checkouts. The binder requires the actual derived driver SHA and emits the fresh `role-bindings-first.json`; no result exists yet. Inherited 71 codec/lifecycle controls remain available but are not part of this necessary changed-source check sequence.

After those succeed, root separately records fresh full-campaign capacity and absence of competing work, then runs the exact smoke array, corrected smoke readback, a fresh remaining-capacity check, timing isolation wrapper and independent audit. Only substitute `ACTUAL_TERMINAL_TIMING_SESSION` in the audit argv with the actual successful timing session. No launch receipt is acceptance. All timing, audit, source-binding and current-control results are pending.

The observation in `capacity-observation.json` is dated evidence, not a reservation: 25,120,661,504 bytes free versus the inherited empirical full-campaign scenario of 79,455,850,496 bytes (54,335,188,992-byte observed gap). Actual compression and changed throughput can change retention; the protocol's guards and hard caps remain controlling. Root's later free-space observation was 25,119,088,640 bytes. No prior cleanup is credited again. Root owns any separate lossless capacity work.

`runtime-commands.json` holds the four exact phase argv arrays. The output directories are fresh receipt-tail smoke, timing/cohorts, auditor results and readiness/smoke-readback paths. Originals, retained ELFs, benchmark/Chaos payloads and all existing COLD catalogs remain untouched. Publication and reporting are outside this preparation.
