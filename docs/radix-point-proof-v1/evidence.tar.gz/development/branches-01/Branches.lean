import Std

/- Local semantic rewrites for the actual radix split/collapse and path frames.
   This module alone is NOT whole-tree or Rust implementation refinement.
   Byte paths use UInt8. Subtree interpretations are pointwise finite-map views;
   the tree invariant and operational correspondence are separate obligations. -/
namespace Kv9.Radix

abbrev Key := List UInt8
abbrev Value := List UInt8
abbrev Map := Key → Option Value
abbrev Edges := UInt8 → Map

def strip : Key → Key → Option Key
  | [], query => some query
  | _ :: _, [] => none
  | byte :: prefix, head :: tail => if byte = head then strip prefix tail else none

theorem strip_some_iff (prefix query suffix : Key) :
    strip prefix query = some suffix ↔ query = prefix ++ suffix := by
  induction prefix generalizing query with
  | nil => simp [strip]
  | cons byte prefix ih =>
      cases query with
      | nil => simp [strip]
      | cons head tail =>
          by_cases same : byte = head
          · subst head
            simp [strip, ih]
          · simp [strip, same, Ne.symm same]

theorem strip_append (prefix suffix : Key) :
    strip prefix (prefix ++ suffix) = some suffix :=
  (strip_some_iff prefix _ suffix).mpr rfl

theorem strip_empty_suffix (prefix query : Key) :
    strip prefix query = some [] ↔ query = prefix := by
  simpa using strip_some_iff prefix query []

theorem strip_consumed_bound (prefix query suffix : Key)
    (h : strip prefix query = some suffix) :
    prefix.length ≤ query.length ∧ query.length = prefix.length + suffix.length := by
  have eq := (strip_some_iff _ _ _).mp h
  simp [eq]

theorem strip_composed (a b query : Key) :
    strip (a ++ b) query = (strip a query).bind (strip b) := by
  induction a generalizing query with
  | nil => simp [strip]
  | cons head tail ih =>
      cases query with
      | nil => simp [strip]
      | cons byte rest =>
          by_cases same : head = byte <;> simp [strip, same, ih]

def empty : Map := fun _ => none
def singleton (key : Key) (value : Value) : Map :=
  fun query => if query = key then some value else none
def put (key : Key) (value : Value) (state : Map) : Map :=
  fun query => if query = key then some value else state query
def erase (key : Key) (state : Map) : Map :=
  fun query => if query = key then none else state query
def under (prefix : Key) (state : Map) : Map :=
  fun query => (strip prefix query).bind state
def route (terminal : Option Value) (edges : Edges) : Map
  | [] => terminal
  | byte :: suffix => edges byte suffix
def noEdges : Edges := fun _ => empty
def replaceEdge (byte : UInt8) (child : Map) (edges : Edges) : Edges :=
  fun query => if query = byte then child else edges query
def oneEdge (byte : UInt8) (child : Map) : Edges := replaceEdge byte child noEdges

theorem under_nil (state : Map) : under [] state = state := by
  funext query
  simp [under, strip]

theorem under_composed (a b : Key) (state : Map) :
    under a (under b state) = under (a ++ b) state := by
  funext query
  simp [under, strip_composed, Option.bind_assoc]

theorem under_empty (prefix : Key) : under prefix empty = empty := by
  funext query
  simp [under, empty]

theorem under_singleton (prefix key : Key) (value : Value) :
    under prefix (singleton key value) = singleton (prefix ++ key) value := by
  funext query
  cases h : strip prefix query with
  | none =>
      have absent : query ≠ prefix ++ key := by
        intro eq
        simp [eq, strip_append] at h
      simp [under, singleton, h, absent]
  | some suffix =>
      have eq := (strip_some_iff _ _ _).mp h
      simp [under, singleton, h, eq]

theorem under_put (prefix key : Key) (value : Value) (state : Map) :
    under prefix (put key value state) = put (prefix ++ key) value (under prefix state) := by
  funext query
  cases h : strip prefix query with
  | none =>
      have absent : query ≠ prefix ++ key := by
        intro eq
        simp [eq, strip_append] at h
      simp [under, put, h, absent]
  | some suffix =>
      have eq := (strip_some_iff _ _ _).mp h
      simp [under, put, h, eq]

theorem under_erase (prefix key : Key) (state : Map) :
    under prefix (erase key state) = erase (prefix ++ key) (under prefix state) := by
  funext query
  cases h : strip prefix query with
  | none =>
      have absent : query ≠ prefix ++ key := by
        intro eq
        simp [eq, strip_append] at h
      simp [under, erase, h, absent]
  | some suffix =>
      have eq := (strip_some_iff _ _ _).mp h
      simp [under, erase, h, eq]

theorem route_empty : route none noEdges = empty := by
  funext query
  cases query <;> rfl

theorem route_only_terminal (value : Value) :
    route (some value) noEdges = singleton [] value := by
  funext query
  cases query <;> simp [route, noEdges, empty, singleton]

theorem route_one_edge (byte : UInt8) (child : Map) :
    route none (oneEdge byte child) = under [byte] child := by
  funext query
  cases query with
  | nil => rfl
  | cons head tail =>
      by_cases same : head = byte
      · subst head
        simp [route, oneEdge, replaceEdge, under, strip]
      · simp [route, oneEdge, replaceEdge, noEdges, empty, under, strip, same, Ne.symm same]

theorem terminal_put (terminal : Option Value) (edges : Edges) (value : Value) :
    route (some value) edges = put [] value (route terminal edges) := by
  funext query
  cases query <;> simp [route, put]

theorem terminal_erase (terminal : Option Value) (edges : Edges) :
    route none edges = erase [] (route terminal edges) := by
  funext query
  cases query <;> simp [route, erase]

theorem child_put (terminal : Option Value) (edges : Edges)
    (byte : UInt8) (key : Key) (value : Value) :
    route terminal (replaceEdge byte (put key value (edges byte)) edges) =
      put (byte :: key) value (route terminal edges) := by
  funext query
  cases query with
  | nil => simp [route, put]
  | cons head tail =>
      by_cases same : head = byte
      · subst head
        simp [route, replaceEdge, put]
      · simp [route, replaceEdge, put, same]

theorem child_erase (terminal : Option Value) (edges : Edges)
    (byte : UInt8) (key : Key) :
    route terminal (replaceEdge byte (erase key (edges byte)) edges) =
      erase (byte :: key) (route terminal edges) := by
  funext query
  cases query with
  | nil => simp [route, erase]
  | cons head tail =>
      by_cases same : head = byte
      · subst head
        simp [route, replaceEdge, erase]
      · simp [route, replaceEdge, erase, same]

theorem new_child_put (prefix : Key) (terminal : Option Value) (edges : Edges)
    (byte : UInt8) (key : Key) (value : Value) (absent : edges byte = empty) :
    under prefix (route terminal (replaceEdge byte (singleton key value) edges)) =
      put (prefix ++ byte :: key) value (under prefix (route terminal edges)) := by
  have replacement : singleton key value = put key value (edges byte) := by
    rw [absent]
    rfl
  rw [replacement, child_put, under_put]

theorem terminal_put_under (prefix : Key) (terminal : Option Value)
    (edges : Edges) (value : Value) :
    under prefix (route (some value) edges) =
      put prefix value (under prefix (route terminal edges)) := by
  rw [terminal_put terminal, under_put]
  simp

theorem terminal_erase_under (prefix : Key) (terminal : Option Value) (edges : Edges) :
    under prefix (route none edges) = erase prefix (under prefix (route terminal edges)) := by
  rw [terminal_erase terminal, under_erase]
  simp

theorem collapse_empty (prefix : Key) : under prefix (route none noEdges) = empty := by
  rw [route_empty, under_empty]

theorem collapse_terminal (prefix : Key) (value : Value) :
    under prefix (route (some value) noEdges) = singleton prefix value := by
  rw [route_only_terminal, under_singleton]
  simp

theorem collapse_branch (prefix childPrefix : Key) (byte : UInt8) (child : Map) :
    under prefix (route none (oneEdge byte (under childPrefix child))) =
      under (prefix ++ byte :: childPrefix) child := by
  rw [route_one_edge, under_composed, under_composed]
  simp

theorem collapse_leaf (prefix suffix : Key) (byte : UInt8) (value : Value) :
    under prefix (route none (oneEdge byte (singleton suffix value))) =
      singleton (prefix ++ byte :: suffix) value := by
  rw [route_one_edge, under_singleton, under_singleton]
  rfl

theorem split_branch (prefix rest : Key) (byte : UInt8) (body : Map) :
    under (prefix ++ byte :: rest) body =
      under prefix (route none (oneEdge byte (under rest body))) :=
  (collapse_branch prefix rest byte body).symm

theorem split_leaf_old_terminal (prefix suffix : Key) (byte : UInt8) (old fresh : Value) :
    under prefix (route (some old) (oneEdge byte (singleton suffix fresh))) =
      put (prefix ++ byte :: suffix) fresh (singleton prefix old) := by
  rw [new_child_put prefix (some old) noEdges byte suffix fresh (by rfl), collapse_terminal]

theorem split_leaf_new_terminal (prefix suffix : Key) (byte : UInt8) (old fresh : Value) :
    under prefix (route (some fresh) (oneEdge byte (singleton suffix old))) =
      put prefix fresh (singleton (prefix ++ byte :: suffix) old) := by
  rw [terminal_put_under prefix none, collapse_leaf]

theorem split_leaf_different_edges (prefix oldSuffix newSuffix : Key)
    (oldByte newByte : UInt8) (old fresh : Value) (different : newByte ≠ oldByte) :
    under prefix (route none
      (replaceEdge newByte (singleton newSuffix fresh) (oneEdge oldByte (singleton oldSuffix old)))) =
      put (prefix ++ newByte :: newSuffix) fresh (singleton (prefix ++ oldByte :: oldSuffix) old) := by
  rw [new_child_put prefix none _ newByte newSuffix fresh (by
    simp [oneEdge, replaceEdge, noEdges, different]), collapse_leaf]

structure Frame where
  prefix : Key
  terminal : Option Value
  byte : UInt8
  otherEdges : Edges

def plug (frame : Frame) (child : Map) : Map :=
  under frame.prefix (route frame.terminal (replaceEdge frame.byte child frame.otherEdges))

def liftKey (frame : Frame) (key : Key) : Key := frame.prefix ++ frame.byte :: key

theorem replace_edge_twice (byte : UInt8) (a b : Map) (edges : Edges) :
    replaceEdge byte a (replaceEdge byte b edges) = replaceEdge byte a edges := by
  funext query
  by_cases same : query = byte <;> simp [replaceEdge, same]

theorem plug_put (frame : Frame) (key : Key) (value : Value) (child : Map) :
    plug frame (put key value child) = put (liftKey frame key) value (plug frame child) := by
  have h := child_put frame.terminal (replaceEdge frame.byte child frame.otherEdges) frame.byte key value
  simp only [replaceEdge, if_pos rfl] at h
  have h' := congrArg (under frame.prefix) h
  simpa only [replace_edge_twice, under_put, plug, liftKey] using h'

theorem plug_erase (frame : Frame) (key : Key) (child : Map) :
    plug frame (erase key child) = erase (liftKey frame key) (plug frame child) := by
  have h := child_erase frame.terminal (replaceEdge frame.byte child frame.otherEdges) frame.byte key
  simp only [replaceEdge, if_pos rfl] at h
  have h' := congrArg (under frame.prefix) h
  simpa only [replace_edge_twice, under_erase, plug, liftKey] using h'

-- Frames are in pop order: immediate parent first, root last.
def restore (frames : List Frame) (child : Map) : Map :=
  frames.foldl (fun state frame => plug frame state) child
def restoreKey (frames : List Frame) (key : Key) : Key :=
  frames.foldl (fun suffix frame => liftKey frame suffix) key

theorem restore_put (frames : List Frame) (key : Key) (value : Value) (child : Map) :
    restore frames (put key value child) = put (restoreKey frames key) value (restore frames child) := by
  induction frames generalizing key child with
  | nil => rfl
  | cons frame tail ih =>
      simp only [restore, restoreKey, List.foldl_cons]
      rw [plug_put]
      exact ih (liftKey frame key) (plug frame child)

theorem restore_erase (frames : List Frame) (key : Key) (child : Map) :
    restore frames (erase key child) = erase (restoreKey frames key) (restore frames child) := by
  induction frames generalizing key child with
  | nil => rfl
  | cons frame tail ih =>
      simp only [restore, restoreKey, List.foldl_cons]
      rw [plug_erase]
      exact ih (liftKey frame key) (plug frame child)

end Kv9.Radix
