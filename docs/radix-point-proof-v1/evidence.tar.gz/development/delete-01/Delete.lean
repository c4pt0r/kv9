import Normalize

namespace Kv9.Radix

def dropKey (query : Key) (rows : List Entry) : List Entry :=
  rows.filter (fun entry => decide (query ≠ entry.key))

theorem linear_none_iff (query : Key) (rows : List Entry) :
    linearLookup query rows = none ↔ ∀ entry ∈ rows, query ≠ entry.key := by
  induction rows with
  | nil => simp [linearLookup]
  | cons entry tail ih =>
      by_cases same : query = entry.key <;> simp [linearLookup, same, ih]

theorem drop_absent (query : Key) (rows : List Entry) (absent : linearLookup query rows = none) :
    dropKey query rows = rows := by
  apply List.filter_eq_self.mpr
  intro entry member
  exact decide_eq_true ((linear_none_iff _ _).mp absent entry member)

theorem drop_append (query : Key) (a b : List Entry) :
    dropKey query (a ++ b) = dropKey query a ++ dropKey query b := by
  simp [dropKey]

theorem drop_cons (query : Key) (entry : Entry) (tail : List Entry) :
    dropKey query (entry :: tail) =
      if query = entry.key then dropKey query tail else entry :: dropKey query tail := by
  by_cases same : query = entry.key <;> simp [dropKey, same]

mutual
  def deleteTree (query : Key) : Tree → Key → Option Tree
    | .leaf _, _ => none
    | .branch pfx terminal children, remaining =>
        match strip pfx remaining with
        | none => some (.branch pfx terminal children)
        | some [] => normalize (.branch pfx none children)
        | some (byte :: suffix) => normalize (.branch pfx terminal (deleteForest query children byte suffix))
  def deleteForest (query : Key) : Forest → UInt8 → Key → Forest
    | .nil, _, _ => .nil
    | .cons byte child tail, target, suffix =>
        if target = byte then
          match deleteTree query child suffix with
          | none => tail
          | some result => .cons byte result tail
        else .cons byte child (deleteForest query tail target suffix)
end

theorem delete_forest_missing (query : Key) (forest : Forest) (target absent : UInt8) (suffix : Key)
    (missing : MissingEdge absent forest) :
    MissingEdge absent (deleteForest query forest target suffix) := by
  cases forest with
  | nil => trivial
  | cons byte child tail =>
      obtain ⟨different, tailMissing⟩ := missing
      by_cases same : target = byte
      · rw [deleteForest, if_pos same]
        cases deleteTree query child suffix with
        | none => exact tailMissing
        | some result => exact ⟨different, tailMissing⟩
      · rw [deleteForest, if_neg same]
        exact ⟨different, delete_forest_missing query tail target absent suffix tailMissing⟩

mutual
  theorem delete_tree_valid (path : Key) (tree : Tree) (query remaining : Key)
      (valid : Valid path tree) : ValidOptional path (deleteTree query tree remaining) := by
    cases tree with
    | leaf entry => trivial
    | branch pfx terminal children =>
        obtain ⟨terminalValid, childrenValid⟩ := valid
        cases h : strip pfx remaining with
        | none =>
            rw [deleteTree, h]
            exact ⟨terminalValid, childrenValid⟩
        | some suffix =>
            cases suffix with
            | nil =>
                rw [deleteTree, h]
                exact normalize_valid _ _ ⟨by simp, childrenValid⟩
            | cons byte rest =>
                rw [deleteTree, h]
                exact normalize_valid _ _ ⟨terminalValid,
                  delete_forest_valid (path ++ pfx) children query byte rest childrenValid⟩
  theorem delete_forest_valid (path : Key) (forest : Forest) (query : Key) (target : UInt8) (suffix : Key)
      (valid : ValidForest path forest) : ValidForest path (deleteForest query forest target suffix) := by
    cases forest with
    | nil => trivial
    | cons byte child tail =>
        obtain ⟨childValid, tailValid, missing⟩ := valid
        by_cases same : target = byte
        · rw [deleteForest, if_pos same]
          have resultValid := delete_tree_valid (path ++ [byte]) child query suffix childValid
          cases h : deleteTree query child suffix with
          | none => exact tailValid
          | some result => exact ⟨by simpa [h, ValidOptional] using resultValid, tailValid, missing⟩
        · rw [deleteForest, if_neg same]
          exact ⟨childValid, delete_forest_valid path tail query target suffix tailValid,
            delete_forest_missing query tail target byte suffix missing⟩
end

mutual
  theorem delete_tree_canonical (tree : Tree) (query remaining : Key) (canonical : Canonical tree) :
      ∀ result, deleteTree query tree remaining = some result → Canonical result := by
    cases tree with
    | leaf entry => simp [deleteTree]
    | branch pfx terminal children =>
        cases h : strip pfx remaining with
        | none =>
            intro result eq
            simp only [deleteTree, h, Option.some.injEq] at eq
            subst result
            exact canonical
        | some suffix =>
            cases suffix with
            | nil =>
                rw [deleteTree, h]
                exact normalize_canonical _ canonical.2
            | cons byte rest =>
                rw [deleteTree, h]
                exact normalize_canonical _ (delete_forest_canonical children query byte rest canonical.2)
  theorem delete_forest_canonical (forest : Forest) (query : Key) (target : UInt8) (suffix : Key)
      (canonical : CanonicalForest forest) : CanonicalForest (deleteForest query forest target suffix) := by
    cases forest with
    | nil => trivial
    | cons byte child tail =>
        by_cases same : target = byte
        · rw [deleteForest, if_pos same]
          cases h : deleteTree query child suffix with
          | none => exact canonical.2
          | some result => exact ⟨delete_tree_canonical child query suffix canonical.1 result h, canonical.2⟩
        · rw [deleteForest, if_neg same]
          exact ⟨canonical.1, delete_forest_canonical tail query target suffix canonical.2⟩
end

end Kv9.Radix
