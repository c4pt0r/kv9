import Ordered

set_option autoImplicit false

namespace Kv9.Radix

mutual
  def insertTree (path : Key) (fresh : Entry) : Tree → Tree × Bool
    | .leaf old =>
        if old.key = fresh.key then (.leaf fresh, false) else (splitLeaf path old fresh, true)
    | .branch pfx terminal children =>
        let remaining := fresh.key.drop path.length
        if (common pfx remaining).length < pfx.length then
          (splitBranch path pfx terminal children fresh, true)
        else
          match remaining.drop pfx.length with
          | [] => (.branch pfx (some fresh) children, terminal.isNone)
          | byte :: _ =>
              let result := insertForest (path ++ pfx) fresh children byte
              (.branch pfx terminal result.1, result.2)
  def insertForest (path : Key) (fresh : Entry) : Forest → UInt8 → Forest × Bool
    | .nil, byte => (.cons byte (.leaf fresh) .nil, true)
    | .cons byte child tail, target =>
        if target = byte then
          let result := insertTree (path ++ [byte]) fresh child
          (.cons byte result.1 tail, result.2)
        else if target < byte then (.cons target (.leaf fresh) (.cons byte child tail), true)
        else
          let result := insertForest path fresh tail target
          (.cons byte child result.1, result.2)
end

theorem matching_key_decomposition (path pfx key : Key) (valid : HasPrefix path key)
    (matching : ¬ (common pfx (key.drop path.length)).length < pfx.length) :
    key = (path ++ pfx) ++ (key.drop path.length).drop pfx.length := by
  have shared : common pfx (key.drop path.length) = pfx := by
    apply common_full_left
    have bound := (common_bounds pfx (key.drop path.length)).1
    omega
  have pfxValid : HasPrefix pfx (key.drop path.length) := by
    simpa only [shared] using common_right pfx (key.drop path.length)
  simpa [List.append_assoc] using (prefix_drop path key valid).trans
    (congrArg (List.append path) (prefix_drop pfx (key.drop path.length) pfxValid))

theorem byte_reverse_lt (a b : UInt8) (different : a ≠ b) (notLess : ¬ a < b) : b.toNat < a.toNat := by
  have differentNat : a.toNat ≠ b.toNat := fun same => different (UInt8.toNat_inj.mp same)
  have notLessNat : ¬ a.toNat < b.toNat := notLess
  omega

theorem insert_forest_missing (path : Key) (fresh : Entry) (forest : Forest) (target absent : UInt8)
    (different : absent ≠ target) (missing : MissingEdge absent forest) :
    MissingEdge absent (insertForest path fresh forest target).1 := by
  cases forest with
  | nil => exact ⟨different, trivial⟩
  | cons byte child tail =>
      by_cases same : target = byte
      · simpa only [insertForest, if_pos same, MissingEdge] using missing
      · by_cases less : target < byte
        · simpa only [insertForest, if_neg same, if_pos less, MissingEdge] using And.intro different missing
        · rw [insertForest, if_neg same, if_neg less]
          exact ⟨missing.1, insert_forest_missing path fresh tail target absent different missing.2⟩

theorem insert_forest_above (path : Key) (fresh : Entry) (forest : Forest) (target lower : UInt8)
    (less : lower.toNat < target.toNat) (above : Above lower forest) :
    Above lower (insertForest path fresh forest target).1 := by
  cases forest with
  | nil => exact ⟨less, trivial⟩
  | cons byte child tail =>
      by_cases same : target = byte
      · simpa only [insertForest, if_pos same, Above] using above
      · by_cases before : target < byte
        · simpa only [insertForest, if_neg same, if_pos before, Above] using And.intro less above
        · rw [insertForest, if_neg same, if_neg before]
          exact ⟨above.1, insert_forest_above path fresh tail target lower less above.2⟩

mutual
  theorem insert_tree_valid (path : Key) (fresh : Entry) (tree : Tree)
      (valid : Valid path tree) (ordered : OrderedTree tree) (freshValid : HasPrefix path fresh.key) :
      Valid path (insertTree path fresh tree).1 := by
    cases tree with
    | leaf old =>
        by_cases same : old.key = fresh.key
        · simpa only [insertTree, if_pos same, Valid] using freshValid
        · simpa only [insertTree, if_neg same] using split_leaf_valid path old fresh valid freshValid
    | branch pfx terminal children =>
        by_cases split : (common pfx (fresh.key.drop path.length)).length < pfx.length
        · simpa only [insertTree, if_pos split] using split_branch_valid path pfx terminal children fresh valid freshValid
        · have key := matching_key_decomposition path pfx fresh.key freshValid split
          dsimp only [insertTree]
          rw [if_neg split]
          generalize suffixEq : (fresh.key.drop path.length).drop pfx.length = suffix
          rw [suffixEq] at key
          cases suffix with
          | nil =>
              refine ⟨?_, valid.2⟩
              simpa using key
          | cons byte rest =>
              refine ⟨valid.1, insert_forest_valid (path ++ pfx) fresh children byte valid.2 ordered ?_⟩
              exact ⟨rest, by simpa [List.append_assoc] using key⟩
  theorem insert_forest_valid (path : Key) (fresh : Entry) (forest : Forest) (target : UInt8)
      (valid : ValidForest path forest) (ordered : OrderedForest forest)
      (freshValid : HasPrefix (path ++ [target]) fresh.key) :
      ValidForest path (insertForest path fresh forest target).1 := by
    cases forest with
    | nil => exact ⟨freshValid, trivial, trivial⟩
    | cons byte child tail =>
        by_cases same : target = byte
        · subst target
          rw [insertForest, if_pos rfl]
          exact ⟨insert_tree_valid _ _ _ valid.1 ordered.1 freshValid, valid.2⟩
        · by_cases less : target < byte
          · rw [insertForest, if_neg same, if_pos less]
            refine ⟨freshValid, valid, ?_⟩
            exact above_missing target (.cons byte child tail)
              ⟨less, above_trans target byte tail less ordered.2.2⟩
          · rw [insertForest, if_neg same, if_neg less]
            exact ⟨valid.1, insert_forest_valid path fresh tail target valid.2.1 ordered.2.1 freshValid,
              insert_forest_missing path fresh tail target byte (Ne.symm same) valid.2.2⟩
end

mutual
  theorem insert_tree_ordered (path : Key) (fresh : Entry) (tree : Tree) (ordered : OrderedTree tree) :
      OrderedTree (insertTree path fresh tree).1 := by
    cases tree with
    | leaf old =>
        by_cases same : old.key = fresh.key
        · simp [insertTree, same, OrderedTree]
        · simpa [insertTree, same] using split_leaf_ordered path old fresh
    | branch pfx terminal children =>
        by_cases split : (common pfx (fresh.key.drop path.length)).length < pfx.length
        · simpa only [insertTree, if_pos split] using split_branch_ordered path pfx terminal children fresh ordered
        · dsimp only [insertTree]
          rw [if_neg split]
          cases (fresh.key.drop path.length).drop pfx.length with
          | nil => exact ordered
          | cons byte rest => exact insert_forest_ordered (path ++ pfx) fresh children byte ordered
  theorem insert_forest_ordered (path : Key) (fresh : Entry) (forest : Forest) (target : UInt8)
      (ordered : OrderedForest forest) : OrderedForest (insertForest path fresh forest target).1 := by
    cases forest with
    | nil => exact ⟨trivial, trivial, trivial⟩
    | cons byte child tail =>
        by_cases same : target = byte
        · subst target
          rw [insertForest, if_pos rfl]
          exact ⟨insert_tree_ordered _ _ _ ordered.1, ordered.2⟩
        · by_cases less : target < byte
          · rw [insertForest, if_neg same, if_pos less]
            exact ⟨trivial, ordered, less, above_trans target byte tail less ordered.2.2⟩
          · rw [insertForest, if_neg same, if_neg less]
            exact ⟨ordered.1, insert_forest_ordered path fresh tail target ordered.2.1,
              insert_forest_above path fresh tail target byte (byte_reverse_lt target byte same less) ordered.2.2⟩
end

theorem insert_forest_alternatives (path : Key) (fresh : Entry) (forest : Forest) (target : UInt8)
    (terminal : Option Entry) : alternatives terminal forest ≤ alternatives terminal (insertForest path fresh forest target).1 := by
  cases forest with
  | nil => simp [insertForest, alternatives]
  | cons byte child tail =>
      by_cases same : target = byte
      · simp [insertForest, same, alternatives]
      · by_cases less : target < byte
        · simp [insertForest, same, less, alternatives]
        · simp only [insertForest, if_neg same, if_neg less, alternatives]
          exact Nat.add_le_add_left (insert_forest_alternatives path fresh tail target terminal) 1

theorem alternatives_terminal (terminal : Option Entry) (forest : Forest) (fresh : Entry) :
    alternatives terminal forest ≤ alternatives (some fresh) forest := by
  cases forest with
  | nil => cases terminal <;> simp [alternatives]
  | cons byte child tail => exact Nat.add_le_add_left (alternatives_terminal terminal tail fresh) 1

mutual
  theorem insert_tree_canonical (path : Key) (fresh : Entry) (tree : Tree) (canonical : Canonical tree) :
      Canonical (insertTree path fresh tree).1 := by
    cases tree with
    | leaf old =>
        by_cases same : old.key = fresh.key
        · simp [insertTree, same, Canonical]
        · simpa [insertTree, same] using split_leaf_canonical path old fresh
    | branch pfx terminal children =>
        by_cases split : (common pfx (fresh.key.drop path.length)).length < pfx.length
        · simpa only [insertTree, if_pos split] using split_branch_canonical path pfx terminal children fresh canonical
        · dsimp only [insertTree]
          rw [if_neg split]
          cases (fresh.key.drop path.length).drop pfx.length with
          | nil => exact ⟨Nat.le_trans canonical.1 (alternatives_terminal terminal children fresh), canonical.2⟩
          | cons byte rest => exact ⟨Nat.le_trans canonical.1 (insert_forest_alternatives (path ++ pfx) fresh children byte terminal),
              insert_forest_canonical (path ++ pfx) fresh children byte canonical.2⟩
  theorem insert_forest_canonical (path : Key) (fresh : Entry) (forest : Forest) (target : UInt8)
      (canonical : CanonicalForest forest) : CanonicalForest (insertForest path fresh forest target).1 := by
    cases forest with
    | nil => exact ⟨trivial, trivial⟩
    | cons byte child tail =>
        by_cases same : target = byte
        · subst target
          rw [insertForest, if_pos rfl]
          exact ⟨insert_tree_canonical _ _ _ canonical.1, canonical.2⟩
        · by_cases less : target < byte
          · rw [insertForest, if_neg same, if_pos less]
            exact ⟨trivial, canonical⟩
          · rw [insertForest, if_neg same, if_neg less]
            exact ⟨canonical.1, insert_forest_canonical path fresh tail target canonical.2⟩
end

end Kv9.Radix
