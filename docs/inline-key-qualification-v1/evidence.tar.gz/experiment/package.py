#!/usr/bin/env python3
"""Package bounded qualification evidence; keep binaries local."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

R=Path('/home/dongxu/kv9');S=Path(__file__).resolve().parent
O=R/'docs/inline-key-qualification-v1';O.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
audit=json.loads((S/'qualification-audit.json').read_text());assert audit['complete']
members={}
excluded=[]
for p in sorted(S.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    if any(part.startswith('issue9') for part in p.relative_to(S).parts):continue
    with p.open('rb') as f: magic=f.read(4)
    if magic==b'\x7fELF' or p.suffix=='.olean':
        excluded.append(str(p.relative_to(S)));continue
    members['experiment/'+str(p.relative_to(S))]=p
for directory in ('scripts/inline-key','proofs/lean/inline-key'):
    for p in sorted((R/directory).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:members['repo/'+str(p.relative_to(R))]=p
members['repo/scripts/build_cache.py']=R/'scripts/build_cache.py'
records=[];archive=O/'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,p in sorted(members.items()):
                assert not p.is_symlink()
                data=p.read_bytes();info=tar.gettarinfo(str(p),arcname=name)
                info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
                with p.open('rb') as f:tar.addfile(info,f)
                records.append(dict(path=name,bytes=len(data),sha256=sha(data)))
with tarfile.open(archive,'r:gz') as tar:
    assert tar.getnames()==[r['path'] for r in records]
    for r in records:
        data=tar.extractfile(r['path']).read();assert len(data)==r['bytes'] and sha(data)==r['sha256']
manifest=dict(complete=True,members=len(records),expanded_bytes=sum(r['bytes'] for r in records),
              compressed_bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),all_members_read_back=True,
              local_root=str(S),selected_layout='layout-formatted',excluded_binaries_and_lean_objects=excluded,
              limits='No timing, new database/Redis, external MinIO, distributed recovery or actual Chaos acceptance. Conditional proof; production unchanged.')
for name,data in [('manifest.json',manifest),('members.json',records)]:
    (O/name).write_text(json.dumps(data,indent=2)+'\n')
for name in ('qualification-plan.json','qualification-audit.json','next-performance-plan.json'):
    shutil.copyfile(S/name,O/name)
shutil.copyfile(S/'layout-formatted/observations.json',O/'allocation-observations.json')
(O/'README.md').write_text(f'''# Inline-key qualification evidence

See the [report](../INLINE-KEY-QUALIFICATION.md). Source/model/proof qualification
passes; no engine timing or production promotion is included.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['sha256']}`.
Every member size/hash passed readback; [members.json](members.json) and
[manifest.json](manifest.json) record retained bytes and excluded local binaries.

The packet includes both engine/common source workspaces, the exact private key
and patch, matching model and existing tests, complete Clippy/build/test outputs,
19-theorem / nine-control conditional proof, 33 selected allocator observations,
constructor disassembly and independent qualification audit. Upstream dependency
archives are identified by Cargo.lock SHA-256; installed source files were
checked against those archives. The allocator module is retained with probe inputs.

The selected allocation probe is `layout-formatted`. Initial preparation failure,
proof-authoring diagnostics and the unselected pre-format probe/runner remain
separate and are not pooled. Executable hashes remain in build records.

Reproduction uses source base `14f35ec` with these experiment tools and the
recorded absolute paths. Restore those inputs or adapt a fresh attempt without
relabeling existing results. The [next screen](next-performance-plan.json) is
prospective, not implemented or executed. Its original corpus is already in
the [outlined packet](../outlined-mutation-path-v1/README.md) as `outlined/groups.bin`.
No industrial checklist item is closed by this component qualification.
''')
print(json.dumps(manifest))
