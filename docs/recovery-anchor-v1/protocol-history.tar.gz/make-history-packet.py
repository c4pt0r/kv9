import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path('/tmp/kv9-c04-anchor-envelope-process-20260915-first/kv9-minio-kv-twvjyjso')
out=Path('/home/dongxu/kv9/docs/recovery-anchor-v1');archive=out/'protocol-history.tar.gz';assert not archive.exists()
paths=[(f'n{n}/raft/raft.log',root/f'n{n}/raft/raft.log') for n in (1,2,3)]
paths.append(('make-history-packet.py',Path(__file__)))
secrets=[]
for line in Path('/tmp/kv9-c04-minio-tmpfs-fixture-20260915-first/attempt-second/credentials.env').read_text().splitlines():
 if line.split('=',1)[0] in ('MINIO_ROOT_USER','MINIO_ROOT_PASSWORD'):secrets.append(line.split('=',1)[1].encode())
secrets.extend(s.encode() for s in json.loads(Path('/tmp/kv9-c04-anchor-envelope-chaos-20260915-first/credentials.json').read_text()).values())
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,p in paths:
  assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert len(b)<64*1024**2
  assert all(s not in b for s in secrets if s)
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
  rows.append(dict(name=name,original=str(p),bytes=len(b),sha256=sha(b)))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  assert member.isfile() and member.name==row['name'];b=tar.extractfile(member).read()
  assert b==Path(row['original']).read_bytes() and sha(b)==row['sha256']
r=dict(status='PASS',members=len(rows),decoded_bytes=sum(r['bytes'] for r in rows),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),complete_original_readback=True,known_fixture_secrets_absent=True,files=rows)
(out/'protocol-history-inventory.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='files'},indent=2))
