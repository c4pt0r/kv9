---- MODULE Arithmetic ----
EXTENDS Naturals, TLAPS
Size(r,m,n1,n2,n3,n4,o) == 22+4+r+32+16+32+8+32+1+o+16+8*(n1+n2+n3+n4)+1+4+m+32+32
THEOREM Bound == ASSUME NEW r \in Nat, NEW m \in Nat, NEW n1 \in Nat, NEW n2 \in Nat, NEW n3 \in Nat, NEW n4 \in Nat, NEW o \in Nat, r <= 65536, m <= 1048576, n1 <= 1024, n2 <= 1024, n3 <= 1024, n4 <= 1024, o <= 16 PROVE Size(r,m,n1,n2,n3,n4,o) <= 1147128
BY SMT DEF Size
====
