;; Proof obligation:
;;	ASSUME NEW CONSTANT CONSTANT_r_ \in Nat,
;;	       NEW CONSTANT CONSTANT_m_ \in Nat,
;;	       NEW CONSTANT CONSTANT_n1_ \in Nat,
;;	       NEW CONSTANT CONSTANT_n2_ \in Nat,
;;	       NEW CONSTANT CONSTANT_n3_ \in Nat,
;;	       NEW CONSTANT CONSTANT_n4_ \in Nat,
;;	       NEW CONSTANT CONSTANT_o_ \in Nat,
;;	       CONSTANT_r_ =< 65536 ,
;;	       CONSTANT_m_ =< 1048576 ,
;;	       CONSTANT_n1_ =< 1024 ,
;;	       CONSTANT_n2_ =< 1024 ,
;;	       CONSTANT_n3_ =< 1024 ,
;;	       CONSTANT_n4_ =< 1024 ,
;;	       CONSTANT_o_ =< 16 
;;	PROVE  22 + 4 + CONSTANT_r_ + 32 + 16 + 32 + 8 + 32 + 1 + CONSTANT_o_ + 16
;;	       + 8 * (CONSTANT_n1_ + CONSTANT_n2_ + CONSTANT_n3_ + CONSTANT_n4_) + 1
;;	       + 4 + CONSTANT_m_ + 32 + 32 =< 1147128
;; TLA+ Proof Manager 4600b24
;; Proof obligation #1
;; Generated from file "/tmp/kv9-c04-anchor-frame-arithmetic-diagnosis-20260915-second/Arithmetic.tla", line 5, characters 1-2

(set-logic UFNIA)

;; Sorts

(declare-sort Idv 0)

;; Hypotheses

(declare-fun smt__TLA____Cast__Int (Int) Idv)

(declare-fun smt__TLA____IntLteq (Idv Idv) Bool)

(declare-fun smt__TLA____IntPlus (Idv Idv) Idv)

(declare-fun smt__TLA____IntSet () Idv)

(declare-fun smt__TLA____IntTimes (Idv Idv) Idv)

(declare-fun smt__TLA____Mem (Idv Idv) Bool)

(declare-fun smt__TLA____NatSet () Idv)

(declare-fun smt__TLA____Proj__Int (Idv) Int)

(declare-fun smt__TLA____SetExtTrigger (Idv Idv) Bool)

;; Axiom: SetExt
(assert
  (!
    (forall ((smt__x Idv) (smt__y Idv))
      (!
        (=>
          (forall ((smt__z Idv))
            (= (smt__TLA____Mem smt__z smt__x)
              (smt__TLA____Mem smt__z smt__y))) (= smt__x smt__y))
        :pattern ((smt__TLA____SetExtTrigger smt__x smt__y))))
    :named |SetExt|))

;; Axiom: NatSetDef
(assert
  (!
    (forall ((smt__x Idv))
      (!
        (= (smt__TLA____Mem smt__x smt__TLA____NatSet)
          (and (smt__TLA____Mem smt__x smt__TLA____IntSet)
            (smt__TLA____IntLteq (smt__TLA____Cast__Int 0) smt__x)))
        :pattern ((smt__TLA____Mem smt__x smt__TLA____NatSet))))
    :named |NatSetDef|))

;; Axiom: CastInjAlt Int
(assert
  (!
    (forall ((smt__x Int))
      (! (= smt__x (smt__TLA____Proj__Int (smt__TLA____Cast__Int smt__x)))
        :pattern ((smt__TLA____Cast__Int smt__x)))) :named |CastInjAlt Int|))

;; Axiom: TypeGuardIntro Int
(assert
  (!
    (forall ((smt__z Int))
      (! (smt__TLA____Mem (smt__TLA____Cast__Int smt__z) smt__TLA____IntSet)
        :pattern ((smt__TLA____Cast__Int smt__z))))
    :named |TypeGuardIntro Int|))

;; Axiom: TypeGuardElim Int
(assert
  (!
    (forall ((smt__x Idv))
      (!
        (=> (smt__TLA____Mem smt__x smt__TLA____IntSet)
          (= smt__x (smt__TLA____Cast__Int (smt__TLA____Proj__Int smt__x))))
        :pattern ((smt__TLA____Mem smt__x smt__TLA____IntSet))))
    :named |TypeGuardElim Int|))

;; Axiom: Typing TIntPlus
(assert
  (!
    (forall ((smt__x1 Int) (smt__x2 Int))
      (!
        (=
          (smt__TLA____IntPlus (smt__TLA____Cast__Int smt__x1)
            (smt__TLA____Cast__Int smt__x2))
          (smt__TLA____Cast__Int (+ smt__x1 smt__x2)))
        :pattern ((smt__TLA____IntPlus (smt__TLA____Cast__Int smt__x1)
                    (smt__TLA____Cast__Int smt__x2)))))
    :named |Typing TIntPlus|))

;; Axiom: Typing TIntTimes
(assert
  (!
    (forall ((smt__x1 Int) (smt__x2 Int))
      (!
        (=
          (smt__TLA____IntTimes (smt__TLA____Cast__Int smt__x1)
            (smt__TLA____Cast__Int smt__x2))
          (smt__TLA____Cast__Int (* smt__x1 smt__x2)))
        :pattern ((smt__TLA____IntTimes (smt__TLA____Cast__Int smt__x1)
                    (smt__TLA____Cast__Int smt__x2)))))
    :named |Typing TIntTimes|))

;; Axiom: Typing TIntLteq
(assert
  (!
    (forall ((smt__x1 Int) (smt__x2 Int))
      (!
        (=
          (smt__TLA____IntLteq (smt__TLA____Cast__Int smt__x1)
            (smt__TLA____Cast__Int smt__x2)) (<= smt__x1 smt__x2))
        :pattern ((smt__TLA____IntLteq (smt__TLA____Cast__Int smt__x1)
                    (smt__TLA____Cast__Int smt__x2)))))
    :named |Typing TIntLteq|))

; hidden fact

; hidden fact

; omitted declaration of 'CONSTANT_EnabledWrapper_' (second-order)

; omitted declaration of 'CONSTANT_CdotWrapper_' (second-order)

(declare-fun smt__CONSTANT__r__ () Idv)

(assert (smt__TLA____Mem smt__CONSTANT__r__ smt__TLA____NatSet))

(declare-fun smt__CONSTANT__m__ () Idv)

(assert (smt__TLA____Mem smt__CONSTANT__m__ smt__TLA____NatSet))

(declare-fun smt__CONSTANT__n1__ () Idv)

(assert (smt__TLA____Mem smt__CONSTANT__n1__ smt__TLA____NatSet))

(declare-fun smt__CONSTANT__n2__ () Idv)

(assert (smt__TLA____Mem smt__CONSTANT__n2__ smt__TLA____NatSet))

(declare-fun smt__CONSTANT__n3__ () Idv)

(assert (smt__TLA____Mem smt__CONSTANT__n3__ smt__TLA____NatSet))

(declare-fun smt__CONSTANT__n4__ () Idv)

(assert (smt__TLA____Mem smt__CONSTANT__n4__ smt__TLA____NatSet))

(declare-fun smt__CONSTANT__o__ () Idv)

(assert (smt__TLA____Mem smt__CONSTANT__o__ smt__TLA____NatSet))

(assert
  (smt__TLA____IntLteq smt__CONSTANT__r__ (smt__TLA____Cast__Int 65536)))

(assert
  (smt__TLA____IntLteq smt__CONSTANT__m__ (smt__TLA____Cast__Int 1048576)))

(assert
  (smt__TLA____IntLteq smt__CONSTANT__n1__ (smt__TLA____Cast__Int 1024)))

(assert
  (smt__TLA____IntLteq smt__CONSTANT__n2__ (smt__TLA____Cast__Int 1024)))

(assert
  (smt__TLA____IntLteq smt__CONSTANT__n3__ (smt__TLA____Cast__Int 1024)))

(assert
  (smt__TLA____IntLteq smt__CONSTANT__n4__ (smt__TLA____Cast__Int 1024)))

(assert (smt__TLA____IntLteq smt__CONSTANT__o__ (smt__TLA____Cast__Int 16)))

;; Goal
(assert
  (!
    (not
      (smt__TLA____IntLteq
        (smt__TLA____IntPlus
          (smt__TLA____IntPlus
            (smt__TLA____IntPlus
              (smt__TLA____IntPlus
                (smt__TLA____IntPlus
                  (smt__TLA____IntPlus
                    (smt__TLA____IntPlus
                      (smt__TLA____IntPlus
                        (smt__TLA____IntPlus
                          (smt__TLA____IntPlus
                            (smt__TLA____IntPlus
                              (smt__TLA____IntPlus
                                (smt__TLA____IntPlus
                                  (smt__TLA____IntPlus
                                    (smt__TLA____IntPlus
                                      (smt__TLA____IntPlus
                                        (smt__TLA____Cast__Int 22)
                                        (smt__TLA____Cast__Int 4))
                                      smt__CONSTANT__r__)
                                    (smt__TLA____Cast__Int 32))
                                  (smt__TLA____Cast__Int 16))
                                (smt__TLA____Cast__Int 32))
                              (smt__TLA____Cast__Int 8))
                            (smt__TLA____Cast__Int 32))
                          (smt__TLA____Cast__Int 1)) smt__CONSTANT__o__)
                      (smt__TLA____Cast__Int 16))
                    (smt__TLA____IntTimes (smt__TLA____Cast__Int 8)
                      (smt__TLA____IntPlus
                        (smt__TLA____IntPlus
                          (smt__TLA____IntPlus smt__CONSTANT__n1__
                            smt__CONSTANT__n2__) smt__CONSTANT__n3__)
                        smt__CONSTANT__n4__))) (smt__TLA____Cast__Int 1))
                (smt__TLA____Cast__Int 4)) smt__CONSTANT__m__)
            (smt__TLA____Cast__Int 32)) (smt__TLA____Cast__Int 32))
        (smt__TLA____Cast__Int 1147128))) :named |Goal|))

(check-sat)
(exit)
