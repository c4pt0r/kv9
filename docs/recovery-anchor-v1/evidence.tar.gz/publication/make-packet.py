import gzip,hashlib,io,json,tarfile
from pathlib import Path
repo=Path('/home/dongxu/kv9');root=Path(__file__).resolve().parent
out=repo/'docs/recovery-anchor-v1';out.mkdir(exist_ok=True)
archive=out/'evidence.tar.gz';assert not archive.exists()
entries={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(name,path,expected=None):
 p=Path(path);assert p.is_file() and not p.is_symlink(),p
 b=p.read_bytes();assert len(b)<=64*1024**2,p
 if expected:assert sha(b)==expected,p
 assert name not in entries,name
 entries[name]=(p,b)
inputs=Path('/tmp/kv9-c04-anchor-envelope-runtime-inputs-20260915-first')
sources=list(json.loads((inputs/'source-tree.json').read_text()))
sources+=['scripts/check-anchor-binding.py','scripts/check-configuration-protocol.py','scripts/check-checkpoint-base.py','scripts/check-checkpoint-publication.py','scripts/checkpoint-publication-chaos.py','scripts/check-tlaps.py','scripts/check-tla.py','scripts/ProofAudit.java','scripts/minio-kv-e2e.py','scripts/root_provision.py','scripts/wal_layout.py','docs/RECOVERY-ANCHOR-ENVELOPE.md','docs/RECOVERY-RETENTION-CONTRACT.md','docs/WRITE-PERFORMANCE-NEXT.md','docs/DEVELOPMENT-PATH.md']
for family in ('anchor_binding','checkpoint_base','checkpoint_publication','configuration_cut'):
 for kind in ('tla','tlaps'):
  sources.extend(str(p.relative_to(repo)) for p in (repo/'proofs'/kind/family).iterdir() if p.is_file())
for name in sorted(set(sources)):add('source/'+name,repo/name)
for run in sorted(Path('/tmp').glob('kv9-c04-anchor-*')):
 if not run.is_dir() or run==root or any(x in run.name for x in ('chaos-','process-','environment-capacity','cache-cleanup')):continue
 for p in sorted(run.rglob('*')):
  rel=p.relative_to(run)
  if not p.is_file() or p.is_symlink() or any(x in rel.parts for x in ('cache','states','auditor','target','__pycache__','.tlacache')):continue
  if p.suffix not in ('.json','.jsonl','.py','.log','.rs','.tla','.cfg','.java','.md','.smt','.out'):continue
  add('runs/'+run.name+'/'+str(rel),p)
for family in ('anchor-binding-protocol',):
 p=Path('/tmp')/(f'kv9-c04-{family}-20260915-first.log');add('runs/'+p.name,p)
secrets=[]
for name,selector in [('chaos','/tmp/kv9-c04-anchor-envelope-chaos-20260915-first/public-evidence-final-manifest.json'),('process','/tmp/kv9-c04-anchor-envelope-process-20260915-first/public-evidence-manifest.json')]:
 p=Path(selector);manifest=json.loads(p.read_text())
 for row in manifest['files']:
  src=Path(row['path']);add(name+'/'+str(src.relative_to(p.parent)),src,row['sha256'])
 add(name+'/final-selector.json',p)
 credentials=p.parent/'credentials.json'
 if credentials.exists():secrets.extend(v.encode() for v in json.loads(credentials.read_text()).values())
for row in json.loads((root/'process-public-files.json').read_text())['files']:
 add('process-fixture/'+row['name'],row['path'],row['sha256'])
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in ('.json','.py'):add('publication/'+p.name,p)
for p in Path('/tmp/kv9-c04-minio-tmpfs-fixture-20260915-first').rglob('credentials.env'):
 secrets.extend(line.split('=',1)[1].encode() for line in p.read_text().splitlines() if line.split('=',1)[0] in ('MINIO_ROOT_USER','MINIO_ROOT_PASSWORD'))
for name,(_,b) in entries.items():assert all(s not in b for s in secrets if s),'secret in '+name
rows=[]
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
 for name,(p,b) in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
  rows.append(dict(name=name,bytes=len(b),sha256=sha(b),original=str(p)))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):
  assert m.isfile() and m.name==row['name'];b=tar.extractfile(m).read()
  assert b==Path(row['original']).read_bytes() and len(b)==row['bytes'] and sha(b)==row['sha256']
result=dict(status='PASS',members=len(rows),decoded_bytes=sum(r['bytes'] for r in rows),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),complete_original_readback=True,known_fixture_secrets_absent=True,files=rows)
(out/'inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
