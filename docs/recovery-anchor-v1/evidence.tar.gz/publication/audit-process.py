import hashlib,json,re
from pathlib import Path
root=Path('/tmp/kv9-c04-anchor-envelope-process-20260915-first')
publication=Path('/tmp/kv9-c04-anchor-envelope-publication-20260915-first')
load=lambda p:json.loads(p.read_text())
r=load(root/'result.json');assert r['status']=='PASS' and r['exit_code']==0 and r['owned_process_group_absent']
assert r['binary_sha256']=='19a2cd9bdf352c9ae8c11dd88c11eeff23e76ee0d303c2315e8a2e2b8e53a0b6'
assert r['minimum_available_bytes']>=r['free_space_floor_bytes']==8*1024**3
assert r['peak_observed_local_allocation_bytes']<=r['fresh_local_allocation_limit_bytes']==1024**3
assert 'PASS: minio-kv-e2e (3 replicas, failover, remote checkpoint, reclaimed WAL, live tail, deletes)' in (root/'process.log').read_text()
fixture=Path(r['artifacts']);audit=load(root/'anchor-log-audit.json');groups={};rows=[]
for node in audit['nodes']:
 p=Path(node['log']['path']);data=p.read_bytes()
 assert p==fixture/f"n{node['node']}.log" and hashlib.sha256(data).hexdigest()==node['log']['sha256']
 matches=re.findall(r'node (\d+) recovered checkpoint generation=(\d+) cut=(\d+) publication=(\d+) anchor=([0-9a-f]{64})(?:\n|$)',data.decode())
 assert len(matches)==len(node['recoveries'])>=2
 for match in matches:
  n,g,c,p=map(int,match[:4]);assert n==node['node'] and 0<c<p and g>0
  key=(g,c,p);groups.setdefault(key,set()).add(match[4]);rows.append(dict(node=n,generation=g,cut=c,publication=p,anchor=match[4]))
assert {n['node'] for n in audit['nodes']}=={1,2,3}
assert all(len(v)==1 for v in groups.values())
# The selected fixture uses the same root and retained manifests; this checks
# observed identity agreement, not a general hash-collision or refinement proof.
old=load(Path('/tmp/kv9-c04-checkpoint-base-publication-20260915-first/process-public-files.json'))
files=[]
for row in old['files']:
 p=fixture/row['name'];assert p.is_file() and not p.is_symlink()
 files.append(dict(name=row['name'],path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(publication/'process-public-files.json').write_text(json.dumps(dict(files=files),indent=2)+'\n')
print(json.dumps(dict(status='PASS',recoveries=rows,observed_shared_image_identity_agrees=True,selected_files=len(files),scope='Actual process terminal/resources and retained recovery logs; fixture file selection for portable readback. No workload rerun or general concurrent-history proof.'),indent=2))
