import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/dongxu/kv9');work=Path('/mnt/data/kv9-work/retirement-20260917');out=root/'docs/storage-retirement-v1'
e2e=json.loads((work/'e2e-second/result.json').read_text())
assert e2e['verdict']=='accepted' and not e2e['chaos_mesh']
local=json.loads((work/'local-validation.json').read_text())
assert local['schema']==1
out.mkdir(exist_ok=False)
files={};excluded=[]
for p in sorted(work.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 r=p.relative_to(work)
 if '__pycache__' in r.parts or p.suffix in ('.olean','.ilean','.pyc'):continue
 if p.name.startswith('issue') or 'issues' in r.parts or p.name in ('publication.json','handoff-in.md'):continue
 if p.name in ('kubeconfig','token','credentials','root.bin') or p.suffix in ('.key','.pem'):excluded.append(str(r));continue
 with p.open('rb') as stream:magic=stream.read(4)
 if magic==b'\x7fELF':excluded.append(str(r));continue
 files['evidence/'+str(r)]=p
names=set()
for model in ['storage-retirement','replica-removal','voter-promotion','source-truncation','install-evidence','runtime-adoption','learner-attach','source-capture','migration-authority','joint-install','protocol-snapshot','group-preparation','group-activation','group-control','data-range','routed-client']:
 c=root/'proofs/lean'/model/'source-contract.json';names.add(str(c.relative_to(root)));names.update(json.loads(c.read_text())['source_sha256'])
names.update(['scripts/prove-storage-retirement.py','scripts/retirement-e2e.py','scripts/check-retention-ledger.py','proofs/tlaps/retention_ledger/inventory.json','docs/STORAGE-RETIREMENT.md','docs/HORIZONTAL-SCALING-PLAN.md','Cargo.toml','Cargo.lock'])
for command in [['git','diff','--name-only'],['git','ls-files','--others','--exclude-standard']]:
 for name in subprocess.check_output(command,cwd=root,text=True).splitlines():
  if name not in ('scripts/checkpoint-publication-chaos.py','scripts/checkpoint-owned-crash.py') and not name.startswith('docs/storage-retirement-v1/'):
   names.add(name)
for name in names:
 if (root/name).is_file():files['source/'+name]=root/name
members=[];total=0
with (out/'evidence.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,p in sorted(files.items()):
  data=p.read_bytes();total+=len(data);assert total<=256*1024**2
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  members.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert (out/'evidence.tar.gz').stat().st_size<=60*1024**2
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 actual=[]
 for m in tar:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  d=tar.extractfile(m).read();actual.append({'name':m.name,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
assert actual==members
artifact=out/'evidence.tar.gz'
summary={'schema':1,'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'archive_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'archive_bytes':artifact.stat().st_size,'decoded_bytes':total,'members':members,'excluded_files':excluded,'accepted':{'local':'evidence/local-validation.json','storage_retirement_proof':'evidence/storage-retirement-proof/result.json','sibling_lean_models':['evidence/data-range-proof.log','evidence/group-activation-proof.log','evidence/group-control-proof.log','evidence/group-preparation-proof.log','evidence/joint-install-proof.log','evidence/learner-attach-proof.log','evidence/migration-authority-proof.log','evidence/protocol-snapshot-proof.log','evidence/routed-client-proof.log','evidence/source-capture-proof.log','evidence/runtime-adoption-proof.log','evidence/install-evidence-proof.log','evidence/source-truncation-proof.log','evidence/voter-promotion-proof.log','evidence/replica-removal-proof.log'],'retention_tlaps':'evidence/retention-ledger-recheck.log','minio_focused':'evidence/minio-focused.log','e2e':'evidence/e2e-second/result.json','e2e_first_attempt_also_accepted':'evidence/e2e-first/result.json'},'not_claimed':['physical reclamation','serving from the learner','physical disk reclamation or follower-side compaction','stranded-learner recovery','destination pin release','network snapshot reception','split publication or placement','Chaos Mesh for this increment','general concurrent linearizability','verified Rust extraction','new throughput or scaling','hosted CI']}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['archive_sha256','archive_bytes','decoded_bytes']}));print('members',len(members))
