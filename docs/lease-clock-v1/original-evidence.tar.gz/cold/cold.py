"""Finite cold conversion of the 32 authorized historical executable copies."""
import gzip
import hashlib
import json
import os
import stat
import sys
import time
import traceback
from pathlib import Path

OUT = Path('/tmp/kv9-lease-clock-storage-cold-first')
PREP = Path('/tmp/kv9-lease-clock-storage-inventory-first')
INVENTORY_SHA = '35c25d3edb7d80adecc3022492dd0be88c6bafcbd0d1e4123b1b51d2aaa09657'
FLOOR = 80 * 1024**3
CAP = 4 * 1024**3
GOAL = 3 * 1024**3
CHUNK = 1024**2
CPUS = set(range(6, 16)) | set(range(22, 32))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def identity(path):
    s = path.lstat()
    return dict(dev=s.st_dev, ino=s.st_ino, bytes=s.st_size,
                allocated_bytes=s.st_blocks * 512, mode=s.st_mode,
                uid=s.st_uid, gid=s.st_gid, nlink=s.st_nlink,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)


def guard(extra=0):
    v = os.statvfs(OUT)
    free = v.f_bavail * v.f_frsize
    allocated = sum(p.stat().st_blocks * 512 for p in OUT.iterdir() if p.is_file())
    require(free - extra >= FLOOR, '80 GiB free floor reached')
    require(allocated + extra <= CAP, '4 GiB archive/preparation cap reached')
    return dict(free_bytes=free, owned_allocated_bytes=allocated, observed_ns=time.time_ns())


def save(name, value):
    guard(CHUNK)
    with (OUT / name).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while block := f.read(CHUNK):
            guard()
            h.update(block)
    return h.hexdigest()


def check_source(row):
    path = Path(row['path'])
    require(path.resolve() == path and not any('target' in p.lower() for p in path.parts),
            'source path is linked or under a target')
    require(identity(path) == row['identity'], 'original metadata identity changed: ' + str(path))
    s = row['identity']
    require(stat.S_ISREG(s['mode']) and s['uid'] == 1000 and s['nlink'] == 1,
            'source type/ownership/link count differs')
    require(sha(path) == row['expected_sha256'], 'original role hash mismatch: ' + str(path))
    require(identity(path) == s, 'source changed during hash')


def check_metadata(records):
    for record in records:
        p = Path(record['path'])
        require(p.is_file() and not p.is_symlink(), 'protected metadata is missing or linked')
        require(p.stat().st_size == record['bytes'] and sha(p) == record['sha256'],
                'protected historical metadata changed: ' + str(p))
        if 'identity' in record:
            require(identity(p) == record['identity'], 'protected metadata identity changed')


def references(row, name):
    original = row['identity']
    key = original['dev'], original['ino']
    mapped_key = os.major(key[0]), os.minor(key[0]), key[1]
    root = row['root'].encode()
    hits, errors = [], []
    checked = 0
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            for kind, target in [('exe', proc / 'exe')] + [('fd', p) for p in (proc / 'fd').iterdir()]:
                try:
                    s = target.stat()
                    if (s.st_dev, s.st_ino) == key:
                        hits.append(dict(pid=int(proc.name), kind=kind, path=row['path']))
                except (FileNotFoundError, ProcessLookupError):
                    pass
            for line in (proc / 'maps').read_text().splitlines():
                fields = line.split(None, 5)
                if len(fields) >= 5:
                    major, minor = [int(x, 16) for x in fields[3].split(':')]
                    if (major, minor, int(fields[4])) == mapped_key:
                        hits.append(dict(pid=int(proc.name), kind='mapped-inode', path=row['path']))
            if root in (proc / 'cmdline').read_bytes():
                hits.append(dict(pid=int(proc.name), kind='command-root-reference', root=row['root']))
            checked += 1
        except (FileNotFoundError, ProcessLookupError) as error:
            if proc.exists():
                errors.append(dict(pid=int(proc.name), error=repr(error)))
        except OSError as error:
            if proc.exists():
                errors.append(dict(pid=int(proc.name), error=repr(error)))
    selected = []
    for directory in ['/tmp/kv9-thin-lto-main-integration-release-verbose-first',
                      '/tmp/kv9-owner-poll-release-first', '/tmp/kv9-wal-crc32-release-first',
                      '/tmp/kv9-point-write-v3-release-first/native',
                      '/tmp/kv9-point-write-v3-release-first/redis']:
        p = Path(directory)
        if p.exists():
            for f in p.iterdir():
                if f.is_file() and not f.is_symlink() and os.access(f, os.X_OK):
                    s = f.stat()
                    selected.append(dict(path=str(f), aliases_source=(s.st_dev, s.st_ino) == key))
    result = dict(complete=not hits and not errors, checked_processes=checked, hits=hits,
                  surviving_process_errors=errors, selected_runtime_exclusions=selected,
                  observed_ns=time.time_ns(), source_path=row['path'])
    save(name, result)
    require(not hits and not errors and not any(x['aliases_source'] for x in selected),
            'active reference, permission gap or selected-runtime alias')
    require(identity(Path(row['path'])) == original, 'source changed during reference census')


class GuardedWriter:
    def __init__(self, file):
        self.file = file

    def write(self, block):
        guard(len(block) + CHUNK)
        return self.file.write(block)

    def flush(self):
        self.file.flush()


def main():
    require(os.geteuid() == 0 and set(os.sched_getaffinity(0)) <= CPUS,
            'privileged reference visibility and authorized CPUs required')
    require(sha(PREP / 'inventory.json') == INVENTORY_SHA, 'frozen inventory hash differs')
    frozen = json.loads((PREP / 'inventory.json').read_text())
    check_metadata(frozen['records'])
    candidates = json.loads((PREP / 'candidate-inventory.json').read_text())
    rows = [r for r in candidates['files'] if r['expected_sha256']]
    require(len(rows) == 32 and len({r['path'] for r in rows}) == 32, 'exact 32-file selection differs')
    protected = []
    for entry in candidates['metadata']:
        protected.append(dict(entry, identity=identity(Path(entry['path']))))
    check_metadata(protected)
    for row in rows:
        value = json.loads(Path(row['manifest_path']).read_text())
        for component in row['manifest_field'].split('.'):
            value = value[component]
        require(value == row['expected_sha256'], 'role-specific manifest hash differs')
        require(identity(Path(row['path'])) == row['identity'], 'frozen source identity changed')
    before = guard()
    save('invocation-first.json', dict(pid=os.getpid(), argv=sys.argv, started_ns=time.time_ns(),
         helper_sha256=sha(Path(__file__)), inventory_path=str(PREP / 'inventory.json'),
         inventory_sha256=INVENTORY_SHA, original_selection=rows, protected_metadata=protected,
         before=before, floor_bytes=FLOOR, archive_cap_bytes=CAP, goal_bytes=GOAL,
         cpu_affinity=sorted(os.sched_getaffinity(0))))
    converted = []
    for index, row in enumerate(rows):
        check_source(row)
        check_metadata(protected)
        references(row, f'{index:02d}-references-before.json')
        source = Path(row['path'])
        archive = OUT / f'executable-{index:02d}.gz'
        h = hashlib.sha256()
        count = 0
        with source.open('rb') as src, archive.open('xb') as raw:
            with gzip.GzipFile(filename='', mode='wb', compresslevel=1, mtime=0,
                               fileobj=GuardedWriter(raw)) as gz:
                while block := src.read(CHUNK):
                    guard()
                    count += len(block)
                    h.update(block)
                    require(count <= row['identity']['bytes'], 'original byte bound exceeded')
                    gz.write(block)
            raw.flush()
            os.fsync(raw.fileno())
        require(count == row['identity']['bytes'] and h.hexdigest() == row['expected_sha256'],
                'source bytes changed during compression')
        require(identity(source) == row['identity'], 'source metadata changed during compression')
        h = hashlib.sha256()
        decoded_count = 0
        with gzip.open(archive, 'rb') as decoded:
            while block := decoded.read(CHUNK):
                guard()
                decoded_count += len(block)
                require(decoded_count <= row['identity']['bytes'], 'decoded byte bound exceeded')
                h.update(block)
        require(decoded_count == count and h.hexdigest() == row['expected_sha256'],
                'independent decoded EOF byte/hash verification failed')
        compressed = dict(path=str(archive), bytes=archive.stat().st_size,
                          allocated_bytes=archive.stat().st_blocks * 512, sha256=sha(archive))
        record = dict(original=row, archive=compressed, decoded_bytes=decoded_count,
                      decoded_sha256=h.hexdigest(), gzip_consumed_to_eof=True)
        save(f'{index:02d}-verified.json', record)
        check_source(row)
        require(sha(archive) == compressed['sha256'], 'archive changed before eviction')
        check_metadata(protected)
        save(f'{index:02d}-eviction-intent.json', dict(verified_record=record, observed_ns=time.time_ns()))
        references(row, f'{index:02d}-references-before-unlink.json')
        require(identity(source) == row['identity'], 'original changed at unlink boundary')
        guard()
        source.unlink()
        directory_fd = os.open(source.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
        record['unlinked_ns'] = time.time_ns()
        save(f'{index:02d}-evicted.json', record)
        converted.append(record)
        allocated_gain = sum(r['original']['identity']['allocated_bytes'] - r['archive']['allocated_bytes']
                             for r in converted)
        current = guard()
        observed_gain = current['free_bytes'] - before['free_bytes']
        own_net = sum(r['original']['identity']['allocated_bytes'] for r in converted) - current['owned_allocated_bytes']
        print(json.dumps(dict(completed_files=len(converted), payload_allocated_saving=allocated_gain,
                              owned_net_saving=own_net, observed_free_gain=observed_gain,
                              current_free_bytes=current['free_bytes'])), flush=True)
        if min(own_net, observed_gain) >= GOAL:
            break
    check_metadata(protected)
    after = guard()
    payload_gain = sum(r['original']['identity']['allocated_bytes'] - r['archive']['allocated_bytes']
                       for r in converted)
    own_net = sum(r['original']['identity']['allocated_bytes'] for r in converted) - after['owned_allocated_bytes']
    save('result-first.json', dict(complete=True, exit_code=0, ended_ns=time.time_ns(),
         candidates=32, files_evicted=len(converted), catalog=converted,
         unconverted=[r['path'] for r in rows[len(converted):]], before=before, after=after,
         payload_allocated_saving=payload_gain, owned_net_saving=own_net,
         observed_free_gain=after['free_bytes'] - before['free_bytes'],
         reached_goal=min(own_net, after['free_bytes'] - before['free_bytes']) >= GOAL,
         stopping_rule='Stop after a complete per-file transaction once both observed and owned net savings reach 3GiB, or all32 candidates exhausted.',
         protected_metadata_unchanged=True,
         scope='Lossless preservation only. Original failed/dirty/accepted outcomes unchanged. No historical replay is attempted; restore exact originals before validators that require executable files.'))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        with (OUT / 'first-failure.json').open('x') as f:
            json.dump(dict(complete=False, error=repr(error), traceback=traceback.format_exc(),
                           observed_ns=time.time_ns()), f, indent=2)
            f.write('\n')
        raise
