# Lossless cold preservation of historical executable copies

Completed once: **session 40419, exit 0, terminal receipt f21b09**. Initial receipt a8a887; actual PID 3976794 is absent. The controller stopped after **29 of the 32 authorized copies** when both recorded net savings exceeded 3 GiB. Three unconverted originals remain resident with their frozen metadata identities. No first-attempt failure or retry occurred.

Observed filesystem gain: **3,311,271,936 bytes (3.083862 GiB)**. Owned allocation gain after runtime metadata: **3,311,382,528 bytes**; original-minus-gzip payload saving: **3,312,111,616 bytes**. The 29 originals had 4,721,475,584 allocated bytes; gzip objects total 1,409,249,801 logical / 1,409,363,968 allocated bytes. Result-time available space was **104,569,970,688 bytes**, 1,490,755,584 above the unchanged 96 GiB source preflight. These are observations at the recorded times; later unrelated work can consume capacity. Final reporting metadata consumes a small additional allocation.

Every original was checked against its frozen device/inode/size/owner/mode/link-count/mtime/ctime and role-specific recorded SHA-256 before compression. Each exclusive gzip was independently decoded to EOF with exact byte-count/SHA equality. The original and gzip were rehashed before unlink, followed by a fresh privileged exe/fd/mapped-inode/command-root check immediately before eviction. All **58 per-file reference checks** passed with no hits, surviving-process permission errors or selected-runtime inode aliases. Original directories were fsynced after unlink.

All recorded manifests, source maps and historical build logs remain byte- and identity-identical. Dirty source markers, feature/profile scope, original failed attempts and original acceptance results were not relabeled. This storage operation establishes exact retained bytes; it does not assert every historical fixture succeeded or that current source matches an old dirty build. No shared-object deduplication occurred: each converted original has its own gzip and original-path restore record.

The inherited 4 GiB archive/preparation cap and 80 GiB free floor were enforced on every streaming step. Work ran serially on CPUs 6–7, within the authorized CPU set. No Cargo, target, repository, current source check, selected runtime/client, fixture, Kubernetes resource or already-cold payload was changed.

| Index | Original executable | Original bytes | Original/decoded SHA-256 | Gzip | Gzip bytes |
| --- | --- | ---: | --- | --- | ---: |
| 0 | `/tmp/kv9-async-write-status-identity-default-build/kv9` | 179639856 | `e44cfe74f916799e97b4d476f42a44528a2338d0629a562e48fc617ccd39c9ca` | `executable-00.gz` | 54738564 |
| 1 | `/tmp/kv9-b3-acceptance-build/admission-pressure` | 145363392 | `42fec57853a96155c7f613598adf253a018d5b860750d287ae2d5cb7734bc882` | `executable-01.gz` | 42443102 |
| 2 | `/tmp/kv9-b3-acceptance-build/kv9` | 176492312 | `263b540f9f5a592c4f35294b2c10047d97063d2bcaa0f17aa5217c79f923e9e8` | `executable-02.gz` | 53643532 |
| 3 | `/tmp/kv9-benchmark-build-debug-1/kv9` | 169558208 | `3dcc43a2050d923357ede23e325907b23162dfb86cbb1536bb37be068828e3e2` | `executable-03.gz` | 51822285 |
| 4 | `/tmp/kv9-benchmark-build-debug-1/workload-loopback` | 148206096 | `2c8b14d3233fd0c6fb41244532d29581a7ba232467641afb3b416b5fe56470af` | `executable-04.gz` | 43351756 |
| 5 | `/tmp/kv9-benchmark-build-debug-1/workload/kv9-workload` | 139841184 | `a73b75b14af7646ded5877915122c788ae311a736cad6516bc9e75ea01a76879` | `executable-05.gz` | 41182689 |
| 6 | `/tmp/kv9-benchmark-build-debug-2/kv9` | 169558208 | `3dcc43a2050d923357ede23e325907b23162dfb86cbb1536bb37be068828e3e2` | `executable-06.gz` | 51822285 |
| 7 | `/tmp/kv9-benchmark-build-debug-2/workload-loopback` | 148206096 | `2c8b14d3233fd0c6fb41244532d29581a7ba232467641afb3b416b5fe56470af` | `executable-07.gz` | 43351756 |
| 8 | `/tmp/kv9-benchmark-build-debug-2/workload/kv9-workload` | 139841184 | `a73b75b14af7646ded5877915122c788ae311a736cad6516bc9e75ea01a76879` | `executable-08.gz` | 41182689 |
| 9 | `/tmp/kv9-fe-acceptance-build/admission-pressure` | 145463992 | `0991e6d3f74ae272083a3ba2e13c92f9a1000653b3496b17938fb4cec1582fee` | `executable-09.gz` | 42443669 |
| 10 | `/tmp/kv9-fe-acceptance-build/kv9` | 176800512 | `3fb57e1618ba8b79bd05045ec0bf69836cd69d426c4a12d31e99687e1e4840bf` | `executable-10.gz` | 53758678 |
| 11 | `/tmp/kv9-formation-benchmark-build/kv9` | 170245416 | `4ccdeaa811caf3af3d8fd82f947b09a4b1b06fb22595d30bd5da214e0e4e0956` | `executable-11.gz` | 52042764 |
| 12 | `/tmp/kv9-formation-benchmark-build/workload-loopback` | 148313840 | `0dbdc70086051fdfee3a81aaf0d469d5752ad9170ef40ad0855d0ca9f160bbcf` | `executable-12.gz` | 43383587 |
| 13 | `/tmp/kv9-formation-benchmark-build/workload/kv9-workload` | 139975200 | `ce78020a340d4120a54e3032b359baa5d46cc931253f0eef01d5ca9eba278496` | `executable-13.gz` | 41208037 |
| 14 | `/tmp/kv9-native-batch-benchmark-build-dev1/kv9-batch-benchmark` | 156132640 | `2a3552a7bd1102f7e37b490955e1a28791f8c0979902447dd14b4eeb035ef1f9` | `executable-14.gz` | 45966671 |
| 15 | `/tmp/kv9-native-batch-build-first/kv9` | 185105144 | `f7e88b6c2f2514748c13fbaf85c3ee0540284138b3f3cc6bd774bdfd17e7eb4e` | `executable-15.gz` | 56316513 |
| 16 | `/tmp/kv9-native-batch-build-first/workload/kv9-batch-workload` | 157108672 | `6fb5633bd42cd34c9121d9bd8c04103b146beb79fcad52cb1fc8df41529db6d8` | `executable-16.gz` | 46160402 |
| 17 | `/tmp/kv9-normal-stream-build-first/kv9` | 185105152 | `c31f8c57085ab24b902ed52b31bf36bc600fa53eb04470c25a9dddf7e0e0c9a3` | `executable-17.gz` | 56316701 |
| 18 | `/tmp/kv9-normal-stream-build-first/workload-loopback` | 160382832 | `d7b3d9357c11ecef6d83be88fc04f35b19ebe80acdb32d90b2e44311bcf07d04` | `executable-18.gz` | 46648876 |
| 19 | `/tmp/kv9-normal-stream-build-first/workload/kv9-workload` | 153076408 | `dcf6f88aa8aa943d8be71af329094bc8015f26a8844ed2b34032972bc4b4bef7` | `executable-19.gz` | 44883445 |
| 20 | `/tmp/kv9-proposal-queue-workload-build/kv9-workload` | 144869296 | `1107444e5ea2ea470b158821e3fbd28d7c37c8ba863c52eb7ea97ff7938096ad` | `executable-20.gz` | 42375343 |
| 21 | `/tmp/kv9-rpc-framework-build-first/kv9` | 191144608 | `1eb8ea9f86d51bfca066d2c51292188c93af218ad1e2425c2deacf0e7ce67b69` | `executable-21.gz` | 58467635 |
| 22 | `/tmp/kv9-rpc-framework-build-first/workload/kv9-workload` | 158270056 | `9e5b26ada6d31d0f9979798d71f0be18471b24a64f888ec1c63cadb34b999d13` | `executable-22.gz` | 46711584 |
| 23 | `/tmp/kv9-rpc-framework-build-second/kv9` | 191144608 | `1eb8ea9f86d51bfca066d2c51292188c93af218ad1e2425c2deacf0e7ce67b69` | `executable-23.gz` | 58467635 |
| 24 | `/tmp/kv9-rpc-framework-build-second/workload/kv9-workload` | 158270056 | `9e5b26ada6d31d0f9979798d71f0be18471b24a64f888ec1c63cadb34b999d13` | `executable-24.gz` | 46711584 |
| 25 | `/tmp/kv9-status-process-identity-default-build/kv9` | 176606792 | `5d5aa8772bd6946f52164634b12d554c1420cc7f017906b9591e2870867891df` | `executable-25.gz` | 53699007 |
| 26 | `/tmp/kv9-stream-build-first/kv9` | 200390000 | `bfa8e503348fdb00ef0ba2eb336449251e4588ead2becbde624e524109e09d58` | `executable-26.gz` | 60394380 |
| 27 | `/tmp/kv9-stream-build-first/workload/kv9-workload` | 166878696 | `cc994b44d17a0db9edc7bd95b5d0d267d3bb7fac8be86daf83076f96c0b75f9e` | `executable-27.gz` | 48572925 |
| 28 | `/tmp/kv9-workload-runner-build-1/kv9-workload` | 139841104 | `0769470da5af5121e3b1d5727ab246cbc36482a3d881fb4b74dc3a797f1a2220` | `executable-28.gz` | 41181707 |

The complete compressed SHA-256 values, original mode/UID/GID/mtime, manifest paths/hashes and exact source identities are in `restore-catalog.json`, which is derived from the unchanged `result-first.json` and original protected metadata.

## Exact original-path restore (not executed)

1. Select one index from `restore-catalog.json`. Require the exact original parent directory with no symlink components and an absent destination. Keep all gzip objects and cold evidence. Reserve the full decoded length above the unchanged 80 GiB free floor and use bounded streaming work on the authorized helper CPUs.
2. Check gzip byte count and SHA-256 against the catalog. Create an exclusive temporary regular file in the original parent. Stream gzip decoding with a hard `decoded_bytes` bound, require EOF, fsync, then verify exact decoded byte count and SHA-256. Preserve a failed temporary and error receipt; do not install it.
3. Apply recorded UID/GID, permission bits (`original_identity.mode & 0o7777`) and `original_identity.mtime_ns` to the verified temporary. Install with a no-overwrite hard link at the exact original path, then remove only the temporary link and fsync the parent. Fail on any concurrent/conflicting destination. Historical inode and ctime are evidence and cannot be recreated.
4. Verify restored bytes/hash, ownership/mode/mtime and one-link status. Record a fresh restore receipt bound to this catalog and original gzip. Never rewrite original manifests, source maps, test outcomes or the cold result. Restoring bytes must not execute the historical binary.

Older validators or scripts that require the executable path must be run only after restoring that exact file. The cold catalog does not silently change their acceptance predicates. Current Markdown references and original inventories stay unchanged; all original source and validation evidence remain in their original locations.

Unconverted originals:

- `/tmp/kv9-workload-runner-build-final/kv9-workload`
- `/tmp/kv9-workload-runner-commit-build/kv9-workload`
- `/tmp/kv9-workload-startup-build-1/kv9-workload`

Evidence chain: original inventory SHA `35c25d3edb7d80adecc3022492dd0be88c6bafcbd0d1e4123b1b51d2aaa09657`; `lineage.json`; actual `invocation-first.json`; every `NN-verified.json`, `NN-references-*.json`, `NN-eviction-intent.json`, `NN-evicted.json`; `result-first.json`; actual `terminal-first.json`. Final packaging checks are metadata-only and do not repeat payload hashing or decoding.
