# Read-only clock-adapter storage options

A finite pool of **32 historical retained executable copies** has original per-artifact SHA-256 records and occupies **5,141,045,248 allocated bytes (4.788 GiB)**. These are old unoptimized server/workload/pressure/benchmark copies outside all Cargo targets and selected current releases. No binary bytes were hashed, compressed, linked, deleted or otherwise changed; only stat, small historical build metadata and current process/reference records were read.

Cold compression of this pool is a plausible way to recover 3 GiB, but it is not a guaranteed capacity result. Net recovery must be measured after a separately authorized conversion. Independently compressing each file must save at least **62.66%** of the present allocation, plus room for metadata, to reach 3 GiB. At 65% saving the estimate is 3,341,679,411 bytes (3.112 GiB); at 60% it is only 3,084,627,148 bytes (2.873 GiB). Earlier 90 MB test probes retained about one third of their bytes, which motivates the estimate but does not establish these different executables' ratios.

The privileged process census inspected 633 processes with **zero executable/fd/mapped-inode hits, zero matching command references and zero surviving-process permission errors**. No candidate identities changed during that check, and no selected-runtime inode alias was found. This is a point-in-time observation; it does not replace the mandatory repeated process and identity check immediately before a future unlink.

| Original retained root | Files | Allocated bytes | Basenames / relative paths |
| --- | ---: | ---: | --- |
| `/tmp/kv9-async-write-status-identity-default-build` | 1 | 179646464 | `kv9` |
| `/tmp/kv9-b3-acceptance-build` | 2 | 321867776 | `admission-pressure`, `kv9` |
| `/tmp/kv9-benchmark-build-debug-1` | 3 | 457625600 | `kv9`, `workload-loopback`, `workload/kv9-workload` |
| `/tmp/kv9-benchmark-build-debug-2` | 3 | 457625600 | `kv9`, `workload-loopback`, `workload/kv9-workload` |
| `/tmp/kv9-fe-acceptance-build` | 2 | 322273280 | `admission-pressure`, `kv9` |
| `/tmp/kv9-formation-benchmark-build` | 3 | 458551296 | `kv9`, `workload-loopback`, `workload/kv9-workload` |
| `/tmp/kv9-native-batch-benchmark-build-dev1` | 1 | 156139520 | `kv9-batch-benchmark` |
| `/tmp/kv9-native-batch-build-first` | 2 | 342224896 | `kv9`, `workload/kv9-batch-workload` |
| `/tmp/kv9-normal-stream-build-first` | 3 | 498577408 | `kv9`, `workload-loopback`, `workload/kv9-workload` |
| `/tmp/kv9-proposal-queue-workload-build` | 1 | 144871424 | `kv9-workload` |
| `/tmp/kv9-rpc-framework-build-first` | 2 | 349429760 | `kv9`, `workload/kv9-workload` |
| `/tmp/kv9-rpc-framework-build-second` | 2 | 349429760 | `kv9`, `workload/kv9-workload` |
| `/tmp/kv9-status-process-identity-default-build` | 1 | 176091136 | `kv9` |
| `/tmp/kv9-stream-build-first` | 2 | 367276032 | `kv9`, `workload/kv9-workload` |
| `/tmp/kv9-workload-runner-build-1` | 1 | 139845632 | `kv9-workload` |
| `/tmp/kv9-workload-runner-build-final` | 1 | 139845632 | `kv9-workload` |
| `/tmp/kv9-workload-runner-commit-build` | 1 | 139845632 | `kv9-workload` |
| `/tmp/kv9-workload-startup-build-1` | 1 | 139878400 | `kv9-workload` |

`candidate-inventory.json` contains every exact path, device/inode, size/allocation, UID/GID/mode/link count/mtime/ctime, original manifest path+hash field, declared executable hash, revision, source map/tree bindings and build-finished observations. These hashes are original metadata claims; current executable-to-manifest byte identity remains a required future check. Paired RPC and benchmark debug copies have different source provenance even where their declared binary hashes match; preserve each original manifest independently.

Four additional large copies totaling 635,240,448 allocated bytes are excluded from the bound pool: all three files in `/tmp/kv9-cc8-acceptance-build` lack a sibling per-artifact manifest here, and `/tmp/kv9-workload-startup-build-1/kv9` shares a manifest that actually pins the workload role. Do not attach that workload hash to the server.

Six pairs in the bound pool declare equal binary hashes and equal lengths (946,900,992 redundant allocated bytes according to their manifests). These equalities have not been verified against current payloads. A shared cold object could improve margin only after exact verification and an explicitly reviewed per-original restore catalog; do not hard-link writable historical originals or assume a deduplication guarantee. The simple one-archive-per-file estimate above does not use this possible benefit.

## Preservation and release conditions

1. Obtain separate authorization for the exact executable list; this report authorizes no conversion. Preserve original manifests, source maps, build logs, scripts, historical failures, dirty-source markers and results unchanged. A dirty historical build is not relabeled clean or newly accepted. Build success alone does not establish every later fixture passed.
2. Recheck every selected file is the same singly linked ordinary file, owned by the expected UID, not under a target/repository/current fixture, and not a selected release/client. Repeat privileged exe/fd/mapped-inode and owner checks; surviving-process permission errors fail closed. Bind any old terminal/use records needed to establish the chosen owner has ended.
3. Before any removal, hash actual bytes against the original role-specific manifest, stream an exclusive archive under the existing 4 GiB output cap and 80 GiB free floor, independently consume it to gzip EOF and require exact byte count/hash, rehash the unchanged source and archive, then repeat reference checks. Process one conversion at a time on helper CPUs. Leave partial archives and first failures retained, with no automatic retry or altered outcomes.
4. Record per-path device/inode/metadata, original and archive hashes/counts, source/build manifest hashes, terminal receipt and a no-overwrite restoration catalog. Only a verified original executable may be unlinked; never remove its build directory, metadata or associated data/WAL evidence. Stop when actual net recovery meets the target or report the remaining shortfall.
5. Restore through a fresh exclusive temporary in the original directory, enforce the full original byte bound and SHA-256, set mode/owner/mtime, then install with a no-overwrite operation and fsync. Preserve the archive. Restoring bytes must not run the executable or change any historical result.

## Existing references and limits

Current repository references are only in six Markdown locations captured verbatim in `current-reference-matches.txt`; the checked `scripts` tree contains no literal matches. Generic older validators can still accept these build directories as inputs and require the original executable to exist. Therefore cold conversion is not transparent to all historical replays: restore the exact original first. Keep historical acceptance inventories unchanged and use a separate cold-location catalog; no new re-auditability or runtime acceptance is implied.

The cited docs include NATIVE-BATCH-ACCEPTANCE, RPC-STREAM-CONTROL, NATIVE-BATCH-BENCHMARK, RAW-GROUP-VALIDATION, STREAMING-RPC-PROCESS-ACCEPTANCE and CC8-MINIO-CHAOS-ACCEPTANCE (the CC8 root is excluded). Current selected ThinLTO, fixed-v3 clients, original CRC and owner-poll releases were checked only as inode exclusions. No Cargo command, fixture/process control, Kubernetes action, source edit, target scan or codec ran.

The last recorded free-space value is in `capacity-estimates.json`; no resource threshold changed and no current 96 GiB preflight readiness is claimed.
