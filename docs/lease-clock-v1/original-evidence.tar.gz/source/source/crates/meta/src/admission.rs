//! Cluster identity + node-admission catalog operations (task #24).
//!
//! The three-gate membership contract's data half:
//!
//! - **Gate 2 (identity)**: [`initialize_cluster`] records the ClusterId the
//!   bootstrap winner minted — as ordinary committed catalog rows, so identity
//!   is crash-safe and replicated like everything else. Written once, never
//!   updated; a second initialization attempt is a typed error.
//! - **Gate 3 (admission)**: [`admit_node`] is the leader-committed approval
//!   binding `(cluster_id, node_id, address, role)` BEFORE a node may join the
//!   raft group; [`consume_admission`] flips it exactly once when the join
//!   completes. A valid cluster token is never admission by itself.
//!
//! Everything here produces or reads catalog rows inside a [`MetaTxn`];
//! replication happens by the caller committing that txn through raft (the
//! same propose → wait-applied path as `CreateKeyspace`). NOTHING here
//! mutates state outside the transaction — a "locally admitted" node the log
//! doesn't know about is exactly the fake-Registered state the #24 contract
//! forbids.
//!
//! The join-ticket seam (`nonce_sha256`) is NOT implemented in this block:
//! the column exists for the schema's final shape, no code writes or compares
//! it, and the minimal admission mode is a mandatory `--cluster-id`. When
//! implemented, the hash must be SHA-256 (not a checksum hash), the compare
//! constant-time, and neither ticket nor digest ever logged (Tess's review).

use kv9_common::{ClusterId, Error, NodeId, Result};
use kv9_engine::Engine;

use crate::codec::{decode_uint_component, memcmp_uint, ColumnValue, RowValue};
use crate::schema::{ColumnId, CLUSTER_META_DESC, NODE_ADMISSIONS_DESC};
use crate::store::MetaTxn;

/// Stable semantic reason consumed by the registration transport adapter.
/// Keep the producer and classifier on this one definition; independently
/// copied text would silently demote an invalid ticket to a generic refusal.
pub const INVALID_JOIN_TICKET_MESSAGE: &str = "invalid join ticket";

/// The role an admission grants. Only learner exists in Phase-1 dynamic
/// membership: promotion to voter is a separate leader decision through raft
/// ConfChange, not an admission state.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AdmittedRole {
    Learner = 1,
}

/// Admission lifecycle. `Pending` → `Consumed` on successful join (exactly
/// once). `Superseded` cancels an obsolete ticket during endpoint migration
/// without decommissioning its existing member. `Revoked` additionally denies
/// that member's node authentication until an explicit new admission.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AdmissionState {
    Pending = 1,
    Consumed = 2,
    Revoked = 3,
    Superseded = 4,
}

impl AdmissionState {
    fn from_code(code: u64) -> Result<AdmissionState> {
        match code {
            1 => Ok(AdmissionState::Pending),
            2 => Ok(AdmissionState::Consumed),
            3 => Ok(AdmissionState::Revoked),
            4 => Ok(AdmissionState::Superseded),
            other => Err(Error::Config(format!(
                "unknown admission state code {other}"
            ))),
        }
    }
}

/// One admission record, decoded.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Admission {
    pub node_id: NodeId,
    pub cluster_id: ClusterId,
    pub addr: String,
    pub role: AdmittedRole,
    pub state: AdmissionState,
    pub expires_unix: u64,
    /// SHA-256 of the one-time join ticket. The plaintext is never committed.
    pub ticket_sha256: Vec<u8>,
}

const CM_PK: u64 = 0; // cluster_meta singleton row id
const CM_CLUSTER_ID: ColumnId = ColumnId(2);
const CM_CREATED: ColumnId = ColumnId(3);

const NA_CLUSTER_ID: ColumnId = ColumnId(2);
const NA_ADDR: ColumnId = ColumnId(3);
const NA_ROLE: ColumnId = ColumnId(4);
const NA_STATE: ColumnId = ColumnId(5);
const NA_TICKET_SHA256: ColumnId = ColumnId(6);
const NA_EXPIRES: ColumnId = ColumnId(7);

/// Production admission path: bind a one-time credential hash to the
/// cluster/node/address tuple in the same committed row.
pub fn admit_node_with_ticket_hash<E: Engine>(
    txn: &mut MetaTxn<'_, E>,
    node_id: NodeId,
    addr: &str,
    role: AdmittedRole,
    ticket_sha256: &[u8],
    expires_unix: u64,
) -> Result<()> {
    if ticket_sha256.len() != 32 {
        return Err(Error::Config(
            "join ticket digest must be exactly 32 bytes".into(),
        ));
    }
    admit_node_inner(txn, node_id, addr, role, ticket_sha256, expires_unix)
}

/// Record the freshly minted cluster identity (bootstrap winner, exactly
/// once). Fails if an identity already exists — a ClusterId is immutable, and
/// a second write is either a replayed init (harmless to refuse: apply is
/// idempotent via the watermark, this guard is for the PROPOSE path) or a bug.
pub fn initialize_cluster<E: Engine>(
    txn: &mut MetaTxn<'_, E>,
    cluster_id: ClusterId,
    created_unix: u64,
) -> Result<()> {
    if txn
        .get(&CLUSTER_META_DESC, &[memcmp_uint(CM_PK)])?
        .is_some()
    {
        return Err(Error::Config(
            "cluster identity already initialized; ClusterId is immutable".into(),
        ));
    }
    let mut row = RowValue::new();
    row.set(
        CM_CLUSTER_ID,
        ColumnValue::Bytes(cluster_id.as_bytes().to_vec()),
    );
    row.set(CM_CREATED, ColumnValue::Uint(created_unix));
    txn.insert(&CLUSTER_META_DESC, &[memcmp_uint(CM_PK)], row)
}

/// Read the cluster identity, if initialized.
pub fn cluster_id<E: Engine>(txn: &MetaTxn<'_, E>) -> Result<Option<ClusterId>> {
    let Some(row) = txn.get(&CLUSTER_META_DESC, &[memcmp_uint(CM_PK)])? else {
        return Ok(None);
    };
    let Some(ColumnValue::Bytes(b)) = row.value.get(CM_CLUSTER_ID) else {
        return Err(Error::Config("cluster_meta row missing cluster_id".into()));
    };
    let bytes: [u8; 16] = b
        .as_slice()
        .try_into()
        .map_err(|_| Error::Config(format!("cluster_id must be 16 bytes, got {}", b.len())))?;
    Ok(Some(ClusterId::from_bytes(bytes)))
}

/// Leader-committed admission: approve `node_id@addr` to join THIS cluster as
/// `role`. Refuses if the cluster identity is missing (admission is a gate-3
/// artifact — it cannot precede gate 2) or if a PENDING or CONSUMED record
/// exists for the node; only a REVOKED record may be replaced
/// ([`revoke_admission`] is the operator's retry/decommission path — silently
/// replacing a live record would let one approval be used twice).
pub fn admit_node<E: Engine>(
    txn: &mut MetaTxn<'_, E>,
    node_id: NodeId,
    addr: &str,
    role: AdmittedRole,
    expires_unix: u64,
) -> Result<()> {
    // Retained for catalog-level callers that do not exercise authentication.
    // Production uses `admit_node_with_ticket_hash` and registration refuses
    // a row whose digest does not match the presented ticket.
    admit_node_inner(txn, node_id, addr, role, &[0; 32], expires_unix)
}

fn admit_node_inner<E: Engine>(
    txn: &mut MetaTxn<'_, E>,
    node_id: NodeId,
    addr: &str,
    role: AdmittedRole,
    ticket_sha256: &[u8],
    expires_unix: u64,
) -> Result<()> {
    // NodeId 0 is the wire encoding's "no node" (leader_id=0 = none): a
    // committed admission for it would be an unaddressable identity that
    // every "is there a leader/node" check misreads. CLI validation cannot
    // substitute for the catalog invariant — future RPC callers hit this
    // same gate (Tess's review).
    if node_id.0 == 0 {
        return Err(Error::Config(
            "node id 0 is reserved (means 'no node') and cannot be admitted".into(),
        ));
    }
    // Canonical socket address only: the admission binds an exact endpoint,
    // and a free-form string would make the consume-time comparison
    // format-sensitive ("127.0.0.1:9" vs "127.000.000.001:9").
    let canonical: std::net::SocketAddr = addr.parse().map_err(|_| {
        Error::Config(format!(
            "admission address must be a canonical socket address, got {addr:?}"
        ))
    })?;
    let addr = canonical.to_string();
    let Some(cid) = cluster_id(txn)? else {
        return Err(Error::Config(
            "cannot admit a node before the cluster identity is initialized".into(),
        ));
    };
    if let Some(existing) = admission(txn, node_id)? {
        // Only a terminal credential may be replaced. Pending/Consumed
        // records retain their one-time approval until explicitly invalidated.
        if !matches!(
            existing.state,
            AdmissionState::Revoked | AdmissionState::Superseded
        ) {
            return Err(Error::Config(format!(
                "an admission record for node {} already exists in state {:?} \
                 (revoke it first)",
                node_id.0, existing.state
            )));
        }
        let changes = vec![
            (NA_CLUSTER_ID, ColumnValue::Bytes(cid.as_bytes().to_vec())),
            (NA_ADDR, ColumnValue::Text(addr.clone())),
            (NA_ROLE, ColumnValue::Uint(role as u64)),
            (NA_STATE, ColumnValue::Uint(AdmissionState::Pending as u64)),
            (NA_TICKET_SHA256, ColumnValue::Bytes(ticket_sha256.to_vec())),
            (NA_EXPIRES, ColumnValue::Uint(expires_unix)),
        ];
        return txn.update(&NODE_ADMISSIONS_DESC, &[memcmp_uint(node_id.0)], changes);
    }
    let mut row = RowValue::new();
    row.set(NA_CLUSTER_ID, ColumnValue::Bytes(cid.as_bytes().to_vec()));
    row.set(NA_ADDR, ColumnValue::Text(addr));
    row.set(NA_ROLE, ColumnValue::Uint(role as u64));
    row.set(NA_STATE, ColumnValue::Uint(AdmissionState::Pending as u64));
    row.set(NA_TICKET_SHA256, ColumnValue::Bytes(ticket_sha256.to_vec()));
    row.set(NA_EXPIRES, ColumnValue::Uint(expires_unix));
    txn.insert(&NODE_ADMISSIONS_DESC, &[memcmp_uint(node_id.0)], row)
}

/// Consume a pending admission at join time — exactly once. Verifies, in
/// order: the record exists; it binds THIS cluster (a record replayed into the
/// wrong environment must admit nobody); it is still `Pending`
/// (consumed/revoked are terminal for this call); and it has not expired
/// (`now_unix` comes from the caller — catalog code takes no clocks).
pub fn consume_admission<E: Engine>(
    txn: &mut MetaTxn<'_, E>,
    node_id: NodeId,
    expected_cluster: ClusterId,
    expected_addr: &str,
    now_unix: u64,
) -> Result<Admission> {
    consume_admission_inner(
        txn,
        node_id,
        expected_cluster,
        expected_addr,
        None,
        now_unix,
    )
}

/// Consume an admission only when the presented one-time ticket matches the
/// leader-committed SHA-256 digest. Comparison is constant-time with respect
/// to the digest contents and the plaintext is never stored or logged.
pub fn consume_admission_with_ticket<E: Engine>(
    txn: &mut MetaTxn<'_, E>,
    node_id: NodeId,
    expected_cluster: ClusterId,
    expected_addr: &str,
    ticket_sha256: &[u8],
    now_unix: u64,
) -> Result<Admission> {
    if ticket_sha256.len() != 32 {
        return Err(Error::Config(INVALID_JOIN_TICKET_MESSAGE.into()));
    }
    consume_admission_inner(
        txn,
        node_id,
        expected_cluster,
        expected_addr,
        Some(ticket_sha256),
        now_unix,
    )
}

fn consume_admission_inner<E: Engine>(
    txn: &mut MetaTxn<'_, E>,
    node_id: NodeId,
    expected_cluster: ClusterId,
    expected_addr: &str,
    ticket_sha256: Option<&[u8]>,
    now_unix: u64,
) -> Result<Admission> {
    // Three-way identity equality: LOCAL singleton == caller expectation ==
    // the row's own binding. Comparing only caller-vs-row would let an
    // admission row replayed into a DIFFERENT cluster's catalog be consumed
    // by anyone still presenting the original cluster id (Tess's review);
    // the local singleton is the ground truth this catalog actually belongs to.
    let local = cluster_id(txn)?.ok_or_else(|| {
        Error::Config("cannot consume an admission before cluster identity exists".into())
    })?;
    if local != expected_cluster {
        return Err(Error::Config(format!(
            "expected cluster does not match this catalog's identity (node {})",
            node_id.0
        )));
    }
    let adm = admission(txn, node_id)?
        .ok_or_else(|| Error::Config(format!("no admission record for node {}", node_id.0)))?;
    if adm.cluster_id != expected_cluster {
        return Err(Error::Config(format!(
            "admission for node {} binds a different cluster",
            node_id.0
        )));
    }
    // The admission binds (cluster, node, ADDRESS): consuming from an address
    // other than the admitted one is refused — knowing a public cluster id
    // and squatting an admitted node id must not be enough. (The registration
    // handler's authenticated NodeId is a separate, orthogonal gate.)
    let expected_addr: std::net::SocketAddr = expected_addr
        .parse()
        .map_err(|_| Error::Config("consume address must be a canonical socket address".into()))?;
    if adm.addr != expected_addr.to_string() {
        return Err(Error::Config(format!(
            "admission for node {} binds a different address",
            node_id.0
        )));
    }
    if adm.state != AdmissionState::Pending {
        return Err(Error::Config(format!(
            "admission for node {} is {:?}, not pending",
            node_id.0, adm.state
        )));
    }
    if let Some(presented) = ticket_sha256 {
        if !constant_time_eq(&adm.ticket_sha256, presented) {
            return Err(Error::Config(INVALID_JOIN_TICKET_MESSAGE.into()));
        }
    }
    if now_unix > adm.expires_unix {
        return Err(Error::Config(format!(
            "admission for node {} expired at {}",
            node_id.0, adm.expires_unix
        )));
    }
    let changes = vec![(NA_STATE, ColumnValue::Uint(AdmissionState::Consumed as u64))];
    txn.update(&NODE_ADMISSIONS_DESC, &[memcmp_uint(node_id.0)], changes)?;
    Ok(Admission {
        state: AdmissionState::Consumed,
        ..adm
    })
}

fn constant_time_eq(left: &[u8], right: &[u8]) -> bool {
    if left.len() != right.len() {
        return false;
    }
    left.iter()
        .zip(right)
        .fold(0u8, |difference, (a, b)| difference | (a ^ b))
        == 0
}

/// Revoke an admission (leader-committed): the operator's recovery path for an
/// expired, mistaken, or failed admission. Terminal for the record's current
/// life — but a revoked record MAY be replaced by a fresh [`admit_node`],
/// which is exactly what makes retry possible without ever reusing an
/// approval. Consumed records can also be revoked (e.g. decommission), which
/// permits later re-admission of the same node id.
pub fn revoke_admission<E: Engine>(txn: &mut MetaTxn<'_, E>, node_id: NodeId) -> Result<()> {
    let adm = admission(txn, node_id)?
        .ok_or_else(|| Error::Config(format!("no admission record for node {}", node_id.0)))?;
    if adm.state == AdmissionState::Revoked {
        return Err(Error::Config(format!(
            "admission for node {} is already revoked",
            node_id.0
        )));
    }
    let changes = vec![(NA_STATE, ColumnValue::Uint(AdmissionState::Revoked as u64))];
    txn.update(&NODE_ADMISSIONS_DESC, &[memcmp_uint(node_id.0)], changes)
}

/// Cancel an obsolete join credential in the same transaction as an endpoint
/// change. An explicit decommission verdict is stronger and is never lifted.
pub fn supersede_admission<E: Engine>(txn: &mut MetaTxn<'_, E>, node_id: NodeId) -> Result<()> {
    let adm = admission(txn, node_id)?
        .ok_or_else(|| Error::Config(format!("no admission record for node {}", node_id.0)))?;
    if matches!(
        adm.state,
        AdmissionState::Revoked | AdmissionState::Superseded
    ) {
        return Ok(());
    }
    txn.update(
        &NODE_ADMISSIONS_DESC,
        &[memcmp_uint(node_id.0)],
        vec![(
            NA_STATE,
            ColumnValue::Uint(AdmissionState::Superseded as u64),
        )],
    )
}

/// Read one admission record.
pub fn admission<E: Engine>(txn: &MetaTxn<'_, E>, node_id: NodeId) -> Result<Option<Admission>> {
    let Some(row) = txn.get(&NODE_ADMISSIONS_DESC, &[memcmp_uint(node_id.0)])? else {
        return Ok(None);
    };
    decode_admission(node_id, &row.value).map(Some)
}

/// All admissions still pending (the status surface's `pending_admissions`).
pub fn pending_admissions<E: Engine>(txn: &MetaTxn<'_, E>) -> Result<Vec<Admission>> {
    let rows = txn.scan(&NODE_ADMISSIONS_DESC, usize::MAX)?;
    let mut out = Vec::new();
    for row in rows {
        let pk = row
            .pk
            .first()
            .ok_or_else(|| Error::Config("admission row without pk".into()))?;
        let node_id = NodeId(decode_uint_component(pk)?);
        let adm = decode_admission(node_id, &row.value)?;
        if adm.state == AdmissionState::Pending {
            out.push(adm);
        }
    }
    Ok(out)
}

fn decode_admission(node_id: NodeId, row: &RowValue) -> Result<Admission> {
    let cluster_id = match row.get(NA_CLUSTER_ID) {
        Some(ColumnValue::Bytes(b)) => {
            let bytes: [u8; 16] = b.as_slice().try_into().map_err(|_| {
                Error::Config(format!(
                    "admission cluster_id must be 16 bytes, got {}",
                    b.len()
                ))
            })?;
            ClusterId::from_bytes(bytes)
        }
        _ => return Err(Error::Config("admission row missing cluster_id".into())),
    };
    let addr = match row.get(NA_ADDR) {
        Some(ColumnValue::Text(t)) => t.clone(),
        _ => return Err(Error::Config("admission row missing addr".into())),
    };
    let role = match row.get(NA_ROLE) {
        Some(ColumnValue::Uint(1)) => AdmittedRole::Learner,
        Some(ColumnValue::Uint(other)) => {
            return Err(Error::Config(format!(
                "unknown admission role code {other}"
            )))
        }
        _ => return Err(Error::Config("admission row missing role".into())),
    };
    let state = match row.get(NA_STATE) {
        Some(ColumnValue::Uint(code)) => AdmissionState::from_code(*code)?,
        _ => return Err(Error::Config("admission row missing state".into())),
    };
    let expires_unix = match row.get(NA_EXPIRES) {
        Some(ColumnValue::Uint(v)) => *v,
        _ => return Err(Error::Config("admission row missing expiry".into())),
    };
    Ok(Admission {
        node_id,
        cluster_id,
        addr,
        role,
        state,
        expires_unix,
        ticket_sha256: match row.get(NA_TICKET_SHA256) {
            Some(ColumnValue::Bytes(bytes)) if bytes.len() == 32 => bytes.clone(),
            _ => {
                return Err(Error::Config(
                    "node admission missing 32-byte join ticket digest".into(),
                ))
            }
        },
    })
}
