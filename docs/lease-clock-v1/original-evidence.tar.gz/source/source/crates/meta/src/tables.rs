//! Typed row structs + typed accessors/queries over [`MetaStore`] (METADATA-CATALOG §2, §4).
//!
//! These wrap the generic [`crate::store`] op API in table-specific types and the
//! **known joins** the scheduler/router need (METADATA-CATALOG §4), hand-written as
//! index-driven nested lookups. Respecting the corrected hierarchy:
//! **tenant → keyspace → txn group → timeline**, where `txn_groups.keyspace_id`
//! points *up* to `keyspaces` (a keyspace CONTAINS its txn groups; a `raw` keyspace has
//! none) — there is no duplicated "which group" field to drift.

use kv9_common::{ApiType, KeyspaceId, NodeId, RegionId, Result, TenantId, TimelineId, TxnGroupId};
use kv9_engine::Engine;

use crate::codec::{memcmp_uint, ColumnValue, RowValue};
use crate::schema::{self, ColumnId, IndexId};
use crate::store::{MetaStore, MetaTxn};

// ---------------------------------------------------------------------------
// Typed row structs (METADATA-CATALOG §2).
// ---------------------------------------------------------------------------

/// A `tenants` row (METADATA-CATALOG §2).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Tenant {
    pub id: TenantId,
    pub name: String,
    pub quota_tokens: u64,
    pub state: u32,
}

/// A `keyspaces` row (METADATA-CATALOG §2). `api_type` selects `txn`/`raw`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Keyspace {
    pub id: KeyspaceId,
    pub name: String,
    pub tenant_id: TenantId,
    pub api_type: ApiType,
    pub start_key: Vec<u8>,
    pub end_key: Vec<u8>,
    pub state: u32,
    pub config: Vec<u8>,
}

/// A `txn_groups` row (METADATA-CATALOG §2). `keyspace_id` points **up** to the owning
/// keyspace; groups merely subdivide a `txn` keyspace to shard its TSO. ONLY for
/// `api_type = txn`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TxnGroup {
    pub id: TxnGroupId,
    pub keyspace_id: KeyspaceId,
    pub name: String,
    pub sub_start: Vec<u8>,
    pub sub_end: Vec<u8>,
}

/// A `tso_timelines` row (METADATA-CATALOG §2). 1:1 with a txn group.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TsoTimeline {
    pub id: TimelineId,
    pub txn_group_id: TxnGroupId,
    pub provider_node: NodeId,
    pub window_hi: u64,
}

/// A `nodes` (membership) row (METADATA-CATALOG §2).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Node {
    pub id: NodeId,
    pub addr: String,
    pub state: u32,
    pub last_heartbeat: u64,
    pub capacity: Vec<u8>,
}

/// A `regions` row (METADATA-CATALOG §2).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Region {
    pub id: RegionId,
    pub keyspace_id: KeyspaceId,
    pub start_key: Vec<u8>,
    pub end_key: Vec<u8>,
    pub epoch_conf: u64,
    pub epoch_ver: u64,
    pub leader_node: NodeId,
}

/// A `region_peers` row (METADATA-CATALOG §2). PK is `(region_id, node_id)`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RegionPeer {
    pub region_id: RegionId,
    pub node_id: NodeId,
    pub role: u32,
}

/// An `sst_files` row — the catalog's **GC/billing view only** (agreed design ruling).
///
/// Which files a region holds is answered by that region's raft-replicated manifest,
/// the single authority for LSM structure; this row exists for object-storage GC
/// (`refcount` as a conservative upper bound: +ref commits *before* the manifest
/// change referencing a file, −ref only *after* the change dropping it) and for
/// per-tenant billing (`keyspace_id` is unique and stable even when a split shares a
/// file across regions, because regions never span keyspaces; `bytes` is written once
/// at creation).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SstFile {
    pub file_id: u64,
    pub keyspace_id: KeyspaceId,
    pub bytes: u64,
    pub refcount: u32,
    pub state: u32,
    pub created: u64,
}

// ---------------------------------------------------------------------------
// Row <-> RowValue conversions (a real impl would derive these). Phase-1 wires
// the two used on the CreateKeyspace path; the rest are declared for the team.
// ---------------------------------------------------------------------------

impl Keyspace {
    /// Encode into a tag-length [`RowValue`] (METADATA-CATALOG §3).
    pub fn to_row_value(&self) -> RowValue {
        let mut r = RowValue::new();
        r.set(ColumnId(1), ColumnValue::Uint(self.id.0 as u64));
        r.set(ColumnId(2), ColumnValue::Text(self.name.clone()));
        r.set(ColumnId(3), ColumnValue::Uint(self.tenant_id.0));
        r.set(ColumnId(4), ColumnValue::Uint(api_type_code(self.api_type)));
        r.set(ColumnId(5), ColumnValue::Bytes(self.start_key.clone()));
        r.set(ColumnId(6), ColumnValue::Bytes(self.end_key.clone()));
        r.set(ColumnId(7), ColumnValue::Uint(self.state as u64));
        r.set(ColumnId(8), ColumnValue::Bytes(self.config.clone()));
        r
    }

    /// The primary-key components for this keyspace (id).
    pub fn pk(&self) -> Vec<Vec<u8>> {
        vec![memcmp_uint(self.id.0 as u64)]
    }
}

impl TxnGroup {
    /// Encode into a tag-length [`RowValue`] (METADATA-CATALOG §3).
    pub fn to_row_value(&self) -> RowValue {
        let mut r = RowValue::new();
        r.set(ColumnId(1), ColumnValue::Uint(self.id.0));
        r.set(ColumnId(2), ColumnValue::Uint(self.keyspace_id.0 as u64));
        r.set(ColumnId(3), ColumnValue::Text(self.name.clone()));
        r.set(ColumnId(4), ColumnValue::Bytes(self.sub_start.clone()));
        r.set(ColumnId(5), ColumnValue::Bytes(self.sub_end.clone()));
        r
    }

    /// The primary-key components for this txn group (id).
    pub fn pk(&self) -> Vec<Vec<u8>> {
        vec![memcmp_uint(self.id.0)]
    }
}

/// Stable on-disk code for an [`ApiType`] (0 = txn, 1 = raw).
pub fn api_type_code(api: ApiType) -> u64 {
    match api {
        ApiType::Txn => 0,
        ApiType::Raw => 1,
    }
}

/// Inverse of [`api_type_code`].
pub fn api_type_from_code(code: u64) -> Result<ApiType> {
    match code {
        0 => Ok(ApiType::Txn),
        1 => Ok(ApiType::Raw),
        _ => Err(kv9_common::Error::MalformedKey(format!(
            "unknown catalog API type {code}"
        ))),
    }
}

// ---------------------------------------------------------------------------
// Typed queries + the known joins (METADATA-CATALOG §4). Signatures real;
// bodies are Phase-1 stubs pending the codec pk-decode helpers.
// ---------------------------------------------------------------------------

/// Typed catalog accessors bound to a [`MetaStore`] (METADATA-CATALOG §4, §8).
pub struct Tables<'a, E: Engine> {
    store: &'a MetaStore<E>,
}

impl<'a, E: Engine> Tables<'a, E> {
    pub fn new(store: &'a MetaStore<E>) -> Self {
        Tables { store }
    }

    /// Point get: a keyspace by id (METADATA-CATALOG §4).
    pub fn keyspace(&self, id: KeyspaceId) -> Result<Option<Keyspace>> {
        let txn = self.store.begin()?;
        Self::keyspace_in(&txn, id)
    }

    /// [`Self::keyspace`] against a CALLER-OWNED transaction — the txn-scoped
    /// twin of [`Self::region_for_key_in`]. A context gate that must judge
    /// keyspace + region + epoch together uses ONE `MetaTxn` for all three;
    /// letting `keyspace()` open its own view would let a commit land between
    /// the two reads and stitch a "validated" conclusion out of two moments
    /// (Ren's #25 region-gate seam; Tess's same-view ruling).
    pub fn keyspace_in(txn: &MetaTxn<'_, E>, id: KeyspaceId) -> Result<Option<Keyspace>> {
        let row = txn.get(&schema::KEYSPACES_DESC, &[memcmp_uint(id.0 as u64)])?;
        row.map(|r| decode_keyspace(id, &r.value)).transpose()
    }

    /// Join — *keyspaces of tenant T* → `index_scan(keyspaces, by_tenant, T)`
    /// (METADATA-CATALOG §4).
    pub fn keyspaces_of_tenant(&self, tenant: TenantId) -> Result<Vec<KeyspaceId>> {
        let txn = self.store.begin()?;
        let pks = txn.index_scan(
            &schema::KEYSPACES_DESC,
            IndexId(1), // by_tenant
            &[memcmp_uint(tenant.0)],
            usize::MAX,
        )?;
        pks.into_iter()
            .map(|pk| {
                let component = pk.first().ok_or_else(|| {
                    kv9_common::Error::MalformedKey("empty keyspace index primary key".into())
                })?;
                checked_keyspace(crate::codec::decode_uint_component(component)?)
            })
            .collect()
    }

    /// Join — *regions on node N* → `index_scan(region_peers, by_node, N)` →
    /// `get(regions, region_id)` (METADATA-CATALOG §4).
    pub fn regions_on_node(&self, node: NodeId) -> Result<Vec<Region>> {
        let txn = self.store.begin()?;
        let peer_pks = txn.index_scan(
            &schema::REGION_PEERS_DESC,
            IndexId(1), // by_node
            &[memcmp_uint(node.0)],
            usize::MAX,
        )?;
        let mut out = Vec::with_capacity(peer_pks.len());
        for pk in peer_pks {
            // region_peers pk = (region_id, node_id); the region id is the first comp.
            let Some(region_comp) = pk.first() else {
                continue;
            };
            let region_id = crate::codec::decode_uint_component(region_comp)?;
            if let Some(row) = txn.get(&schema::REGIONS_DESC, &[memcmp_uint(region_id)])? {
                out.push(decode_region(RegionId(region_id), &row.value)?);
            }
        }
        Ok(out)
    }

    /// Join — *which region owns key K in keyspace KS*: greatest `by_range` entry
    /// with `start_key ≤ K`, then the `end_key` check (METADATA-CATALOG §4).
    ///
    /// One reverse-merged index step ([`MetaTxn::index_rev_first_le`]) — O(1) result
    /// memory, no range materialization — then the row fetch and the `end_key` check,
    /// all inside one transaction view. The `by_range` key is `(keyspace_id,
    /// start_key)` prefix-encoded and the search is bounded below by the keyspace
    /// prefix, so it structurally cannot resolve into another keyspace; the `end_key`
    /// check still guards the gap case (K past the keyspace's last region): that
    /// returns `None`, never a neighbor — principle 4's tenant-isolation line.
    pub fn region_for_key(&self, keyspace: KeyspaceId, key: &[u8]) -> Result<Option<Region>> {
        let txn = self.store.begin()?;
        self.region_for_key_in(&txn, keyspace, key)
    }

    /// [`Self::region_for_key`] against a caller-supplied transaction, so routing
    /// sees that txn's own uncommitted regions (read-your-writes) and respects its
    /// deletes (a tombstoned best candidate falls back to the previous live one).
    pub fn region_for_key_in(
        &self,
        txn: &crate::store::MetaTxn<'_, E>,
        keyspace: KeyspaceId,
        key: &[u8],
    ) -> Result<Option<Region>> {
        let ks_comp = memcmp_uint(keyspace.0 as u64);
        let target = crate::codec::memcmp_bytes(key);
        let Some((suffix, _)) = txn.index_rev_first_le(
            &schema::REGIONS_DESC,
            IndexId(1), // by_range
            std::slice::from_ref(&ks_comp),
            &target,
        )?
        else {
            return Ok(None);
        };
        // Entry suffix = memcmp(keyspace_id) ++ memcmp(start_key) ++ memcmp(region_id).
        let rest = &suffix[ks_comp.len()..];
        let comps = crate::codec::split_components(
            &[
                crate::schema::ColumnType::Bytes,
                crate::schema::ColumnType::Uint,
            ],
            rest,
            true,
        )?;
        let region_id = crate::codec::decode_uint_component(&comps[1])?;
        let Some(row) = txn.get(&schema::REGIONS_DESC, &[memcmp_uint(region_id)])? else {
            return Ok(None);
        };
        let region = decode_region(RegionId(region_id), &row.value)?;
        if region.keyspace_id != keyspace
            || crate::codec::memcmp_bytes(&region.start_key) != comps[0]
            || key < region.start_key.as_slice()
        {
            return Err(kv9_common::Error::MalformedKey(
                "region row disagrees with routing index".into(),
            ));
        }
        // end_key check: empty end_key = unbounded (to the keyspace's end).
        if region.end_key.is_empty() || key < region.end_key.as_slice() {
            Ok(Some(region))
        } else {
            Ok(None)
        }
    }

    /// Point get — *region by id*, against a CALLER-OWNED transaction (the
    /// txn-scoped shape of [`Self::keyspace_in`]).
    ///
    /// Built for the task #48 fence adjudicator, which holds a `RegionFence`
    /// (id + expected epoch, no key) and must read the authoritative epoch
    /// from the SAME snapshot as the apply it serves — opening its own view
    /// here would let a commit land between the epoch read and the apply and
    /// stitch a verdict out of two moments. `Ok(None)` means the catalog
    /// authoritatively has no such region (a log fact — e.g. consumed by a
    /// split — which the adjudicator maps to a deterministic `Ok(false)`
    /// rejection); `Err` is the read itself failing (a local fact → apply
    /// error). Decoding stays HERE so exactly one region decoder exists —
    /// a server-side copy would drift, and drift here reads a wrong epoch,
    /// which is a wrong verdict, which is replica divergence.
    pub fn region_by_id_in(txn: &MetaTxn<'_, E>, id: RegionId) -> Result<Option<Region>> {
        let Some(row) = txn.get(&schema::REGIONS_DESC, &[memcmp_uint(id.0)])? else {
            return Ok(None);
        };
        Ok(Some(decode_region(id, &row.value)?))
    }

    /// Join — *txn group for key K in keyspace KS* → `index_scan(txn_groups,
    /// by_keyspace, KS)`, pick the sub-range ∋ K (METADATA-CATALOG §4).
    ///
    /// A `raw` keyspace has no groups (returns `None`); the default single group has
    /// empty `sub_start`/`sub_end` = the whole keyspace.
    pub fn txn_group_for_key(
        &self,
        keyspace: KeyspaceId,
        key: &[u8],
    ) -> Result<Option<TxnGroupId>> {
        let txn = self.store.begin()?;
        let group_pks = txn.index_scan(
            &schema::TXN_GROUPS_DESC,
            IndexId(1), // by_keyspace
            &[memcmp_uint(keyspace.0 as u64)],
            usize::MAX,
        )?;
        for pk in group_pks {
            let Some(id_comp) = pk.first() else { continue };
            let group_id = crate::codec::decode_uint_component(id_comp)?;
            let Some(row) = txn.get(&schema::TXN_GROUPS_DESC, &[memcmp_uint(group_id)])? else {
                continue;
            };
            let sub_start = bytes_or(&row.value, ColumnId(4));
            let sub_end = bytes_or(&row.value, ColumnId(5));
            let ge_start = sub_start.is_empty() || key >= sub_start.as_slice();
            let lt_end = sub_end.is_empty() || key < sub_end.as_slice();
            if ge_start && lt_end {
                return Ok(Some(TxnGroupId(group_id)));
            }
        }
        Ok(None)
    }
}

/// Decode a `regions` [`RowValue`] into the typed [`Region`] (METADATA-CATALOG §3).
fn decode_region(id: RegionId, v: &RowValue) -> Result<Region> {
    Ok(Region {
        id,
        keyspace_id: checked_keyspace(required_uint(v, ColumnId(2))?)?,
        start_key: required_bytes(v, ColumnId(3))?,
        end_key: required_bytes(v, ColumnId(4))?,
        epoch_conf: required_uint(v, ColumnId(5))?,
        epoch_ver: required_uint(v, ColumnId(6))?,
        leader_node: NodeId(required_uint(v, ColumnId(7))?),
    })
}

fn decode_keyspace(id: KeyspaceId, v: &RowValue) -> Result<Keyspace> {
    checked_keyspace(id.0 as u64)?;
    Ok(Keyspace {
        id,
        name: text_or(v, ColumnId(2)),
        tenant_id: TenantId(required_uint(v, ColumnId(3))?),
        api_type: api_type_from_code(required_uint(v, ColumnId(4))?)?,
        start_key: required_bytes(v, ColumnId(5))?,
        end_key: required_bytes(v, ColumnId(6))?,
        state: u32::try_from(uint_or(v, ColumnId(7)))
            .map_err(|_| kv9_common::Error::MalformedKey("keyspace state exceeds u32".into()))?,
        config: bytes_or(v, ColumnId(8)),
    })
}
fn checked_keyspace(id: u64) -> Result<KeyspaceId> {
    if id > kv9_common::KeyspaceId::MAX as u64 {
        return Err(kv9_common::Error::MalformedKey(
            "catalog keyspace id exceeds encoded namespace".into(),
        ));
    }
    Ok(KeyspaceId(id as u32))
}
fn required_uint(v: &RowValue, c: ColumnId) -> Result<u64> {
    match v.get(c) {
        Some(ColumnValue::Uint(n)) => Ok(*n),
        _ => Err(kv9_common::Error::MalformedKey(format!(
            "required catalog uint {} missing or mistyped",
            c.0
        ))),
    }
}
fn required_bytes(v: &RowValue, c: ColumnId) -> Result<Vec<u8>> {
    match v.get(c) {
        Some(ColumnValue::Bytes(bytes)) => Ok(bytes.clone()),
        _ => Err(kv9_common::Error::MalformedKey(format!(
            "required catalog bytes {} missing or mistyped",
            c.0
        ))),
    }
}

fn uint_or(v: &RowValue, c: ColumnId) -> u64 {
    match v.get(c) {
        Some(ColumnValue::Uint(u)) => *u,
        _ => 0,
    }
}
fn text_or(v: &RowValue, c: ColumnId) -> String {
    match v.get(c) {
        Some(ColumnValue::Text(s)) => s.clone(),
        _ => String::new(),
    }
}
fn bytes_or(v: &RowValue, c: ColumnId) -> Vec<u8> {
    match v.get(c) {
        Some(ColumnValue::Bytes(b)) => b.clone(),
        _ => Vec::new(),
    }
}
