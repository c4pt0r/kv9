"""Cold-preserve exactly one authorized, terminal restored test executable."""
import gzip,hashlib,json,os,stat,subprocess,sys,time,traceback
from pathlib import Path
OUT=Path('/tmp/kv9-lease-renewal-cold-supplement-first')
FIRST=Path('/tmp/kv9-segment-publication-controls-first/reusable-failed-checkpoint/restored-build/segment_publication_probe')
CONTROL=Path('/tmp/kv9-segment-publication-controls-first')
CAP=4*1024**3;FLOOR=80*1024**3;CHUNK=1024**2
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def save(name,obj):
    with (OUT/name).open('x')as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def ident(p):
    s=p.lstat()
    return dict(dev=s.st_dev,ino=s.st_ino,bytes=s.st_size,allocated_bytes=s.st_blocks*512,mode=s.st_mode,
        uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def guard(extra=0):
    v=os.statvfs(OUT);free=v.f_bavail*v.f_frsize;allocation=sum(p.stat().st_blocks*512 for p in OUT.iterdir()if p.is_file())
    require(free-extra>=FLOOR,'80 GiB floor reached');require(allocation+extra<=CAP,'4 GiB archive/preparation cap reached')
    return dict(free_bytes=free,owned_allocated_bytes=allocation,observed_ns=time.time_ns())
def sha(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        while b:=f.read(CHUNK):guard();h.update(b)
    return h.hexdigest()
def ownership(phase):
    subprocess.run([sys.executable,str(OUT/f'check-use-{phase}.py')],check=True)
    row=json.loads((OUT/f'use-{phase}.json').read_text())
    require(row['complete']and not row['hits']and not row['errors']and row['no_selected_inode_alias'],'ambiguous/live/selected reference; no unlink permitted')
class Writer:
    def __init__(self,f):self.f=f
    def write(self,b):guard(len(b)+CHUNK);return self.f.write(b)
    def flush(self):self.f.flush()
def main():
    require(os.geteuid()==0 and set(os.sched_getaffinity(0))<={6,7},'root /proc visibility and helper CPUs6-7 required')
    before=guard();census=json.loads((OUT/'census-first.json').read_text());rows=census['files']
    selected=[FIRST]
    require(len(selected)==1 and list(map(str,selected))==[r['path']for r in rows],'exact one-file selection differs')
    protected={};catalog=[]
    for path,row in zip(selected,rows):
        original=ident(path);require(all(original[k]==v for k,v in row.items()if k!='path'),'census identity differs')
        require(path.resolve()==path and stat.S_ISREG(original['mode'])and original['uid']==1000 and original['nlink']==1,'source executable ownership/path differs')
        result=json.loads((CONTROL/'report.json').read_text())
        require(result['complete'] and all(c['detected'] and c['restored'] for c in result['controls']),'historical control receipt changed')
        binding=json.loads((OUT/'source-binding-first.json').read_text())
        require(binding['path']==str(path) and binding['bytes']==original['bytes'],'bound restored artifact differs')
        require(sha(CONTROL/'report.json')==binding['report_sha256'],'historical report changed')
        expected=binding['sha256']
        for receipt in binding['original_receipts']:
            p=Path(receipt['path']); require(sha(p)==receipt['sha256'],'historical command receipt changed')
            command=json.loads(p.read_text());require(command['exit']==0,'historical build/use did not exit successfully')
            if p.parent!=path.parent:require(command['argv'][0]==str(path),'historical use referenced another executable')
            protected[str(p)]=dict(path=str(p),identity=ident(p),sha256=sha(p))
        for rel,wanted in {(c['source'],c['original_sha256'])for c in result['controls']}:
            p=CONTROL/'source'/rel;require(sha(p)==wanted,'restored historical source hash differs')
            protected[str(p)]=dict(path=str(p),identity=ident(p),sha256=sha(p))
        for rel in ['crates/engine/examples/segment_publication_probe.rs','Cargo.toml','Cargo.lock','crates/engine/Cargo.toml','rust-toolchain.toml','scripts/check-segment-publication-controls.py','scripts/check-segment-publication.py']:
            p=CONTROL/'source'/rel;require(p.is_file() and not p.is_symlink() and p.stat().st_size<2*CHUNK,'historical source input invalid')
            protected[str(p)]=dict(path=str(p),identity=ident(p),sha256=sha(p))
        for p in [CONTROL/'reusable-failed-checkpoint/original.rs',CONTROL/'reusable-failed-checkpoint/mutant.rs',CONTROL/'reusable-failed-checkpoint/mutant-diagnostic.txt']:
            protected[str(p)]=dict(path=str(p),identity=ident(p),sha256=sha(p))
        require(len(expected)==64,'binary receipt hash missing')
        catalog.append(dict(original_path=str(path),identity=original,original_sha256=expected,original_result=result))
        for neighbor in sorted(path.parent.rglob('*')):
            if neighbor==path:continue
            require(not neighbor.is_symlink(),'linked protected neighbor')
            if neighbor.is_dir():continue
            require(neighbor.is_file()and neighbor.stat().st_size<2*CHUNK,'unexpected protected evidence type/size')
            protected[str(neighbor)]=dict(path=str(neighbor),identity=ident(neighbor),sha256=sha(neighbor))
    summary=CONTROL/'report.json';protected[str(summary)]=dict(path=str(summary),identity=ident(summary),sha256=sha(summary))
    save('invocation-first.json',dict(argv=sys.argv,pid=os.getpid(),started_ns=time.time_ns(),script_sha256=sha(Path(__file__)),
        original_selection=catalog,protected=list(protected.values()),before=before,min_free_bytes=FLOOR,max_archive_storage_bytes=CAP,cpu_affinity=sorted(os.sched_getaffinity(0))))
    ownership('before-archive')
    for index,row in enumerate(catalog):
        source=Path(row['original_path']);archive=OUT/f'executable-{index:02d}.gz';h=hashlib.sha256();count=0
        with source.open('rb')as src,archive.open('xb')as raw:
            with gzip.GzipFile(filename='',mode='wb',compresslevel=1,mtime=0,fileobj=Writer(raw))as gz:
                while b:=src.read(CHUNK):guard();h.update(b);count+=len(b);gz.write(b)
            raw.flush();os.fsync(raw.fileno())
        require(count==row['identity']['bytes']and h.hexdigest()==row['original_sha256']and ident(source)==row['identity'],'source build bytes/identity differ')
        h=hashlib.sha256();count=0
        with gzip.open(archive,'rb')as decoded:
            while b:=decoded.read(CHUNK):
                guard();h.update(b);count+=len(b);require(count<=row['identity']['bytes'],'decoded byte bound exceeded')
        require(count==row['identity']['bytes']and h.hexdigest()==row['original_sha256'],'exact independent decoded identity differs')
        row['archive']=dict(path=str(archive),bytes=archive.stat().st_size,allocated_bytes=archive.stat().st_blocks*512,sha256=sha(archive))
        row['decoded_bytes']=count;row['decoded_sha256']=h.hexdigest();row['gzip_consumed_to_eof']=True
        save(f'verified-{index:02d}.json',dict(complete=True,**row))
    for row in catalog:
        source=Path(row['original_path']);require(ident(source)==row['identity']and sha(source)==row['original_sha256'],'source changed before eviction')
        require(sha(Path(row['archive']['path']))==row['archive']['sha256'],'archive changed before eviction')
    for row in protected.values():require(ident(Path(row['path']))==row['identity']and sha(Path(row['path']))==row['sha256'],'protected source/log/result changed')
    ownership('before-eviction')
    save('eviction-authority.json',dict(complete=True,all_archives_decoded=True,all_originals_rehashed=True,catalog=catalog,
        protected_evidence_unchanged=True,guard=guard()))
    with (OUT/'eviction-first.jsonl').open('x')as log:
        for row in catalog:
            source=Path(row['original_path']);require(ident(source)==row['identity'],'source changed at unlink boundary');guard();source.unlink()
            log.write(json.dumps(dict(original_path=str(source),identity=row['identity'],unlinked_ns=time.time_ns()))+'\n');log.flush()
        os.fsync(log.fileno())
    for row in protected.values():require(ident(Path(row['path']))==row['identity']and sha(Path(row['path']))==row['sha256'],'protected evidence changed after eviction')
    after=guard();save('result-first.json',dict(complete=True,exit_code=0,ended_ns=time.time_ns(),files_evicted=len(catalog),catalog=catalog,
        original_bytes=sum(r['identity']['bytes']for r in catalog),original_allocated_bytes=sum(r['identity']['allocated_bytes']for r in catalog),
        archive_bytes=sum(r['archive']['bytes']for r in catalog),archive_allocated_bytes=sum(r['archive']['allocated_bytes']for r in catalog),
        payload_allocation_saving=sum(r['identity']['allocated_bytes']-r['archive']['allocated_bytes']for r in catalog),
        before=before,after=after,observed_free_delta_bytes=after['free_bytes']-before['free_bytes'],required96GiB_met=after['free_bytes']>=96*1024**3,
        all_selected_sources_absent=all(not p.exists()for p in selected),protected_evidence_unchanged=True,
        scope='One retained restored test probe only; historical control and first mutation failure outcomes preserved, no compiler/test run or new correctness verdict. Free delta can include unrelated activity.'))
    print(json.dumps(dict(complete=True,files=len(catalog),free_bytes=after['free_bytes'])),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException as error:
        save('first-failure.json',dict(complete=False,error=repr(error),traceback=traceback.format_exc(),observed_ns=time.time_ns()));raise
