# Retained test-executable cold preservation

Completed once, exit 0, terminal receipt `db1818`. Direct tool completion; no numeric session.

Original allocation 90,370,048 bytes; archived allocation 29,966,336 bytes; payload allocation saving 60,403,712 bytes. Observed filesystem free-space increase 60,354,560 bytes to 103,115,395,072. The observed free-space delta can include concurrent unrelated activity.

Both privileged executable/file-descriptor/mapping censuses were clear (632 and 632 processes). Each source had one link, original UID 1000, and no selected-runtime inode alias. Only the listed executable files were unlinked; source/log/result identities and bytes were checked unchanged. CPUs 6–7, 4 GiB archive cap and 80 GiB free floor remained enforced. This operation provides no new test or correctness result.

The result catalog retains exact original path, identity, mode, UID/GID, modification time, bytes and SHA-256, plus compressed and decoded identities. Every gzip was consumed to EOF independently and the original source and compressed object were rehashed before unlink. Inode/ctime are historical evidence, not restorable identity.

The historical restored probe has original successful build and three successful use receipts, and its control report records restoration. Its per-binary SHA was measured for this conversion; it is not relabeled as an original build receipt. All initial mutant failure evidence remains unchanged.

| Index | Original path | Decoded bytes | Decoded SHA-256 | Archive | Compressed bytes | Compressed SHA-256 |
| --- | --- | ---: | --- | --- | ---: | --- |
| 0 | `/tmp/kv9-segment-publication-controls-first/reusable-failed-checkpoint/restored-build/segment_publication_probe` | 90365312 | `7e97a5daa2a0e22af9b6f44749c926b0a45779d60f68ee965d34c4f128f65cc3` | `executable-00.gz` | 29964611 | `8f60aa53b43b3a3a043df6a43925ca5b307c3e0ae8761bd11f7e63610efb6f42` |

## Restore one original path

Use `/tmp/kv9-lease-renewal-cold-supplement-first/result-first.json` and select the catalog index above. Restoration has not been executed. Keep the gzip and all records retained.

1. Ensure the target parent is the original ordinary directory with no symlink components; the target itself must be absent. Stop on a conflicting path. Reserve the full decoded byte count plus the unchanged 80 GiB free floor. Run bounded streaming work on CPUs 6–7.
2. Verify the compressed object byte count and SHA-256 against `catalog[index].archive` before decoding. Create a fresh exclusive temporary regular file in the original parent directory. Do not overwrite any existing file.
3. Stream gzip decoding to the temporary file, rejecting output beyond `identity.bytes`. Reach gzip EOF successfully, fsync the temporary file, and verify exact decoded byte count and SHA-256 against `decoded_bytes` and `decoded_sha256`. On any failure retain the temporary file and error record; do not install it.
4. Restore `identity.uid`, `identity.gid`, permission bits `identity.mode & 0o7777`, and `identity.mtime_ns` to the verified temporary file. Recheck the original path is absent. Use a no-overwrite hard link from the verified temporary file to the original path, then remove only the temporary link and fsync the parent directory. A concurrent destination creation must fail rather than overwrite.
5. Verify the installed original bytes/hash, permission/ownership/mtime and one-link status. Save a fresh restore receipt that binds this catalog and the current compressed object; do not rewrite the original source/test result or the cold-conversion receipt.

No test or executable invocation is part of restoring bytes. No server, client, Cargo target, previous cold object, repository file or original data/WAL payload was changed.
