# Retained test-executable cold preservation

Completed once, exit 0, terminal receipt `ea7d09`. Yielded session `55546`.

Original allocation 242,638,848 bytes; archived allocation 75,747,328 bytes; payload allocation saving 166,891,520 bytes. Observed filesystem free-space increase 166,825,984 bytes to 103,097,561,088. The observed free-space delta can include concurrent unrelated activity.

Both privileged executable/file-descriptor/mapping censuses were clear (633 and 633 processes). Each source had one link, original UID 1000, and no selected-runtime inode alias. Only the listed executable files were unlinked; source/log/result identities and bytes were checked unchanged. CPUs 6–7, 4 GiB archive cap and 80 GiB free floor remained enforced. This operation provides no new test or correctness result.

The result catalog retains exact original path, identity, mode, UID/GID, modification time, bytes and SHA-256, plus compressed and decoded identities. Every gzip was consumed to EOF independently and the original source and compressed object were rehashed before unlink. Inode/ctime are historical evidence, not restorable identity.

The new lease gate remains failed/incomplete exactly as recorded in its original result. Its compile succeeded, but its election fixture failed; this maintenance does not alter that outcome. The older baseline probe retains its completed six-control report.

| Index | Original path | Decoded bytes | Decoded SHA-256 | Archive | Compressed bytes | Compressed SHA-256 |
| --- | --- | ---: | --- | --- | ---: | --- |
| 0 | `/tmp/kv9-lease-renewal-repaired-source-first/raft-tests` | 152263376 | `bfed275b87424cd0d1762f4f09e59ff8f7f77a20e9dfc9ccb451108f9f821269` | `executable-00.gz` | 45769751 | `a00e1b281f820b8a7a55500de01a425ad50bfa2bcb422e55979cb9e3cd2a37ba` |
| 1 | `/tmp/kv9-segment-publication-controls-first/baseline-build/segment_publication_probe` | 90365096 | `aa929259b9c83a74d646939991b8de889dacf1735dc50d2622ee50bbad0dff26` | `executable-01.gz` | 29965478 | `eff7be30d941268888a53c3a08c4761cbe90e526c9eb770fac9aad4871f11061` |

## Restore one original path

Use `/tmp/kv9-lease-renewal-cold-first/result-first.json` and select the catalog index above. Restoration has not been executed. Keep the gzip and all records retained.

1. Ensure the target parent is the original ordinary directory with no symlink components; the target itself must be absent. Stop on a conflicting path. Reserve the full decoded byte count plus the unchanged 80 GiB free floor. Run bounded streaming work on CPUs 6–7.
2. Verify the compressed object byte count and SHA-256 against `catalog[index].archive` before decoding. Create a fresh exclusive temporary regular file in the original parent directory. Do not overwrite any existing file.
3. Stream gzip decoding to the temporary file, rejecting output beyond `identity.bytes`. Reach gzip EOF successfully, fsync the temporary file, and verify exact decoded byte count and SHA-256 against `decoded_bytes` and `decoded_sha256`. On any failure retain the temporary file and error record; do not install it.
4. Restore `identity.uid`, `identity.gid`, permission bits `identity.mode & 0o7777`, and `identity.mtime_ns` to the verified temporary file. Recheck the original path is absent. Use a no-overwrite hard link from the verified temporary file to the original path, then remove only the temporary link and fsync the parent directory. A concurrent destination creation must fail rather than overwrite.
5. Verify the installed original bytes/hash, permission/ownership/mtime and one-link status. Save a fresh restore receipt that binds this catalog and the current compressed object; do not rewrite the original source/test result or the cold-conversion receipt.

No test or executable invocation is part of restoring bytes. No server, client, Cargo target, previous cold object, repository file or original data/WAL payload was changed.
