from pathlib import Path
import gzip, hashlib, io, json, shutil, tarfile

repo = Path('/home/dongxu/kv9')
work = Path(__file__).resolve().parent
cargo = Path('/tmp/kv9-lease-renewal-election-clock-source-first')
control = Path('/tmp/kv9-lease-renewal-controls-first')
out = repo / 'docs/lease-renewal-publication-v1'
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
source_result = read(cargo / 'result.json')
controls = read(control / 'result.json')
assert source_result['complete'] and all(r['exit_code'] == 0 for r in source_result['commands'])
assert source_result['commands'][2]['test_result'] == ['231', '0', '0']
assert controls['complete'] and len(controls['controls']) == 8
assert all(c['expected_failure_observed'] for c in controls['controls'])
assert all(c['exit_code'] == c['expected_exit_code'] for c in controls['commands'])
before = read(cargo / 'sources-before.json')
assert before == read(cargo / 'sources-after.json')
for name, digest in before['sources'].items():
    if name.endswith(('.rs', '.toml', '.lock')) and digest is not None:
        assert sha((repo / name).read_bytes()) == digest, name
for name, digest in read(control / 'source-inputs.json').items():
    assert sha((repo / name).read_bytes()) == digest, name
    assert sha((control / 'source' / name).read_bytes()) == digest, name
assert read(cargo/'result.json')['commands'][1]['test_binary_sha256'] == '0da7be3c916b5d3f18f018ed8b15d1f307c9e3372c3ef977d9c8a03f26ee450f'
for root in ['/tmp/kv9-lease-renewal-election-clock-root-first', '/tmp/kv9-lease-renewal-controls-root-first']:
    r = read(Path(root) / 'source-result.json')
    assert r['complete'] and r['exit_code'] == 0
    assert r['initial_available_bytes'] >= 96 * 1024**3
    assert min(s['available_bytes'] for s in r['samples']) >= 80 * 1024**3
    assert r['initial_available_bytes'] - min(s['available_bytes'] for s in r['samples']) <= 16 * 1024**3
for root in ['/tmp/kv9-lease-renewal-root-first', '/tmp/kv9-lease-renewal-repaired-root-first']:
    r = read(Path(root) / 'source-result.json')
    assert not r['complete'] and r['exit_code'] == 1
first = Path('/tmp/kv9-lease-renewal-source-first')
second = Path('/tmp/kv9-lease-renewal-repaired-source-first')
assert 'could not find `NodeDriver`' in (first/'default-compile.stderr').read_text()
assert '230 passed; 1 failed; 0 ignored' in (second/'default-tests.stdout').read_text()
assert not read(first/'result.json')['complete'] and not read(second/'result.json')['complete']

files = {}
def add(name, path):
    assert path.is_file() and not path.is_symlink() and name not in files, name
    data = path.read_bytes()
    assert len(data) <= 2 * 1024**2, name
    files[name] = data
def tree(directory, prefix, skip=()):
    assert directory.is_dir(), directory
    for path in directory.rglob('*'):
        relative = path.relative_to(directory)
        if any(part in skip for part in relative.parts): continue
        if path.is_file(): add(prefix + '/' + str(relative), path)
for name in ['crates/raft/src/lib.rs', 'crates/raft/src/driver.rs',
             'crates/raft/src/rawnode.rs', 'crates/raft/src/lease.rs',
             'crates/raft/src/lease/tests.rs', 'crates/raft/src/rawnode/lease_wire.rs',
             'crates/raft/src/rawnode/lease_gate.rs', 'crates/raft/src/rawnode/lease_gate/tests.rs',
             'crates/raft/tests/lease_restart.rs', 'scripts/check-lease-renewal.py',
             'scripts/build_cache.py', 'scripts/build-workload.py']:
    add('source/' + name, repo/name)
tree(cargo, 'cargo', {'raft-tests.gz'})
tree(control, 'controls', {'source'})
tree(first, 'first-source', {'raft-tests', 'raft-tests.gz'})
tree(second, 'second-source', {'raft-tests', 'raft-tests.gz'})
for name in ['root-first', 'repaired-root-first', 'election-clock-root-first', 'controls-root-first']:
    tree(Path('/tmp/kv9-lease-renewal-' + name), 'supervisors/' + name)
for name in ['cache-first', 'repaired-cache-first', 'election-clock-cache-first', 'controls-cache-first']:
    tree(Path('/tmp/kv9-lease-renewal-' + name), 'cache-maintenance/' + name)
for directory in read(work/'cold-directories.json'):
    base = Path(directory)
    for path in base.iterdir():
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.md', '.py'}:
            add('cold-executables/' + base.name + '/' + path.name, path)
add('publication/publish.py', work/'publish.py')
add('publication/cold-directories.json', work/'cold-directories.json')

out.mkdir()
archive = out / 'original-evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|') as tar:
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name); entry.size = len(data); entry.mode = 0o644
            tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files) and {m.name for m in members} == set(files)
    for member in members:
        assert member.isfile() and tar.extractfile(member).read() == files[member.name]
inventory = {'archive': archive.name, 'archive_bytes': archive.stat().st_size,
    'archive_sha256': sha(archive.read_bytes()), 'files': len(files),
    'members': [{'name': n, 'bytes': len(d), 'sha256': sha(d)} for n,d in sorted(files.items())],
    'scope': 'Actual source, Cargo outputs, eight fault controls, first compile/fixture failures and maintenance metadata. Full duplicate workspace and compressed executable payloads excluded.'}
(out/'inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
shutil.copyfile(cargo/'result.json', out/'source-summary.json')
shutil.copyfile(control/'result.json', out/'controls-summary.json')
total = sum(p.stat().st_size for p in (repo/'docs').rglob('original-evidence.tar.gz'))
assert total < 64 * 1024**2, total
receipt = {k:v for k,v in inventory.items() if k != 'members'}
receipt['aggregate_archive_bytes'] = total
(work/'readback.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
