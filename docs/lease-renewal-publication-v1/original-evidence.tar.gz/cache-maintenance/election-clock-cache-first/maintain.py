import importlib.util, json, os, time
from pathlib import Path
root=Path('/home/dongxu/kv9');out=Path('/tmp/kv9-lease-renewal-election-clock-cache-first')
os.environ.update(CARGO_TARGET_DIR=str(root/'target'), CARGO_BUILD_JOBS='4', CARGO_NET_OFFLINE='true')
def free():
 s=os.statvfs(root);return s.f_bavail*s.f_frsize
r={'complete':False,'purpose':'Locked first-party debug cache invalidation only; no compilation or retained evidence removal','before_available_bytes':free(),'started_ns':time.time_ns()}
if free()<80*1024**3: raise RuntimeError('maintenance free floor violated')
spec=importlib.util.spec_from_file_location('builder',root/'scripts/build-workload.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
try:
 with b.cache.BuildCache(root,out,False,b.snapshot()): pass
 r.update(complete=True,after_available_bytes=free())
 if free()<80*1024**3: raise RuntimeError('maintenance free floor violated')
finally:
 r['ended_ns']=time.time_ns();(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
