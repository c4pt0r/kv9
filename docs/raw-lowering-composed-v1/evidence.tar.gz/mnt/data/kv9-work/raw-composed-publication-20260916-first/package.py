#!/usr/bin/env python3
import gzip,hashlib,io,json,re,shutil,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Q.with_name('raw-lowering-composed-20260916-first');O=Q/'packet'
assert not O.exists();assert json.loads((R/'analysis.json').read_text())['complete']
CAP=8*1024**2;TOTAL=80*1024**2;contents={};rows={}
secret=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def add(p):
 assert p.is_file() and not p.is_symlink() and p.stat().st_size<=CAP
 b=p.read_bytes();assert not secret.search(b)
 name=str(p).lstrip('/');contents[name]=b;rows[name]=dict(member=name,source=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for p in sorted(R.rglob('*')):
 if p.is_file() and p.suffix in ('.json','.jsonl','.rs','.py','.toml','.lock','.stdout','.stderr','.log','.md'):add(p)
inputs=json.loads((R/'analysis-inputs.json').read_text());included=0
for path,expected in inputs.items():
 p=Path(path)
 if p.suffix=='.bin':continue
 assert pin(p)==expected;add(p);included+=1
for name in ('terminals.json','package.py','verify.py'):add(Q/name)
assert len(rows)<512 and sum(r['bytes'] for r in rows.values())<=TOTAL
manifest=dict(scope='Original composed experiment source and metadata. Exact large group/Raft inputs and executable remain local; no standalone runtime or full-source replay.',original_files=len(rows),original_bytes=sum(r['bytes']for r in rows.values()),member_cap_bytes=CAP,total_cap_bytes=TOTAL,compressed_cap_bytes=32*1024**2,decoded_tar_cap_bytes=TOTAL,report_inputs_included=included,members=[rows[n]for n in sorted(rows)])
blob=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();contents['members.json']=blob
O.mkdir();(O/'members.json').write_bytes(blob)
with (O/'evidence.tar.gz').open('xb') as target:
 with gzip.GzipFile(filename='',fileobj=target,mode='wb',compresslevel=6,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as archive:
   for name,b in sorted(contents.items()):
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(b))
assert (O/'evidence.tar.gz').stat().st_size<=32*1024**2
for row in rows.values():assert pin(Path(row['source']))=={k:row[k]for k in ('bytes','sha256')}
for source,name in ((R/'analysis.json','analysis.json'),(R/'bench/src/main.rs','composed.rs'),(R/'analyze.py','analyze-original.py'),(Q/'terminals.json','terminals.json'),(Q/'verify.py','verify.py')):shutil.copyfile(source,O/name)
result=dict(complete=True,original_files=len(rows),original_bytes=manifest['original_bytes'],archive_members=len(contents),report_inputs_included=included,archive=pin(O/'evidence.tar.gz'),members=pin(O/'members.json'))
(O/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
