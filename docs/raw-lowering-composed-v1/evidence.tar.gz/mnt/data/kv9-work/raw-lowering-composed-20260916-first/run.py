#!/usr/bin/env python3
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/'runs-first';O.mkdir(exist_ok=False)
build=json.loads((R/'build-corrected/result.json').read_text());assert build['complete']
pin=build['artifacts']['timing'];assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
assert hashlib.sha256((R/'plan.json').read_bytes()).hexdigest()=='a8e89abb31a105a66d4ec64c62bd9451761a1dd99312d21036d313c3d1cd88bc'
free={p:shutil.disk_usage(p).free for p in ['/home/dongxu/kv9','/mnt/data']};assert min(free.values())>=8*1024**3
argv=['sudo','-n','taskset','-c','4',pin['path'],str(R),str(O/'timing.json')]
record=dict(complete=False,argv=argv,started_ns=time.time_ns(),binary_sha256=pin['sha256'],free_bytes=free,cpu=4,shared_host=True,cpu_thread_siblings=Path('/sys/devices/system/cpu/cpu4/topology/thread_siblings_list').read_text().strip(),loadavg=Path('/proc/loadavg').read_text().strip())
with (O/'timing.stdout').open('x') as out,(O/'timing.stderr').open('x') as err:
 p=subprocess.Popen(argv,stdout=out,stderr=err);record['pid']=p.pid;(O/'timing-launch.json').write_text(json.dumps(record,indent=2)+'\n')
 try:
  record['exit_code']=p.wait(timeout=900)
  if record['exit_code']==0:
   data=(O/'timing.json').read_bytes();assert len(data)<=8*1024**2
   result=json.loads(data);assert result['complete'] and len(result['rows'])==24 and len(result['correctness'])==6
   assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256'];record.update(complete=True,result_bytes=len(data),result_sha256=hashlib.sha256(data).hexdigest())
 finally:
  record['ended_ns']=time.time_ns();(O/'timing-terminal.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['complete'],record
print(json.dumps(record))
