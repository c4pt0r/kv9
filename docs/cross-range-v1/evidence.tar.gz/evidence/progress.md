# cross-range increment (D02) — progress

Baseline bd91d67. Task #26. IMPLEMENTED (compiles, binary current):
- RuntimeBackend::raw_scan_paged_inner: chunked walk over unsealed
  partition (get_for cursor → clamp chunk at range end → group scan under
  its own authorization); foreign-leader chunk mid-walk → (page,
  Some(resume_cursor)); at the FIRST chunk → typed NotLeader propagates.
  RawApi trait gains default raw_scan_paged (single-range backends never
  pause); RuntimeBackend overrides; grpc raw_scan handler returns
  scan_response_paged; proto ScanResponse += bytes resume_from=2;
  RawClient::scan returns (rows, resume); CLI raw-scan prints
  resume_from=hex when nonempty.
- raw_delete_range: same walk; foreign chunk after progress → receipt
  with resume_from (DeleteRangeReceipt += resume_from Option; proto
  RawDeleteRangeResponse += bytes resume_from=4; Copy derive dropped);
  no progress → NotLeader. RawGroup::range_binding() accessor.
- scripts/cross-range-e2e.py (port 27010, xrange-e2e-*): scan helper
  follows resume_from OR paginate-past-last-key; delete helper loops
  cursor=resume_from across nodes. e2e history: e2e-first exposed
  foreign-leader gap (design); e2e-2/3 harness syntax; e2e-fourth showed
  empty-page/foreign-chunk pagination gap → resume_from added;
  e2e-fifth RUNNING (b2lfh8dtj).
- Lean model proofs/lean/cross-range/CrossRange.lean COMPILES (11 thms).
REMAINING: runner scripts/prove-cross-range.py + README + docs/
CROSS-RANGE.md + plan sentence (drafts were written but LOST to a cwd
reset — REWRITE from the versions embedded in the transcript at the
"Model compile, runner, docs" step); fmt/clippy; contract (pins:
runtime.rs range_api.rs api.rs grpc.rs proto main.rs client? e2e script
model files) + sibling refresh; qualify (23 models); packaging (copy
parent-retirement scripts; e2e-fifth accepted + 4 retained); commit;
issues #9 (replace checkpoint) + #23 (D02 issue — append checkpoint);
publication + handoff (next candidates: automatic split triggers /
physical reclamation / stranded-learner recovery / #20 batching).
