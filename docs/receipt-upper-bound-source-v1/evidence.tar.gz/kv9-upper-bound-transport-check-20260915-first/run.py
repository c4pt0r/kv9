#!/usr/bin/env python3
"""One exact transport test, under the existing shared retained-build lock."""
import fcntl, hashlib, json, os, signal, subprocess, time
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/tmp/kv9-receipt-upper-bound-20260915-first')
PRIOR=Path('/tmp/kv9-upper-bound-development-20260915-first')
TARGET=Path('/home/dongxu/kv9/target')
COMMAND=['cargo','test','--offline','--locked','-j','4','-p','kv9-raft','--lib','--features','write-path-diagnostics','transport::tests::three_nodes_over_real_tcp_elect_replicate_and_discover','--','--exact','--test-threads=1']
def save(n,d):
    with(OUT/n).open('w')as f:json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def available():
    s=os.statvfs(OUT);return s.f_bavail*s.f_frsize
def sources():
    ns=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0')
    return {n:pin(ROOT/n)['sha256']for n in sorted(set(ns))if n and (n.startswith(('crates/','src/','proto/','.cargo/'))or n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml'))}
SCAN="""from pathlib import Path
import os,json,subprocess
rows=[];errors=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  exe=os.readlink(p/'exe');args=(p/'cmdline').read_bytes();st=(p/'stat').read_text()
  if Path(exe).name in ('cargo','rustc','rustdoc','clippy-driver'):rows.append(dict(pid=int(p.name),start_ticks=int(st.rsplit(')',1)[1].split()[19]),exe=exe,argv=args.decode(errors='replace').split('\\0')))
 except FileNotFoundError:pass
 except PermissionError as e:
  if p.exists():errors.append(str(e))
r=subprocess.run(['ss','-H','-tanp','sport = :39777 or dport = :39777'],capture_output=True,text=True)
print(json.dumps(dict(compilers=rows,errors=errors,socket_command=r.args,socket_exit=r.returncode,socket_stdout=r.stdout,socket_stderr=r.stderr)))
"""
result=dict(complete=False,scope='One isolated unchanged transport test after initial EADDRINUSE; not a port-race fix or replacement for the failed full run.',command=COMMAND,source=str(ROOT),source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),host_floor_bytes=8*1024**3,max_decrease_bytes=16*1024**3,timeout_seconds=1200,original_failure=dict(tool='26501/bda851/1',result=pin(PRIOR/'result.json'),log=pin(PRIOR/'check-0.log')),startup_reason='Initial test failed at bind127.0.0.1:39777 before discovery/election/application. Port reservation is released by free_addr(); isolate only this test once to distinguish reproducibility without changing assertions.',samples=[])
baseline=available();result['available_before']=baseline;child=None
def interrupted(sig,frame):raise InterruptedError('received signal '+str(sig))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
    before=sources();assert before==json.loads((PRIOR/'runtime-inputs.json').read_text()),'runtime input changed from failed original run';save('runtime-inputs-before.json',before)
    assert baseline>=result['host_floor_bytes']
    with(TARGET/'.kv9-retained-build.lock').open('r+')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        result['lock']=dict(path=str(TARGET/'.kv9-retained-build.lock'),device=os.fstat(lock.fileno()).st_dev,inode=os.fstat(lock.fileno()).st_ino,fd=lock.fileno(),exclusive=True,passed_to_cargo=True)
        scan=json.loads(subprocess.check_output(['sudo','-n','taskset','-c','6-15,22-31','python3','-c',SCAN],text=True));save('preflight.json',scan)
        assert not scan['compilers']and not scan['errors']and scan['socket_exit']==0,'compiler/reference scan incomplete'
        started=time.monotonic();result['started_unix_ns']=time.time_ns()
        env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='4',CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
        with(OUT/'test.log').open('x')as log:
            child=subprocess.Popen(['taskset','-c','6-15,22-31',*COMMAND],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,pass_fds=(lock.fileno(),))
            result['pid']=child.pid;result['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip();result['start_ticks']=int(Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19]);save('result.json',result)
            try:
                while child.poll()is None:
                    current=available();result['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=current))
                    assert current>=result['host_floor_bytes']and baseline-current<=result['max_decrease_bytes'],'space guard'
                    assert time.monotonic()-started<1200,'test timeout'
                    try:child.wait(timeout=5)
                    except subprocess.TimeoutExpired:pass
            finally:
                if child.poll()is None:os.killpg(child.pid,signal.SIGKILL)
                child.wait();result.update(exit_code=child.returncode,child_reaped=True,ended_unix_ns=time.time_ns())
        after=sources();save('runtime-inputs-after.json',after);result['runtime_inputs_unchanged']=after==before
        current=available();assert current>=result['host_floor_bytes']and baseline-current<=result['max_decrease_bytes'],'final space guard'
        assert child.returncode==0 and result['runtime_inputs_unchanged'],'isolated test failed/source changed'
        text=(OUT/'test.log').read_text();assert 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 258 filtered out;'in text,'test selection differs'
        result['complete']=True
except BaseException as e:
    result['failure']=repr(e);raise
finally:
    result['available_after']=available()
    if(OUT/'test.log').exists():result['test_log']=pin(OUT/'test.log')
    save('result.json',result)
print(json.dumps(result))
