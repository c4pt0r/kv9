# Receipt upper-bound development checkpoint

Candidate: `/tmp/kv9-receipt-upper-bound-20260915-first`, detached from `7f458bfba79a1ab654127bf1f63e76d2750abe79`. Experimental changes remain uncommitted; main is unchanged. No new performance result or promotion is claimed.

## Completed local development checks

- First instrumented Raft run: 258 passed, one TCP fixture bind failure. Preserve `/tmp/kv9-upper-bound-development-20260915-first` and its original failure.
- Exact failed fixture recheck: one passed, 258 filtered, actual tool receipt `9d6d20/0`; runtime source hashes unchanged. Evidence: `/tmp/kv9-upper-bound-transport-check-20260915-first`. This does not fix the released-port race.
- Only subsequent Rust edit: update the server diagnostic schema assertions for schema 2, 18 distributions and the new lookup algorithm label. All prior diagnostic Raft results are reused, not replayed.
- Remaining checks in this directory ended with actual tool receipt `c93db6/0`: default workspace 792 passed and 23 ignored; scoped server diagnostic snapshot one passed; Clippy with warnings denied and formatting check passed. See `runtime-inputs.json`, `prior-run-reuse.json`, `result.json`, and original logs.
- The later accidental poll of already-terminal session 61574 returned an unknown-process error; it did not launch or repeat any check.
- TLAPS drafts one and two remain preserved with their failed obligations. The third draft completed under strict, fresh checking with 82 obligations proved, actual tool receipt `ada93f/0`; source copies and output are under `/tmp/kv9-upper-bound-proof-draft-20260915-third`.

## Pending acceptance

The third proof draft is not yet the source-contract-bound, semantic-audited final proof package. Complete exact surrounding-driver equivalence, the legal-input assumption inventory, finite positive and deliberately incorrect-bound/guard controls, and proof-hole/false-axiom rejection controls. Keep the complete `(index, term, outcome)` first-match semantics, original vector ordering/eviction and unchanged fatal/watermark/deadline/cancellation/replacement/stop decisions. The upper bound only rejects impossible receipt lookups and never authorizes success.

The candidate observer uses schema 2 and adds actual skipped ring length; the schema-1 offline observer checker must not be reused without a separately verified schema-2 extension. The conservation equation is ring length = actual linear probes + matched slots behind the tail + skipped ring length, summed over the same lookup population.

Ordinary recovery, actual Chaos Mesh and the original 8-smoke/16-ten-second matched performance acceptance are not yet run for this candidate. No release has been built for it. The independent held tail-hint path-counter comparison remains pending and is not replaced by this new upper-bound experiment.

## Capacity

Root has no live Cargo/release/timed workload after the completed checks. The test-environment agent owns only the authorized 040–055 cold-retention tranche; it must not extend to 056. Its exact controller and per-boundary output are `/tmp/kv9-write-release-capacity-tranche-20260915-first`. Free space changes during retention and development; take a fresh `f_bavail` measurement before new workloads. The release minimum remains 25,778,192,384 bytes and the current tranche target is 26,851,934,208 bytes. Do not reduce guards or count predicted savings as available space.
