Schema2 upper-bound observer checker

This is a separately versioned offline derivative of the frozen schema1 checker. It accepts diagnostic schema_version2, lookup_algorithm upper_bound_then_first_match_linear_scan and exactly18 driver distributions plus the original three Ready distributions. The added index17 metric is receipt_upper_bound_skipped_ring_length, in receipts. It never relabels or accepts schema1 diagnostic captures. Default status still must omit the diagnostic line.

Only synthetic metadata qualification has run here:11 focused controls passed cf491d/0. No candidate capture, build, source test, workload, codec, cleanup or formal proof was run. origin preserves the earlier source, controls and their original correction/failure/result records. The earlier13 controls were not replayed. The new controls use the old synthetic fixture constructors, but execute only the new test_schema2 suite.

check.py.diff shows the finite changes. All existing identity, process PID/start/boot/store continuity, exporter, fresh-drain, source/config/input inventory, output ownership, histogram bounds/validity/saturation/monotonicity, service, age, successful-group, pump/joint and Ready checks remain. The added result labels explicitly identify schema2. source-delta.json checks that only conservation(), snapshot() and main() differ, and that main() differs only in those output labels. No original file was edited.

Recorder-derived lookup equations

Let L be receipt_ring_length_at_lookup, P be receipt_linear_probes_per_lookup, H be receipt_hit_slots_behind_tail, S be receipt_upper_bound_skipped_ring_length, M be lookup_misses and K be lookup_hits. With valid unsaturated snapshots:

- Every lookup records one L and one P sample, so L.count=P.count=K+M.
- AppliedReceipts::find_index passes slot=None on the upper-bound branch and returns None immediately. That branch records P value0 and one S sample with the actual ring length, including length0. Therefore S.count<=M; S is an actual subpopulation of L, including each histogram bucket.
- For a fallback hit at slot j in a ring of length n, P=j+1 and H=n−1−j, so n=P+H. A fallback miss has P=n and no H or S sample. An upper-bound miss has P=0, H absent and S=n. Summing all three cases yields L.sum=P.sum+H.sum+S.sum.
- A zero-probe fallback can occur only on an empty ring. Every skipped lookup has zero probes. Subtracting the skipped-empty overlap yields P.bucket0=S.count+L.bucket0−S.bucket0. The old P.bucket0<=M constraint remains. This also ensures skips cannot silently be represented as positive probe events.
- Every hit still has one H sample; index-distance samples remain at most K because tail_index.checked_sub(requested) may fail. No lookup count is equated with asynchronous service inspection counts.

These count statements depend on both the recorder and its actual caller: record_bounded_lookup accepts separate slot and upper_bound_miss arguments, while find_index is what guarantees upper_bound_miss implies slot=None. Exact source files and their hashes are in source-pins.json. Driver snapshots record each lookup atomically under the same observer lock, and invalid/saturated snapshots are rejected. The equations are checked for both cumulative endpoints and their monotonic delta.

What the aggregates cannot prove

An empty-ring skipped lookup has S.count1, S.sum0, S.bucket0=1. The positive control verifies that event survives delta extraction. An empty-ring fallback miss instead has no S sample. Their L/P/H/outcome marginals can otherwise be identical; without query/bound history, deleting or reclassifying an empty skipped event can be observationally indistinguishable from a fallback-empty miss. The checker does not invent that missing per-event authority. It rejects a missing S distribution, incorrect histogram counts, inconsistent skipped lengths/zero-probe counts, or violations of the source-derived aggregate constraints.

S.sum measures the lengths of rings whose scans were skipped. It is not CPU time, saved memory loads, an observed alternate execution, a tail-hint hit count or a predicted speedup. Whole-capture timing/group/queue limits remain unchanged: snapshots span setup/prefill inside the boundaries, warmup, measurement, completion tails, drains and dataset readback; they are not measurement-only data. The reader has no per-call history and cannot establish continuous leadership. No production selection is made.

Future use

The CLI remains --manifest PATH --manifest-sha256 SHA --output FRESH_DIRECTORY. Output must be immediately under this new preparation. The manifest's own format remains schema_version1; that is distinct from the embedded diagnostic schema_version2. It still describes the original finite16-row, two-second default/diagnostic observer sweep with exact source/feature roles, opposite orders and the nine pinned metadata inputs per row. ROOT-COMMANDS.json keeps actual capture authorities pending. Parent owns any executable build/fixture authority and future live acceptance. No original schema1 result should be passed to this checker or pooled with future schema2 observations as if it were the same schema.
