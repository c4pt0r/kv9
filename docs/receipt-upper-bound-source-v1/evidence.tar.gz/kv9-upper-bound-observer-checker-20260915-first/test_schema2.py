"""Focused schema2 metadata controls; no inherited test suite is executed."""
import copy
import importlib.util
from pathlib import Path
import unittest
import check as c

P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('old_fixture_builders',P/'origin/test_check.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
spec=importlib.util.spec_from_file_location('schema1_checker',P/'origin/check.py')
v1=importlib.util.module_from_spec(spec);spec.loader.exec_module(v1)

def sample(events=(),empty_pumps=False):
    # Retain the earlier synthetic service/group/Ready fixture, independently
    # replace only lookup populations with the explicit six-event table below.
    s=old.sample(empty_pumps)
    s['driver']['lookup_algorithm']='upper_bound_then_first_match_linear_scan'
    d=s['driver'];d['lookup_hits']=sum(e['hit']for e in events);d['lookup_misses']=len(events)-d['lookup_hits']
    values=[[e['length']for e in events],[e['probes']for e in events],
            [e['behind']for e in events if e['hit']],
            [e['distance']for e in events if e['hit']and e['distance']is not None],
            [e['length']for e in events if e['skip']]]
    d['distributions'][13:]=[old.dist(n,u,val)for(n,u),val in zip(c.METRICS[13:],values)]
    return s

EVENTS=[
    dict(length=3,probes=1,hit=True,behind=2,distance=99,skip=False),
    dict(length=3,probes=3,hit=True,behind=0,distance=0,skip=False),
    dict(length=3,probes=3,hit=False,skip=False),
    dict(length=0,probes=0,hit=False,skip=False),
    dict(length=5,probes=0,hit=False,skip=True),
    dict(length=0,probes=0,hit=False,skip=True),
]

class ChangedControls(unittest.TestCase):
    def reject(self,mutate):
        s=sample(EVENTS);mutate(s)
        with self.assertRaises(c.Refusal):c.snapshot(s)
    def test_mixed_hits_fallback_misses_and_skips(self):
        s=sample(EVENTS);c.snapshot(s)
        out=c.delta(sample((),True),s)['conservation']
        self.assertEqual((out['lookup_count'],out['upper_bound_skipped_lookups'],out['upper_bound_skipped_empty_ring_lookups'],out['upper_bound_skipped_ring_length_sum']),(6,2,1,5))
        d=s['driver']['distributions']
        self.assertEqual((d[13]['sum'],d[14]['sum'],d[15]['sum'],d[17]['sum']),(14,7,2,5))
        self.assertEqual((d[14]['buckets'][0],d[13]['buckets'][0],d[17]['buckets'][0]),(3,2,1))
    def test_empty_ring_skip_is_an_event(self):
        s=sample([EVENTS[-1]],True);c.snapshot(s)
        d=c.delta(sample((),True),s)
        skip=d['driver']['distributions'][17]
        self.assertEqual((skip['count'],skip['sum'],skip['buckets'][0]),(1,0,1))
        self.assertEqual(skip['maximum_bounds'],dict(lower=0,upper=0))
    def test_empty_fallback_is_also_allowed_not_inferred_as_skip(self):
        s=sample([EVENTS[3]],True);c.snapshot(s)
        self.assertEqual(s['driver']['distributions'][17]['count'],0)
        # Aggregate ring/probe/outcome marginals alone cannot determine which
        # empty-ring miss branch ran; the explicit skipped event is necessary.
        other=sample([EVENTS[-1]],True)
        self.assertEqual(s['driver']['distributions'][13:17],other['driver']['distributions'][13:17])
    def test_schema_algorithm_and_schema1_separation(self):
        self.reject(lambda s:s.__setitem__('schema_version',1))
        self.reject(lambda s:s['driver'].__setitem__('lookup_algorithm','first_match_linear_scan'))
        with self.assertRaises(v1.Refusal):v1.snapshot(sample(EVENTS))
    def test_skipped_inventory_omission_name_unit(self):
        self.reject(lambda s:s['driver']['distributions'].pop())
        self.reject(lambda s:s['driver']['distributions'][17].__setitem__('name','receipt_ring_length_at_lookup'))
        self.reject(lambda s:s['driver']['distributions'][17].__setitem__('unit','bytes'))
    def test_skipped_sum_and_count(self):
        self.reject(lambda s:s['driver']['distributions'].__setitem__(17,old.dist(*c.METRICS[17],[4,0])))
        self.reject(lambda s:s['driver']['distributions'][17].__setitem__('count',3))
        self.reject(lambda s:s['driver']['distributions'].__setitem__(17,old.dist(*c.METRICS[17],[5,0,0,0,0])))
    def test_skipped_ring_subset(self):
        self.reject(lambda s:s['driver']['distributions'].__setitem__(17,old.dist(*c.METRICS[17],[4,1])))
    def test_zero_probe_identity_and_omitted_nonempty_skip(self):
        self.reject(lambda s:s['driver']['distributions'].__setitem__(14,old.dist(*c.METRICS[14],[1,1,1,1,3,0])))
        self.reject(lambda s:s['driver']['distributions'].__setitem__(17,old.dist(*c.METRICS[17],[0])))
    def test_new_histogram_validity_saturation_and_exact_integers(self):
        for field,value in [('saturated',True),('count',True),('sum',1.0),('sum',c.U64+1),('buckets',[0]*64),('max',0)]:
            with self.subTest(field=field,value=value):self.reject(lambda s:s['driver']['distributions'][17].__setitem__(field,value))
    def test_skipped_reset_refused(self):
        a=sample([EVENTS[4]],True)
        b=sample([dict(length=5,probes=5,hit=False,skip=False)],True)
        c.snapshot(a);c.snapshot(b)
        with self.assertRaises(c.Refusal):c.delta(a,b)
    def test_prior_conservation_still_applies_with_skips(self):
        for index,values in [(4,[0,5]),(11,[10,20]),(15,[2]),(16,[99,0,1])]:
            with self.subTest(index=index):self.reject(lambda s:s['driver']['distributions'].__setitem__(index,old.dist(*c.METRICS[index],values)))
        self.reject(lambda s:s['driver'].__setitem__('successful_pumps',3))
        self.reject(lambda s:s['driver'].__setitem__('valid',False))
        self.reject(lambda s:s['driver']['applied_vs_resolved'][0].__setitem__(0,2))

if __name__=='__main__':unittest.main(verbosity=2)
