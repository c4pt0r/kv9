#!/usr/bin/env python3
import hashlib,importlib.util,json,os,shutil,subprocess,time,tomllib
from pathlib import Path
R=Path(__file__).resolve().parent;B=Path('/home/dongxu/kv9/scripts/resident-selected-profile');W=B.parents[1];O=R/'build-frame-pointers';O.mkdir(exist_ok=False)
os.environ['CARGO_TARGET_DIR']=str(W/'target');os.environ['CARGO_BUILD_JOBS']='4'
assert not os.environ.get('RUSTFLAGS')and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
assert not os.environ.get('CFLAGS')
os.environ['RUSTFLAGS']='-Cforce-frame-pointers=yes'
os.environ['CFLAGS']='-fno-omit-frame-pointer'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (O/'metadata.json').open('x')as out:subprocess.run(['cargo','metadata','--offline','--format-version','1'],cwd=B,stdout=out,check=True)
def registry(p):return{(x['name'],x['version'],x['source']):x['checksum']for x in tomllib.loads(p.read_text())['package']if x.get('source','').startswith('registry+')}
root=registry(W/'Cargo.lock');resolved=registry(B/'Cargo.lock');assert all(root.get(k)==v for k,v in resolved.items())
paths=[W/'Cargo.toml',W/'Cargo.lock',B/'Cargo.toml',B/'Cargo.lock',*sorted((B/'src').rglob('*.rs'))]
for crate in ('engine','common'):paths.extend([W/'crates'/crate/'Cargo.toml',*sorted((W/'crates'/crate/'src').rglob('*.rs'))])
sources={str(p):sha(p)for p in paths}
for p in paths:
 dst=O/'source'/p.relative_to(W);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
spec=importlib.util.spec_from_file_location('cache',W/'scripts/build_cache.py');cache=importlib.util.module_from_spec(spec);spec.loader.exec_module(cache)
result={'complete':False,'started_ns':time.time_ns(),'sources':sources,'registry_packages':len(resolved),'observation_flags':{'RUSTFLAGS':os.environ['RUSTFLAGS'],'CFLAGS':os.environ['CFLAGS']},'production_timing_eligible':False}
try:
 with cache.BuildCache(B,O,True,sources)as c:
  with (O/'engine-clean.stdout').open('x')as out,(O/'engine-clean.stderr').open('x')as err:c.run(['cargo','clean','--offline','--locked','--profile','release','-p','kv9-engine','-p','kv9-common'],stdout=out,stderr=err)
  with (O/'clippy.stdout').open('x')as out,(O/'clippy.stderr').open('x')as err:c.run(['cargo','clippy','--offline','--locked','--release','--all-targets','--','-D','warnings'],stdout=out,stderr=err)
  argv=['cargo','build','--offline','--locked','--release','--message-format','json-render-diagnostics']
  with (O/'cargo.jsonl').open('x')as out,(O/'cargo.stderr').open('x')as err:c.run(argv,stdout=out,stderr=err)
  c.check_artifacts(O/'cargo.jsonl')
  for name in ('kv9-engine','kv9-common'):
   units=[json.loads(l)for l in(O/'cargo.jsonl').read_text().splitlines()if 'compiler-artifact'in l];units=[u for u in units if u.get('target',{}).get('name')==name.replace('-','_')];assert len(units)==1 and not units[0]['fresh']and not units[0]['features']
  binary=O/'resident-selected-profile';shutil.copyfile(W/'target/release/kv9-resident-selected-profile',binary);binary.chmod(0o755)
  result['binary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary),'argv':argv}
 assert all(sha(Path(p))==h for p,h in sources.items());result['complete']=True
except BaseException as e:result['failure']=repr(e);raise
finally:
 result['ended_ns']=time.time_ns();(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'complete':True,'sources':len(sources),'binary':result['binary']}))
