#!/usr/bin/env python3
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/sys.argv[1];record=json.loads((O/'terminal.json').read_text());assert record['complete']
p=O/'perf.data';h=hashlib.sha256(p.read_bytes()).hexdigest();assert h==record['raw_perf']['sha256'];perf=record['perf']
argv=[perf,'script','-i',str(p),'--ns','--show-lost-events','-F','comm,pid,tid,time,event,ip,sym,symoff,dso']
with (O/'perf-script.txt').open('x')as out,(O/'perf-script.stderr').open('x')as err:
 t=time.time_ns();res=subprocess.run(argv,stdout=out,stderr=err,env=dict(os.environ,DEBUGINFOD_URLS=''),timeout=60)
(O/'decode-terminal.json').write_text(json.dumps({'argv':argv,'exit_code':res.returncode,'started_ns':t,'ended_ns':time.time_ns(),'raw_sha256':h},indent=2)+'\n');assert res.returncode==0
assert (O/'perf-script.txt').stat().st_size<32*1024**2
with (O/'perf-header.txt').open('x')as out,(O/'perf-header.stderr').open('x')as err:subprocess.run([perf,'report','--header-only','--stdio','-i',str(p)],stdout=out,stderr=err,check=True,timeout=30)
assert hashlib.sha256(p.read_bytes()).hexdigest()==h
subprocess.run(['python3','-B',str(R/'analyze.py'),sys.argv[1]],check=True,timeout=60)
