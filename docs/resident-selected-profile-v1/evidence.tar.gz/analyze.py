#!/usr/bin/env python3
"""Decode exact owned-PID apply spans and reject insufficient caller coverage."""
import bisect,collections,hashlib,json,re,sys
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/sys.argv[1];plan=json.loads((R/('frame-pointer-plan.json'if sys.argv[1].startswith('fp-')else'plan.json')).read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=json.loads((O/'terminal.json').read_text());ready=json.loads((O/'ready.json').read_text());output=json.loads((O/'result.json').read_text());decode=json.loads((O/'decode-terminal.json').read_text())
assert output['complete']and run['harness_exit_code']==0 and decode['exit_code']==0
if not run['complete']:
 reconcile=json.loads((O/'capture-reconciliation.json').read_text());assert run['perf_exit_code']==-2 and reconcile['owned_lifetimes_exited'];assert reconcile['raw_sha256']==decode['raw_sha256']==sha(O/'perf.data');assert reconcile['harness_result_sha256']==sha(O/'result.json')
else:assert run['raw_perf']['sha256']==decode['raw_sha256']==sha(O/'perf.data')
assert sha(Path(run['binary']['path']))==run['binary']['sha256'];assert output['pid']==ready['pid']==run['harness']['pid']
# Independently recover final values from the original retained corpus.
import struct
b=(R/'groups.bin').read_bytes();assert hashlib.sha256(b).hexdigest()==ready['input_sha256']==plan['corpus_sha256'];assert b[:8]==b'KV9GRP01'
pos=8;model={};ordinal=0;groups=0;previous_end=14221
while pos<len(b):
 previous,last,term,size=struct.unpack_from('<QQQI',b,pos);pos+=28;assert previous==previous_end and last>previous and term==1;previous_end=last;end=pos+size;n=struct.unpack_from('<I',b,pos)[0];pos+=4
 for _ in range(n):
  tag,cf,length=struct.unpack_from('<BBI',b,pos);pos+=6;assert tag==cf==0;k=b[pos:pos+length];pos+=length;length=struct.unpack_from('<I',b,pos)[0];pos+=4;v=b[pos:pos+length];pos+=length;ordinal+=1
  if output['workload']=='unique_insert':k+=ordinal.to_bytes(8,'big')
  model[k]=v
 assert pos==end;groups+=1
assert groups==106 and ordinal==100096 and previous_end==15785
h=hashlib.sha256();h.update(len(model).to_bytes(8,'little'))
for k,v in sorted(model.items()):h.update(len(k).to_bytes(8,'little'));h.update(k);h.update(len(v).to_bytes(8,'little'));h.update(v)
assert output['final_state_sha256']==ready['final_state_sha256']==h.hexdigest();assert output['final_keys']==len(model)
assert len(output['spans'])==output['passes']*106 and output['mutations']==output['passes']*100096
for i,(p,g,a,z)in enumerate(output['spans']):
 assert (p,g)==divmod(i,106)and a<z
 if i:assert output['spans'][i-1][3]<=a
starts=[s[2]for s in output['spans']];samples=[];selected=[];categories=collections.Counter();leaf_counts=collections.Counter();callers=0;unknown_leaf=0
text=(O/'perf-script.txt').read_text();assert not re.search(r'PERF_RECORD_LOST|LOST\s+\d+',text)
header=re.compile(r'^\S+\s+(\d+)/(\d+)\s+(\d+)\.(\d{9}):\s+cpu-clock:u:\s*$')
for chunk in re.split(r'\n\s*\n',text.strip()):
 lines=chunk.splitlines();m=header.fullmatch(lines[0]);assert m,lines[0];pid,tid,sec,ns=map(int,m.groups());assert pid==tid==output['pid'];stamp=sec*10**9+ns
 frames=[]
 for line in lines[1:]:
  m=re.fullmatch(r'\s*([0-9a-f]+)\s+(.+)\s+\((.*)\)\s*',line);assert m,line
  frames.append({'ip':m[1],'symbol':m[2],'dso':m[3]})
 assert frames;samples.append({'time_ns':stamp,'frames':frames})
 index=bisect.bisect_right(starts,stamp)-1
 if index<0 or stamp>=output['spans'][index][3]:continue
 symbols=[f['symbol']for f in frames];bound=any('kv9_resident_selected_profile::selected_apply'in s or ('kv9_engine::mem::MemEngine'in s and 'write_applied'in s)for s in symbols)
 callers+=bound;leaf=symbols[0];leaf_counts[leaf.split('+0x')[0]]+=1
 if 'memcmp'in leaf or 'bcmp'in leaf:category='comparison'
 elif 'memcpy'in leaf or 'memmove'in leaf:category='copy'
 elif any(s in leaf for s in ('_rjem_','tcache_','je_','malloc','dalloc','free','alloc::raw_vec','alloc::alloc')):category='allocation_free_maintenance'
 elif 'rpds::map::red_black_tree_map'in leaf or 'archery::'in leaf or 'Arc<'in leaf:category='tree_traversal_ownership'
 elif '[unknown]'in leaf:category='unknown_leaf';unknown_leaf+=1
 else:category='engine_or_other'
 categories[category]+=1;selected.append({'ordinal':len(samples)-1,'time_ns':stamp,'span':index,'named_apply_boundary':bound,'category':category,'frames':frames})
log=(O/'perf-record.log').read_text();n=int(re.search(r'\((\d+) samples\)',log)[1]);assert n==len(samples)
coverage={'recorded_samples':len(samples),'selected_apply_samples':len(selected),'named_apply_boundary_samples':callers,'named_apply_boundary_fraction':callers/len(selected),'unknown_leaf_samples':unknown_leaf,'one_frame_selected':sum(len(s['frames'])==1 for s in selected),'lost_events':0}
gate=plan['qualification_gate'];qualified=len(selected)>=gate['minimum_selected_samples']and coverage['named_apply_boundary_fraction']>=gate['minimum_named_apply_boundary_fraction']
result={'complete':True,'qualified':qualified,'coverage':coverage,'exclusive_leaf_categories':dict(categories),'leaf_counts':dict(leaf_counts.most_common()),'all_final_states_and_spans_verified':True,'selected':selected,'raw_sha256':sha(O/'perf.data'),'script_sha256':sha(O/'perf-script.txt'),'source_binary_sha256':run['binary']['sha256'],'original_supervisor_complete':run['complete'],'scope':'User CPU samples inside original apply spans, current-source offline component executable. No production-ELF CPU share, latency fraction, blocked time or QPS claim. Missing callers remain missing; leaf categories do not repair that absence.'}
(O/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'qualified':qualified,'coverage':coverage,'categories':dict(categories),'top_leaves':leaf_counts.most_common(10)}))
