#!/usr/bin/env python3
"""Capture one predeclared offline MemEngine case, owned process scope only."""
import hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parent;plan=json.loads((R/'frame-pointer-plan.json').read_text());build=json.loads((R/'build-frame-pointers/result.json').read_text());assert build['complete']
case_index=int(sys.argv[1]);cases=[plan['qualification_case'],*plan['subsequent_cases_if_qualified']];assert 0<=case_index<len(cases)
if case_index:
 q=json.loads((R/'fp-case-0/analysis.json').read_text());assert q['qualified'],q['coverage']
case=cases[case_index];O=R/f'fp-case-{case_index}';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for path,h in build['sources'].items():assert sha(path)==h
binary=build['binary'];assert sha(binary['path'])==binary['sha256']
assert min(shutil.disk_usage(p).free for p in ('/home/dongxu/kv9','/mnt/data'))>=plan['minimum_free_bytes']
perf=(Path('/usr/lib/linux-tools')/os.uname().release/'perf').resolve();assert perf.is_file()
assert sorted(os.sched_getaffinity(0))==list(range(6,16))+list(range(22,32))

def save(name,x):(O/name).write_text(json.dumps(x,indent=2)+'\n')
def identity(pid):
 p=Path('/proc')/str(pid);f=(p/'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'start_ticks':int(f[19]),'comm':(p/'comm').read_text().strip(),'affinity':sorted(os.sched_getaffinity(pid)),'argv':[os.fsdecode(x)for x in(p/'cmdline').read_bytes().split(b'\0')if x]}
def alive(who):
 try:return identity(who['pid'])['start_ticks']==who['start_ticks']
 except FileNotFoundError:return False

def children(pid):
 queue=[pid];found=[]
 for current in queue:
  try:
   found.append(identity(current));queue+=list(map(int,Path(f'/proc/{current}/task/{current}/children').read_text().split()))
  except FileNotFoundError:pass
 return found
proc=recorder=None;perf_identity=None;logs=[]
result={'complete':False,'case':case,'started_ns':time.time_ns(),'binary':binary,'plan_sha256':sha(R/'frame-pointer-plan.json'),'perf':str(perf),'perf_sha256':sha(perf),'throughput_acceptance':False}
try:
 argv=['taskset','-c','4',binary['path'],str(R),str(O),case['workload'],'pinned'if case['pinned']else'unpinned',str(case['passes'])]
 out=(O/'harness.stdout').open('x');err=(O/'harness.stderr').open('x');logs +=[out,err]
 proc=subprocess.Popen(argv,stdout=out,stderr=err);result['harness']=identity(proc.pid);result['harness_command']=argv;save('launch.json',result)
 deadline=time.monotonic()+60
 while not(O/'ready.json').exists():
  assert proc.poll()is None,'harness exited before ready';assert time.monotonic()<deadline,'ready timeout';time.sleep(.02)
 # Writing the ready file is followed by a gate wait; require complete JSON before proceeding.
 ready=None
 for _ in range(50):
  try:ready=json.loads((O/'ready.json').read_text());break
  except json.JSONDecodeError:time.sleep(.01)
 assert ready and ready['pid']==proc.pid and ready['prefix_states_checked']==106
 result['harness']=identity(proc.pid);assert result['harness']['affinity']==[4]and sha(f'/proc/{proc.pid}/exe')==binary['sha256']
 probe=['sudo','-n',str(perf),'stat','-e','cpu-clock:u','-p',str(proc.pid),'--','sleep','0.1']
 with (O/'permission.stdout').open('x')as out,(O/'permission.stderr').open('x')as err:
  result['permission_exit_code']=subprocess.run(probe,stdout=out,stderr=err,timeout=10).returncode
 assert result['permission_exit_code']==0
 command=['sudo','-n',str(perf),'record','--no-buildid-cache','--clockid','mono','-e','cpu-clock:u','-F','499','--call-graph','fp','--no-bpf-event','--max-size','128M','-m','256','-p',str(proc.pid),'-o',str(O/'perf.data')]
 log=(O/'perf-record.log').open('x');logs.append(log);recorder=subprocess.Popen(command,stdout=log,stderr=log,env=dict(os.environ,DEBUGINFOD_URLS=''))
 result['perf_command']=command
 deadline=time.monotonic()+3
 while time.monotonic()<deadline:
  assert recorder.poll()is None,'recorder exited before gate'
  matches=[p for p in children(recorder.pid)if p['comm']=='perf']
  if len(matches)==1:perf_identity=matches[0];break
  time.sleep(.02)
 assert perf_identity;result['profiler']=perf_identity;save('launch.json',result)
 time.sleep(.2);assert recorder.poll()is None;assert proc.poll()is None
 result['gate_monotonic_ns']=time.monotonic_ns();(O/'go').touch(exist_ok=False)
 print(json.dumps({'event':'recording','case':case_index,'harness_pid':proc.pid,'profiler_pid':perf_identity['pid']}),flush=True)
 result['harness_exit_code']=proc.wait(timeout=plan['perf']['timeout_seconds']);assert result['harness_exit_code']==0
 if recorder.poll()is None and alive(perf_identity):
  result['requested_stop']={'signal':2,'monotonic_ns':time.monotonic_ns(),'target':perf_identity};save('stop-request.json',result['requested_stop'])
  subprocess.run(['sudo','-n','kill','-INT',str(perf_identity['pid'])],check=True,timeout=10)
 result['perf_exit_code']=recorder.wait(timeout=15);assert result['perf_exit_code']==0 or (result['perf_exit_code']==-2 and result.get('requested_stop',{}).get('signal')==2)
 subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(O/'perf.data')],check=True,timeout=10)
 assert 0<(O/'perf.data').stat().st_size<plan['perf']['cap_bytes']
 output=json.loads((O/'result.json').read_text());assert output['complete']and output['passes']==case['passes']and output['mutations']==case['passes']*100096
 result['raw_perf']={'bytes':(O/'perf.data').stat().st_size,'sha256':sha(O/'perf.data')};result['harness_result_sha256']=sha(O/'result.json')
 assert not alive(result['harness'])and not alive(perf_identity)
 for path,h in build['sources'].items():assert sha(path)==h
 result['complete']=True
except BaseException as error:result['failure']=repr(error);raise
finally:
 if proc and proc.poll()is None:proc.terminate();proc.wait(timeout=10)
 if recorder and recorder.poll()is None:
  if perf_identity and alive(perf_identity):subprocess.run(['sudo','-n','kill','-INT',str(perf_identity['pid'])],check=False,timeout=10)
  recorder.wait(timeout=15)
 for log in logs:log.close()
 result['ended_ns']=time.time_ns();save('terminal.json',result)
print(json.dumps({'complete':result['complete'],'case':case_index,'raw_perf':result.get('raw_perf')}))
