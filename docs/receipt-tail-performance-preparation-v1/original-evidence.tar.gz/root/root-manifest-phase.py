"""Run explicitly selected frozen command arrays and retain original child results."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


p = argparse.ArgumentParser()
p.add_argument('--manifest', type=Path, required=True)
p.add_argument('--sha256', required=True)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--pin', action='append', default=[])
p.add_argument('phases', nargs='+')
a = p.parse_args()
raw = a.manifest.read_bytes()
assert hashlib.sha256(raw).hexdigest() == a.sha256
commands = json.loads(raw)
pins = dict(item.split('=', 1) for item in a.pin)
a.root.mkdir(exist_ok=True)
for phase in a.phases:
    spec = commands[phase]
    argv = [pins.get(value, value) for value in spec['argv']]
    assert not any(value.startswith('ACTUAL_') for value in argv)
    started = time.time_ns()
    save(a.root / (phase + '-invocation.json'), dict(
        argv=argv, cwd=spec.get('cwd'), started_ns=started,
        command_manifest_sha256=a.sha256))
    with (a.root / (phase + '.stdout')).open('xb') as out, \
            (a.root / (phase + '.stderr')).open('xb') as err:
        child = subprocess.Popen(argv, cwd=spec.get('cwd'), stdout=out, stderr=err)
        code = child.wait()
    result = dict(complete=code == 0, exit_code=code, pid=child.pid,
                  started_ns=started, ended_ns=time.time_ns(), argv=argv)
    if 'result' in spec and Path(spec['result']).is_file():
        data = Path(spec['result']).read_bytes()
        result.update(result_path=spec['result'],
                      result_sha256=hashlib.sha256(data).hexdigest())
    save(a.root / (phase + '-child-terminal.json'), result)
    print(json.dumps(result), flush=True)
    if code:
        raise SystemExit(code)
