import hashlib,json,subprocess,time
from pathlib import Path
R=Path(__file__).parent;P=Path('/tmp/kv9-write-crc-slicing8-full-regression-runtime-preparation-first')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert __debug__ and sha(P/'inventory.json')=='392d842332f324d8689b8bf09c7aa46a4f058495d943f91ba3dfd1e25caf15dd'
inv=json.loads((P/'inventory.json').read_text())
for name,b in inv['files'].items():
 p=P/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==b['bytes'] and sha(p)==b['sha256'],name
commands=json.loads((P/'commands.json').read_text())['contracts_root_only'];r=dict(complete=False,started_ns=time.time_ns(),inventory_sha256=sha(P/'inventory.json'),commands=[],scope='Finite preparation/source contracts only; no build, codec, benchmark or fault launch')
try:
 for i,argv in enumerate(commands):
  with (R/f'{i}.stdout').open('xb') as out,(R/f'{i}.stderr').open('xb') as err:
   row=dict(argv=argv,started_ns=time.time_ns());p=subprocess.Popen(argv,stdout=out,stderr=err);row['pid']=p.pid;r['commands'].append(row)
   row['exit_code']=p.wait(timeout=60);row['ended_ns']=time.time_ns();assert row['exit_code']==0,(i,'contract failure')
 r['complete']=True
except BaseException as e:r['failure']=repr(e);raise
finally:
 r['ended_ns']=time.time_ns();(R/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r));print('\n'.join((R/f'{i}.stderr').read_text()[-650:] for i in range(len(commands))))
