"""Finite source-text construction only: never import or execute fixture helpers."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = Path('/tmp/kv9-write-crc-slicing8-ab-preparation-first')
PLAN = Path('/tmp/kv9-write-crc-slicing8-full-regression-preparation-first')
ROOT = Path('/tmp/kv9-write-crc-slicing8-ab-campaign-root-second')
SMOKE = '/tmp/kv9-write-crc-slicing8-full-regression-smoke-first'
TIMING = '/tmp/kv9-write-crc-slicing8-full-regression-timing-first'
PROTOCOL = 'kv9-crc-slicing8-full-native-regression-c1-c64-v1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, data):
    p = HERE/name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(data.encode() if isinstance(data, str) else data)

def save(name, obj):
    write(name, json.dumps(obj, sort_keys=True, indent=2)+'\n')

def replace(text, before, after, count=None):
    actual = text.count(before)
    assert actual and (count is None or actual == count), (before, actual, count)
    return text.replace(before, after)

def paths(text):
    return text.replace(str(BASE), str(HERE)).replace(
        '/tmp/kv9-write-crc-slicing8-ab-smoke-first', SMOKE).replace(
        '/tmp/kv9-write-crc-slicing8-ab-timing-first', TIMING)

def funcs(text):
    return {n.name: ast.get_source_segment(text, n) for n in ast.parse(text).body
            if isinstance(n, (ast.FunctionDef, ast.ClassDef))}

pins = {}
def retain(path, name):
    data = path.read_bytes()
    assert len(data) <= 2*1024**2, path
    pins[str(path)] = dict(bytes=len(data), sha256=sha(data), retained_as=name)
    write(name, data)
    return data

original_inventory = (BASE/'inventory.json').read_bytes()
assert sha(original_inventory) == 'de26af8d419cc7c1693259098bad1e51e47f81468d54a7a9034d215f9e1105ab'
retain(BASE/'inventory.json', 'origins/accepted-crc-preparation/inventory.json')
for name, entry in json.loads(original_inventory)['files'].items():
    data = retain(BASE/name, 'origins/accepted-crc-preparation/'+name)
    assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], name
    if name.startswith('origins/'):
        write(name, data)
for name in ('PLAN.md','READINESS.json','protocol-plan.json','capacity-scenario.json','inventory.json'):
    retain(PLAN/name, 'origins/full-regression-plan/'+name)
for name in ('check-smoke.py','check-smoke-corrected.py','smoke-checker-import-repair.json'):
    retain(ROOT/name, 'origins/smoke-import-repair/'+name)
plan = json.loads((PLAN/'protocol-plan.json').read_text())

changed = {}
def derived(name, text, origin=None):
    before = (origin or BASE/name).read_text()
    ast.parse(text, filename=str(HERE/name))
    write(name, text)
    write(name+'.diff', ''.join(difflib.unified_diff(before.splitlines(True), text.splitlines(True),
        fromfile=str(origin or BASE/name), tofile=str(HERE/name))))
    old, new = funcs(before), funcs(text)
    assert old.keys() == new.keys(), name
    changed[name] = dict(changed_functions_or_classes=[n for n in old if old[n] != new[n]],
        unchanged_functions_or_classes=[n for n in old if old[n] == new[n]],
        original_sha256=sha(before.encode()), derived_sha256=sha(text.encode()))

for name in ('compressed_retention.py','retention_audit.py','isolate-and-run.py'):
    derived(name, paths((BASE/name).read_text()))
    assert not changed[name]['changed_functions_or_classes'], name
retention_sha = sha((HERE/'compressed_retention.py').read_bytes())
reader_sha = sha((HERE/'retention_audit.py').read_bytes())

d = paths((BASE/'matched-driver.py').read_text())
d = replace(d, 'kv9-write-crc-slicing8-ab-c1-c64-v1', PROTOCOL)
d = replace(d, 'WORKLOAD_CELLS = [("point", 1, 0), ("batch64", 64, 0)]',
            'WORKLOAD_CELLS = [("point", 1, 0), ("point", 1, 50), ("point", 1, 100),\n'
            '                  ("batch64", 64, 0), ("batch64", 64, 50), ("batch64", 64, 100)]', 1)
d = replace(d, '(8 if smoke else 16)', '(24 if smoke else 48)', 1)
d = replace(d, '8d9647f0b90cc9d6bad30443613ac4971371755bbe9231f3bb11d068a7159fca', retention_sha)
d = replace(d, '16-cohort shared-host native v3 point Put/BatchPut64 c1/c64 diagnostic screen; no promotion, read/mixed regression or Chaos acceptance',
            '48-cohort shared-host native v3 point/batch GET/PUT/mixed c1/c64 regression screen; no promotion or new Chaos acceptance')
d = replace(d, '8-cohort native v3 point Put/BatchPut64 c1/c64 correctness smoke only; no timing acceptance',
            '24-cohort native v3 point/batch GET/PUT/mixed c1/c64 correctness smoke only; no timing acceptance')
derived('matched-driver.py', d)
assert set(changed['matched-driver.py']['changed_functions_or_classes']) == {'make_plan','main'}
driver_sha = sha(d.encode())

a = paths((BASE/'audit.py').read_text())
for before, after in [
    ('Independent 16-cohort native v3 write-only diagnostic readback', 'Independent 48-cohort native v3 point/batch read/write/mixed regression readback'),
    ('kv9-write-crc-slicing8-ab-c1-c64-v1', PROTOCOL),
    ("WORKLOADS = (('point-r000',1,0), ('batch64-r000',64,0))", "WORKLOADS = (('point-r000',1,0), ('point-r050',1,50), ('point-r100',1,100),\n             ('batch64-r000',64,0), ('batch64-r050',64,50), ('batch64-r100',64,100))"),
    ('choices=(16,)', 'choices=(48,)'),
    ("len(matrix['attempts'])==16", "len(matrix['attempts'])==48"),
    ('args.successful_arms==16', 'args.successful_arms==48'),
    ("len(smoke_matrix['attempts'])==8", "len(smoke_matrix['attempts'])==24"),
    ('expected_cohorts()[:8]', 'expected_cohorts()[:24]'),
    ('len(smoke_cases)==8 and len(smoke_lifetimes)==32', 'len(smoke_cases)==24 and len(smoke_lifetimes)==96'),
    ('owned_lifetimes_exited=32', 'owned_lifetimes_exited=96'),
    ('len(smoke_retention)==8', 'len(smoke_retention)==24'),
    ('len(retention_summaries)==16', 'len(retention_summaries)==48'),
    ("len(result['cases'])==16 and len(lifetimes)==64 and drains==48 and writer_bindings==48",
     "len(result['cases'])==48 and len(lifetimes)==192 and drains==144 and writer_bindings==144"),
    ('8d9647f0b90cc9d6bad30443613ac4971371755bbe9231f3bb11d068a7159fca', retention_sha),
    ('4d353e003d3ed044359c544b0f2587937b25a1a069b6de8c79586a545e3f8cc2', reader_sha),
    ('Two-repeat 10-second native v3 point Put/BatchPut64 c1/c64 shared-host tmpfs write screen; no read/mixed regression, Chaos, promotion, sustained-capacity, exact issued nonce ledger or full-history claim',
     'Two-repeat 10-second native v3 point/batch GET/PUT/mixed c1/c64 shared-host tmpfs regression screen; no new Chaos, promotion, sustained-capacity, exact issued nonce ledger or full-history claim'),
]:
    a = replace(a, before, after)
a = a.replace('sixteen', 'forty-eight')
derived('audit.py', a)
assert changed['audit.py']['changed_functions_or_classes'] == ['validate_matrix_protocol']
audit_sha = sha(a.encode())

for name in ('driver-arguments.json','build-bindings.json','original-input-pins.json'):
    write(name, (BASE/name).read_bytes())
assert sha((HERE/'driver-arguments.json').read_bytes()) == 'cf44d832cc43b83ab8c8487c0901661f78216526bf047750ce0a9190a96c98b1'

s = paths((ROOT/'check-smoke-corrected.py').read_text())
s = replace(s, '537eeb3bb0e1fb533ec5648b5b114c123d2d71b791085097274414442fb77f40', driver_sha)
s = replace(s, '391df0c4d2a032152d36a8a70767784e07fb09c3fe42848bc733733ca05f53ca', audit_sha)
s = replace(s, "len(matrix['attempts']) == 8", "len(matrix['attempts']) == 24", 1)
s = replace(s, 'len(lifetimes) == 32', 'len(lifetimes) == 96', 1)
derived('check-smoke-corrected.py', s, ROOT/'check-smoke-corrected.py')
assert not changed['check-smoke-corrected.py']['changed_functions_or_classes']

t = (BASE/'test_driver.py').read_text()
for before, after in [
    ('test_independent_16_order_and_exact_8_smoke','test_independent_48_order_and_exact_24_smoke'),
    ('for reads in [0]','for reads in [0, 50, 100]'),
    ('len(plan), 16','len(plan), 48'),
    ('kv9-write-crc-slicing8-ab-c1-c64-v1', PROTOCOL),
    ('repeat*8:(repeat+1)*8','repeat*24:(repeat+1)*24'),
    ('len(smoke), 8','len(smoke), 24'), ('plan[:8]','plan[:24]')
]: t = replace(t, before, after)
derived('test_driver.py', t)

t = (BASE/'test_audit_contract.py').read_text()
for before, after in [
    ('writes=[r for r in WORKLOAD_ROWS if r[2]==0]', 'writes=list(WORKLOAD_ROWS)'),
    ('for name,batch,reads in WORKLOAD_ROWS if reads==0', 'for name,batch,reads in WORKLOAD_ROWS'),
    ('kv9-write-crc-slicing8-ab-c1-c64-v1', PROTOCOL),
    ('test_exact_16_entire_reverse_order_and_run_ids','test_exact_48_entire_reverse_order_and_run_ids'),
    ('len(expected),16','len(expected),48'),
    ('(0,4,8,12,15)', '(0,12,24,36,47)'),
    ("(1,'new-batch64-r000','p10064'),(1,'new-batch64-r000','p10001')",
     "(1,'new-batch64-r100','p10064'),(1,'new-batch64-r100','p10001')"),
    ('for workload,_,_ in [r for r in WORKLOAD_ROWS if r[2]==0]', 'for workload,_,_ in WORKLOAD_ROWS'),
]: t = replace(t, before, after)
# Retain each negative class, scaled to the full physical order.
t = replace(t, "m['cohort_inventory'][8:]=m['cohort_inventory'][12:]+m['cohort_inventory'][8:12]",
               "m['cohort_inventory'][24:]=m['cohort_inventory'][36:]+m['cohort_inventory'][24:36]")
t = replace(t, "m['cohort_inventory'][4:8]=copy.deepcopy(m['cohort_inventory'][:4])",
               "m['cohort_inventory'][12:24]=copy.deepcopy(m['cohort_inventory'][:12])")
t = replace(t, "m['cohort_inventory']=m['cohort_inventory'][:8];m['attempts']=[{}]*8",
               "m['cohort_inventory']=m['cohort_inventory'][:24];m['attempts']=[{}]*24")
t = replace(t, "m['cohort_inventory'][8:]=copy.deepcopy(m['cohort_inventory'][:8])",
               "m['cohort_inventory'][24:]=copy.deepcopy(m['cohort_inventory'][:24])")
t = replace(t, "m['attempts']=[{}]*12", "m['attempts']=[{}]*47")
derived('test_audit_contract.py', t)
t = replace((BASE/'test_smoke_schema.py').read_text(),
    'len(smoke_cases)==8 and len(smoke_lifetimes)==32', 'len(smoke_cases)==24 and len(smoke_lifetimes)==96')
derived('test_smoke_schema.py', t)

protocol = json.loads((BASE/'protocol.json').read_text())
protocol.update(protocol_id=PROTOCOL, driver_sha256=driver_sha, auditor_sha256=audit_sha,
    smoke_inventory=plan['smoke_inventory_proposed'], timed_inventory=plan['timed_inventory_proposed'],
    workload_cells=plan['workload_cells'], expected_counts=plan['counts'], runtime_ready=False,
    capacity_qualified=False, contracts_executed=False,
    decision_scope='Complete native point/batch GET/PUT/50%-read mixed c1/c64 screen in two entire opposite orders. '
    'Report each operation/order and pooled work/time. No automatic promotion or new Chaos acceptance; '
    'historical results are not current observations.')
protocol['compressed_retention'].update(helper=dict(bytes=len((HERE/'compressed_retention.py').read_bytes()),sha256=retention_sha),
    independent_reader=dict(bytes=len((HERE/'retention_audit.py').read_bytes()),sha256=reader_sha),
    logical_campaign_roots=[SMOKE,TIMING+'/cohorts'])
save('protocol.json', protocol)
save('expected-descriptors.json', dict(smoke=protocol['smoke_inventory'],timed=protocol['timed_inventory']))
save('source-delta.json', dict(changes=changed, helpers_executed=False,
    scope='Exact workload/count/path/pin adaptation. Generic API/population/dataset/lifecycle/retention/isolation functions retained byte-for-byte.'))
save('input-hashes.json', pins)
print(json.dumps(dict(complete=True, construction_only=True, driver_sha256=driver_sha, auditor_sha256=audit_sha,
                     files=len(list(HERE.rglob('*'))))))
