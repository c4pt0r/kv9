"""Finite changed-scope controls. Pure descriptors/AST/virtual data; no fixture or codec."""
import ast
import copy
import json
from pathlib import Path
import unittest

import test_audit_contract as original
import test_driver as driver_contract

H = Path(__file__).resolve().parent
d = driver_contract.d
audit = original.audit


def exec_nodes(nodes, namespace):
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<source-bound-controls>', 'exec'), namespace)


def source_call(tree, message):
    rows = [n for n in ast.walk(tree) if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
            and any(isinstance(x, ast.Constant) and x.value == message for x in n.value.args)]
    if len(rows) != 1:
        raise AssertionError((message, len(rows)))
    return rows[0]


def smoke_check(matrix):
    """Execute only actual count/order/path guards, stopping before report I/O."""
    tree = ast.parse((H/'audit.py').read_text())
    initial = source_call(tree, 'combined capacity requires the original complete same-role smoke')
    loop = next(n for n in ast.walk(tree) if isinstance(n, ast.For) and
                'smoke_attempt' in [x.id for x in ast.walk(n.target) if isinstance(x, ast.Name)])
    last = source_call(tree, 'smoke path/order/completion differs')
    prefix = loop.body[:loop.body.index(last)+1]
    bounded_loop = ast.For(target=loop.target, iter=loop.iter, body=prefix, orelse=[])
    ast.fix_missing_locations(bounded_loop)
    ns = dict(audit, Path=Path, smoke_matrix=matrix,
              smoke_root=Path('/tmp/kv9-write-crc-slicing8-full-regression-smoke-first'),
              matrix={'role_bindings':{'synthetic':'same exact roles'}})
    exec_nodes([initial, bounded_loop], ns)
    # The corrected standalone reader also binds the entire declared inventory.
    checker = ast.parse((H/'check-smoke-corrected.py').read_text())
    guard = next(n for n in checker.body if isinstance(n, ast.Assert) and
                 "matrix['cohort_inventory']" in ast.unparse(n))
    exec_nodes([guard], dict(matrix=matrix, driver=d))


def smoke_matrix():
    rows = []
    root = Path('/tmp/kv9-write-crc-slicing8-full-regression-smoke-first')
    for i, item in enumerate(original.matrix()['cohort_inventory'][:24]):
        desc = copy.deepcopy(item)
        desc['shared']['measure_ms'] = 2000
        rows.append(dict(index=i, descriptor=desc, complete=True,
                         directory=str(root/f'{i:03d}-{desc["arm"]}-p0{desc["shared"]["workers"]:04d}')))
    return dict(complete=True, smoke=True, protocol_id='kv9-crc-slicing8-full-native-regression-c1-c64-v1',
                role_bindings={'synthetic':'same exact roles'}, attempts=rows,
                cohort_inventory=[copy.deepcopy(row['descriptor']) for row in rows])


def population_check(config, calls):
    report = original.phase_report(config, True)
    for op, count in zip(report['metrics']['measurement']['statistics'], calls):
        op['populations'][0]['calls'] = count
    for phase in report['metrics'].values():
        for op in phase['statistics']:
            op['attempts'] = [dict(raw=dict(count=op['populations'][0]['calls']))]
    audit['validate_phase_apis'](report, config, True)
    return d.population_observations(report, config, False)


class FullRegressionContract(unittest.TestCase):
    def test_frozen_protocol_and_independent_all_api_inventory(self):
        p = json.loads((H/'protocol.json').read_text())
        expected = original.matrix()['cohort_inventory']
        self.assertEqual(p['timed_inventory'], expected)
        self.assertEqual(p['timed_inventory'], d.make_plan(False))
        smoke = [dict(row, shared=dict(row['shared'], measure_ms=2000)) for row in expected[:24]]
        self.assertEqual(p['smoke_inventory'], smoke)
        self.assertEqual(p['smoke_inventory'], d.make_plan(True))
        self.assertEqual(len(p['timed_inventory']), 48)
        self.assertEqual(len(p['smoke_inventory']), 24)
        self.assertEqual(p['expected_counts']['timed_fresh_drains'], 144)
        self.assertFalse(p['runtime_ready'])
        self.assertFalse(p['capacity_qualified'])

    def test_unused_operation_refused_for_both_pure_apis(self):
        for kind in ('point', 'batch64'):
            for reads, counts in ((0, [0, 3]), (100, [3, 0])):
                c = original.config(0, 64, f'{kind}-r{reads:03d}', 'old')
                population_check(c, counts)
                report = original.phase_report(c, True)
                for op in report['metrics']['measurement']['statistics']:
                    op['attempts'] = [dict(raw=dict(count=1))]
                for op, n in zip(report['metrics']['measurement']['statistics'], [2, 1]):
                    op['populations'][0]['calls'] = n
                with self.assertRaises(ValueError):
                    audit['validate_phase_apis'](report, c, True)
                # Only the measurement section is needed for the driver's independent population guard.
                report['metrics'] = {'measurement':report['metrics']['measurement']}
                with self.assertRaises(ValueError):
                    d.population_observations(report, c, False)

    def test_mixed_requires_both_operations_without_exact_half_claim(self):
        for kind in ('point', 'batch64'):
            c = original.config(1, 64, kind+'-r050', 'new')
            for calls in ([1, 2], [2, 1]):
                self.assertEqual(population_check(c, calls)['measurement']['calls'], calls)
            for calls in ([0, 3], [3, 0]):
                with self.assertRaises(ValueError):
                    population_check(c, calls)
                report = dict(measured_issued=3, metrics={'measurement':dict(
                    operations=[c['read_api'].removeprefix('point_'), c['write_api'].removeprefix('point_')],
                    statistics=[dict(populations=[dict(calls=n)], attempts=[dict(raw=dict(count=n))]) for n in calls])})
                with self.assertRaises(ValueError):
                    d.population_observations(report, c, False)

    def test_mixed_nonce_selection_membership_and_pure_read_dataset(self):
        for kind, batch in (('point', 1), ('batch64', 64)):
            c = original.config(0, 1, kind+'-r050', 'old')
            c.update(keys=128, batch_size=batch, value_bytes=16)
            key = lambda i: f'{c["run_id"]}:{i:016x}'.encode()
            value = lambda i, n: i.to_bytes(8, 'big')+n.to_bytes(8, 'big')
            data = {key(i):value(i, 0) for i in range(c['keys']+1)}
            write_nonce = next(n for n in range(1, 1000) if original.oracle_mix(c['seed']^n)%100 >= 50)
            read_nonce = next(n for n in range(1, 1000) if original.oracle_mix(c['seed']^n)%100 < 50)
            first = original.oracle_mix(c['seed']^write_nonce^0xc6275c213842315b)%c['keys']
            data[key(first)] = value(first, write_nonce)
            for checker in (lambda values: audit['dataset_check'](c, values),
                            lambda values: d.final_dataset(c, values, driver_contract.resp)):
                self.assertEqual(checker(data)['changed_keys'], 1)
                self.assertFalse(checker(data)['exact_issued_nonce_set_checked'])
                bad = dict(data)
                read_first = original.oracle_mix(c['seed']^read_nonce^0xc6275c213842315b)%c['keys']
                bad[key(read_first)] = value(read_first, read_nonce)
                with self.assertRaises(ValueError): checker(bad)
                bad = dict(data)
                wrong = (first+batch)%c['keys']
                bad[key(wrong)] = value(wrong, write_nonce)
                with self.assertRaises(ValueError): checker(bad)
            c['read_percent'] = 100
            zero = {key(i):value(i, 0) for i in range(c['keys']+1)}
            self.assertEqual(audit['dataset_check'](c, zero)['changed_keys'], 0)
            self.assertEqual(d.final_dataset(c, zero, driver_contract.resp)['changed_keys'], 0)
            with self.assertRaises(ValueError): audit['dataset_check'](c, data)
            with self.assertRaises(ValueError): d.final_dataset(c, data, driver_contract.resp)

    def test_smoke_missing_duplicate_reordered_count_and_scope_rejected(self):
        good = smoke_matrix()
        smoke_check(good)
        bads = []
        m = copy.deepcopy(good); m['attempts'].pop(); bads.append(m)
        m = copy.deepcopy(good); m['attempts'].append(copy.deepcopy(m['attempts'][0])); bads.append(m)
        m = copy.deepcopy(good); m['attempts'][1] = copy.deepcopy(m['attempts'][0]); bads.append(m)
        m = copy.deepcopy(good); m['attempts'][0], m['attempts'][1] = m['attempts'][1], m['attempts'][0]; bads.append(m)
        m = copy.deepcopy(good); m['attempts'][0]['complete'] = False; bads.append(m)
        m = copy.deepcopy(good); m['cohort_inventory'].reverse(); bads.append(m)
        m = copy.deepcopy(good); m['role_bindings'] = {}; bads.append(m)
        for m in bads:
            with self.assertRaises((ValueError, AssertionError)): smoke_check(m)

    def test_retention_collector_exact_new_roots_and_synthetic_boundary(self):
        tree = ast.parse((H/'compressed_retention.py').read_text())
        nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('need','logical_roots')
                 or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'COHORT_ROOTS' for t in n.targets)]
        ns = dict(Path=Path, __file__=str(H/'compressed_retention.py'))
        exec_nodes(nodes, ns)
        expected = [Path('/tmp/kv9-write-crc-slicing8-full-regression-smoke-first'),
                    Path('/tmp/kv9-write-crc-slicing8-full-regression-timing-first/cohorts')]
        self.assertEqual(ns['COHORT_ROOTS'], expected)
        for root in expected: self.assertEqual(ns['logical_roots'](root), expected)
        synthetic = H/'synthetic-first'/'finite'
        self.assertEqual(ns['logical_roots'](synthetic), [synthetic])
        for root in (Path('/tmp/kv9-write-crc-slicing8-ab-smoke-first'),
                     Path('/tmp/kv9-write-crc-slicing8-ab-timing-first/cohorts'),
                     Path(str(expected[0])+'-other'), expected[1].parent, expected[0]/'child',
                     expected[0]/'..'/'foreign', H/'synthetic-first-other'):
            with self.assertRaisesRegex(ValueError, 'unbound campaign root'): ns['logical_roots'](root)

    def test_retention_reader_rejects_old_extra_missing_reordered_roots(self):
        tree = ast.parse((H/'retention_audit.py').read_text())
        nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'check'
                 or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'COHORT_ROOTS' for t in n.targets)]
        ns = dict(Path=Path)
        exec_nodes(nodes, ns)
        guard = source_call(tree, 'combined campaign scope')
        expected = [str(x) for x in ns['COHORT_ROOTS']]
        exec_nodes([guard], dict(ns, catalog={'logical_campaign_roots':expected}))
        for roots in (expected[:1], list(reversed(expected)), expected+[expected[0]],
                      ['/tmp/kv9-write-crc-slicing8-ab-smoke-first', expected[1]]):
            with self.assertRaisesRegex(ValueError, 'combined campaign scope'):
                exec_nodes([guard], dict(ns, catalog={'logical_campaign_roots':roots}))


if __name__ == '__main__':
    unittest.main(verbosity=2)
