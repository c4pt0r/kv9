# CRC slicing-by-8 full native regression preparation

This frozen preparation implements the published six-workload plan for selected
`11113f68f6a5df77da1ffb4fcec850953716ffa3` versus CRC
`e748620a7b0ba326ac5f4fa8e3a6b1ff48553c6a`, with the original fixed v3 client
`0be806d9671e2c50701a64aa7889c8859b7648ba`. No contracts, source validators,
workloads, auditors or codecs were executed during preparation. Runtime and
capacity readiness are false.

The exact matrix is 24 fresh 2-second correctness smokes followed, after their
terminal readback and a separate capacity release, by 48 fresh 10-second timed
cohorts. The first order is concurrency 1 then 64; point then batch64; read
percentage 0, 50, 100; old then new. The second timed order reverses the entire
24-element list. Each role therefore runs Put/BatchPut64, GET/BatchGet64, and
50%-read mixed traffic at both concurrencies. `protocol.json` contains every
descriptor, API selector, source/build hash and expected count. Redis has no
trial or server role; the unchanged source-bound configuration oracle remains
an imported dependency.

`source-delta.json` and the adjacent diffs record the finite changes. The driver
changes only `make_plan` and the retention pin/display strings in `main`, plus
the workload/protocol constants. The auditor changes only the count/message in
`validate_matrix_protocol`, plus top-level path, scope, pin and accounting
constants. Its generic API/population/dataset/histogram/resource/lifecycle
checks are byte-identical to the accepted native write16 reader. Both retention
files change only `COHORT_ROOTS`; every function, class and limit is unchanged.
Isolation is byte-identical. The standalone smoke checker preserves the actual
fixed native-v3 scripts import and only changes paths, pins and counts.

All accepted original preparation files, including its rejected initial draft,
are retained under `origins/accepted-crc-preparation`. The original smoke import
failure and corrected checker are retained under `origins/smoke-import-repair`.
`static-review-first` preserves a preparation-only display-string correction;
it is not a failed test or workload. No historical result is relabeled as a new
observation.

Use the exact root-only argv arrays in `commands.json`. The four control arrays
contain the adapted original 8 driver, 15 auditor and 5 native-smoke controls,
plus 7 focused changed-scope controls. One original driver control revalidates
the actual retained source/build inputs; root must schedule these commands
under its exclusive source-check policy. The new controls use only tiny virtual
datasets and extracted actual guard statements. They cover the exact protocol,
pure-operation refusals, both mixed populations without an exact-half assertion,
mixed final nonce/write membership, smoke count/order/completion refusals, and
both collector and reader retention-root boundaries. The adapted original
auditor controls reject incomplete, duplicate and incorrectly reversed timed
inventories. No new large codec qualification is required by a root-only change.

Execution order remains: verify frozen inventory and retained inputs; root local
controls/source checks; separate actual capacity and environment release; fresh
24 smokes; terminal smoke checker; fresh 48 timed cohorts through the unchanged
isolation wrapper; actual terminal receipt; independent enclosing audit with
`--successful-arms 48` and the real positive `--root-session`. Outputs must be
fresh. The command placeholder is not a session or permission. Reporting is
prepared separately by the reporting owner and consumes only new accepted
audit/input-inventory/report bindings.

Timing clients stay on CPUs 0–1 and all three voters share CPUs 2–5. Smoke and
helper placement is inherited exactly. Each cohort retains original source,
binary, listener, launch, status, metrics, three fresh drains, full paginated
dataset plus sentinel, process resources and terminal cleanup evidence. The
timed audit independently totals 48 cohorts, 192 process lifetimes, 144 drains
and 144 writer/listener bindings; it checks 24 smoke cohorts and 96 smoke
lifetimes. The expected 72 smoke drains come from the unchanged three-drain
driver lifecycle; the enclosing smoke result has no independent drain-count
field. Do not report that number as a newly summed audit observation.

Mixed selection is deterministic per nonce; realized GET/PUT counts need not be
equal. Preserve all outcomes, attempts, empty unused-operation populations and
the separate healthy single-attempt suitability flag. Final values establish
configured nonce bounds, deterministic bytes and write-key membership; aggregate
reports do not establish the exact issued nonce set or concurrent write order.
CPU estimates cover accepted process-resource intervals and are not exclusively
the measurement window or proven per-request service time. Histograms retain
bucket uncertainty; do not average percentiles. Both servers use ordinary sync
on tmpfs WAL: this is not power-loss durability, new Chaos acceptance or an
automatic promotion decision.

`capacity.json` only references the published historical planning scenario. Its
81,042,588,591 compressed-object bytes are not a complete resident-allocation
bound, and its former 80,877,257,647-byte shortfall is not a current observation.
No capacity value or gate was changed or newly qualified here. Original per-arm
32-GiB tmpfs/96-GiB disk preflight, 16-GiB tmpfs/64-GiB driver runtime guards,
96-GiB retention floor, 8-GiB member, 16-GiB cohort and 128-GiB combined campaign
retention caps remain intact. A fresh whole-campaign capacity release, with
actual total resident allocation and restore/transient reservation, is required
before any runtime launch.

`inventory.json` is an envelope with relative-path `files` records (SHA256 and
bytes), excluding itself. Every prepared input is bounded by the 16-MiB total
preparation allowance. The stored historical inventories keep their original
schemas and verdicts. The preparation contains no measured campaign results.
