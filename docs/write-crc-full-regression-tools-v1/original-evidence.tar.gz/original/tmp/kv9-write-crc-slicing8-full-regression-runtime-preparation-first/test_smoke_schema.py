#!/usr/bin/env python3
"""Finite native projection of the accepted smoke schema repair; no runtime."""
import ast, copy, hashlib, json, unittest
from pathlib import Path
H=Path(__file__).resolve().parent
SOURCE=(H/'audit.py').read_text()
TREE=ast.parse(SOURCE)
def require(ok,message):
    if not ok: raise ValueError(message)
def cleanup(cl,exit_code=0):
    loop=next(n for n in ast.walk(TREE) if isinstance(n,ast.For) and any(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cleanup_ok' for t in x.targets) for x in n.body))
    i=next(i for i,n in enumerate(loop.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cleanup_ok' for t in n.targets))
    exec(compile(ast.Module(body=loop.body[i:i+2],type_ignores=[]),'<native-smoke-cleanup>','exec'),dict(cl=cl,read=lambda _:dict(exit_code=exit_code),sd=Path('/synthetic'),require=require))
def binary(identity):
    calls=[n for n in ast.walk(TREE) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and "'smoke executing binary differs'" in ast.get_source_segment(SOURCE,n)]
    assert len(calls)==1
    exec(compile(ast.Module(body=calls,type_ignores=[]),'<native-smoke-binary>','exec'),dict(identity=identity,expected_sha='a'*64,require=require))
class NativeSmokeSchema(unittest.TestCase):
    def test_original_native_schema(self):
        cleanup(dict(complete=True,storage='tmpfs',children=[{}]*4))
        binary(dict(executable_sha256='a'*64))
    def test_cleanup_rejections(self):
        good=dict(complete=True,storage='tmpfs',children=[{}]*4)
        for k,v in [('complete',False),('complete',1),('storage','wal'),('children',[{}]*3)]:
            bad=copy.deepcopy(good);bad[k]=v
            with self.assertRaises(ValueError):cleanup(bad)
        with self.assertRaises(ValueError):cleanup(good,1)
        with self.assertRaises(KeyError):cleanup(dict(errors=[],children=[{}]*4))
    def test_executable_rejections(self):
        with self.assertRaises(ValueError):binary(dict(executable_sha256='b'*64))
        with self.assertRaises(KeyError):binary(dict(executable='/synthetic/path'))
    def test_original_lifetime_predicates_retained(self):
        repaired=(H/'origins/repaired-redis3-audit.py').read_text()
        for text in ["life not in smoke_lifetimes", "child.get('absent',child.get('pid_absent_after_reap'))", "not Path('/proc',str(identity['pid'])).exists()", "child['exit_code']==(0 if client or not native_smoke else -9)"]:
            self.assertIn(text,repaired);self.assertIn(text,SOURCE)
        self.assertIn('len(smoke_cases)==24 and len(smoke_lifetimes)==96',SOURCE)
    def test_exact_native_ancestry_arguments_and_retention_functions(self):
        def funcs(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
        for filename in ['compressed_retention.py','retention_audit.py','isolate-and-run.py']:
            self.assertEqual(funcs((H/filename).read_text()),funcs((H/'origins'/filename).read_text()))
        old=funcs((H/'origins/matched-driver.py').read_text());new=funcs((H/'matched-driver.py').read_text())
        for name in ['native_trial','configs','final_dataset','observe_client','fresh_drain','allocator_provenance','summary_from_report']:
            self.assertEqual(old[name],new[name],name)
        argument_sha=hashlib.sha256((H/'driver-arguments.json').read_bytes()).hexdigest()
        self.assertIn("invocation['driver_arguments_sha256']=='"+argument_sha+"'",SOURCE)
        self.assertNotIn('--redis-client-build',json.loads((H/'driver-arguments.json').read_text()))
if __name__=='__main__':unittest.main(verbosity=2)
