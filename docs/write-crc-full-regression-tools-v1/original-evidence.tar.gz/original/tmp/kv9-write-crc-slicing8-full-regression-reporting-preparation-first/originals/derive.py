#!/usr/bin/env python3
"""Finite statistics from the accepted complete72 ThinLTO compressed-retention campaign."""
if not __debug__:
    raise SystemExit('Python assertions must be enabled')
import argparse
import hashlib
import json
from pathlib import Path
from core import aggregate, add_maps, compare, merge_histograms, phase_accounting, qtext
from gates import AUDIT, WORKLOADS, accepted_cases, frozen_inputs, terminal_receipts, report_binding, scalar

HERE=Path(__file__).parent
parser=argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
parser.add_argument('--timing-receipt',type=Path,required=True)
parser.add_argument('--audit-receipt',type=Path,required=True)
parser.add_argument('--root-session',type=int,required=True)
parser.add_argument('--expected-audit-sha256',required=True)
parser.add_argument('--expected-inventory-sha256',required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
assert not args.output.exists(), 'fresh statistics output required'
OUTPUT=args.output
inputs={};raw_inputs={}
def read(path,decode=True):
    if str(path) not in raw_inputs:raw_inputs[str(path)]=path.read_bytes()
    raw=raw_inputs[str(path)]
    inputs[str(path)]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    return json.loads(raw) if decode else raw

def save(name,value):
    with (OUTPUT/name).open('x') as f:
        json.dump(value,f,indent=2);f.write('\n')

protocol,commands=frozen_inputs(read)
gate=read(args.audit_receipt);timing=read(args.timing_receipt)
terminal_receipts(timing,gate,args.root_session,commands)
audit=read(AUDIT/'audit.json');inventory=read(AUDIT/'input-inventory.json')
assert inputs[str(AUDIT/'audit.json')]['sha256']==args.expected_audit_sha256
assert inputs[str(AUDIT/'input-inventory.json')]['sha256']==args.expected_inventory_sha256
accepted_cases(audit,protocol,args.root_session)
reports={};cases=[]
for case in audit['cases']:
    path=Path(case['directory'])/'run/report.json';report=read(path)
    report_binding(path,raw_inputs[str(path)],inventory,case)
    coverage=Path(case['directory'])/'resource-coverage.json'
    report['_accepted_cpu']=read(coverage)['cpu'];report_binding(coverage,raw_inputs[str(coverage)],inventory)
    for i,operation in enumerate(report['metrics']['measurement']['statistics']):
        assert merge_histograms(p['whole_call']['raw'] for p in operation['populations'])==case['operations'][i]['whole_call_latency']
    assert merge_histograms(p['whole_call']['raw'] for o in report['metrics']['measurement']['statistics'] for p in o['populations'])==case['whole_call_latency']
    reports[case['ordinal']]=report
    row={k:case[k] for k in ['ordinal','repeat','concurrency','arm','workload','read_api','write_api','batch_size','read_percent','directory','report_sha256','all_success_single_attempt']}
    row['role']=case['arm'].split('-',1)[0]
    row['order']='forward' if row['repeat']==0 else 'reverse'
    row['server_memory']=case['server_memory']
    row.update(aggregate([case],[report]))
    row['phases']={name:phase_accounting(metric,row['role']!='redis') for name,metric in report['metrics'].items()}
    row['connection_attempts']=case['connection_attempts'];row['connection_failures']=case['connection_failures']
    row['terminal_rpc_codes']=case['terminal_rpc_codes']
    cases.append(row)

pooled=[];pairs=[];pooled_pairs=[]
def comparisons(selected):
    result={}
    for baseline in ['old','redis']:
        reference,candidate=selected[baseline],selected['new']
        result[baseline]=dict(combined=compare(reference,candidate),
            candidate_qps_divided_by_reference=candidate['completed_calls_per_second']/reference['completed_calls_per_second'],
            operations=[dict(api_class='read' if i==0 else 'write',
                             reference_api=reference['operations'][i]['operation'],
                             candidate_api=candidate['operations'][i]['operation'],
                             comparison=compare(reference['operations'][i],candidate['operations'][i])) for i in (0,1)])
    return result
for c in [1,64]:
    for w in WORKLOADS:
        for role in ['old','new','redis']:
            selected=[row for row in cases if (row['concurrency'],row['workload'],row['role'])==(c,w,role)]
            assert len(selected)==2 and {r['repeat'] for r in selected}=={0,1}
            indices=[r['ordinal'] for r in selected]
            row={k:selected[0][k] for k in ['concurrency','workload','role','read_api','write_api','batch_size','read_percent']}
            row.update(aggregate([audit['cases'][i] for i in indices],[reports[i] for i in indices]))
            row['source_ordinals']=indices;pooled.append(row)
        for repeat in [0,1]:
            selected={r['role']:r for r in cases if (r['concurrency'],r['workload'],r['repeat'])==(c,w,repeat)}
            assert set(selected)=={'old','new','redis'}
            pairs.append(dict(concurrency=c,workload=w,repeat=repeat,candidate_vs=comparisons(selected)))
        selected={r['role']:r for r in pooled if (r['concurrency'],r['workload'])==(c,w)}
        pooled_pairs.append(dict(concurrency=c,workload=w,candidate_vs=comparisons(selected)))

totals={k:sum(row[k] for row in cases) for k in ['calls','input_items','issued','attempts','dropped_slots']}
for key in ['outcomes','reasons','attempt_reasons']:
    totals[key]=add_maps(row[key] for row in cases)
totals['connection_attempts']=sum(r['connection_attempts'] or 0 for r in cases)
totals['connection_failures']=sum(r['connection_failures'] or 0 for r in cases)
totals['terminal_rpc_codes']=[sum((r['terminal_rpc_codes'] or [0]*17)[i] for r in cases) for i in range(17)]
phase_totals={}
for phase in ['initialization','warmup','measurement','verification']:
    selected=[row['phases'][phase] for row in cases]
    phase_totals[phase]={key:sum(r[key] for r in selected) for key in ['calls','input_items','attempts','extra_attempts']}
    for key in ['outcomes','reasons','attempt_reasons']:
        phase_totals[phase][key]=add_maps(r[key] for r in selected)
checks={k:audit[k] for k in ['successful_arms','owned_lifetimes_exited','role_source_file_checks','resource_samples','qualifying_drains','voter_writer_listener_bindings','retained_files','retained_bytes','outer_restoration']}
result=dict(complete=True,protocol_id=audit['protocol_id'],cases=cases,pooled=pooled,pairs=pairs,pooled_pairs=pooled_pairs,
    totals=totals,phase_totals=phase_totals,checks=checks,performance_promotion=False,
    scope='Complete72 point1/batch64 read0/50/100 c1/c64 cohorts; two 10-second forward/reverse repetitions. Separate36-cohort smoke is excluded from timing. No significance, equal-durability or sustained-capacity claim.',
    original_audit_scope=audit['scope'],scope_wording_note='Statistics cover only this exact new accepted72 campaign. The independent audit additionally verifies smoke/timing byte retention; historical24/72 reports are never pooled. Compression follows writer reaping between cohorts; longer inter-cohort gaps can affect cache/thermal state.',
    method='Completed QPS = summed completed calls / summed complete cohort elapsed seconds; successful QPS uses summed successes. Pooled pooled mean = summed whole-call nanoseconds / count. p50/p95/p99 merge original histogram buckets and use ceil(count*percent/100). Mixed read and write each use their own histogram population and the full cohort duration as rate denominator. No percentile averages.',
    source_revisions={'crc':'ca0002c7f8e9ee6f595efcc9f4151085ccce87cb','thin-lto':'02d0c01024b65a84b220c6948ff2224bfa7900bc','native_redis_clients':'0be806d9671e2c50701a64aa7889c8859b7648ba'},
    parent_terminal_receipts={'timing':{'path':str(args.timing_receipt),'record':timing},'audit':{'path':str(args.audit_receipt),'record':gate}})
result['accepted_audit_sha256']=args.expected_audit_sha256
result['accepted_inventory_sha256']=args.expected_inventory_sha256
result['memory_comparison']=audit['memory_comparison']
result['compressed_retention']=audit['compressed_retention']
result['all_success_single_attempt']=audit['all_success_single_attempt']
result['api_accounting_totals']=[]
for role in ['old','new','redis']:
    for api in sorted({op['operation'] for r in cases if r['role']==role for op in r['operations']}):
        ops=[op for r in cases if r['role']==role for op in r['operations'] if op['operation']==api]
        result['api_accounting_totals'].append(dict(role=role,operation=api,
            **{k:sum(op[k] for op in ops) for k in ['calls','input_items','attempts']},
            **{k:add_maps(op[k] for op in ops) for k in ['outcomes','reasons','attempt_reasons']},
            scope='Accounting across workload cells, not an aggregate throughput comparison'))
OUTPUT.mkdir(exist_ok=False)
save('summary.json',result)
save('input-hashes.json',dict(inputs=inputs,arithmetic_core_sha256=hashlib.sha256((HERE/'core.py').read_bytes()).hexdigest(),
    reader_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),gates_sha256=hashlib.sha256((HERE/'gates.py').read_bytes()).hexdigest()))

def table(rows,operations=False,repeat=False):
    lines=['| c | Workload | Role | '+('Repeat / order | ' if repeat else '')+('API | ' if operations else '')+'Completed calls | Success calls/s | Completed calls/s | Success items/s | Mean µs | p50 µs | p95 µs | p99 µs |',
           '|---:|---|---|'+('---|' if repeat else '')+('---|' if operations else '')+'---:|---:|---:|---:|---:|---|---|---|']
    for r in rows:
        for item in r['operations'] if operations else [r]:
            hist=item['whole_call_latency']
            cells=[str(r['concurrency']),r['workload'],{'old':'CRC','new':'ThinLTO','redis':'Redis'}[r['role']]]
            if repeat:cells.append(str(r['repeat'])+' / '+r['order'])
            if operations:cells.append(item['operation'])
            cells += [str(item['calls']),scalar(item['successful_calls_per_second']),scalar(item['completed_calls_per_second']),
                      scalar(item['successful_input_items_per_second']),scalar(hist['mean_ns'],1000),qtext(hist,50),qtext(hist,95),qtext(hist,99)]
            lines.append('| '+' | '.join(cells)+' |')
    return lines

lines=['# ThinLTO complete workload matrix','',result['scope'],'',
       'All72 cases and both orders are retained. CRC is the selected byte-table server; ThinLTO changes release codegen only. Native point calls use GET/PUT and batch calls use BatchGet/BatchPut(64); Redis uses actual GET/SET or MGET/MSET. KV9 uses three voters and normal quorum/sync calls on volatile tmpfs WAL; Redis is standalone memory with persistence disabled. These writes do not have equal durability.','',
       'Rates divide summed successful/completed calls or input items by summed complete cohort elapsed time. Means are sum/count. Quantiles merge raw histogram buckets and retain intervals. Whole-batch latency is never divided by64. Inactive operations remain visible with count0 and undefined quantiles.','',
       '## Pooled calls','',*table(pooled),'','## Every API, separately pooled','',*table(pooled,operations=True),'',
       '## Paired comparisons','',
       '| c | Workload | Successful QPS vs CRC | Mean vs CRC | Successful QPS vs Redis | Mean vs Redis |',
       '|---:|---|---:|---:|---:|---:|']
for r in pooled_pairs:
    old=r['candidate_vs']['old']['combined'];redis=r['candidate_vs']['redis']['combined']
    lines.append('| '+' | '.join([str(r['concurrency']),r['workload'],scalar(old['successful_qps_change_percent']),scalar(old['mean_change_percent']),scalar(redis['successful_qps_change_percent']),scalar(redis['mean_change_percent'])])+' |')
lines += ['', 'Comparison values are percentages. Complete per-operation and per-repeat p95/p99 intervals versus CRC and Redis are preserved in summary.json; PER-REPEAT.md shows both orders directly. No percentile averages or automatic promotion.','',
          f"Measured totals: {totals['calls']:,} completed calls / {totals['issued']:,} issued / {totals['attempts']:,} attempts / {totals['dropped_slots']:,} dropped slots. Success={totals['outcomes'].get('success',0):,}. All outcome/reason/attempt populations and all initialization/warmup/measurement/verification accounting remain in summary.json. Single-attempt suitability refers to measured calls only, not setup routing retries.",'',
          '## CPU estimates','',
          '| c | Workload | Role | Client cores | Server cores |', '|---:|---|---|---:|---:|']
for r in pooled:
    lines.append(f"| {r['concurrency']} | {r['workload']} | {r['role']} | {r['client_cpu_cores']:.3f} | {r['server_cpu_cores']:.3f} |")
lines += ['', 'CPU estimates use accepted resource-coverage sample durations as weights. They are not exclusively measurement-window service time and CPU/QPS is not proven per-request CPU. Exact per-process sample durations remain in summary.json.','',
          '## Accepted per-repeat memory comparison','',
          '| c | Workload | Repeat | CRC sampled mean RSS bytes | ThinLTO sampled mean RSS bytes | CRC summed HWM bytes | ThinLTO summed HWM bytes |',
          '|---:|---|---:|---:|---:|---:|---:|']
for r in audit['memory_comparison']:
    old=r['aggregate_voters']['old'];new=r['aggregate_voters']['new']
    lines.append(f"| {r['concurrency']} | {r['workload']} | {r['repeat']} | {old['sampled_mean_rss_bytes']:.3f} | {new['sampled_mean_rss_bytes']:.3f} | {old['summed_hwm_bytes']} | {new['summed_hwm_bytes']} |")
lines += ['', 'Memory rows preserve the accepted voter samples. HWM includes setup; summed voter high waters need not coincide. No pooled HWM is invented. Per-voter PID/start identities and Redis memory rows remain in each case.','',
          f"Acceptance: {checks['successful_arms']} cohorts, {checks['owned_lifetimes_exited']} exited lifetimes, {checks['qualifying_drains']} drains and {checks['voter_writer_listener_bindings']} voter/listener bindings. Logical original retained files={checks['retained_files']}, logical original bytes={checks['retained_bytes']:,}. These are not physical object bytes. The accepted compressed_retention record separately reports compressed bytes, unique allocated bytes across smoke+timing and complete independent byte decoding; it is copied verbatim into summary.json.",'',
          result['scope_wording_note'],'',
          'This reporting pass reads accepted audit/metadata and client reports only. It does not rerun the full audit or decode compressed WAL objects. The exact audited object inventory remains in the original independent results; all new reporting inputs and frozen helpers receive byte hashes in input-hashes.json.']
with (OUTPUT/'README.md').open('x') as f:f.write('\n'.join(lines)+'\n')
with (OUTPUT/'PER-REPEAT.md').open('x') as f:f.write('\n'.join(['# Every original repetition','',*table(cases,repeat=True),'','## Every API in every repetition','',*table(cases,operations=True,repeat=True)])+'\n')
print(json.dumps(dict(complete=True,cases=len(cases),pooled_rows=len(pooled),paired_repeats=len(pairs),output=str(OUTPUT),totals=totals)))
