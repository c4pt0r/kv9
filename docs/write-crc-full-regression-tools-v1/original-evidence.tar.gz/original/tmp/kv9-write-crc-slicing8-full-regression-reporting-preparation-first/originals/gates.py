"""Finite identity/terminal/schedule checks for this one pending campaign."""
import hashlib, json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PREP=Path('/tmp/kv9-thin-lto-compressed-performance-preparation-first')
RUN=Path('/tmp/kv9-thin-lto-compressed-performance-timing-first/cohorts')
AUDIT=PREP/'results-first'
PROTOCOL='kv9-thin-lto-compressed-broad-workloads-c1-c64-v1'
WORKLOADS=['point-r000','point-r050','point-r100','batch64-r000','batch64-r050','batch64-r100']

def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(raw):return dict(bytes=len(raw),sha256=sha(raw))
def same_pin(raw,expected):assert pin(raw)=={k:expected[k] for k in ('bytes','sha256')},'exact input bytes differ'

def frozen_inputs(read):
    frozen=read(HERE/'frozen-inputs.json')
    for original,entry in frozen['files'].items():
        for path in (Path(original),HERE/entry['copy']):
            raw=read(path,decode=False);same_pin(raw,entry)
    assert sha((HERE/'core.py').read_bytes())==frozen['core_sha256']=='827110ec99b2ae82f042e40fc81844263eefe4c484680ef6d8ab54653515b17f'
    protocol=read(PREP/'protocol.json');assert protocol['protocol_id']==PROTOCOL
    assert len(protocol['timed_inventory'])==72 and len(protocol['smoke_inventory'])==36
    assert protocol['driver_sha256']==frozen['files'][str(PREP/'matched-driver.py')]['sha256']
    assert protocol['auditor_sha256']==frozen['files'][str(PREP/'audit.py')]['sha256']
    return protocol,read(PREP/'commands.json')

def suffix(argv,script):
    assert isinstance(argv,list) and argv.count(str(script))==1,'receipt executable identity differs'
    return argv[argv.index(str(script)):]

def terminal_receipts(timing,gate,session,commands):
    assert type(session)is int and session>0
    for rec in (timing,gate):
        assert rec['complete'] is True and rec['exit_code']==0,'actual terminal exit required'
        assert type(rec['started_ns'])is int and rec['started_ns']<rec['ended_ns'],'terminal interval differs'
        assert rec.get('reaped',True) is True
    assert timing['ended_ns']<=gate['started_ns'],'audit must follow terminal timing'
    expected=[str(session) if s=='ROOT_TERMINAL_TIMING_SESSION' else s for s in commands['audit_only_after_terminal_timing']]
    assert suffix(gate['argv'],PREP/'audit.py')==suffix(expected,PREP/'audit.py'),'exact independent audit argv differs'
    assert suffix(timing['argv'],PREP/'isolate-and-run.py')==suffix(commands['timing_root_only_after_smoke_and_capacity_release'],PREP/'isolate-and-run.py'),'exact timing argv differs'

def accepted_cases(audit,protocol,session):
    assert audit['complete'] is True and audit['matched_diagnostic_accepted'] is True
    assert audit['protocol_id']==PROTOCOL and audit['parent_confirmed_session']==session and audit['parent_confirmed_exit_code']==0
    assert audit['successful_arms']==audit['expected_successful_arms']==len(audit['cases'])==72,'complete72 only'
    assert (audit['owned_lifetimes_exited'],audit['qualifying_drains'],audit['voter_writer_listener_bindings'])==(240,144,144)
    assert audit['outer_restoration']['accepted'] is True
    retention=audit['compressed_retention']
    assert retention['independently_decoded_all_bytes'] is True and retention['resident_original_paths'] is False
    assert len(retention['cohorts'])==48
    for ordinal,(case,desc) in enumerate(zip(audit['cases'],protocol['timed_inventory'])):
        expected=dict(ordinal=ordinal,repeat=desc['repeat'],concurrency=desc['shared']['workers'],arm=desc['arm'],
                      workload=desc['workload'],read_api=desc['read_api'],write_api=desc['write_api'],
                      batch_size=desc['shared']['batch_size'],read_percent=desc['shared']['read_percent'],
                      directory=str(RUN/f"{ordinal:03d}-{desc['arm']}-{desc['shared']['run_id']}"))
        assert {k:case[k] for k in expected}==expected,'case identity/order/root differs'

def report_binding(path,raw,inventory,case=None):
    assert path.is_relative_to(RUN),'historical/smoke input excluded'
    same_pin(raw,inventory[str(path)])
    if case is not None:assert sha(raw)==case['report_sha256'],'audit report hash differs'

def scalar(value,scale=1):return '—' if value is None else f'{value/scale:.3f}'
