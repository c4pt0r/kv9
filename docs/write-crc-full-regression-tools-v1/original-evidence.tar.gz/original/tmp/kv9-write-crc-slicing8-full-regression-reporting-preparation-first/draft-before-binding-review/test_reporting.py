"""Tiny synthetic reporting controls; no original campaign, process, codec or source audit."""
import copy
import hashlib
import unittest
from pathlib import Path
import core
import gates
import report
from cpu import cpu_from_samples, bucket_direction

OUTCOMES = ['success', 'refused', 'unknown_write', 'read_failure', 'client_rejected']


def raw_hist(values):
    buckets = [0] * 3776
    for value in values:
        # These deliberately exact low buckets are independently inspectable test data.
        assert 0 <= value < 128
        buckets[value] += 1
    return dict(count=len(values), sum_ns=sum(values), buckets=buckets)


def sample(reads, writes, elapsed=10**9, batch=1, errors=(), ordinal=0, cpu=1.0):
    statistics = []
    for index, values in enumerate((reads, writes)):
        populations = []
        for outcome in OUTCOMES:
            chosen = list(errors) if index == 1 and outcome == 'unknown_write' else list(values) if outcome == 'success' else []
            populations.append(dict(calls=len(chosen), input_items=len(chosen)*batch,
                completed_before_cutoff=len(chosen), whole_call=dict(raw=raw_hist(chosen))))
        statistics.append(dict(populations=populations, reasons=[len(values), len(errors) if index else 0],
            attempt_reasons=[len(values), len(errors) if index else 0], rpc_codes=[0]*17))
    metrics = dict(operations=['get', 'put'] if batch == 1 else ['batch_get', 'batch_put'],
        outcomes=OUTCOMES, reasons=['success', 'deadline'], statistics=statistics)
    accounted = core.phase_accounting(metrics, True)
    case = {k: accounted[k] for k in ('calls', 'input_items', 'attempts', 'outcomes', 'reasons', 'attempt_reasons')}
    case.update(ordinal=ordinal, operations=accounted['operations'], cohort_elapsed_ns=elapsed,
        issued=accounted['calls'], dropped_slots=0, all_success_single_attempt=not errors)
    for index, op in enumerate(case['operations']):
        op['whole_call_latency'] = core.merge_histograms(x['whole_call']['raw'] for x in statistics[index]['populations'])
    case['whole_call_latency'] = core.merge_histograms(x['whole_call']['raw'] for op in statistics for x in op['populations'])
    case['successful_whole_call_latency'] = core.merge_histograms(op['populations'][0]['whole_call']['raw'] for op in statistics)
    r = dict(cohort_elapsed_ns=elapsed, measured_completed=case['calls'], measured_issued=case['issued'], dropped_slots=0,
        metrics={phase:copy.deepcopy(metrics) for phase in ('initialization', 'warmup', 'measurement', 'verification')},
        _accepted_cpu={name:dict(cpu_cores=cpu, sample_seconds=elapsed/10**9) for name in ('client', 'voter-1', 'voter-2', 'voter-3')})
    return case, r


def protocol():
    return dict(protocol_id=gates.PROTOCOL, server_pins=copy.deepcopy(gates.SERVER_PINS),
        client_revision=gates.CLIENT_REV, client_pins={'client':copy.deepcopy(gates.CLIENT_PIN)},
        timed_inventory=gates.descriptors(), smoke_inventory=gates.descriptors(True))


def accepted_audit():
    return dict(complete=True, matched_diagnostic_accepted=True, protocol_id=gates.PROTOCOL,
        parent_confirmed_session=7, parent_confirmed_exit_code=0, successful_arms=48,
        expected_successful_arms=48, cases=[gates.expected_case(i, d) for i, d in enumerate(gates.descriptors())],
        owned_lifetimes_exited=192, qualifying_drains=144, voter_writer_listener_bindings=144,
        performance_promotion=False, outer_restoration=dict(accepted=True),
        smoke=dict(owned_lifetimes_exited=96, cases=[dict(target=d['server_role'],
            directory=str(gates.SMOKE/f"{i:03d}-{d['arm']}-{d['shared']['run_id']}"))
            for i, d in enumerate(gates.descriptors(True))]),
        compressed_retention=dict(independently_decoded_all_bytes=True, resident_original_paths=False,
            cohorts=[{} for _ in range(48)], smoke_byte_retention=[{} for _ in range(24)]))


class Arithmetic(unittest.TestCase):
    def test_count_weighted_mean_and_merged_percentiles(self):
        a, ar = sample([10], [], ordinal=0)
        b, br = sample([20]*9, [], elapsed=3*10**9, ordinal=1)
        got = report.aggregate_group([a, b], [ar, br])
        self.assertEqual(got['whole_call_latency']['mean_ns'], 19)
        self.assertNotEqual(got['whole_call_latency']['mean_ns'], 15)
        for q in ('p50', 'p95', 'p99'):
            self.assertEqual(got['whole_call_latency'][q], dict(lower_ns=20, upper_ns=20))
        self.assertEqual(got['completed_calls_per_second'], 2.5)

    def test_mixed_operation_rates_use_full_interval_and_separate_histograms(self):
        a, ar = sample([5, 5], [100], elapsed=2*10**9)
        b, br = sample([10], [110, 110, 110], elapsed=4*10**9, ordinal=1)
        got = report.aggregate_group([a, b], [ar, br])
        read, write = got['operations']
        self.assertEqual(read['calls'], 3); self.assertEqual(write['calls'], 4)
        self.assertEqual(read['completed_calls_per_second'], 0.5)
        self.assertEqual(write['completed_calls_per_second'], 4/6)
        self.assertEqual(read['whole_call_latency']['sum_ns'], 20)
        self.assertEqual(write['whole_call_latency']['sum_ns'], 430)
        self.assertEqual(got['whole_call_latency']['sum_ns'], 450)
        self.assertEqual(got['whole_call_latency']['count'], 7)

    def test_empty_operation_populations_remain_unavailable(self):
        for reads, writes, inactive in [([10], [], 1), ([], [20], 0)]:
            a, r = sample(reads, writes)
            got = report.aggregate_group([a], [r]); op = got['operations'][inactive]
            self.assertEqual(op['calls'], 0); self.assertEqual(op['completed_calls_per_second'], 0)
            self.assertFalse(op['latency_available'])
            self.assertEqual(op['whole_call_latency'], dict(count=0, sum_ns=0, mean_ns=None, p50=None, p95=None, p99=None))
            change = report.measurement_comparison(op, op)
            self.assertIsNone(change['mean_change_percent'])
            self.assertIsNone(change['successful_qps_change_percent'])
            self.assertEqual(change['quantile_directions']['p99'], 'unavailable')

    def test_batch_items_do_not_divide_whole_call_latency(self):
        a, r = sample([64], [108], batch=64)
        got = report.aggregate_group([a], [r])
        self.assertEqual(got['input_items'], 128)
        self.assertEqual(got['operations'][1]['successful_input_items_per_second'], 64)
        self.assertEqual(got['operations'][1]['whole_call_latency']['mean_ns'], 108)

    def test_failed_write_population_and_attempts_are_retained(self):
        a, r = sample([5], [10], errors=[120])
        got = report.aggregate_group([a], [r])
        self.assertEqual(got['calls'], 3); self.assertEqual(got['attempts'], 3)
        self.assertEqual(got['outcomes']['unknown_write'], 1)
        self.assertEqual(got['operations'][1]['outcome_latency']['unknown_write']['mean_ns'], 120)
        self.assertEqual(got['operations'][1]['successful_whole_call_latency']['mean_ns'], 10)
        self.assertFalse(got['healthy_comparison_eligible'])

    def test_cpu_weighting_and_bucket_directions(self):
        a, ar = sample([1], [], cpu=1)
        b, br = sample([1], [], cpu=3, elapsed=3*10**9, ordinal=1)
        self.assertEqual(report.aggregate_group([a, b], [ar, br])['client_cpu_cores'], 2.5)
        self.assertEqual(bucket_direction(dict(lower_ns=100, upper_ns=110), dict(lower_ns=100, upper_ns=110)), 'same_bucket')
        self.assertEqual(bucket_direction(dict(lower_ns=100, upper_ns=110), dict(lower_ns=90, upper_ns=99)), 'new_lower_interval')
        self.assertEqual(bucket_direction(dict(lower_ns=100, upper_ns=110), dict(lower_ns=105, upper_ns=115)), 'overlapping_intervals')

    def test_unused_operation_and_audit_histogram_mismatch_rejected(self):
        a, r = sample([1], [2]); desc = gates.descriptors()[0]
        with self.assertRaises(AssertionError): report.measurement_gate(a, r, desc)
        desc = next(x for x in gates.descriptors() if x['shared']['read_percent'] == 50)
        report.measurement_gate(a, r, desc)
        a['operations'][0]['whole_call_latency']['sum_ns'] += 1
        with self.assertRaises(AssertionError): report.measurement_gate(a, r, desc)


class Gates(unittest.TestCase):
    def test_complete_exact_two_orders_accept(self):
        gates.accepted_cases(accepted_audit(), protocol(), 7)
        forward = gates.descriptors()[:24]; reverse = gates.descriptors()[24:]
        self.assertEqual([x['arm'] for x in reverse], [x['arm'] for x in reversed(forward)])
        self.assertEqual(len(gates.descriptors(True)), 24)

    def test_wrong_role_source_or_extra_role_rejected(self):
        for change in ('swap', 'extra', 'client'):
            p = protocol()
            if change == 'swap': p['server_pins']['old'], p['server_pins']['new'] = p['server_pins']['new'], p['server_pins']['old']
            elif change == 'extra': p['server_pins']['redis'] = {}
            else: p['client_revision'] = 'historical-other-client'
            with self.subTest(change=change), self.assertRaises(AssertionError): gates.accepted_cases(accepted_audit(), p, 7)

    def test_missing_duplicate_reordered_or_historical_cohort_rejected(self):
        for change in ('missing', 'duplicate', 'reorder', 'historical'):
            a = accepted_audit()
            if change == 'missing': a['cases'].pop()
            elif change == 'duplicate': a['cases'][1] = copy.deepcopy(a['cases'][0])
            elif change == 'reorder': a['cases'][0], a['cases'][1] = a['cases'][1], a['cases'][0]
            else: a['cases'][0]['directory'] = '/tmp/historical/000'
            with self.subTest(change=change), self.assertRaises(AssertionError): gates.accepted_cases(a, protocol(), 7)

    def test_wrong_smoke_count_lifetimes_drains_or_restoration_rejected(self):
        for change in ('smoke', 'lifetimes', 'drains', 'restoration', 'partial'):
            a = accepted_audit()
            if change == 'smoke': a['smoke']['cases'].pop()
            elif change == 'lifetimes': a['owned_lifetimes_exited'] = 191
            elif change == 'drains': a['qualifying_drains'] = 143
            elif change == 'restoration': a['outer_restoration']['accepted'] = False
            else: a['complete'] = False
            with self.subTest(change=change), self.assertRaises(AssertionError): gates.accepted_cases(a, protocol(), 7)

    def test_missing_changed_or_outside_report_binding_rejected(self):
        path = gates.RUN/'000-old-point-r000-p00001/run/report.json'; data = b'{}'
        pin = dict(bytes=2, sha256=hashlib.sha256(data).hexdigest()); inventory = {str(path):pin}
        gates.report_binding(path, data, inventory, dict(report_sha256=pin['sha256']))
        with self.assertRaises(AssertionError): gates.report_binding(path, b'{ }', inventory)
        with self.assertRaises(KeyError): gates.report_binding(path, data, {})
        with self.assertRaises(AssertionError): gates.report_binding(Path('/tmp/old/report.json'), data, inventory)


if __name__ == '__main__': unittest.main()
