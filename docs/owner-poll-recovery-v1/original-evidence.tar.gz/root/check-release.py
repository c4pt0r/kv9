from pathlib import Path
import hashlib,json,subprocess,shlex
root=Path('/tmp/kv9-owner-poll-root-first');source=Path('/tmp/kv9-bounded-owner-poll');release=Path('/tmp/kv9-owner-poll-release-first');checks=Path('/tmp/kv9-owner-poll-read-stage-corrected-first')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((release/'build.json').read_text());w=json.loads((release/'workload/build.json').read_text());c=json.loads((release/'cache-safety.json').read_text())
rev=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
assert rev==m['revision']==w['revision'] and not m['dirty'] and not w['dirty']
qualified=json.loads((source/'docs/owner-poll-source-v1/qualification.json').read_text());assert qualified['complete']
checked=json.loads((checks/'sources-after.json').read_text())['sources']
deltas={name for name in set(checked)|set(m['sources']) if checked.get(name)!=m['sources'].get(name)}
assert deltas and all(name.startswith('docs/') for name in deltas),deltas
assert all(m['sources'].get(name)==digest for name,digest in checked.items() if not name.startswith('docs/'))
checked=m['sources']
assert all(sha(source/name)==digest for name,digest in checked.items())
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':')).encode()
assert hashlib.sha256(canonical(checked)).hexdigest()==m['source_tree_sha256']==w['source_tree_sha256']
assert m['workload_build_sha256']==sha(release/'workload/build.json')
assert m['binaries']['kv9']['sha256']==sha(release/'kv9')
assert w['binary_sha256']==sha(release/'workload/kv9-batch-workload')
assert c['complete'] and c['invalidation_complete'] and c['source_root']==str(source)
first=[a for a in c['first_party_artifacts'] if not a['seen_after_invalidation']];assert first and all(not a['fresh'] for a in first)
observed=[]
for log in [release/'kv9-cargo.jsonl',release/'workload/cargo.jsonl']:
 rows=[json.loads(line) for line in log.read_text().splitlines()];assert rows[-1]=={'reason':'build-finished','success':True}
 for a in rows:
  if a.get('reason')=='compiler-artifact' and str(source) in a['package_id']:
   assert a['features']==[],a['features'];observed.append(a)
assert observed
links=[]
for log,crate in [(release/'kv9-build.log','kv9'),(release/'workload/build.log','kv9_batch_workload')]:
 commands=[]
 for line in log.read_text().splitlines():
  stripped=line.strip()
  if stripped.startswith('Running `') and stripped.endswith('`'):
   args=shlex.split(stripped[len('Running `'):-1])
   if '--crate-name' in args and args[args.index('--crate-name')+1]==crate and '--test' not in args:
    commands.append(args)
 assert len(commands)==1,(str(log),len(commands))
 args=commands[0];codegen=[args[i+1] for i,v in enumerate(args[:-1]) if v=='-C']
 assert 'lto=thin' in codegen and 'codegen-units=1' in codegen and 'opt-level=3' in codegen
 assert not any(x.startswith(('panic=','target-cpu=','target-feature=')) for x in codegen)
 assert '--target' not in args
 cfg_cmd=[args[0],'--print','cfg','-C','opt-level=3','-C','lto=thin','-C','codegen-units=1']
 cfg=subprocess.check_output(cfg_cmd,cwd=source,text=True)
 assert 'panic="unwind"' in cfg.splitlines() and 'debug_assertions' not in cfg.splitlines()
 links.append(dict(crate=crate,log=str(log),log_sha256=sha(log),rustc_argv=args,cfg_argv=cfg_cmd,cfg=cfg,codegen=codegen))
(root/'production-codegen-verbose.json').write_text(json.dumps(links,indent=2)+'\n')
out=dict(complete=True,revision=rev,source_tree_sha256=m['source_tree_sha256'],server_sha256=sha(release/'kv9'),manifest_sha256=sha(release/'build.json'),cache_receipt_sha256=sha(release/'cache-safety.json'),workload_sha256=sha(release/'workload/kv9-batch-workload'),workload_manifest_sha256=sha(release/'workload/build.json'),first_observed_units=len(first),artifact_observations=len(c['first_party_artifacts']),default_feature_observations=len(observed),source_count=len(checked),rustc=m['rustc'],instrumentation_enabled=False,production_codegen_sha256=sha(root/'production-codegen-verbose.json'),panic='unwind',target_cpu='unchanged default target',lto='thin',codegen_units=1)
out['source_gate_receipt']=str(source/'docs/owner-poll-source-v1/qualification.json');out['source_gate_sha256']=sha(source/'docs/owner-poll-source-v1/qualification.json');out['documentation_changes_after_source_gate']=sorted(deltas)
(root/'release-readback.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
