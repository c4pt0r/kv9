#!/usr/bin/env python3
"""Run the frozen ordinary integration recovery or its terminal-only auditor."""
import argparse,hashlib,json,os,signal,subprocess,time
from pathlib import Path
R=Path('/tmp/kv9-owner-poll-root-first')
P=Path('/tmp/kv9-owner-poll-recovery-preparation-first')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def available():
 s=os.statvfs('/home/dongxu/kv9');return s.f_bavail*s.f_frsize
ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['recovery','audit']);a=ap.parse_args()
assert __debug__ and set(os.sched_getaffinity(0))<=set(range(6,16))|set(range(22,32))
assert 'TOKIO_WORKER_THREADS' not in os.environ
assert sha(P/'inventory.final.json')=='a0b9980902426480db9dc98bd0a83ce45a46020fdb471b2ab555d1fe67d21dd6'
for rel,pin in json.loads((P/'inventory.final.json').read_text()).items():
 p=P/rel;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],rel
assert json.loads((P/'binding.final.json').read_text())['ready'] is True
assert json.loads((R/'release-result.json').read_text())['complete'] is True
assert json.loads((R/'recovery-contracts-first/result.json').read_text())['complete'] is True
if a.stage=='audit':
 for path in [R/'recovery-result.json',R/'recovery-terminal.json',Path('/tmp/kv9-owner-poll-process-e2e-first/summary.json')]:
  assert json.loads(path.read_text())['complete'] is True,str(path)
commands=json.loads((P/'commands.json').read_text());key='process_after_source_release_binding' if a.stage=='recovery' else 'independent_audit_after_explicit_runtime_terminal'
cmd=commands[key];initial=available();floor=80*1024**3;ceiling=4*1024**3
assert initial-ceiling>=floor
r=dict(complete=False,argv=cmd,script_sha256=sha(Path(__file__)),commands_sha256=sha(P/'commands.json'),started_ns=time.time_ns(),initial_available_bytes=initial,minimum_available_bytes=floor,additional_consumption_ceiling_bytes=ceiling,timeout_seconds=600,samples=[])
p=None
try:
 with (R/(a.stage+'-first.log')).open('x') as log:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=p.pid
  save(R/(a.stage+'-invocation.json'),r)
  while True:
   free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
   if free<floor or initial-free>ceiling:raise RuntimeError('ordinary recovery/audit disk reservation exceeded')
   if time.time_ns()-r['started_ns']>600*10**9:raise TimeoutError('ordinary recovery/audit deadline exceeded')
   try:r['exit_code']=p.wait(timeout=5);r['reaped']=True;break
   except subprocess.TimeoutExpired:pass
  if r['exit_code']!=0:raise RuntimeError(a.stage+' failed')
 r['complete']=True
except BaseException as e:
 r['failure']=repr(e)
 if p is not None and p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  r['exit_code']=p.returncode;r['reaped']=True
 raise
finally:
 r['ended_ns']=time.time_ns();save(R/(a.stage+'-result.json'),r)
print('PASS: '+a.stage+' completed within its reservation')
