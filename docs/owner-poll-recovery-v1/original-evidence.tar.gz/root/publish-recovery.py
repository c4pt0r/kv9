from pathlib import Path
import hashlib,json,tarfile

ROOT=Path('/tmp/kv9-owner-poll-root-first')
MAIN=Path('/home/dongxu/kv9')
PREP=Path('/tmp/kv9-owner-poll-recovery-preparation-first')
RUN=Path('/tmp/kv9-owner-poll-process-e2e-first')
BUILD=Path('/tmp/kv9-owner-poll-release-first')
OUT=MAIN/'docs/owner-poll-recovery-v1'
def read(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')

assert read(ROOT/'release-terminal.json')['exit_code']==0
assert read(ROOT/'recovery-terminal.json')['exit_code']==0
assert read(ROOT/'audit-result.json')['complete']
a=read(PREP/'results-first/audit.json')
assert a['complete'] and a['accepted']
summary=dict(complete=True,revision=a['revision'],operations=sum(x['operations'] for x in a['cases']),
             outcomes={key:sum(x['outcomes'].get(key,0) for x in a['cases']) for key in ['ok','unknown']},
             fresh_drains=sum(x['fresh_drained_voters'] for x in a['cases']),
             server_lifetimes=a['server_lifetimes'],client_lifetimes=a['client_lifetimes'],
             release=read(ROOT/'release-readback.json'),
             recovery_terminal=dict(session=33692,receipt='ec0bb4',exit_code=0),
             audit_terminal=dict(receipt='789e8a',exit_code=0),
             scope='Default production build and ordinary local stream/unary atomic point/batch histories with leader loss and original-directory restart. No performance, actual Chaos Mesh, independent host or power-loss acceptance.')
OUT.mkdir();save(OUT/'summary.json',summary)
inputs={}
for label,directory in [('original-release',BUILD),('original-runtime',RUN),('recovery-preparation-and-audit',PREP)]:
    for p in sorted(directory.rglob('*')):
        assert not p.is_symlink(),str(p)
        if p.is_file():inputs[label+'/'+str(p.relative_to(directory))]=p
for p in sorted(ROOT.iterdir()):
    if p.is_file() and (p.name.startswith(('release-', 'recovery-', 'audit-', 'production-codegen'))
                        or p.name in ['run-release.py','check-release.py','run-recovery-stage.py','publish-recovery.py']):
        inputs['root/'+p.name]=p
for name in ['recovery-finalize-first','recovery-contracts-first']:
    for p in sorted((ROOT/name).rglob('*')):
        if p.is_file():inputs['root/'+name+'/'+str(p.relative_to(ROOT/name))]=p
rows=[dict(path=name,original_path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(inputs.items())]
assert len(rows)<2000 and sum(x['bytes'] for x in rows)<64*1024**2
archive=OUT/'original-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for row in rows:tar.add(row['original_path'],arcname=row['path'],recursive=False)
assert archive.stat().st_size<32*1024**2
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(rows)
    for member,row in zip(members,rows):
        assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']==sha(Path(row['original_path']))
save(OUT/'archive-inventory.json',dict(files=rows,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,original_bytes=sum(x['bytes'] for x in rows)))
print(json.dumps(dict(operations=summary['operations'],outcomes=summary['outcomes'],fresh_drains=summary['fresh_drains'],files=len(rows),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive))))
