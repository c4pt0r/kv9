#!/usr/bin/env python3
"""Root-invoked read-only release binding; emits only fresh preparation metadata."""
import argparse, hashlib, json, os
from pathlib import Path

HERE=Path(__file__).resolve().parent
REV='PENDING_COMMITTED_REVISION'
SOURCE=Path('/tmp/kv9-bounded-owner-poll')
BUILD=Path('/tmp/kv9-owner-poll-release-first')

def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p);b=p.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,value):
    with (HERE/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')

ap=argparse.ArgumentParser()
for name in ['release-readback','release-terminal','source-gate','production-codegen']:
    ap.add_argument('--'+name,type=Path,required=True)
    ap.add_argument('--'+name+'-sha256',required=True)
ap.add_argument('--root-session',type=int,required=True)
ap.add_argument('--root-tool-receipt',required=True)
args=ap.parse_args()
assert __debug__ and set(os.sched_getaffinity(0))<=set(range(6,16))|set(range(22,32))
assert args.root_session>0 and args.root_tool_receipt
assert 'TOKIO_WORKER_THREADS' not in os.environ
assert not (HERE/'binding.final.json').exists() and not (HERE/'commands.json').exists()
for rel,binding in read(HERE/'inventory.pending.json').items():
    assert pin(HERE/rel)==binding,rel
receipts={}
for key in ['release_readback','release_terminal','source_gate','production_codegen']:
    path=getattr(args,key);actual=pin(path)
    assert actual['sha256']==getattr(args,key+'_sha256'),key
    receipts[key]=dict(path=str(path),**actual)
r=read(args.release_readback);terminal=read(args.release_terminal);gate=read(args.source_gate)
assert r['complete'] is True and terminal['complete'] is True and terminal['exit_code']==0 and gate['complete'] is True
assert r['revision']==REV
assert r['instrumentation_enabled'] is False and r['lto']=='thin' and r['codegen_units']==1
assert r['panic']=='unwind' and r['target_cpu']=='unchanged default target'
assert r['production_codegen_sha256']==receipts['production_codegen']['sha256']
assert r['first_observed_units']==11 and r['default_feature_observations']==r['artifact_observations']
b=read(BUILD/'build.json');w=read(BUILD/'workload/build.json');s=read(BUILD/'workload/sources.json')
assert b['revision']==w['revision']==s['revision']==REV
assert b['dirty'] is False and w['dirty'] is False and s['dirty'] is False
assert b['profile']==w['profile']=='release'
assert b['sources']==s['sources'] and len(b['sources'])==r['source_count']
assert b['source_tree_sha256']==w['source_tree_sha256']==s['source_tree_sha256']==r['source_tree_sha256']
for rel,expected in b['sources'].items():
    assert pin(SOURCE/rel)['sha256']==expected,rel
assert b['binaries']['kv9']['command']==['cargo','build','--locked','--bin','kv9','--release','--message-format=json-render-diagnostics']
for rel,key in [('kv9','server_sha256'),('build.json','manifest_sha256'),('workload/kv9-batch-workload','workload_sha256'),('workload/build.json','workload_manifest_sha256'),('cache-safety.json','cache_receipt_sha256')]:
    assert pin(BUILD/rel)['sha256']==r[key],rel
assert b['binaries']['kv9']['sha256']==r['server_sha256'] and w['binary_sha256']==r['workload_sha256']
assert b['workload_build_sha256']==r['workload_manifest_sha256']
for name,binding in read(HERE/'source-helper-bindings.json')['helpers'].items():
    assert pin(SOURCE/'scripts'/name)=={k:binding[k] for k in ('bytes','sha256')}
binding=read(HERE/'binding.source-pinned.json')
assert not Path(binding['process_output']).exists() and not Path(binding['audit_output']).exists()
binding.update(ready=True,source_tree_sha256=r['source_tree_sha256'],source_file_count=r['source_count'],server_sha256=r['server_sha256'],workload_sha256=r['workload_sha256'],build_manifest_sha256=r['manifest_sha256'],workload_manifest_sha256=r['workload_manifest_sha256'],cache_receipt_sha256=r['cache_receipt_sha256'],root_release_terminal=dict(**receipts['release_terminal'],exit_code=0,root_reported_tool_session=args.root_session,tool_receipt=args.root_tool_receipt),original_source_gate_receipt=receipts['source_gate'],root_readback=receipts['release_readback'],production_codegen=receipts['production_codegen'],note='Exact original bounded-owner-poll release bound. Root owns ordinary recovery and independent terminal audit; no runtime acceptance inferred.')
save('binding.final.json',binding)
commands=read(HERE/'commands.source-pinned.json')
commands.update(candidate_bound=True,release_pending=False,templates_only=False,note='Original bounded-owner-poll release bound; root exclusively executes recovery/audit. All pending preparation retained.')
save('commands.json',commands)
save('binding-readback.json',dict(complete=True,revision=REV,receipts=receipts,source_files=len(b['sources']),source_helpers_unchanged=True,default_features_from_original_root_readback=True,production_codegen_from_original_root_readback=True,contracts_executed=False,runtime_executed=False))
save('READINESS.final.json',dict(preparation_complete=True,release_bound=True,runtime_executed=False,runtime_authorized=False,revision=REV,runner=pin(HERE/'process-runner.py'),auditor=pin(HERE/'audit.py'),commands=pin(HERE/'commands.json'),root_execution_required=True))
save('inventory.final.json',{str(p.relative_to(HERE)):pin(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='inventory.final.json'})
print(json.dumps(dict(complete=True,inventory=pin(HERE/'inventory.final.json'),commands=pin(HERE/'commands.json'),binding=pin(HERE/'binding.final.json')),indent=2))
