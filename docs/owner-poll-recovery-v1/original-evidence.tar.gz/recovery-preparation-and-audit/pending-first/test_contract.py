"""Pure preparation contracts. Authored only; root controls later execution."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent


class Contracts(unittest.TestCase):
    def test_wrapper_is_only_the_explicit_source_path_derivative(self):
        before = (HERE / 'fixtures/predecessor-process-runner.py').read_text()
        expected = before.replace("source=Path('/tmp/kv9-thin-lto-main-integration-first')",
                                  "source=Path('/tmp/kv9-bounded-owner-poll')")
        self.assertNotEqual(before, expected)
        self.assertEqual((HERE / 'process-runner.py').read_text(), expected)

    def test_independent_auditor_is_byte_identical(self):
        actual = hashlib.sha256((HERE / 'audit.py').read_bytes()).hexdigest()
        self.assertEqual(actual, '64aa248892c538c82ddbb1f2469dbefac8b2ad97f29dd2a04bfb58d44b1f6dc5')

    def test_pending_binding_cannot_be_mistaken_for_a_release(self):
        binding = json.loads((HERE / 'binding.pending.json').read_text())
        commands = json.loads((HERE / 'commands.pending.json').read_text())
        self.assertFalse(binding['ready'])
        for key in ('revision', 'source_tree_sha256', 'server_sha256',
                    'workload_sha256', 'build_manifest_sha256',
                    'workload_manifest_sha256', 'cache_receipt_sha256',
                    'root_release_terminal'):
            self.assertIsNone(binding[key], key)
        self.assertTrue(commands['templates_only'])
        self.assertFalse(commands['runtime_authorized'])
        audit = commands['independent_audit_after_explicit_runtime_terminal']
        self.assertEqual(audit[audit.index('--revision') + 1], 'PENDING_COMMITTED_REVISION')
        process = commands['process_after_source_release_binding']
        self.assertEqual(process[-4:], ['--build', binding['build'], '--output', binding['process_output']])
        self.assertNotIn('--features', process)

    def metric_validator(self):
        path = HERE / 'fixtures/check-latency-metrics.py'
        spec = importlib.util.spec_from_file_location('retained_metrics26', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_original_metrics26_remain_valid_with_uninterpreted_extension(self):
        validator = self.metric_validator()
        original = json.loads((HERE / 'fixtures/original-metrics.json').read_text())
        unchanged = copy.deepcopy(original)
        validator.validate(original)
        # Deliberately invalid diagnostic content demonstrates that this legacy
        # validator is NOT a validator of the historical optional diagnostic extension.
        extended = copy.deepcopy(original)
        extended['raft_request_body_handoff'] = {'deliberately': 'not a diagnostic snapshot'}
        validator.validate(extended)
        self.assertEqual(original, unchanged)

    def test_extension_does_not_hide_original_histogram_or_inventory_corruption(self):
        validator = self.metric_validator()
        original = json.loads((HERE / 'fixtures/original-metrics.json').read_text())
        bad_count = copy.deepcopy(original)
        bad_count['raft_request_body_handoff'] = []
        bad_count['metrics'][0]['latency']['outcomes'][0]['count'] += 1
        with self.assertRaisesRegex(AssertionError, 'histogram conservation failed'):
            validator.validate(bad_count)
        missing = copy.deepcopy(original)
        missing['raft_request_body_handoff'] = []
        missing['metrics'].pop()
        with self.assertRaisesRegex(AssertionError, 'metric inventory changed'):
            validator.validate(missing)


if __name__ == '__main__':
    unittest.main()
