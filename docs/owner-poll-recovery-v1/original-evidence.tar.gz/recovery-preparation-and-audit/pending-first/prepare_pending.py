#!/usr/bin/env python3
"""Copy retained ordinary recovery preparation; no helper/runtime imports."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil

P = Path(__file__).resolve().parent
O = Path('/tmp/kv9-thin-lto-main-integration-recovery-preparation-verbose-first')
SOURCE = '/tmp/kv9-bounded-owner-poll'
BUILD = '/tmp/kv9-owner-poll-release-first'
RUN = '/tmp/kv9-owner-poll-process-e2e-first'
H = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
subs = {
    str(O): str(P),
    '/tmp/kv9-thin-lto-main-integration-first': SOURCE,
    '/tmp/kv9-thin-lto-main-integration-release-verbose-first': BUILD,
    '/tmp/kv9-thin-lto-main-integration-process-e2e-first': RUN,
    '11113f68f6a5df77da1ffb4fcec850953716ffa3': 'PENDING_COMMITTED_REVISION',
    'main-integration': 'bounded-owner-poll',
}
def substitute(text):
    regex = re.compile('|'.join(map(re.escape, sorted(subs, key=len, reverse=True))))
    return regex.sub(lambda m: subs[m[0]], text)
(P/'originals').mkdir(); (P/'diffs').mkdir(); (P/'fixtures').mkdir()
names = ('process-runner.py', 'audit.py', 'test_contract.py', 'binding.pending.json',
         'commands.pending.json', 'scope-and-requirements.json', 'freeze_after_build.py',
         'freeze-after-build.pending.json', 'source-helper-bindings.json')
for name in names:
    shutil.copyfile(O/name, P/'originals'/name)
for name in ('process-runner.py', 'audit.py', 'binding.pending.json', 'commands.pending.json',
             'freeze_after_build.py', 'freeze-after-build.pending.json'):
    (P/name).write_text(substitute((O/name).read_text()))
test = (O/'test_contract.py').read_text()
test = test.replace("source=Path('/tmp/kv9-thin-lto-main-integration-first')", "source=Path('/tmp/kv9-bounded-owner-poll')")
test = test.replace("source=Path('/tmp/kv9-release-thin-lto')", "source=Path('/tmp/kv9-thin-lto-main-integration-first')")
(P/'test_contract.py').write_text(test)
shutil.copyfile(O/'process-runner.py', P/'fixtures/predecessor-process-runner.py')
for name in ('check-latency-metrics.py', 'original-metrics.json'):
    shutil.copyfile(O/'fixtures'/name, P/'fixtures'/name)
scope = json.loads((O/'scope-and-requirements.json').read_text())
scope['candidate_boundary'] = 'Pending clean bounded-owner-poll candidate based on root-reported inventory-repair base 2ccb478; fixed 32-us budget is root implementation scope. No candidate source/build/recovery qualification is inferred here.'
write_json(P/'scope-and-requirements.json', scope)
helpers = json.loads((O/'source-helper-bindings.json').read_text())
rows = {}
for name, row in helpers['helpers'].items():
    rows[name] = dict(bytes=row['bytes'], sha256=row['sha256'],
        predecessor_candidate_path=row['candidate'], proposed_candidate_path=SOURCE+'/scripts/'+name,
        current_candidate_observed=False,
        required='Root compares actual qualified candidate bytes. Runtime fixture/report/history helpers retain their accepted semantics. Any build-helper inventory repair must have its exact source/qualification/manifest binding retained separately.')
write_json(P/'source-helper-bindings.pending.json', dict(helpers=rows,
    source_revision=None, root_source_qualification=None, current_source_verified=False,
    scope='Expected predecessor identities only, not an assertion about current candidate bytes. Materialize source-helper-bindings.json only after root exact-source readback; the inherited finalizer refuses missing or mismatched helper bindings.'))
binding = json.loads((P/'binding.pending.json').read_text())
write_json(P/'binding.source-pinned.pending.json', dict(binding, revision='PENDING_COMMITTED_REVISION'))
commands = json.loads((P/'commands.pending.json').read_text())
write_json(P/'commands.source-pinned.pending.json', dict(commands, source_bound=False,
    source_revision='PENDING_COMMITTED_REVISION', release_pending=True,
    note='Still a pending template. Root must produce commands.source-pinned.json from its actual clean source revision before release finalization.'))
lineage = {}
for original in sorted((P/'originals').iterdir()):
    name = original.name
    if name == 'source-helper-bindings.json':
        updated = P/'source-helper-bindings.pending.json'
    else:
        updated = P/name
    (P/'diffs'/(name+'.diff')).write_text(''.join(difflib.unified_diff(
        original.read_text().splitlines(True), updated.read_text().splitlines(True),
        fromfile=str(O/name), tofile=str(updated))))
    lineage[name] = dict(original_path=str(O/name), original=H(original),
                         derived_path=str(updated), derived=H(updated))
assert (P/'audit.py').read_bytes() == (O/'audit.py').read_bytes()
assert (P/'process-runner.py').read_text() == (O/'process-runner.py').read_text().replace(
    "source=Path('/tmp/kv9-thin-lto-main-integration-first')", "source=Path('/tmp/kv9-bounded-owner-poll')")
write_json(P/'lineage.json', dict(parent=str(O), substitutions=subs, files=lineage,
    test_substitutions='Only predecessor source literal and new candidate source literal in the original five contracts.',
    runtime_scope_changed=False, auditor_byte_identical=True,
    source_helper_binding_scope='Predecessor requirements retained; current source identities and inventory-repair build entrypoints remain root-bound pending data.',
    prior_accepted_result_not_copied=True, tests_executed=False, source_validation_executed=False,
    build_executed=False, runtime_executed=False, audit_executed=False))
write_json(P/'READINESS.pending.json', dict(preparation_complete=True, runtime_ready=False,
    source=SOURCE, proposed_build=BUILD, revision=None, process_output=RUN,
    audit_output=str(P/'results-first'), contracts_retained=5, contracts_executed=False,
    source_validation_executed=False, runtime_executed=False, audit_executed=False,
    runner=H(P/'process-runner.py'), auditor=H(P/'audit.py'), commands=H(P/'commands.pending.json'),
    missing=['Root terminal clean candidate source qualification and actual full revision',
        'Root actual original server plus same-source recovery workload release and cache/codegen/source maps',
        'Actual source-helper bindings including any separately qualified build-inventory change',
        'Root actual readback/source/codegen/terminal records and matching hashes required by freeze-after-build.pending.json',
        'Root finite finalization and fresh final inventories; deferred original contracts only when released',
        'Root storage/placement/ordinary-recovery release; subsequent actual terminal before independent audit']))
print(json.dumps(dict(complete=True, pending=True, runtime_executed=False,
    runner=H(P/'process-runner.py'), auditor=H(P/'audit.py'), commands=H(P/'commands.pending.json')), indent=2))
