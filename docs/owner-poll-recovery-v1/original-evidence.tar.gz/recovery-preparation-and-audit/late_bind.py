#!/usr/bin/env python3
"""Materialize root-supplied metadata only; no source/build/runtime validators."""
import difflib, hashlib, json, shutil
from pathlib import Path
P=Path(__file__).resolve().parent
R=Path('/tmp/kv9-owner-poll-root-first')
SRC=Path('/tmp/kv9-bounded-owner-poll')
BUILD=Path('/tmp/kv9-owner-poll-release-first')
def read(p): return json.loads(p.read_bytes())
def h(p):
    b=p.read_bytes(); return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x): p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
pending=read(P/'inventory.pending.json')
(P/'pending-first').mkdir()
for rel in [*pending,'inventory.pending.json']:
    dest=P/'pending-first'/rel; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(P/rel,dest)
(P/'finalization-diffs').mkdir(); (P/'root-bindings').mkdir()
r=read(R/'release-readback.json'); rev=r['revision']
q=SRC/'docs/owner-poll-source-v1/qualification.json'
inputs={
    'release-readback.json':R/'release-readback.json',
    'release-terminal.json':R/'release-terminal.json',
    'release-result.json':R/'release-result.json',
    'production-codegen-verbose.json':R/'production-codegen-verbose.json',
    'source-qualification.json':q,
    'source-inventory-controls-result.json':SRC/'docs/source-inventory-v1/controls-result.json',
    'source-inventory-controls-output.log':SRC/'docs/source-inventory-v1/controls-output.log',
    'source-inventory-inventory.json':SRC/'docs/source-inventory-v1/inventory.json',
}
for name,path in inputs.items(): shutil.copyfile(path,P/'root-bindings'/name)
receipt_pins={name:dict(path=str(path),copy='root-bindings/'+name,**h(path)) for name,path in inputs.items()}
script=(P/'freeze_after_build.py').read_text().replace('PENDING_COMMITTED_REVISION',rev).replace("HERE/'inventory.pending.json'", "HERE/'inventory.bound.json'")
(P/'freeze_after_build.py').write_text(script)
binding=read(P/'binding.pending.json'); binding['revision']=rev
save(P/'binding.source-pinned.json',binding)
c=read(P/'commands.pending.json')
c=json.loads(json.dumps(c).replace('PENDING_COMMITTED_REVISION',rev))
c.update(source_bound=True,source_revision=rev,release_pending=False,candidate_bound=False,
         templates_only=True,note='Actual root original release metadata supplied; inherited freeze_after_build.py and root contracts remain unexecuted. Use only after actual finalizer acceptance and a separate runtime release.')
save(P/'commands.source-pinned.json',c)
b=read(BUILD/'build.json')
requirements=read(P/'source-helper-bindings.pending.json')['helpers']
helpers={}
for name,old in requirements.items():
    helpers[name]=dict(bytes=(SRC/'scripts'/name).stat().st_size,
        sha256=b['sources']['scripts/'+name],candidate=str(SRC/'scripts'/name),
        predecessor=old['predecessor_candidate_path'],predecessor_sha256=old['sha256'],
        byte_identical_to_predecessor_manifest=b['sources']['scripts/'+name]==old['sha256'])
save(P/'source-helper-bindings.json',dict(helpers=helpers,source_revision=rev,
    source_manifest=dict(path=str(BUILD/'build.json'),**h(BUILD/'build.json')),
    root_readback=receipt_pins['release-readback.json'],
    inventory_repair=receipt_pins['source-inventory-controls-result.json'],
    scope='Hashes are from the original root-accepted source manifest, sizes from file metadata; no current-source validator ran here. Only build-workload.py differs from predecessor among these ten helpers. All ten actual pins are still checked by the inherited finalizer.'))
command=read(P/'freeze-after-build.pending.json')
vals={
    'ROOT_ACTUAL_RELEASE_READBACK_JSON':str(R/'release-readback.json'),
    'ROOT_ACTUAL_RELEASE_READBACK_SHA256':h(R/'release-readback.json')['sha256'],
    'ROOT_ACTUAL_RELEASE_TERMINAL_JSON':str(R/'release-terminal.json'),
    'ROOT_ACTUAL_RELEASE_TERMINAL_SHA256':h(R/'release-terminal.json')['sha256'],
    'ROOT_ACTUAL_SOURCE_GATE_JSON':str(q), 'ROOT_ACTUAL_SOURCE_GATE_SHA256':h(q)['sha256'],
    'ROOT_ACTUAL_PRODUCTION_CODEGEN_JSON':str(R/'production-codegen-verbose.json'),
    'ROOT_ACTUAL_PRODUCTION_CODEGEN_SHA256':h(R/'production-codegen-verbose.json')['sha256'],
    'ROOT_ACTUAL_BUILD_SESSION':'86339','ROOT_ACTUAL_BUILD_TERMINAL_RECEIPT':'78beb1',
}
command['argv']=[vals.get(x,x) for x in command['argv']]
command.update(prepared_from_actual_root_receipts=True,executed=False,
               frozen_input_inventory='inventory.bound.json')
save(P/'freeze-after-build.json',command)
before=P/'pending-first'
for name in ('freeze_after_build.py','README.md'):
    if name=='README.md':
        (P/name).write_text('# Bounded owner polling ordinary recovery: root finalizer ready\n\n'
            f'Clean candidate `{rev}` and original `/tmp/kv9-owner-poll-release-first` are now pinned from root readback. '
            'Root build 86339/0 (78beb1), readback 761fa1/0. Source qualification retains 714 default, 443 read-stage and 5 focused tests with overlapping populations, 14/49 new proof statements/obligations and 33/294 dependency counts; its first failures remain recorded. '
            'All 716 source inputs and five documentation-only post-check changes are described by the original readback. No current source validator, finalizer, test, process or audit ran in this preparation.\n\n'
            '`freeze-after-build.json` supplies the exact real-record/hash/session argv for root to run the inherited strict finalizer. It now binds `inventory.bound.json`; the original `inventory.pending.json` is unchanged, with the entire pending state also retained under `pending-first/`. '
            'The finalizer changes only its revision and input-inventory filename. It still verifies every source/helper, server/workload/manifest/cache hash, default features, original root ThinLTO/codegen1/unwind evidence, clean original build identity and fresh output paths. '
            'The changed build-workload helper is pinned to `16fc5032211c1458f5a063204a70594956351ec604dcad0c7d51f6561dce7b2e`, supported by the retained source-inventory qualification; the other nine listed helpers match the predecessor manifest. This does not relabel the old helper.\n\n'
            '`commands.source-pinned.json` contains process, terminal-audit and five original contract commands. The finalizer will create `commands.json`, `binding.final.json`, `binding-readback.json`, `READINESS.final.json` and `inventory.final.json`; these remain absent until root executes it. '
            'The runner changes only its source path and the generic auditor remains byte-identical. Same-source `workload/kv9-batch-workload`, stream then unary, all original histories/unknowns/attempts/windows, 30-second configured workload, caps, deadlines, six drains, seven lifetimes, placement, default26 metrics and cleanup remain unchanged. Full constants are in `scope-and-requirements.json`.\n\n'
            'Root still owns current storage/environment checks, helper contracts, ordinary recovery and subsequent independent audit after actual terminal. No performance or Chaos acceptance is inferred. The pending README is retained in `pending-first/README.md`; finite changes and original receipt bindings are in `late-binding.json` and `finalization-diffs/`.\n')
    (P/'finalization-diffs'/(name+'.diff')).write_text(''.join(difflib.unified_diff(
        (before/name).read_text().splitlines(True),(P/name).read_text().splitlines(True),
        fromfile=str(before/name),tofile=str(P/name))))
save(P/'late-binding.json',dict(revision=rev,build=str(BUILD),root_records=receipt_pins,
    pending_inventory=dict(path=str(P/'inventory.pending.json'),**h(P/'inventory.pending.json')),
    current_helper_pins=helpers,finalizer_changes=['REV literal','inventory.pending.json -> inventory.bound.json (all pending bytes preserved)'],
    all_helper_predicates_preserved=True,source_validation_executed=False,finalizer_executed=False,
    contracts_executed=False,runtime_executed=False,audit_executed=False))
save(P/'READINESS.bound.json',dict(preparation_complete=True,revision=rev,
    actual_release_metadata_supplied=True,root_finalizer_required=True,finalizer_executed=False,
    contracts_executed=False,runtime_executed=False,runtime_authorized=False,
    command=h(P/'freeze-after-build.json'),runner=h(P/'process-runner.py'),auditor=h(P/'audit.py')))
save(P/'inventory.bound.json',{str(f.relative_to(P)):h(f) for f in sorted(P.rglob('*'))
    if f.is_file() and f.name!='inventory.bound.json' and f.name!='late-bind-first.log'})
print(json.dumps(dict(complete_metadata_binding=True,finalizer_executed=False,
    inventory=h(P/'inventory.bound.json'),finalizer=h(P/'freeze_after_build.py'),
    freeze_command=h(P/'freeze-after-build.json'),commands=h(P/'commands.source-pinned.json')),indent=2))
