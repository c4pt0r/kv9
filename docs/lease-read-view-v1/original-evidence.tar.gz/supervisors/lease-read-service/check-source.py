import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import time

SOURCE = Path('/home/dongxu/kv9')
OUT = Path('/tmp/kv9-lease-read-service-source-first')
os.environ.update(CARGO_TARGET_DIR='/home/dongxu/kv9/target', CARGO_BUILD_JOBS='4',
                  CARGO_NET_OFFLINE='true')

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def main():
    OUT.mkdir()
    spec = importlib.util.spec_from_file_location('lease_builder', SOURCE / 'scripts/build-workload.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    before = builder.snapshot()
    save(OUT / 'sources-before.json', before)
    retained_source = OUT / 'source'
    retained_source.mkdir()
    for name in ['crates', 'proto', '.cargo']:
        if (SOURCE / name).exists(): shutil.copytree(SOURCE / name, retained_source / name)
    for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'rustfmt.toml']:
        if (SOURCE / name).exists(): shutil.copy2(SOURCE / name, retained_source / name)

    result = {'complete': False, 'source_root': str(SOURCE), 'commands': []}
    commands = [
        ('format', ['cargo', 'fmt', '--all', '--', '--check'], False),
        ('default-compile', ['cargo', 'test', '--locked', '-p', 'kv9-engine', '-p', 'kv9-raft', '--lib', '--no-run',
                             '--message-format=json-render-diagnostics'], True),
        ('default-tests', ['cargo', 'test', '--locked', '-p', 'kv9-engine', '-p', 'kv9-raft', '--lib', '--', '--test-threads=4'], False),
        ('server-tests', ['cargo', 'test', '--locked', '-p', 'kv9-server', '--lib', '--', '--test-threads=4'], False),
        ('default-restart-probe', ['cargo', 'test', '--locked', '-p', 'kv9-raft', '--test', 'lease_restart', '--', '--test-threads=1'], False),
        ('default-server-check', ['cargo', 'check', '--locked', '-p', 'kv9-server', '--message-format=json-render-diagnostics'], True),
        ('experimental-check', ['cargo', 'check', '--locked', '-p', 'kv9-server', '--features',
                                 'experimental-leader-lease', '--message-format=json-render-diagnostics'], True),
        ('experimental-clippy', ['cargo', 'clippy', '--locked', '-p', 'kv9-engine', '-p', 'kv9-raft', '-p', 'kv9-server', '--all-targets',
                                  '--features', 'experimental-leader-lease', '--', '-D', 'warnings'], False),
    ]
    save(OUT / 'commands.json', commands)
    try:
        with builder.cache.BuildCache(SOURCE, OUT, False, before) as cache:
            for name, command, artifact_check in commands:
                row = {'name': name, 'argv': command, 'started_ns': time.time_ns()}
                result['commands'].append(row)
                save(OUT / 'result.json', result)
                print(name, 'started', flush=True)
                with (OUT / (name + '.stdout')).open('x') as stdout, (OUT / (name + '.stderr')).open('x') as stderr:
                    code = cache.run(command, stdout=stdout, stderr=stderr, timeout=1200).returncode
                row.update(exit_code=code, ended_ns=time.time_ns())
                if artifact_check:
                    cache.check_artifacts(OUT / (name + '.stdout'))
                if name == 'default-compile':
                    artifacts = [json.loads(line) for line in (OUT / (name + '.stdout')).read_text().splitlines()]
                    binaries = [r['executable'] for r in artifacts if r.get('reason') == 'compiler-artifact'
                                and r.get('executable') and r['target']['name'] == 'kv9_raft']
                    assert len(binaries) == 1, binaries
                    binary = Path(binaries[0])
                    assert binary.stat().st_size <= 512 * 1024**2
                    with binary.open('rb') as src:
                        binary_sha = hashlib.file_digest(src, 'sha256').hexdigest()
                    retained = OUT / 'raft-tests.gz'
                    with binary.open('rb') as src, retained.open('xb') as dst:
                        with gzip.GzipFile(filename='', fileobj=dst, mode='wb', mtime=0, compresslevel=6) as zipped:
                            shutil.copyfileobj(src, zipped, length=64 * 1024)
                    assert retained.stat().st_size <= 512 * 1024**2
                    with gzip.open(retained, 'rb') as decoded:
                        assert hashlib.file_digest(decoded, 'sha256').hexdigest() == binary_sha
                    row.update(test_binary_sha256=binary_sha, retained_binary=str(retained),
                               retained_binary_bytes=retained.stat().st_size,
                               restoration='gzip -dc raft-tests.gz > raft-tests; chmod +x raft-tests')
                if name == 'default-tests':
                    output = (OUT / (name + '.stdout')).read_text()
                    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
                    assert len(matches) == 2 and all(int(x[0]) > 25 and x[1:] == ('0', '0') for x in matches), matches
                    row['test_results'] = matches
                    assert matches[1] == ('243', '0', '0'), matches
                    assert len(re.findall(r'^test driver::lease_read::tests::\w+ \.\.\. ok$', output, re.M)) == 8
                    assert len(re.findall(r'^test rawnode::lease_gate::tests::\w+ \.\.\. ok$', output, re.M)) == 18
                    assert len(re.findall(r'^test lease::tests::\w+ \.\.\. ok$', output, re.M)) == 26
                if name == 'server-tests':
                    output = (OUT / (name + '.stdout')).read_text()
                    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
                    assert len(matches) == 1 and int(matches[0][0]) > 100 and matches[0][1:] == ('0', '1'), matches
                    assert len(re.findall(r'^test runtime::tests::lease_read_tests::\w+ \.\.\. ok$', output, re.M)) == 5
                    row['test_result'] = matches[0]
                if builder.snapshot() != before:
                    raise RuntimeError('Lease read-view source changed during checks')
                save(OUT / 'result.json', result)
                print(name, 'passed', flush=True)
        result['complete'] = True
        save(OUT / 'sources-after.json', builder.snapshot())
    except BaseException as error:
        result['failure'] = repr(error)
        raise
    finally:
        save(OUT / 'result.json', result)

if __name__ == '__main__':
    main()
