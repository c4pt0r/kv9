# Lease service source-test capacity increment

Completed once: session **52139**, exit **0**, terminal receipt **82b285**. Original owner PID 3751323 is absent. This is byte-preserving storage maintenance, with no new build/test/correctness verdict.

The two terminal mutant probes had 180,729,952 logical bytes / 180,740,096 allocated bytes. The independently decoded gzip objects retain 59,931,759 compressed bytes / 59,944,960 allocated bytes. Attributable payload allocation saving is **120,795,136 bytes**; observed filesystem gain is **120,713,216 bytes (115.121 MiB)**. Other work was active, so observed free-space changes are not exclusively attributable to this operation.

Post-conversion free space was 101,871,648,768 bytes, below the separate 96 GiB source preflight. The requested 1 GiB increment was not available from the understood eligible probe copies; root explicitly approved only these two. No runtime/Chaos client, library, target/cache, source, report or previously compressed payload was converted.

Original source/control reports, build/use receipts, mutated source, diagnostics and logs were hash/identity checked unchanged before and after unlink. Both mutant use receipts retain exit 101; both original compile receipts retain exit 0. Fresh archive-source hashes are not represented as historical build hashes. Privileged executable/fd/mapping checks were clear over 628 and 628 processes, with no permission errors or selected-runtime inode aliases. Both files were ordinary, singly linked, UID 1000 and unreferenced.

One conversion ran at a time on CPUs 6–7 (within the authorized CPU set). The inherited 4 GiB archive/preparation cap, 80 GiB free floor, exact source identities, gzip EOF/hash equality, rehash-before-unlink and fail-closed reference rules were preserved. No conversion failed or retried. Historical failed outcomes remain failed.

| Index | Original path | Original bytes | Original/decoded SHA-256 | Archive | Compressed bytes | Compressed SHA-256 |
| --- | --- | ---: | --- | --- | ---: | --- |
| 0 | `/tmp/kv9-segment-publication-controls-first/reused-unlinked-legacy-writer/mutant-build/segment_publication_probe` | 90365784 | `cb54da6c8894ca5e8d1b79ed165eace52a1cf3a32cf9057b8b4f80e1d8018f32` | `executable-00.gz` | 29965015 | `43a121cf2b7a699b66d4e2e4d57d25313615955a298a5f042c69af3512d7a55e` |
| 1 | `/tmp/kv9-segment-publication-controls-first/omitted-publication-directory-sync/mutant-build/segment_publication_probe` | 90364168 | `470ebf2947ff778088698acbc4e477e81805b7eb82602f2ef7d89226702d50dd` | `executable-01.gz` | 29966744 | `36b5a921315d8350951e8edca9fdf3569e03379f232e1d396ebbdc87ae9e76c6` |

## Restore an original executable

Restoration is not executed by this task. Use `result-first.json`, `catalog[index]`, for the exact original path, bytes, SHA-256, permission mode, owner/group and modification time. Keep the archive and all conversion records after restoring.

1. Require the original parent directory with no symlink components and an absent original file path. Reserve the full decoded length above the unchanged 80 GiB floor. Use bounded streaming work on the authorized helper CPUs.
2. Verify compressed byte count and SHA-256 first. Create a fresh exclusive temporary regular file in the original parent directory. Decode to it with a strict `identity.bytes` limit, require gzip EOF, fsync, and verify the full decoded byte count and SHA-256. Retain any failed temporary and failure receipt; never install it.
3. Apply recorded UID/GID, `identity.mode & 0o7777`, and `identity.mtime_ns` to the verified temporary. Install through a no-overwrite hard link at the original path, then remove only the temporary link and fsync the parent. A destination collision must fail. Historical inode/ctime cannot be restored.
4. Verify installed bytes/hash, ownership/mode/mtime and one-link status. Record a fresh restore receipt bound to the original catalog and compressed object. Do not alter original control results or execute the probe.

## Census limitation and remaining candidates

The initial metadata census included some top-level private target directories because their names matched test/proof roots. These matches were explicitly removed by `census-classification.json`; none of their payloads were read or modified. Only the exact two paths in `selection-first.json` authorized conversion. The retained census lists sixteen small CRC/table extraction executables totaling 63,404,016 logical bytes; they are unconverted and would need separate exact-source/terminal binding. Two historical Chaos workload clients are excluded, and all target/library matches remain excluded. These findings do not justify a 1 GiB capacity claim.

The frozen inventory binds the helper/diff, original terminal/source bindings, two privileged reference checks, independently verified archive records, eviction authority/log, actual result and actual terminal. No compressed payload was reread for this metadata packaging.
