import json, os, time
from pathlib import Path

out=Path('/tmp/kv9-lease-read-view-cold-first')
census=json.loads((out/'census-first.json').read_text())
targets={(x['dev'],x['ino']):x['path'] for x in census['files']}
hits=[];errors=[];checked=0
assert os.geteuid()==0
def inspect(pid,kind,path):
    try:
        s=path.stat();key=(s.st_dev,s.st_ino)
        if key in targets:hits.append(dict(pid=int(pid),kind=kind,target=targets[key]))
    except (FileNotFoundError,ProcessLookupError):pass
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
        inspect(proc.name,'exe',proc/'exe')
        for fd in (proc/'fd').iterdir():inspect(proc.name,'fd',fd)
        for line in (proc/'maps').read_text().splitlines():
            parts=line.split(None,5)
            if len(parts)==6 and parts[5].removesuffix(' (deleted)') in targets.values():
                hits.append(dict(pid=int(proc.name),kind='mapping',target=parts[5]))
        checked+=1
    except (FileNotFoundError,ProcessLookupError):pass
    except OSError as error:errors.append(dict(pid=int(proc.name),error=repr(error)))
selected=[]
for root in ['/tmp/kv9-thin-lto-main-integration-release-verbose-first','/tmp/kv9-owner-poll-release-first','/tmp/kv9-point-write-v3-release-first/native','/tmp/kv9-point-write-v3-release-first/redis']:
    p=Path(root)
    if not p.exists():continue
    for f in p.iterdir():
        if f.is_file() and not f.is_symlink() and os.access(f,os.X_OK):
            s=f.stat();selected.append(dict(path=str(f),dev=s.st_dev,ino=s.st_ino,same_candidate_inode=(s.st_dev,s.st_ino)in targets))
for row in census['files']:
    s=Path(row['path']).lstat()
    assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)==(row['dev'],row['ino'],row['bytes'],row['mtime_ns'],row['ctime_ns'],row['nlink'])
result=dict(complete=not errors,checked_processes=checked,hits=hits,errors=errors,selected_runtime_files=selected,
    no_selected_inode_alias=not any(x['same_candidate_inode']for x in selected),candidate_metadata_unchanged=True,
    observed_unix_ns=time.time_ns(),scope='Read-only current executable/fd/mapping census; no archive or deletion authority. No payload hashes read.')
with (out/'use-before-archive.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='selected_runtime_files'}))
