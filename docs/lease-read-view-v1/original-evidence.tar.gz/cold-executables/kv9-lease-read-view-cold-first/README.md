# Lease read-view source-test headroom

Completed once: session 95760, exit 0, terminal tool receipt `70dbc1`; process 3597072 is absent. No cold-conversion attempt failed and no retry occurred. Historical failed mutation outcomes remain failed.

Nine previously resident test probes occupied 813,326,336 allocated bytes (813,284,840 logical bytes). Their exact gzip objects occupy 269,733,888 allocated bytes (269,683,549 compressed bytes). Attributable payload allocation saving is **543,592,448 bytes**. The observed filesystem increase, including preparation metadata and possible unrelated activity, is **543,252,480 bytes (518.086 MiB)**. This exceeds the requested 512 MiB increment.

The post-conversion free observation was 102,926,385,152 bytes: still 152,829,952 below the separate 96 GiB source-build preflight. This maintenance is not a build-readiness or correctness acceptance claim.

Only five restored and four mutant copies of `segment_publication_probe` were cold-converted. All original build commands were terminal with exit 0; original use commands preserve their exact exits, including 101. Historical control detection/restoration reports, original/mutated source text, diagnostics, and command logs remain unchanged. Per-executable hashes are fresh archival observations, not invented historical build pins. Both privileged executable/fd/mapping censuses were clear (627 and 627 processes). Selected files had one link, ordinary non-symlink paths, UID 1000 and no selected-runtime inode aliases.

The inherited compressor, independent gzip EOF readback, repeated original/object hash checks, protected-evidence identity checks and unlink guards are unchanged. The only helper-function change is `main`, binding this finite nine-file list and its original success/failure/source receipts. CPUs 6–7, the 4 GiB archive/preparation cap and the 80 GiB free floor were enforced. No Cargo, shared target, server/client artifact, live owner, original source, log, result or already-cold payload was changed.

| Index | Original path | Bytes | Original/decoded SHA-256 | Archive | Compressed bytes | Compressed SHA-256 |
| --- | --- | ---: | --- | --- | ---: | --- |
| 0 | `/tmp/kv9-segment-publication-controls-first/missing-empty-source-frame/restored-build/segment_publication_probe` | 90365312 | `7e97a5daa2a0e22af9b6f44749c926b0a45779d60f68ee965d34c4f128f65cc3` | `executable-00.gz` | 29964611 | `8f60aa53b43b3a3a043df6a43925ca5b307c3e0ae8761bd11f7e63610efb6f42` |
| 1 | `/tmp/kv9-segment-publication-controls-first/empty-frame-pins-stream/restored-build/segment_publication_probe` | 90365312 | `7e97a5daa2a0e22af9b6f44749c926b0a45779d60f68ee965d34c4f128f65cc3` | `executable-01.gz` | 29964611 | `8f60aa53b43b3a3a043df6a43925ca5b307c3e0ae8761bd11f7e63610efb6f42` |
| 2 | `/tmp/kv9-segment-publication-controls-first/premature-covered-unlink/restored-build/segment_publication_probe` | 90365312 | `7e97a5daa2a0e22af9b6f44749c926b0a45779d60f68ee965d34c4f128f65cc3` | `executable-02.gz` | 29964611 | `8f60aa53b43b3a3a043df6a43925ca5b307c3e0ae8761bd11f7e63610efb6f42` |
| 3 | `/tmp/kv9-segment-publication-controls-first/reused-unlinked-legacy-writer/restored-build/segment_publication_probe` | 90365312 | `7e97a5daa2a0e22af9b6f44749c926b0a45779d60f68ee965d34c4f128f65cc3` | `executable-03.gz` | 29964611 | `8f60aa53b43b3a3a043df6a43925ca5b307c3e0ae8761bd11f7e63610efb6f42` |
| 4 | `/tmp/kv9-segment-publication-controls-first/omitted-publication-directory-sync/restored-build/segment_publication_probe` | 90365312 | `7e97a5daa2a0e22af9b6f44749c926b0a45779d60f68ee965d34c4f128f65cc3` | `executable-04.gz` | 29964611 | `8f60aa53b43b3a3a043df6a43925ca5b307c3e0ae8761bd11f7e63610efb6f42` |
| 5 | `/tmp/kv9-segment-publication-controls-first/missing-empty-source-frame/mutant-build/segment_publication_probe` | 90361736 | `df03261e9af77210ef490b21dee324d58f91de96bd8950ea416b9c5ad07f80e6` | `executable-05.gz` | 29965958 | `086ff7018964ddebf951e5f4468c0394adfd0f5e4d9242f2df9c26e177728940` |
| 6 | `/tmp/kv9-segment-publication-controls-first/empty-frame-pins-stream/mutant-build/segment_publication_probe` | 90364920 | `b317d8227738d9bccc1e5aa45da0dba91f6c095f8d6aebaf57a62fb13113bc9c` | `executable-06.gz` | 29964568 | `7575a5c6eae5b99ee8fbb70a27c6f8efbf519567f5bd9af565aaf0658356a538` |
| 7 | `/tmp/kv9-segment-publication-controls-first/reusable-failed-checkpoint/mutant-build/segment_publication_probe` | 90365312 | `312a29caf282f551707f9ba9798e363bc8ca20cc53f7e9e4a995f56d9ad467c1` | `executable-07.gz` | 29964601 | `acb268531e466c7c61456f6d5b3451e9395383a59ae6cba22d510e1a752bac4f` |
| 8 | `/tmp/kv9-segment-publication-controls-first/premature-covered-unlink/mutant-build/segment_publication_probe` | 90366312 | `4f11dd7733fb9d5481f2627ed1bdfe5c8d09c7e492a6ad9a0e444f0f17401567` | `executable-08.gz` | 29965367 | `e31b13a6834d2ab74b3fe41154c2b5c2d2fb43eabbec9d630d048179d1af76f2` |

## Restore a selected executable

Restoration has not been run. Use `result-first.json`, `catalog[index]`, and the table above. All gzip objects remain retained after any future restore.

1. Require the exact original parent directory, no symlink components, and an absent original file path. Reserve the full decoded length plus the unchanged 80 GiB free floor. Run streaming work on CPUs 6–7.
2. Verify the archive byte count and SHA-256 before decoding. Create a fresh exclusive temporary regular file in the original parent directory; never overwrite a conflicting path.
3. Decode to the temporary file with a hard bound of `identity.bytes`; require successful gzip EOF, fsync, exact decoded length, and SHA-256 equal to `decoded_sha256`. Retain a failed temporary and error receipt rather than installing it.
4. Set recorded UID/GID, `identity.mode & 0o7777`, and `identity.mtime_ns`. Install the verified temporary through a no-overwrite hard link at the original path, remove only its temporary link, and fsync the parent. Any concurrent destination must make installation fail. Historical inode/ctime are evidence, not restorable identity.
5. Recheck installed bytes/hash, ownership/mode/mtime and one-link status. Save a fresh restore receipt binding the original catalog and compressed object. Preserve the cold receipt and original test results, including failures. Restoring bytes must not execute the probe.

The exact reproduction/verification record is `invocation-first.json`, `source-binding-first.json`, `use-before-*.json`, `verified-00.json` through `verified-08.json`, `eviction-authority.json`, `eviction-first.jsonl`, `result-first.json` and `terminal-first.json`. No original bulk archive or current target was inspected.
