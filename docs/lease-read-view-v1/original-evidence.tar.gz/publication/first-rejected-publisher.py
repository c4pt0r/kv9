from pathlib import Path
import gzip, hashlib, io, json, shutil, tarfile

repo = Path('/home/dongxu/kv9')
work = Path(__file__).resolve().parent
cargo = Path('/tmp/kv9-lease-read-service-auth-source-first')
control = Path('/tmp/kv9-lease-read-controls-first')
out = repo / 'docs/lease-read-view-v1'
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
source_result = read(cargo / 'result.json')
controls = read(control / 'result.json')
assert source_result['complete'] and all(r['exit_code'] == 0 for r in source_result['commands'])
assert source_result['commands'][2]['test_results'] == [['136', '0', '0'], ['243', '0', '0']]
assert source_result['commands'][3]['test_result'] == ['207', '0', '1']
assert controls['complete'] and len(controls['controls']) == 9
assert len(controls['commands']) == 40
assert all(c['expected_failure_observed'] for c in controls['controls'])
assert all(c['exit_code'] == c['expected_exit_code'] for c in controls['commands'])
before = read(cargo / 'sources-before.json')
assert before == read(cargo / 'sources-after.json')
for name, digest in before['sources'].items():
    if name.endswith(('.rs', '.toml', '.lock')) and digest is not None:
        assert sha((repo / name).read_bytes()) == digest, name
for name, digest in read(control / 'source-inputs.json').items():
    assert sha((repo / name).read_bytes()) == digest, name
    assert sha((control / 'source' / name).read_bytes()) == digest, name
for directory, result_name in [('/tmp/kv9-lease-read-service-auth-root-first', 'source-result.json'), ('/tmp/kv9-lease-read-controls-root-first', 'controls-result.json')]:
    r = read(Path(directory) / result_name)
    assert r['complete'] and r['exit_code'] == 0
    assert r['initial_available_bytes'] >= 96 * 1024**3
    minimum = min(s['available_bytes'] for s in r['samples'])
    assert minimum >= 80 * 1024**3 and r['initial_available_bytes'] - minimum <= 16 * 1024**3
failed_roots = ['lease-read-view', 'lease-read-view-retention', 'lease-read-service', 'lease-read-service-clock']
for prefix in failed_roots:
    r = read(Path('/tmp/kv9-' + prefix + '-root-first') / 'source-result.json')
    assert not r['complete'] and r['exit_code'] == 1
assert 'ColumnFamily' in Path('/tmp/kv9-lease-read-view-retention-source-first/default-compile.stderr').read_text()
assert 'tokio::time::Instant' in Path('/tmp/kv9-lease-read-service-source-first/server-tests.stderr').read_text()
assert '205 passed; 2 failed; 1 ignored' in Path('/tmp/kv9-lease-read-service-clock-source-first/server-tests.stdout').read_text()
assert 'invalid bearer token' in Path('/tmp/kv9-lease-read-service-clock-source-first/server-tests.stdout').read_text()

files = {}
def add(name, path):
    assert path.is_file() and not path.is_symlink() and name not in files, name
    data = path.read_bytes()
    assert len(data) <= 2 * 1024**2, name
    files[name] = data
def tree(directory, prefix, skip=()):
    assert directory.is_dir(), directory
    for path in directory.rglob('*'):
        relative = path.relative_to(directory)
        if any(part in skip for part in relative.parts): continue
        if path.is_file(): add(prefix + '/' + str(relative), path)
for name in ['crates/engine/src/lib.rs', 'crates/engine/src/mem.rs', 'crates/engine/src/persist.rs',
             'crates/raft/src/driver.rs', 'crates/raft/src/driver/lease_read.rs', 'crates/raft/src/driver/lease_read/tests.rs',
             'crates/raft/src/async_read.rs', 'crates/raft/src/rawnode.rs', 'crates/raft/src/rawnode/lease_gate.rs',
             'crates/raft/src/lease.rs', 'crates/raft/src/lease_policy.rs', 'crates/raft/tests/lease_restart.rs',
             'crates/server/Cargo.toml', 'crates/server/src/runtime.rs', 'crates/server/src/runtime/tests/lease_read_tests.rs',
             'scripts/check-lease-read-view.py', 'scripts/build_cache.py', 'scripts/build-workload.py']:
    add('source/' + name, repo/name)
tree(cargo, 'cargo', {'source', 'raft-tests.gz'})
tree(control, 'controls', {'source'})
for prefix in ['lease-read-view', 'lease-read-view-retention', 'lease-read-view-imports', 'lease-read-service', 'lease-read-service-clock']:
    directory = Path('/tmp/kv9-' + prefix + '-source-first')
    tree(directory, 'earlier/' + prefix, {'source', 'raft-tests.gz'})
    for name in ['crates/raft/src/driver/lease_read/tests.rs', 'crates/server/src/runtime/tests/lease_read_tests.rs']:
        path = directory/'source'/name
        if path.exists(): add('earlier/' + prefix + '/source/' + name, path)
for prefix in ['lease-read-view', 'lease-read-view-retention', 'lease-read-view-imports', 'lease-read-service', 'lease-read-service-clock', 'lease-read-service-auth', 'lease-read-controls']:
    tree(Path('/tmp/kv9-' + prefix + '-root-first'), 'supervisors/' + prefix)
    directory = Path('/tmp/kv9-' + prefix + '-cache-first')
    if directory.exists(): tree(directory, 'cache-maintenance/' + prefix)
for directory in read(work/'cold-directories.json'):
    base = Path(directory)
    for path in base.iterdir():
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.md', '.py'}:
            add('cold-executables/' + base.name + '/' + path.name, path)
add('publication/publish.py', work/'publish.py')
add('publication/cold-directories.json', work/'cold-directories.json')

out.mkdir()
archive = out / 'original-evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|') as tar:
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name); entry.size = len(data); entry.mode = 0o644
            tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files) and {m.name for m in members} == set(files)
    for member in members:
        assert member.isfile() and tar.extractfile(member).read() == files[member.name]
inventory = {'archive': archive.name, 'archive_bytes': archive.stat().st_size,
    'archive_sha256': sha(archive.read_bytes()), 'files': len(files),
    'members': [{'name': n, 'bytes': len(d), 'sha256': sha(d)} for n,d in sorted(files.items())],
    'scope': 'Actual source, Cargo outputs, nine fault controls, first retention/compile/authentication failures and maintenance metadata. Full duplicate workspace and compressed executable payloads excluded.'}
(out/'inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
shutil.copyfile(cargo/'result.json', out/'source-summary.json')
shutil.copyfile(control/'result.json', out/'controls-summary.json')
total = sum(p.stat().st_size for p in (repo/'docs').rglob('original-evidence.tar.gz'))
assert total < 64 * 1024**2, total
receipt = {k:v for k,v in inventory.items() if k != 'members'}
receipt['aggregate_archive_bytes'] = total
(work/'readback.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
