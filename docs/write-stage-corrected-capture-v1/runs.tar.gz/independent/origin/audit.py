#!/usr/bin/env python3
"""Independent finite metadata acceptance for four loaded Batch64 captures.

No fixture, codec, container operation or WAL payload read. Full fixture-byte
retention remains attributed to the original copy/readback receipts.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys
import time

if not __debug__:
    raise RuntimeError('assertions must remain enabled')
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PREP=Path('/mnt/data/kv9-work/write-stage-capture-preparation-20260915-first')
RUN=Path('/mnt/data/kv9-work/write-stage-capture-20260915-first')
EXEC=Path('/mnt/data/kv9-work/write-stage-capture-execution-20260915-first')
CLIENT=Path('/mnt/data/kv9-work/performance-input-recovery-20260915-first/rebuild-first')
INVENTORY_SHA='539e6134f04344985e4dfe1b9d35f4657b4881101dea815618be93a38c37ff2c'
READER_SHA='4bfe18d3b749204337a0d6d6b5366c51a4c5bc813303a8c551279a47c7876ca8'
GIB=1024**3
INPUTS={}


def need(ok,message):
    if not ok:raise ValueError(message)


def blob(path,limit=16*1024**2):
    path=Path(path);a=path.lstat()
    need(stat.S_ISREG(a.st_mode) and 0<a.st_size<=limit,'bounded regular metadata required')
    raw=path.read_bytes();b=path.lstat()
    need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==
         (b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns),'input changed while reading')
    record=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    need(str(path) not in INPUTS or INPUTS[str(path)]==record,'input changed between reads')
    INPUTS[str(path)]=record
    return raw


def read(path):return json.loads(blob(path))
def sha(path,limit=16*1024**2):return hashlib.sha256(blob(path,limit)).hexdigest()
def equal(a,b):return json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))


def save(path,result):
    with path.open('x') as out:json.dump(result,out,indent=2,sort_keys=True);out.write('\n')


def load(name,path):
    blob(path)
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def original_arithmetic():
    source=Path('/mnt/data/kv9-work/upper-bound-requalified-preparation-20260915-first/audit.py')
    wanted={'mix','value','dataset_check','validate_phase_apis','qualify','validate_storage'}
    tree=ast.parse(blob(source));functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in wanted]
    need({n.name for n in functions}==wanted,'original arithmetic functions missing')
    env=dict(require=need,Path=Path,ZERO=('public_rpc_in_flight','public_rpc_queued','public_rpc_running','public_rpc_encoded_bytes',
        'raft_async_apply_queued','raft_async_apply_in_flight','raft_async_read_queued','raft_async_read_active',
        'raft_async_read_in_flight','raft_async_read_active_groups'),
        STORAGE_GUARDS={'runtime':dict(root=24*GIB,retention=8*GIB,tmpfs=16*GIB)})
    exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),env)
    return env


def lifetime_gone(identity):
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if boot!=identity['boot_id']:return True
    try:fields=Path('/proc',str(identity['pid']),'stat').read_text().rsplit(')',1)[1].split()
    except FileNotFoundError:return True
    return int(fields[19])!=identity['start_ticks']


def isolation(matrix,expected_exit=0):
    before=read(RUN/'before.json');after=read(RUN/'after.json');iso=read(RUN/'isolation.json')
    outer=read(RUN/'summary.json');inv=read(RUN/'invocation.json')
    expected=['/usr/bin/python3',str(PREP/'capture.py'),'--output',str(RUN/'cohorts'),
              '--isolation-snapshot',str(RUN/'isolation.json'),*read(PREP/'arguments.json')]
    need(inv['argv']==expected and inv['driver_arguments_sha256']==sha(PREP/'arguments.json') and
         inv['wrapper_sha256']==sha(PREP/'isolate-and-run.py'),'actual inner invocation differs')
    need(outer['complete'] is (expected_exit==0) and outer['restoration_complete'] is True and outer['child_exit_code']==expected_exit and
         not outer.get('child_cleanup_errors') and not outer.get('forced_group_cleanup') and
         not outer.get('deferred_cleanup_signals') and not after['errors'],'outer failure or restoration incomplete')
    need(iso['complete'] is True and iso['measured_client_cpus']==[0,1] and iso['measured_server_cpus']==[2,3,4,5] and
         iso['background_cpus']==list(range(6,16))+list(range(22,32)) and
         iso['driver_sha256']==sha(PREP/'capture.py') and matrix['isolation']==iso,'isolation source/placement differs')
    need(before['containers']==after['containers'] and before['clusters']==after['clusters'],'exact recorded container/cluster restoration differs')
    wrapper=load('accepted_isolation',PREP/'isolate-and-run.py')
    need(set(before['containers'])==set(iso['containers'])==set(wrapper.OWNED),'owned container scope')
    for name,cid in wrapper.OWNED.items():
        old=before['containers'][name];mid=read(RUN/(name+'-isolated.json'))
        need(old['id']==cid and old['configured_cpus']==old['effective_cpus']=='0-31','original owned container differs')
        for row in [mid,iso['containers'][name]]:
            need(wrapper.same_process(old,row) and row['configured_cpus']==row['effective_cpus']==wrapper.CPUSET,'isolated identity differs')
        need(mid['descendants']['tasks'] and all(set(t['cpus'])<=set(wrapper.BACKGROUND) for t in mid['descendants']['tasks']),
             'isolated descendant escaped')
    return dict(complete=True,containers=3,exact_original_restoration=True,current_cluster_operation_performed=False)


def raw_boundaries(directory,instrumented,identities,reader):
    phases=['before','post-client','post-drain','post-readback'];captures=[];raw={};nodes={}
    previous_end=0
    for phase in phases:
        receipt=read(directory/'raw-status'/phase/'capture.json')
        need(receipt['complete'] is True and receipt['phase']==phase and set(receipt['voters'])=={'1','2','3'} and
             previous_end<=receipt['started_unix_ns']<=receipt['ended_unix_ns'] and
             receipt['ended_unix_ns']-receipt['started_unix_ns']<=21_000_000_000,'raw capture order/deadline/completion')
        previous_end=receipt['ended_unix_ns'];captures.append(receipt)
        for node,item in receipt['voters'].items():
            path=directory/'raw-status'/phase/f'node-{node}.status'
            need(item['path']==str(path),'raw original path differs')
            data=blob(path,reader.MAX_STATUS_BYTES);raw[(phase,node)]=data
            need(INPUTS[str(path)]=={k:item[k] for k in ['bytes','sha256']},'raw original digest differs')
            fields=dict(line.split('=',1) for line in data.decode().splitlines())
            identity=identities[int(fields['pid'])]
            need(int(fields['node_id'])==int(node) and fields['process_start_ticks']==str(identity['start_ticks']) and
                 fields['process_boot_id']==identity['boot_id'],'raw owned lifetime differs')
            need(int(fields['metrics_export_successes'])==item['metrics_export_successes']>=receipt['baseline_exports'][node]+2,
                 'first-fresh exporter advances differ')
            need(receipt['started_unix_ns']<=item['observed_unix_ns']<=receipt['ended_unix_ns'],'raw observation timestamp')
            need(('write_stage_trace' in fields)==instrumented and ('write_path_diagnostics' in fields)==instrumented,'raw feature line differs')
    recorded=read(directory/'raw-status/comparison.json')
    for node in ['1','2','3']:
        if not instrumented:
            nodes[node]=dict(default_trace_absent=True);continue
        result={}
        for a,b in zip(phases,phases[1:]):
            analysis=reader.analyze_status(raw[(a,node)],raw[(b,node)])
            path=directory/'raw-status'/f'node-{node}-{a}-to-{b}.json'
            need(equal(read(path),analysis),'independent trace recomputation differs')
            _,ta=reader.parse_status(raw[(a,node)]);_,tb=reader.parse_status(raw[(b,node)])
            entry=dict(result_path=str(path),result_sha256=sha(path),counter_delta=analysis['counter_delta'],
                coverage=analysis['coverage'],join_counts=analysis['join_counts'],group_ring_unchanged=ta['groups']==tb['groups'],
                inspection_ring_unchanged=ta['inspections']==tb['inspections'])
            result[a+'_to_'+b]=entry
        nodes[node]=result
    need(recorded==dict(complete=True,instrumented=instrumented,nodes=nodes,complete_history=False,
                       periodic_sampling=False,no_resampling=True),'recorded raw boundary comparison differs')
    return dict(nodes=nodes,raw_files=12,first_fresh_provenance='Frozen first-fresh-only helper plus exact exporter/clock receipts; discarded polling bytes are not reconstructed.',
                complete_history=False,causal_native_p99_join=False)


def case(row,attempt,matrix,native,health,driver,arithmetic,reader):
    ordinal=row['ordinal'];d=RUN/'cohorts'/f'{ordinal:02d}-{row["mode"]}-{row["workload"]}-c64'
    need(attempt['ordinal']==ordinal and attempt['directory']==str(d),'case path/order differs')
    r=read(d/'result.json');report=read(d/'run/report.json');config=read(d/'requested-config.json')
    need(equal(attempt['result'],r) and r['complete'] is True and r['workload_complete'] is True and r['cleanup_complete'] is True,
         'incomplete native trial')
    want,_=driver.configs(row,config['client']['peers'],config['client']['keyspace_id'],'127.0.0.1:6379')
    need(equal(config,want),'exact requested workload differs')
    for f in ['config.json','build.json']:blob(d/'run'/f)
    validated=native.validate(d/'run',CLIENT/'native',d/'requested-config.json',driver.REDIS_REVISION,require_timing=True)
    need(equal(validated,r['validated']) and r['report_sha256']==sha(d/'run/report.json') and report['stop_reason']=='duration','native report authority differs')
    arithmetic['validate_phase_apis'](report,config,True)
    h=health.health(r,report);need(equal(h,attempt['health']),'independent outcome/attempt accounting differs')
    cleanup=read(d/'cleanup.json');client=read(d/'client-identity.json')
    need(cleanup['complete'] is True and cleanup['storage']=='tmpfs' and len(cleanup['children'])==4 and
         read(d/'client-exit.json')['exit_code']==0 and client['pid']==report['process_id'],'client/cleanup scope differs')
    identities={};lifetimes=[]
    for child in cleanup['children']:
        ident=child['identity'];pid=ident['pid'];is_client=pid==report['process_id'];mask=[0,1] if is_client else [2,3,4,5]
        expected=matrix['source_bindings']['client' if is_client else row['server_role']]['binary_sha256']
        need(child['pid']==pid and child['absent'] is True and child['exit_code']==(0 if is_client else -9) and lifetime_gone(ident),
             'owned recorded lifetime did not exit')
        need(ident['executable_sha256']==expected and ident['cpu_affinity']==mask and ident['thread_placement']['expected']==mask,
             'executed binary/startup placement differs')
        need(pid not in identities,'duplicate owned PID');identities[pid]=ident
        lifetimes.append(dict(pid=pid,start_ticks=ident['start_ticks'],boot_id=ident['boot_id'],exit_code=child['exit_code'],same_lifetime_absent=True))
    need(client==identities[client['pid']],'client identity receipt differs')
    for label in ['before','post-client','post-readback']:
        drain=read(d/(label+'-fresh-drain.json'))
        need(0<drain['completed_unix_ns']-drain['started_unix_ns']<=20_000_000_000 and
             set(drain['baseline'])==set(drain['first_advances'])==set(drain['final'])=={'1','2','3'},'fresh drain scope/time')
        positions=set()
        for n,final in drain['final'].items():
            initial=drain['baseline'][n];first=drain['first_advances'][n]['status']
            for s in [initial,first,final]:
                ident=identities[int(s['pid'])]
                need(s['process_start_ticks']==str(ident['start_ticks']) and s['process_boot_id']==ident['boot_id'],'drain process identity')
            need(all(first[k]==initial[k]==final[k] for k in ['pid','process_start_ticks','process_boot_id']) and
                 int(initial['metrics_export_successes'])<int(first['metrics_export_successes'])<int(final['metrics_export_successes']) and
                 arithmetic['qualify'](first) and arithmetic['qualify'](final),'fresh empty drain predicates')
            positions.add((final['applied_term'],final['applied_index']))
        need(len(positions)==1,'voter drain position differs')
    dataset={};pages=sorted(d.glob('readback-*.txt'));need(1<=len(pages)<=20,'final dataset page bound')
    for i,path in enumerate(pages):
        need(path.name==f'readback-{i:02d}.txt','dataset page ordering')
        lines=blob(path).decode().strip().splitlines();need(lines[-1]==f'count={len(lines)-1}','dataset page count')
        for line in lines[:-1]:
            fields=dict(p.split('=',1) for p in line.split());need(set(fields)=={'key_hex','value_hex'},'dataset syntax')
            key=bytes.fromhex(fields['key_hex']);need(key not in dataset,'duplicate dataset key');dataset[key]=bytes.fromhex(fields['value_hex'])
    data=arithmetic['dataset_check'](config,dataset)
    samples=read(d/'resource-samples.json');coverage=read(d/'resource-coverage.json')
    start=report['measurement_start_unix_ns'];end=start+report['cohort_elapsed_ns'];inside=[s for s in samples if start<=s['unix_ns']<=end]
    need(len(inside)==coverage['samples']>=10 and inside[0]['unix_ns']-start==coverage['first_gap_ns']<=150_000_000 and
         end-inside[-1]['unix_ns']==coverage['last_gap_ns']<=150_000_000,'measured resource coverage')
    for sample in inside:
        need({p['pid'] for p in sample['processes'].values()}==set(identities),'measured process inventory')
        for name,item in sample['processes'].items():
            mask=[0,1] if name=='client' else [2,3,4,5];place=item['thread_placement']
            need(item['start_ticks']==identities[item['pid']]['start_ticks'] and item['cpu_affinity']==place['process']==place['expected']==mask and
                 place['threads'] and all(m==mask for m in place['threads'].values()),'measured process/thread affinity')
    storage=read(d/'storage-resource-samples.json');need(len(storage)>=len(inside),'storage sample coverage')
    for observation in storage:
        devices=arithmetic['validate_storage'](observation,d,'runtime')
        need(devices['root']==matrix['root_device'] and devices['retention']==matrix['retention_device'],'launch/runtime storage device')
        available=observation['filesystems']['retention']['available_bytes']
        need(matrix['available_before']-available<=13*GIB,'campaign decrease exceeded')
    retained=read(d/'fixture/tmpfs-retention.json');budget=read(d/'fixture/diagnostic-retention-budget.json')
    need(retained['complete'] is True and retained['children_exited'] is True and retained['scratch_removed'] is True and
         retained['retained_data']==str(d/'fixture/data') and not Path(retained['original_scratch']).exists(),'original copied fixture closure')
    payload=sum(v['bytes'] for v in retained['files'].values())
    need(payload==budget['bytes']<=3*GIB and budget['full_readback'] is True and budget['policy']==matrix['policy'] and
         budget['original_available']==matrix['available_before'] and budget['available_after']>=8*GIB and
         matrix['available_before']-budget['available_after']<=13*GIB,'original payload readback/budget receipt')
    for name,entry in retained['files'].items():
        rel=Path(name);need(not rel.is_absolute() and '..' not in rel.parts,'retained inventory path')
        p=d/'fixture/data'/rel;s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size==entry['bytes'],'retained inventory current size/kind')
    trace=raw_boundaries(d,row['mode']=='instrumented',identities,reader)
    return dict(ordinal=ordinal,directory=str(d),mode=row['mode'],complete=True,health=h,
        measured_calls=report['measured_completed'],measured_items=r['validated']['successful_input_items'],fresh_drains=3,
        lifetimes=lifetimes,final_dataset=data,retained_payload_bytes=payload,retained_files=len(retained['files']),
        fixture_payload_scope='Original full-copy/full-SHA readback accepted at runtime; current audit checks receipt and regular-file size only, no WAL payload rehash.',
        raw_trace=trace,resource_samples=len(inside),storage_samples=len(storage),report_sha256=sha(d/'run/report.json'))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--terminal',type=Path,required=True);parser.add_argument('--terminal-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    need(args.output.parent.resolve()==HERE and not args.output.exists(),'fresh owned output required');args.output.mkdir()
    result=dict(complete=False,accepted_four_row_capture=False,cases=[],started_unix_ns=time.time_ns())
    try:
        need(args.terminal.resolve()==EXEC/'terminal.json' and sha(args.terminal)==args.terminal_sha256,'actual terminal authority differs')
        terminal=read(args.terminal);result['actual_terminal']=dict(path=str(args.terminal),sha256=args.terminal_sha256,receipt=terminal)
        need(terminal['exit_code']==0,'original capture failed; successful four-row acceptance refused')
        need(sha(PREP/'inventory.json')==INVENTORY_SHA,'frozen preparation inventory differs')
        inventory=read(PREP/'inventory.json')
        for row in inventory['files']:need(INPUTS.get(str(PREP/row['path']),{})=={k:row[k] for k in ['bytes','sha256']} or sha(PREP/row['path'])==row['sha256'],'frozen preparation member differs')
        sys.path.insert(0,str(PREP));capture=load('accepted_capture',PREP/'capture.py');driver=load('accepted_driver',PREP/'inherited-driver.py')
        health=load('accepted_health',PREP/'health.py');need(sha(PREP/'check-write-stage-trace.py')==READER_SHA,'trace reader differs')
        reader=load('independent_trace',PREP/'check-write-stage-trace.py');arith=original_arithmetic()
        outer_inv=read(EXEC/'invocation.json');need(outer_inv['argv']==read(PREP/'ROOT-COMMANDS.json')['capture_root_only_after_review'] and
             outer_inv['input_inventory_sha256']==INVENTORY_SHA,'outer launch authority differs')
        matrix=read(RUN/'cohorts/matrix.json');plan=read(RUN/'cohorts/plan.json')
        need(matrix['complete'] is True and matrix['rows']==capture.plan_rows(driver) and len(matrix['attempts'])==4 and
             matrix['policy']==capture.POLICY and matrix['raw_capture']==capture.write_stage_capture.POLICY and
             matrix['source_revision']==capture.REVISION and matrix['protocol_id']=='kv9-write-stage-loaded-batch-capture-v1' and
             matrix['available_before']==plan['available_before']>=21*GIB+8*1024**2,'four-row protocol/baseline differs')
        need(all(matrix[k]==plan[k] for k in plan if k not in ['complete','attempts','available_after','failure']),'plan/matrix authority changed')
        result['isolation']=isolation(matrix)
        release_pins=read(PREP/'release-pins.json');readback=read(release_pins['release_readback']['path'])
        need(sha(release_pins['release_readback']['path'])==release_pins['release_readback']['sha256'] and readback['complete'] is True,'release actual readback differs')
        for role,binding in matrix['source_bindings'].items():
            build=Path(binding['build_directory']);manifest=read(build/'build.json')
            sources=read(build/'sources.json')['sources'] if role=='client' else manifest['sources']
            need(binding['source']['sources']==sources and binding['source']['revision']==manifest['revision'] and
                 binding['source']['source_tree_sha256']==manifest['source_tree_sha256'] and manifest['dirty'] is False,'source/build inventory binding differs')
            binary=build/('kv9-batch-benchmark' if role=='client' else 'kv9')
            need(sha(binary,32*1024**2)==binding['binary_sha256']==manifest.get('binary_sha256',manifest.get('binaries',{}).get('kv9',{}).get('sha256')),'actual retained role ELF differs')
            if role!='client':
                pin=release_pins['default' if role=='old' else 'instrumented'];need(sha(build/'build.json')==pin['manifest_sha256'],'server manifest pin')
                cargo=[json.loads(line) for line in blob(build/'kv9-cargo.jsonl').splitlines()]
                need(cargo[-1]=={'reason':'build-finished','success':True},'Cargo terminal')
                for name,actual in binding['cargo_artifacts'].items():
                    rows=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name]
                    expected=['write-path-diagnostics','write-stage-tracing'] if role=='new' and name!='kv9_engine' else []
                    need(rows==[actual] and actual['features']==expected,'exact server feature graph differs')
        for path,h in matrix['helper_hashes'].items():need(sha(path)==h,'executed helper source differs')
        for f in ['build.json','sources.json','cargo.jsonl']:blob(CLIENT/'native'/f)
        sys.path.insert(0,str(CLIENT/'source/scripts'));import batch_benchmark_report as native
        for row,attempt in zip(matrix['rows'],matrix['attempts']):
            result['cases'].append(case(row,attempt,matrix,native,health,driver,arith,reader))
        lives=[l for c in result['cases'] for l in c['lifetimes']]
        need(len({(l['pid'],l['start_ticks'],l['boot_id']) for l in lives})==16,'duplicate campaign lifetime')
        result.update(complete=True,accepted_four_row_capture=True,source_revision=capture.REVISION,
            measured_calls=sum(c['measured_calls'] for c in result['cases']),measured_items=sum(c['measured_items'] for c in result['cases']),
            fresh_drains=12,owned_lifetimes=16,raw_status_files=48,retained_payload_bytes=sum(c['retained_payload_bytes'] for c in result['cases']),
            scope='Four current-source two-second loaded Batch64 observer cohorts. Source inventories bind accepted release plus runtime attestation; no new full-source scan. No full history, native p99 causal join, historical speedup, physical-power-loss claim or promotion.')
    except BaseException as error:
        result['failure_type']=type(error).__name__;result['failure']=str(error) if isinstance(error,ValueError) else repr(error)
    result['ended_unix_ns']=time.time_ns();save(args.output/'input-hashes.json',INPUTS);save(args.output/'result.json',result)
    print(json.dumps(dict(complete=result['complete'],output=str(args.output/'result.json'),cases=len(result['cases']),failure=result.get('failure'))))
    return 0 if result['complete'] else 1


if __name__=='__main__':raise SystemExit(main())
