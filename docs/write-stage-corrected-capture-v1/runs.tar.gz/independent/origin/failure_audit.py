#!/usr/bin/env python3
"""Audit the original failed two-attempt scope, never accept four cohorts."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import audit as a

TERMINAL_SHA='d21d41ed3112d9cf36738b8552b7685a4b989d7ce42e12d5ad36c7954f32a295'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    a.need(args.output.parent.resolve()==a.HERE and not args.output.exists(),'fresh owned failure-audit output required');args.output.mkdir()
    result=dict(complete=False,accepted_four_row_capture=False,original_runtime_exit_code=1,
        original_runtime_tool_session=90381,original_runtime_tool_terminal='db2939',scope='Independent failed-capture metadata audit; not successful trace or performance acceptance.')
    try:
        terminal=a.read(a.EXEC/'terminal.json')
        a.need(a.sha(a.EXEC/'terminal.json')==TERMINAL_SHA and terminal['exit_code']==1,'actual failed terminal pin differs')
        a.need(a.sha(a.PREP/'inventory.json')==a.INVENTORY_SHA,'frozen preparation differs')
        for row in a.read(a.PREP/'inventory.json')['files']:
            a.need(a.sha(a.PREP/row['path'])==row['sha256'] and a.INPUTS[str(a.PREP/row['path'])]['bytes']==row['bytes'],'frozen helper bytes differ')
        sys.path.insert(0,str(a.PREP));capture=a.load('capture_failure_authority',a.PREP/'capture.py')
        driver=a.load('native_failure_authority',a.PREP/'inherited-driver.py');health=a.load('health_failure_authority',a.PREP/'health.py')
        a.need(a.sha(a.PREP/'check-write-stage-trace.py')==a.READER_SHA,'reader differs')
        reader=a.load('raw_failure_reader',a.PREP/'check-write-stage-trace.py');arithmetic=a.original_arithmetic()
        matrix=a.read(a.RUN/'cohorts/matrix.json');plan=a.read(a.RUN/'cohorts/plan.json')
        a.need(matrix['complete'] is False and len(matrix['attempts'])==2 and matrix['rows']==capture.plan_rows(driver) and
               matrix['policy']==capture.POLICY and matrix['source_revision']==capture.REVISION,'original partial matrix scope')
        a.need(matrix['failure']=="ValueError('incomplete cohort; original failure preserved')",'original failure differs')
        a.need(all(matrix[k]==plan[k] for k in plan if k not in ['complete','attempts','failure','available_after']),'original plan changed')
        expected=a.read(a.PREP/'ROOT-COMMANDS.json')['capture_root_only_after_review']
        a.need(terminal['argv']==expected==a.read(a.EXEC/'invocation.json')['argv'] and terminal['input_inventory_sha256']==a.INVENTORY_SHA,'actual launch differs')
        result['restoration']=a.isolation(matrix,1)
        release=a.read(a.PREP/'release-pins.json');release_readback=a.read(release['release_readback']['path'])
        a.need(a.sha(release['release_readback']['path'])==release['release_readback']['sha256'] and release_readback['complete'] is True,'release readback binding')
        for role,binding in matrix['source_bindings'].items():
            build=Path(binding['build_directory']);manifest=a.read(build/'build.json')
            sources=a.read(build/'sources.json')['sources'] if role=='client' else manifest['sources']
            a.need(binding['source']['sources']==sources and binding['source']['source_tree_sha256']==manifest['source_tree_sha256'] and
                   binding['source']['revision']==manifest['revision'] and manifest['dirty'] is False,'source binding differs')
            binary=build/('kv9-batch-benchmark' if role=='client' else 'kv9')
            a.need(a.sha(binary,32*1024**2)==binding['binary_sha256'],'retained ELF changed')
            if role!='client':
                pin=release['default' if role=='old' else 'instrumented']
                a.need(a.sha(build/'build.json')==pin['manifest_sha256'] and binding['binary_sha256']==pin['binary_sha256'],'server role pin')
                cargo=[json.loads(line) for line in a.blob(build/'kv9-cargo.jsonl').splitlines()]
                a.need(cargo[-1]=={'reason':'build-finished','success':True},'server Cargo terminal')
                for name,actual in binding['cargo_artifacts'].items():
                    selected=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name]
                    features=['write-path-diagnostics','write-stage-tracing'] if role=='new' and name!='kv9_engine' else []
                    a.need(selected==[actual] and actual['features']==features,'actual production/instrumented feature graph')
        for path,h in matrix['helper_hashes'].items():a.need(a.sha(path)==h,'actual helper source changed')
        for name in ['build.json','sources.json','cargo.jsonl']:a.blob(a.CLIENT/'native'/name)
        sys.path.insert(0,str(a.CLIENT/'source/scripts'));import batch_benchmark_report as native
        result['completed_default_row']=a.case(matrix['rows'][0],matrix['attempts'][0],matrix,native,health,driver,arithmetic,reader)
        d=Path(matrix['attempts'][1]['directory']);row=matrix['rows'][1]
        a.need(d==a.RUN/'cohorts/01-instrumented-batch64-r000-c64','failed row path')
        trial=a.read(d/'result.json');report=a.read(d/'run/report.json');config=a.read(d/'requested-config.json')
        a.need(trial==matrix['attempts'][1]['result'] and trial['complete'] is False and trial['failure']=="Refusal('lost recording calls')" and
               trial['cleanup_complete'] is True and not trial.get('workload_complete'),'failed native trial scope differs')
        desired,_=driver.configs(row,config['client']['peers'],config['client']['keyspace_id'],'127.0.0.1:6379')
        a.need(a.equal(desired,config),'failed row requested config')
        for f in ['config.json','build.json']:a.blob(d/'run'/f)
        validated=native.validate(d/'run',a.CLIENT/'native',d/'requested-config.json',driver.REDIS_REVISION,require_timing=True)
        a.need(report['stop_reason']=='duration' and a.read(d/'client-exit.json')['exit_code']==0,'failed observation did not follow successful native child')
        arithmetic['validate_phase_apis'](report,config,True)
        # Reuse the exact health arithmetic on a plainly synthetic validation
        # input; do not overwrite or relabel the original incomplete trial.
        populations=driver.population_observations(report,config,False)
        outcomes=health.health(dict(complete=True,population_observations=populations),report)
        cleanup=a.read(d/'cleanup.json');a.need(cleanup['complete'] is True and len(cleanup['children'])==4,'failed row owned cleanup')
        identities={};lifetimes=[]
        for c in cleanup['children']:
            i=c['identity'];client=i['pid']==report['process_id'];mask=[0,1] if client else [2,3,4,5]
            a.need(c['absent'] is True and c['exit_code']==(0 if client else -9) and a.lifetime_gone(i),'failed row live recorded child')
            a.need(i['executable_sha256']==matrix['source_bindings']['client' if client else 'new']['binary_sha256'] and i['cpu_affinity']==mask,'failed row runtime identity')
            identities[i['pid']]=i;lifetimes.append(dict(pid=i['pid'],start_ticks=i['start_ticks'],boot_id=i['boot_id'],exit_code=c['exit_code'],same_lifetime_absent=True))
        before=a.read(d/'raw-status/before/capture.json');after=a.read(d/'raw-status/post-client/capture.json')
        a.need(before['complete'] is True and after['complete'] is False and after['failure_type']=='Refusal' and
               after['failure']=='lost recording calls' and set(before['voters'])==set(after['voters'])=={'1','2','3'},'actual first-fresh refusal receipt')
        observations={}
        for n in ['1','2','3']:
            raws=[]
            for phase,receipt in [('before',before),('post-client',after)]:
                path=d/'raw-status'/phase/f'node-{n}.status';raw=a.blob(path,reader.MAX_STATUS_BYTES);item=receipt['voters'][n]
                a.need(item['path']==str(path) and a.INPUTS[str(path)]=={k:item[k] for k in ['bytes','sha256']},'first-fresh raw identity')
                fields=dict(line.split('=',1) for line in raw.decode().splitlines());ident=identities[int(fields['pid'])]
                a.need(fields['node_id']==n and fields['process_start_ticks']==str(ident['start_ticks']) and fields['process_boot_id']==ident['boot_id'],'first-fresh owned process')
                a.need(int(fields['metrics_export_successes'])==item['metrics_export_successes']>=receipt['baseline_exports'][n]+2,'first-fresh advances')
                raws.append(raw)
            _,t0=reader.parse_status(raws[0]);fields=dict(line.split('=',1) for line in raws[1].decode().splitlines());t1=json.loads(fields['write_stage_trace'])
            observed=dict(role=fields['role'],leader_id=fields['leader_id'],before_lost=t0['dropped_recording_calls'],
                post_client_lost=t1['dropped_recording_calls'],valid=t1['valid'],rows_available=t1['rows_available'],
                group_rows=t1['groups']['total_recorded'],group_overwritten=t1['groups']['overwritten'],
                inspection_rows=t1['inspections']['total_recorded'],inspection_overwritten=t1['inspections']['overwritten'])
            try:
                parsed=reader.analyze_status(*raws)
                a.need(n!='2','leader lost calls unexpectedly accepted')
                observed.update(reader_accepted_retained_window=True,coverage=parsed['coverage'],join_counts=parsed['join_counts'])
            except reader.Refusal as error:
                a.need(n=='2' and str(error)=='lost recording calls' and t1['dropped_recording_calls']==5,'unexpected reader refusal')
                observed.update(reader_accepted_retained_window=False,refusal=str(error))
            observations[n]=observed
        for name in ['post-client-fresh-drain.json','post-readback-fresh-drain.json','after-status.json','raw-status/post-drain','raw-status/post-readback']:
            a.need(not (d/name).exists(),'unreached failed-row phase unexpectedly exists')
        retained=a.read(d/'fixture/tmpfs-retention.json');budget=a.read(d/'fixture/diagnostic-retention-budget.json')
        a.need(retained['complete'] is True and retained['children_exited'] is True and retained['scratch_removed'] is True and
               not Path(retained['original_scratch']).exists() and sum(x['bytes'] for x in retained['files'].values())==budget['bytes']<=3*a.GIB and
               budget['full_readback'] is True,'failed row original payload retention closure')
        for name,e in retained['files'].items():
            rel=Path(name);a.need(not rel.is_absolute() and '..' not in rel.parts,'retained relative path')
            path=d/'fixture/data'/rel;s=path.lstat();a.need(not path.is_symlink() and path.is_file() and s.st_size==e['bytes'],'retained original size/kind')
        directories=sorted(p.name for p in (a.RUN/'cohorts').iterdir() if p.is_dir())
        a.need(directories==['00-default-batch64-r000-c64','01-instrumented-batch64-r000-c64'],'unstarted later rows or unknown fixture root')
        result.update(complete=True,failure_state_verified=True,original_runtime_remains_failed=True,
            completed_rows=[0],failed_rows=[1],unstarted_rows=[2,3],owned_exited_lifetimes=8,
            failed_row=dict(native_report_arithmetic=validated,health=outcomes,native_child_exit=0,
                measurement_calls=report['measured_completed'],lifetimes=lifetimes,raw_nodes=observations,
                post_client_drain_executed=False,independent_final_dataset_executed=False,
                retained_payload_bytes=budget['bytes'],accepted_trace_capture=False),
            raw_status_files=18,no_wal_payload_rehash=True,no_runtime_replay=True,
            limitation='Follower windows can be structurally read, but leader loss rejects its joined analysis and the instrumented cohort. Native report success does not accept the failed observation capture. Full fixture hashes remain original copy/readback authority, not a new payload audit.')
    except BaseException as error:
        result['audit_error_type']=type(error).__name__;result['audit_error']=str(error)
    result['ended_unix_ns']=time.time_ns();a.save(args.output/'input-hashes.json',a.INPUTS);a.save(args.output/'result.json',result)
    print(json.dumps(dict(complete=result['complete'],original_runtime_exit_code=1,accepted_four_row_capture=False,
                         output=str(args.output/'result.json'),audit_error=result.get('audit_error'))))
    return 0 if result['complete'] else 1


if __name__=='__main__':raise SystemExit(main())
