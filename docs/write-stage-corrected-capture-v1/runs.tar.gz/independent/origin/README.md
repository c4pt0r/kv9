# Failed stage capture: independent metadata audit

Original runtime 90381/db2939/1 remains failed. Default row 0 completed its
full dataset, drains, retained copy and owned cleanup. Instrumented row 1
completed its native client, then refused the first fresh post-client trace
with five lost recording calls on leader node 2. Rows 2 and 3 never started.

The independent failure-state readback passed **7ce083/0**. Its result is
`failure-privileged-second/result.json`; `accepted_four_row_capture` is false.
All eight original voter/client lifetimes are absent, all first-fresh raw
observations survive, and the exact container/cluster isolation state was
restored. The first nonprivileged metadata attempt **b0cdfe/1** is retained
under `failure-first`: it could not lstat root-owned copied data. The second
used sudo with identical audit code and a fresh output. No WAL payload was
opened, hashed, decoded or replayed. Original full-copy/full-readback receipts
remain the payload authority; current checks cover regular-file type/size.

Row 1 has 32,562 successful measured native calls, but no post-client fresh
drain, independent final dataset scan or post-readback trace capture. Its
native report arithmetic does not accept the failed observation. Both follower
trace windows have zero recorded loss and no terminal inspection rows. The
leader has five lost recording calls and the unchanged reader refuses it.
No loss counter or trace byte was edited to obtain analysis.

`audit.py` was drafted for the prospective full capture and supplies bounded
metadata utilities; its success-only main was never executed. The actual
`failure_audit.py` checks the explicitly failed two-attempt state. Its reused
health-function input marks only independently validated client-report
arithmetic as complete; it never writes that synthetic input over the failed
trial or classifies the instrumented cohort as accepted. All consumed metadata
and retained ELF hashes are in the result input inventory. Source inventories
are bound through actual release/readback and runtime source attestation; this
is not a repeated full source-tree or original fixture payload scan.

`snapshot-gate-review.json` and its exact source diff separately review the
new tracing-only synchronization change. No blocker was found in the inspected
production recording call graph, lock order or release-before-allocation.
Busy snapshots remain unavailable and rejected. Holding the existing gate
during fixed-array copying can delay the next pump, so this is a new observer
overhead environment and cannot rescue or reinterpret the original run.
No Cargo, test, fixture, codec, cleanup or source mutation was performed.
