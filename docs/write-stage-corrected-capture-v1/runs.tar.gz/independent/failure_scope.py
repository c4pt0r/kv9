"""Preserve a failed four-row attempt's finite retained scope without acceptance.

This branch does not reinterpret failed trace rows or fabricate completed
workload, drain or dataset gates. Complete-prefix rows use the ordinary audit.
"""
import json
from pathlib import Path
import sys
import time
import audit as a


def failed_scope(args):
    a.need(args.output.parent.resolve()==a.HERE and not args.output.exists(),'fresh owned output required')
    args.output.mkdir()
    result=dict(complete=False,accepted_four_row_capture=False,original_runtime_remains_failed=True,
                cases=[],unstarted_rows=[],failed_attempts=[],started_unix_ns=time.time_ns())
    try:
        a.need(args.terminal.resolve()==a.EXEC/'terminal.json' and a.sha(args.terminal)==args.terminal_sha256,'actual failed terminal pin')
        terminal=a.read(args.terminal);a.need(type(terminal['exit_code']) is int and terminal['exit_code']!=0,'failure branch requires failed actual terminal')
        result['actual_terminal']=dict(path=str(args.terminal),sha256=args.terminal_sha256,receipt=terminal)
        a.need(a.sha(a.PREP/'inventory.json')==a.INVENTORY_SHA,'frozen preparation changed')
        for row in a.read(a.PREP/'inventory.json')['files']:
            a.need(a.sha(a.PREP/row['path'])==row['sha256'] and a.INPUTS[str(a.PREP/row['path'])]['bytes']==row['bytes'],'frozen helper identity')
        expected=a.read(a.PREP/'ROOT-COMMANDS.json')['capture_root_only_after_review']
        a.need(terminal['argv']==expected==a.read(a.EXEC/'invocation.json')['argv'],'failed original invocation')
        sys.path.insert(0,str(a.PREP))
        capture=a.load('failed_current_capture',a.PREP/'capture.py');driver=a.load('failed_current_driver',a.PREP/'inherited-driver.py')
        health=a.load('failed_current_health',a.PREP/'health.py');reader=a.load('failed_current_reader',a.PREP/'check-write-stage-trace.py')
        arithmetic=a.original_arithmetic()
        matrix_path=a.RUN/'cohorts/matrix.json'
        if not matrix_path.exists():
            # Actual terminal, preserved outer outputs and absent matrix are
            # evidence of incomplete preparation/runtime, never zero-row PASS.
            result.update(matrix_absent=True,unstarted_rows=list(range(4)),phase='before completed cohort matrix')
            for name in ['summary.json','after.json','before.json']:
                path=a.RUN/name
                if path.exists():result[name]=a.read(path)
        else:
            matrix=a.read(matrix_path);rows=matrix['rows'];attempts=matrix['attempts']
            a.need(matrix['complete'] is False and rows==capture.plan_rows(driver) and len(attempts)<=4,'failed matrix scope')
            result['original_matrix_failure']=matrix.get('failure')
            result['restoration']=a.isolation(matrix,1)
            sys.path.insert(0,str(a.CLIENT/'source/scripts'));import batch_benchmark_report as native
            failed_seen=False
            for ordinal,attempt in enumerate(attempts):
                row=rows[ordinal];d=a.RUN/'cohorts'/f'{ordinal:02d}-{row["mode"]}-{row["workload"]}-c64'
                a.need(attempt['ordinal']==ordinal and attempt['directory']==str(d) and not failed_seen,'noncontiguous failure attempt scope')
                trial=a.read(d/'result.json');a.need(a.equal(trial,attempt['result']),'original attempted result mismatch')
                if trial['complete'] is True and (d/'raw-status/comparison.json').exists():
                    result['cases'].append(a.case(row,attempt,matrix,native,health,driver,arithmetic,reader))
                    continue
                failed_seen=True
                record=dict(ordinal=ordinal,directory=str(d),original_result=trial,
                            accepted_trace_capture=False,phase_presence={},raw_captures={},same_lifetimes_absent=[])
                for name in ['before-fresh-drain.json','post-client-fresh-drain.json','post-readback-fresh-drain.json',
                             'after-status.json','raw-status/comparison.json','cleanup.json','run/report.json']:
                    record['phase_presence'][name]=(d/name).exists()
                if (d/'cleanup.json').exists():
                    cleanup=a.read(d/'cleanup.json');record['cleanup']=cleanup
                    for child in cleanup.get('children',[]):
                        identity=child['identity']
                        record['same_lifetimes_absent'].append(dict(pid=identity['pid'],start_ticks=identity['start_ticks'],
                            boot_id=identity['boot_id'],recorded_exit_code=child['exit_code'],
                            same_lifetime_currently_absent=a.lifetime_gone(identity)))
                for phase in ['before','post-client','post-drain','post-readback']:
                    path=d/'raw-status'/phase/'capture.json'
                    if not path.exists():continue
                    receipt=a.read(path);captured=dict(receipt=receipt,nodes={})
                    for node,row_pin in receipt.get('voters',{}).items():
                        a.need(node in ['1','2','3'],'unexpected raw voter')
                        original=d/'raw-status'/phase/f'node-{node}.status'
                        raw=a.blob(original,reader.MAX_STATUS_BYTES)
                        a.need(row_pin['path']==str(original) and a.INPUTS[str(original)]=={k:row_pin[k] for k in ['bytes','sha256']},'failed first-fresh raw pin')
                        try:
                            identity,trace=reader.parse_status(raw)
                            captured['nodes'][node]=dict(reader_snapshot_valid=True,identity=identity,
                                group_rows=trace['groups']['total_recorded'],inspection_rows=trace['inspections']['total_recorded'])
                        except reader.Refusal as error:
                            captured['nodes'][node]=dict(reader_snapshot_valid=False,refusal=str(error))
                    record['raw_captures'][phase]=captured
                result['failed_attempts'].append(record)
            result['unstarted_rows']=list(range(len(attempts),4))
            result['all_recorded_attempts']=len(attempts)
            result['owned_cleanup_fully_verified']=all(all(x['same_lifetime_currently_absent'] and x['recorded_exit_code'] is not None
                for x in f['same_lifetimes_absent']) and bool(f['same_lifetimes_absent']) for f in result['failed_attempts'])
        result.update(complete=True,failure_state_observed=True,
            limitation='Failed-run metadata inventory only. No missing lifecycle/drain/dataset gate is invented. Failed trace bytes are preserved and checked by the unchanged reader, never made valid. Original runtime stays failed; no workload or payload replay.')
    except BaseException as error:
        result['audit_error_type']=type(error).__name__;result['audit_error']=str(error)
    result['ended_unix_ns']=time.time_ns();a.save(args.output/'input-hashes.json',a.INPUTS);a.save(args.output/'result.json',result)
    print(json.dumps(dict(complete=result['complete'],accepted_four_row_capture=False,output=str(args.output/'result.json'),audit_error=result.get('audit_error'))))
    return 0 if result['complete'] else 1
