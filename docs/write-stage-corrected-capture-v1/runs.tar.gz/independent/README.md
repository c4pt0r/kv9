# Corrected capture independent readback

Run check.py only after the actual corrected runtime terminal exists, using
ROOT-COMMANDS.json with its observed SHA. Root supervisor output is the exact
write-stage-corrected-capture-execution-20260915-first/terminal.json. Sudo is
required for metadata lstat through retained root-owned fixture directories;
the old nonprivileged refusal remains in original evidence.

The prospective successful four-row auditor is the preserved original audit.py
with only preparation/runtime/execution paths and frozen inventory SHA changed.
Its complete default-row path previously passed7ce083/0 in the original failed
campaign audit. It checks exact four-row order, source/build/ELF/client pins,
original native validation and phase/attempt arithmetic, dataset text receipts,
fresh drains, recorded lifetimes, sample affinity/coverage, three filesystem
guards, exact container restoration, original copy/readback metadata and the
unchanged raw trace reader's results. It does not read/hash WAL payloads or
repeat source-tree/proof/workload tests. Source inventories are bound through
actual release and runtime authority; current retained ELFs are hashed.

check.py selects successful acceptance only for an actual integer exit zero.
The small failure_scope.py handles a nonzero actual terminal by preserving
completed-prefix, failed-attempt and unstarted-row scope. It never validates
missing drains/datasets, changes original results or turns invalid snapshots
into accepted traces. A malformed/incomplete failure state may itself refuse
the audit; it cannot produce four-row acceptance. A complete failure-state
observation means only that its stated original metadata was inspected.

The six focused preparation checks passedca973a/0, including actual server/client
path bindings and false/missing/string terminal refusal. Earlier eight capture
controls and trace-reader controls are inherited, not rerun. No fixture,
container, codec, workload, Cargo, source or original evidence is modified by
these readers. All new audit outputs remain in this separate data-volume root.
No actual corrected capture result has been read or presumed during preparation.
