#!/usr/bin/env python3
"""Choose success acceptance or failed-run observation from an actual terminal."""
import argparse
from pathlib import Path
import audit
import failure_scope


def scope(terminal):
    audit.need(type(terminal) is dict and type(terminal.get('exit_code')) is int,'actual integer terminal exit required')
    return 'success' if terminal['exit_code']==0 else 'failure'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--terminal',type=Path,required=True)
    parser.add_argument('--terminal-sha256',required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    audit.need(args.terminal.resolve()==audit.EXEC/'terminal.json' and audit.sha(args.terminal)==args.terminal_sha256,'actual terminal binding')
    selected=scope(audit.read(args.terminal))
    return audit.main() if selected=='success' else failure_scope.failed_scope(args)


if __name__=='__main__':raise SystemExit(main())
