"""Accepted typed initialization-read retry and recorded-lifetime helpers, unchanged."""
import hashlib
import json
from pathlib import Path

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def health(result, report):
    require(result['complete'] is True and report['complete'] is True, 'incomplete logical workload')
    require(not report['failure'] and not report['task_failures'] and report['dropped_slots'] == 0,
            'failed or dropped workload')
    phases = {'initialization', 'warmup', 'measurement', 'verification'}
    require(set(report['metrics']) == phases == set(result['population_observations']), 'phase scope differs')
    discovery = 0
    for phase, metrics in report['metrics'].items():
        require(metrics['valid'] is True, 'invalid population')
        require(metrics['attempt_outcomes'] == ['success','refused','failed_or_unknown'], 'attempt schema differs')
        require(metrics['outcomes'] == ['success','refused','unknown_write','read_failure','client_rejected'], 'outcome schema differs')
        require(len(metrics['statistics']) == 2, 'operation scope differs')
        if phase == 'initialization':
            require(metrics['operations'] == ['batch_get','batch_put'], 'initialization operation differs')
        counts, successes, attempts = [], [], []
        for index, op in enumerate(metrics['statistics']):
            logical = [p['calls'] for p in op['populations']]
            attempt = [p['raw']['count'] for p in op['attempts']]
            reasons = op['attempt_reasons']
            require(len(logical) == 5 and len(attempt) == 3 and len(reasons) == len(metrics['reasons']), 'counter schema differs')
            require(all(type(n) is int and n >= 0 for n in logical+attempt+reasons), 'invalid typed counter')
            calls = sum(logical); tries = sum(attempt)
            require(logical[0] == calls and attempt[0] == calls and attempt[2] == 0, 'non-success or unknown operation')
            expected = [0] * len(reasons)
            expected[metrics['reasons'].index('success')] = calls
            if phase == 'initialization' and index == 0:
                discovery = attempt[1]
                expected[metrics['reasons'].index('not_leader')] = discovery
            else:
                require(tries == calls, 'write or post-initialization retry')
            require(reasons == expected, 'retry reason is not initialization-read not_leader discovery')
            counts.append(calls); successes.append(logical[0]); attempts.append(tries)
        observed = result['population_observations'][phase]
        require(observed == dict(calls=counts,successes=successes,attempts=attempts,
                                 all_success=counts==successes,
                                 all_success_single_attempt=counts==successes==attempts), 'population observation differs')
    return {'initialization_read_discovery_retries': discovery, 'allowed_reason':'not_leader',
            'initialization_writes_single_attempt':True,'warmup_measurement_verification_single_attempt':True,
            'every_phase_logically_successful':True}

def gone(identity):
    require(type(identity['pid']) is int and type(identity['start_ticks']) is int and identity['boot_id'], 'missing lifetime')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != identity['boot_id']:
        return True
    try:
        current = Path('/proc')/str(identity['pid'])/'stat'
        start = int(current.read_text().rsplit(')',1)[1].split()[19])
    except FileNotFoundError:
        return True
    return start != identity['start_ticks']
