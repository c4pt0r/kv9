# Current-source loaded Batch64 stage capture

This preparation runs exactly four fresh two-second BatchPut(64), c64 cohorts:
default, instrumented, instrumented, default. Both releases use clean source
`8c0008569d50e51a39eb04ff2ebb6cde1d00ba13`, including the current checkpoint
owner integration. Default has no features; instrumented enables both
`write-stage-tracing` and `write-path-diagnostics`. Any rate comparison measures
their combined observation overhead in this short capture. It is not a new
comparison to historical bd42/e2e, a ten-second screen, or candidate promotion.

The retained default server is `cb77ef363437aa9893d931aad059e91cf5a3124a7ff31adeb12d4db3a55d5ebf`;
instrumented is `e78217c464640076dce085737ab4668b1f83a09bf3ead728bc8900f722d24b23`.
`release-pins.json` binds both actual manifests and the independent release
readback (build 54360/cd1a78/0; readback 8509d8/0). The one requalified native
v3 client remains `1b8060eb168610328c10a27480de16bd8b2d6805166d8169638f85ceef0992c4`
from the clean 581-file 0be806d source. It is not the historical 8da9 ELF.

`origin/capture.py` preserves the accepted full observer wrapper from
`/tmp/kv9-upper-bound-observer-preparation-20260915-first`. Its typed
initialization-read discovery retry rule (`health.py`) and exact three-container
isolation/restoration wrapper are byte-identical. `inherited-driver.py` is the
entire unchanged requalified data-volume matched driver. Its native trial,
client sampler, fresh drains, native validation, full final dataset scan,
PID/start/boot/ELF/affinity checks and failure cleanup bodies are unchanged.
The source delta and original helper hashes are explicit. Old failures and
historical captures remain at their original paths; no old row is reused.

The protocol keeps 4096 keys, 128-byte values, seed 71, warmup 128, closed-loop
c64, 10-million-call cap, the existing client deadlines, three voters, quorum,
sync, successful single-attempt writes/warmup/measurement/verification, and
typed initialization-read retries only. Client CPUs are 0–1, server CPUs 2–5,
helper/background CPUs 6–15 and 22–31. Unrelated host activity remains possible.
Voters use tmpfs; full post-exit copies are verified before owned scratch
removal. These sync calls establish no physical-power-loss durability claim.

`write_stage_capture.py` wraps existing method calls, without changing their
function bodies. It retains raw local status for all three voters at four
boundaries: before client launch, first fresh post-client, post-client drain,
and post-readback drain. The client exit follows its own verification phase;
it is not the precise measurement-stop edge. Each boundary has a 20-second
deadline and waits for two exporter-success advances from its initial status.
This excludes a snapshot already rendering at entry without assuming a fixed
20 ms export cadence. The first fresh raw file is retained before trace-quality
validation. Lost calls, busy/invalid trace, wrong identity or feature omission
remain failures; there is no quality-based resampling.

Raw originals are `COHORT/raw-status/PHASE/node-N.status`, with byte/hash and
export-boundary receipts beside them. Existing before/after status maps remain.
The unchanged independent `check-write-stage-trace.py` reads the raw files
directly and validates each adjacent boundary pair. `comparison.json` reports
exact post-client ring/counter changes; a nonzero change is visible rather than
silently treating a later snapshot as the stop snapshot. The two 512-row rings
sample actual indices modulo 16. Stop-time captures cover only retained tails,
not all two seconds or individual native p99 calls. Overwritten prefixes,
missing/ambiguous joins and terminal paths outside the hook remain explicit.
No periodic reader runs in the measured loop. The instrumented runtime's
continuous status export and inherited host/root/data/tmpfs observations still
have overhead.

Four original loaded-batch rows retained 8,504,803,812 payload bytes in total
(largest 2,134,563,435). Those are historical e2e/8da9 empirical values, not a
bound for this source/client. The new finite campaign budget is 12 GiB payload
(four unchanged 3 GiB per-row caps) plus 1 GiB metadata, narrowing the old
16 GiB decline cap to 13 GiB. Data launch requires **22,556,966,912 bytes**:
8 GiB floor + 13 GiB maximum decrease + 8 MiB launch envelope. Root is separately
observed at **24 GiB** before/during capture and retention; tmpfs stays
32 GiB launch / 16 GiB continuous. Devices are bound to the fresh campaign
baseline. Only `f_bavail` is budgeted; output bytes are not counted twice on
root. Raw status is capped at 2 MiB/file, 24 MiB/cohort, 96 MiB across four rows.
`capacity.json` is a historical observation; launch must recheck it.

Eight focused synthetic controls passed actual direct tool **a8cc5d/0**. They
exercise first-fresh invalid preservation, freshness/type/refusal boundaries,
actual StreamingFixture/TmpfsFixture snapshot MRO, restoration of hooks after
an exception, explicit changed post-drain tails, matrix and budget arithmetic.
No old reader controls, Cargo, fixture or workload were replayed. The original
schema-1 trace reader remains byte-identical to its separately qualified source.

`ROOT-COMMANDS.json` contains the exact root invocation. Root owns fresh
exclusivity/capacity checks, launch and actual terminal receipts. The outer
wrapper preserves attempts and restores the exact owned isolation state even
on failure. This campaign-specific absolute-path wrapper is experimental
execution evidence, not a portable installation. No runtime has been executed
by the preparer. All new files and future outputs remain on the data volume;
the three new repository scripts can be published by root with this evidence.
