#!/usr/bin/env python3
"""Only new path/source/release bindings; no fixture or inherited control replay."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
OLD=Path('/mnt/data/kv9-work/write-stage-capture-preparation-20260915-first')
INDEPENDENT=Path('/mnt/data/kv9-work/write-stage-corrected-capture-independent-20260915-first')
SOURCE=Path('/mnt/data/kv9-work/write-stage-corrected-release-source-20260915-first')
CLIENT=Path('/mnt/data/kv9-work/performance-input-recovery-20260915-first/rebuild-first')
sys.path.insert(0,str(HERE))
import capture


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def main():
    checks=[]
    original=(OLD/'capture.py').read_text()
    normalized=(HERE/'capture.py').read_text().replace(str(HERE),str(OLD)).replace(
        '3f4d4cf6bced54cae677e3c93794eb59c5dd5999','8c0008569d50e51a39eb04ff2ebb6cde1d00ba13')
    assert normalized==original;checks.append('capture differs only in exact source/preparation path')
    for name in ['inherited-driver.py','health.py','isolate-and-run.py','write_stage_capture.py','check-write-stage-trace.py']:
        assert (HERE/name).read_bytes()==(OLD/name).read_bytes()
    checks.append('five runtime/helper/reader files byte-identical')
    args=json.loads((HERE/'arguments.json').read_text());old=json.loads((OLD/'arguments.json').read_text())
    assert [s.replace('write-stage-corrected-release-','write-stage-release-') for s in args]==old
    checks.append('arguments differ only in server release/source paths')
    driver=load('exact_driver',HERE/'inherited-driver.py')
    bound={}
    for role in ['default','instrumented']:
        build=Path('/mnt/data/kv9-work')/f'write-stage-corrected-release-{role}-20260915-first'
        result=capture.server_binding(driver,SOURCE,build,role=='instrumented')
        assert len(result['source']['sources'])==1396
        bound[role]={k:v for k,v in result.items() if k!='source'}
        bound[role]['source']={k:v for k,v in result['source'].items() if k!='sources'}
        bound[role]['source']['files']=len(result['source']['sources'])
    checks.append('both actual source/ELF/manifest/Cargo feature graphs accepted')
    cm=driver.read(CLIENT/'native/build.json');ci=driver.read(CLIENT/'native/sources.json')
    assert driver.digest(CLIENT/'native/kv9-batch-benchmark')==cm['binary_sha256']==capture.CLIENT_SHA
    cb=driver.source_binding(CLIENT/'source',dict(cm,sources=ci['sources']),capture.CLIENT_REVISION)
    assert len(cb['sources'])==581 and cm['rustc']==bound['default']['rustc']==bound['instrumented']['rustc']
    checks.append('unchanged qualified client/source/compiler binding')
    sys.path.insert(0,str(INDEPENDENT));check=load('outcome_scope',INDEPENDENT/'check.py')
    assert check.scope({'exit_code':0})=='success' and check.scope({'exit_code':1})=='failure' and check.scope({'exit_code':-15})=='failure'
    for value in [{},{'exit_code':True},{'exit_code':None},{'exit_code':'0'}]:
        try:check.scope(value)
        except ValueError:pass
        else:raise AssertionError('invalid actual terminal accepted')
    checks.append('actual integer terminal selects honest success/failure scope; missing/boolean/string refused')
    result=dict(complete=True,checks=checks,role_bindings=bound,client_source_files=581,
                client_binary_sha256=capture.CLIENT_SHA,runtime_executed=False,old_controls_replayed=False)
    with (HERE/'path-qualification.json').open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(dict(complete=True,checks=len(checks),output=str(HERE/'path-qualification.json'))))


if __name__=='__main__':main()
