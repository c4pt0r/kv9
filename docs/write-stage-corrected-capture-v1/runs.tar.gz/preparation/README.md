# Corrected-source loaded Batch64 capture preparation

This is a new four-row capture from clean3f4d4cf6bced54cae677e3c93794eb59c5dd5999.
Rows remain default, instrumented, instrumented, default; BatchPut64/c64, two
seconds,4096keys/128B/seed71/warm128, qualified1b8060 client. Default has no
features; instrumented has write-stage-tracing plus write-path-diagnostics.
It is a short combined-observer overhead capture, not a historical comparison
or candidate promotion. The original8c000 failure and both attempted rows are
preserved through lineage.json; no original row is reused or relabeled.

Only source/preparation/release/output paths and actual release pins change.
The entire native driver, raw-boundary hooks, trace reader, typed initialization
retry check and isolation wrapper are byte-identical. The earlier eight
controls remain inherited a8cc5d/0. Six focused checks passed ca973a/0, including
actual1396-file server and581-file client source/ELF bindings, both Cargo
feature graphs, exact path-only source normalization and terminal type refusal.
No fixture/build or old control was replayed. origin and diffs preserve bytes.

Actual release/readback is13353/4bd6ff/0 and070a11/0. Default ELF is
18d5da4a5aa8855288088374daa59889c71d39c5332eb58bfdea17e1084dda1a; instrumented
is14c4d61b3e08f34dc1cba55eaee789901dac2d166cee738abdb4bf23a543f698.
release-pins.json binds complete originals. release-pins.pending.json is the
preserved preparation placeholder, not runtime authority.

All resource predicates are unchanged:22,556,966,912B fresh data launch,8GiB
data floor,13GiB maximum campaign decline,3GiB per-row retained payload,
24GiB root floor,32GiB/16GiB tmpfs launch/runtime. Fresh actual guards remain
mandatory. CPU placement, complete native dataset, all outcomes/attempts,
quorum/sync, first-fresh invalid/loss refusal, copy/readback-before-cleanup and
exact container restoration stay unchanged. Existing eight controls and
original README describe these qualified semantics. No quality-based resample
or periodic raw sampler is introduced.

ROOT-COMMANDS.json contains the exact reviewed root launch array. All outputs
are new data-volume paths. Root owns launch/actual terminals. The independent
reader is separately prepared in write-stage-corrected-capture-independent-
20260915-first; its actual output must await terminal. Original capture
failed; this preparation claims no new runtime success.
