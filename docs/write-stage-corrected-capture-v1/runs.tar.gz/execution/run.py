import hashlib,json,os,subprocess,time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PREP=Path('/mnt/data/kv9-work/write-stage-corrected-capture-preparation-20260915-first')
RUNTIME=Path('/mnt/data/kv9-work/write-stage-corrected-capture-20260915-first')
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,value):(ROOT/name).write_text(json.dumps(value,indent=2)+'\n')
def main():
 assert not RUNTIME.exists(), 'Use a fresh runtime directory.'
 inventory=json.loads((PREP/'inventory.json').read_text())
 for row in inventory['files']:
  p=PREP/row['path'];assert p.is_file() and not p.is_symlink()
  assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],row['path']
 argv=json.loads((PREP/'ROOT-COMMANDS.json').read_text())['capture_root_only_after_review']
 assert argv[argv.index('--output')+1]==str(RUNTIME)
 available={name:os.statvfs(name).f_bavail*os.statvfs(name).f_frsize for name in ['/','/mnt/data','/dev/shm']}
 assert available['/']>=24*1024**3 and available['/mnt/data']>=21*1024**3+8*1024**2 and available['/dev/shm']>=32*1024**3
 result={'argv':argv,'started_unix_ns':time.time_ns(),'input_inventory_sha256':digest(PREP/'inventory.json'),'checked_preparation_files':len(inventory['files']),'available_bytes':available,'scope':'Four corrected-source loaded-batch observation cohorts; no promotion or fault injection.'}
 save('invocation.json',result)
 with (ROOT/'capture.log').open('x') as log:
  process=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT)
  save('process.json',{'pid':process.pid,'argv':argv,'started_unix_ns':time.time_ns()})
  result['exit_code']=process.wait()
  log.flush();os.fsync(log.fileno())
 result['ended_unix_ns']=time.time_ns();save('terminal.json',result)
 print(json.dumps(result),flush=True)
 raise SystemExit(result['exit_code'])
if __name__=='__main__':main()
