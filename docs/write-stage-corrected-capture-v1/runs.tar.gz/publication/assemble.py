"""Archive original metadata once; large retained database payloads stay local."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path('/mnt/data/kv9-work')
OUT = Path(__file__).resolve().parent
PACK = OUT/'packet'


def main():
    runtime = ROOT/'write-stage-corrected-capture-20260915-first'
    execution = ROOT/'write-stage-corrected-capture-execution-20260915-first'
    assert json.loads((runtime/'summary.json').read_text())['complete']
    assert json.loads((execution/'tool-terminal.json').read_text())['exit_code']==0
    PACK.mkdir(exist_ok=False)
    rows = {}
    excluded = []
    roots = [
        ('release', 'write-stage-corrected-release-root-20260915-first'),
        ('default', 'write-stage-corrected-release-default-20260915-first'),
        ('instrumented', 'write-stage-corrected-release-instrumented-20260915-first'),
        ('preparation', 'write-stage-corrected-capture-preparation-20260915-first'),
        ('execution', 'write-stage-corrected-capture-execution-20260915-first'),
        ('runtime', 'write-stage-corrected-capture-20260915-first'),
        ('independent', 'write-stage-corrected-capture-independent-20260915-first'),
        ('analysis', 'write-stage-corrected-capture-analysis-20260915-first'),
    ]
    for prefix,name in roots:
        root = ROOT/name
        for p in sorted(root.rglob('*')):
            assert not p.is_symlink(), str(p)
            if not p.is_file():
                continue
            rel = p.relative_to(root)
            payload = prefix=='runtime' and len(rel.parts)>4 and rel.parts[0]=='cohorts' and rel.parts[2:4]==('fixture','data')
            executable = prefix in ('default','instrumented') and rel.parts==('kv9',)
            if payload or executable:
                excluded.append(dict(path=str(p),bytes=p.stat().st_size,
                                     kind='database_payload' if payload else 'executable'))
                continue
            assert p.stat().st_size<=32*1024**2, (str(p),p.stat().st_size)
            rows[f'{prefix}/{rel}'] = p
    rows['publication/assemble.py'] = Path(__file__)
    entries = []
    archive = PACK/'runs.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
        for name,p in sorted(rows.items()):
            data = p.read_bytes()
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            tar.addfile(member,io.BytesIO(data))
            entries.append(dict(member=name,source=str(p),bytes=len(data),
                                sha256=hashlib.sha256(data).hexdigest()))
    inventory = dict(archive=dict(file=archive.name,bytes=archive.stat().st_size,
                                 sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
                     members=entries,excluded=excluded,logical_bytes=sum(x['bytes'] for x in entries),
                     excluded_payload_bytes=sum(x['bytes'] for x in excluded if x['kind']=='database_payload'))
    assert inventory['excluded_payload_bytes']==8418027444
    (PACK/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
    with tarfile.open(archive,'r:gz') as tar:
        members = tar.getmembers()
        assert len(members)==len(entries)
        for member,entry in zip(members,entries):
            assert member.name==entry['member'] and member.isfile()
            data = tar.extractfile(member).read()
            assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
            assert data==Path(entry['source']).read_bytes()
    result = dict(status='PASS',scope='Full archive member decode/hash/original-byte readback; no workload, WAL payload read or test execution.',
                  members=len(entries),logical_bytes=inventory['logical_bytes'],
                  archive_bytes=archive.stat().st_size,archive_sha256=inventory['archive']['sha256'],
                  excluded_payload_bytes=inventory['excluded_payload_bytes'])
    (PACK/'readback.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
