# Existing WAL metric differences

For each instrumented cohort and voter, read the original `before-metrics.json`
and `after-metrics.json` identified by the output SHA-256 inventory. Match the
selected metric by exact name and select the `success` outcome. Refuse saturated
counts/sums or clamped durations. Subtract the earlier count and duration sum
from the later values, requiring both differences to be nonnegative. Mean is
duration-sum difference divided by count difference, or null for zero count.

These fixture snapshots include surrounding setup, verification and idle time.
They do not share the native measurement population or retained trace sample.
Use their separate totals as context, without subtracting unlike means or
claiming exclusive CPU time. tmpfs sync does not model power-loss durability.
