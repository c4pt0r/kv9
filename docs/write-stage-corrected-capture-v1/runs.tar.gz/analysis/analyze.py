"""Summarize accepted diagnostic tails without pooling them with client p99."""
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path('/mnt/data/kv9-work/write-stage-corrected-capture-20260915-first')
OUT = Path(__file__).resolve().parent
INPUTS = {}


def read(path):
    raw = path.read_bytes()
    INPUTS[str(path)] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    return json.loads(raw)


def stats(values):
    values = sorted(values)
    assert values
    return dict(count=len(values), sum=sum(values), mean=statistics.fmean(values),
                minimum=values[0], p50=values[math.ceil(len(values)*.5)-1],
                p99=values[math.ceil(len(values)*.99)-1], maximum=values[-1])


def group_intervals(g):
    assert g['receipts_inserted_ns'] is not None
    return dict(prepare_to_locks=g['locks_acquired_ns']-g['prepare_started_ns'],
                locks_to_apply=g['apply_started_ns']-g['locks_acquired_ns'],
                apply=g['apply_finished_ns']-g['apply_started_ns'],
                apply_return_to_receipt_insertion=g['receipts_inserted_ns']-g['apply_finished_ns'])


def main():
    audit = read(Path('/mnt/data/kv9-work/write-stage-corrected-capture-independent-20260915-first/readback-first/result.json'))
    # The audit's actual result and input hashes are retained separately. Keep
    # this analysis dependent on accepted runtime rows and validated trace files.
    assert audit['complete']
    runtime = read(ROOT/'summary.json')
    assert runtime['complete'] and runtime['restoration_complete']
    rows = []
    for directory in sorted((ROOT/'cohorts').iterdir()):
        if not directory.is_dir():
            continue
        result = read(directory/'result.json')
        assert result['complete'] and result['workload_complete'] and result['cleanup_complete']
        s = result['summary']
        op = next(o for o in s['operations'] if o['operation']=='batch_put')
        pop = next(p for p in op['populations'] if p['outcome']=='success')
        assert s['calls']==s['issued']==pop['calls'] and s['dropped_slots']==0
        row = dict(directory=directory.name, role=result['server_role'], calls=s['calls'],
                   items=pop['input_items'], elapsed_ns=s['cohort_elapsed_ns'],
                   items_per_second=s['successful_input_items_per_second'],
                   whole_call_latency=pop['whole_call_latency'], nodes={})
        if 'instrumented' in directory.name:
            for path in sorted((directory/'raw-status').glob('node-*-before-to-post-client.json')):
                a = read(path)
                assert a['complete'] and a['accepted_retained_window_analysis']
                assert a['counter_delta']['dropped_recording_calls']==0
                groups = {g['group_sequence']:g for g in a['retained_groups']
                          if g['sequence']>a['coverage']['groups']['before_total']}
                intervals = [group_intervals(g) for g in groups.values()]
                joins = [j for j in a['joins'] if j['status']=='unique_compatible_pair'
                         and j['inspection_recorded_after_before']]
                entry = dict(identity=a['identity'], coverage=a['coverage'],
                             counters=a['counter_delta'], join_counts=a['join_counts'],
                             retained_distinct_groups=len(groups),
                             commands_per_retained_group=stats([g['commands'] for g in groups.values()]),
                             deduplicated_group_intervals_ns={k:stats([g[k] for g in intervals]) for k in intervals[0]})
                if joins:
                    entry['sampled_position_intervals_ns'] = {
                        k:stats([j['intervals_ns'][k] for j in joins]) for k in joins[0]['intervals_ns']}
                    entry['registration_age_ns'] = stats([j['registration_age_ns'] for j in joins])
                row['nodes'][str(a['identity']['node_id'])] = entry
        rows.append(row)
    assert len(rows)==4
    comparisons=[]
    for default_i,instrumented_i in [(0,1),(3,2)]:
        d,i=rows[default_i],rows[instrumented_i]
        assert 'default' in d['directory'] and 'instrumented' in i['directory']
        comparisons.append(dict(default=d['directory'],instrumented=i['directory'],
            instrumented_items_per_second_change_percent=(i['items_per_second']/d['items_per_second']-1)*100,
            instrumented_whole_call_mean_change_percent=(i['whole_call_latency']['mean_ns']/d['whole_call_latency']['mean_ns']-1)*100,
            default_p99_interval=d['whole_call_latency']['p99'], instrumented_p99_interval=i['whole_call_latency']['p99']))
    pooled={}
    for mode in ['default','instrumented']:
        selected=[r for r in rows if mode in r['directory']]
        calls=sum(r['calls'] for r in selected)
        pooled[mode]=dict(calls=calls,items=sum(r['items'] for r in selected),
            elapsed_ns=sum(r['elapsed_ns'] for r in selected),
            items_per_second=sum(r['items'] for r in selected)*1e9/sum(r['elapsed_ns'] for r in selected),
            whole_call_mean_ns=sum(r['whole_call_latency']['population']['sum_ns'] for r in selected)/calls)
    result=dict(complete=True,rows=rows,order_comparisons=comparisons,pooled=pooled,
        pooled_throughput_change_percent=(pooled['instrumented']['items_per_second']/pooled['default']['items_per_second']-1)*100,
        scope='Two-second shared-host observer qualification, both diagnostic features enabled; no selected-runtime improvement or Redis comparison.',
        limitations=[
            'Retained tails use deterministic index-modulo-16 sampling, not random sampling or complete histories.',
            'Group stage statistics deduplicate group_sequence; sampled-position statistics intentionally weight shared groups repeatedly.',
            'The before-to-post-client window includes warmup and client verification; client exit is not exact measurement stop.',
            'Sampled internal p99 is not the client p99 population and cannot be added across stages.',
            'Registration age is sampled before inspection and does not identify exact registration/proposal/quorum/client boundaries.',
            'p99 bounds are kept per order. No average of percentiles or pooled percentile is calculated.',
            'The fixed-array snapshot correction may delay a pump; these instrumented intervals include its scheduling effects.'
        ],inputs=INPUTS)
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(complete=True,calls=sum(r['calls'] for r in rows),items=sum(r['items'] for r in rows),
                         order_comparisons=comparisons,pooled=pooled,pooled_throughput_change_percent=result['pooled_throughput_change_percent']),indent=2))


if __name__=='__main__':
    main()
