"""Preparation only: read accepted metadata and local CLI help, never WAL/objects."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,time

P=Path(__file__).resolve().parent
AP=Path('/tmp/kv9-published-directory-performance-v3-preparation-20260915-first')
pins=[]
def meta(path,expected=None):
    path=Path(path);raw=path.read_bytes();pin=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    if len(raw)>4*1024**2:raise RuntimeError('metadata cap')
    if expected is not None:assert pin==expected,str(path)
    pins.append(dict(path=str(path),**pin));return json.loads(raw)
def ident(path):
    s=Path(path).lstat();assert stat.S_ISREG(s.st_mode)
    return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,allocated_bytes=s.st_blocks*512)

audit=meta(AP/'results-first/audit.json');inventory=meta(AP/'results-first/input-inventory.json')
protocol=meta(AP/'protocol.json');bindings=meta(AP/'build-bindings.json')
assert audit['complete'] and audit['matched_diagnostic_accepted']
members=[];groups=[]
for group,ordinal in [('point',1),('batch',3)]:
    case=audit['cases'][ordinal];assert case['ordinal']==ordinal and case['complete'] and case['arm'].startswith('new-')
    cohort=Path(case['directory']);fixture=cohort/'fixture'
    catalog=meta(fixture/'retention-catalog.json',inventory[str(fixture/'retention-catalog.json')])
    original=meta(fixture/'retention-original.json',inventory[str(fixture/'retention-original.json')])
    assert catalog['original_inventory_sha256']==inventory[str(fixture/'retention-original.json')]['sha256']
    assert not catalog['resident_original_paths'] and all(c['absent'] and c['exit_code'] is not None for c in catalog['children'])
    assert all(c['complete'] and c['absent'] and c['exit_code']==0 for c in catalog['codecs'])
    for voter in ['n1','n2','n3']:
        ss=[m for m in catalog['members']if m['name'].startswith(voter+'/catalog.segments/') and m['name'].endswith('.wal')]
        chosen=[m for m in ss if Path(m['name']).name=='00000000000000000002.wal'];assert len(chosen)==1
        m=chosen[0];assert 16*1024**2-65536<=m['original']['bytes']<=16*1024**2
        assert original['inventory']['files'][m['name']]==m['original']
        later=[x for x in ss if int(Path(x['name']).stem)>2];assert later
        obj=fixture/m['object'];object_identity=ident(obj)
        compressed=dict(bytes=m['compressed_bytes'],sha256=m['compressed_sha256'])
        assert inventory[str(obj)]==compressed and object_identity['bytes']==compressed['bytes']
        members.append(dict(id=group+'-'+voter,group=group,voter=voter,cohort=str(cohort),name=m['name'],sequence=2,
                            original=dict(bytes=m['original']['bytes'],sha256=m['original']['sha256']),
                            original_metadata=m['original']['metadata'],object_path=str(obj),object_identity=object_identity,
                            compressed=compressed,later_observed_sequence=max(int(Path(x['name']).stem)for x in later)))
    groups.append(dict(name=group,ordinal=ordinal,cohort=str(cohort),workload=case['workload'],arm=case['arm'],concurrency=case['concurrency'],
                       exited_children=[dict(pid=c['pid'],exit_code=c['exit_code'],absent=c['absent'],identity=c['identity'])for c in catalog['children']],
                       original_codec_lifetimes=len(catalog['codecs']),catalog_verified_unix_ns=catalog['verified_unix_ns'],
                       closure='Original writer processes exited and accepted retention verified all bytes; chosen ordinal is below later observed segment ordinals. No decoded selected-topology entry is present in these metadata authorities.'))
assert len(members)==6 and len({m['original']['sha256']for m in members})==6
assert sum(m['original']['bytes']for m in members)<=512*1024**2
codec=Path('/usr/bin/zstd');toolbytes=codec.read_bytes()
codec_pin=dict(path=str(codec),bytes=len(toolbytes),sha256=hashlib.sha256(toolbytes).hexdigest(),identity=ident(codec))
assert codec_pin['sha256']==catalog['codec']['sha256']
help_result=subprocess.run([str(codec),'--help'],capture_output=True,timeout=10)
assert help_result.returncode==0 and b'v1.5.5' in help_result.stdout+help_result.stderr and b'--patch-from=REF' in help_result.stdout+help_result.stderr
(P/'zstd-help.stdout').write_bytes(help_result.stdout);(P/'zstd-help.stderr').write_bytes(help_result.stderr)
source=bindings['roles']['new']['source']
selection=dict(version=1,protocol_id='kv9-cross-voter-zstd-patch-pilot-v1',prepared_ns=time.time_ns(),
               output=str(P/'pilot-first'),metadata_inputs=pins,codec=codec_pin,groups=groups,members=members,
               role_source={k:source[k]for k in ['path','revision','source_tree_sha256']},
               limits=dict(free_floor_bytes=8*1024**3,maximum_added_allocation_bytes=1024**3,maximum_member_bytes=128*1024**2,
                           maximum_total_decoded_bytes=512*1024**2,combined_timeout_seconds=1200,codec_rlimit_as_bytes=512*1024**2,
                           decoder_memory_flag='--memory=512MiB',one_codec_at_a_time=True,cpu_affinity=list(range(6,16))+list(range(22,32))),
               ordinary_flags=['-q','--no-progress','--single-thread','-3','--check','--zstd=wlog=26'],
               patch_extra_flag='--patch-from=<same-group-n1-verified-raw>',selected_logical_bytes=sum(m['original']['bytes']for m in members),
               original_compressed_bytes=sum(m['compressed']['bytes']for m in members),
               scientific_scope='Byte-level lossless storage pilot only; matching is cohort/voter/ordinal, not equality or equal record boundaries. No database performance inference or bulk saving guarantee.',
               execution_performed=False,bulk_conversion_authorized=False)
with (P/'selection.json').open('x')as f:json.dump(selection,f,indent=2);f.write('\n')
print(json.dumps(dict(selection_sha256=hashlib.sha256((P/'selection.json').read_bytes()).hexdigest(),selected_logical_bytes=selection['selected_logical_bytes'],original_compressed_bytes=selection['original_compressed_bytes'],codec_sha256=codec_pin['sha256'])))
