import hashlib,json,os,sys,time
from pathlib import Path
OLD=Path('/tmp/kv9-cross-voter-patch-pilot-preparation-20260915-first')
assert hashlib.sha256((OLD/'common.py').read_bytes()).hexdigest()=='83dc44c951a6bbdaa06a301bcdca925c21d5a700f8ad8097fad89d8375e71ae1'
sys.path.insert(0,str(OLD))
from common import Session,save,check,digest,CPUS
P=Path(__file__).resolve().parent
assert set(os.sched_getaffinity(0))==CPUS
base=bytes(range(256))*64;target=base[:8192]+bytes([base[8192]^1])+base[8193:]
(P/'base.raw').write_bytes(base);(P/'target.raw').write_bytes(target)
baseline=dict(started_ns=time.time_ns(),started_monotonic_ns=time.monotonic_ns(),device=os.stat(P).st_dev)
s=Session(P,baseline);z='/usr/bin/zstd'
assert digest(z)['sha256']=='7c5468b370f7c47eda07281e3437fafc568f95d10420051e3aa522709f9342c5'
positive=dict(bytes=len(target),sha256=hashlib.sha256(target).hexdigest())
result=dict(complete=False,scope='Tiny synthetic argument diagnosis only; no original object reads; inherited 512 MiB process address-space bound',input_bytes=len(base)+len(target))
try:
 flags=[z,'-q','--no-progress','--single-thread','-3','--check','--zstd=wlog=26']
 s.codec('tiny-ordinary',flags+['-c',str(P/'target.raw')],P/'ordinary.zst',65536)
 rows=[]
 for name,flag,expected in [('bare512','-M512',11),('explicit512KiB','-M512KiB',0),('explicit512MiB','--memory=512MiB',0),('explicit536870912','--memory=536870912',0)]:
  out=P/(name+'.raw')
  row=s.codec(name,[z,'-q','-d','--single-thread',flag,'-c',str(P/'ordinary.zst')],out,len(target),decoded=True,allow_failure=True)
  assert row['exit_code']==expected,(name,row)
  if expected==0:check(out,positive)
  else:assert out.stat().st_size==0 and 'Parameter is out of bound' in Path(row['stderr']).read_text()
  rows.append(dict(flag=flag,exit_code=row['exit_code'],output=digest(out)))
 s.codec('tiny-patch',flags+['--patch-from='+str(P/'base.raw'),'-c',str(P/'target.raw')],P/'patch.zst',65536)
 s.codec('tiny-patch-corrected-decode',[z,'-q','-d','--single-thread','--memory=512MiB','--patch-from='+str(P/'base.raw'),'-c',str(P/'patch.zst')],P/'patch-decoded.raw',len(target),decoded=True)
 check(P/'patch-decoded.raw',positive)
 result.update(complete=True,variants=rows,patch_roundtrip=positive,resource=s.guard())
except BaseException as exc:result['error']=repr(exc)
finally:
 result.update(children=s.records,all_children_reaped=all(r.get('reaped')for r in s.records),ended_ns=time.time_ns())
 save(P/'result.json',result)
print(json.dumps(dict(complete=result['complete'],children=len(s.records),all_children_reaped=result['all_children_reaped'],result_sha256=digest(P/'result.json')['sha256'])))
sys.exit(0 if result['complete']else 1)
