"""Independent original-authority round trips and negative controls, serial codecs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from common import P,CPUS,MIB,Session,save,digest,check,load_selection,check_originals

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--approve-selection-sha256',required=True)
    ap.add_argument('--approve-code-sha256',required=True);ap.add_argument('--producer-result-sha256',required=True);args=ap.parse_args()
    if digest(P/'code-pins.json')['sha256']!=args.approve_code_sha256:raise RuntimeError('code pin manifest')
    for name,pin in json.loads((P/'code-pins.json').read_text()).items():check(P/name,pin,'verifier code changed')
    if set(os.sched_getaffinity(0))!=CPUS:raise RuntimeError('exact helper CPU placement required')
    s=load_selection(args.approve_selection_sha256);root=Path(s['output']);producer=root/'producer-result.json'
    if digest(producer)['sha256']!=args.producer_result_sha256:raise RuntimeError('producer result pin')
    r=json.loads(producer.read_text())
    if not r['complete'] or not r['all_codec_children_reaped']:raise RuntimeError('producer not terminal')
    if len(r['children'])!=16 or any(x['exit_code']!=0 or not x['complete'] or not x['reaped'] for x in r['children']):raise RuntimeError('six decode, six ordinary and four patch child exits required')
    if r['decoded_bytes']!=sum(m['original']['bytes']for m in s['members']):raise RuntimeError('original decoded accounting')
    if r['selection_sha256']!=args.approve_selection_sha256 or r['code_pins_sha256']!=args.approve_code_sha256:raise RuntimeError('producer binding')
    dest=root/'verification-first';dest.mkdir(mode=0o700)
    session=Session(root,json.loads((root/'baseline.json').read_text()),r['decoded_bytes'])
    result=dict(complete=False,roundtrip_accepted=False,producer_result_sha256=args.producer_result_sha256,selection_sha256=args.approve_selection_sha256)
    try:
        session.guard();check_originals(s)
        rows={x['id']:x for x in r['outputs']}
        if len(r['outputs'])!=6 or len(rows)!=6 or set(rows)!={m['id']for m in s['members']}:raise RuntimeError('six exact producer rows required')
        verified=[];controls=[];zstd=s['codec']['path']
        for m in s['members']:
            row=rows[m['id']];ordinary=root/(m['id']+'.ordinary.zst')
            if row['ordinary']!=str(ordinary):raise RuntimeError('ordinary path binding')
            check(ordinary,row['ordinary_digest'])
            output=dest/(m['id']+'.ordinary.decoded')
            session.codec('independent-ordinary-'+m['id'],[zstd,'-q','-d','--single-thread','-M512','-c',str(ordinary)],output,m['original']['bytes'],decoded=True)
            check(output,m['original'],'ordinary roundtrip mismatch')
            if m['voter']!='n1':
                base_member=next(x for x in s['members']if x['id']==m['group']+'-n1')
                base=root/(base_member['id']+'.raw');patch=root/(m['id']+'.patch.zst')
                if row['base']!=str(base) or row['patch']!=str(patch):raise RuntimeError('patch/base path binding')
                check(base,base_member['original'],'base_sha_mismatch');check(patch,row['patch_digest'])
                output=dest/(m['id']+'.patch.decoded')
                session.codec('independent-patch-'+m['id'],[zstd,'-q','-d','--single-thread','-M512','--patch-from='+str(base),'-c',str(patch)],output,m['original']['bytes'],decoded=True)
                check(output,m['original'],'patch roundtrip mismatch')
                # A wrong base must fail the pinned identity gate even when its changed bytes might be unused.
                wrong=dest/(m['id']+'.wrong-base')
                session.guard(base_member['original']['bytes']+MIB)
                with wrong.open('xb') as f:
                    remain=base_member['original']['bytes']
                    while remain:count=min(MIB,remain);f.write(b'\0'*count);remain-=count
                    f.flush();os.fsync(f.fileno())
                refused=False
                try:check(wrong,base_member['original'],'base_sha_mismatch')
                except RuntimeError as exc:
                    if str(exc)!='base_sha_mismatch':raise
                    refused=True
                if not refused:raise RuntimeError('wrong base unexpectedly accepted')
                controls.append(dict(kind='bad_base',member=m['id'],refused=True,mechanism='pinned original base SHA/length gate before codec',wrong_base=digest(wrong)))
                # Mutate only a fresh patch copy's checksum trailer; original patch and objects are unchanged.
                corrupt=dest/(m['id']+'.corrupt.patch.zst')
                session.guard(patch.stat().st_size+MIB)
                with patch.open('rb') as src,corrupt.open('xb') as out:
                    while chunk:=src.read(MIB):out.write(chunk)
                with corrupt.open('r+b') as f:
                    if f.seek(0,2)<8:raise RuntimeError('patch frame too short')
                    f.seek(-1,2);last=f.read(1);f.seek(-1,2);f.write(bytes([last[0]^1]));f.flush();os.fsync(f.fileno())
                output=dest/(m['id']+'.corrupt.decoded')
                receipt=session.codec('corrupt-patch-'+m['id'],[zstd,'-q','-d','--single-thread','-M512','--patch-from='+str(base),'-c',str(corrupt)],output,m['original']['bytes'],decoded=True,allow_failure=True)
                diagnostic=Path(receipt['stderr']).read_text(errors='replace')
                if receipt['exit_code']!=1 or 'checksum' not in diagnostic.lower():raise RuntimeError('corruption did not produce exact checksum refusal')
                controls.append(dict(kind='corrupt_patch',member=m['id'],refused=True,mechanism='independent decoder checksum error',child=receipt,corrupt_digest=digest(corrupt)))
            verified.append(dict(id=m['id'],original=m['original'],ordinary_bytes=ordinary.stat().st_size,
                                 patch_bytes=(root/(m['id']+'.patch.zst')).stat().st_size if m['voter']!='n1' else None))
        comparisons=[]
        for group in ['point','batch']:
            rr=[x for x in verified if x['id'].startswith(group+'-')]
            baseline=sum(x['ordinary_bytes']for x in rr)
            patched=next(x['ordinary_bytes']for x in rr if x['id']==group+'-n1')+sum(x['patch_bytes']for x in rr if x['patch_bytes']is not None)
            comparisons.append(dict(group=group,ordinary_three_objects_bytes=baseline,one_ordinary_base_plus_two_patches_bytes=patched,byte_difference=baseline-patched,scope='Six selected members only; no extrapolated fleet saving, no database QPS'))
        check_originals(s)
        result.update(complete=True,roundtrip_accepted=True,verified=verified,controls=controls,comparisons=comparisons,
                      decoded_bytes_total=session.decoded,resource=session.guard(),original_objects_unchanged=True)
    except BaseException as exc:result['error']=repr(exc)
    finally:
        result.update(ended_ns=time.time_ns(),children=session.records,all_codec_children_reaped=all(x.get('reaped')for x in session.records))
        save(dest/'result.json',result)
    print(json.dumps(dict(complete=result['complete'],result=str(dest/'result.json'),result_sha256=digest(dest/'result.json')['sha256'])))
    return 0 if result['complete'] else 1
if __name__=='__main__':sys.exit(main())
