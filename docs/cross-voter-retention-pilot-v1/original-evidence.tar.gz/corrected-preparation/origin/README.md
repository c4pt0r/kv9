# Six-member cross-voter Zstandard patch pilot

This is executable preparation only. No original object or WAL was opened during preparation, and no compression, decompression, test, cleanup or runtime ran. Local `zstd --help` and small source/metadata/tool hashing were the only executable/tool observations. Root owns review and execution.

`selection.json` binds six original engine WAL members from the accepted directory screen: new-role timed cohort `001-new-point-r000-p00001` and `003-new-batch64-r000-p00001`, sequence 2 from each of n1/n2/n3. Both are c1 workloads. The six members total **100,639,065 logical bytes**; their existing ordinary objects total **67,878,587 compressed bytes**. Each member is approximately 16 MiB and all six whole-file SHA256 values differ.

Matching means the same completed cohort, voter role and segment ordinal. It does not assert equal record boundaries or equal bytes. The accepted catalogs bind all original writer exits and successful codec/independent readback lifetimes. Sequence 2 is below later observed sequences 3 (point) or 40 (batch). These authorities prove closed retained stores and a non-final observed ordinal; they do not include a freshly decoded selected-topology closed-entry proof. This byte-level pilot does not require or claim such a proof. The original role source revision/tree/path is retained in the selection, independent of current main.

## Execution

Run the two arrays in `commands.json` serially on CPUs **6–15,22–31**, after root review. `producer` creates exactly the fresh `pilot-first` directory. After a successful actual producer terminal, use its emitted `producer-result.json` SHA256 in the independent `verify` array. The second command cannot be prebound to a hypothetical successful result. The combined deadline begins with producer creation; execute readback promptly within that same 1,200-second budget.

The producer checks the frozen code and selection, all source metadata pins, the actual Zstandard executable SHA/stat identity, and each original compressed object's SHA/length/stat identity. It then serially:

1. Decodes each of the six original objects into the isolated pilot directory and checks the complete original SHA256 and length.
2. Produces ordinary compression for all six fresh raw members.
3. Produces four patches: n1→n2 and n1→n3 within each cohort. Each patch's base is the exact SHA-verified raw n1 member from that cohort.

Ordinary and patch encoders use identical fixed flags `-q --no-progress --single-thread -3 --check --zstd=wlog=26`, differing only by `--patch-from=<base>`. Both read regular files, so comparison does not mix file-input and stdin header conventions. Original retained object sizes are context, not substitutes for these same-flag ordinary results.

The separate verifier reads the frozen original SHA/length authorities independently of the producer's claimed round-trip outcomes. It decodes all six newly produced ordinary objects and all four patches in fresh files, hashes each complete decoded file to EOF, and compares the exact original length/digest. It verifies the producer's exact six identities and 16 successful, reaped codec children. It reports per-triplet ordinary storage versus **one ordinary base plus two patches**, not an invalid saving that omits the base.

## Refusal controls and failure evidence

For each of the four patches, verification creates a fresh all-zero wrong base of the original base's exact size. The same pinned-base SHA/length gate used before positive decoding must reject it before codec launch. This control intentionally does not assume Zstandard itself always rejects a changed base: a modified byte might be unused by a particular patch.

It also creates a fresh patch copy, flips the last checksum byte, independently decodes that copy with the correct base and requires Zstandard exit 1 with an explicit checksum diagnostic. A signal, timeout, allocation failure or unrelated error does not satisfy this control. All original compressed objects, ordinary objects and valid patch files remain unchanged. Partial failed outputs and stderr/child receipts are retained; there are no retries, overwrites or removal operations.

Each codec receipt records its exact argv, PID/start ticks/boot ID, inherited CPU set, configured process limits, timestamps, actual exit and reap status. The producer reports `roundtrip_accepted=false`; only the independent successful result can report true. Failure before the fresh output directory exists is reported through the actual root tool stderr/terminal; failure after creation additionally retains the relevant result/child files.

## Hard bounds and interpretation

- Available-space floor: **8 GiB**, using `f_bavail`; output space is also reserved before each bounded operation.
- Added pilot directory allocation: **at most 1 GiB**, including original decodes, ordinary objects, patches, all verification/control copies, stderr and receipts. Original source objects are not charged again as new output.
- Per member/output: **at most 128 MiB**. Decoder output gets the tighter exact original-length file-size limit; encoder output gets original length +1 MiB, capped at 128 MiB.
- Cumulative decoded output across both processes: **at most 512 MiB**, including retained output from checksum-refusal attempts. Six selected originals occupy about 96 MiB; positive and negative verification remains explicitly charged.
- Combined deadline: **1,200 seconds**. One codec child at a time; all children reaped, including killed failed children. No background workers.
- Encoder and decoder child `RLIMIT_AS`: **512 MiB**; core dumps disabled. Decoder also receives `-M512`. The local v1.5.5 help documents `-M` as decoder memory control, so it is not relied on for encoder memory.

Zstandard patch mode uses the reference as dictionary material and may adjust its window/long-distance parameters. The explicit process limit remains authoritative. An allocation refusal stays a visible failed pilot; no memory/window policy is silently enlarged. The helper prints actual file sizes and child receipts, not database QPS or workload latency. Results cover these two c1 ordinal samples only and cannot establish a bulk saving, physical-block identity or safe campaign-wide transformation.

No ordinary compressed original, catalog, historical proof/runtime evidence, source, selected executable or prior failed result is deleted, renamed or rewritten. No restore to an original path is attempted. No bulk conversion, catalog migration or capacity release is authorized by preparation or by a successful small pilot.

Preparation metadata/tool-help observation completed **dd8723/0**. The retained local help identifies Zstandard **1.5.5** with `--patch-from`; executable SHA is `7c5468b370f7c47eda07281e3437fafc568f95d10420051e3aa522709f9342c5`. AST parsing is preparation validation only; all actual codec/readback/refusal results remain pending.
