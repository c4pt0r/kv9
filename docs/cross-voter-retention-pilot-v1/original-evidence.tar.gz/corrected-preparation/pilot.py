"""Produce six ordinary objects and four cross-voter patches; no retirement."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from common import P,CPUS,MIB,Session,save,digest,identity,check,load_selection,check_originals

def main():
    a=argparse.ArgumentParser();a.add_argument('--approve-selection-sha256',required=True)
    a.add_argument('--approve-code-sha256',required=True);a.add_argument('--output',required=True);args=a.parse_args()
    code=json.loads((P/'code-pins.json').read_text())
    if hashlib.sha256((P/'code-pins.json').read_bytes()).hexdigest()!=args.approve_code_sha256:raise RuntimeError('code pin manifest')
    for name,pin in code.items():check(P/name,pin,'pilot code changed')
    if set(os.sched_getaffinity(0))!=CPUS:raise RuntimeError('exact helper CPU placement required')
    selection=load_selection(args.approve_selection_sha256)
    root=Path(args.output)
    if root!=Path(selection['output']):raise RuntimeError('exact fresh output path required')
    root.mkdir(mode=0o700)
    baseline=dict(started_ns=time.time_ns(),started_monotonic_ns=time.monotonic_ns(),device=os.stat(root).st_dev)
    save(root/'baseline.json',baseline)
    session=Session(root,baseline);result=dict(complete=False,roundtrip_accepted=False,selection_sha256=args.approve_selection_sha256,code_pins_sha256=args.approve_code_sha256)
    try:
        session.guard();check_originals(selection)
        zstd=selection['codec']['path'];outputs=[]
        for m in selection['members']:
            raw=root/(m['id']+'.raw')
            session.codec('decode-original-'+m['id'],[zstd,'-q','-d','--single-thread','--memory=512MiB','-c',m['object_path']],raw,m['original']['bytes'],decoded=True)
            check(raw,m['original'],'original decoded SHA/length mismatch')
            ordinary=root/(m['id']+'.ordinary.zst')
            flags=[zstd,'-q','--no-progress','--single-thread','-3','--check','--zstd=wlog=26']
            session.codec('ordinary-'+m['id'],flags+['-c',str(raw)],ordinary,min(128*MIB,m['original']['bytes']+MIB))
            row=dict(id=m['id'],raw=str(raw),ordinary=str(ordinary),ordinary_digest=digest(ordinary))
            if m['voter']!='n1':
                base=root/(m['group']+'-n1.raw');patch=root/(m['id']+'.patch.zst')
                check(base,next(x['original'] for x in selection['members']if x['id']==m['group']+'-n1'))
                session.codec('patch-'+m['id'],flags+['--patch-from='+str(base),'-c',str(raw)],patch,min(128*MIB,m['original']['bytes']+MIB))
                row.update(base=str(base),patch=str(patch),patch_digest=digest(patch))
            outputs.append(row)
        check_originals(selection)
        result.update(complete=True,outputs=outputs,decoded_bytes=session.decoded,resource=session.guard(),
                      scope='Producer complete; independent ordinary/patch readback and refusal controls remain required. Original objects/catalogs unchanged.')
    except BaseException as exc:
        result['error']=repr(exc)
    finally:
        result.update(ended_ns=time.time_ns(),children=session.records,all_codec_children_reaped=all(x.get('reaped') for x in session.records))
        save(root/'producer-result.json',result)
    print(json.dumps(dict(complete=result['complete'],roundtrip_accepted=False,result=str(root/'producer-result.json'),result_sha256=digest(root/'producer-result.json')['sha256'])))
    return 0 if result['complete'] else 1
if __name__=='__main__':sys.exit(main())
