"""Finite metadata observation of exactly three accepted 24-cohort screens. No payload opens."""
import hashlib,json,os,re,stat,time
from pathlib import Path,PurePosixPath
OUT=Path(__file__).resolve().parent
SCREENS=[
 ('fnv-writer','/tmp/kv9-fnv-writer-performance-budget-v2-preparation-20260914-first','/tmp/kv9-fnv-writer-performance-budget-v2-root-20260914-first','/tmp/kv9-fnv-writer-performance-budget-v2-smoke-20260914-first','/tmp/kv9-fnv-writer-performance-budget-v2-timing-20260914-first/cohorts','WRITE-FNV-WRITER-PERFORMANCE.md'),
 ('published-directory','/tmp/kv9-published-directory-performance-v3-preparation-20260915-first','/tmp/kv9-published-directory-performance-v3-root-20260915-second','/tmp/kv9-published-directory-performance-v3-smoke-20260915-first','/tmp/kv9-published-directory-performance-v3-timing-20260915-first/cohorts','WRITE-PUBLISHED-DIRECTORY-PERFORMANCE.md'),
 ('frame-buffer-crc','/tmp/kv9-frame-crc-performance-preparation-20260914-first','/tmp/kv9-frame-crc-performance-root-20260914-first','/tmp/kv9-frame-crc-performance-smoke-20260914-first','/tmp/kv9-frame-crc-performance-timing-20260914-first/cohorts','WRITE-FRAME-BUFFER-CRC-PERFORMANCE.md')]
PINNED=[];ISSUES=[];MEMBERS=[];COHORTS=[];SUMMARIES=[];OBJECTS={};METADATA_BYTES=0

def read(p,expected=None):
 global METADATA_BYTES
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size<=8*1024**2,(p,s.st_size)
 raw=p.read_bytes();METADATA_BYTES+=len(raw);assert METADATA_BYTES<128*1024**2
 h=hashlib.sha256(raw).hexdigest();pin=dict(path=str(p),bytes=len(raw),sha256=h)
 if expected is not None:assert pin['bytes']==expected['bytes']and h==expected['sha256'],p
 PINNED.append(pin)
 return json.loads(raw)
def pintext(p):
 p=Path(p);raw=p.read_bytes();assert len(raw)<1024**2
 PINNED.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
def save(name,x):
 raw=(json.dumps(x,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<16*1024**2
 with (OUT/name).open('xb')as f:f.write(raw)
def current_object(path,m,physical):
 # Stat only: compressed payload is never opened or hashed.
 try:s=path.lstat()
 except FileNotFoundError:return dict(eligible=False,reason='missing_object')
 current=dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,blocks=s.st_blocks,mode=s.st_mode,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink)
 old=physical.get(str(path));reasons=[]
 if not stat.S_ISREG(s.st_mode):reasons.append('not_regular')
 if s.st_size!=m['compressed_bytes']:reasons.append('catalog_size_mismatch')
 if old is None:reasons.append('absent_from_accepted_physical_inventory')
 elif any(current[k]!=old[k]for k in ['device','inode','bytes','blocks','mode','mtime_ns','ctime_ns']):reasons.append('changed_since_accepted_physical_inventory')
 if s.st_nlink!=1:reasons.append('not_single_link')
 return dict(eligible=not reasons,reasons=reasons,current=current,allocated_bytes=s.st_blocks*512)
def allocated(rows):
 unique={}
 for row in rows:
  obs=row['observation']
  if 'current'in obs:unique[(obs['current']['device'],obs['current']['inode'])]=obs['allocated_bytes']
 return sum(unique.values())

for label,prep,root,smoke,timing,doc in SCREENS:
 prep=Path(prep);root=Path(root);roots={'smoke':Path(smoke),'timing':Path(timing)}
 pintext(Path('/home/dongxu/kv9/docs')/doc)
 terminals={kind:read(root/(kind+'-terminal.json'))for kind in ['smoke','timing','audit']}
 assert all(t['exit_code']==0 and t.get('terminal_receipt',t.get('actual_terminal_receipt'))for t in terminals.values())
 audit=read(prep/'results-first/audit.json');audit_pin=PINNED[-1]
 assert audit_pin['sha256']==terminals['audit'].get('audit_sha256',terminals['audit']['result_sha256'])
 assert audit['complete'] and audit['matched_diagnostic_accepted'] and audit['successful_arms']==16
 assert audit['owned_lifetimes_exited']==64 and audit['smoke']['owned_lifetimes_exited']==32 and audit['qualifying_drains']==48
 assert audit['compressed_retention']['independently_decoded_all_bytes'] and audit['compressed_retention']['resident_original_paths']is False
 inv=read(prep/'results-first/input-inventory.json');invpin=PINNED[-1]
 if 'input_inventory_sha256'in terminals['audit']:assert invpin['sha256']==terminals['audit']['input_inventory_sha256']
 physical_doc=read(prep/'results-first/combined-physical-retention.json');physical=physical_doc['metadata'];assert physical_doc['complete']
 expected={'smoke':{Path(x['directory'])for x in audit['smoke']['cases']},'timing':{Path(x['cohort'])for x in audit['compressed_retention']['cohorts']}}
 assert len(expected['smoke'])==8 and len(expected['timing'])==16
 cats={Path(k):v for k,v in inv.items()if k.endswith('/retention-catalog.json')}
 wanted={c/'fixture/retention-catalog.json' for v in expected.values()for c in v}
 if set(cats)!=wanted:ISSUES.append(dict(screen=label,kind='catalog_scope_difference',missing=sorted(map(str,wanted-set(cats))),extra=sorted(map(str,set(cats)-wanted))))
 screen_rows=[];catalog_count=0
 for phase,cohorts in expected.items():
  assert all(p.parent==roots[phase]for p in cohorts)
  ordinals=sorted(int(p.name.split('-',1)[0])for p in cohorts);assert ordinals==list(range(8 if phase=='smoke' else 16))
  for cohort in sorted(cohorts):
   cp=cohort/'fixture/retention-catalog.json';entry=cats.get(cp)
   if entry is None or not cp.exists():ISSUES.append(dict(screen=label,cohort=str(cohort),kind='missing_catalog'));continue
   c=read(cp,entry);catalog_count+=1
   assert c['fixture']==str(cp.parent) and c['representation']=='zstd-files-v1'and c['resident_original_paths']is False and not c['synthetic_only'] and c['verified_unix_ns']>0
   assert all(x['absent'] and isinstance(x['exit_code'],int)for x in c['children'])
   assert all(x['complete'] and x['absent'] and x['exit_code']==0 for x in c['codecs'])
   all_names=[m['name']for m in c['members']];assert len(all_names)==len(set(all_names))
   engine=[];nonengine=0;generations={f'n{x}':set()for x in (1,2,3)}
   for m in c['members']:
    match=re.fullmatch(r'(n[123])/catalog\.segments/([^/]+)/([0-9]{20})\.wal',m['name'])
    if not match:nonengine+=1;continue
    voter,generation,ordinal=match.groups();ordinal=int(ordinal);generations[voter].add(generation)
    op=PurePosixPath(m['object']);assert not op.is_absolute()and '..'not in op.parts and len(op.parts)==2 and op.parts[0]=='retention-objects'and op.suffix=='.zst'
    path=cp.parent/m['object'];obs=current_object(path,m,physical)
    row=dict(screen=label,phase=phase,cohort=str(cohort),catalog=str(cp),catalog_sha256=entry['sha256'],voter=voter,generation=generation,segment_ordinal=ordinal,name=m['name'],object=str(path),compressed_bytes=m['compressed_bytes'],compressed_sha256=m['compressed_sha256'],logical_bytes=m['original']['bytes'],logical_sha256=m['original']['sha256'],observation=obs)
    engine.append(row);MEMBERS.append(row);screen_rows.append(row)
    if not obs['eligible']:ISSUES.append(dict(screen=label,cohort=str(cohort),kind='object_metadata_ineligible',object=str(path),observation=obs))
   unique={};ambiguous=[]
   for r in engine:
    key=(r['voter'],r['segment_ordinal'])
    if key in unique:ambiguous.append(key)
    unique[key]=r
   if any(len(v)!=1 for v in generations.values())or ambiguous:ISSUES.append(dict(screen=label,cohort=str(cohort),kind='ambiguous_generation_or_ordinal',generations={k:sorted(v)for k,v in generations.items()},ambiguous=ambiguous))
   pairs=[];unpaired=[];bases={}
   for row in engine:
    if row['voter']=='n1':continue
    base=unique.get(('n1',row['segment_ordinal']))
    if base is None or ambiguous or any(len(v)!=1 for v in generations.values())or not row['observation']['eligible']or not base['observation']['eligible']:
     unpaired.append(dict(object=row['object'],name=row['name'],reason='missing_or_ambiguous_or_metadata_ineligible_n1_base_or_target'));continue
    row['paired_base_object']=base['object'];bases[base['object']]=base;pairs.append(row)
   for row in engine:row['role']='paired_target'if 'paired_base_object'in row else 'base'if row['voter']=='n1'else 'unpaired_target'
   COHORTS.append(dict(screen=label,phase=phase,cohort=str(cohort),catalog=str(cp),catalog_sha256=entry['sha256'],engine_members=len(engine),nonengine_members_excluded=nonengine,engine_allocated_bytes=allocated(engine),n1_base_members=sum(r['voter']=='n1'for r in engine),n1_base_allocated_bytes=allocated([r for r in engine if r['voter']=='n1']),used_base_members=len(bases),used_base_allocated_bytes=allocated(list(bases.values())),eligible_n2_targets=sum(r['voter']=='n2'for r in pairs),eligible_n3_targets=sum(r['voter']=='n3'for r in pairs),eligible_target_allocated_bytes=allocated(pairs),unpaired_targets=unpaired,raw_length_equal_pairs=sum(r['logical_bytes']==unique[('n1',r['segment_ordinal'])]['logical_bytes']for r in pairs)))
 ss=[c for c in COHORTS if c['screen']==label]
 SUMMARIES.append(dict(screen=label,accepted_smoke_cohorts=8,accepted_timing_cohorts=16,current_catalogs=catalog_count,engine_members=len(screen_rows),engine_allocated_bytes=allocated(screen_rows),n1_base_members=sum(r['voter']=='n1'for r in screen_rows),n1_base_allocated_bytes=allocated([r for r in screen_rows if r['voter']=='n1']),eligible_n2_targets=sum(r.get('role')=='paired_target'and r['voter']=='n2'for r in screen_rows),eligible_n3_targets=sum(r.get('role')=='paired_target'and r['voter']=='n3'for r in screen_rows),eligible_target_allocated_bytes=allocated([r for r in screen_rows if r.get('role')=='paired_target']),unpaired_target_count=sum(len(c['unpaired_targets'])for c in ss),historical_full_campaign_allocation=audit['compressed_retention']['combined_independent_allocated_bytes'],audit= audit_pin,input_inventory=invpin))

now=time.time_ns();save('members.json',dict(scope='Metadata-only ordinal pairs. Catalog hashes are inherited accepted payload identities; payload bytes were not opened or verified now.',observed_unix_ns=now,members=MEMBERS))
save('cohorts.json',dict(cohorts=COHORTS))
save('metadata-pins.json',dict(files=PINNED,metadata_bytes_read=METADATA_BYTES))
summary=dict(complete=True,metadata_only=True,observed_unix_ns=now,scope='Exactly three accepted screens, each eight smoke and sixteen timed cohorts. Pairing n2/n3 engine catalog.segments WAL with same-cohort n1 ordinal, requiring one generation per voter and exact present object metadata. No byte-similarity inference, predicted saving, deletion authority or performance claim.',screens=SUMMARIES,totals=dict(catalogs=sum(x['current_catalogs']for x in SUMMARIES),engine_members=len(MEMBERS),engine_allocated_bytes=allocated(MEMBERS),n1_base_members=sum(r['voter']=='n1'for r in MEMBERS),n1_base_allocated_bytes=allocated([r for r in MEMBERS if r['voter']=='n1']),eligible_n2_targets=sum(r.get('role')=='paired_target'and r['voter']=='n2'for r in MEMBERS),eligible_n3_targets=sum(r.get('role')=='paired_target'and r['voter']=='n3'for r in MEMBERS),eligible_target_allocated_bytes=allocated([r for r in MEMBERS if r.get('role')=='paired_target']),unpaired_targets=sum(len(c['unpaired_targets'])for c in COHORTS)),issues=ISSUES,limits=dict(max_screens=3,max_cohorts_per_screen=24,max_metadata_member_bytes=8*1024**2,max_metadata_read_bytes=128*1024**2),payloads_read=0,codecs_executed=0,mutation_authorized=False)
save('summary.json',summary);print(json.dumps(summary,indent=2))
