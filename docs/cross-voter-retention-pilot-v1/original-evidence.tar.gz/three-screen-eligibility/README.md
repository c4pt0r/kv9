# Cross-voter engine-WAL eligibility

Metadata-only assessment of exactly the three documented completed write screens. All 72 expected catalogs (24 per screen) are present and match accepted audit input hashes. Current engine object device/inode/size/allocation/mode/mtime/ctime match the accepted physical inventories; all are single-link regular files. Compressed payloads were never opened.

| Screen | n1 bases | Base allocated bytes | n2 targets | n3 targets | Target allocated bytes |
| --- | ---: | ---: | ---: | ---: | ---: |
| fnv-writer | 746 | 8,684,171,264 | 744 | 746 | 17,368,993,792 |
| published-directory | 741 | 8,617,615,360 | 739 | 741 | 17,235,668,992 |
| frame-buffer-crc | 742 | 8,634,216,448 | 741 | 741 | 17,269,055,488 |

Totals: **2,229 n1 bases / 25,936,003,072 allocated bytes** and **4,452 paired n2/n3 targets / 51,873,718,272 allocated bytes**. Allocation counts unique inodes. `by-voter.json` separates n2/n3 allocation and compressed file lengths. `cohorts.json` gives every cohort; `members.json` retains exact paths, accepted hashes and current stat observations.

Pairing uses one engine generation per voter and the same numeric segment ordinal within the same cohort. It ignores the voter-specific generation directory name. Only 1,014 pairs have equal raw lengths; neither ordinal nor length establishes byte similarity or patch success. Engine catalog.segments files are the sole scope: Raft logs, catalog.wal descriptors, other metadata and all other screens are excluded.

One target is unpaired: FNV timing `011-old-point-r000-p10064`, n2 segment 15, object `fixture/retention-objects/000047.zst`; n1 has no matching ordinal. Its 274,432 allocated bytes are excluded. No cohorts or inspected engine objects are missing or changed.

This is a feasibility ceiling on current target allocation, not predicted savings, reservation, migration selection or deletion authority. New patch objects and metadata consume additional space; the n1 bases must remain available. Every future representation change still requires independently verified exact reconstruction of the original retained encoded bytes and original raw bytes, explicit dependency and exclusive restore handling, and fresh root review. No retention conversion was performed.

Actual metadata observation: direct tool terminal `8f5394/0`; 44,134,320 metadata bytes read. Initial parse-only failure `329176/1` is preserved with its source; it preceded all metadata or payload reads. Docs and terminal pins are in `metadata-pins.json`, with the directory published-inventory closure separate. No source, original evidence, object, cache or runtime state was changed.
