# CRC full-regression engine-WAL eligibility

All **72 accepted catalogs** (24 smoke + 48 timing) are present and match their accepted audit input hashes. Exact audit SHA is `99e3912ae4463aff73d038ae7b054aa70c2a8b322e9e29619aff3aed3e731d34`; input inventory SHA is `f97d13e83b92820fc6d3435f553ae2bca8bbcab74096577c8356a33a754b00e5`. Actual root audit terminal is `12850/3b33fa/0`, timing `76372/3727d8/0`, smoke `1330/0dffdf/0`.

| Retained role | Members | Current allocated bytes |
| --- | ---: | ---: |
| n1 bases | 1,224 | 13,898,285,056 |
| Eligible n2/n3 targets | 2,447 | 27,797,909,504 |
| All scoped engine segments | 3,671 | 41,696,194,560 |

Every inspected compressed engine object is a single-link regular file whose device, inode, size, blocks, mode, mtime and ctime match the accepted physical inventory. No missing/changed catalogs or objects, ambiguous generations, or unpaired targets were found. `by-voter.json` separates n2/n3 and smoke/timing. `cohorts.json` lists every cohort; `members.json` gives exact pair paths, original encoded/raw hashes and fresh metadata identities.

Pairing means n2 or n3 against n1 in the same cohort and numeric segment ordinal, with one engine generation per voter. The per-voter generation UUID is not presumed equal. Matching ordinal does not prove byte equality, patch efficiency or reconstructibility. Only `n[123]/catalog.segments/<generation>/<ordinal>.wal` members are included. Raft logs, descriptors, all other artifacts and every other campaign remain excluded.

The original full-campaign allocation of 84,585,664,512 bytes is historical accepted accounting, not new free space or the target estimate. **27,797,909,504 bytes is only the additional target allocation ceiling**, before any patch objects, transaction metadata or working space. Bases remain retained. No savings, capacity readiness, migration selection or deletion authority is claimed.

The documented portable evidence is commit `425ae37f8f2dbf7dea22c63af2c4cccc9f38eb05`, `docs/write-crc-full-regression-v1`; exact local audit, terminal and catalog paths are pinned in `metadata-pins.json`. This observation preserves the earlier three-screen result untouched. No compressed payload was opened, no codec ran, and no original evidence or source was mutated. Any later conversion requires separate qualification, exact encoded/raw reconstruction checks and root review.

Metadata observation completed at direct tool terminal `db58c5/0`. The finite source derivative changes only this one fixed scope, cohort/count expectations and its actual terminal schema; all lstat and unique-inode accounting functions are unchanged from the prior observation. No tests or migration framework were added.
