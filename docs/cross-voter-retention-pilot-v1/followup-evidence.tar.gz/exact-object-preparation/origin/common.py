"""Small pilot I/O and child guard; never removes or rewrites an original."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import time

GIB=1024**3
MIB=1024**2
CPUS=set(range(6,16))|set(range(22,32))
P=Path(__file__).resolve().parent

def save(path, data):
    with Path(path).open('x') as f:
        json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())

def identity(path):
    s=Path(path).lstat()
    if not stat.S_ISREG(s.st_mode): raise RuntimeError('not regular: '+str(path))
    return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,
                nlink=s.st_nlink,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,allocated_bytes=s.st_blocks*512)

def digest(path, limit=128*MIB):
    before=identity(path)
    if before['bytes']>limit: raise RuntimeError('file size limit')
    h=hashlib.sha256();n=0
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        s=os.fstat(f.fileno())
        if (s.st_dev,s.st_ino)!=(before['device'],before['inode']):raise RuntimeError('opened identity changed')
        while chunk:=f.read(MIB):n+=len(chunk);h.update(chunk)
    if identity(path)!=before:raise RuntimeError('file changed during hash')
    return dict(bytes=n,sha256=h.hexdigest())

def check(path, expected, code='digest_mismatch'):
    actual=digest(path)
    if actual!={k:expected[k]for k in ['bytes','sha256']}:raise RuntimeError(code)
    return actual

def load_selection(pin):
    raw=(P/'selection.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=pin:raise RuntimeError('selection pin')
    s=json.loads(raw)
    for item in s['metadata_inputs']:check(item['path'],item,'metadata authority changed')
    check(s['codec']['path'],s['codec'],'codec changed')
    if identity(s['codec']['path'])!=s['codec']['identity']:raise RuntimeError('codec identity changed')
    return s

def check_originals(selection):
    for m in selection['members']:
        if identity(m['object_path'])!=m['object_identity']:raise RuntimeError('original object identity changed')
        check(m['object_path'],m['compressed'],'original object changed')

def allocated(root):
    total=0
    for base,dirs,names in os.walk(root,followlinks=False):
        for p in [Path(base)]+[Path(base)/n for n in names]:
            s=p.lstat()
            if stat.S_ISLNK(s.st_mode):raise RuntimeError('pilot symlink')
            total+=s.st_blocks*512
        if any((Path(base)/d).is_symlink() for d in dirs):raise RuntimeError('pilot symlink directory')
    return total

class Session:
    def __init__(self, root, baseline, decoded=0):
        self.root=Path(root);self.baseline=baseline;self.decoded=decoded;self.records=[]
        self.minimum_available=None;self.maximum_allocation=0;self.guard_observations=0
    def guard(self,reserve=0):
        if os.stat(self.root).st_dev!=self.baseline['device']:raise RuntimeError('pilot device changed')
        v=os.statvfs(self.root);free=v.f_bavail*v.f_frsize
        if free<8*GIB+reserve:raise RuntimeError('8 GiB available floor/reservation')
        used=allocated(self.root)
        self.minimum_available=free if self.minimum_available is None else min(self.minimum_available,free)
        self.maximum_allocation=max(self.maximum_allocation,used);self.guard_observations+=1
        if used+reserve>GIB:raise RuntimeError('1 GiB pilot allocation cap')
        if time.monotonic_ns()-self.baseline['started_monotonic_ns']>1200*10**9:raise RuntimeError('1200 second combined deadline')
        return dict(available_bytes=free,pilot_allocated_bytes=used,observed_ns=time.time_ns(),
                    observed_minimum_available_bytes=self.minimum_available,observed_maximum_pilot_allocation_bytes=self.maximum_allocation,
                    guard_observations=self.guard_observations)
    def codec(self,label,argv,destination,limit,decoded=False,allow_failure=False):
        if not 0<limit<=128*MIB:raise RuntimeError('member cap')
        if decoded and self.decoded+limit>512*MIB:raise RuntimeError('512 MiB decoded total cap')
        before=self.guard(limit+MIB)
        out=Path(destination);err=out.with_name(out.name+'.stderr')
        record=dict(label=label,argv=argv,output=str(out),stderr=str(err),started_ns=time.time_ns(),
                    limit_bytes=limit,decoded=decoded,rlimit_as_bytes=512*MIB,cpu_affinity=sorted(CPUS),resource_before=before)
        child=None;failure=None
        def child_limits():
            os.sched_setaffinity(0,CPUS)
            resource.setrlimit(resource.RLIMIT_AS,(512*MIB,512*MIB))
            resource.setrlimit(resource.RLIMIT_FSIZE,(limit,limit))
            resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        try:
            with out.open('xb') as output,err.open('xb') as errors:
                child=subprocess.Popen(argv,stdout=output,stderr=errors,stdin=subprocess.DEVNULL,
                                       preexec_fn=child_limits,start_new_session=True,close_fds=True)
                record['pid']=child.pid
                ps=Path(f'/proc/{child.pid}/stat').read_text()
                record['start_ticks']=int(ps[ps.rfind(')')+2:].split()[19])
                record['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
                while child.poll() is None:
                    self.guard()
                    if out.stat().st_size>limit or err.stat().st_size>65536:raise RuntimeError('codec output bound')
                    time.sleep(.05)
                record['exit_code']=child.wait()
                output.flush();os.fsync(output.fileno());errors.flush();os.fsync(errors.fileno())
            if err.stat().st_size>65536 or out.stat().st_size>limit:raise RuntimeError('codec output bound')
        except BaseException as exc:
            failure=repr(exc)
        finally:
            if child is not None:
                if child.poll() is None:
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                record['exit_code']=child.wait();record['reaped']=True
            record.update(ended_ns=time.time_ns(),complete=child is not None and failure is None,error=failure)
            if out.exists():
                record['output_bytes']=out.stat().st_size
                if decoded:self.decoded+=record['output_bytes']
            self.records.append(record)
            save(out.with_name(out.name+'.child.json'),record)
        if failure is not None:raise RuntimeError(failure)
        self.guard()
        if record['exit_code']!=0 and not allow_failure:raise RuntimeError('codec failed: '+label)
        return record
