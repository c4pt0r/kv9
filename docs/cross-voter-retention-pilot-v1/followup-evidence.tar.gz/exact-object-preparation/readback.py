"""Independently check original compressed identity, then original logical identity."""
import argparse,json,os,sys,time
from pathlib import Path
from common import P,CPUS,Session,save,digest,identity,check,load_selection

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--selection-sha256',required=True);ap.add_argument('--code-pins-sha256',required=True);ap.add_argument('--reconstruction-result-sha256',required=True);a=ap.parse_args()
    if digest(P/'code-pins.json')['sha256']!=a.code_pins_sha256:raise RuntimeError('code pins')
    for name,pin in json.loads((P/'code-pins.json').read_text()).items():check(P/name,pin)
    if set(os.sched_getaffinity(0))!=CPUS:raise RuntimeError('helper CPU binding')
    sel=load_selection(a.selection_sha256);root=Path(sel['output']);rp=root/'result.json'
    if digest(rp)['sha256']!=a.reconstruction_result_sha256:raise RuntimeError('actual reconstruction result pin')
    producer=json.loads(rp.read_text())
    if not producer['complete']or not producer['exact_objects_reproduced']or not producer['all_children_reaped']:raise RuntimeError('reconstruction failed')
    if producer['selection_sha256']!=a.selection_sha256 or producer['code_pins_sha256']!=a.code_pins_sha256:raise RuntimeError('source binding')
    if len(producer['rows'])!=6 or len({r['id']for r in producer['rows']})!=6 or {r['id']for r in producer['rows']}!={m['id']for m in sel['members']}:raise RuntimeError('six-member count/identity')
    if len(producer['children'])!=6 or any(r['exit_code']!=0 or not r['reaped']or not r['complete']for r in producer['children']):raise RuntimeError('six encoder exits')
    dest=root/'readback-first';dest.mkdir(mode=0o700);s=Session(root,json.loads((root/'baseline.json').read_text()))
    result=dict(complete=False,exact_object_compatibility=False,selection_sha256=a.selection_sha256,reconstruction_result_sha256=a.reconstruction_result_sha256)
    rows=[]
    try:
        s.guard()
        for m in sel['members']:
            raw=Path(m['raw_path'])
            if identity(raw)!=m['raw_identity']:raise RuntimeError('raw source metadata changed')
            check(raw,m['original'],'raw original digest changed')
            obj=root/(m['id']+'.original-object.zst')
            compressed=check(obj,m['compressed'],'original compressed SHA/length mismatch')
            before=identity(obj);fd=os.open(obj,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
            try:
                fs=os.fstat(fd)
                if (fs.st_dev,fs.st_ino)!=(before['device'],before['inode']):raise RuntimeError('object stdin race')
                decoded=dest/(m['id']+'.decoded')
                s.codec('independent-original-readback-'+m['id'],m['original_decode_receipt']['argv'],decoded,m['original']['bytes'],decoded=True,stdin_fd=fd)
            finally:os.close(fd)
            logical=check(decoded,m['original'],'original logical SHA/length mismatch')
            if identity(obj)!=before:raise RuntimeError('reconstructed object changed')
            rows.append(dict(id=m['id'],compressed=compressed,logical=logical,exact_original_object=True,decoded_to_eof=True))
        result.update(complete=True,exact_object_compatibility=True,verified_members=len(rows),resource=s.guard(),decoded_bytes=s.decoded,
                      original_compressed_objects_read=False,original_paths_restored=False,retired_bytes=0,
                      scope='Exact old compressed bytes and decoded identities for six sampled members only; no general migration qualification')
    except BaseException as exc:result['error']=repr(exc)
    finally:
        result.update(rows=rows,children=s.records,all_children_reaped=all(r.get('reaped')for r in s.records),ended_ns=time.time_ns())
        save(dest/'result.json',result)
    print(json.dumps(dict(complete=result['complete'],result=str(dest/'result.json'),result_sha256=digest(dest/'result.json')['sha256'])))
    return 0 if result['complete']else 1
if __name__=='__main__':sys.exit(main())
