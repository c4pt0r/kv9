# Six-member exact compressed-object reconstruction

Preparation only: no codec, original-payload read, reconstruction, test or cleanup was executed by this helper. Root runs the two serial arrays in `commands.json`, binding the independent readback command to the actual successful reconstruction result SHA. Every output goes below a fresh `reconstruction-first` directory; nothing is restored to an original path.

The six input files are exclusively the already verified `.raw` outputs of the accepted second patch pilot. They total **100,639,065 bytes**. Their original ordinary compressed identities total **67,878,587 bytes**, as pinned by the accepted directory-screen catalogs and input inventory. The accepted pilot summary SHA is `980e7352d6e684f90b9b426ab11714215a6b435930f62a0b3b55d039bb405be2`; all 30 original pilot codec lifetimes were observed absent. Original failure `2dcf60/1` remains separately hash-bound; the successful patch producer/readback receipts are `99674/8dfa0b/0` and `73260/ac2d2e/0`.

## Exact input mode

The original `compressed_retention.py` is source-bound by the screen protocol to SHA `1f87075106081831d689ddcb5d21ad744f2a1ea3c8554e1d048045ff74fdec6a`. Its `file_fd` at line 67 opens the original using `O_RDONLY|O_NOFOLLOW|O_NOATIME`. Its codec at lines 194–206 supplies that fresh regular-file descriptor directly as stdin. It is neither a Python-fed pipe nor a named input argument. See the retained source and `source-mode-excerpt.txt`.

Every selected original encoder receipt has this exact argv:

```
/usr/bin/zstd -q --no-progress --single-thread -3 --check --zstd=wlog=26 -c
```

The follow-up uses precisely that argv, the same pinned Zstandard 1.5.5 executable, regular-file stdin opened with the same flags at offset zero, and regular-file stdout. There is no filename or `--stream-size` pledge. It adds only process/resource constraints outside the compression arguments. The prior pilot's named-file ordinary objects were three bytes larger for **each** selected member; their logical round trips passed but their compressed identity was not the old catalog identity. This observation motivates the input-mode replay; it does not prove replay will match before the actual experiment.

## Reconstruction and independent readback

`reconstruct.py` checks all metadata/code/tool pins and each raw input's full original SHA256/length plus current stat identity. It then opens that raw file as stdin and serially reconstructs six fresh `.zst` files. Each result is hashed to EOF and compared against the **original catalog compressed SHA256 and length**, not the prior named-file object or a producer-created expectation. Raw input identity/digest is checked again afterward.

All six byte comparisons are retained even if a compressed identity differs. A completed comparison with any mismatch returns exit 1 and `exact_objects_reproduced=false`; failed codec/guard/input checks stop execution and preserve partial outputs and child records. There is no retry or alternate-flag search that could hide a first failure. A logical match cannot substitute for the required compressed match.

The separate `readback.py` requires the actual successful reconstruction result SHA, six exact member identities and six reaped successful encoder receipts. It independently hashes each reconstructed object against the original catalog authority, then decodes it using the original receipt argv and regular-file stdin:

```
/usr/bin/zstd -q --no-progress --single-thread -d --memory=64MB -c
```

Each complete decoded SHA256/length must equal the original WAL authority. This decoder's explicit 64 MiB window limit remains below the additional **512 MiB process address-space cap**. Original compressed objects are never opened: their immutable recorded hashes/lengths provide the compatibility target. No previous catalog semantics are changed.

## Bounds and preserved evidence

- CPUs 6–15,22–31; one codec child at a time, all exits/reaps recorded.
- Encoder/decoder `RLIMIT_AS` at most 512 MiB; core dumps disabled.
- Fresh output allocation at most 1 GiB, with an 8 GiB `f_bavail` floor and reservation checks before each output. Existing verified raw files are read only and not charged again as fresh allocation.
- At most 128 MiB per output; tighter known source-length limits are used. Independent decoded output is capped at 512 MiB total and is expected to be exactly 100,639,065 bytes.
- One combined 1,200-second deadline starts with reconstruction. Run independent readback promptly against the same baseline; no deadline reset.
- Fresh paths and exclusive output creation; original sources, raw pilot outputs, valid patches, ordinary objects, catalogs and all first failures remain unchanged.

`common.py` is a narrow derivative of the already accepted pilot guard: only `Session.codec` gains an optional regular-file stdin descriptor and records/checks that descriptor's type, identity and zero starting offset. All other functions and bounds remain unchanged. The caller owns descriptor closure in `finally`. `common.py.diff` preserves the exact delta.

A successful result qualifies exact byte reconstruction only for these six sampled members, current pinned codec and replay recipe. It is not a general determinism theorem, a migration controller, deletion authorization or a capacity reclamation receipt. Any future retirement would need its own preservation/restore/ownership qualification. No retired bytes are reported here.

Metadata/source preparation completed `8676a9/0`. A subsequent nonprivileged attempt to adjust the new selection's decoder-limit description failed with `PermissionError` (`fdc752/1`); the privileged metadata-only correction completed `89c023/0`. No original file or codec ran in either attempt. The original encoder flags and sample identities were unaffected; the final selection explicitly records the unchanged original `--memory=64MB` decoder option.
