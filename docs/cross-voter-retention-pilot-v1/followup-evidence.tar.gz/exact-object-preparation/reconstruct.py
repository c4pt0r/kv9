"""Replay exact catalog encoder argv with verified regular-file stdin; no old-object reads."""
import argparse,json,os,sys,time
from pathlib import Path
from common import P,CPUS,MIB,Session,save,digest,identity,check,load_selection

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--selection-sha256',required=True);ap.add_argument('--code-pins-sha256',required=True);a=ap.parse_args()
    if digest(P/'code-pins.json')['sha256']!=a.code_pins_sha256:raise RuntimeError('code pins')
    for name,pin in json.loads((P/'code-pins.json').read_text()).items():check(P/name,pin)
    if set(os.sched_getaffinity(0))!=CPUS:raise RuntimeError('helper CPU binding')
    sel=load_selection(a.selection_sha256);root=Path(sel['output']);root.mkdir(mode=0o700)
    baseline=dict(started_ns=time.time_ns(),started_monotonic_ns=time.monotonic_ns(),device=root.stat().st_dev)
    save(root/'baseline.json',baseline);s=Session(root,baseline)
    result=dict(complete=False,exact_objects_reproduced=False,independent_readback_pending=True,selection_sha256=a.selection_sha256,code_pins_sha256=a.code_pins_sha256)
    rows=[]
    try:
        s.guard()
        for m in sel['members']:
            raw=Path(m['raw_path'])
            if identity(raw)!=m['raw_identity']:raise RuntimeError('verified raw input identity changed')
            check(raw,m['original'],'verified raw original digest changed')
            target=root/(m['id']+'.original-object.zst')
            fd=os.open(raw,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
            try:
                fs=os.fstat(fd)
                if (fs.st_dev,fs.st_ino)!=(m['raw_identity']['device'],m['raw_identity']['inode']):raise RuntimeError('raw stdin race')
                receipt=s.codec('reconstruct-'+m['id'],m['original_compress_receipt']['argv'],target,
                                min(128*MIB,m['original']['bytes']+m['original']['bytes']//128+MIB),stdin_fd=fd)
                consumed=os.lseek(fd,0,os.SEEK_CUR)
            finally:os.close(fd)
            actual=digest(target)
            rows.append(dict(id=m['id'],output=str(target),expected_original_compressed=m['compressed'],actual_compressed=actual,
                             exact_original_compressed_bytes_match=actual==m['compressed'],stdin_file_offset_after=consumed,codec_receipt=receipt))
            if identity(raw)!=m['raw_identity']:raise RuntimeError('raw input metadata changed')
            check(raw,m['original'],'raw input changed after reconstruction')
        result.update(complete=True,exact_objects_reproduced=all(r['exact_original_compressed_bytes_match']for r in rows),resource=s.guard(),
                      source_scope='Only six already verified pilot raw inputs; original compressed objects and catalogs unchanged/unopened')
    except BaseException as exc:result['error']=repr(exc)
    finally:
        result.update(rows=rows,children=s.records,all_children_reaped=all(r.get('reaped')for r in s.records),ended_ns=time.time_ns())
        save(root/'result.json',result)
    print(json.dumps(dict(complete=result['complete'],exact_objects_reproduced=result['exact_objects_reproduced'],result=str(root/'result.json'),result_sha256=digest(root/'result.json')['sha256'])))
    return 0 if result['complete']and result['exact_objects_reproduced']else 1
if __name__=='__main__':sys.exit(main())
