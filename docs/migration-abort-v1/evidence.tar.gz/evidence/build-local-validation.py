import json, re, subprocess
from pathlib import Path

work = Path('/mnt/data/kv9-work/stranded-learner-20260917')
root = Path('/home/dongxu/kv9')

text = (work / 'workspace-serial.log').read_text()
tallies = [(int(a), int(b), int(c)) for a, b, c in re.findall(
    r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
serial = {
    'suites': len(tallies),
    'passed': sum(t[0] for t in tallies),
    'failed': sum(t[1] for t in tallies),
    'ignored': sum(t[2] for t in tallies),
    'exit_code': 0,
    'log': 'workspace-serial.log',
}
assert serial['failed'] == 0 and serial['suites'] > 0

minio = (work / 'minio-focused.log').read_text()
m = re.findall(r'test result: ok\. (\d+) passed; 0 failed', minio)
assert m, 'minio focused run must pass'

abort = json.loads((work / 'migration-abort-proof/result.json').read_text())
assert abort['accepted'] and abort['theorems'] == 13 and abort['semantic_controls'] == 5

siblings = {}
for model in ['data-range', 'group-activation', 'group-control', 'group-preparation',
              'joint-install', 'learner-attach', 'migration-authority',
              'protocol-snapshot', 'routed-client', 'source-capture', 'runtime-adoption',
              'install-evidence', 'source-truncation', 'voter-promotion', 'replica-removal',
              'storage-retirement', 'split-intent', 'partition-directory', 'parent-seal',
              'child-population', 'split-publication', 'parent-retirement', 'cross-range',
              'auto-split', 'cascade-split', 'storage-reclamation']:
    r = json.loads((work / f'{model}-proof/result.json').read_text())
    assert r['accepted'], model
    siblings[model] = {'theorems': r['theorems'], 'semantic_controls': r['semantic_controls']}

retention = (work / 'retention-ledger-recheck.log').read_text()
assert 'PASS: retention ledger' in retention.splitlines()[-1]

e2e = json.loads((work / 'e2e-eighth/result.json').read_text())
assert e2e['verdict'] == 'accepted'
for also in ('e2e-sixth', 'e2e-seventh'):
    assert json.loads((work / also / 'result.json').read_text())['verdict'] == 'accepted', also
sixth = json.loads((work / 'e2e-sixth/result.json').read_text())
for run in ('e2e-first', 'e2e-second', 'e2e-third', 'e2e-fourth', 'e2e-fifth'):
    assert json.loads((work / run / 'result.json').read_text())['verdict'] == 'failed', run

clippy = subprocess.run(
    ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'kv9-raft/testing'],
    cwd=root, capture_output=True, text=True)
warnings = len(re.findall(r'^warning:', clippy.stderr, re.M))
assert clippy.returncode == 0 and warnings == 0, (clippy.returncode, warnings)

out = {
    'schema': 1,
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'workspace': {'serial': serial},
    'lint': {'clippy_warnings': 0},
    'minio_focused': {'passed': int(m[-1]), 'log': 'minio-focused.log'},
    'migration_abort_model': {
        'theorems': abort['theorems'],
        'semantic_controls': abort['semantic_controls'],
        'policy_controls': abort['hole_and_axiom_controls'],
        'result': 'migration-abort-proof/result.json',
    },
    'sibling_lean_models': siblings,
    'retention_tlaps': {'log': 'retention-ledger-recheck.log', 'line': retention.splitlines()[-1]},
    'e2e': {'verdict': e2e['verdict'], 'checks': e2e['checks'], 'result': 'e2e-eighth/result.json'},
    'also_accepted': {'runs': ['e2e-sixth/result.json', 'e2e-seventh/result.json']},
    'failed_e2e_retained': ['e2e-first (Consumed admission wall -> revoke-admission verb)',
                            'e2e-second (incarnation gate wall -> pending takeover authority)',
                            'e2e-third (stale-heartbeat panic at empty log)',
                            'e2e-fourth (panic persisted -> step-layer heartbeat clamp)',
                            'e2e-fifth (attach replication-lag flake -> bounded retry)'],
    'not_claimed': ['truncation for aborted operations, object-store reclamation of abandoned images, '
                    'automatic abort, voter takeover, chaos, scaling, QPS, hosted CI'],
}
(work / 'local-validation.json').write_text(json.dumps(out, indent=2) + '\n')
print('local-validation.json written; serial', serial)
