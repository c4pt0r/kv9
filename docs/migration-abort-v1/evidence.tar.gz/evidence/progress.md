# Stranded-learner recovery (task #30) — progress

Baseline: 2ec7df1 (storage-reclamation). Port for e2e: 27100.

## Design decision (settled this session)
The reachable stranded case is a DESTINATION INCARNATION LOSS mid-
operation (before adoption evidence): the operation wedges forever —
the source pin sticks at Published (quiesce needs committed evidence;
evidence needs adoption at the EXACT named incarnation), truncation
stays blocked, the attached learner stays in the source config. A live
learner behind the compacted floor cannot arise through the committed
flow (the truncation gate requires every live migration's learner at/
above the floor or evidenced), and fresh learners are image-installed,
not log-replayed.

Increment: **committed migration ABORT authority** (kind 108, magic
KV9ABT01), the system-level recovery:
1. crates/meta/src/data_groups/abort.rs — kind-108 immutable idempotent
   row: operation, region, destination replica, subject (cross-checked
   vs the PUBLISHED source pin like record_install_evidence does).
   plan_abort REFUSES when committed evidence exists for the operation
   (completed operations never abort) and vice versa: evidence planning
   refuses when an abort row exists (add gate in evidence.rs);
   truncation planning gate unchanged (needs Released pin — abort
   provides the release path).
   `abort_matches_owner_pair(view, root, op_digest, subject)` mirrors
   evidence_matches_owner_pair (bounded raw TASKS scan).
2. crates/meta/src/retention.rs QuiesceAfterTransfer arm: accept
   evidence-matched OR abort-matched pairs (same subject+operation
   digest discipline). Tests mirror the evidence ones.
3. Runtime backend record_migration_abort (catalog txn: prepare/commit
   pattern like record_install_evidence, subject from published source
   pin via migration_owner_ids), release path reuses existing quiesce/
   release verbs (retention-apply). reconcile_adoption SKIPS aborted
   operations (alive-slow destination race closed in the safe
   direction); adopt_installed refuses aborted ops. record_install_
   evidence refuses when abort committed (system-wide wedge-proof).
4. Source config cleanup: remove the learner via driver conf change —
   check existing API (remove_voter exists; learner removal analog
   needed? attach used driver.attach_learner presumably — find it).
5. CLI verb record-migration-abort; e2e (attach+capture+publish, NO
   install, abort, pin Published→Quiesced→Released via retention-apply,
   truncate source, learner removed, then a NEW operation with a NEW
   destination incarnation completes the migration end to end).
6. Lean model proofs/lean/migration-abort/ (~12 theorems: abort refuses
   on evidence, evidence refuses on abort — mutual exclusion is
   permanent; release requires evidence XOR abort; aborted ops never
   adopt; the recovery chain completes) + prover + contract.
7. Docs docs/MIGRATION-ABORT.md + packet docs/migration-abort-v1 +
   issues #9 (replace) + #24 (append, D03 issue) + qualify (27 models).

## Key file map (from prior increments)
- evidence.rs: kind 104, from_row_for_siblings, migration_operation_digest,
  evidence_matches_owner_pair — MIRROR for abort.rs.
- retention.rs:810-828 the evidenced check to extend.
- runtime.rs record_install_evidence (~line 2235 area) — txn pattern;
  migration_retention.rs migration_owner_ids for subject cross-check.
- reconcile_adoption (runtime.rs ~5400) — add aborted-op skip.
- region_manager adopt_installed — add refusal.
- Serial suite 933 tests; 26 Lean models in qualify; retention inventory
  key source_pins.

## Status
- [x] abort.rs (kind 108, KV9ABT01, 136-byte payload, mutual exclusion with evidence both directions, 4 unit tests)
- [x] retention arm + tests (settled = evidence OR abort matched; test migration_pins_quiesce_and_release_with_a_matching_committed_abort; abort payload layout in test: magic+root+op+task+mig_task+region+node+incarnation+subject; 71 meta tests green)
- [x] runtime backend record_migration_abort (subject from PUBLISHED source pin via migration_owner_ids+retention_owner, refuses unless pin Published) + detach_aborted_learner (source leader, refuses voter destination, idempotent when absent, uses driver.remove_voter=RemoveNode)
- [x] api.rs RecordMigrationAbortResult/DetachAbortedLearnerResult + trait defaults
- [x] grpc handlers + proto RPCs (RecordMigrationAbort/DetachAbortedLearner) + DataGroupClient methods + 3 service! macro stubs
- [x] CLI verbs record-migration-abort / detach-aborted-learner + help
- [x] adoption fence: reconcile_adoption skips committed-abort operations
- [x] full workspace check zero errors
- [x] plan_migration + row-set decode: region reuse legal exactly when all other region migrations carry committed aborts (readback stays whole — cascade-defect class avoided); attach fences aborted ops; 72 meta tests
- [~] e2e 27100 (e2e-first: failed at re-admission 'Consumed (revoke it first)' -> added revoke-admission verb (meta revoke_admission exposed: backend+RPC+CLI+3 stubs); e2e-second: failed at re-registration 'rejected_invalid_incarnation' -> register() incarnation gate now skipped under a fresh PENDING admission (operator takeover authority), refresh_registration_endpoint performs the incarnation TAKEOVER (updates column, bumps generation; endpoint test rewritten to the new contract); e2e-third RUNNING. Original plan: (derive from scripts/destination-evidence-e2e.py: setup+migrate+attach+bind+capture; STRAND node4 (stop, never restart); record-migration-abort (committed+confirmed); retention-apply quiesce+release (abort settlement); detach-aborted-learner at source leader; wipe n4 + store-prepare NEW incarnation + admit + join; SECOND migration op2 completes fully install/adopt/evidence/quiesce/release. NOTE: truncation-after-abort OUT OF SCOPE (record_source_truncation requires evidence; document as limit))
- [x] Lean model 13 theorems + prover (5+2 controls) ACCEPTED + contract (pins: abort.rs evidence.rs migration.rs retention.rs runtime.rs e2e script model README)
- [ ] sibling refresh (AFTER all source settles: runtime.rs/endpoint.rs still moving)
- [ ] qualify + packet + publish + issues #9/#24
