"""Independent actual ordinal013 acceptance: retained receipts and streaming object hashes only."""
import fcntl,hashlib,importlib.util,json,os,stat,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
OLD=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first')
CAMP=Path('/tmp/kv9-cross-voter-multicohort-campaign-preparation-20260915-first')
ROOT=Path('/tmp/kv9-retention-013-reconciliation-root-20260915-first')
REPAIR=Path('/tmp/kv9-retention-013-reconciliation-preparation-20260915-first')
PIDFIX=Path('/tmp/kv9-retention-pid-identity-repair-20260915-first')
TX=Path('/tmp/kv9-cross-voter-group-013-fnv-writer-20260915-first')
EXEC=Path('/tmp/kv9-cross-voter-multicohort-execution-20260915-first')
CAMPOUT=Path('/tmp/kv9-cross-voter-multicohort-campaign-root-20260915-first')
FAILROOT=Path('/tmp/kv9-cross-voter-multicohort-campaign-failure-013-20260915-first')
MIB=1024**2;GIB=1024**3
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def pin(p,limit=16*MIB):
    p=Path(p);st=p.lstat();need(stat.S_ISREG(st.st_mode)and not p.is_symlink()and st.st_size<=limit,'bounded ordinary source/metadata')
    b=p.read_bytes();now=p.lstat();fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns');need(all(getattr(now,k)==getattr(st,k)for k in fields),'source/metadata changed');return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checksha(p,sha):need(pin(p)['sha256']==sha,'bound SHA differs: '+str(p))
def js(p):return json.loads(Path(p).read_text())
def save(p,d):
    with p.open('x')as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
    fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def load(name,p,sha):
    checksha(p,sha);spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
checksha(CAMP/'campaign.py','4d162d0a6ca48027b6de98fd174ba611f9cc72625e47d7787afc061895d94c97')
C=load('frozen_campaign_reader',CAMP/'campaign.py','4d162d0a6ca48027b6de98fd174ba611f9cc72625e47d7787afc061895d94c97')
D=C.original_modules()
import support as q
import common

def main():
    started=time.monotonic();inputs={};lifetimes=[]
    need(os.geteuid()==0 and set(os.sched_getaffinity(0))==C.CPUS,'root/exact helper CPUs')
    def bind(p,sha=None):
        r=pin(p)
        if sha:need(r['sha256']==sha,'actual input SHA differs: '+str(p))
        inputs[str(p)]=r;return js(p)
    def guard():
        need(time.monotonic()-started<=1200,'finite audit deadline')
        v=os.statvfs(TX);need(v.f_bavail*v.f_frsize>=8*GIB,'8 GiB available floor')
    def life(r,label,require_ok=True):
        need(type(r['pid'])is int and type(r['start_ticks'])is int and r['start_ticks']>0 and isinstance(r['boot_id'],str),'recorded lifetime missing')
        if require_ok:need(r.get('exit_code')==0 and (r.get('reaped')or r.get('child_reaped')or r.get('absent')),'recorded child failed/unknown')
        C.gone(r);lifetimes.append(dict(kind=label,pid=r['pid'],start_ticks=r['start_ticks'],boot_id=r['boot_id'],exit_code=r.get('exit_code'),same_lifetime_present=False))
    def stream_pin(path,expected,identity):
        need(q.identity(path)==identity,'preserved object current identity');h=hashlib.sha256();count=0;fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
        with os.fdopen(fd,'rb')as f:
            st=os.fstat(f.fileno());need((st.st_dev,st.st_ino)==(identity['device'],identity['inode']),'opened object identity')
            while b:=f.read(MIB):
                count+=len(b);need(count<=expected['bytes']<=8*GIB,'original member bound');h.update(b);guard()
        need(dict(bytes=count,sha256=h.hexdigest())==expected and q.identity(path)==identity,'preserved object full SHA/identity')
        return dict(path=str(path),**expected,identity=identity)
    with C.dispatcher_read_lock():
        group=bind(OLD/'group-plan.json',C.GROUP);row,s=C.selected(group,13);sp=row['selection']['sha256'];bind(row['selection']['path'],sp)
        term=bind(ROOT/'tool-terminal.json','378a6b917cafad8da64ca7c1c47b891ccd3312e70464ebb164628718c6941ce0')
        child=bind(ROOT/'launch-first/ordinal013_finish-child-terminal.json','b1231a26ef06a8d1949a7ec1f02d731f6c1ac9ac40b1ef18b6d5ce7f9eca2337')
        need(term['session_id']==56762 and term['terminal']['chunk_id']=='364874'and term['terminal']['exit_code']==0 and json.loads(term['terminal']['output'])==child,'actual outer tool/wait receipt')
        need(child['complete']and child['exit_code']==0 and child['result_path']==str(TX/'retire-2/result.json'),'actual finish child outcome')
        inv=bind(REPAIR/'inventory.json','289615ee63d27604b6265aa332d094cf2e96aac4b2c084e855ecb8da0df02e04')
        for r in inv['rows']:q.check(REPAIR/r['path'],r)
        manifest=bind(PIDFIX/'reader-bindings.json','3269e44abe84555e70ad1f07e86ea32e057d828515888b23e6663c4e4b724386')
        source=next(r for r in manifest['rows']if r['family']==s['screen'])
        need(source['prior_readback_reader']==s['readback_reader']and source['original_campaign_reader']==s['legacy_reader'],'old selected source authority')
        for k in ('corrected_reader','prior_readback_reader','original_campaign_reader'):q.check(source[k]['path'],source[k])
        scope='producer_lifetime_identity_repair_of_original_selected_readback_reader'
        frozen={'verification-first/result.json':'6b17d3766c740a223627b69d2161d86cc7edb7672864370a2a32616d1d686099','restore-1/result.json':'6b15909ae5c84acd148535aa9ca3de9139f679969de1b26d05fc0cdbccf9a5ce','readback-1/result.json':'a9fedebaf08dbeb02e1733d90c9602401027be7e543525e82f350c771b77970d','readback-1-repaired-first/result.json':'69845f4e24f6df43efc5932f802a23a770e0485c25f5f42c05033db64e8ec7ad','retire-2/result.json':'1214b0c5d70b79ae0edfb59b3c0341f958c63b48c95fffe3f2617ed1885d52ab'}
        docs={n:bind(TX/n,frozen.get(n))for n in ['staged.json','verification-first/result.json','retire-1/result.json','restore-1/result.json','readback-1/result.json','readback-1-repaired-first/result.json','retire-2/result.json']}
        stage=docs['staged.json'];ver=docs['verification-first/result.json'];restore=docs['restore-1/result.json'];failed=docs['readback-1/result.json'];reader=docs['readback-1-repaired-first/result.json'];cold=docs['retire-2/result.json']
        need(child['result_sha256']==frozen['retire-2/result.json'],'actual final result pin')
        need(failed['complete']is False and failed['error']=="ValueError('producer codec ownership/exit')",'original failure preserved')
        binding=dict(selection_sha256=sp,verified_sha256=frozen['verification-first/result.json'])
        for phase,name,expected in [('stage','staged.json',dict(selection_sha256=sp,code_pins_sha256=C.CODE,state='STAGED')),('verify','verification-first/result.json',dict(selection_sha256=sp,code_pins_sha256=C.CODE,state='VERIFIED')),('retire-1','retire-1/result.json',dict(binding,state='COLD',cycle=1)),('restore-1','restore-1/result.json',dict(binding,state='RESTORED')),('readback-1-repaired','readback-1-repaired-first/result.json',dict(selection_sha256=sp,restore_result_sha256=frozen['restore-1/result.json'],readback_scope=scope)),('retire-2','retire-2/result.json',dict(binding,state='COLD',cycle=2))]:
            C.phase_receipt(13,phase,TX/name,expected);receipt=bind(EXEC/'013'/(phase+'-complete.json'));life(receipt,'successful_phase')
        need(ver['staged_sha256']==inputs[str(TX/'staged.json')]['sha256']and stage['all_children_reaped']and ver['all_children_reaped']and restore['all_children_reaped'],'verified stage/child lineage')
        sr,vr,mm=C.pair_proofs(s,stage,ver);targets={p['target']for p in s['pairs']};restored=C.exact_rows(restore['rows'],targets)
        need(len(mm)==344 and len(targets)==209,'fixed whole-cohort scope')
        need(reader['preparation_inventory_sha256']==inputs[str(REPAIR/'inventory.json')]['sha256']and reader['readback_reader']==source['corrected_reader']and reader['original_reader']==s['legacy_reader']and reader['original_selected_reader']==s['readback_reader']and reader['prior_readback_scope']==s['readback_scope'],'actual corrected reader authority')
        need(reader['reader_manifest']==dict(path=str(PIDFIX/'reader-bindings.json'),sha256=inputs[str(PIDFIX/'reader-bindings.json')]['sha256'])and reader['failed_readback']==dict(path=str(TX/'readback-1/result.json'),sha256=frozen['readback-1/result.json']),'reader original failure/manifest pins')
        ob=reader['observed'];need(ob['files']==344 and ob['logical_bytes']==s['logical_cohort_bytes']==10402566933 and ob['compressed_bytes']==s['encoded_cohort_bytes']==7362155494 and ob['decoded_all_original_bytes']and ob['codec_lifetimes']==688,'all original bytes read back')
        bypath={m['path']:m for m in mm.values()};logical=reader['logical_original_inventory'];need(len(logical)==344 and {r['physical_object']for r in logical.values()}==set(bypath),'logical original mapping')
        for path,r in logical.items():
            m=bypath[r['physical_object']];need(path==str(Path(s['fixture'])/'data'/m['name'])and dict(bytes=r['bytes'],sha256=r['sha256'])==m['original'],'logical original raw identity')
        for label,rows in [('failed_readback_decoder',failed['decoder_receipts']),('corrected_readback_decoder',reader['decoder_receipts'])]:
            need(len(rows)==344 and {r['object']for r in rows}==set(bypath),'decoder complete exact set')
            for r in rows:
                need(r['complete']and dict(bytes=r['bytes'],sha256=r['sha256'])==bypath[r['object']]['original']and r['codec_sha256']==s['codec']['sha256']and r['cpu_affinity']==sorted(C.CPUS),'actual decoder outcome/raw SHA/CPU')
                life(r,label)
        for m in mm.values():need(reader['records'][m['path']]==m['compressed'],'restored exact compressed readback hash')
        for r in s['metadata']+s['authorities']:q.check(r['path'],r);inputs[r['path']]=dict(bytes=r['bytes'],sha256=r['sha256'])
        recipes,embedded=C.codec_roles(s,stage,ver)
        for expected in recipes:
            out=Path(expected['output']);r=q.js(str(out)+'.child.json');C.codec_receipt(expected,r,q.js(str(out)+'.child-intent.json'),q.js(str(out)+'.child-start.json'),embedded[expected['label']]);life(r,'stage_or_verify_codec')
        children=[c for r in stage['rows']for c in r['children']]+ver['children']+restore['children'];need(len(children)==1881,'exact migration codec count')
        C.sidecar_closure(children,TX.rglob('*.child.json'),TX.rglob('*.child-intent.json'),TX.rglob('*.child-start.json'))
        for r in restore['children']:
            need(q.js(r['output']+'.child.json')==r and r['argv'][0]==str(TX/'toolchain/ld-linux-x86-64.so.2'),'actual restore sidecar/retained codec');life(r,'restore_codec')
        fresh=[r for r in lifetimes if r['kind']not in ('successful_phase',)];need(len(fresh)==2569 and len({(r['pid'],r['start_ticks'],r['boot_id'])for r in fresh})==2569,'unique fresh codec lifetimes')
        failed_child=bind(EXEC/'013/readback-1-attempt-0/child.json');failed_terminal=bind(EXEC/'013/readback-1-attempt-0/failure.json');need(failed_terminal['exit_code']==1 and failed_terminal['complete']is False,'original failed phase outcome');life(dict(failed_child,exit_code=1),'failed_phase',False)
        for name in ('stage-verify','finish'):
            r=bind(CAMPOUT/'013'/name/'terminal.json');need(r['exit_code']==(0 if name=='stage-verify'else 1),'original dispatcher outcome');life(r,'original_dispatcher',False)
        tc=bind(TX/'toolchain.json',ver['toolchain_sha256']);need(stage['toolchain_sha256']==ver['toolchain_sha256'],'toolchain lineage')
        dependencies={r['name']:r for r in s['retained_codec_dependencies']}
        need({r['name']for r in tc['files']}==set(dependencies),'exact retained toolchain set')
        for r in tc['files']:
            need(r['source']==dependencies[r['name']]and r['path']==str(TX/'toolchain'/r['name'])and q.identity(r['path'])==r['identity'],'retained toolchain identity');q.check(r['path'],r['pin'])
        catalog=q.js(Path(s['fixture'])/'retention-catalog.json');need(len(catalog['codecs'])==688,'original producer lifetime count')
        for r in catalog['codecs']:life(r,'historical_producer')
        q.preserved(s);q.no_references(s);q.no_codec_processes(s)
        preserved=[stream_pin(Path(m['path']),m['compressed'],m['identity'])for k,m in mm.items()if k not in targets]
        need(len(preserved)==135 and all(q.absent(Path(mm[k]['path']))for k in targets),'exact preserved/retired sets')
        patch_rows=[]
        for r in stage['rows']:
            q.check_patch(TX,r);patch_rows.append(dict(id=r['id'],**r['patch']))
        recon=cold['reconciliation'];need(recon['corrected_readback']==dict(path=str(TX/'readback-1-repaired-first/result.json'),sha256=frozen['readback-1-repaired-first/result.json'])and recon['restore_result_sha256']==frozen['restore-1/result.json']and recon['original_code_pins_sha256']==C.CODE,'actual final COLD authority')
        for k in ('readback_reader','original_reader','original_selected_reader','reader_manifest','failed_readback','readback_scope','prior_readback_scope'):need(recon[k]==reader[k],'final COLD corrected reader binding')
        C.exact_rows(cold['rows'],{p['id']for p in s['pairs']})
        for pair in s['pairs']:
            intent=bind(TX/'retire-2'/(pair['id']+'.retire-intent.json'))
            need(intent['authority']==dict(binding,cycle=2,restore_result_sha256=frozen['restore-1/result.json'],readback_result_sha256=frozen['readback-1-repaired-first/result.json']),'exact final retirement release')
        before=bind(TX/'readback-1/decode-reservation.json');after=bind(TX/'readback-1-repaired-first/decode-reservation.json')
        need(before['charged_decoded_bytes']==after['charged_decoded_bytes']==10402566933 and before['previous_cumulative_decoded_bytes']==20752952088 and after['previous_cumulative_decoded_bytes']==31155519021,'failed and corrected whole-decode charges')
        charge=q.charged_decoded(TX,s['limits']['cumulative_decoded_bytes']);need(charge==41558085954,'exact cumulative decoded charge')
        group_account=D.account(group);need(group_account['complete']and group_account['cold_cohorts']==14,'all actual prior cohorts COLD, no partial later cohort')
        extras=[CAMP,CAMPOUT,ROOT,FAILROOT,REPAIR,PIDFIX,P]
        extra_rows=[dict(path=str(p),allocated_bytes=common.allocated(p,256*MIB))for p in extras]
        # Reserve the remaining entire 4 MiB owned audit allowance before writing summary/terminal.
        own_now=next(r['allocated_bytes']for r in extra_rows if r['path']==str(P));need(own_now<=4*MIB,'bounded independent report')
        conservative_extra=sum(r['allocated_bytes']for r in extra_rows)+4*MIB-own_now
        corrected_net=group_account['conservative_net_allocated_change_bytes']-conservative_extra
        for path,r in inputs.items():need(pin(path)==r,'bound input changed during audit')
        guard()
        report=dict(complete=True,ordinal=13,state='COLD',selection_sha256=sp,phase_hashes={n:inputs[str(TX/n)]['sha256']for n in docs},actual_tool_terminal=inputs[str(ROOT/'tool-terminal.json')],actual_child_terminal=inputs[str(ROOT/'launch-first/ordinal013_finish-child-terminal.json')],
            targets=209,objects=344,logical_bytes=10402566933,encoded_bytes=7362155494,patch_bytes=sum(r['patch']['pin']['bytes']for r in stage['rows']),
            actual_fresh_codec_lifetimes=2569,historical_producer_lifetimes=688,lifetimes=lifetimes,preserved_objects=preserved,patches=patch_rows,
            all_original_metadata_unchanged=True,original_failed_readback_preserved=True,charged_decoded_bytes=charge,decoded_cap_bytes=s['limits']['cumulative_decoded_bytes'],
            corrected_reader_binding={k:reader[k]for k in ('readback_reader','original_reader','original_selected_reader','reader_manifest','failed_readback','readback_scope','prior_readback_scope')},
            group_accounting=group_account,additional_allocation=extra_rows,own_audit_allocation_reservation_bytes=4*MIB,conservative_group_net_after_all_metadata_bytes=corrected_net,
            input_pins=inputs,observed_ns=time.time_ns(),no_payload_decode_or_workload=True,
            scope='Independent receipt/lifetime/identity/full preserved-object hash acceptance for actual013. Historical failed result remains failed. Old controller, failure evidence, repaired execution and all new metadata are charged in addition to original group accounting.')
        save(P/'accepted-summary.json',report)
        print(json.dumps({k:report[k]for k in ('complete','ordinal','state','targets','objects','logical_bytes','actual_fresh_codec_lifetimes','historical_producer_lifetimes','charged_decoded_bytes','conservative_group_net_after_all_metadata_bytes')}))
        print(json.dumps(dict(accepted_summary=pin(P/'accepted-summary.json'))))
if __name__=='__main__':
    try:main()
    except BaseException as exc:
        save(P/('failure-'+str(time.time_ns())+'.json'),dict(complete=False,error=repr(exc)));raise
