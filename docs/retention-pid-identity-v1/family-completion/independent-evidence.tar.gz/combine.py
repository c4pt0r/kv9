"""Combine two newly checked families with two previously accepted metadata references."""
import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
def read(p,sha=None):
    p=Path(p);b=p.read_bytes();pin=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    if sha is not None:assert pin['sha256']==sha
    return json.loads(b),pin
new,np=read(P/'result.json');assert new['complete']and new['snapshot_completed_ordinals']==[20,21]and not new['validation_failures']
old,op=read('/tmp/kv9-retention-corrected-reader-coverage-20260915-first/result.json','6da05e72b4f122cf2299bb82eb02b5e1172f97adb209950e2cd58015236e1145')
fnv,fp=read('/tmp/kv9-retention-013-independent-acceptance-20260915-first/accepted-summary.json','4b957a568e9fb516cdc10312dee27abe5bd31efef22bfe6dc38579dd7fb7afd7')
assert old['complete']and fnv['complete']and fnv['ordinal']==13 and fnv['state']=='COLD'
rows=[]
catalog_path='/tmp/kv9-fnv-writer-performance-budget-v2-timing-20260914-first/cohorts/006-old-batch64-r000-p00064/fixture/retention-catalog.json'
rows.append(dict(family='fnv-writer',ordinal=13,state='COLD',validation='Previously independently accepted; no old payload or lifetime re-audit in this report.',
    acceptance=fp,selection_sha256=fnv['selection_sha256'],catalog=dict(path=catalog_path,**fnv['input_pins'][catalog_path]),
    successful_current_readback_decoders=fnv['objects'],historical_producer_counter=fnv['historical_producer_lifetimes'],
    logical_bytes=fnv['logical_bytes'],encoded_bytes=fnv['encoded_bytes'],corrected_reader=fnv['corrected_reader_binding']['readback_reader'],
    original_reader=fnv['corrected_reader_binding']['original_reader'],prior_selected_reader=fnv['corrected_reader_binding']['original_selected_reader'],
    readback_sha256=fnv['phase_hashes']['readback-1-repaired-first/result.json'],cold_sha256=fnv['phase_hashes']['retire-2/result.json']))
crc=next(r for r in old['cohorts']if r['ordinal']==14)
for r,receipt,kind in [(crc,op,'Previously independently checked metadata; no old payload or lifetime re-audit in this report.')]+[(r,np,'New completed-cohort metadata and actual current decoder lifetime validation.')for r in new['cohorts']]:
    rows.append(dict(family=r['family'],ordinal=r['ordinal'],state='COLD',validation=kind,acceptance=receipt,selection=r['selection'],catalog=r['catalog'],
        controller_complete=r['controller_complete'],release=r['release'],corrected_reader=r['corrected_reader'],original_reader=r['original_reader'],prior_selected_reader=r['prior_selected_reader'],
        successful_current_readback_decoders=r['actual_current_decoder_count'],historical_producer_counter=r['historical_observed']['codec_lifetimes'],
        logical_bytes=r['logical_bytes'],encoded_bytes=r['encoded_bytes'],readback=r['readback'],cold=r['cold']))
assert {r['family']for r in rows}=={'fnv-writer','crc-full-regression','published-directory','frame-buffer-crc'}
assert [r['ordinal']for r in rows]==[13,14,20,21]
report=dict(complete=True,four_reader_families_complete=True,scope='Four first accepted corrected-reader families, with newly validated actual020/021 and unchanged prior013/014 metadata authorities. This is representation-readback coverage, not new benchmark acceptance.',
    families=rows,newly_checked_ordinals=[20,21],newly_checked_successful_decoders=sum(r['actual_current_decoder_count']for r in new['cohorts']),
    total_successful_current_readback_decoders_across_four_accepted_runs=sum(r['successful_current_readback_decoders']for r in rows),
    historical_counter_warning='Historical producer counters and original observed timestamps are never labeled fresh decoder observations. Prior013/014 acceptance is reused and not re-audited.',
    validation_failures=[],reporting_allocation_policy=dict(cap_bytes=4*1024**2,charged_in_running_controller_nine_root_accounting=False,scope='Record separately; no existing controller accounting is rewritten.'),
    exact_new_validation=np,prior_crc_validation=op,prior_fnv_acceptance=fp)
encoded=json.dumps(report,indent=2,sort_keys=True)+'\n';assert len(encoded.encode())<256*1024
with (P/'family-completion.json').open('x')as f:f.write(encoded)
print(json.dumps(dict(complete=True,newly_checked_successful_decoders=report['newly_checked_successful_decoders'],four_family_decoders=report['total_successful_current_readback_decoders_across_four_accepted_runs'],families=[dict(family=r['family'],ordinal=r['ordinal'],current_decoders=r['successful_current_readback_decoders'],historical_producer_counter=r['historical_producer_counter'])for r in rows])))
