"""One finite completed-cohort metadata snapshot; no polling or payload access."""
import hashlib,json,os,time
from pathlib import Path
P=Path(__file__).resolve().parent
PREP=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first')
CONT=Path('/tmp/kv9-cross-voter-multicohort-continuation-preparation-20260915-first')
ROOT=Path('/tmp/kv9-cross-voter-multicohort-continuation-root-20260915-first')
EXEC=Path('/tmp/kv9-cross-voter-multicohort-execution-20260915-first')
ORDINALS=(20,21)
SNAPSHOT_NS=time.time_ns()
pins={}
def need(ok,msg):
    if not ok:raise ValueError(msg)
def read(p,expected=None):
    p=Path(p);a=p.lstat();need(not p.is_symlink()and p.is_file()and a.st_size<=16*1024**2,'bounded ordinary metadata')
    b=p.read_bytes();z=p.lstat();need((a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns),'metadata changed')
    pin=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    if expected:
        need(pin['sha256']==expected['sha256']and('bytes'not in expected or pin['bytes']==expected['bytes']),'metadata authority hash mismatch')
    pins[str(p)]=pin;return json.loads(b)
def gone(r):
    need(type(r['pid'])is int and type(r['start_ticks'])is int and r['start_ticks']>0 and isinstance(r['boot_id'],str),'lifetime record')
    current=None
    try:
        text=(Path('/proc')/str(r['pid'])/'stat').read_text();current=dict(pid=r['pid'],start_ticks=int(text.rsplit(')',1)[1].split()[19]),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())
    except (FileNotFoundError,ProcessLookupError):pass
    same=current is not None and all(current[k]==r[k]for k in ('pid','start_ticks','boot_id'));need(not same,'recorded lifetime still live')
    return dict(pid=r['pid'],start_ticks=r['start_ticks'],boot_id=r['boot_id'],same_lifetime_present=False,current_identity=current)
def main():
    group=read(PREP/'group-plan.json',dict(sha256='e0e9956c1334149ded0f23f2989f90e2ef54d3510a25293d30f1d5b7d66a86de'))
    manifest=read('/tmp/kv9-retention-pid-identity-repair-20260915-first/reader-bindings.json',dict(sha256='3269e44abe84555e70ad1f07e86ea32e057d828515888b23e6663c4e4b724386'))
    families={r['family']:r for r in manifest['rows']};cohorts=[]
    for i in ORDINALS:
        d=ROOT/f'{i:03d}';done=read(d/'complete.json');need(done['complete']is True and done['ordinal']==i,'snapshot cohort not complete')
        row=group['rows'][i];s=read(row['selection']['path'],row['selection']);accept=done['acceptance'];tx=Path(s['root']);family=families[s['screen']]
        release=read(d/'release.json',done['release_pin']);need(release['complete']and release['ordinal']==i and release['verified_sha256']==done['verified_sha256']==accept['verified_sha256'],'exact verification release')
        need(accept['complete']and accept['state']=='COLD'and accept['selection_sha256']==row['selection']['sha256'],'accepted COLD lineage')
        controller=[]
        for mode in ('stage-verify','finish'):
            r=read(d/mode/'terminal.json');inv=read(d/mode/'invocation.json');need(r['complete']and r['exit_code']==0 and r['child_reaped']and r['argv']==inv['argv'],'actual controller child outcome')
            controller.append(dict(mode=mode,**gone(r)))
        results={};phase_lives=[]
        for phase,name in [('stage','staged.json'),('verify','verification-first/result.json'),('retire-1','retire-1/result.json'),('restore-1','restore-1/result.json'),('readback-1-repaired','readback-1-repaired-first/result.json'),('retire-2','retire-2/result.json')]:
            r=read(EXEC/f'{i:03d}'/(phase+'-complete.json'));need(r['complete']and r['exit_code']==0 and r['child_reaped']and r['result_path']==str(tx/name),'actual phase completion')
            inv=read(r['invocation']);need(inv['argv']==r['argv']and inv['result_path']==r['result_path'],'actual phase invocation')
            v=read(tx/name,dict(sha256=r['result_sha256']));need(v['complete']and v['selection_sha256']==row['selection']['sha256'],'phase selection/complete')
            results[phase]=v;phase_lives.append(dict(phase=phase,**gone(r)))
        rr=results['readback-1-repaired'];cold=results['retire-2'];ver=results['verify'];restore=results['restore-1']
        need(ver['staged_sha256']==pins[str(tx/'staged.json')]['sha256']and restore['verified_sha256']==cold['verified_sha256']==accept['verified_sha256'],'stage/verification/restore lineage')
        need(accept['readback_sha256']==pins[str(tx/'readback-1-repaired-first/result.json')]['sha256']and accept['cold_sha256']==pins[str(tx/'retire-2/result.json')]['sha256']and rr['restore_result_sha256']==accept['restore_sha256']==pins[str(tx/'restore-1/result.json')]['sha256'],'actual acceptance result pins')
        need(rr['readback_reader']==family['corrected_reader']and rr['original_reader']==s['legacy_reader']==family['original_campaign_reader']and rr['original_selected_reader']==s['readback_reader']==family['prior_readback_reader'],'corrected and original source roles')
        need(rr['readback_scope']=='producer_lifetime_identity_repair_of_original_selected_readback_reader'and rr['failed_readback']is None,'honest new corrected-reader scope')
        for k,v in accept['reader_binding'].items():need(rr[k]==v and cold['reconciliation'][k]==v,'corrected COLD reader authority')
        need(cold['reconciliation']['corrected_readback']==dict(path=str(tx/'readback-1-repaired-first/result.json'),sha256=accept['readback_sha256']),'COLD actual corrected readback')
        catalog_path=Path(s['fixture'])/'retention-catalog.json';catalog_pin=next(r for r in s['metadata']if r['path']==str(catalog_path));catalog=read(catalog_path,catalog_pin)
        need(rr['records'][str(catalog_path)]=={k:catalog_pin[k]for k in ('bytes','sha256')},'current reader catalog authority')
        mm={m['path']:m for m in s['members']};originals={str(Path(s['fixture'])/m['object']):m for m in catalog['members']};ds=rr['decoder_receipts'];obs=rr['observed']
        need(len(mm)==len(originals)==len(ds)==s['original_object_count']and set(mm)==set(originals)=={r['object']for r in ds},'complete exact current decoder coverage')
        need(obs['files']==len(mm)and obs['logical_bytes']==s['logical_cohort_bytes']and obs['compressed_bytes']==s['encoded_cohort_bytes']and obs['decoded_all_original_bytes']is True,'whole-cohort byte scope')
        current=[];unique=set()
        for r in ds:
            m=mm[r['object']];catalog_raw=originals[r['object']]['original'];need(m['original']=={k:catalog_raw[k]for k in ('bytes','sha256')}and dict(bytes=r['bytes'],sha256=r['sha256'])==m['original'],'current raw receipt identity')
            need(r['complete']is True and r['exit_code']==0 and r['absent']is True and r['codec_sha256']==s['codec']['sha256'],'current decoder successful/pinned')
            need(rr['records'][m['path']]==m['compressed'],'current compressed receipt identity')
            key=(r['pid'],r['start_ticks'],r['boot_id']);need(key not in unique,'duplicate current decoder lifetime');unique.add(key);current.append(dict(object=r['object'],bytes=r['bytes'],sha256=r['sha256'],**gone(r)))
        cohorts.append(dict(ordinal=i,family=s['screen'],cohort=s['cohort'],selection=pins[row['selection']['path']],catalog=pins[str(catalog_path)],controller_complete=pins[str(d/'complete.json')],release=pins[str(d/'release.json')],
            corrected_reader=rr['readback_reader'],original_reader=rr['original_reader'],prior_selected_reader=rr['original_selected_reader'],readback=pins[str(tx/'readback-1-repaired-first/result.json')],cold=pins[str(tx/'retire-2/result.json')],
            original_objects=len(mm),logical_bytes=s['logical_cohort_bytes'],encoded_bytes=s['encoded_cohort_bytes'],target_objects=s['target_count'],
            historical_observed=obs,historical_observed_explanation='Original catalog/retention timing and producer counters inherited by verify(); these are not fresh decoder counts.',
            actual_current_decoder_count=len(current),actual_current_decoder_bytes=sum(r['bytes']for r in current),actual_current_decoder_lifetimes=current,actual_phase_lifetimes=phase_lives,actual_controller_lifetimes=controller))
    coverage={f:dict(status='complete'if any(c['family']==f for c in cohorts)else'pending_in_this_continuation_snapshot',completed_cohorts=[c['ordinal']for c in cohorts if c['family']==f])for f in families}
    result=dict(complete=True,scope='One finite metadata-only coverage snapshot. No partial cohort adoption, new runtime, codec, payload read, source comparison, or monitor.',snapshot_observed_ns=SNAPSHOT_NS,validated_ns=time.time_ns(),snapshot_completed_ordinals=list(ORDINALS),
        prior_accepted_fnv013_reference='/tmp/kv9-retention-013-independent-acceptance-20260915-first/accepted-summary.json',prior_accepted_fnv013_sha256='4b957a568e9fb516cdc10312dee27abe5bd31efef22bfe6dc38579dd7fb7afd7',
        coverage=coverage,new_reader_families_beyond_prior_fnv013_and_crc014=['published-directory','frame-buffer-crc'],cohorts=cohorts,actual_current_decoder_count=sum(c['actual_current_decoder_count']for c in cohorts),validation_failures=[],input_pins=list(pins.values()))
    encoded=json.dumps(result,sort_keys=True,indent=2)+'\n';need(len(encoded.encode())<3*1024**2,'bounded family report');(P/'result.json').write_text(encoded)
    print(json.dumps({k:result[k]for k in ('complete','snapshot_completed_ordinals','coverage','actual_current_decoder_count','new_reader_families_beyond_prior_fnv013_and_crc014','validation_failures')}))
if __name__=='__main__':
    try:main()
    except BaseException as exc:
        (P/('failure-'+str(time.time_ns())+'.json')).write_text(json.dumps(dict(complete=False,error=repr(exc)))+'\n');raise
