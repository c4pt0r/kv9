"""Finite source-only derivative; never reads compressed objects or runs a reader."""
import ast, difflib, hashlib, json
from pathlib import Path
P=Path(__file__).resolve().parent
OLD=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first')
def pin(p):
    b=Path(p).read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
    with p.open('x')as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
helper=(P/'identity-helper.txt').read_text()
old_atom='not Path(f\'/proc/{c["pid"]}\').exists()'
new_atom='producer_lifetime_absent(c)'
for d in ('originals','readers','diffs','evidence'):(P/d).mkdir()
g=json.loads((OLD/'group-plan.json').read_text());rows=[];seen=set()
for r in g['rows']:
    if r['screen']in seen:continue
    seen.add(r['screen']);s=json.loads(Path(r['selection']['path']).read_text());prior=s['readback_reader'];src=Path(prior['path'])
    assert pin(src)==prior
    before=src.read_text();assert before.count(old_atom)==1
    marker='def unique_pairs(pairs):';assert before.count(marker)==1
    after=before.replace(marker,helper+'\n'+marker).replace(old_atom,new_atom)
    assert after.replace(helper+'\n','',1).replace(new_atom,old_atom)==before
    ast.parse(after)
    name=r['screen']+'.py';original=P/'originals'/name;new=P/'readers'/name
    original.write_bytes(src.read_bytes());new.write_text(after)
    delta=P/'diffs'/(r['screen']+'.diff');delta.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(src),tofile=str(new))))
    rows.append(dict(family=r['screen'],original_campaign_reader=s['legacy_reader'],prior_readback_reader=prior,
        preserved_source_copy=pin(original),corrected_reader=pin(new),diff=pin(delta),
        capacity_policy_unchanged=True,scope='Current producer lifetime identity repair only; historical original acceptance unchanged.'))
save(P/'reader-bindings.json',dict(schema=1,rows=rows,old_atom=old_atom,new_atom=new_atom,helper=pin(P/'identity-helper.txt')))
s=json.loads((OLD/'selections/013.json').read_text());catalog=Path(s['fixture'])/'retention-catalog.json';c=json.loads(catalog.read_text())
child=Path('/tmp/kv9-cross-voter-multicohort-execution-20260915-first/013/readback-1-attempt-0/child.json');a=json.loads(child.read_text());row=c['codecs'][319]
assert row['pid']==a['pid']==1272867 and row['start_ticks']==171408954 and a['start_ticks']==174257498 and row['boot_id']==a['boot_id']
for path in [child,Path(s['root'])/'readback-1/result.json',Path(s['root'])/'readback-1/decode-reservation.json']:
    (P/'evidence'/('reader-child.json' if path==child else 'failed-readback-'+path.name)).write_bytes(path.read_bytes())
save(P/'collision.json',dict(ordinal=13,catalog=pin(catalog),catalog_codec_index=319,recorded_producer=row,
    reader_child=pin(child),actual_reader=a,selection=pin(OLD/'selections/013.json'),
    original_producer=pin(Path(s['legacy_producer']['path'])),
    conclusion='The readback Python process reused an exited historical decoder PID; start_ticks differ on the same boot. Original runtime and this readback attempt remain failed.'))
print(json.dumps(dict(complete=True,readers=len(rows),reader_bindings=pin(P/'reader-bindings.json'),collision=pin(P/'collision.json'))))
