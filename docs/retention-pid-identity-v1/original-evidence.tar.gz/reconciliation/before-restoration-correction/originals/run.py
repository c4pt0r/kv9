"""Finite serial root dispatcher: stage/verify, explicit released finish, and exact restore.
No automatic release: finish/restore require the independently reviewed verification hash.
"""
import argparse,fcntl,json,os,signal,subprocess,sys,time
from pathlib import Path
import common
from support import canonical_path,js,need,durable_json,digest,check,absent,fsync_dir,first_cohort_qualified
P=Path(__file__).resolve().parent
EXECUTION=Path('/tmp/kv9-cross-voter-multicohort-execution-20260915-first')
EXECUTION_CAP=256*common.MIB

def validate_done(doc,result_path,expected):
 need(doc['complete']and doc['exit_code']==0 and doc['result_path']==str(result_path),'prior phase incomplete/path differs')
 need(digest(result_path)['sha256']==doc['result_sha256'],'completed phase result changed')
 r=js(result_path);need(r['complete'],'completed helper result false')
 for key,value in expected.items():need(r.get(key)==value,'completed helper binding differs: '+key)
 return r

def guard(start=None):
 v=os.statvfs(EXECUTION);free=v.f_bavail*v.f_frsize
 need(free>=8*common.GIB,'8 GiB actual available floor')
 need(common.allocated(EXECUTION,EXECUTION_CAP)<=EXECUTION_CAP,'execution metadata/log allocation cap')
 if start is not None:need(time.monotonic()-start<=2100,'2100 second outer phase deadline')
 return free

def step(folder,name,argv,result_path,expected):
 done=folder/(name+'-complete.json')
 if done.exists():return validate_done(js(done),result_path,expected)
 attempt=None
 for n in range(3):
  p=folder/f'{name}-attempt-{n}'
  if absent(p):p.mkdir();fsync_dir(folder);attempt=p;break
 need(attempt is not None,'three wrapper attempts exhausted; retained for review')
 invocation=dict(argv=argv,result_path=str(result_path),expected=expected,started_ns=time.time_ns())
 durable_json(attempt/'invocation.json',invocation);child=None;failure=None;start=time.monotonic();parent=os.getpid()
 try:
  with (attempt/'stdout').open('xb')as out,(attempt/'stderr').open('xb')as err:
   child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,preexec_fn=lambda:common.parent_death_guard(parent))
   stat=Path(f'/proc/{child.pid}/stat').read_text();birth=int(stat[stat.rfind(')')+2:].split()[19]);boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
   durable_json(attempt/'child.json',dict(pid=child.pid,start_ticks=birth,boot_id=boot,argv=argv))
   while child.poll()is None:
    guard(start);need((attempt/'stdout').stat().st_size<=common.MIB and (attempt/'stderr').stat().st_size<=common.MIB,'bounded wrapper output');time.sleep(5)
   code=child.wait();out.flush();os.fsync(out.fileno());err.flush();os.fsync(err.fileno())
  need((attempt/'stdout').stat().st_size<=common.MIB and (attempt/'stderr').stat().st_size<=common.MIB,'final wrapper output bound')
  need(code==0,'phase child failed');r=js(result_path);need(r['complete'],'helper incomplete')
  for k,v in expected.items():need(r.get(k)==v,'helper result binding differs: '+k)
  doc=dict(complete=True,exit_code=0,result_path=str(result_path),result_sha256=digest(result_path)['sha256'],invocation=str(attempt/'invocation.json'),argv=argv,pid=child.pid,start_ticks=birth,boot_id=boot,ended_ns=time.time_ns(),child_reaped=True)
  durable_json(attempt/'result.json',doc);durable_json(done,doc);guard();return r
 except BaseException as exc:failure=repr(exc);raise
 finally:
  if child is not None and child.poll()is None:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait()
  if failure is not None:durable_json(attempt/'failure.json',dict(complete=False,error=failure,exit_code=None if child is None else child.returncode,ended_ns=time.time_ns(),scope='No broad cleanup; partial transaction and original files retained.'))

def account(group):
 rows=[];added=0;gross=0;completed=0;incomplete=[]
 for row in group['rows']:
  root=Path(row['root'])
  if absent(root):continue
  check(row['selection']['path'],row['selection'],'selection changed');s=js(row['selection']['path']);targets={p['target']for p in s['pairs']}
  current=sum(common.identity(m['path'])['allocated_bytes']for m in s['members']if m['id']in targets and not absent(Path(m['path'])))
  allocated=common.allocated(root,s['limits']['metadata_bytes']);added+=allocated;gross+=s['target_allocated_bytes']-current
  done=EXECUTION/f"{row['ordinal']:03d}"/'retire-2-complete.json';cold=False
  if done.exists():
   c=validate_done(js(done),root/'retire-2/result.json',dict(state='COLD',cycle=2,selection_sha256=row['selection']['sha256']))
   # A completed later restore is not mislabeled current COLD or credited as absent.
   cold=current==0 and all(absent(Path(m['path']))for m in s['members']if m['id']in targets)
   if cold:completed+=1
  if not cold:incomplete.append(row['ordinal'])
  rows.append(dict(ordinal=row['ordinal'],root=str(root),currently_cold=cold,current_target_allocated_bytes=current,transaction_allocated_bytes=allocated,original_target_allocation=s['target_allocated_bytes']))
 exec_alloc=common.allocated(EXECUTION,EXECUTION_CAP);prep_alloc=common.allocated(P,32*common.MIB);free=guard()
 return dict(complete=not incomplete,scope='Metadata-only current allocation, not another payload acceptance. All existing selected transaction roots, retained scratch/toolchains/receipts, execution and preparation metadata charged. Prior first-cohort savings excluded.',rows=rows,cold_cohorts=completed,incomplete_or_restored_cohorts=incomplete,target_gross_allocation_decrease_bytes=gross,transaction_allocated_bytes=added,execution_allocated_bytes=exec_alloc,preparation_allocated_bytes=prep_alloc,conservative_net_allocated_change_bytes=gross-added-exec_alloc-prep_alloc,actual_available_bytes=free,target_reached=free>=group['actual_available_stop_target_bytes'],all_selected_exhausted=completed==len(group['rows']),benchmark_runtime_ready=False)

def ensure_staging_phase(root):
 need(absent(root/'retire-1'),'retirement already begun: use released finish/resume or exact restoration, never relabel as untouched stage')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['stage-verify','finish','restore-final','readback-final','account'],required=True);ap.add_argument('--ordinal',type=int);ap.add_argument('--code-pins-sha256',required=True);ap.add_argument('--release-verified-sha256');a=ap.parse_args()
 need(os.geteuid()==0 and set(os.sched_getaffinity(0))==common.CPUS,'root/exact helper CPUs required')
 need(digest(P/'code-pins.json')['sha256']==a.code_pins_sha256,'code pins changed')
 for name,pin in js(P/'code-pins.json').items():check(P/name,pin,'frozen helper/input changed')
 group=js(P/'group-plan.json');first_cohort_qualified(group)
 canonical_path(EXECUTION);EXECUTION.mkdir(mode=0o700,exist_ok=True);fsync_dir(EXECUTION.parent)
 lock=os.open(EXECUTION/'serial.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  guard()
  if a.mode=='account':print(json.dumps(account(group)));return 0
  need(a.ordinal is not None and 0<=a.ordinal<len(group['rows']),'finite ordinal required');row=group['rows'][a.ordinal];need(row['ordinal']==a.ordinal,'ordered group differs')
  if a.mode=='stage-verify':
   status=account(group)
   if status['target_reached']and not status['incomplete_or_restored_cohorts']:
    print(json.dumps(dict(complete=True,stopped_before_new_cohort=True,accounting=status)));return 0
   need(not set(status['incomplete_or_restored_cohorts'])-{a.ordinal},'finish/resolve existing selected cohort before starting another')
  sp=row['selection'];check(sp['path'],sp,'selection changed');s=js(sp['path']);root=Path(row['root']);folder=EXECUTION/f'{a.ordinal:03d}';folder.mkdir(exist_ok=True);fsync_dir(EXECUTION)
  base=['--selection',sp['path'],'--selection-sha256',sp['sha256'],'--code-pins-sha256',a.code_pins_sha256]
  def argv(script,*extra):return [sys.executable,str(P/script),*base,*extra]
  vp=root/'verification-first/result.json';same=dict(selection_sha256=sp['sha256'],code_pins_sha256=a.code_pins_sha256)
  if a.mode=='stage-verify':
   ensure_staging_phase(root)
   if absent(root):need(guard()>=s['limits']['launch_available_bytes']+EXECUTION_CAP,'fresh selected transaction plus group metadata reservation')
   stage=step(folder,'stage',argv('stage.py'),root/'staged.json',dict(same,state='STAGED'))
   v=step(folder,'verify',argv('verify.py','--staged-sha256',digest(root/'staged.json')['sha256'],'--retained-toolchain-sha256',stage['toolchain_sha256'],'--output',str(vp.parent)),vp,dict(same,state='VERIFIED',staged_sha256=digest(root/'staged.json')['sha256']))
   print(json.dumps(dict(complete=True,mode=a.mode,ordinal=a.ordinal,verified_result=str(vp),verified_sha256=digest(vp)['sha256'],originals_retired=False,root_release_required=True)));return 0
  need(a.release_verified_sha256 is not None and digest(vp)['sha256']==a.release_verified_sha256,'explicit exact reviewed verification hash required')
  v=validate_done(js(folder/'verify-complete.json'),vp,dict(same,state='VERIFIED'))
  tool=['--retained-toolchain-sha256',v['toolchain_sha256']];release=['--verified-result',str(vp),'--release-verified-sha256',a.release_verified_sha256]
  binding=dict(selection_sha256=sp['sha256'],verified_sha256=a.release_verified_sha256)
  if a.mode=='finish':
   step(folder,'retire-1',argv('transition.py','retire','--cycle','1',*release,*tool),root/'retire-1/result.json',dict(binding,state='COLD',cycle=1))
   step(folder,'restore-1',argv('transition.py','restore','--cycle','1',*release,*tool),root/'restore-1/result.json',dict(binding,state='RESTORED'))
   restore=digest(root/'restore-1/result.json')['sha256']
   step(folder,'readback-1',argv('readback.py','--cycle','1','--restore-result-sha256',restore),root/'readback-1/result.json',dict(selection_sha256=sp['sha256'],restore_result_sha256=restore,readback_reader=s['readback_reader'],original_reader=s['legacy_reader'],readback_scope=s['readback_scope']))
   readback=digest(root/'readback-1/result.json')['sha256']
   step(folder,'retire-2',argv('transition.py','retire','--cycle','2',*release,*tool,'--restore-result-sha256',restore,'--readback-result-sha256',readback),root/'retire-2/result.json',dict(binding,state='COLD',cycle=2))
   status=account(group);durable_json(folder/('account-'+str(time.time_ns())+'.json'),status);print(json.dumps(dict(complete=True,mode=a.mode,ordinal=a.ordinal,accounting=status)));return 0
  restore1=digest(root/'restore-1/result.json')['sha256'];readback1=digest(root/'readback-1/result.json')['sha256']
  if a.mode=='restore-final':
   need(guard()>=8*common.GIB+s['limits']['external_restored_target_allowance_bytes']+s['limits']['scratch_reserve_bytes']+16*common.MIB,'fresh full selected restore plus scratch reservation')
   step(folder,'restore-2',argv('transition.py','restore','--cycle','2',*release,*tool,'--restore-result-sha256',restore1,'--readback-result-sha256',readback1),root/'restore-2/result.json',dict(binding,state='RESTORED'))
  else:
   restore2=digest(root/'restore-2/result.json')['sha256']
   step(folder,'readback-2',argv('readback.py','--cycle','2','--restore-result-sha256',restore2),root/'readback-2/result.json',dict(selection_sha256=sp['sha256'],restore_result_sha256=restore2,readback_reader=s['readback_reader'],original_reader=s['legacy_reader'],readback_scope=s['readback_scope']))
  print(json.dumps(dict(complete=True,mode=a.mode,ordinal=a.ordinal,result=str(root/('restore-2'if a.mode=='restore-final'else'readback-2')/'result.json'),no_third_retirement_supported=True)));return 0
 finally:os.close(lock)
if __name__=='__main__':sys.exit(main())
