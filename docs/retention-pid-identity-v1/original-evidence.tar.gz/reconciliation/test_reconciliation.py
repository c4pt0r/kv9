"""Metadata-only controls; no original payload, codec, retirement or fixture execution."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import authority as A
import reconcile as R
import transition_repaired as T


class ReconciliationControls(unittest.TestCase):
    def setUp(self):
        base = A.OWN / 'controls-data'
        base.mkdir(exist_ok=True)
        self.root = Path(tempfile.mkdtemp(prefix=self._testMethodName + '-', dir=base))

    def metadata(self, path, doc):
        path.parent.mkdir(exist_ok=True, parents=True)
        path.write_text(json.dumps(doc))
        return A.digest(path)['sha256']

    def fixtures(self):
        old = dict(path='/original-reader', bytes=1, sha256='a' * 64)
        selected = dict(path='/selected-reader', bytes=2, sha256='b' * 64)
        s = dict(root=str(self.root), screen='fnv-writer', group_ordinal=13,
                 legacy_reader=old, readback_reader=selected, readback_scope='prior-scope',
                 target_count=2, original_object_count=3, logical_cohort_bytes=6,
                 encoded_cohort_bytes=4, codec=dict(sha256='c' * 64),
                 pairs=[dict(target='1'), dict(target='2')],
                 members=[dict(id=str(i), path='/object/' + str(i), original=dict(bytes=2, sha256=str(i) * 64)) for i in range(3)])
        a = SimpleNamespace(selection_sha256='selection', restore_result_sha256='restore',
                            release_verified_sha256='verified', readback_result_sha256='readback',
                            preparation_inventory_sha256='repair-inventory')
        ds = [dict(object=m['path'], complete=True, exit_code=0, absent=True,
                   bytes=m['original']['bytes'], sha256=m['original']['sha256'],
                   codec_sha256=s['codec']['sha256'], pid=1, start_ticks=i + 1, boot_id='old')
              for i, m in enumerate(s['members'])]
        with patch.object(A, 'effective_reader', return_value=dict(path='/corrected', bytes=3, sha256='d' * 64)):
            doc = dict(complete=True, selection_sha256=a.selection_sha256,
                       restore_result_sha256=a.restore_result_sha256,
                       preparation_inventory_sha256=a.preparation_inventory_sha256,
                       charged_decoded_bytes=6, **A.reader_binding(s),
                       observed=dict(files=3, logical_bytes=6, compressed_bytes=4, decoded_all_original_bytes=True),
                       decoder_receipts=ds)
        return s, a, doc

    def reader_context(self):
        return patch.object(A, 'effective_reader', return_value=dict(path='/corrected', bytes=3, sha256='d' * 64))

    def test_actual_four_manifest_families_and_original_pins(self):
        manifest = A.js(A.MANIFEST)
        self.assertEqual(A.digest(A.MANIFEST)['sha256'], A.MANIFEST_SHA)
        group = A.js(A.OLD / 'group-plan.json')
        seen = set()
        for row in group['rows']:
            s = A.js(row['selection']['path'])
            if s['screen'] in seen:
                continue
            seen.add(s['screen'])
            reader = A.reader_row(manifest, s)
            A.check(reader['corrected_reader']['path'], reader['corrected_reader'])
        self.assertEqual(len(seen), 4)

    def test_missing_duplicate_and_changed_reader_authority(self):
        s = A.js(A.OLD / 'selections/013.json')
        manifest = A.js(A.MANIFEST)
        mutations = []
        for key in ['rows']:
            m = copy.deepcopy(manifest); m[key] = []; mutations.append(m)
        m = copy.deepcopy(manifest); m['rows'].append(m['rows'][0]); mutations.append(m)
        for key in ['original_campaign_reader', 'prior_readback_reader', 'corrected_reader']:
            m = copy.deepcopy(manifest); m['rows'][0][key]['path'] = '/wrong'; mutations.append(m)
        m = copy.deepcopy(manifest); m['rows'][0]['capacity_policy_unchanged'] = False; mutations.append(m)
        for m in mutations:
            with self.subTest(m=m), self.assertRaises(RuntimeError):
                A.reader_row(m, s)

    def test_manifest_argument_and_changed_bytes_refused(self):
        a = SimpleNamespace(reader_manifest=str(A.MANIFEST), reader_manifest_sha256='wrong', preparation_inventory_sha256='own')
        with self.assertRaises(RuntimeError):
            A.source_authority(a)
        a.reader_manifest_sha256 = A.MANIFEST_SHA
        def fake_digest(p):
            return dict(sha256='own' if Path(p) == A.OWN / 'inventory.json' else 'changed')
        with patch.object(A, 'digest', side_effect=fake_digest), patch.object(A, 'js', return_value=dict(rows=[])), self.assertRaises(RuntimeError):
            A.source_authority(a)

    def test_exact013_charge_and_below_or_missing_refusal(self):
        A.charge_gate(A.BEFORE_DECODE, 10402566933, A.DECODE_CAP)
        for before, charge, cap in [(A.BEFORE_DECODE - 1, 10402566933, A.DECODE_CAP), (20752952088, 10402566933, A.DECODE_CAP), (A.BEFORE_DECODE, 10402566932, A.DECODE_CAP), (A.BEFORE_DECODE, 10402566933, A.AFTER_DECODE - 1)]:
            with self.assertRaises(RuntimeError):
                A.charge_gate(before, charge, cap)

    def test_both_failed_and_repaired_reservations_are_charged(self):
        self.metadata(self.root / 'readback-1/decode-reservation.json', dict(charged_decoded_bytes=11))
        self.metadata(self.root / 'readback-1-repaired-first/decode-reservation.json', dict(charged_decoded_bytes=11))
        self.metadata(self.root / 'work/member/a.child-intent.json', dict(decoded=True, reserved_decoded_bytes=5))
        self.assertEqual(A.original.charged_decoded(self.root, 27), 27)
        with self.assertRaises(RuntimeError):
            A.original.charged_decoded(self.root, 26)

    def test_corrected_acceptance_requires_complete_bound_result(self):
        s, a, doc = self.fixtures()
        with self.reader_context(), patch.object(A, 'gone'):
            self.assertTrue(A.repaired_reader_ok(doc, s, a))
            for key, value in [('complete', False), ('restore_result_sha256', 'wrong'), ('selection_sha256', 'wrong'), ('preparation_inventory_sha256', 'wrong'), ('readback_reader', s['readback_reader']), ('original_selected_reader', None), ('reader_manifest', None), ('failed_readback', None), ('charged_decoded_bytes', 0)]:
                bad = copy.deepcopy(doc); bad[key] = value
                with self.subTest(key=key), self.assertRaises(RuntimeError):
                    A.repaired_reader_ok(bad, s, a)

    def test_decoder_missing_duplicate_failure_and_wrong_raw_refused(self):
        s, a, doc = self.fixtures()
        mutations = []
        bad = copy.deepcopy(doc); bad['decoder_receipts'].pop(); mutations.append(bad)
        bad = copy.deepcopy(doc); bad['decoder_receipts'][1] = bad['decoder_receipts'][0]; mutations.append(bad)
        for key, value in [('complete', False), ('exit_code', 1), ('absent', False), ('bytes', 3), ('sha256', 'wrong'), ('codec_sha256', 'wrong')]:
            bad = copy.deepcopy(doc); bad['decoder_receipts'][0][key] = value; mutations.append(bad)
        with self.reader_context(), patch.object(A, 'gone'):
            for bad in mutations:
                with self.assertRaises(RuntimeError):
                    A.repaired_reader_ok(bad, s, a)

    def test_real_second_cycle_gate_uses_new_file_and_keeps_old_failure(self):
        s, a, doc = self.fixtures()
        old = dict(complete=False, error='original failure')
        self.metadata(self.root / 'readback-1/result.json', old)
        saved = (self.root / 'readback-1/result.json').read_bytes()
        restored = dict(complete=True, state='RESTORED', selection_sha256=a.selection_sha256,
                        verified_sha256=a.release_verified_sha256, rows=[dict(id='1', identity={'inode': 1}), dict(id='2', identity={'inode': 2})])
        a.restore_result_sha256 = self.metadata(self.root / 'restore-1/result.json', restored)
        doc['restore_result_sha256'] = a.restore_result_sha256
        a.readback_result_sha256 = self.metadata(self.root / 'readback-1-repaired-first/result.json', doc)
        with self.reader_context(), patch.object(A, 'gone'):
            self.assertEqual(T.second_cycle_gate(s, self.root, a), {'1': {'inode': 1}, '2': {'inode': 2}})
            a.readback_result_sha256 = A.digest(self.root / 'readback-1/result.json')['sha256']
            with self.assertRaises(RuntimeError):
                T.second_cycle_gate(s, self.root, a)
        self.assertEqual((self.root / 'readback-1/result.json').read_bytes(), saved)

    def test_external_repair_allocation_is_part_of_original_cap(self):
        limits = dict(metadata_bytes=1000000, tx_allocated_bytes=100, external_restored_target_allowance_bytes=70)
        original_session = SimpleNamespace(guard=lambda reserve=0: {} )
        calls = []
        def guard(reserve=0):
            calls.append(original_session.external_allocation_reserve)
            A.need(original_session.external_allocation_reserve + reserve <= 100, 'test actual combined cap')
            return {}
        original_session.guard = guard
        with patch.object(A.original, 'session', return_value=original_session), patch.object(A, 'external_allocation', return_value=31):
            sess = A.session(self.root, dict(limits=limits))
            with self.assertRaises(RuntimeError):
                sess.guard()
        self.assertEqual(calls, [101])

    def test_original_step_retains_failed_child_then_records_actual_success(self):
        folder = self.root / 'wrapper'; folder.mkdir()
        output = self.root / 'new-result.json'
        self.metadata(output, dict(complete=True, identity='expected'))
        class Child:
            pid = os.getpid()
            returncode = 1
            def poll(self): return self.returncode
            def wait(self): return self.returncode
        child = Child()
        with patch.object(R.dispatcher.subprocess, 'Popen', return_value=child), patch.object(R.dispatcher, 'guard', return_value=10**12):
            with self.assertRaises(RuntimeError):
                R.dispatcher.step(folder, 'repaired', ['synthetic-only'], output, dict(identity='expected'))
            failed = folder / 'repaired-attempt-0/failure.json'
            prior = failed.read_bytes()
            self.assertFalse((folder / 'repaired-complete.json').exists())
            child.returncode = 0
            result = R.dispatcher.step(folder, 'repaired', ['synthetic-only'], output, dict(identity='expected'))
            self.assertTrue(result['complete'])
            done = A.js(folder / 'repaired-complete.json')
            self.assertEqual(done['exit_code'], 0)
            self.assertTrue(done['child_reaped'])
            self.assertEqual(failed.read_bytes(), prior)

    def test_inherited_retirement_loop_and_step_are_unchanged(self):
        def retire_body(path):
            tree = ast.parse(path.read_text())
            fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
            for n in ast.walk(fn):
                if isinstance(n, ast.If) and ast.unparse(n.test) == "a.action == 'retire'":
                    return ast.dump(ast.Module(body=n.body, type_ignores=[]), include_attributes=False)
            self.fail('retire body missing')
        self.assertEqual(retire_body(A.OLD / 'transition.py'), retire_body(A.OWN / 'transition_repaired.py'))
        self.assertEqual((A.OWN / 'originals/run.py').read_bytes(), (A.OLD / 'run.py').read_bytes())
        self.assertEqual((A.OWN / 'originals/support.py').read_bytes(), (A.OLD / 'support.py').read_bytes())
        self.assertEqual((A.OWN / 'originals/common.py').read_bytes(), (A.OLD / 'common.py').read_bytes())
        self.assertIs(R.dispatcher.step.__code__.co_filename.endswith('/run.py'), True)

    def test_exact_second_restore_readback_charge_is_bounded(self):
        A.charge_gate(48475736650, 10402566933, A.DECODE_CAP, 2)
        for previous, cap, cycle in [(48475736649, A.DECODE_CAP, 2), (48475736650, 58878303582, 2), (48475736650, A.DECODE_CAP, 3)]:
            with self.assertRaises(RuntimeError):
                A.charge_gate(previous, 10402566933, cap, cycle)

    def test_original_restore_body_unchanged_and_no_third_cycle(self):
        def restore_body(path):
            tree = ast.parse(path.read_text())
            for n in ast.walk(tree):
                if isinstance(n, ast.If) and ast.unparse(n.test) == "a.action == 'retire'":
                    return ast.dump(ast.Module(body=n.orelse, type_ignores=[]), include_attributes=False)
        self.assertEqual(restore_body(A.OLD / 'transition.py'), restore_body(A.OWN / 'transition_repaired.py'))
        tree = ast.parse((A.OWN / 'transition_repaired.py').read_text())
        conditions = [ast.unparse(n.args[0]) for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'need' and n.args]
        self.assertIn('a.cycle == 2', conditions)

    def test_dispatcher_exposes_real_corrected_restore_and_readback_routes(self):
        from contextlib import ExitStack, redirect_stdout
        import io
        folder = self.root / 'exec/013'; folder.mkdir(parents=True)
        (folder.parent / 'serial.lock').touch()
        s = dict(root=str(self.root), group_ordinal=13, limits=dict(metadata_bytes=1000000, external_restored_target_allowance_bytes=100, scratch_reserve_bytes=100, tx_allocated_bytes=1000000000))
        group = dict(rows=[None] * 13 + [dict(ordinal=13, selection=dict(path='selection', sha256='selection'))])
        hashes = {'result.json': 'result'}
        def fake_digest(p):
            p = Path(p)
            value = 'verified' if p.parent.name == 'verification-first' else 'restore1' if p.parent.name == 'restore-1' else 'readback1' if p.parent.name == 'readback-1-repaired-first' else 'restore2' if p.parent.name == 'restore-2' else 'result'
            return dict(bytes=1, sha256=value)
        for mode, expected_script, expected_phase in [('restore-final', 'transition_repaired.py', 'restore-2'), ('readback-final', 'readback_repaired.py', 'readback-2-repaired')]:
            calls = []
            with ExitStack() as stack:
                for name, value in [('source_authority', None), ('load', s), ('js', group), ('external_allocation', 0), ('reader_binding', {}), ('repaired_reader_ok', True), ('accounting', {})]:
                    stack.enter_context(patch.object(R, name, return_value=value))
                stack.enter_context(patch.object(R, 'digest', side_effect=fake_digest))
                stack.enter_context(patch.object(R.dispatcher, 'EXECUTION', folder.parent))
                stack.enter_context(patch.object(R.dispatcher, 'guard', return_value=10**12))
                stack.enter_context(patch.object(R.dispatcher, 'validate_done', return_value=dict(toolchain_sha256='tool')))
                stack.enter_context(patch.object(R.dispatcher, 'step', side_effect=lambda *args: calls.append(args) or {}))
                stack.enter_context(patch.object(R.common, 'allocated', return_value=0))
                stack.enter_context(patch.object(R.signal, 'signal'))
                stack.enter_context(patch.object(R, 'reconciliation_binding', return_value=dict(first_restore='restore1', first_readback='readback1')))
                stack.enter_context(patch.object(R.sys, 'argv', ['reconcile.py', '--mode', mode, '--ordinal', '13', '--code-pins-sha256', A.CODE_SHA, '--release-verified-sha256', 'verified', '--preparation-inventory-sha256', 'own', '--reader-manifest', str(A.MANIFEST), '--reader-manifest-sha256', A.MANIFEST_SHA]))
                with redirect_stdout(io.StringIO()):
                    self.assertEqual(R.main(), 0)
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0][1], expected_phase)
            argv = calls[0][2]
            self.assertEqual(Path(argv[1]).name, expected_script)
            self.assertEqual(argv[argv.index('--cycle') + 1], '2')
            self.assertEqual(argv[argv.index('--restore-result-sha256') + 1], 'restore1' if mode == 'restore-final' else 'restore2')
            if mode == 'restore-final':
                self.assertIn('restore', argv)
                self.assertEqual(argv[argv.index('--readback-result-sha256') + 1], 'readback1')


if __name__ == '__main__':
    unittest.main(verbosity=2)
