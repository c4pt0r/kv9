"""Freeze only finite metadata and source authorities; never reads object payloads."""
from pathlib import Path
import ast,difflib,hashlib,json,os,stat,time
P=Path(__file__).resolve().parent
OLD=Path('/tmp/kv9-write-release-capacity-tranche-20260915-second')
GROUP=Path('/tmp/kv9-cross-voter-multicohort-migration-preparation-20260915-first')
def pin(f):
 f=Path(f);st=f.lstat();assert stat.S_ISREG(st.st_mode)and st.st_size<=16*1024**2
 b=f.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,value):
 with (P/name).open('x')as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
assert pin(P/'tranche.original.py')['sha256']=='3e631ecf4cc009a11a29b522d8eee1a75dcac47455850e33fd80c38c15362826'
assert pin(OLD/'tranche.py')==pin(P/'tranche.original.py')
result=json.loads((P/'controls-result.json').read_text());assert result['complete']and result['exit_code']==0
for f,r in result['source_pins'].items():assert pin(f)==r
save('controls-terminal.json',dict(complete=True,execution_kind='direct_tool_terminal',terminal_receipt='18e6d2',exit_code=0,tests=6,result=pin(P/'controls-result.json'),scope='New observer boundary/prefix/accounting controls only.'))
(P/'tranche.diff').write_text(''.join(difflib.unified_diff((P/'tranche.original.py').read_text().splitlines(True),(P/'tranche.py').read_text().splitlines(True),fromfile=str(OLD/'tranche.py'),tofile=str(P/'tranche.py'))))
before=json.loads((OLD/'inputs.json').read_text());files=dict(before['files'])
for f,r in files.items():assert pin(f)==r,'prior authority changed: '+f
prefix=OLD/'result-1789472166055108240.json'
extra=[OLD/n for n in ['tranche.py','inputs.json','invocation.json','tool-terminal.json','launch-child-terminal.json','status.json','accepted-summary.json','inventory.final.json','preparation-inventory.json','controls-terminal.json']]+[prefix]
for i in range(56,61):extra.extend([OLD/f'{i:03d}'/'complete.json',OLD/f'{i:03d}'/'release.json'])
selections=[]
for i,ceiling in [(61,336265216),(62,335695872),(63,335314944)]:
 f=GROUP/'selections'/f'{i:03d}.json';s=json.loads(f.read_text());extra.append(f)
 assert s['group_ordinal']==i and s['target_allocated_bytes']==ceiling and s['target_count']==28 and s['original_object_count']==72
 assert s['limits']['tx_allocated_bytes']==2*1024**3 and s['limits']['cumulative_decoded_bytes']==10*1024**3 and s['limits']['free_floor_bytes']==8*1024**3
 tx=Path(s['root']);ex=Path('/tmp/kv9-cross-voter-multicohort-execution-20260915-first')/f'{i:03d}'
 assert not tx.exists()and not tx.is_symlink()and not ex.exists()and not ex.is_symlink()
 selections.append(dict(ordinal=i,selection=dict(path=str(f),**pin(f)),root=s['root'],cohort=s['cohort'],screen=s['screen'],target_count=s['target_count'],original_object_count=s['original_object_count'],logical_bytes=s['logical_cohort_bytes'],target_allocation_ceiling_bytes=ceiling,limits=s['limits'],root_and_execution_absent=True))
files.update({str(f):pin(f)for f in extra})
own={f.name:pin(f)for f in P.iterdir()if f.is_file()}
save('inputs.json',dict(schema=1,files=files,own_sources=own,previous_prefix_path=before['previous_prefix_path'],recent_prefix_path=str(prefix),scope='Observer capacity only: actual completed000..060 authority, fresh061..063 only, never064. No performance capacity claim.',first=61,last=63,actual_available_stop_bytes=26315063296,observer_launch_bytes=25778192384))
v=os.statvfs(P);free=v.f_bavail*v.f_frsize
save('capacity-plan.json',dict(metadata_only=True,runtime_ready=False,observed_ns=time.time_ns(),actual_available_bytes=free,observer_launch_bytes=25778192384,observer_stop_bytes=26315063296,launch_gap_bytes=max(0,25778192384-free),stop_gap_bytes=max(0,26315063296-free),selected_target_allocation_ceiling_bytes=sum(x['target_allocation_ceiling_bytes']for x in selections),ceiling_is_not_saving_or_retirement_authority=True,first=61,end_exclusive=64,selections=selections,full_performance_gate_not_addressed=True,minimum_cohort_launch_including_controller_allowance_bytes=10754195456+512*1024**2))
argv=['sudo','-n','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','taskset','-c','6-15,22-31','python3','-u',str(P/'tranche.py'),'--inputs-sha256',pin(P/'inputs.json')['sha256']]
save('ROOT-COMMANDS.json',dict(schema=1,launch=dict(argv=argv,source_sha256=pin(P/'tranche.py')['sha256'],inputs_sha256=pin(P/'inputs.json')['sha256'],expected_status_path=str(P/'status.json'),root_must_record_actual_tool_terminal=True),new_controls=dict(already_completed=True,actual_terminal_receipt='18e6d2',exit_code=0,tests=6),release_pending=True,scope='Root reviews and launches only this finite observer-capacity tranche. Existing c.invoke owns bounded serial phase supervision and fresh input/space/prefix gates. No codec/retirement was executed during preparation.'))
assert not any(f.suffix=='.pyc'for f in P.rglob('*'))
rows={str(f.relative_to(P)):pin(f)for f in P.rglob('*')if f.is_file()}
allocated=sum(f.lstat().st_blocks*512 for f in [P,*P.rglob('*')])
assert sum(r['bytes']for r in rows.values())<8*1024**2 and allocated+32768<8*1024**2
save('preparation-inventory.json',dict(complete=True,runtime_executed=False,files=rows,file_bytes=sum(r['bytes']for r in rows.values()),allocated_bytes_before_inventory=allocated,preparation_cap_bytes=8*1024**2))
print(json.dumps(dict(source=pin(P/'tranche.py'),inputs=pin(P/'inputs.json'),commands=pin(P/'ROOT-COMMANDS.json'),inventory=pin(P/'preparation-inventory.json'),external_authority_files=len(files),prepared_files=len(rows),allocated_bytes_before_inventory=allocated,actual_available_bytes=free),sort_keys=True))
