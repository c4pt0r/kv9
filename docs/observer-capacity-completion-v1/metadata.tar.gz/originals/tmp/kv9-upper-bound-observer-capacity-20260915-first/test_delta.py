"""Only new observer boundary, predecessor056..060 and accounting controls."""
import ast,copy,unittest
from pathlib import Path
from types import SimpleNamespace
import tranche as t

class ObserverDelta(unittest.TestCase):
 def fixture(self):
  db={};pins={};checked=[];proofpath=t.RECENT/'result-1789472166055108240.json'
  pins[str(proofpath)]={'sha256':'prefix'}
  binding={'recent_prefix_path':str(proofpath),'files':{str(proofpath):pins[str(proofpath)]}}
  accept=lambda i:dict(state='COLD',ordinal=i,selection_sha256=f's{i}',verified_sha256=f'v{i}')
  proof=dict(complete=True,historical_completed_ordinals=list(range(56)),new_completed_ordinals=list(range(56,61)),next_ordinal=61,reason='actual_release_envelope_plus_margin',completed=[])
  db[str(t.RECENT/'tool-terminal.json')]=dict(complete=True,session_id=86445,terminal_receipt='d61c44',exit_code=0,result_path=str(t.RECENT/'status.json'),result_sha256='status')
  db[str(t.RECENT/'launch-child-terminal.json')]=dict(complete=True,exit_code=0,argv=['bound','argv'])
  db[str(t.RECENT/'invocation.json')]={'argv':['bound','argv']}
  db[str(t.RECENT/'status.json')]=dict(state='COMPLETE',reason='actual_release_envelope_plus_margin',target_reached=True,next_ordinal=61,completed_ordinals=list(range(56,61)))
  pins[str(t.RECENT/'status.json')]={'sha256':'status'}
  for i in range(56,61):
   cp=t.RECENT/f'{i:03d}'/'complete.json';rp=t.RECENT/f'{i:03d}'/'release.json';pins[str(cp)]={'sha256':f'c{i}'};pins[str(rp)]={'sha256':f'r{i}'}
   r=dict(complete=True,ordinal=i,verified_sha256=f'v{i}',acceptance=accept(i),release_pin=copy.deepcopy(pins[str(rp)]));db[str(cp)]=r
   proof['completed'].append(dict(ordinal=i,verified_sha256=f'v{i}',acceptance=accept(i),complete_record=copy.deepcopy(pins[str(cp)])))
  db[str(proofpath)]=proof
  def check(p,v):
   if pins[str(p)]!=v:raise RuntimeError('changed pin')
   checked.append(str(p))
  c=SimpleNamespace(js=lambda p:db[str(p)],pin=lambda p:pins[str(p)],check=check,completed=lambda g,i,v:accept(i))
  return c,db,pins,binding,[dict(ordinal=i)for i in range(56)],checked
 def test_exact_bound_prefix(self):
  c,db,pins,b,h,checks=self.fixture();self.assertEqual([r['ordinal']for r in t.extend_recent_history(c,None,b,h)],list(range(61)));self.assertEqual(len(checks),6)
 def test_bad_terminal_status_or_child_refused(self):
  for file,key,bad in [('tool-terminal.json','exit_code',1),('tool-terminal.json','terminal_receipt','other'),('tool-terminal.json','session_id',0),('launch-child-terminal.json','complete',False),('launch-child-terminal.json','argv',['other']),('status.json','state','FAILED'),('status.json','next_ordinal',62),('status.json','completed_ordinals',list(range(56,60)))]:
   c,db,pins,b,h,_=self.fixture();db[str(t.RECENT/file)][key]=bad
   with self.subTest(file=file,key=key),self.assertRaises(RuntimeError):t.extend_recent_history(c,None,b,h)
 def test_prefix_hash_population_and_release_refused(self):
  for mutation in ['proof-hash','missing-row','wrong-history','completion-pin','release-pin','restored']:
   c,db,pins,b,h,_=self.fixture()
   if mutation=='proof-hash':pins[b['recent_prefix_path']]={'sha256':'changed'}
   elif mutation=='missing-row':db[b['recent_prefix_path']]['completed'].pop()
   elif mutation=='wrong-history':h.pop()
   elif mutation=='completion-pin':pins[str(t.RECENT/'058/complete.json')]={'sha256':'changed'}
   elif mutation=='release-pin':pins[str(t.RECENT/'058/release.json')]={'sha256':'changed'}
   else:c.completed=lambda g,i,v:dict(state='RESTORED',ordinal=i)
   with self.subTest(mutation=mutation),self.assertRaises(RuntimeError):t.extend_recent_history(c,None,b,h)
 def test_finite_boundary_and_actual_stop(self):
  self.assertEqual((t.FIRST,t.END,t.STOP,t.OBSERVER_LAUNCH),(61,64,26315063296,25778192384));self.assertEqual(t.STOP-t.OBSERVER_LAUNCH,512*1024**2)
  self.assertIsNone(t.stop_reason(t.STOP-1,63));self.assertEqual(t.stop_reason(t.STOP-1,64),'finite_061_063_exhaustion');self.assertEqual(t.stop_reason(t.STOP,61),'actual_observer_envelope_plus_margin')
  self.assertEqual(t.prefix({},set()),([],61))
  for names in [{64},{62},{60}]:
   with self.assertRaises(RuntimeError):t.prefix({},names)
  with self.assertRaises(RuntimeError):t.prefix({61:{'complete':False}}, {61})
 def test_added_roots_and_unchanged_phase_functions(self):
  c=t.load_controller();rows=c.extra_accounting_roots();self.assertEqual(len(rows),15);self.assertEqual(len(set(str(p)for p,cap in rows)),15)
  for p in [t.HERE,t.OLD_OUT,t.PREVIOUS,t.RECENT]:self.assertIn((p,c.CAP),rows)
  for p in t.ADDITIONAL_REPORT_ROOTS:self.assertIn((p,8*c.MIB),rows)
  for f in [c.invoke,c.verify_release,c.completed,c.finish_argv]:self.assertEqual(f.__code__.co_filename,str(t.PREP/'campaign.py'))
  old=ast.parse((t.HERE/'tranche.original.py').read_text());new=ast.parse((t.HERE/'tranche.py').read_text())
  a={n.name:ast.dump(n)for n in old.body if isinstance(n,ast.FunctionDef)};b={n.name:ast.dump(n)for n in new.body if isinstance(n,ast.FunctionDef)}
  self.assertEqual(a['historical_before040'],b['historical_before040'])
 def test_allocation_stop_uses_actual_space(self):
  c=SimpleNamespace(accounting=lambda o,g:dict(target_reached=True,actual_available_bytes=t.STOP-1,scope='old'))
  a=t.scoped_accounting(c,None,None);self.assertFalse(a['target_reached']);self.assertTrue(a['prior_continuation_85gb_target_reached']);self.assertEqual(a['tranche_range'],[61,63])
if __name__=='__main__':unittest.main(verbosity=2)
