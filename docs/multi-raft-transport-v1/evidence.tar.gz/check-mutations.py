from pathlib import Path
import subprocess,json,hashlib,time
work=Path(__file__).parent
repo=Path('/home/dongxu/kv9')
plan=json.loads((work/'mutation-plan.json').read_text())
receipts=[]
def run(name,selector,exact=False):
 cmd=['cargo','test','-p','kv9-raft','--lib',selector,'--','--test-threads=1']+(['--exact'] if exact else [])
 with (work/(name+'.log')).open('w') as log:
  completed=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 out=(work/(name+'.log')).read_text()
 return completed.returncode,out
code,out=run('mutation-baseline',plan['baseline_filter'])
assert code==0 and 'test result: ok. 5 passed; 0 failed' in out
for c in plan['controls']:
 p=repo/c['file'];original=p.read_bytes();text=original.decode();assert text.count(c['old'])==1
 mutated=text.replace(c['old'],c['new']);(work/(c['name']+'.rs')).write_text(mutated)
 try:
  p.write_text(mutated)
  code,out=run(c['name'],c['test'],True)
 finally:
  p.write_bytes(original)
 assert code==101 and 'test result: FAILED. 0 passed; 1 failed' in out and c['failure'] in out,(c['name'],code,out[-2000:])
 receipts.append({'name':c['name'],'test':c['test'],'selected':1,'exit_code':code,'expected_failure':c['failure'],'original_sha256':hashlib.sha256(original).hexdigest(),'mutated_sha256':hashlib.sha256(mutated.encode()).hexdigest()})
 (work/'mutation-results.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('CONTROL_ACCEPTED',c['name'],flush=True)
code,out=run('mutation-restored',plan['baseline_filter'])
assert code==0 and 'test result: ok. 5 passed; 0 failed' in out
print('MULTI_GROUP_MUTATION_CHECKS_ACCEPTED: 5 controls; 5 baseline/restored tests',flush=True)
