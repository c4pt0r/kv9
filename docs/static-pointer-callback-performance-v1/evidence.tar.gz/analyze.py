#!/usr/bin/env python3
"""Independently validate every terminal/result and recompute the selection gate."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path

S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('inputs', S / 'validate-inputs.py')
inputs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inputs)
used = {}


def read(path):
    data = path.read_bytes()
    used[str(path)] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return json.loads(data)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def percentile(samples, percentile):
    return sorted(samples)[math.ceil(len(samples) * percentile / 100) - 1]


plan = read(S / 'timing-plan.json')
build = read(S / 'build-summary.json')
runs = read(S / 'run-summary.json')
assert build['complete'] and runs['complete'] and len(runs['processes']) == 338
assert all(p['complete'] and p['exit_code'] == 0 for p in runs['processes'])
assert build['plan_sha256'] == sha(S / 'timing-plan.json')
for path, digest in build['sources'].items():
    assert sha(Path(path)) == digest
for arm in ('baseline', 'candidate'):
    cache = read(S / ('build-' + arm) / 'cache-safety.json')
    sources = read(S / ('build-' + arm) / 'sources.json')
    assert cache['complete'] and cache['invalidation_complete']
    assert cache['source_identity_sha256'] == hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    for mode in ('timing', 'counting'):
        pin = build['arms'][arm][mode]
        assert sha(Path(pin['path'])) == pin['sha256']
accepted = read(S / 'runs/inputs-accepted.json')
assert accepted['complete'] and accepted['independent_reconstruction']
models, metadata = inputs.reconstruct()
assert metadata == accepted['models']
for arm in ('baseline', 'candidate'):
    path = S / 'runs' / ('prepare-' + arm + '.json')
    prepared = read(path)
    assert sha(path) == accepted['prepared_sha256'][arm]
    assert prepared['workloads'] == metadata and prepared['correctness_live_prefixes'] == 1908 and prepared['correctness_old_views'] == 954
    terminal = read(S / 'runs' / ('prepare-' + arm + '-terminal.json'))
    assert terminal['complete'] and terminal['exit_code'] == 0 and terminal['result_sha256'] == sha(path)
cases = [(d, 'write', w, p) for d in plan['datasets'] for w in plan['write_workloads'] for p in (False, True)]
cases += [(d, op, w, False) for d in plan['datasets'] for w in plan['read_workloads'] for op in plan['read_operations']]
assert len(cases) == 42
results = {}
for mode in ('timing', 'counting'):
    rows = []
    for case, key in enumerate(cases):
        for order, arm in enumerate(plan['orders']):
            name = f'{mode}-{case:02d}-{order}'
            terminal = read(S / 'runs' / (name + '-terminal.json'))
            payload = read(S / 'runs' / (name + '.json'))
            pin = build['arms'][arm][mode]
            assert terminal['complete'] and terminal['exit_code'] == 0 and terminal['arm'] == arm and terminal['mode'] == mode
            assert terminal['argv'] == ['taskset', '-c', str(plan['cpu']), pin['path'], str(S), str(S / 'runs' / (name + '.json')), 'measure', str(case), str(order)]
            assert terminal['binary_sha256'] == pin['sha256'] and terminal['result_sha256'] == used[str(S / 'runs' / (name + '.json'))]['sha256']
            assert payload['complete'] and payload['counting_build'] == (mode == 'counting') and len(payload['rows']) == 1
            assert payload['workloads'] == metadata and payload['input_plan_sha256'] == build['plan_sha256'] and payload['group_file_sha256'] == plan['corpus_sha256']
            row = payload['rows'][0]
            assert (row['dataset'], row['operation'], row['workload'], row['pinned']) == key
            assert row['case'] == case and row['order'] == order and row['backend'] == arm
            passes = 12 if mode == 'timing' else 1
            assert row['passes'] == passes
            metrics = row['metrics']
            assert metrics['windows'] == passes * (106 if row['operation'] == 'write' else 512)
            if row['operation'] == 'write':
                model = models[row['dataset'], row['workload']]
                assert row['mutations'] == 100096 * passes and row['final_state_sha256'] == inputs.digest(model) and row['final_keys'] == len(model)
            else:
                assert row['queries'] == 512 and row['all_query_outputs_checked']
                query = next(q for q in accepted['query_identities'] if (q['dataset'], q['workload'], q['operation']) == (row['dataset'], row['workload'], row['operation']))
                assert row['query_sha256'] == query['query_sha256']
            if mode == 'timing':
                samples = metrics['samples_ns']
                assert len(samples) == metrics['windows'] and all(type(n) is int and n > 0 for n in samples)
                assert metrics['sum_ns'] == sum(samples) and metrics['mean_ns'] == sum(samples) / len(samples)
                for quantile in (50, 95, 99):
                    assert metrics[f'p{quantile}_ns'] == percentile(samples, quantile)
            else:
                assert 'samples_ns' not in metrics and 'mean_ns' not in metrics
            rows.append(row)
    assert len(rows) == 168
    results[mode] = rows

reports = []
for case, (dataset, operation, workload, pinned) in enumerate(cases):
    timed = [r for r in results['timing'] if r['case'] == case]
    counted = [r for r in results['counting'] if r['case'] == case]
    assert len(timed) == len(counted) == 4
    assert len({json.dumps(r['metrics'], sort_keys=True) for r in counted}) == 1, ('allocation operations changed', case)
    memory = None
    if operation == 'write':
        assert all(r['requested_live_bytes']['released_after_drop'] for r in counted)
        assert len({json.dumps(r['requested_live_bytes'], sort_keys=True) for r in counted}) == 1
        memory = counted[0]['requested_live_bytes']
    pooled = {}
    for arm in ('baseline', 'candidate'):
        samples = [n for r in timed if r['backend'] == arm for n in r['metrics']['samples_ns']]
        pooled[arm] = {'samples': len(samples), 'mean_ns': sum(samples) / len(samples), 'p99_ns': percentile(samples, 99)}
    comparisons = []
    for old, new in ((0, 1), (3, 2)):
        baseline, candidate = timed[old]['metrics'], timed[new]['metrics']
        comparisons.append({'baseline_order': old, 'candidate_order': new,
                            'mean_change_percent': (candidate['mean_ns'] / baseline['mean_ns'] - 1) * 100,
                            'p99_change_percent': (candidate['p99_ns'] / baseline['p99_ns'] - 1) * 100,
                            'baseline_mean_ns': baseline['mean_ns'], 'candidate_mean_ns': candidate['mean_ns'],
                            'baseline_p99_ns': baseline['p99_ns'], 'candidate_p99_ns': candidate['p99_ns']})
    reports.append({'case': case, 'dataset': dataset, 'operation': operation, 'workload': workload, 'pinned': pinned,
                    'pooled': pooled, 'mean_change_percent': (pooled['candidate']['mean_ns'] / pooled['baseline']['mean_ns'] - 1) * 100,
                    'p99_change_percent': (pooled['candidate']['p99_ns'] / pooled['baseline']['p99_ns'] - 1) * 100,
                    'orders': comparisons, 'allocation_counts_per_pass': counted[0]['metrics'], 'requested_live_bytes': memory})
writes = [r for r in reports if r['operation'] == 'write']
reads = [r for r in reports if r['operation'] != 'write']
material = all(r['mean_change_percent'] <= -10 for r in writes if r['dataset'] == 'original24' and r['workload'] in ('overwrite', 'unique_insert'))
order_gate = all(order['mean_change_percent'] < 0 for row in writes for order in row['orders'])
read_gate = all(row['mean_change_percent'] <= 2 and row['p99_change_percent'] <= 2 for row in reads)
result = {'complete': True, 'production_changed': False, 'new_database_qps': False,
          'independent_input_state_queries_statistics': True, 'rows_per_mode': 168, 'cases': reports,
          'prefix_states': 3816, 'old_views': 1908, 'terminal_processes': 338,
          'allocation_and_live_bytes_identical': True,
          'predeclared_gate': {'original_material_write_gain': material, 'all_write_order_means_better': order_gate,
                              'reads_within_two_percent': read_gate, 'advance': material and order_gate and read_gate}}
(S / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
(S / 'analysis-inputs.json').write_text(json.dumps(used, indent=2) + '\n')
print(json.dumps({'complete': True, 'gate': result['predeclared_gate'],
                  'original_writes': [{k: r[k] for k in ('workload', 'pinned', 'mean_change_percent', 'p99_change_percent', 'orders')} for r in writes if r['dataset'] == 'original24'],
                  'read_gate_failures': [{k: r[k] for k in ('dataset', 'operation', 'workload', 'mean_change_percent', 'p99_change_percent')} for r in reads if r['mean_change_percent'] > 2 or r['p99_change_percent'] > 2]}, indent=2))
