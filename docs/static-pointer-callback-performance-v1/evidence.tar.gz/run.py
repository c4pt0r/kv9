#!/usr/bin/env python3
"""Execute the declared per-case ABBA comparison after independent preparation."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

S = Path(__file__).resolve().parent
O = S / 'runs'
O.mkdir(exist_ok=False)
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
build = load(S / 'build-summary.json')
plan = load(S / 'timing-plan.json')
assert build['complete'] and sha(S / 'timing-plan.json') == build['plan_sha256']
assert sorted(os.sched_getaffinity(0)) == list(range(6, 16)) + list(range(22, 32))
assert plan['orders'] == ['baseline', 'candidate', 'candidate', 'baseline']
for path, digest in build['sources'].items():
    assert sha(Path(path)) == digest
qualification = Path(plan['qualified_dependency_root'])
assert load(qualification / 'independent-audit.json')['complete']
for path, digest in load(qualification / 'proof/source-inputs.json').items():
    assert sha(Path(path)) == digest
cases = [(d, 'write', w, p) for d in plan['datasets'] for w in plan['write_workloads'] for p in (False, True)]
cases += [(d, op, w, False) for d in plan['datasets'] for w in plan['read_workloads'] for op in plan['read_operations']]
assert len(cases) == 42
summary = {'complete': False, 'started_ns': time.time_ns(), 'processes': [], 'performance_acceptance': False}


def execute(name, arm, mode, operation, case, order):
    pin = build['arms'][arm][mode]
    assert sha(Path(pin['path'])) == pin['sha256']
    free = {path: shutil.disk_usage(path).free for path in ('/home/dongxu/kv9', '/mnt/data')}
    assert min(free.values()) >= plan['minimum_free_bytes']
    command = ['taskset', '-c', str(plan['cpu']), pin['path'], str(S), str(O / (name + '.json')), operation, str(case), str(order)]
    row = {'name': name, 'arm': arm, 'mode': mode, 'complete': False, 'argv': command,
           'binary_sha256': pin['sha256'], 'started_ns': time.time_ns(), 'free_bytes': free,
           'loadavg': Path('/proc/loadavg').read_text().strip(), 'cpu': plan['cpu'],
           'cpu_siblings': Path('/sys/devices/system/cpu/cpu4/topology/thread_siblings_list').read_text().strip(),
           'shared_host': True}
    process = None
    try:
        with (O / (name + '.stdout')).open('x') as out, (O / (name + '.stderr')).open('x') as err:
            process = subprocess.Popen(command, stdout=out, stderr=err)
            row['pid'] = process.pid
            row['start_ticks'] = int(Path(f'/proc/{process.pid}/stat').read_text().rsplit(')', 1)[1].split()[19])
            (O / (name + '-launch.json')).write_text(json.dumps(row, indent=2) + '\n')
            row['exit_code'] = process.wait(timeout=plan['timeout_seconds_per_process'])
        assert row['exit_code'] == 0, name
        path = O / (name + '.json')
        assert path.stat().st_size <= plan['process_output_max_bytes']
        result = load(path)
        assert result['complete'] and result['input_plan_sha256'] == build['plan_sha256']
        assert result['group_file_sha256'] == plan['corpus_sha256']
        if operation == 'measure':
            assert result['counting_build'] == (mode == 'counting') and len(result['rows']) == 1
            measured = result['rows'][0]
            assert measured['backend'] == arm and measured['order'] == order and measured['case'] == case
            assert (measured['dataset'], measured['operation'], measured['workload'], measured['pinned']) == cases[case]
            assert measured['passes'] == (plan['count_passes'] if mode == 'counting' else plan['passes'])
        assert sha(Path(pin['path'])) == pin['sha256']
        row.update(complete=True, result_sha256=sha(path), result_bytes=path.stat().st_size)
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            process.wait(timeout=30)
        row['ended_ns'] = time.time_ns()
        (O / (name + '-terminal.json')).write_text(json.dumps(row, indent=2) + '\n')
        summary['processes'].append(row)
        (S / 'run-progress.json').write_text(json.dumps(summary, indent=2) + '\n')


try:
    for order, arm in enumerate(('baseline', 'candidate')):
        execute('prepare-' + arm, arm, 'timing', 'prepare', 0, order)
        print(json.dumps({'prepare_complete': arm}), flush=True)
    with (O / 'inputs-check.stdout').open('x') as out, (O / 'inputs-check.stderr').open('x') as err:
        validation = subprocess.run(['python3', '-B', str(S / 'validate-inputs.py')], stdout=out, stderr=err, timeout=120)
    assert validation.returncode == 0
    assert load(O / 'inputs-accepted.json')['complete']
    for mode in ('timing', 'counting'):
        for case in range(42):
            for order, arm in enumerate(plan['orders']):
                execute(f'{mode}-{case:02d}-{order}', arm, mode, 'measure', case, order)
            print(json.dumps({'mode': mode, 'case_complete': case, 'total_cases': 42}), flush=True)
    for path, digest in build['sources'].items():
        assert sha(Path(path)) == digest
    assert len(summary['processes']) == 338 and all(p['complete'] for p in summary['processes'])
    summary['complete'] = True
except BaseException as error:
    summary['failure'] = repr(error)
    raise
finally:
    summary['ended_ns'] = time.time_ns()
    (S / 'run-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
