#!/usr/bin/env python3
"""Build paired ordinary-release timing/counting executables under one cache lock."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import tomllib

S = Path(__file__).resolve().parent
R = Path('/home/dongxu/kv9')
H = R / 'scripts/resident-static-callback'
Q = Path('/mnt/data/kv9-work/static-pointer-callback-20260916-first')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((Q / 'independent-audit.json').read_text())['complete']
for path, digest in json.loads((Q / 'proof/source-inputs.json').read_text()).items():
    assert sha(Path(path)) == digest
os.environ['CARGO_TARGET_DIR'] = str(R / 'target')
os.environ['CARGO_BUILD_JOBS'] = '4'
assert not any(os.environ.get(k) for k in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CFLAGS'))
spec = importlib.util.spec_from_file_location('cache', R / 'scripts/build_cache.py')
cache = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cache)
spec = importlib.util.spec_from_file_location('proof_helpers', R / 'scripts/check-crc32-proof.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
reference_source = (R / 'scripts/resident-packed-prefix/src/main.rs').read_text()
current_source = (H / 'src/main.rs').read_text()
reused = {}
for name in ('hash', 'digest', 'corpus', 'workload', 'populate', 'check_workload', 'begin', 'write_case', 'answer', 'queries', 'read_case', 'rekey', 'hex', 'emit'):
    old = helpers.declaration(reference_source, 'fn ' + name)
    new = helpers.declaration(current_source, 'fn ' + name)
    assert old == new, name
    reused[name] = hashlib.sha256(new.encode()).hexdigest()
for name in ('counting.rs', 'probes.rs'):
    assert (R / 'scripts/resident-packed-prefix/src' / name).read_bytes() == (H / 'src' / name).read_bytes()
(S / 'harness-reuse.json').write_text(json.dumps(reused, indent=2) + '\n')
with (S / 'harness-metadata.json').open('x') as out, (S / 'harness-metadata.stderr').open('x') as err:
    subprocess.run(['cargo', 'metadata', '--offline', '--format-version', '1'], cwd=H, stdout=out, stderr=err, check=True, timeout=120)
registry = lambda p: {(v['name'], v['version'], v['source']): v['checksum'] for v in tomllib.loads(p.read_text())['package'] if v.get('source', '').startswith('registry+')}
reference = registry(R / 'Cargo.lock')
summary = {'complete': False, 'started_ns': time.time_ns(), 'arms': {}, 'sources': {}, 'plan_sha256': sha(S / 'timing-plan.json')}
try:
    for arm in ('baseline', 'candidate'):
        work = S / ('source-' + arm)
        work.mkdir(exist_ok=False)
        shutil.copytree(H / 'src', work / 'src')
        manifest = (H / 'Cargo.toml').read_text() + f'\n[patch.crates-io]\narchery = {{ path = "{Q / (arm + "-archery")}" }}\n'
        (work / 'Cargo.toml').write_text(manifest)
        shutil.copyfile(H / 'Cargo.lock', work / 'Cargo.lock')
        output = S / ('build-' + arm)
        output.mkdir(exist_ok=False)
        with (output / 'metadata.json').open('x') as out, (output / 'metadata.stderr').open('x') as err:
            subprocess.run(['cargo', 'metadata', '--offline', '--format-version', '1'], cwd=work, stdout=out, stderr=err, check=True, timeout=120)
        resolved = registry(work / 'Cargo.lock')
        assert all(reference.get(key) == value for key, value in resolved.items())
        paths = [H / 'Cargo.toml', H / 'Cargo.lock', *sorted((H / 'src').rglob('*.rs')),
                 work / 'Cargo.toml', work / 'Cargo.lock', *sorted((work / 'src').rglob('*.rs')),
                 Q / (arm + '-archery') / 'Cargo.toml', *sorted((Q / (arm + '-archery') / 'src').rglob('*.rs'))]
        identity = {str(path): sha(path) for path in paths}
        summary['sources'].update(identity)
        (output / 'sources.json').write_text(json.dumps(identity, indent=2) + '\n')
        for path in paths:
            relative = Path('repo') / path.relative_to(R) if path.is_relative_to(R) else Path('qualification') / path.relative_to(Q) if path.is_relative_to(Q) else Path('experiment') / path.relative_to(S)
            dest = output / 'source' / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, dest)
        artifacts = {}
        summary['arms'][arm] = artifacts
        with cache.BuildCache(work, output, True, identity) as build:
            with (output / 'dependency-clean.stdout').open('x') as out, (output / 'dependency-clean.stderr').open('x') as err:
                build.run(['cargo', 'clean', '--offline', '--locked', '--profile', 'release', '-p', 'archery', '-p', 'rpds'], stdout=out, stderr=err)
            with (output / 'clippy.stdout').open('x') as out, (output / 'clippy.stderr').open('x') as err:
                build.run(['cargo', 'clippy', '--offline', '--locked', '--release', '--all-targets', '--all-features', '--', '-D', 'warnings'], stdout=out, stderr=err)
            for mode in ('timing', 'counting'):
                command = ['cargo', 'build', '--offline', '--locked', '--release', '--message-format', 'json-render-diagnostics']
                if mode == 'counting':
                    command += ['--features', 'allocation-counting']
                with (output / (mode + '.jsonl')).open('x') as out, (output / (mode + '.stderr')).open('x') as err:
                    build.run(command, stdout=out, stderr=err)
                build.check_artifacts(output / (mode + '.jsonl'))
                units = [json.loads(line) for line in (output / (mode + '.jsonl')).read_text().splitlines()]
                for name in ('archery', 'rpds'):
                    selected = [u for u in units if u.get('reason') == 'compiler-artifact' and u['target']['name'] == name]
                    assert len(selected) == 1
                    if mode == 'timing':
                        assert not selected[0]['fresh']
                    if name == 'archery':
                        assert (Q / (arm + '-archery')).as_uri() in selected[0]['package_id']
                binary = output / mode
                shutil.copyfile(R / 'target/release/kv9-static-callback-experiment', binary)
                binary.chmod(0o755)
                artifacts[mode] = {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size}
        assert all(sha(Path(path)) == digest for path, digest in identity.items())
        print(json.dumps({'arm': arm, 'artifacts': artifacts}), flush=True)
    assert registry(S / 'source-baseline/Cargo.lock') == registry(S / 'source-candidate/Cargo.lock')
    assert all(sha(Path(path)) == digest for path, digest in summary['sources'].items())
    summary['complete'] = True
except BaseException as error:
    summary['failure'] = repr(error)
    raise
finally:
    summary['ended_ns'] = time.time_ns()
    (S / 'build-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
