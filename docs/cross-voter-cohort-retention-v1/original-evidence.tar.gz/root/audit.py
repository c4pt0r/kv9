"""Independent final state/lifetime audit; preserved objects use their original size bounds."""
from pathlib import Path
import sys
import json
import hashlib
import time

P = Path('/tmp/kv9-cross-voter-cohort-migration-preparation-20260915-first')
ROOT = Path(__file__).resolve().parent
TX = Path('/tmp/kv9-cross-voter-directory-cohort-003-transaction-20260915-first')
sys.path.insert(0, str(P))
import support as q

selection = json.loads((P / 'selection.json').read_bytes())
cold_raw = (TX / 'retire-2/result.json').read_bytes()
cold_sha = hashlib.sha256(cold_raw).hexdigest()
assert cold_sha == '86cf7e724506dfd37996f025e612dca5ee76f1639a45fc38556a1b37726a8054'
cold = json.loads(cold_raw)
assert cold['complete'] and cold['state'] == 'COLD' and len(cold['rows']) == 80
q.preserved(selection)
q.no_codec_processes(selection)
q.no_references(selection)
members = q.members(selection)
targets = {row['target'] for row in selection['pairs']}
assert all(q.absent(Path(members[key]['path'])) for key in targets)
preserved = []
for key, member in members.items():
    if key in targets:
        continue
    path = Path(member['path'])
    before = q.identity(path)
    assert before == member['identity']
    assert before['bytes'] == member['compressed']['bytes'] <= 8 * 1024**3
    # The 128 MiB migration-output helper is inapplicable to larger preserved Raft objects.
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        while block := stream.read(1024**2):
            digest.update(block)
            count += len(block)
    assert q.identity(path) == before
    assert count == member['compressed']['bytes'] and digest.hexdigest() == member['compressed']['sha256']
    preserved.append(dict(id=key, bytes=count, sha256=digest.hexdigest()))
assert len(preserved) == 70
phases = {}
children = []
for name in ['staged.json', 'verification-first/result.json', 'restore-1/result.json', 'legacy-1/result.json', 'retire-1/result.json', 'retire-2/result.json']:
    data = (TX / name).read_bytes()
    result = json.loads(data)
    assert result['complete']
    phases[name] = hashlib.sha256(data).hexdigest()
    if name == 'staged.json':
        children += [child for row in result['rows'] for child in row['children']]
    else:
        children += result.get('children', result.get('decoder_receipts', []))
assert len(children) == 870
boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
lifetimes = []
for child in children:
    assert child['exit_code'] == 0 and (child.get('reaped') or child.get('absent'))
    proc = Path('/proc') / str(child['pid']) / 'stat'
    same = False
    try:
        data = proc.read_text()
        same = boot == child['boot_id'] and int(data[data.rfind(')') + 2:].split()[19]) == child['start_ticks']
    except FileNotFoundError:
        pass
    assert not same
    lifetimes.append(dict(pid=child['pid'], start_ticks=child['start_ticks'], boot_id=child['boot_id'], same_lifetime_present=same))
stage = json.loads((TX / 'staged.json').read_bytes())
decoded = q.charged_decoded(TX)
assert decoded == 12036960356
summary = dict(complete=True, state='COLD', selection_sha256=hashlib.sha256((P / 'selection.json').read_bytes()).hexdigest(),
    target_count=80, original_object_count=150, original_logical_bytes=4015670348, original_encoded_bytes=2838288732,
    patch_encoded_bytes=sum(row['patch']['pin']['bytes'] for row in stage['rows']), phases=phases,
    controls_passed=19, accounting=q.accounting(selection), charged_decoded_bytes=decoded, lifetimes=lifetimes,
    preserved_objects=preserved, all_870_codec_lifetimes_absent=True, original_metadata_unchanged=True,
    all_70_preserved_object_hashes_unchanged=True, retained_toolchain_verified_by_execution=True,
    unchanged_whole_cohort_reader_passed=True, restore_cycle_2_prepared_not_executed=True,
    new_database_benchmark_run=False, observed_ns=time.time_ns())
with (ROOT / 'accepted-summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
print(json.dumps({key: value for key, value in summary.items() if key not in ['lifetimes', 'phases', 'preserved_objects']}))
