"""Stage exactly eighty patches outside the immutable original cohort. No original removal."""
import sys,time
from support import *

def main():
 ap=args();a=ap.parse_args();s=load(a)
 if not Path(s['root']).exists():
  v=os.statvfs(Path(s['root']).parent);need(v.f_bavail*v.f_frsize>=12*GIB+16*MIB,'fresh 12 GiB + 16 MiB migration launch reservation')
 root,fd=lock(s,create=True);sess=session(root);mm=members(s)
 (root/'patches').mkdir(exist_ok=True);(root/'stage-records').mkdir(exist_ok=True)
 try:
  sess.guard(sum(p['patch_limit']for p in s['pairs']if not(root/'stage-records'/(p['id']+'.json')).exists()and not(root/'stage-records'/(p['id']+'.publish-intent.json')).exists())+384*MIB+24*MIB);retain_toolchain(s,root,a.selection_sha256);preserved(s);no_references(s)
  # First pass requires every exact original to remain resident, including resumed staging.
  for pair in s['pairs']:object_ok(mm[pair['target']]);object_ok(mm[pair['base']])
  rows=[]
  for pair in s['pairs']:
   rid=pair['id'];record=root/'stage-records'/(rid+'.json');intent=root/'stage-records'/(rid+'.publish-intent.json');dst=root/'patches'/(rid+'.zst')
   if record.exists():
    row=js(record);need(row['pair']==pair,'stage row differs');check_patch(root,row);rows.append(row);continue
   if intent.exists():
    ip=js(intent);pub=publish(Path(ip['source']),dst,intent,ip['pin']);row=dict(id=rid,pair=pair,patch=pub,recovered_publication=True)
    durable_json(record,row);rows.append(row);continue
   w=work(root,'stage',rid);base=mm[pair['base']];target=mm[pair['target']]
   raw_base=w/'base.raw';raw_target=w/'target.raw';patch=w/'patch.zst'
   object_ok(base);object_ok(target)
   run_stdin(sess,'base-'+rid,base['decode_argv'],base['path'],raw_base,base['original']['bytes'],True);check(raw_base,base['original'])
   run_stdin(sess,'target-'+rid,target['decode_argv'],target['path'],raw_target,target['original']['bytes'],True);check(raw_target,target['original'])
   flags=[s['codec']['path'],'-q','--no-progress','--single-thread','-3','--check','--zstd=wlog=26','--patch-from='+str(raw_base),'-c',str(raw_target)]
   sess.codec('patch-'+rid,flags,patch,pair['patch_limit']);pin=digest(patch)
   object_ok(base);object_ok(target);check(raw_base,base['original']);check(raw_target,target['original'])
   pub=publish(patch,dst,intent,pin);row=dict(id=rid,pair=pair,patch=pub,children=sess.records[-3:]);durable_json(record,row);rows.append(row)
   remove_verified_work(w,[(raw_base,base['original']),(raw_target,target['original'])])
  need(len(rows)==80 and len({r['id']for r in rows})==80,'complete exact stage')
  preserved(s);no_references(s)
  for pair in s['pairs']:object_ok(mm[pair['target']]);object_ok(mm[pair['base']])
  doc=dict(complete=True,state='STAGED',selection_sha256=a.selection_sha256,code_pins_sha256=a.code_pins_sha256,rows=rows,toolchain_sha256=digest(root/'toolchain.json')['sha256'],all_children_reaped=all(r['reaped']and r['exit_code']==0 for r in sess.records),accounting=accounting(s),resource=sess.guard(),ended_ns=time.time_ns(),independent_verified=False)
  result(root,'staged.json',doc);return 0
 except BaseException as exc:
  result(root,'stage-failure-'+str(time.time_ns())+'.json',dict(complete=False,error=repr(exc),children=sess.records,original_retirement_attempted=False));return 1
 finally:os.close(fd)
if __name__=='__main__':sys.exit(main())
