"""Root-run bounded Linux parent interruption control; Python children only, no codec."""
import ctypes,os,signal,subprocess,sys,tempfile,time,unittest
from pathlib import Path
import common

class ParentDeath(unittest.TestCase):
 def test_actual_parent_interruption_kills_and_reaps_child(self):
  libc=ctypes.CDLL(None,use_errno=True);self.assertEqual(libc.prctl(36,1,0,0,0),0) # PR_SET_CHILD_SUBREAPER for this test process only.
  parent=None;child=None;reaped=False
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent)as tmp:
   marker=Path(tmp)/'child.json'
   program="""import os,sys,time
from pathlib import Path
from common import parent_death_guard
parent=os.getpid();child=os.fork()
if child==0:
 parent_death_guard(parent)
 marker=Path(sys.argv[1]);tmp=marker.with_suffix('.pending');tmp.write_text(str(os.getpid()));os.replace(tmp,marker)
 time.sleep(20)
 os._exit(0)
time.sleep(20)
"""
   try:
    parent=subprocess.Popen([sys.executable,'-B','-c',program,str(marker)],cwd=Path(__file__).parent)
    deadline=time.monotonic()+5
    while not marker.exists()and time.monotonic()<deadline:time.sleep(.01)
    self.assertTrue(marker.exists());child=int(marker.read_text());parent.kill();parent.wait(timeout=5)
    deadline=time.monotonic()+5
    while time.monotonic()<deadline:
     found,status=os.waitpid(child,os.WNOHANG)
     if found:
      reaped=True;self.assertTrue(os.WIFSIGNALED(status));self.assertEqual(os.WTERMSIG(status),signal.SIGKILL);break
     time.sleep(.01)
    self.assertTrue(reaped,'orphan child did not terminate promptly')
   finally:
    if parent is not None and parent.poll()is None:parent.kill();parent.wait(timeout=5)
    if child is not None and not reaped:
     try:os.kill(child,signal.SIGKILL)
     except ProcessLookupError:pass
     try:os.waitpid(child,0)
     except ChildProcessError:pass
    libc.prctl(36,0,0,0,0)
if __name__=='__main__':unittest.main(verbosity=2)
