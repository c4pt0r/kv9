"""Fixed-cohort transaction support. No original mutation except explicit transition helpers."""
import argparse,ctypes,errno,fcntl,hashlib,importlib.util,json,os,stat,time
from pathlib import Path
from common import P,CPUS,MIB,GIB,Session,identity,digest,check,save

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def fsync_dir(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(fd)
 finally:os.close(fd)
def canonical_path(p):
 p=Path(p);need(p.is_absolute()and str(p)==os.path.normpath(str(p)),'noncanonical path')
 for parent in reversed([p,*p.parents]):
  if parent.exists()or parent.is_symlink():need(not parent.is_symlink(),'symlink ancestor')
 return p
def absent(p):return not p.exists()and not p.is_symlink()
def js(p):
 def pairs(rows):
  out={}
  for k,v in rows:need(k not in out,'duplicate JSON key');out[k]=v
  return out
 canonical_path(p);need(Path(p).stat().st_size<=16*MIB,'metadata size cap')
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs)
def durable_json(p,data):
 canonical_path(p);save(p,data);fsync_dir(Path(p).parent)
def module(name,p,pin):
 check(p,pin,'frozen helper changed');spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def args():
 a=argparse.ArgumentParser();a.add_argument('--selection-sha256',required=True);a.add_argument('--code-pins-sha256',required=True);a.add_argument('--retained-toolchain-sha256')
 return a
def load(a):
 need(os.geteuid()==0 and set(os.sched_getaffinity(0))==CPUS,'root/exact helper CPU placement required')
 need(digest(P/'selection.json')['sha256']==a.selection_sha256,'selection changed');need(digest(P/'code-pins.json')['sha256']==a.code_pins_sha256,'code manifest changed')
 for name,pin in js(P/'code-pins.json').items():check(P/name,pin,'code changed')
 s=js(P/'selection.json');need(s['target_count']==80 and s['original_object_count']==150,'exact cohort scope')
 canonical_path(s['root']);canonical_path(s['fixture'])
 for row in s['metadata']+s['authorities']:check(row['path'],row,'original metadata changed')
 for row in s['exact_object_qualification']:
  need(digest(row['path'])['sha256']==row['sha256'],'exact-object prerequisite changed');need(js(row['path'])['complete'],'exact-object prerequisite incomplete')
 if a.retained_toolchain_sha256:
  tp=Path(s['root'])/'toolchain.json';need(digest(tp)['sha256']==a.retained_toolchain_sha256,'retained toolchain manifest changed');toolchain=js(tp)
  need(toolchain['complete']and toolchain['selection_sha256']==a.selection_sha256,'retained toolchain binding')
  for row in toolchain['files']:check(row['path'],row['pin'],'retained codec dependency changed');need(identity(row['path'])==row['identity'],'retained codec dependency identity changed')
  byname={r['name']:r for r in toolchain['files']};need(set(byname)=={r['name']for r in s['retained_codec_dependencies']},'retained toolchain exact dependency set')
  need(byname['zstd']['pin']['sha256']==s['codec']['sha256'],'retained encoder pin')
  s['_codec_prefix']=[byname['ld-linux-x86-64.so.2']['path'],'--library-path',str(Path(s['root'])/'toolchain'),byname['zstd']['path']]
  s['_codec_identities']=[byname[k]['identity']for k in ['ld-linux-x86-64.so.2','zstd']]
 else:
  check(s['codec']['path'],s['codec'],'codec changed');need(identity(s['codec']['path'])==s['codec']['identity'],'codec identity changed')
 no_codec_processes(s)
 return s

def no_codec_processes(s):
 expected={(x['device'],x['inode'])for x in s.get('_codec_identities',[s['codec']['identity']])};hits=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   st=(p/'exe').stat()
   if (st.st_dev,st.st_ino)in expected:hits.append(int(p.name))
  except (FileNotFoundError,ProcessLookupError):pass
 need(not hits,'codec already active; preserve pending child receipts and obtain root-owned shutdown before resuming')

def phase_directory(root,name):
 p=canonical_path(root/name);p.mkdir(exist_ok=True);fsync_dir(root);return p

def lock(s,create=False):
 root=Path(s['root']);canonical_path(root)
 if create and not root.exists():root.mkdir(mode=0o700);fsync_dir(root.parent)
 need(root.is_dir()and not root.is_symlink(),'transaction root absent/type')
 fd=os.open(root/'transaction.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 return root,fd

def charged_decoded(root):
 decoded=0;count=0
 for path in root.rglob('*.child-intent.json'):
  count+=1;need(count<=5000,'codec intent count cap');r=js(path)
  final=path.with_name(path.name.replace('.child-intent.json','.child.json'))
  if r.get('decoded'):
   decoded+=js(final).get('output_bytes',0)if final.exists()else r['reserved_decoded_bytes']
 for path in root.glob('legacy-*/decode-reservation.json'):
  decoded+=js(path)['charged_decoded_bytes']
 for path in root.glob('work/*/*.raw'):
  if not path.with_name(path.name+'.child-intent.json').exists():decoded+=identity(path)['bytes']
 need(decoded<=32*GIB,'cumulative decoded byte cap')
 return decoded

def session(root):
 # Every completed/failed output remains charged across resumptions, not per member.
 decoded=charged_decoded(root)
 sess=Session(root,dict(device=root.stat().st_dev,started_monotonic_ns=time.monotonic_ns()),decoded)
 sess.external_allocation_reserve=js(P/'selection.json')['limits']['external_restored_target_allowance_bytes']
 return sess
def members(s):return {r['id']:r for r in s['members']}
def object_ok(m,expected_identity=None):
 p=canonical_path(m['path']);expected=expected_identity or m['identity']
 need(identity(p)==expected,'original/base object identity changed');check(p,m['compressed'],'original/base object digest changed')
 return expected

def preserved(s,hash_all=False):
 target={r['target']for r in s['pairs']}
 for m in s['members']:
  if m['id']not in target:
   need(identity(canonical_path(m['path']))==m['identity'],'preserved non-target identity changed')
   if hash_all:check(m['path'],m['compressed'],'preserved object changed')
 for row in s['metadata']:check(row['path'],row,'original catalog/report changed')
def no_references(s):
 # Unchanged qualified root-only FD/maps/subtree reader; no file descriptors remain open on the cohort.
 m=module('original_reference_reader',s['legacy_producer']['path'],s['legacy_producer'])
 return m.no_references(Path(s['cohort']))

def run_stdin(sess,label,argv,source,out,limit,decoded=False):
 before=identity(source);fd=os.open(source,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  st=os.fstat(fd);need((st.st_dev,st.st_ino)==(before['device'],before['inode']),'stdin source replaced')
  r=sess.codec(label,argv,out,limit,decoded=decoded,stdin_fd=fd)
  need(os.lseek(fd,0,os.SEEK_CUR)==before['bytes'],'stdin not fully consumed')
 finally:os.close(fd)
 need(identity(source)==before,'stdin source changed');return r

def rename_no_replace(src,dst):
 canonical_path(src);canonical_path(dst)
 libc=ctypes.CDLL(None,use_errno=True);fn=libc.renameat2;fn.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];fn.restype=ctypes.c_int
 if fn(-100,os.fsencode(src),-100,os.fsencode(dst),1)!=0:raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
 fsync_dir(Path(src).parent);fsync_dir(Path(dst).parent)

def publish(src,dst,intent,pin):
 src=canonical_path(src);dst=canonical_path(dst);intent=Path(intent)
 if absent(intent):
  need(absent(dst),'destination collision');check(src,pin,'publication source differs')
  durable_json(intent,dict(source=str(src),destination=str(dst),identity=identity(src),pin=pin))
 row=js(intent);need(row['source']==str(src)and row['destination']==str(dst)and row['pin']==pin,'publication intent conflict')
 if not absent(dst):
  need(absent(src),'publication collision');need({k:v for k,v in identity(dst).items()if k!='ctime_ns'}=={k:v for k,v in row['identity'].items()if k!='ctime_ns'},'published identity changed');check(dst,pin,'published content changed');fsync_dir(dst.parent)
 else:
  need(identity(src)==row['identity'],'publication source identity changed');check(src,pin,'publication source changed');rename_no_replace(src,dst)
 return dict(path=str(dst),pin=pin,identity=identity(dst))

def retire_one(path,intent,expected,pin,authority):
 path=canonical_path(path);intent=Path(intent)
 if absent(intent):
  need(identity(path)==expected,'retirement identity changed');check(path,pin,'retirement source changed')
  durable_json(intent,dict(path=str(path),identity=expected,pin=pin,authority=authority))
 row=js(intent);need(row==dict(path=str(path),identity=expected,pin=pin,authority=authority),'retirement intent conflict')
 if not absent(path):
  need(identity(path)==expected,'retirement path replaced');check(path,pin,'retirement bytes changed');path.unlink();fsync_dir(path.parent)
 else:fsync_dir(path.parent)
 return dict(path=str(path),absent=True,authorized_intent=str(intent))

def work(root,phase,member):
 base=canonical_path(root/'work');base.mkdir(exist_ok=True);fsync_dir(root)
 for attempt in range(3):
  p=base/f'{phase}-{member}-{attempt}'
  if absent(p):p.mkdir(mode=0o700);fsync_dir(base);return p
 raise RuntimeError('three-attempt member bound; preserve partial outputs for review')
def remove_verified_work(workdir,rows):
 # Only exact successfully verified scratch payloads; original/patch/manifest files are never passed here.
 for p,pin in rows:
  p=Path(p);need(p.parent==workdir,'scratch deletion scope');check(p,pin,'scratch changed');p.unlink();fsync_dir(workdir)

def check_patch(root,row):
 p=root/'patches'/(row['id']+'.zst');need(identity(p)==row['patch']['identity'],'patch identity changed');check(p,row['patch']['pin'],'patch changed');return p

def result(root,name,data):
 p=root/name;durable_json(p,data);print(json.dumps(dict(complete=data['complete'],result=str(p),result_sha256=digest(p)['sha256'])));return p

def accounting(s):
 from common import allocated
 root=Path(s['root']);now=sum(identity(m['path'])['allocated_bytes']for m in s['members']if m['id']in{r['target']for r in s['pairs']}and not absent(Path(m['path'])))
 added=allocated(root);gross=s['target_allocated_bytes']-now
 return dict(original_target_allocated_bytes=s['target_allocated_bytes'],current_target_allocated_bytes=now,transaction_allocated_bytes=added,gross_target_decrease_bytes=gross,conservative_net_allocated_change_bytes=gross-added,available_bytes=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize,scope='All transaction files/directories including patches, scratch and receipts are charged; original free-space movement is separately observed, not attributed exclusively.')


def codec_argv(s,argv):
 need(argv[0]==s['codec']['path'],'codec recipe executable differs')
 return s.get('_codec_prefix',[argv[0]])+argv[1:]

def retain_toolchain(s,root,selection_sha):
 folder=canonical_path(root/'toolchain');folder.mkdir(exist_ok=True);fsync_dir(root)
 manifest=root/'toolchain.json'
 if manifest.exists():
  t=js(manifest);need(t['selection_sha256']==selection_sha,'toolchain selection differs')
  for row in t['files']:check(row['path'],row['pin']);need(identity(row['path'])==row['identity'],'retained toolchain changed')
  return
 rows=[]
 for source in s['retained_codec_dependencies']:
  need(identity(source['path'])==source['identity'],'source codec dependency changed');pin=digest(source['path'],8*MIB)
  dst=folder/source['name']
  if absent(dst):
   with open(source['path'],'rb')as src,dst.open('xb')as out:
    while b:=src.read(MIB):out.write(b)
    out.flush();os.fsync(out.fileno())
   os.chmod(dst,stat.S_IMODE(source['identity']['mode']))
  check(dst,pin,'partial/colliding retained tool copy differs')
  df=os.open(dst,os.O_RDONLY|os.O_NOFOLLOW)
  try:os.fsync(df)
  finally:os.close(df)
  fsync_dir(folder)
  need(identity(source['path'])==source['identity'],'codec dependency changed during copy')
  rows.append(dict(name=source['name'],path=str(dst),source=source,pin=pin,identity=identity(dst)))
 need(sum(r['pin']['bytes']for r in rows)<=8*MIB,'toolchain cap')
 durable_json(manifest,dict(complete=True,selection_sha256=selection_sha,files=rows,scope='Verified retained exact encoder/loader/library bytes; current legacy acceptance still uses original system executable.'))


def retained_toolchain_ok(s,root,expected_sha):
 path=root/'toolchain.json';need(digest(path)['sha256']==expected_sha,'durable retained toolchain manifest changed')
 t=js(path);need(t['complete']and len(t['files'])==len(s['retained_codec_dependencies']),'retained toolchain incomplete')
 need({r['name']for r in t['files']}=={r['name']for r in s['retained_codec_dependencies']},'retained dependency names differ')
 for row in t['files']:
  need(Path(row['path'])==root/'toolchain'/row['name'],'retained toolchain path differs');check(row['path'],row['pin']);need(identity(row['path'])==row['identity'],'retained dependency changed')
 need(next(r['pin']['sha256']for r in t['files']if r['name']=='zstd')==s['codec']['sha256'],'retained encoder changed')
