"""Independent patch -> original WAL -> exact original encoded-byte validation. No producer import."""
import sys,time
from support import *

def reconstruct(sess,s,pair,row,w):
 mm=members(s);base=mm[pair['base']];target=mm[pair['target']];patch=check_patch(Path(s['root']),row)
 object_ok(base);base_raw=w/'base.raw';target_raw=w/'target.raw';encoded=w/'original.zst'
 run_stdin(sess,'independent-base-'+pair['id'],codec_argv(s,base['decode_argv']),base['path'],base_raw,base['original']['bytes'],True);check(base_raw,base['original'],'decoded base SHA/size differs')
 sess.codec('independent-patch-'+pair['id'],codec_argv(s,[s['codec']['path'],'-q','-d','--single-thread','--memory=512MiB','--patch-from='+str(base_raw),'-c',str(patch)]),target_raw,target['original']['bytes'],decoded=True)
 check(target_raw,target['original'],'decoded target original WAL SHA/size differs')
 run_stdin(sess,'original-encode-'+pair['id'],codec_argv(s,target['encode_argv']),target_raw,encoded,min(128*MIB,target['original']['bytes']+MIB))
 check(encoded,target['compressed'],'re-encoded original compressed SHA/size differs')
 object_ok(base);check_patch(Path(s['root']),row);check(base_raw,base['original']);check(target_raw,target['original'])
 return encoded,[(base_raw,base['original']),(target_raw,target['original'])]

def main():
 ap=args();ap.add_argument('--staged-sha256',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();s=load(a);root,fd=lock(s);sess=session(root)
 out=canonical_path(a.output);need(out.parent==root and absent(out),'fresh direct transaction verification output required');out.mkdir(mode=0o700)
 try:
  need(digest(root/'staged.json')['sha256']==a.staged_sha256,'staged pin');stage=js(root/'staged.json')
  need(stage['complete']and stage['selection_sha256']==a.selection_sha256 and stage['code_pins_sha256']==a.code_pins_sha256 and stage['all_children_reaped'],'stage incomplete/binding')
  rows={r['id']:r for r in stage['rows']};need(len(rows)==len(stage['rows'])==80 and set(rows)=={p['id']for p in s['pairs']},'exact complete patch inventory')
  retained_toolchain_ok(s,root,stage['toolchain_sha256']);preserved(s);no_references(s);verified=[]
  for pair in s['pairs']:
   w=work(root,'verify',pair['id']);encoded,scratch=reconstruct(sess,s,pair,rows[pair['id']],w)
   verified.append(dict(id=pair['id'],base=pair['base'],patch=rows[pair['id']]['patch'],original=members(s)[pair['target']]['original'],compressed=members(s)[pair['target']]['compressed'],decoded_to_eof=True,original_compressed_exact=True))
   durable_json(out/(pair['id']+'.json'),verified[-1]);remove_verified_work(w,scratch+[(encoded,members(s)[pair['target']]['compressed'])])
  preserved(s);no_references(s)
  result(out,'result.json',dict(complete=True,state='VERIFIED',selection_sha256=a.selection_sha256,code_pins_sha256=a.code_pins_sha256,staged_sha256=a.staged_sha256,toolchain_sha256=stage['toolchain_sha256'],rows=verified,children=sess.records,all_children_reaped=all(r['reaped']and r['exit_code']==0 for r in sess.records),resource=sess.guard(),accounting=accounting(s),scope='Independent full raw and exact encoded reconstruction for all eighty target members; no original removed.'))
  return 0
 except BaseException as exc:result(out,'result.json',dict(complete=False,error=repr(exc),children=sess.records));return 1
 finally:os.close(fd)
if __name__=='__main__':sys.exit(main())
