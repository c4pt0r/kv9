"""Tiny local source/transaction controls only; no codec, cluster, benchmark or original object access."""
import ast,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import support as s

class Transitions(unittest.TestCase):
 def setUp(self):
  parent=s.P/'synthetic-controls';parent.mkdir(exist_ok=True);self.t=tempfile.TemporaryDirectory(dir=parent);self.r=Path(self.t.name)
 def tearDown(self):self.t.cleanup()
 def file(self,name,b=b'bounded original bytes'):
  p=self.r/name;p.write_bytes(b);return p
 def test_exact_hash_positive_and_corruption_refused(self):
  p=self.file('p');pin=s.digest(p);s.check(p,pin);p.write_bytes(b'corrupt')
  with self.assertRaises(RuntimeError):s.check(p,pin)
 def test_changed_base_identity_refused(self):
  p=self.file('base');m=dict(path=str(p),identity=s.identity(p),compressed=s.digest(p));p.write_bytes(b'changed')
  with self.assertRaises(RuntimeError):s.object_ok(m)
 def test_changed_patch_refused(self):
  (self.r/'patches').mkdir();p=self.file('patches/000001.zst');row=dict(id='000001',patch=dict(identity=s.identity(p),pin=s.digest(p)));p.write_bytes(b'wrong')
  with self.assertRaises(RuntimeError):s.check_patch(self.r,row)
 def test_destination_collision_preserved(self):
  src=self.file('src');dst=self.file('dst',b'existing');before=dst.read_bytes()
  with self.assertRaises(RuntimeError):s.publish(src,dst,self.r/'intent',s.digest(src))
  self.assertEqual(dst.read_bytes(),before);self.assertTrue(src.exists())
 def test_symlink_ancestor_refused(self):
  d=self.r/'dir';d.mkdir();(self.r/'link').symlink_to(d,target_is_directory=True)
  with self.assertRaises(RuntimeError):s.canonical_path(self.r/'link'/'file')
 def test_interrupted_before_publication_resumes(self):
  src=self.file('src');dst=self.r/'dst';intent=self.r/'intent';pin=s.digest(src)
  with patch.object(s,'rename_no_replace',side_effect=InterruptedError('before publication')):
   with self.assertRaises(InterruptedError):s.publish(src,dst,intent,pin)
  self.assertTrue(src.exists());self.assertFalse(dst.exists());s.publish(src,dst,intent,pin);s.check(dst,pin)
 def test_interrupted_after_rename_before_receipt_resumes_ctime_honestly(self):
  src=self.file('src');dst=self.r/'dst';intent=self.r/'intent';pin=s.digest(src);before=s.identity(src);rename=s.rename_no_replace
  def interrupted(a,b):rename(a,b);raise InterruptedError('after rename before caller receipt')
  with patch.object(s,'rename_no_replace',side_effect=interrupted):
   with self.assertRaises(InterruptedError):s.publish(src,dst,intent,pin)
  result=s.publish(src,dst,intent,pin);self.assertEqual(result['identity'],s.identity(dst));self.assertEqual(result['identity']['inode'],before['inode']);self.assertFalse(src.exists())
 def test_changed_publication_source_after_intent_refused(self):
  src=self.file('src');dst=self.r/'dst';intent=self.r/'intent';pin=s.digest(src)
  with patch.object(s,'rename_no_replace',side_effect=InterruptedError()):
   with self.assertRaises(InterruptedError):s.publish(src,dst,intent,pin)
  src.write_bytes(b'changed')
  with self.assertRaises(RuntimeError):s.publish(src,dst,intent,pin)
  self.assertFalse(dst.exists())
 def test_interrupted_removal_resumes_only_same_release(self):
  original=self.file('original');intent=self.r/'intent';meta=s.identity(original);pin=s.digest(original);authority=dict(verified='a'*64);fsync=s.fsync_dir
  def interrupted(p):
   fsync(p)
   if not original.exists():raise InterruptedError('unlink durable intent already exists')
  with patch.object(s,'fsync_dir',side_effect=interrupted):
   with self.assertRaises(InterruptedError):s.retire_one(original,intent,meta,pin,authority)
  self.assertTrue(intent.exists());self.assertFalse(original.exists());s.retire_one(original,intent,meta,pin,authority)
  with self.assertRaises(RuntimeError):s.retire_one(original,intent,meta,pin,dict(verified='b'*64))
 def test_missing_original_without_intent_refused(self):
  original=self.file('original');meta=s.identity(original);pin=s.digest(original);original.unlink()
  with self.assertRaises(FileNotFoundError):s.retire_one(original,self.r/'intent',meta,pin,{})
 def test_changed_retirement_original_refused(self):
  p=self.file('original');meta=s.identity(p);pin=s.digest(p);p.write_bytes(b'changed')
  with self.assertRaises(RuntimeError):s.retire_one(p,self.r/'intent',meta,pin,{})
  self.assertTrue(p.exists());self.assertFalse((self.r/'intent').exists())
 def test_phase_parent_fsync_precedes_mutation(self):
  seen=[]
  with patch.object(s,'fsync_dir',side_effect=lambda p:seen.append(p)):
   phase=s.phase_directory(self.r,'retire-1')
  self.assertEqual(seen,[self.r]);self.assertTrue(phase.is_dir())
  source=(s.P/'transition.py').read_text();self.assertLess(source.index('phase=phase_directory'),source.index('retire_one('))
 def test_restore_collision_cannot_overwrite(self):
  reconstructed=self.file('reconstructed');original=self.file('original',b'different original');pin=s.digest(reconstructed)
  with self.assertRaises(RuntimeError):s.publish(reconstructed,original,self.r/'restore-intent',pin)
  self.assertEqual(original.read_bytes(),b'different original')
 def test_second_cold_and_second_restore_source_gates_remain(self):
  source=(s.P/'transition.py').read_text();ast.parse(source)
  for clause in ['a.restore_result_sha256 and a.legacy_result_sha256',"legacy['unchanged_reader']==s['legacy_reader']","retired=root/('retire-'+str(a.cycle))","a.cycle in (1,2)"]:
   self.assertIn(clause,source)
  self.assertIn("all_children_reaped",source)
 def test_legacy_full_reservation_precedes_unchanged_reader(self):
  source=(s.P/'legacy.py').read_text();self.assertLess(source.index("durable_json(dest/'decode-reservation.json'"),source.index('observed=reader.verify('))
  self.assertIn("charged=s['logical_cohort_bytes']",source);self.assertIn("reader.verify(Path(s['fixture']),original_children,records,logical,decoders)",source)
 def test_constant_external_restore_allowance_is_in_actual_guard(self):
  source=(s.P/'common.py').read_text();self.assertIn('used+reserve+self.external_allocation_reserve>4*GIB',source)
  selection=s.js(s.P/'selection.json');need=selection['limits']['external_restored_target_allowance_bytes'];self.assertGreater(need,selection['target_allocated_bytes'])
if __name__=='__main__':unittest.main(verbosity=2)
