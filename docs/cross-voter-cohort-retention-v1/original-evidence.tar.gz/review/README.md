# Independent cohort migration review

No remaining transaction blocker was found in the reviewed source after five corrections. This is a read-only code review; controls and actual migration acceptance remain pending root execution.

The review is limited to one cohort, 80 eligible target objects and 150 original objects. No original payload was opened, changed, restored or retired by this reviewer.

| Finding | Reviewed correction |
| --- | --- |
| Rename ctime prevented publication resume | Compare invariant inode metadata and complete bytes; retain observed post-rename identity. |
| New directory entries were not durably published before mutation | Fsync root after phase/work creation, before intents or unlink. |
| COLD-2 lacked a later restore path | Separate bounded restore-2 and receipts; no third retirement. |
| Parent death before codec exec/final receipt | Parent-death SIGKILL with parent recheck, durable prelaunch reservation, conservative missing-receipt charging. |
| Second-COLD control was source-text-only | Behavioral checks of the actual receipt gate reject incomplete, absent or mismatched authority. |

The reviewed path publishes and independently verifies patches before original retirement. Per-file retirement intent binds the selected source identity, original compressed SHA/size and explicit verified release. Replaying an interrupted removal requires the same intent authority. Restoration uses no-replace publication, retains collision evidence, verifies exact original compressed bytes and records new inode/ctime honestly. A second COLD transition requires actual completed restore and unchanged whole-cohort reader results bound by explicit hashes.

Prepared controls exercise actual helper interruption before/after rename and after unlink, content/base/patch corruption, path collisions, stale retirement authority and missing originals. Additional controls cover decoded-byte reservations and Linux parent-death behavior with Python children only. They were read, not executed here.

A small control-only PID marker publication race was sent to the owner before freeze. It must not be mistaken for a transaction failure. See result-first.json for exact reviewed hashes, function line references, findings and limitations. Earlier source snapshots and findings remain retained.

Interrupted attempts without final receipts are not retroactively successful. Source fsync ordering is not a power-loss test. Root independently owns capacity/authority review and all executable gates.
