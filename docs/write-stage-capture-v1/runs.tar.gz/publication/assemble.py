from pathlib import Path
import json,hashlib,tarfile,io,shutil
ROOT=Path('/mnt/data/kv9-work')
OUT=ROOT/'write-stage-capture-publication-20260915-first'
PACK=OUT/'packet';PACK.mkdir(exist_ok=False)
rows={};excluded=[]
for prefix,name in [('preparation','write-stage-capture-preparation-20260915-first'),('execution','write-stage-capture-execution-20260915-first'),('runtime','write-stage-capture-20260915-first'),('independent','write-stage-capture-independent-20260915-first'),('correction','write-stage-export-contention-development-20260915-first')]:
 root=ROOT/name
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(root)
  if prefix=='runtime' and len(relative.parts)>4 and relative.parts[0]=='cohorts' and relative.parts[2:4]==('fixture','data'):
   excluded.append(dict(path=str(p),bytes=p.stat().st_size,reason='Retained database payload; original copy/readback receipts remain included.'));continue
  assert not p.is_symlink(),str(p)
  assert p.stat().st_size<=32*1024**2,(str(p),p.stat().st_size)
  rows[f'{prefix}/{relative}']=p
for name in ['crates/raft/src/write_stage_trace.rs','crates/raft/src/driver.rs','scripts/write_stage_capture.py','scripts/capture-write-stage-trace.py','scripts/check-write-stage-capture-controls.py']:
 rows[f'correction-source/{name}']=Path('/home/dongxu/kv9')/name
rows['publication/assemble.py']=Path(__file__)
entries=[];archive=PACK/'runs.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(rows.items()):
  data=p.read_bytes();member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data));entries.append(dict(member=name,source=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
inventory=dict(archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),members=entries,excluded_payloads=excluded,logical_bytes=sum(x['bytes'] for x in entries),excluded_payload_bytes=sum(x['bytes'] for x in excluded))
(PACK/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(entries)
 for m,e in zip(members,entries):
  assert m.name==e['member'] and m.isfile();data=tar.extractfile(m).read();assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'] and data==Path(e['source']).read_bytes()
for source,dest in [('metadata.tar.gz','release-metadata.tar.gz'),('metadata-inventory.json','release-metadata-inventory.json'),('independent-readback.json','release-readback.json')]:
 p=ROOT/'write-stage-release-root-20260915-first'/source;shutil.copyfile(p,PACK/dest);assert p.read_bytes()==(PACK/dest).read_bytes()
release=json.loads((PACK/'release-metadata-inventory.json').read_text());assert hashlib.sha256((PACK/'release-metadata.tar.gz').read_bytes()).hexdigest()==release['archive_sha256']
with tarfile.open(PACK/'release-metadata.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(release['members'])
 for m,e in zip(members,release['members']):
  data=tar.extractfile(m).read();assert m.name==e['name'] and len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
result=dict(status='PASS',scope='Full member decode/hash/original-byte check; release archive member hashes rechecked. Not another workload, database payload read or proof execution.',run_members=len(entries),run_logical_bytes=inventory['logical_bytes'],run_archive_sha256=inventory['archive']['sha256'],run_archive_bytes=archive.stat().st_size,release_members=len(release['members']),excluded_payload_bytes=inventory['excluded_payload_bytes'])
(PACK/'readback.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
