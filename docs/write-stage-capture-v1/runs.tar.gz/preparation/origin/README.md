# Upper-bound schema-2 observer capture preparation

This is a separate 16-row, two-second observer diagnostic for exact source
`e2e23cca5e70a9ea0cc241877b3b35b5b6433d27`. It compares that source's retained
default and diagnostic-feature releases, using the unchanged native v3 client.
It does not compare the candidate against CRC, replace the original 8-smoke /
16-ten-second performance screen, or authorize promotion.

`role-pins.json` binds the actual release manifests and readbacks. The default
server SHA is `6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49`;
the diagnostic server SHA is
`dbfb271302cc079c5fdd249a4c011a28aa759f4ad036b5e3707d446e078bc2e5`.
The fixed `0be806d` client SHA remains
`8da9af469f962a938027d1970141bbe4622f7d42b2b795f720e288fb3f8d5957`.

Requested current-role qualification passed **a2dd86/0** using only the
existing `server_binding()` / `source_binding()` readers. Both current build
layouts and exact feature graphs were accepted; all 1,116 source files per
server and 581 fixed-client files, retained binaries and compiler identities
matched. `role-readback-first/result.json` preserves the actual result. No
fixture, build, workload, codec or previously passed control was run.

## Exact inherited behavior and finite integration

`origin/portable-archive.json` is the published original observer archive index.
The original full runner, accepted continuation, their controls, failed
metadata attempts and actual successful continuation receipts are preserved
under `origin/`. No old row or source result is reused as a new measurement.

The first original full-campaign runner supplies a fresh observed space
baseline and executes every ordinal 0–15. Its obsolete all-phase single-attempt
predicate is replaced with the accepted continuation's **byte-identical**
`health()` function: only typed `not_leader` discovery retries for initialization
batch reads are allowed. Initialization writes and all warmup, measurement and
verification operations remain successful and single-attempt. All outcomes and
attempts remain present. Root reviewed this necessary integration at d8ac0e/0.

Every other capture function, the inherited native trial/cleanup/retention
driver and isolation wrapper are unchanged. The metadata freezer only replaces
old continuation row-zero/baseline authority with all 16 fresh directories and
the new actual plan baseline. `diffs/` and `source-delta.json` show these changes.
There is no new measurement predicate or control framework.

The matrix remains Put / BatchPut64, c1/c64, default/diagnostic modes, two
complete opposite orders, 2,000 ms per row, 4096 keys, 128-byte values, seed 71,
128 warmup calls and three voters. Quorum, synchronization, application/reply,
fresh drains, deterministic dataset, PID/start/boot, CPU isolation, exact
retention copying/readback and isolator restoration checks remain intact.

## Commands and remaining launch dependency

`ROOT-COMMANDS.json` contains the exact serial arrays. Root first reviews frozen
pins and fresh capacity, then executes `capture` once. It writes the original
actual `runtime-tool-terminal.json` and `launch-child-terminal.json` under this
preparation only after those real commands exit. Only complete outer capture,
all 16 rows and exact restoration permit `freeze_completed`.

The freezer emits `analysis-inputs.json`, `analysis-manifest.json` and
`completed-capture.json`; no hypothetical successful output exists here.
Root replaces `ACTUAL_COMPLETED_MANIFEST_SHA256` in `offline_schema2` with the
actual emitted hash. `check.py` is byte-identical to the already qualified
schema-2 checker (SHA `acfbf3217583f363a7241cfe91b78095a7c7bbab8dd9902051c211dd82419d2a`).
Its eleven synthetic controls remain historical acceptance, not new live data.
The manifest format stays schema 1; the embedded driver observations must be
schema 2 with `upper_bound_then_first_match_linear_scan`, 18 driver and three
Ready distributions. Default snapshots must omit the diagnostic line.

Initial host capacity must be **25,778,192,384 B**: 8 GiB continuous floor plus
the 16 GiB maximum campaign decrease and 8 MiB launch envelope. Tmpfs remains
32 GiB before / 16 GiB during a row. Each row may retain at most 3 GiB of
uncompressed payload; actual full copy/readback precedes scratch removal.
`capacity.json` records a historical preparation snapshot and its positive
shortfall; it is not a reservation. Root owns the separate small capacity
tranche and fresh launch observation. No storage threshold is weakened here.

The earlier accepted observer retained 13,015,897,757 logical payload bytes
(largest row 2,129,897,405 B), with a 13,159,960,576 B observed free-space decline.
That decline includes metadata and possible host activity; it is not an exact
physical payload census or guaranteed upper bound for this candidate. New
output can still hit the unchanged per-row or campaign caps and must remain a
visible failure if it does.

Counter snapshots cover the whole capture interval, including the setup,
warmup, completion/drain and dataset work falling between their boundaries.
They do not isolate the nominal two-second interval, exclusive CPU/service
time, continuous leadership or per-call causality. Skipped ring lengths are
counted observations, not predicted speedup. Root owns separate reporting.

Preparation is bounded to 16 MiB. No repository, candidate, old helper, report,
payload or accepted failure has been modified. Runtime readiness remains false.
