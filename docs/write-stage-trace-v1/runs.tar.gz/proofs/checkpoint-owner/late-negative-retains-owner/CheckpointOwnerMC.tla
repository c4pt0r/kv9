---------------- MODULE CheckpointOwnerMC ----------------
EXTENDS CheckpointOwner
CNoAppliedNegativeClear == \A o \in cCleared :
    ~(o \in cNegative /\ o \in cEffects /\ cPending[o] = 2 /\ cVersion[o] = 0)
=========================================================
