# Independent write-stage trace reader qualification

The two new scripts are `scripts/check-write-stage-trace.py` and
`scripts/check-write-stage-trace-controls.py`. They read no database payload,
run no workload/build/codec and never inspect or change a live process.

Use the reader with two retained raw local status files, not the JSON status
maps used by earlier diagnostics:

```
env PYTHONOPTIMIZE=0 PYTHONDONTWRITEBYTECODE=1 taskset -c 6-15,22-31 \
  python3 -B scripts/check-write-stage-trace.py \
  --before /absolute/retained-before-status.txt \
  --after /absolute/retained-after-status.txt \
  --output /mnt/data/kv9-work/fresh-trace-result.json
```

Each status is bounded to 2 MiB and its trace JSON to 384 KiB. Only PID,
node ID, root digest, store incarnation, boot ID, process start ticks and trace
instance are exported with trace records. Other status values never appear in
the result or refusal messages. Exact input lengths/SHA and reader SHA are
recorded. Output must be absent; malformed input creates a separate failed
result rather than an accepted analysis.

The reader implements the final `trace_instance`, `locks_acquired_ns`,
`receipts_inserted_ns`, `capture_started_ns` and `capture_finished_ns` schema.
It requires unchanged process/store/trace identity and temporally ordered
snapshots. It checks exact keys/types, unsigned bounds (booleans are not
integers), ring capacity/sample rule, chronological fields, counter deltas,
sequence/overwrite accounting and unchanged overlapping rows.

Busy/invalid snapshots and any recorded lost call refuse accepted analysis.
Wrap is allowed: each ring reports historic overwrites, new rows missing
between snapshots, and retained union coverage. Wrap does not imply those
missing rows were examined. Joins use exact term/index within this driver
lifetime; unmatched, multiple and temporally incompatible pairs are explicit.
Only unique compatible successful-receipt pairs receive interval arithmetic.
The result always says `complete_history: false` and `causality_proven: false`.
Group-sequence deduplication, deterministic sample bias, insertion under locks,
excluded cancellation/deadline/stop/synchronous terminals, and missing
proposal/RPC/client intervals remain stated limitations.

Actual synthetic controls: 16 passed `3d4da4/0`. Parent review identified the
Python JSON parser's separate oversized-integer ValueError. The final reader
normalizes it to a retained refusal; one new 5,000-digit integer API+CLI control
passed `4f2ef8/0`. The prior 16 controls were not replayed. Both original and
final helper bytes and exact diffs are preserved here. No live trace has been
read or accepted by this qualification.

The source-format review binds final Rust and status exporters in
`qualification.json`. The trace's process-local instance counter is nonzero
and unique until exhaustion; zero/invalid refuses. `runtime.rs` supplies
identity labels; `common/root.rs` prints fixed lowercase root/store hex;
`observability.rs` prints decimal ticks and normalized boot UUID (or an
explicit unavailable value, which this reader refuses).
