from pathlib import Path
import hashlib, io, json, shutil, tarfile
ROOT = Path('/mnt/data/kv9-work')
OUT = ROOT / 'write-stage-trace-publication-20260915-first'
PACKET = OUT / 'packet'
PACKET.mkdir(exist_ok=False)
members = {}
for stage in ['first', 'second', 'third']:
    root = ROOT / f'write-stage-trace-development-20260915-{stage}'
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.name.startswith('issue9-'):
            continue
        members[f'development/{stage}/{p.relative_to(root)}'] = p
for prefix, root in [
    ('proofs', ROOT / 'write-stage-trace-proof-compositions-20260915-first'),
    ('reader-controls', ROOT / 'write-stage-trace-reader-controls-20260915-first'),
]:
    for p in sorted(root.rglob('*')):
        if p.is_file():
            members[f'{prefix}/{p.relative_to(root)}'] = p
pins = json.loads((ROOT / 'write-stage-trace-development-20260915-third/source-pins.json').read_text())
for name, sha in pins.items():
    if name == 'scripts/checkpoint-publication-chaos.py':
        continue
    p = Path(name)
    assert hashlib.sha256(p.read_bytes()).hexdigest() == sha, name
    members[f'source/{name}'] = p
for name in ['scripts/check-write-stage-trace.py', 'scripts/check-write-stage-trace-controls.py']:
    members[f'source/{name}'] = Path(name)
for name in ['check-anchor-binding.py', 'check-checkpoint-base.py', 'check-checkpoint-publication.py', 'check-checkpoint-owner.py', 'check-retention-ledger.py']:
    members[f'source/scripts/{name}'] = Path('scripts') / name
members['publication/validation.json'] = OUT / 'validation.json'
members['publication/assemble.py'] = Path(__file__)
entries = []
archive = PACKET / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name,p in sorted(members.items()):
        assert not p.is_symlink(), str(p)
        data=p.read_bytes()
        assert len(data) < 5_000_000, str(p)
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
        entries.append(dict(member=name,source=str(p.absolute()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
inventory=dict(archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),member_count=len(entries),logical_bytes=sum(e['bytes'] for e in entries),members=entries)
(PACKET/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
shutil.copyfile(OUT/'validation.json',PACKET/'validation.json')
expected={e['member']:e for e in entries}
seen=set()
with tarfile.open(archive,'r:gz') as tar:
    for member in tar:
        assert member.isfile() and member.name in expected and member.name not in seen
        seen.add(member.name);data=tar.extractfile(member).read();e=expected[member.name]
        assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
        assert Path(e['source']).read_bytes()==data
assert seen==set(expected)
readback=dict(status='PASS',members=len(seen),logical_bytes=inventory['logical_bytes'],archive_sha256=inventory['archive']['sha256'],scope='Every regular archive member decoded, hashed and compared with its original input. No proof or workload rerun.')
(PACKET/'readback.json').write_text(json.dumps(readback,indent=2)+'\n')
print(json.dumps(dict(packet=str(PACKET),readback=readback,archive_bytes=archive.stat().st_size),indent=2))
