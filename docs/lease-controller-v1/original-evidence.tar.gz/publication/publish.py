from pathlib import Path
import gzip, hashlib, io, json, shutil, tarfile

repo = Path('/home/dongxu/kv9')
work = Path(__file__).resolve().parent
cargo = Path('/tmp/kv9-lease-controller-source-first')
control = Path('/tmp/kv9-lease-controller-controls-first')
root = Path('/tmp/kv9-lease-controller-root-first')
out = repo / 'docs/lease-controller-v1'
result = json.loads((cargo / 'result.json').read_text())
assert result['complete'] and all(r['exit_code'] == 0 for r in result['commands'])
proof = json.loads((control / 'summary.json').read_text())
assert (proof['rust_tests'], proof['rust_fault_controls'], proof['math_proofs']) == (25, 8, 3)
assert all(r['verdict'] in {'passed','expected test failure','expected compile rejection'} for r in proof['records'])
guard = json.loads((root / 'source-result.json').read_text())
assert guard['complete'] and guard['exit_code'] == 0
before = json.loads((cargo / 'sources-before.json').read_text())
assert before == json.loads((cargo / 'sources-after.json').read_text())
def digest(data): return hashlib.sha256(data).hexdigest()
for name, sha in before['sources'].items():
    if name.endswith(('.rs', '.toml', '.lock')) and sha is not None:
        assert digest((repo / name).read_bytes()) == sha, name
for name, sha in proof['sources'].items():
    assert digest((repo / name).read_bytes()) == sha, name

files = {}
def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink(), name
    data = path.read_bytes()
    assert len(data) <= 2 * 1024**2, name
    files[name] = data
for relative in proof['sources']:
    add('source/' + relative, repo / relative)
for relative in ['crates/raft/src/lib.rs', 'crates/raft/Cargo.toml',
                 'scripts/build_cache.py', 'scripts/build-workload.py']:
    add('source/' + relative, repo / relative)
for directory, prefix, excluded in [(cargo, 'cargo', {'raft-tests'}),
                                     (control, 'controls', {'controller-tests'}),
                                     (root, 'source-supervisor', set())]:
    for path in directory.rglob('*'):
        if path.is_file() and path.name not in excluded:
            add(prefix + '/' + str(path.relative_to(directory)), path)
add('controls/runner.log', control.with_suffix('.log'))
for suffix in ['arithmetic-draft1', 'division-draft1', 'arithmetic-draft2']:
    directory = Path('/tmp/kv9-lease-timing-' + suffix)
    for path in directory.iterdir():
        if path.is_file(): add('development/' + suffix + '/' + path.name, path)
cold = Path('/tmp/kv9-lease-authority-cold-states-first')
for path in cold.iterdir():
    if path.is_file() and path.suffix in {'.json', '.md'}:
        add('cold-state-maintenance/' + path.name, path)
add('publication/publish.py', Path(__file__))

out.mkdir()
archive = out / 'original-evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|') as tar:
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name); entry.size = len(data); entry.mode = 0o644
            tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files) and {m.name for m in members} == set(files)
    for member in members:
        assert member.isfile() and tar.extractfile(member).read() == files[member.name]
inventory = {'archive': archive.name, 'archive_bytes': archive.stat().st_size,
    'archive_sha256': digest(archive.read_bytes()), 'files': len(files),
    'members': [{'name': n, 'bytes': len(d), 'sha256': digest(d)} for n,d in sorted(files.items())],
    'scope': 'Original source, Cargo/cache outputs, optimized controls, proofs and metadata; compiled binaries and cold state payloads excluded'}
(out/'inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
shutil.copyfile(control/'summary.json', out/'controls-summary.json')
shutil.copyfile(cargo/'result.json', out/'source-summary.json')
total = sum(p.stat().st_size for p in (repo/'docs').rglob('original-evidence.tar.gz'))
assert total < 64 * 1024**2, total
receipt = {k:v for k,v in inventory.items() if k != 'members'}
receipt['aggregate_archive_bytes'] = total
(work/'readback.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
