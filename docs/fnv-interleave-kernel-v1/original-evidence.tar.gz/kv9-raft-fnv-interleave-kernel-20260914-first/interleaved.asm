
/tmp/kv9-raft-fnv-interleave-microbenchmark-20260914-first/fnv-interleave-bench:     file format elf64-x86-64


Disassembly of section .text:

000000000001e850 <fnv_interleave_bench::interleaved>:
   1e850:	55                   	push   %rbp
   1e851:	41 57                	push   %r15
   1e853:	41 56                	push   %r14
   1e855:	41 55                	push   %r13
   1e857:	41 54                	push   %r12
   1e859:	53                   	push   %rbx
   1e85a:	49 89 fc             	mov    %rdi,%r12
   1e85d:	4c 8b 2e             	mov    (%rsi),%r13
   1e860:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
   1e864:	4c 8b 7e 10          	mov    0x10(%rsi),%r15
   1e868:	48 8b 7e 18          	mov    0x18(%rsi),%rdi
   1e86c:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
   1e870:	48 8b 56 28          	mov    0x28(%rsi),%rdx
   1e874:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
   1e878:	48 8b 46 38          	mov    0x38(%rsi),%rax
   1e87c:	48 39 ef             	cmp    %rbp,%rdi
   1e87f:	49 89 ee             	mov    %rbp,%r14
   1e882:	48 89 7c 24 e8       	mov    %rdi,-0x18(%rsp)
   1e887:	4c 0f 42 f7          	cmovb  %rdi,%r14
   1e88b:	4c 39 f2             	cmp    %r14,%rdx
   1e88e:	48 89 54 24 f0       	mov    %rdx,-0x10(%rsp)
   1e893:	4c 0f 42 f2          	cmovb  %rdx,%r14
   1e897:	4c 39 f0             	cmp    %r14,%rax
   1e89a:	4d 89 f3             	mov    %r14,%r11
   1e89d:	48 89 44 24 f8       	mov    %rax,-0x8(%rsp)
   1e8a2:	4c 0f 42 d8          	cmovb  %rax,%r11
   1e8a6:	4d 85 db             	test   %r11,%r11
   1e8a9:	74 29                	je     1e8d4 <fnv_interleave_bench::interleaved+0x84>
   1e8ab:	4c 89 64 24 e0       	mov    %r12,-0x20(%rsp)
   1e8b0:	49 83 fb 01          	cmp    $0x1,%r11
   1e8b4:	75 3a                	jne    1e8f0 <fnv_interleave_bench::interleaved+0xa0>
   1e8b6:	bf c5 9d 1c 81       	mov    $0x811c9dc5,%edi
   1e8bb:	31 c0                	xor    %eax,%eax
   1e8bd:	41 ba c5 9d 1c 81    	mov    $0x811c9dc5,%r10d
   1e8c3:	41 b9 c5 9d 1c 81    	mov    $0x811c9dc5,%r9d
   1e8c9:	41 b8 c5 9d 1c 81    	mov    $0x811c9dc5,%r8d
   1e8cf:	e9 c2 00 00 00       	jmp    1e996 <fnv_interleave_bench::interleaved+0x146>
   1e8d4:	41 b8 c5 9d 1c 81    	mov    $0x811c9dc5,%r8d
   1e8da:	41 b9 c5 9d 1c 81    	mov    $0x811c9dc5,%r9d
   1e8e0:	41 ba c5 9d 1c 81    	mov    $0x811c9dc5,%r10d
   1e8e6:	bf c5 9d 1c 81       	mov    $0x811c9dc5,%edi
   1e8eb:	e9 ea 00 00 00       	jmp    1e9da <fnv_interleave_bench::interleaved+0x18a>
   1e8f0:	4c 89 de             	mov    %r11,%rsi
   1e8f3:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
   1e8f7:	bf c5 9d 1c 81       	mov    $0x811c9dc5,%edi
   1e8fc:	31 d2                	xor    %edx,%edx
   1e8fe:	41 ba c5 9d 1c 81    	mov    $0x811c9dc5,%r10d
   1e904:	41 b9 c5 9d 1c 81    	mov    $0x811c9dc5,%r9d
   1e90a:	41 b8 c5 9d 1c 81    	mov    $0x811c9dc5,%r8d
   1e910:	41 0f b6 44 15 00    	movzbl 0x0(%r13,%rdx,1),%eax
   1e916:	44 31 d0             	xor    %r10d,%eax
   1e919:	44 69 d0 93 01 00 01 	imul   $0x1000193,%eax,%r10d
   1e920:	41 0f b6 04 17       	movzbl (%r15,%rdx,1),%eax
   1e925:	44 31 c8             	xor    %r9d,%eax
   1e928:	44 69 c8 93 01 00 01 	imul   $0x1000193,%eax,%r9d
   1e92f:	0f b6 04 13          	movzbl (%rbx,%rdx,1),%eax
   1e933:	44 31 c0             	xor    %r8d,%eax
   1e936:	44 69 c0 93 01 00 01 	imul   $0x1000193,%eax,%r8d
   1e93d:	0f b6 04 11          	movzbl (%rcx,%rdx,1),%eax
   1e941:	31 f8                	xor    %edi,%eax
   1e943:	69 f8 93 01 00 01    	imul   $0x1000193,%eax,%edi
   1e949:	48 8d 42 02          	lea    0x2(%rdx),%rax
   1e94d:	45 0f b6 64 15 01    	movzbl 0x1(%r13,%rdx,1),%r12d
   1e953:	45 31 d4             	xor    %r10d,%r12d
   1e956:	45 69 d4 93 01 00 01 	imul   $0x1000193,%r12d,%r10d
   1e95d:	45 0f b6 64 17 01    	movzbl 0x1(%r15,%rdx,1),%r12d
   1e963:	45 31 cc             	xor    %r9d,%r12d
   1e966:	45 69 cc 93 01 00 01 	imul   $0x1000193,%r12d,%r9d
   1e96d:	44 0f b6 64 13 01    	movzbl 0x1(%rbx,%rdx,1),%r12d
   1e973:	45 31 c4             	xor    %r8d,%r12d
   1e976:	45 69 c4 93 01 00 01 	imul   $0x1000193,%r12d,%r8d
   1e97d:	0f b6 54 11 01       	movzbl 0x1(%rcx,%rdx,1),%edx
   1e982:	31 fa                	xor    %edi,%edx
   1e984:	69 fa 93 01 00 01    	imul   $0x1000193,%edx,%edi
   1e98a:	48 89 c2             	mov    %rax,%rdx
   1e98d:	48 39 c6             	cmp    %rax,%rsi
   1e990:	0f 85 7a ff ff ff    	jne    1e910 <fnv_interleave_bench::interleaved+0xc0>
   1e996:	41 f6 c3 01          	test   $0x1,%r11b
   1e99a:	4c 8b 64 24 e0       	mov    -0x20(%rsp),%r12
   1e99f:	74 39                	je     1e9da <fnv_interleave_bench::interleaved+0x18a>
   1e9a1:	41 0f b6 54 05 00    	movzbl 0x0(%r13,%rax,1),%edx
   1e9a7:	41 31 d2             	xor    %edx,%r10d
   1e9aa:	45 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%r10d
   1e9b1:	41 0f b6 14 07       	movzbl (%r15,%rax,1),%edx
   1e9b6:	41 31 d1             	xor    %edx,%r9d
   1e9b9:	45 69 c9 93 01 00 01 	imul   $0x1000193,%r9d,%r9d
   1e9c0:	0f b6 14 03          	movzbl (%rbx,%rax,1),%edx
   1e9c4:	41 31 d0             	xor    %edx,%r8d
   1e9c7:	45 69 c0 93 01 00 01 	imul   $0x1000193,%r8d,%r8d
   1e9ce:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
   1e9d2:	31 c7                	xor    %eax,%edi
   1e9d4:	69 ff 93 01 00 01    	imul   $0x1000193,%edi,%edi
   1e9da:	4c 39 dd             	cmp    %r11,%rbp
   1e9dd:	0f 84 b7 00 00 00    	je     1ea9a <fnv_interleave_bench::interleaved+0x24a>
   1e9e3:	4b 8d 14 2b          	lea    (%r11,%r13,1),%rdx
   1e9e7:	89 e8                	mov    %ebp,%eax
   1e9e9:	44 29 d8             	sub    %r11d,%eax
   1e9ec:	83 e0 07             	and    $0x7,%eax
   1e9ef:	74 24                	je     1ea15 <fnv_interleave_bench::interleaved+0x1c5>
   1e9f1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   1e9f8:	0f 1f 84 00 00 00 00 
   1e9ff:	00 
   1ea00:	0f b6 32             	movzbl (%rdx),%esi
   1ea03:	48 ff c2             	inc    %rdx
   1ea06:	44 31 d6             	xor    %r10d,%esi
   1ea09:	44 69 d6 93 01 00 01 	imul   $0x1000193,%esi,%r10d
   1ea10:	48 ff c8             	dec    %rax
   1ea13:	75 eb                	jne    1ea00 <fnv_interleave_bench::interleaved+0x1b0>
   1ea15:	4c 89 d8             	mov    %r11,%rax
   1ea18:	48 29 e8             	sub    %rbp,%rax
   1ea1b:	48 83 f8 f8          	cmp    $0xfffffffffffffff8,%rax
   1ea1f:	77 79                	ja     1ea9a <fnv_interleave_bench::interleaved+0x24a>
   1ea21:	49 01 ed             	add    %rbp,%r13
   1ea24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   1ea2b:	00 00 00 00 00 
   1ea30:	0f b6 02             	movzbl (%rdx),%eax
   1ea33:	44 31 d0             	xor    %r10d,%eax
   1ea36:	69 c0 93 01 00 01    	imul   $0x1000193,%eax,%eax
   1ea3c:	0f b6 72 01          	movzbl 0x1(%rdx),%esi
   1ea40:	31 c6                	xor    %eax,%esi
   1ea42:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ea48:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
   1ea4c:	31 c6                	xor    %eax,%esi
   1ea4e:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ea54:	0f b6 72 03          	movzbl 0x3(%rdx),%esi
   1ea58:	31 c6                	xor    %eax,%esi
   1ea5a:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ea60:	0f b6 72 04          	movzbl 0x4(%rdx),%esi
   1ea64:	31 c6                	xor    %eax,%esi
   1ea66:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ea6c:	0f b6 72 05          	movzbl 0x5(%rdx),%esi
   1ea70:	31 c6                	xor    %eax,%esi
   1ea72:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ea78:	0f b6 72 06          	movzbl 0x6(%rdx),%esi
   1ea7c:	31 c6                	xor    %eax,%esi
   1ea7e:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ea84:	0f b6 72 07          	movzbl 0x7(%rdx),%esi
   1ea88:	48 83 c2 08          	add    $0x8,%rdx
   1ea8c:	31 c6                	xor    %eax,%esi
   1ea8e:	44 69 d6 93 01 00 01 	imul   $0x1000193,%esi,%r10d
   1ea95:	4c 39 ea             	cmp    %r13,%rdx
   1ea98:	75 96                	jne    1ea30 <fnv_interleave_bench::interleaved+0x1e0>
   1ea9a:	4c 8b 6c 24 e8       	mov    -0x18(%rsp),%r13
   1ea9f:	4d 39 dd             	cmp    %r11,%r13
   1eaa2:	0f 84 b2 00 00 00    	je     1eb5a <fnv_interleave_bench::interleaved+0x30a>
   1eaa8:	4b 8d 14 1f          	lea    (%r15,%r11,1),%rdx
   1eaac:	44 89 e8             	mov    %r13d,%eax
   1eaaf:	44 29 d8             	sub    %r11d,%eax
   1eab2:	83 e0 07             	and    $0x7,%eax
   1eab5:	74 1e                	je     1ead5 <fnv_interleave_bench::interleaved+0x285>
   1eab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1eabe:	00 00 
   1eac0:	0f b6 32             	movzbl (%rdx),%esi
   1eac3:	48 ff c2             	inc    %rdx
   1eac6:	44 31 ce             	xor    %r9d,%esi
   1eac9:	44 69 ce 93 01 00 01 	imul   $0x1000193,%esi,%r9d
   1ead0:	48 ff c8             	dec    %rax
   1ead3:	75 eb                	jne    1eac0 <fnv_interleave_bench::interleaved+0x270>
   1ead5:	4c 89 d8             	mov    %r11,%rax
   1ead8:	4c 29 e8             	sub    %r13,%rax
   1eadb:	48 83 f8 f8          	cmp    $0xfffffffffffffff8,%rax
   1eadf:	77 79                	ja     1eb5a <fnv_interleave_bench::interleaved+0x30a>
   1eae1:	4d 01 ef             	add    %r13,%r15
   1eae4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   1eaeb:	00 00 00 00 00 
   1eaf0:	0f b6 02             	movzbl (%rdx),%eax
   1eaf3:	44 31 c8             	xor    %r9d,%eax
   1eaf6:	69 c0 93 01 00 01    	imul   $0x1000193,%eax,%eax
   1eafc:	0f b6 72 01          	movzbl 0x1(%rdx),%esi
   1eb00:	31 c6                	xor    %eax,%esi
   1eb02:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1eb08:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
   1eb0c:	31 c6                	xor    %eax,%esi
   1eb0e:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1eb14:	0f b6 72 03          	movzbl 0x3(%rdx),%esi
   1eb18:	31 c6                	xor    %eax,%esi
   1eb1a:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1eb20:	0f b6 72 04          	movzbl 0x4(%rdx),%esi
   1eb24:	31 c6                	xor    %eax,%esi
   1eb26:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1eb2c:	0f b6 72 05          	movzbl 0x5(%rdx),%esi
   1eb30:	31 c6                	xor    %eax,%esi
   1eb32:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1eb38:	0f b6 72 06          	movzbl 0x6(%rdx),%esi
   1eb3c:	31 c6                	xor    %eax,%esi
   1eb3e:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1eb44:	0f b6 72 07          	movzbl 0x7(%rdx),%esi
   1eb48:	48 83 c2 08          	add    $0x8,%rdx
   1eb4c:	31 c6                	xor    %eax,%esi
   1eb4e:	44 69 ce 93 01 00 01 	imul   $0x1000193,%esi,%r9d
   1eb55:	4c 39 fa             	cmp    %r15,%rdx
   1eb58:	75 96                	jne    1eaf0 <fnv_interleave_bench::interleaved+0x2a0>
   1eb5a:	4c 8b 7c 24 f0       	mov    -0x10(%rsp),%r15
   1eb5f:	4d 39 df             	cmp    %r11,%r15
   1eb62:	0f 84 b2 00 00 00    	je     1ec1a <fnv_interleave_bench::interleaved+0x3ca>
   1eb68:	4a 8d 14 1b          	lea    (%rbx,%r11,1),%rdx
   1eb6c:	44 89 f8             	mov    %r15d,%eax
   1eb6f:	44 29 d8             	sub    %r11d,%eax
   1eb72:	83 e0 07             	and    $0x7,%eax
   1eb75:	74 1e                	je     1eb95 <fnv_interleave_bench::interleaved+0x345>
   1eb77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1eb7e:	00 00 
   1eb80:	0f b6 32             	movzbl (%rdx),%esi
   1eb83:	48 ff c2             	inc    %rdx
   1eb86:	44 31 c6             	xor    %r8d,%esi
   1eb89:	44 69 c6 93 01 00 01 	imul   $0x1000193,%esi,%r8d
   1eb90:	48 ff c8             	dec    %rax
   1eb93:	75 eb                	jne    1eb80 <fnv_interleave_bench::interleaved+0x330>
   1eb95:	4c 89 d8             	mov    %r11,%rax
   1eb98:	4c 29 f8             	sub    %r15,%rax
   1eb9b:	48 83 f8 f8          	cmp    $0xfffffffffffffff8,%rax
   1eb9f:	77 79                	ja     1ec1a <fnv_interleave_bench::interleaved+0x3ca>
   1eba1:	4c 01 fb             	add    %r15,%rbx
   1eba4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   1ebab:	00 00 00 00 00 
   1ebb0:	0f b6 02             	movzbl (%rdx),%eax
   1ebb3:	44 31 c0             	xor    %r8d,%eax
   1ebb6:	69 c0 93 01 00 01    	imul   $0x1000193,%eax,%eax
   1ebbc:	0f b6 72 01          	movzbl 0x1(%rdx),%esi
   1ebc0:	31 c6                	xor    %eax,%esi
   1ebc2:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ebc8:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
   1ebcc:	31 c6                	xor    %eax,%esi
   1ebce:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ebd4:	0f b6 72 03          	movzbl 0x3(%rdx),%esi
   1ebd8:	31 c6                	xor    %eax,%esi
   1ebda:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ebe0:	0f b6 72 04          	movzbl 0x4(%rdx),%esi
   1ebe4:	31 c6                	xor    %eax,%esi
   1ebe6:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ebec:	0f b6 72 05          	movzbl 0x5(%rdx),%esi
   1ebf0:	31 c6                	xor    %eax,%esi
   1ebf2:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ebf8:	0f b6 72 06          	movzbl 0x6(%rdx),%esi
   1ebfc:	31 c6                	xor    %eax,%esi
   1ebfe:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ec04:	0f b6 72 07          	movzbl 0x7(%rdx),%esi
   1ec08:	48 83 c2 08          	add    $0x8,%rdx
   1ec0c:	31 c6                	xor    %eax,%esi
   1ec0e:	44 69 c6 93 01 00 01 	imul   $0x1000193,%esi,%r8d
   1ec15:	48 39 da             	cmp    %rbx,%rdx
   1ec18:	75 96                	jne    1ebb0 <fnv_interleave_bench::interleaved+0x360>
   1ec1a:	48 8b 5c 24 f8       	mov    -0x8(%rsp),%rbx
   1ec1f:	4c 39 f3             	cmp    %r14,%rbx
   1ec22:	0f 86 a0 00 00 00    	jbe    1ecc8 <fnv_interleave_bench::interleaved+0x478>
   1ec28:	4a 8d 14 19          	lea    (%rcx,%r11,1),%rdx
   1ec2c:	89 d8                	mov    %ebx,%eax
   1ec2e:	44 29 d8             	sub    %r11d,%eax
   1ec31:	83 e0 07             	and    $0x7,%eax
   1ec34:	74 1d                	je     1ec53 <fnv_interleave_bench::interleaved+0x403>
   1ec36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   1ec3d:	00 00 00 
   1ec40:	0f b6 32             	movzbl (%rdx),%esi
   1ec43:	48 ff c2             	inc    %rdx
   1ec46:	31 fe                	xor    %edi,%esi
   1ec48:	69 fe 93 01 00 01    	imul   $0x1000193,%esi,%edi
   1ec4e:	48 ff c8             	dec    %rax
   1ec51:	75 ed                	jne    1ec40 <fnv_interleave_bench::interleaved+0x3f0>
   1ec53:	49 29 db             	sub    %rbx,%r11
   1ec56:	49 83 fb f8          	cmp    $0xfffffffffffffff8,%r11
   1ec5a:	77 6c                	ja     1ecc8 <fnv_interleave_bench::interleaved+0x478>
   1ec5c:	48 01 d9             	add    %rbx,%rcx
   1ec5f:	90                   	nop
   1ec60:	0f b6 02             	movzbl (%rdx),%eax
   1ec63:	31 f8                	xor    %edi,%eax
   1ec65:	69 c0 93 01 00 01    	imul   $0x1000193,%eax,%eax
   1ec6b:	0f b6 72 01          	movzbl 0x1(%rdx),%esi
   1ec6f:	31 c6                	xor    %eax,%esi
   1ec71:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ec77:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
   1ec7b:	31 c6                	xor    %eax,%esi
   1ec7d:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ec83:	0f b6 72 03          	movzbl 0x3(%rdx),%esi
   1ec87:	31 c6                	xor    %eax,%esi
   1ec89:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ec8f:	0f b6 72 04          	movzbl 0x4(%rdx),%esi
   1ec93:	31 c6                	xor    %eax,%esi
   1ec95:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ec9b:	0f b6 72 05          	movzbl 0x5(%rdx),%esi
   1ec9f:	31 c6                	xor    %eax,%esi
   1eca1:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1eca7:	0f b6 72 06          	movzbl 0x6(%rdx),%esi
   1ecab:	31 c6                	xor    %eax,%esi
   1ecad:	69 c6 93 01 00 01    	imul   $0x1000193,%esi,%eax
   1ecb3:	0f b6 72 07          	movzbl 0x7(%rdx),%esi
   1ecb7:	48 83 c2 08          	add    $0x8,%rdx
   1ecbb:	31 c6                	xor    %eax,%esi
   1ecbd:	69 fe 93 01 00 01    	imul   $0x1000193,%esi,%edi
   1ecc3:	48 39 ca             	cmp    %rcx,%rdx
   1ecc6:	75 98                	jne    1ec60 <fnv_interleave_bench::interleaved+0x410>
   1ecc8:	45 89 14 24          	mov    %r10d,(%r12)
   1eccc:	45 89 4c 24 04       	mov    %r9d,0x4(%r12)
   1ecd1:	45 89 44 24 08       	mov    %r8d,0x8(%r12)
   1ecd6:	41 89 7c 24 0c       	mov    %edi,0xc(%r12)
   1ecdb:	4c 89 e0             	mov    %r12,%rax
   1ecde:	5b                   	pop    %rbx
   1ecdf:	41 5c                	pop    %r12
   1ece1:	41 5d                	pop    %r13
   1ece3:	41 5e                	pop    %r14
   1ece5:	41 5f                	pop    %r15
   1ece7:	5d                   	pop    %rbp
   1ece8:	c3                   	ret
