
/tmp/kv9-raft-fnv-interleave-microbenchmark-20260914-first/fnv-interleave-bench:     file format elf64-x86-64


Disassembly of section .text:

0000000000020420 <fnv_interleave_bench::serial>:
   20420:	53                   	push   %rbx
   20421:	48 89 f8             	mov    %rdi,%rax
   20424:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
   20428:	b9 c5 9d 1c 81       	mov    $0x811c9dc5,%ecx
   2042d:	ba c5 9d 1c 81       	mov    $0x811c9dc5,%edx
   20432:	4d 85 c9             	test   %r9,%r9
   20435:	0f 84 cc 00 00 00    	je     20507 <fnv_interleave_bench::serial+0xe7>
   2043b:	48 8b 3e             	mov    (%rsi),%rdi
   2043e:	45 89 c8             	mov    %r9d,%r8d
   20441:	41 83 e0 07          	and    $0x7,%r8d
   20445:	49 83 f9 08          	cmp    $0x8,%r9
   20449:	0f 82 96 00 00 00    	jb     204e5 <fnv_interleave_bench::serial+0xc5>
   2044f:	49 83 e1 f8          	and    $0xfffffffffffffff8,%r9
   20453:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2045a:	84 00 00 00 00 00 
   20460:	44 0f b6 17          	movzbl (%rdi),%r10d
   20464:	41 31 d2             	xor    %edx,%r10d
   20467:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   2046e:	44 0f b6 57 01       	movzbl 0x1(%rdi),%r10d
   20473:	41 31 d2             	xor    %edx,%r10d
   20476:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   2047d:	44 0f b6 57 02       	movzbl 0x2(%rdi),%r10d
   20482:	41 31 d2             	xor    %edx,%r10d
   20485:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   2048c:	44 0f b6 57 03       	movzbl 0x3(%rdi),%r10d
   20491:	41 31 d2             	xor    %edx,%r10d
   20494:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   2049b:	44 0f b6 57 04       	movzbl 0x4(%rdi),%r10d
   204a0:	41 31 d2             	xor    %edx,%r10d
   204a3:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   204aa:	44 0f b6 57 05       	movzbl 0x5(%rdi),%r10d
   204af:	41 31 d2             	xor    %edx,%r10d
   204b2:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   204b9:	44 0f b6 57 06       	movzbl 0x6(%rdi),%r10d
   204be:	41 31 d2             	xor    %edx,%r10d
   204c1:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   204c8:	44 0f b6 57 07       	movzbl 0x7(%rdi),%r10d
   204cd:	48 83 c7 08          	add    $0x8,%rdi
   204d1:	41 31 d2             	xor    %edx,%r10d
   204d4:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   204db:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
   204df:	0f 85 7b ff ff ff    	jne    20460 <fnv_interleave_bench::serial+0x40>
   204e5:	4d 85 c0             	test   %r8,%r8
   204e8:	74 1d                	je     20507 <fnv_interleave_bench::serial+0xe7>
   204ea:	45 31 c9             	xor    %r9d,%r9d
   204ed:	0f 1f 00             	nopl   (%rax)
   204f0:	46 0f b6 14 0f       	movzbl (%rdi,%r9,1),%r10d
   204f5:	41 31 d2             	xor    %edx,%r10d
   204f8:	41 69 d2 93 01 00 01 	imul   $0x1000193,%r10d,%edx
   204ff:	49 ff c1             	inc    %r9
   20502:	4d 39 c8             	cmp    %r9,%r8
   20505:	75 e9                	jne    204f0 <fnv_interleave_bench::serial+0xd0>
   20507:	4c 8b 4e 18          	mov    0x18(%rsi),%r9
   2050b:	4d 85 c9             	test   %r9,%r9
   2050e:	0f 84 d3 00 00 00    	je     205e7 <fnv_interleave_bench::serial+0x1c7>
   20514:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
   20518:	45 89 c8             	mov    %r9d,%r8d
   2051b:	41 83 e0 07          	and    $0x7,%r8d
   2051f:	49 83 f9 08          	cmp    $0x8,%r9
   20523:	73 0a                	jae    2052f <fnv_interleave_bench::serial+0x10f>
   20525:	b9 c5 9d 1c 81       	mov    $0x811c9dc5,%ecx
   2052a:	e9 96 00 00 00       	jmp    205c5 <fnv_interleave_bench::serial+0x1a5>
   2052f:	49 83 e1 f8          	and    $0xfffffffffffffff8,%r9
   20533:	b9 c5 9d 1c 81       	mov    $0x811c9dc5,%ecx
   20538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2053f:	00 
   20540:	44 0f b6 17          	movzbl (%rdi),%r10d
   20544:	41 31 ca             	xor    %ecx,%r10d
   20547:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   2054e:	44 0f b6 57 01       	movzbl 0x1(%rdi),%r10d
   20553:	41 31 ca             	xor    %ecx,%r10d
   20556:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   2055d:	44 0f b6 57 02       	movzbl 0x2(%rdi),%r10d
   20562:	41 31 ca             	xor    %ecx,%r10d
   20565:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   2056c:	44 0f b6 57 03       	movzbl 0x3(%rdi),%r10d
   20571:	41 31 ca             	xor    %ecx,%r10d
   20574:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   2057b:	44 0f b6 57 04       	movzbl 0x4(%rdi),%r10d
   20580:	41 31 ca             	xor    %ecx,%r10d
   20583:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   2058a:	44 0f b6 57 05       	movzbl 0x5(%rdi),%r10d
   2058f:	41 31 ca             	xor    %ecx,%r10d
   20592:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   20599:	44 0f b6 57 06       	movzbl 0x6(%rdi),%r10d
   2059e:	41 31 ca             	xor    %ecx,%r10d
   205a1:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   205a8:	44 0f b6 57 07       	movzbl 0x7(%rdi),%r10d
   205ad:	48 83 c7 08          	add    $0x8,%rdi
   205b1:	41 31 ca             	xor    %ecx,%r10d
   205b4:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   205bb:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
   205bf:	0f 85 7b ff ff ff    	jne    20540 <fnv_interleave_bench::serial+0x120>
   205c5:	4d 85 c0             	test   %r8,%r8
   205c8:	74 1d                	je     205e7 <fnv_interleave_bench::serial+0x1c7>
   205ca:	45 31 c9             	xor    %r9d,%r9d
   205cd:	0f 1f 00             	nopl   (%rax)
   205d0:	46 0f b6 14 0f       	movzbl (%rdi,%r9,1),%r10d
   205d5:	41 31 ca             	xor    %ecx,%r10d
   205d8:	41 69 ca 93 01 00 01 	imul   $0x1000193,%r10d,%ecx
   205df:	49 ff c1             	inc    %r9
   205e2:	4d 39 c8             	cmp    %r9,%r8
   205e5:	75 e9                	jne    205d0 <fnv_interleave_bench::serial+0x1b0>
   205e7:	4c 8b 5e 28          	mov    0x28(%rsi),%r11
   205eb:	bf c5 9d 1c 81       	mov    $0x811c9dc5,%edi
   205f0:	41 b8 c5 9d 1c 81    	mov    $0x811c9dc5,%r8d
   205f6:	4d 85 db             	test   %r11,%r11
   205f9:	0f 84 c8 00 00 00    	je     206c7 <fnv_interleave_bench::serial+0x2a7>
   205ff:	4c 8b 4e 20          	mov    0x20(%rsi),%r9
   20603:	45 89 da             	mov    %r11d,%r10d
   20606:	41 83 e2 07          	and    $0x7,%r10d
   2060a:	49 83 fb 08          	cmp    $0x8,%r11
   2060e:	0f 82 91 00 00 00    	jb     206a5 <fnv_interleave_bench::serial+0x285>
   20614:	49 83 e3 f8          	and    $0xfffffffffffffff8,%r11
   20618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2061f:	00 
   20620:	41 0f b6 19          	movzbl (%r9),%ebx
   20624:	44 31 c3             	xor    %r8d,%ebx
   20627:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   2062e:	41 0f b6 59 01       	movzbl 0x1(%r9),%ebx
   20633:	44 31 c3             	xor    %r8d,%ebx
   20636:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   2063d:	41 0f b6 59 02       	movzbl 0x2(%r9),%ebx
   20642:	44 31 c3             	xor    %r8d,%ebx
   20645:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   2064c:	41 0f b6 59 03       	movzbl 0x3(%r9),%ebx
   20651:	44 31 c3             	xor    %r8d,%ebx
   20654:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   2065b:	41 0f b6 59 04       	movzbl 0x4(%r9),%ebx
   20660:	44 31 c3             	xor    %r8d,%ebx
   20663:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   2066a:	41 0f b6 59 05       	movzbl 0x5(%r9),%ebx
   2066f:	44 31 c3             	xor    %r8d,%ebx
   20672:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   20679:	41 0f b6 59 06       	movzbl 0x6(%r9),%ebx
   2067e:	44 31 c3             	xor    %r8d,%ebx
   20681:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   20688:	41 0f b6 59 07       	movzbl 0x7(%r9),%ebx
   2068d:	49 83 c1 08          	add    $0x8,%r9
   20691:	44 31 c3             	xor    %r8d,%ebx
   20694:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   2069b:	49 83 c3 f8          	add    $0xfffffffffffffff8,%r11
   2069f:	0f 85 7b ff ff ff    	jne    20620 <fnv_interleave_bench::serial+0x200>
   206a5:	4d 85 d2             	test   %r10,%r10
   206a8:	74 1d                	je     206c7 <fnv_interleave_bench::serial+0x2a7>
   206aa:	45 31 db             	xor    %r11d,%r11d
   206ad:	0f 1f 00             	nopl   (%rax)
   206b0:	43 0f b6 1c 19       	movzbl (%r9,%r11,1),%ebx
   206b5:	44 31 c3             	xor    %r8d,%ebx
   206b8:	44 69 c3 93 01 00 01 	imul   $0x1000193,%ebx,%r8d
   206bf:	49 ff c3             	inc    %r11
   206c2:	4d 39 da             	cmp    %r11,%r10
   206c5:	75 e9                	jne    206b0 <fnv_interleave_bench::serial+0x290>
   206c7:	4c 8b 56 38          	mov    0x38(%rsi),%r10
   206cb:	4d 85 d2             	test   %r10,%r10
   206ce:	0f 84 d3 00 00 00    	je     207a7 <fnv_interleave_bench::serial+0x387>
   206d4:	48 8b 76 30          	mov    0x30(%rsi),%rsi
   206d8:	45 89 d1             	mov    %r10d,%r9d
   206db:	41 83 e1 07          	and    $0x7,%r9d
   206df:	49 83 fa 08          	cmp    $0x8,%r10
   206e3:	73 0a                	jae    206ef <fnv_interleave_bench::serial+0x2cf>
   206e5:	bf c5 9d 1c 81       	mov    $0x811c9dc5,%edi
   206ea:	e9 96 00 00 00       	jmp    20785 <fnv_interleave_bench::serial+0x365>
   206ef:	49 83 e2 f8          	and    $0xfffffffffffffff8,%r10
   206f3:	bf c5 9d 1c 81       	mov    $0x811c9dc5,%edi
   206f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   206ff:	00 
   20700:	44 0f b6 1e          	movzbl (%rsi),%r11d
   20704:	41 31 fb             	xor    %edi,%r11d
   20707:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   2070e:	44 0f b6 5e 01       	movzbl 0x1(%rsi),%r11d
   20713:	41 31 fb             	xor    %edi,%r11d
   20716:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   2071d:	44 0f b6 5e 02       	movzbl 0x2(%rsi),%r11d
   20722:	41 31 fb             	xor    %edi,%r11d
   20725:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   2072c:	44 0f b6 5e 03       	movzbl 0x3(%rsi),%r11d
   20731:	41 31 fb             	xor    %edi,%r11d
   20734:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   2073b:	44 0f b6 5e 04       	movzbl 0x4(%rsi),%r11d
   20740:	41 31 fb             	xor    %edi,%r11d
   20743:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   2074a:	44 0f b6 5e 05       	movzbl 0x5(%rsi),%r11d
   2074f:	41 31 fb             	xor    %edi,%r11d
   20752:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   20759:	44 0f b6 5e 06       	movzbl 0x6(%rsi),%r11d
   2075e:	41 31 fb             	xor    %edi,%r11d
   20761:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   20768:	44 0f b6 5e 07       	movzbl 0x7(%rsi),%r11d
   2076d:	48 83 c6 08          	add    $0x8,%rsi
   20771:	41 31 fb             	xor    %edi,%r11d
   20774:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   2077b:	49 83 c2 f8          	add    $0xfffffffffffffff8,%r10
   2077f:	0f 85 7b ff ff ff    	jne    20700 <fnv_interleave_bench::serial+0x2e0>
   20785:	4d 85 c9             	test   %r9,%r9
   20788:	74 1d                	je     207a7 <fnv_interleave_bench::serial+0x387>
   2078a:	45 31 d2             	xor    %r10d,%r10d
   2078d:	0f 1f 00             	nopl   (%rax)
   20790:	46 0f b6 1c 16       	movzbl (%rsi,%r10,1),%r11d
   20795:	41 31 fb             	xor    %edi,%r11d
   20798:	41 69 fb 93 01 00 01 	imul   $0x1000193,%r11d,%edi
   2079f:	49 ff c2             	inc    %r10
   207a2:	4d 39 d1             	cmp    %r10,%r9
   207a5:	75 e9                	jne    20790 <fnv_interleave_bench::serial+0x370>
   207a7:	89 10                	mov    %edx,(%rax)
   207a9:	89 48 04             	mov    %ecx,0x4(%rax)
   207ac:	44 89 40 08          	mov    %r8d,0x8(%rax)
   207b0:	89 78 0c             	mov    %edi,0xc(%rax)
   207b3:	5b                   	pop    %rbx
   207b4:	c3                   	ret
