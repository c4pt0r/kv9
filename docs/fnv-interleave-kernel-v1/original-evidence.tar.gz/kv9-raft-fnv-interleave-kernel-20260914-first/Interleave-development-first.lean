import Std

namespace Kv9.FnvInterleave

abbrev Word := BitVec 32
abbrev Byte := BitVec 8

def initial : Word := 0x811c9dc5
def prime : Word := 0x01000193
def step (hash : Word) (byte : Byte) : Word :=
  (hash ^^^ byte.zeroExtend 32) * prime

def scalar (bytes : List Byte) (hash : Word) : Word := bytes.foldl step hash

def four : List Byte → List Byte → List Byte → List Byte →
    Word → Word → Word → Word → Word × Word × Word × Word
  | a::as, b::bs, c::cs, d::ds, h0, h1, h2, h3 =>
      four as bs cs ds (step h0 a) (step h1 b) (step h2 c) (step h3 d)
  | as, bs, cs, ds, h0, h1, h2, h3 =>
      (scalar as h0, scalar bs h1, scalar cs h2, scalar ds h3)

theorem scalar_append (as bs : List Byte) (hash : Word) :
    scalar (as ++ bs) hash = scalar bs (scalar as hash) := by
  exact List.foldl_append

/-- Arbitrary initial states, all lengths, unequal tails and empty lanes. -/
theorem four_equivalence (as bs cs ds : List Byte) (h0 h1 h2 h3 : Word) :
    four as bs cs ds h0 h1 h2 h3 =
      (scalar as h0, scalar bs h1, scalar cs h2, scalar ds h3) := by
  induction as generalizing bs cs ds h0 h1 h2 h3 with
  | nil => rfl
  | cons a as ih =>
    cases bs with
    | nil => rfl
    | cons b bs =>
      cases cs with
      | nil => rfl
      | cons c cs =>
        cases ds with
        | nil => rfl
        | cons d ds =>
          simpa only [four, scalar, List.foldl_cons] using
            ih bs cs ds (step h0 a) (step h1 b) (step h2 c) (step h3 d)

def checksum4 (as bs cs ds : List Byte) : Word × Word × Word × Word :=
  four as bs cs ds initial initial initial initial

theorem checksum_equivalence (as bs cs ds : List Byte) :
    checksum4 as bs cs ds =
      (scalar as initial, scalar bs initial, scalar cs initial, scalar ds initial) := by
  exact four_equivalence as bs cs ds initial initial initial initial

/-- A common prefix and each lane's scalar tail consume the same full list. -/
theorem split_equivalence (a0 a1 b0 b1 c0 c1 d0 d1 : List Byte)
    (h0 h1 h2 h3 : Word) :
    let prefix := four a0 b0 c0 d0 h0 h1 h2 h3
    four a1 b1 c1 d1 prefix.1 prefix.2.1 prefix.2.2.1 prefix.2.2.2 =
      four (a0 ++ a1) (b0 ++ b1) (c0 ++ c1) (d0 ++ d1) h0 h1 h2 h3 := by
  simp only [four_equivalence, scalar_append]

/-- Changing the other lanes cannot affect lane zero, including ragged inputs. -/
theorem lane_independence (as bs cs ds bs' cs' ds' : List Byte)
    (h0 h1 h2 h3 h1' h2' h3' : Word) :
    (four as bs cs ds h0 h1 h2 h3).1 =
      (four as bs' cs' ds' h0 h1' h2' h3').1 := by
  simp only [four_equivalence]

theorem common_length_bound (a b c d : Nat) :
    min (min (min a b) c) d ≤ a ∧ min (min (min a b) c) d ≤ b ∧
    min (min (min a b) c) d ≤ c ∧ min (min (min a b) c) d ≤ d := by
  omega

end Kv9.FnvInterleave
