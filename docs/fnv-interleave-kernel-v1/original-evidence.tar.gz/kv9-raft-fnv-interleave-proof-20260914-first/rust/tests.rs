#[path = "fnv.rs"] mod fnv;
include!("original.rs");
#[test]
fn actual_committed_scalar_matches_all_lanes() {
    let data: [Vec<u8>; 4] = std::array::from_fn(|lane| (0..65536).map(|i| ((i * 71 + lane * 53) ^ (i >> 8)) as u8).collect());
    for sizes in [[0,0,0,0], [0,205,10601,32], [206;4], [10601;4], [65536;4], [205,206,10599,10601]] {
        let inputs = std::array::from_fn(|i| &data[i][..sizes[i]]);
        let expected = inputs.map(original_fnv1a);
        assert_eq!(fnv::fnv1a_four(inputs), expected);
        assert_eq!(inputs.map(fnv::fnv1a), expected);
    }
}
