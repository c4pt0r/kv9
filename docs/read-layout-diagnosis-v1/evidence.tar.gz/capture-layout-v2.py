#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,re,subprocess,time
S=Path(__file__).resolve().parent
H=Path('/home/dongxu/kv9/scripts/read-layout-diagnostic/capture-gdb.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'complete':False,'started_ns':time.time_ns(),'cases':[],'performance_evidence':False,'source_sha256':sha(H)}
try:
 for config in ['ordinary','aligned64']:
  for arm in ['baseline','candidate']:
   name=config+'-'+arm;out=S/('layout-v2-'+name);out.mkdir(exist_ok=False)
   inspection=S/('codegen-'+name)/'result.json';pin=json.loads(inspection.read_text());elf=Path(pin['binary']);assert sha(elf)==pin['sha256']
   symbols=subprocess.check_output(['nm','--defined-only',str(elf)],text=True)
   matches=[line.split()[-1] for line in symbols.splitlines() if re.search(r'kv9_outlined_mutation_experiment6answer17h[0-9a-f]+E$',line)]
   assert len(matches)==1
   script=out/'commands.gdb'
   script.write_text('set pagination off\nset confirm off\nset history save off\nset disable-randomization off\nset debuginfod enabled off\npython\nexec(compile(open('+repr(str(H))+').read(), '+repr(str(H))+', "exec"))\nend\nrun\npython\nassert capture_finished\nend\nquit\n')
   env=dict(os.environ,KV9_LAYOUT_CAPTURE=str(out/'capture.json'),KV9_LAYOUT_INSPECTION=str(inspection),KV9_LAYOUT_SYMBOL=matches[0],DEBUGINFOD_URLS='')
   argv=['taskset','-c','4','gdb','--batch','--return-child-result','-x',str(script),'--args',str(elf),str(S),str(out/'debugger-result.json'),'measure','18','0' if arm=='baseline' else '1']
   row={'name':name,'argv':argv,'binary_sha256':pin['sha256'],'complete':False,'started_ns':time.time_ns()};result['cases'].append(row)
   with (out/'gdb.stdout').open('x') as stdout,(out/'gdb.stderr').open('x') as stderr:
    process=subprocess.run(argv,env=env,stdout=stdout,stderr=stderr,timeout=120)
   row['exit_code']=process.returncode
   assert process.returncode==0,(name,process.returncode)
   capture=json.loads((out/'capture.json').read_text());assert capture['complete'] and capture['binary_sha256']==pin['sha256']
   done=json.loads((out/'debugger-result.json').read_text());assert done['complete']
   row.update(complete=True,ended_ns=time.time_ns(),capture_sha256=sha(out/'capture.json'),debugger_result_sha256=sha(out/'debugger-result.json'))
   print(json.dumps(row),flush=True)
 assert sha(H)==result['source_sha256']
 result['complete']=True
except BaseException as error:
 result['failure']=repr(error);raise
finally:
 result['ended_ns']=time.time_ns();(S/'capture-summary-v2.json').write_text(json.dumps(result,indent=2)+'\n')
