#!/usr/bin/env python3
from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile
S=Path(__file__).resolve().parent;R=Path('/home/dongxu/kv9');D=R/'docs/read-layout-diagnosis-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((S/'analysis.json').read_text())['complete']
assert json.loads((S/'layout-analysis.json').read_text())['complete']
shutil.copytree(R/'scripts/read-layout-diagnostic',S/'published-tools',ignore=shutil.ignore_patterns('__pycache__'))
D.mkdir(exist_ok=False)
allowed={'.py','.rs','.toml','.lock','.json','.jsonl','.txt','.md','.stderr','.stdout','.gdb'}
special={'Cargo.lock','stdout','stderr'}
members=[];excluded=[]
for p in sorted(S.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(S)
 if any(x in rel.parts for x in ['.git','target','__pycache__']):continue
 assert not p.is_symlink()
 if p.name.startswith('issue9-') or p.name in ['continuation.json','run-progress.json','packet-result.json'] or not (p.suffix in allowed or p.name in special):
  excluded.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)});continue
 members.append({'name':str(rel),'source':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
archive=D/'evidence.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for m in members:
  data=Path(m['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==m['sha256']
  info=tarfile.TarInfo(m['name']);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 infos=tar.getmembers();assert len(infos)==len(members)
 for info,m in zip(infos,members):
  assert info.isfile() and info.name==m['name'] and info.size==m['bytes']
  assert hashlib.sha256(tar.extractfile(info).read()).hexdigest()==m['sha256']
for name in ['analysis.json','layout-analysis.json','codegen-comparison.json','timing-plan.json','capture-plan.json','next-engine-diagnostic.json','retained-tool-bindings.json']:
 shutil.copyfile(S/name,D/name)
result={'complete':True,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'expanded_bytes':sum(m['bytes'] for m in members),'members':len(members),'all_members_readback_verified':True,'excluded':excluded,'external_inputs':{'qualified_dependency_sources':'../outlined-mutation-path-v1/evidence.tar.gz (outlined/ subtree)','groups_bin':{'archive':'../outlined-mutation-path-v1/evidence.tar.gz','member':'outlined/groups.bin','sha256':sha(S/'groups.bin')},'ordinary_elfs':'Exact prior ELFs retained in /mnt/data/kv9-work/outlined-mutation-path-20260916-first/bench-build-{baseline,candidate}/timing; hashes in codegen inspections'},'scope':'Retains every planned timing row, independent preparation, source/cache/build evidence, static code inspection and debugger snapshots/failures. Debugger timings are not performance evidence. Executables remain in retained roots. Duplicate corpus, changing continuation/progress and GitHub body snapshots are excluded.'}
(D/'members.json').write_text(json.dumps(members,indent=2)+'\n');(D/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');(S/'packet-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['excluded','external_inputs']},indent=2))
