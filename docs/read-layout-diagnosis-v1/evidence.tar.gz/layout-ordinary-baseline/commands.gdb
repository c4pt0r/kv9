set pagination off
set confirm off
set history save off
set disable-randomization off
set debuginfod enabled off
python
exec(compile(open('/home/dongxu/kv9/scripts/read-layout-diagnostic/capture-gdb.py').read(), '/home/dongxu/kv9/scripts/read-layout-diagnostic/capture-gdb.py', "exec"))
end
run
python
assert capture_finished
end
quit
