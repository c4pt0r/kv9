#!/usr/bin/env python3
"""Root-owned execution of the reviewed, frozen lifecycle-only recording."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).parent
PREP = Path('/tmp/kv9-read-wait-lifecycle-run-preparation')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    readiness = json.loads((PREP / 'READINESS.json').read_text())
    assert sha(PREP / 'READINESS.json') == '3b401847d6e56bc228bda87861818944eb66bd2a09954275809ce110222afd3f'
    assert readiness['complete'] and readiness['contract_exit_code'] == readiness['source_preflight_exit_code'] == 0
    assert sha(PREP / 'inventory.json') == readiness['manifest_sha256']
    inventory = json.loads((PREP / 'inventory.json').read_text())
    for name, pin in inventory.items():
        path = PREP / name
        assert path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'], name
    for name, expected in readiness['hashes'].items():
        assert sha(PREP / name) == expected, name
    command = json.loads((PREP / 'commands.json').read_text())['launch_only_after_root_review']
    assert not Path('/tmp/kv9-read-wait-lifecycle-isolation-first').exists()
    result = dict(argv=command, complete=False, preparation_sha256=sha(PREP / 'READINESS.json'),
                  frozen_files=len(inventory), started_ns=time.time_ns())
    save(ROOT / 'recording-terminal-first.json', result)
    with (ROOT / 'recording-first.log').open('x') as stream:
        child = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT)
        result['wrapper_pid'] = child.pid
        save(ROOT / 'recording-terminal-first.json', result)
        code = child.wait()
    result.update(exit_code=code, ended_ns=time.time_ns())
    if code == 0:
        for name, pin in inventory.items():
            assert sha(PREP / name) == pin['sha256'], name
        result['complete'] = True
    save(ROOT / 'recording-terminal-first.json', result)
    print(json.dumps(result, indent=2), flush=True)
    if code:
        raise SystemExit(code)


if __name__ == '__main__':
    main()
