"""Finite read-only arithmetic for the four accepted lifecycle recordings."""
import hashlib
import json
from pathlib import Path
from fractions import Fraction

if not __debug__:
    raise SystemExit('Python assertions must be enabled')

OUT = Path(__file__).parent
PREP = Path('/tmp/kv9-read-wait-lifecycle-run-preparation')
RAW = Path('/tmp/kv9-read-wait-lifecycle-isolation-first/cohorts')
inputs = {}


def read(path):
    data = path.read_bytes()
    inputs[str(path)] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return json.loads(data)


inventory = read(PREP / 'results-first/input-inventory.json')
analysis = read(PREP / 'results-first/analysis.json')
assert analysis['accepted'] and analysis['complete'] and len(analysis['cohorts']) == 4
assert analysis['parent_confirmed_session'] == 63422 and analysis['parent_confirmed_exit_code'] == 0
bindings = read(RAW / 'build-bindings.json')
phases = ['queue', 'quorum', 'apply', 'notification', 'total']
counter_names = ['admitted_groups', 'admitted_members', 'group_attempts', 'inspected']
rows = []


def hist(document, phase):
    metric, = [m for m in document['metrics'] if m['name'] == 'raft_async_read_profile_' + phase]
    h, = [h for h in metric['latency']['outcomes'] if h['outcome'] == 'success']
    return h


for case in analysis['cohorts']:
    descriptor = case['descriptor']
    directory = RAW / f"{case['index']:03d}-{descriptor['arm']}"
    metrics = {side: read(directory / f'{side}-metrics.json') for side in ['before', 'after']}
    status = {side: read(directory / f'{side}-status.json') for side in ['before', 'after']}
    report = read(directory / 'run/report.json')
    config = read(directory / 'run/config.json')
    assert config == report['configuration'] and report['complete']
    totals = {p: dict(count_delta=0, sum_ns_delta=0) for p in phases}
    counters = {k: 0 for k in counter_names}
    nodes = []
    for node in ['1', '2', '3']:
        expected, = [n for n in case['lifecycle']['nodes'] if n['node_id'] == node]
        sb, sa = status['before'][node], status['after'][node]
        for key in ['pid', 'process_start_ticks', 'process_boot_id', 'node_id', 'cluster_id', 'bootstrap_generation', 'store_incarnation']:
            assert sb[key] == sa[key]
        assert sb['pid'] == expected['pid'] and sb['process_start_ticks'] == expected['start_ticks']
        nd = dict(node_id=node, pid=sb['pid'], start_ticks=sb['process_start_ticks'], boot_id=sb['process_boot_id'], phases={}, counters={})
        for phase in phases:
            b, a = hist(metrics['before'][node], phase), hist(metrics['after'][node], phase)
            delta = dict(count_delta=a['count'] - b['count'], sum_ns_delta=a['sum_ns'] - b['sum_ns'])
            ep, = [v for v in expected['phases'] if v['phase'] == phase]
            assert all(delta[k] == ep[k] and delta[k] >= 0 for k in delta)
            assert b['count'] == ep['before_count'] and a['count'] == ep['after_count']
            nd['phases'][phase] = delta
            for k in delta:
                totals[phase][k] += delta[k]
        for k in counter_names:
            key = 'raft_async_read_' + k
            b, a = int(sb[key]), int(sa[key])
            assert a >= b
            nd['counters'][k] = dict(before=b, after=a, delta=a-b)
            counters[k] += a-b
        nodes.append(nd)
    for phase in phases:
        expected, = [v for v in case['lifecycle']['phases'] if v['phase'] == phase]
        assert all(totals[phase][k] == expected[k] for k in totals[phase])
        totals[phase]['mean_us'] = totals[phase]['sum_ns_delta'] / totals[phase]['count_delta'] / 1000
        totals[phase]['share_percent'] = 100 * totals[phase]['sum_ns_delta'] / totals['total']['sum_ns_delta']
    assert len({v['count_delta'] for v in totals.values()}) == 1
    assert sum(totals[p]['sum_ns_delta'] for p in phases[:-1]) == totals['total']['sum_ns_delta']
    populations = {}
    for phase, metric in report['metrics'].items():
        populations[phase] = []
        for operation, stat in zip(metric['operations'], metric['statistics'], strict=True):
            outcomes = {name: p['calls'] for name, p in zip(metric['outcomes'], stat['populations'], strict=True)}
            attempts = {name: h['raw']['count'] for name, h in zip(metric['attempt_outcomes'], stat['attempts'], strict=True)}
            op = dict(operation=operation, calls=sum(outcomes.values()), outcomes=outcomes,
                      attempts=sum(attempts.values()), attempt_outcomes=attempts,
                      reasons=dict(zip(metric['reasons'], stat['reasons'], strict=True)),
                      attempt_reasons=dict(zip(metric['reasons'], stat['attempt_reasons'], strict=True)),
                      whole_call_sum_ns=sum(p['whole_call']['raw']['sum_ns'] for p in stat['populations']))
            populations[phase].append(op)
            if phase == 'measurement':
                expected, = [v for v in case['runtime']['operations'] if v['operation'] == operation]
                for k in ['calls', 'outcomes', 'attempts', 'reasons', 'attempt_reasons']:
                    assert op[k] == expected[k]
                assert op['whole_call_sum_ns'] == expected['whole_call_latency']['sum_ns']
    measured = populations['measurement']
    assert sum(x['calls'] for x in measured) == report['measured_issued'] == report['measured_completed'] == case['runtime']['measured_calls']
    counters['members_per_admitted_group'] = counters['admitted_members'] / counters['admitted_groups']
    counters['attempts_minus_admitted_groups'] = counters['group_attempts'] - counters['admitted_groups']
    counters['reported_all_phase_read_calls'] = sum(op['calls'] for ps in populations.values() for op in ps if op['operation'] in ['get', 'batch_get'])
    counters['admitted_members_minus_reported_all_phase_reads'] = counters['admitted_members'] - counters['reported_all_phase_read_calls']
    rows.append(dict(arm=descriptor['arm'], workers=config['workers'], read_percent=config['read_percent'],
                     run_id=config['run_id'], phases=totals, nodes=nodes, group_envelope=counters,
                     populations=populations, measurement=dict(issued=report['measured_issued'], completed=report['measured_completed'],
                     dropped_slots=report['dropped_slots'], stop_reason=report['stop_reason'], elapsed_ns=report['cohort_elapsed_ns']),
                     snapshot_coverage=case['lifecycle']['snapshot_coverage']))

differences = {}
for phase in phases:
    crc, credit = rows[2]['phases'][phase], rows[3]['phases'][phase]
    difference = Fraction(credit['sum_ns_delta'], credit['count_delta']) - Fraction(crc['sum_ns_delta'], crc['count_delta'])
    differences[phase] = dict(mean_ns_difference_numerator=difference.numerator, mean_ns_difference_denominator=difference.denominator,
        mean_us_credit_minus_crc=float(difference)/1000, share_percentage_points_credit_minus_crc=credit['share_percent']-crc['share_percent'],
        mean_change_percent=100*float(difference)/float(Fraction(crc['sum_ns_delta'],crc['count_delta'])))
assert sum(Fraction(differences[p]['mean_ns_difference_numerator'], differences[p]['mean_ns_difference_denominator']) for p in phases[:-1]) == Fraction(differences['total']['mean_ns_difference_numerator'], differences['total']['mean_ns_difference_denominator'])
for path, value in inputs.items():
    if path not in [str(PREP / 'results-first/input-inventory.json'), str(PREP / 'results-first/analysis.json')]:
        assert inventory[path] == value, path
measured_ops = [op for r in rows for op in r['populations']['measurement']]
all_ops = [op for r in rows for phase in r['populations'].values() for op in phase]
def total(ops):
    return dict(calls=sum(v['calls'] for v in ops), attempts=sum(v['attempts'] for v in ops),
                outcomes={k:sum(v['outcomes'][k] for v in ops) for k in ops[0]['outcomes']},
                attempt_reasons={k:sum(v['attempt_reasons'][k] for v in ops) for k in ops[0]['attempt_reasons']})
result = dict(raw_integer_deltas_match_analysis=True, runtime_session=63422, runtime_exit_code=0,
              accepted_readback_session_parent_supplied=94688, accepted_readback_exit_code_parent_supplied=0,
              scope='Four instrumented five-second diagnostic cohorts; sampled successful read stages cover the drained whole-client envelope, not measurement-only or pure RTT.',
              arithmetic={'delta':'after - before, summed over the same three voter lifetimes','mean_us':'sum_ns_delta / count_delta / 1000','share_percent':'100 * stage_sum_ns / total_sum_ns','amortization':'delta_admitted_members / delta_admitted_groups'},
              rows=rows, mixed_credit_minus_crc=differences, measured_totals=total(measured_ops), all_client_phase_totals=total(all_ops),
              accepted_lifetime_scope={k:analysis[k] for k in ['owned_lifetimes_exited','fresh_drain_documents','voter_listener_bindings','retained_bytes','retained_files','outer_restoration']},
              source_build_bindings=bindings, inputs=inputs)
with (OUT/'summary.json').open('x') as f:
    json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'rows':[{'arm':r['arm'],'samples':r['phases']['total']['count_delta'],'means_us':{p:v['mean_us'] for p,v in r['phases'].items()},'groups':r['group_envelope'],'measurement':r['measurement'],'operations':[{k:o[k] for k in ['operation','calls','attempts','outcomes']} for o in r['populations']['measurement']]} for r in rows], 'mixed_difference':differences,'measured':result['measured_totals'],'all_phases':result['all_client_phase_totals']},indent=2))
