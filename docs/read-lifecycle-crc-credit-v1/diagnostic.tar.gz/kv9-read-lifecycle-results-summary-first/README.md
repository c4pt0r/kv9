# Fresh read lifecycle diagnostic summary

Independent arithmetic agrees exactly with the accepted analysis for every node and all four cohorts: before/after integer counts and nanosecond sums, aggregate populations, and stage-sum conservation. This is a four-cell instrumented diagnostic, with one five-second recording per cell; it does not support performance promotion, a pure network RTT estimate, or causal isolation of the credit mechanism.

CRC is diagnostic revision `aee183effb1fe4ddf0733eed3844d91255f332b1`; credit is `f19fdfb014699da98ec45f790cd26c155b1d5461`. The shared native client remains `0be806d9671e2c50701a64aa7889c8859b7648ba`. All cells use point GET/PUT, 4,096 keys plus sentinel, 128-byte values, seed 71, 128 warmup calls and a 1,500 ms deadline. c1 is read-only; c64 is configured 50% reads.

The stage populations are sampled successful reads over the drained whole-client envelope, including initialization, warmup, measurement and verification. Before/after captures also bracket final fixture readback; exact status admitted-member deltas equal the reported all-phase client read counts in every cell. Neither this equality nor the sample totals identify a measurement-only sample set or individual request ledger.

Each stage cell below is mean microseconds followed by its share of sampled total duration. Mean = summed stage nanoseconds / sampled count / 1,000; share = stage sum / total sum.

| Cell | Samples | Queue µs (%) | Quorum µs (%) | Apply µs (%) | Notification µs (%) | Total µs |
|---|---:|---:|---:|---:|---:|---:|
| crc-c1 | 2,229 | 1.438 (5.923%) | 20.887 (86.010%) | 0.284 (1.168%) | 1.676 (6.900%) | 24.285 |
| credit-c1 | 2,139 | 1.443 (5.966%) | 20.767 (85.862%) | 0.277 (1.144%) | 1.700 (7.027%) | 24.186 |
| crc-c64 | 6,759 | 19.893 (7.275%) | 168.753 (61.712%) | 28.738 (10.509%) | 56.070 (20.504%) | 273.454 |
| credit-c64 | 6,972 | 82.557 (27.609%) | 142.385 (47.617%) | 20.476 (6.848%) | 53.604 (17.927%) | 299.022 |

Mixed CRC→credit stage-mean changes are **+62.664 µs queue, −26.369 µs quorum, −8.262 µs apply, −2.465 µs notification**, giving **+25.568 µs total (+9.350%)**. Queue share rises from 7.275% to 27.609% (+20.334 percentage points). The quorum-stage reduction accompanies a larger queue-stage increase in these observations; it does not prove lower network RTT. The stages include owner scheduling, callback/pump work, apply coverage and notification delay at their defined boundaries. Stage percentiles cannot be added.

Measurement-only client populations are separate from the stage table. Every issued call completed, every measured call had one successful attempt, and all refused, unknown-write, read-failure and client-rejected populations and dropped slots were zero. These counts are diagnostic accounting, not throughput acceptance.

| Cell | Measured GET calls | Measured PUT calls | Total issued = completed = attempts |
|---|---:|---:|---:|
| crc-c1 | 132,261 | 0 | 132,261 |
| credit-c1 | 132,831 | 0 | 132,831 |
| crc-c64 | 424,518 | 425,936 | 850,454 |
| credit-c64 | 434,691 | 436,077 | 870,768 |

**Measured total: 1,986,314 calls and attempts, all success.** Across all client phases there were 2,035,990 successful logical calls and 2,035,994 attempts: four initialization `not_leader` attempts preceded successful completion (one per cohort). Those safe routing attempts are retained and are not hidden as single-attempt all-phase execution.

Read-group amortization uses the same whole-envelope status snapshots and unchanged process identities. The ratio is admitted members / admitted groups, not measured-only calls / group. “Unadmitted attempts” below is strictly group_attempts − admitted_groups; it is not a count of unique requests, elapsed waits, or exclusively capacity refusals.

| Cell | Admitted members | Admitted groups | Members/group | Group attempts | Unadmitted attempts | Inspected members |
|---|---:|---:|---:|---:|---:|---:|
| crc-c1 | 140,583 | 140,583 | 1.0000 | 140,584 | 1 | 140,584 |
| credit-c1 | 141,153 | 141,153 | 1.0000 | 141,154 | 1 | 141,154 |
| crc-c64 | 432,787 | 137,637 | 3.1444 | 137,638 | 1 | 432,788 |
| credit-c64 | 442,960 | 43,252 | 10.2414 | 217,424 | 174,172 | 1,898,422 |

The accepted independent readback retains 16 exited process lifetimes, 12 fresh drain documents, 12 voter listener bindings, 156 retained files / 1,004,813,947 bytes, and exact configured/effective CPU restoration for three containers with namespace maps preserved. This summary reuses that accepted lifecycle/retention verdict; it adds only raw endpoint arithmetic and client population comparison. It does not rerun fixture validation, CPU profiling or runtime.

Runtime session 63422 exited 0 (parent receipt `c06869`); accepted independent readback session 94688 exited 0 (parent receipt `632a75`). This arithmetic pass exited 0 (`3248b1`). The first arithmetic attempt exited 1 (`4d530d`) because it requested the inventory entry for `run/config.json`; that file exists but the accepted inventory binds `requested-config.json`. The preserved correction changes only that input path after confirming equality for all four cohorts. The original failed script/log remain retained.

`summary.json` stores all exact stage integers, rational mixed mean differences, per-node status counters/identities, full phase outcome/reason populations and absolute input-path byte/hash bindings. Every raw derivation input matches the accepted input inventory. `derive.py` is the finite arithmetic source; no frozen source or original evidence was edited.

- Summary SHA-256: `87826f2224fc287284941d3b5c650ab099fbf82186667ce7dd97a281688f3182`
- Arithmetic source SHA-256: `cb6b7988017a0074230d6964ed264caa0b86ae68a5a3eeddb1b56eb5af8b5f56`
- Accepted analysis SHA-256: `eef7366f18adf541fde5cceb9a1443a7891d559439e3a083b8debaaf6027abd1`
