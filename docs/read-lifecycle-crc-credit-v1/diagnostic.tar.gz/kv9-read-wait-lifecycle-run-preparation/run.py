#!/usr/bin/env python3
"""Four source-bound native lifecycle fixtures; no perf or throughput acceptance."""
import argparse
import json
import os
from pathlib import Path
import signal
import sys
import time
from types import SimpleNamespace

from common import HERE, dependencies, modules, preflight, read, sha
from contract import (CLIENT_BUILD, CLIENT_REVISION, CLIENT_SOURCE, OBSERVER_CPUS,
                      PROTOCOL_ID, check_protocol, descriptors, require)


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    require(__debug__, 'assertions required')
    sys.dont_write_bytecode = True
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--bindings', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--isolation-snapshot', type=Path, required=True)
    args = parser.parse_args()
    require(sorted(os.sched_getaffinity(0)) == OBSERVER_CPUS, 'observer CPU mask differs')
    output = args.output.resolve()
    pins = read(args.bindings)
    for directory in [HERE, Path(CLIENT_SOURCE), Path(CLIENT_BUILD)] + [Path(b[k]) for b in pins for k in ['path', 'output']]:
        require(not output.is_relative_to(directory.resolve()), 'output overlaps retained source/build/preparation')
    output.mkdir(parents=True, exist_ok=False)
    result = dict(complete=False, instrumented=True, throughput_acceptance=False, cpu_profiling=False, cohorts=[])
    def interrupted(signum, _frame):
        raise RuntimeError('lifecycle recording interrupted by signal ' + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        driver = dependencies()
        roles = preflight(pins, driver)
        loaded, helpers = modules(roles, driver)
        isolation = read(args.isolation_snapshot)
        require(isolation['complete'] is True and isolation['exclusive_host'] is False and
                isolation['measured_client_cpus'] == [0, 1] and isolation['measured_server_cpus'] == [2, 3, 4, 5] and
                isolation['background_cpus'] == OBSERVER_CPUS and isolation['driver_sha256'] == sha(__file__),
                'owned outer isolation differs')
        driver.placement = lambda _: dict(client_cpus=[0, 1], server_cpus=[2, 3, 4, 5], separated=True, exclusive_host=False)
        helpers.update({str(p): sha(p) for p in HERE.glob('*.py')})
        helpers[str(args.bindings.resolve())] = sha(args.bindings)
        protocol = dict(version=1, protocol_id=PROTOCOL_ID, instrumented=True,
            throughput_acceptance=False, cpu_profiling=False, cohorts=descriptors(), storage='tmpfs',
            placement=driver.placement(True), observer_cpus=OBSERVER_CPUS, storage_guards=driver.SPACE_GUARDS,
            role_bindings=roles, helper_hashes=helpers, isolation_snapshot=isolation,
            isolation_snapshot_sha256=sha(args.isolation_snapshot), binding_file=str(args.bindings.resolve()),
            binding_sha256=sha(args.bindings), metric_scope='Sampled successful whole-client read envelope; no per-request causal decomposition')
        check_protocol(protocol)
        save(output / 'protocol.json', protocol)
        save(output / 'build-bindings.json', pins)
        save(output / 'summary.json', result)
        (output / 'driver.py').write_bytes(Path(__file__).read_bytes())
        (output / 'isolation-snapshot.json').write_bytes(args.isolation_snapshot.read_bytes())
        retained = output / 'retained-inputs'
        retained.mkdir()
        for name, binding in roles.items():
            destination = retained / name
            destination.mkdir()
            for i, (path, expected) in enumerate(binding['evidence'].items()):
                copied = destination / f'{i:02d}-{Path(path).name}'
                copied.write_bytes(Path(path).read_bytes())
                require(sha(copied) == expected, 'copied role evidence differs')
        fixture_args = SimpleNamespace(smoke=True, storage='tmpfs', client_build=Path(CLIENT_BUILD),
                                       expected_client_revision=CLIENT_REVISION)
        for ordinal, row in enumerate(descriptors()):
            directory = output / f'{ordinal:03d}-{row["arm"]}'
            directory.mkdir()
            entry = dict(index=ordinal, descriptor=row, directory=str(directory), complete=False)
            result['cohorts'].append(entry)
            save(output / 'summary.json', result)
            save(directory / 'profile-plan.json', row)
            space = driver.storage_observation(directory)
            save(directory / 'storage-preflight.json', space)
            try:
                driver.require_storage(space, 'preflight')
            except ValueError:
                save(directory / 'storage-guard-intervention.json', dict(phase='preflight', observation=space,
                    thresholds=driver.SPACE_GUARDS['preflight'], timing_complete=False))
                raise
            print('START: ' + directory.name, flush=True)
            observed = driver.native_trial(row, directory, fixture_args, loaded, roles)
            save(directory / 'fixture-result.json', observed)
            save(directory / 'summary.json', observed)
            entry.update(observed)
            save(output / 'summary.json', result)
            require(observed['complete'], 'native lifecycle fixture failed; preserve original attempt')
            print('TERMINAL: ' + directory.name, flush=True)
        require(preflight(pins, driver) == roles and all(sha(p) == h for p, h in helpers.items()),
                'frozen role/helper inputs changed')
        result['complete'] = True
    except BaseException as error:
        result['failure'] = repr(error)
        raise
    finally:
        result['ended_unix_ns'] = time.time_ns()
        save(output / 'summary.json', result)
    print('PASS: four lifecycle fixtures terminal; independent readback pending', flush=True)


if __name__ == '__main__':
    main()
