"""Finite offline contracts: no server, Cargo, Docker, perf or runtime auditor."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import unittest

import contract as c
import common
import lifecycle_checks
import native_checks as n

HERE = Path(__file__).resolve().parent


class Contracts(unittest.TestCase):
    def test_four_explicit_cells_and_no_perf_scope(self):
        rows = c.descriptors()
        self.assertEqual([(r['server_role'], r['shared']['workers'], r['shared']['read_percent']) for r in rows],
                         [('crc', 1, 100), ('credit', 1, 100), ('crc', 64, 50), ('credit', 64, 50)])
        self.assertEqual(len({r['shared']['run_id'] for r in rows}), 4)
        p = dict(version=1, protocol_id=c.PROTOCOL_ID, instrumented=True, throughput_acceptance=False,
            cpu_profiling=False, cohorts=rows, storage='tmpfs', observer_cpus=c.OBSERVER_CPUS,
            placement=dict(client_cpus=[0, 1], server_cpus=[2, 3, 4, 5], separated=True, exclusive_host=False))
        c.check_protocol(p)
        for key, value in [('cpu_profiling', True), ('throughput_acceptance', True),
                           ('cohorts', rows[::-1]), ('event', 'cpu-clock')]:
            bad = copy.deepcopy(p); bad[key] = value
            with self.assertRaises(ValueError): c.check_protocol(bad)

    def test_independent_config_accepts_four_real_v3_configurations(self):
        driver = common.dependencies()
        peers = [dict(node_id=i, address=f'127.0.0.1:{21000+i}') for i in [1, 2, 3]]
        for row in c.descriptors():
            config, _ = driver.configs(row, peers, 8, '127.0.0.1:6379')
            report = dict(configuration=copy.deepcopy(config), config_sha256='test-hash',
                build=dict(revision=c.CLIENT_REVISION, binary_sha256=c.CLIENT_SHA, profile='release', dirty=False))
            c.check_config(row, config, report, 'test-hash')
            for key, value in [('version', 2), ('read_api', 'batch_get'), ('write_api', 'batch_put'),
                               ('workers', 2), ('batch_size', 64), ('measure_ms', 10000)]:
                bad = copy.deepcopy(config); bad[key] = value
                with self.assertRaises(ValueError): c.check_config(row, bad, report, 'test-hash')
            bad = copy.deepcopy(config); bad['client']['max_in_flight'] += 1
            with self.assertRaises(ValueError): c.check_config(row, bad, report, 'test-hash')

    def test_exact_pending_or_historical_builds_refused(self):
        good = json.loads((HERE / 'root-build-bindings.json').read_text())
        c.check_bindings(good)
        for key, value in [('binary_sha256', None), ('complete', False), ('exit_code', 1),
                           ('path', '/tmp/kv9-rpc-pair-read-profile'), ('first_observed_units', 0)]:
            bad = copy.deepcopy(good); bad[0][key] = value
            with self.assertRaises(ValueError): c.check_bindings(bad)

    def test_fixture_and_metric_checker_bytes_unchanged(self):
        self.assertEqual(common.sha(HERE / 'v3_fixture.py'), common.FIXTURE_SHA)
        self.assertEqual(common.sha(HERE / 'latency_metrics.py'), c.CHECKER_SHA)
        self.assertEqual(len(lifecycle_checks.checker.NAMES), 31)
        for p in HERE.glob('*.py'):
            ast.parse(p.read_text(), filename=str(p))

    def test_mutable_nonce_membership_and_sentinel(self):
        cfg = dict(run_id='fixture', keys=16, value_bytes=128, seed=71, warmup_calls=128,
                   max_calls=10000, batch_size=1, read_percent=50)
        dataset = {f'fixture:{i:016x}'.encode(): n.value(71, 128, i, 0) for i in range(17)}
        nonce = next(x for x in range(1, 100) if n.mix(71 ^ x) % 100 >= 50)
        index = n.mix(71 ^ nonce ^ 0xc6275c213842315b) % 16
        dataset[f'fixture:{index:016x}'.encode()] = n.value(71, 128, index, nonce)
        result = n.dataset_check(cfg, dataset)
        self.assertEqual(result['changed_keys'], 1)
        self.assertFalse(result['exact_issued_nonce_set_checked'])
        self.assertFalse(result['full_history_checked'])
        for key in [f'fixture:{16:016x}'.encode(), f'fixture:{(index+1)%16:016x}'.encode()]:
            bad = dict(dataset); at = int(key.split(b':')[1], 16); bad[key] = n.value(71, 128, at, nonce)
            with self.assertRaises(ValueError): n.dataset_check(cfg, bad)

    def test_original_endpoint_fixture_passes_sample_conservation(self):
        fixture = json.loads((HERE / 'contract-fixture.json').read_text())
        result = lifecycle_checks.check_lifecycle(Path('/contract'), lambda p: copy.deepcopy(fixture[p.name]), {})
        self.assertEqual(result['samples'], 2141)
        self.assertEqual(result['phases'][-1]['sum_ns_delta'], 52343996)

    def test_endpoint_identity_drain_and_population_mutants_fail(self):
        fixture = json.loads((HERE / 'contract-fixture.json').read_text())
        def change_pid(x): x['after-metrics.json']['1']['process_id'] += 1
        def stop_registry(x): x['post-client-fresh-drain.json']['final']['1']['raft_async_read_stopped'] = 'true'
        def stale_export(x):
            d = x['post-client-fresh-drain.json']; d['final']['1']['metrics_export_successes'] = d['baseline']['1']['metrics_export_successes']
        def wrong_partition(x):
            h = lifecycle_checks.checker.histogram(x['after-metrics.json']['1'], 'raft_async_read_profile_total')
            h['sum_ns'] += 1
        for mutation in [change_pid, stop_registry, stale_export, wrong_partition]:
            bad = copy.deepcopy(fixture); mutation(bad)
            with self.assertRaises((ValueError, AssertionError)):
                lifecycle_checks.check_lifecycle(Path('/contract'), lambda p: copy.deepcopy(bad[p.name]), {})

    def test_outcome_populations_not_dropped_or_retried_into_success(self):
        config = dict(version=3, read_api='point_get', write_api='point_put', seed=71,
                      warmup_calls=0, read_percent=50)
        report = dict(version=3, workload_model='bounded_native_api_performance', measured_issued=3,
            metrics={})
        for phase in ['initialization', 'warmup', 'measurement', 'verification']:
            report['metrics'][phase] = dict(operations=['get','put'] if phase in ['warmup','measurement'] else ['batch_get','batch_put'],
                statistics=[dict(populations=[dict(calls=0),dict(calls=0)]) for _ in range(2)])
        # Mixed population includes a non-success call; the API-shape check
        # must not delete it or require the report to become all-success.
        report['metrics']['measurement']['statistics'][0]['populations'][0]['calls'] = 1
        report['metrics']['measurement']['statistics'][1]['populations'][1]['calls'] = 2
        n.validate_phase_apis(report, config, True)
        bad = copy.deepcopy(report); bad['metrics']['measurement']['statistics'][1]['populations'][1]['calls'] = 0
        with self.assertRaises(ValueError): n.validate_phase_apis(bad, config, True)


if __name__ == '__main__':
    unittest.main()
