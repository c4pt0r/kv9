# Four-cohort read lifecycle runner and independent readback

This preparation records CRC and read-credit diagnostics at c1 pure point GET
and c64 point GET/PUT (50% reads), once per cell. Both diagnostic releases are
original clean/default builds supplied by root; the unchanged 0be v3 native
client supplies actual GET/PUT requests. No Redis, CPU profiler or throughput
acceptance is part of this run. A `client_timing_eligible` flag in the original
client report does not select this instrumented server as a performance build.

`commands.json` contains the exact root launch command and a separate readback
command whose terminal-session placeholder must be replaced only after the
recording and wrapper cleanup finish. All commands require assertions and no
bytecode, with helpers on CPUs 6–15,22–31. Actual client CPUs are 0–1 and voters
share 2–5. The wrapper restricts/restores only the three existing owned containers
and preserves historical namespace identities; unrelated host work remains
unconstrained. No runtime command was executed during preparation.

`v3_fixture.py` is a byte-identical copy of the accepted v3 matched driver. The
small `run.py` calls its `native_trial` directly, overriding only placement as
the accepted lifecycle-only runner did and passing `smoke=True` to suppress
performance acceptance. The four descriptors, source/build preflight and free
space preflight are explicit. Every original per-client resource/storage guard,
fresh drain, final scan, retention and owned cleanup runs unchanged. The full
72-cohort main and Redis paths are never called.

`native_checks.py` extracts the already accepted independent native checks.
Its source functions and case checks retain outcome/attempt accounting, real
exit identities, listeners/mounts, resource sampling, allocator/environment
absence, free-space callbacks, mutable final values and retained-data hashes.
The changes replace broad-matrix configuration lookup with independent four-cell
v3 validation and use `require_timing=False`; duration/cap/population checks
remain. All outcomes stay visible. Healthy single-attempt traffic is reported
separately, not manufactured by deleting failures. Final mutable values prove
bounded deterministic write/key membership, not an exact issued nonce ledger.

`lifecycle_checks.py` retains the historical c1 reader's complete per-cohort
metric/status/resource identity, fresh-drain/capture ordering, common successful
population and integer conservation checks. It uses an unchanged 31-name
`latency_metrics.py`. `readback.py` independently combines those checks with
source/build binding, original outer restoration, exact four-cell order and
fixed public/read/apply limits. It requires the completed recording, all 16
owned fixture lifetimes exited, 12 fresh-drain documents and 12 voter/listener
bindings. Historical parent counts are not substituted for new observations.

The independently checked five histograms are queue, invocation-to-confirmation,
confirmation-to-send, notification and total. They cover successfully received
read samples across the drained client envelope, including setup/warmup/
verification and final readback as applicable. The four integer stage sums must
equal total for the identical successful sample population. Metric snapshots
must be quiescent. No per-request/group/RPC ID or workload-phase tag is exported;
credit wait versus other queueing, exact network/quorum completion and remaining
backend/RPC return are not isolated. Do not add percentiles, subtract these
stages from a separate uninstrumented client mean, or infer failure latency from
successful traces. All original reports and unknown/refused outcomes remain.

`reuse.json` identifies the exact sources and bounded extraction changes.
`wrapper.diff` shows only allowed argument-schema changes; isolation, process
group cleanup, identity and restoration code is unchanged. `source-preflight-
first.json` records the completed read-only original-build/source check. Eight
offline contracts passed on their first run; they exercise positive schema,
source/config refusal, mixed outcomes, deterministic mutable values and real
historical endpoint-fixture identity/drain/conservation mutations. That fixture
is contract test input, not new diagnostic evidence.

First failures are retained. Runtime, reader and output directories must be new;
do not alter predicates or rerun a failed fixture to obtain acceptance. Root owns
all launch decisions, actual session/terminal receipts and source/runtime work.
