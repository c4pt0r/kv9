"""Retained dependency and original source/build binding; never launches a workload."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

from contract import (CHECKER_SHA, CLIENT_BUILD, CLIENT_MANIFEST_SHA, CLIENT_REVISION,
                      CLIENT_SHA, CLIENT_SOURCE, check_bindings, require)

HERE = Path(__file__).resolve().parent
FIXTURE_SHA = 'cbbd6db65e668db0c46d0a2b564693f551e2a4137127bae3ed58897d633ad195'
RESP = Path('/tmp/kv9-redis-batch-reference-preparation/run_fixture.py')
RESP_SHA = '008c5bea0640a4a5a092feb6617798a84e9dd4889fd11bf8c6791cfe0852864a'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def dependencies():
    require(sha(HERE / 'v3_fixture.py') == FIXTURE_SHA and sha(RESP) == RESP_SHA and
            sha(HERE / 'latency_metrics.py') == CHECKER_SHA, 'unchanged dependency bytes differ')
    return module('retained_v3_fixture', HERE / 'v3_fixture.py')


def preflight(bindings, driver):
    check_bindings(bindings)
    roles = {}
    for pin in bindings:
        source, build = Path(pin['path']), Path(pin['output'])
        manifest = read(build / 'build.json')
        require(sha(build / 'build.json') == pin['manifest_sha256'], 'diagnostic manifest pin differs')
        source_binding = driver.source_binding(source, manifest, pin['revision'])
        require(len(source_binding['sources']) == pin['source_count'], 'diagnostic source count differs')
        require(manifest['binaries']['kv9']['command'] == driver.SERVER_COMMAND and
                sha(build / 'kv9') == manifest['binaries']['kv9']['sha256'] == pin['binary_sha256'],
                'actual diagnostic server differs')
        cargo = driver.cargo_server(build / 'kv9-cargo.jsonl')
        require(sha(source / 'scripts/check-latency-metrics.py') == CHECKER_SHA,
                'diagnostic 31-metric source checker differs')
        receipt = read(build / 'cache-safety.json')
        require(sha(build / 'cache-safety.json') == pin['cache_receipt_sha256'] and
                receipt['complete'] is True and receipt['invalidation_complete'] is True and
                receipt['source_root'] == str(source), 'original safe build receipt differs')
        require(all(c['exit_code'] == 0 for c in receipt['commands']) and
                sum(c['argv'][1] == 'clean' for c in receipt['commands']) == 1,
                'original build command/clean failed')
        first = [a for a in receipt['first_party_artifacts'] if not a['seen_after_invalidation']]
        require(len(first) == pin['first_observed_units'] and all(a['fresh'] is False for a in first),
                'first-party artifact was not rebuilt')
        roles[pin['role']] = dict(revision=pin['revision'], source=source_binding,
            build_directory=str(build), binary_sha256=pin['binary_sha256'], cargo_artifacts=cargo,
            evidence={str(build / name): sha(build / name) for name in
                      ['build.json', 'kv9-cargo.jsonl', 'cache-safety.json']})
    source, build = Path(CLIENT_SOURCE), Path(CLIENT_BUILD)
    manifest, inventory = read(build / 'build.json'), read(build / 'sources.json')
    require(sha(build / 'build.json') == CLIENT_MANIFEST_SHA and sha(build / 'kv9-batch-benchmark') ==
            manifest['binary_sha256'] == CLIENT_SHA, 'fixed client artifact differs')
    require(all(inventory[k] == manifest[k] for k in
                ['revision', 'dirty', 'source_tree_sha256', 'binary_sha256']), 'client source/build mismatch')
    bound = driver.source_binding(source, dict(manifest, sources=inventory['sources']), CLIENT_REVISION)
    roles['client'] = dict(revision=CLIENT_REVISION, source=bound, build_directory=str(build),
        binary_sha256=CLIENT_SHA, evidence={str(build / name): sha(build / name)
                                          for name in ['build.json', 'sources.json', 'cargo.jsonl']})
    require(sha(Path(bindings[0]['path']) / 'crates/raft/src/read_profile.rs') ==
            sha(Path(bindings[1]['path']) / 'crates/raft/src/read_profile.rs'), 'sampling implementations differ')
    return roles


def modules(roles, driver):
    source = Path(CLIENT_SOURCE)
    sys.path.insert(0, str(source / 'scripts'))
    import benchmark
    import batch_benchmark_report as native
    import redis_batch_report as paired
    support = module('native_lifecycle_support', source / 'scripts/native-batch-e2e.py')
    tmpfs = module('native_lifecycle_tmpfs', source / 'scripts/tmpfs-redis-diagnostic.py')
    comparison = module('native_lifecycle_resources', source / 'scripts/redis-comparison.py')
    resp = module('native_lifecycle_resp', RESP)
    _, manifest, features = native.build_check(Path(CLIENT_BUILD), Path(CLIENT_BUILD), CLIENT_REVISION)
    require(features == [] and manifest['profile'] == 'release', 'client is not default release')
    helpers = {str(RESP): RESP_SHA}
    for imported in list(sys.modules.values()) + [support, tmpfs, comparison, paired]:
        filename = getattr(imported, '__file__', None)
        if filename:
            file = Path(filename).resolve()
            if file.is_relative_to(source):
                require(sha(file) == roles['client']['source']['sources'][str(file.relative_to(source))],
                        'imported client source differs')
                helpers[str(file)] = sha(file)
    return (benchmark, support, tmpfs, comparison, resp, native, paired), helpers
