#!/usr/bin/env python3
import importlib.util
import json
import os
from pathlib import Path
import time
SOURCE = Path('/tmp/kv9-read-credit-window-two')
OUT = Path('/tmp/kv9-read-window-controls-first')
RUNS = OUT / 'controls'
os.environ['CARGO_TARGET_DIR'] = '/home/dongxu/kv9/target'
os.environ['CARGO_BUILD_JOBS'] = '4'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')
def main():
    OUT.mkdir()
    spec = importlib.util.spec_from_file_location('window_builder', SOURCE / 'scripts/build-workload.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    before = builder.snapshot()
    save(OUT / 'sources-before.json', before)
    command = ['python3', '-B', str(SOURCE / 'scripts/check-async-read-controls.py'), '--output', str(RUNS), '--cargo-target', '/home/dongxu/kv9/target', '--timeout-seconds', '600']
    result = dict(complete=False, started_ns=time.time_ns(), argv=command)
    try:
        with builder.cache.BuildCache(SOURCE, OUT, False, before) as cache:
            with (OUT / 'controls.stdout').open('x') as stdout, (OUT / 'controls.stderr').open('x') as stderr:
                result['exit_code'] = cache.run(command, stdout=stdout, stderr=stderr, timeout=2400).returncode
            manifest = json.loads((RUNS / 'manifest.json').read_text())
            assert manifest['accepted'] and len(manifest['controls']) == 14
            for case in manifest['controls']:
                assert case['accepted'] and len(case['runs']) == 3
                for phase in ('baseline', 'mutant', 'restored'):
                    log = (RUNS / case['name'] / (phase + '.log')).read_text()
                    artifacts = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
                    raft = [a for a in artifacts if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'kv9_raft' and a['profile']['test'] and a.get('executable')]
                    assert len(raft) == 1 and raft[0]['fresh'] is False, (case['name'], phase, 'stale test executable')
            after = builder.snapshot()
            save(OUT / 'sources-after.json', after)
            assert after == before, 'source changed during semantic controls'
            result.update(complete=True, control_triples=14, all_42_raft_test_units_freshly_compiled=True)
    except BaseException as error:
        result['failure'] = repr(error)
        raise
    finally:
        result['ended_ns'] = time.time_ns()
        save(OUT / 'result.json', result)
if __name__ == '__main__':
    main()
