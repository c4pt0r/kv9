#!/usr/bin/env python3
"""Root owns the shared Cargo target for the uninstrumented window candidate."""
import importlib.util
import json
import os
from pathlib import Path
import time

SOURCE = Path('/tmp/kv9-read-credit-window-two')
OUT = Path('/tmp/kv9-read-window-workspace-first')
os.environ['CARGO_TARGET_DIR'] = '/home/dongxu/kv9/target'
os.environ['CARGO_BUILD_JOBS'] = '4'


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    OUT.mkdir()
    spec = importlib.util.spec_from_file_location('window_builder', SOURCE / 'scripts/build-workload.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    before = builder.snapshot()
    save(OUT / 'sources-before.json', before)
    commands = [
        ('format', ['cargo', 'fmt', '--all', '--', '--check'], False),
        ('workspace-compile', ['cargo', 'test', '--locked', '--workspace', '--no-run', '--message-format=json-render-diagnostics'], True),
        ('workspace-tests', ['cargo', 'test', '--locked', '--workspace'], False),
        ('clippy', ['cargo', 'clippy', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings'], False),
    ]
    result = dict(complete=False, source_root=str(SOURCE), commands=[])
    save(OUT / 'result.json', result)
    try:
        with builder.cache.BuildCache(SOURCE, OUT, False, before) as cache:
            for name, command, artifact_check in commands:
                row = dict(name=name, argv=command, started_ns=time.time_ns())
                result['commands'].append(row)
                save(OUT / 'result.json', result)
                print(name, 'started', flush=True)
                with (OUT / (name + '.stdout')).open('x') as stdout, (OUT / (name + '.stderr')).open('x') as stderr:
                    code = cache.run(command, stdout=stdout, stderr=stderr, timeout=1200).returncode
                row.update(exit_code=code, ended_ns=time.time_ns())
                if artifact_check:
                    cache.check_artifacts(OUT / (name + '.stdout'))
                if builder.snapshot() != before:
                    raise RuntimeError('window candidate source changed during checks')
                save(OUT / 'result.json', result)
                print(name, 'passed', flush=True)
        result['complete'] = True
        save(OUT / 'sources-after.json', builder.snapshot())
    except BaseException as error:
        result['failure'] = repr(error)
        raise
    finally:
        save(OUT / 'result.json', result)


if __name__ == '__main__':
    main()
