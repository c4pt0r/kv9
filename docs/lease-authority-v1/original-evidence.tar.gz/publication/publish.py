from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

repo = Path('/home/dongxu/kv9')
work = Path(__file__).resolve().parent
accepted = Path('/tmp/kv9-lease-authority-acceptance-scheduled-witness-first')
summary = json.loads((accepted / 'summary.json').read_text())
assert summary['theorems'] == 27 and summary['obligations'] == 348
assert len(summary['records']) == 18
assert all(r['verdict'] in {'proved', 'expected rejection', 'exhausted', 'expected counterexample'}
           for r in summary['records'])
def sha(data):
    return hashlib.sha256(data).hexdigest()
for relative, digest in summary['sources'].items():
    assert sha((repo / relative).read_bytes()) == digest, relative

files = {}
def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink(), name
    data = path.read_bytes()
    assert len(data) <= 2 * 1024 * 1024, name
    files[name] = data
for relative in summary['sources']:
    add('source/' + relative, repo / relative)
for path in accepted.rglob('*'):
    relative = path.relative_to(accepted)
    if path.is_file() and not {'states', 'cache', 'auditor'} & set(relative.parts):
        add('acceptance/' + str(relative), path)
add('acceptance/runner.log', accepted.with_suffix('.log'))

roots = [Path('/tmp/kv9-lease-authority-proof-draft' + str(n)) for n in range(1, 7)]
roots += [Path('/tmp/kv9-lease-authority-' + suffix) for suffix in [
    'model-draft1', 'model-projection-first', 'instant-model-first',
    'symmetric-model-first', 'inventory-first', 'inventory-second']]
for root in roots:
    assert root.is_dir(), root
    for path in root.iterdir():
        if path.is_file():
            add('development/' + root.name + '/' + path.name, path)
failed = Path('/tmp/kv9-lease-authority-acceptance-first')
for path in failed.rglob('*'):
    relative = path.relative_to(failed)
    if path.is_file() and not {'states', 'cache', 'auditor'} & set(relative.parts):
        add('first-campaign/' + str(relative), path)
add('first-campaign/runner.log', failed.with_suffix('.log'))
fixture = Path('/tmp/kv9-leader-lease-chaos-reuse-first')
for path in fixture.iterdir():
    if path.is_file():
        add('chaos-fixture-review/' + path.name, path)
add('publication/publish.py', Path(__file__))

out = repo / 'docs/lease-authority-v1'
out.mkdir()
archive = out / 'original-evidence.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|') as tar:
            for name, data in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files)
    assert {m.name for m in members} == set(files)
    for m in members:
        assert m.isfile() and tar.extractfile(m).read() == files[m.name], m.name
inventory = {
    'archive': archive.name, 'archive_bytes': archive.stat().st_size,
    'archive_sha256': sha(archive.read_bytes()), 'files': len(files),
    'members': [{'name': name, 'bytes': len(data), 'sha256': sha(data)}
                for name, data in sorted(files.items())],
    'scope': 'Original source/log/audit/result files; TLC state stores and TLAPS caches excluded',
}
(out / 'inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
shutil.copyfile(accepted / 'summary.json', out / 'summary.json')
total = sum(p.stat().st_size for p in (repo / 'docs').rglob('original-evidence.tar.gz'))
assert total < 64 * 1024 * 1024, total
receipt = {k: v for k, v in inventory.items() if k != 'members'}
receipt['aggregate_archive_bytes'] = total
(work / 'readback.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
