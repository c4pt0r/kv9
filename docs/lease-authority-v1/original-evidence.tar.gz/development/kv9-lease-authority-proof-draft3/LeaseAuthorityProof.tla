---------------------- MODULE LeaseAuthorityProof ----------------------
EXTENDS LeaseAuthority, TLAPS

THEOREM LAQuorumIntersection ==
    \A a, b \in SUBSET LANodes : LAHasQuorum(a) /\ LAHasQuorum(b) => a \cap b # {}
<1>1. SUFFICES ASSUME NEW a \in SUBSET LANodes, NEW b \in SUBSET LANodes,
                     LAHasQuorum(a), LAHasQuorum(b)
              PROVE a \cap b # {}
    OBVIOUS
<1>2. PICK qa \in LAQuorums : qa \subseteq a
    BY <1>1 DEF LAHasQuorum
<1>3. PICK qb \in LAQuorums : qb \subseteq b
    BY <1>1 DEF LAHasQuorum
<1>4. PICK n \in qa \cap qb : TRUE
    BY <1>2, <1>3, LALegalInputs, SMT
<1> QED BY <1>2, <1>3, <1>4, SMT

THEOREM LAExpirySeparation ==
    \A t, d, x, y \in Nat : t < d /\ d <= x /\ x <= y /\ y <= t => FALSE
BY SMT

THEOREM LARecoveryCover ==
    \A expiry, t, span, quarantine, held \in Nat :
        expiry <= t + span /\ span <= quarantine => expiry <= LAMax(held, t + quarantine)
BY SMT DEF LAMax

THEOREM LAInvariantInit == LAInit => LAInvariant
BY LALegalInputs, SMT DEF LAInit, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAAdvanceStep == ASSUME LAInvariant, LAAdvance PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAAdvance, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAStartRoundStep == ASSUME LAInvariant, NEW r \in LARounds, LAStartRound(r) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAStartRound, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAGrantStep == ASSUME LAInvariant, NEW r \in LARounds, NEW q \in LANodes, NEW d \in LAGrantMin..LAGrantMax, LAGrant(r, q, d) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAGrant, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LADeliverStep == ASSUME LAInvariant, NEW r \in LARounds, NEW q \in LANodes, LADeliver(r, q) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LADeliver, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAActivateStep == ASSUME LAInvariant, NEW r \in LARounds, LAActivate(r) PROVE LAInvariant'
BY LALegalInputs, LAQuorumIntersection, LAExpirySeparation, LARecoveryCover, SMT DEF LAActivate, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LARevokeStep == ASSUME LAInvariant, LARevoke PROVE LAInvariant'
BY LALegalInputs, SMT DEF LARevoke, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LARearmStep == ASSUME LAInvariant, LARearm PROVE LAInvariant'
BY LALegalInputs, LAQuorumIntersection, LAExpirySeparation, LARecoveryCover, SMT DEF LARearm, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LACrashStep == ASSUME LAInvariant, NEW q \in LANodes, LACrash(q) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LACrash, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LARestartStep == ASSUME LAInvariant, NEW q \in LANodes, LARestart(q) PROVE LAInvariant'
BY LALegalInputs, LAQuorumIntersection, LAExpirySeparation, LARecoveryCover, SMT DEF LARestart, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAVoteStep == ASSUME LAInvariant, NEW q \in LANodes, LAVote(q) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAVote, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAElectStep == ASSUME LAInvariant, LAElect PROVE LAInvariant'
BY LALegalInputs, LAQuorumIntersection, LAExpirySeparation, LARecoveryCover, SMT DEF LAElect, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAOldCommitStep == ASSUME LAInvariant, LAOldCommit PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAOldCommit, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LANewCommitStep == ASSUME LAInvariant, LANewCommit PROVE LAInvariant'
BY LALegalInputs, SMT DEF LANewCommit, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAApplyStep == ASSUME LAInvariant, LAApply PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAApply, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAReadBeginStep == ASSUME LAInvariant, NEW r \in LAReads, LAReadBegin(r) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAReadBegin, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAReadViewStep == ASSUME LAInvariant, NEW r \in LAReads, LAReadView(r) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAReadView, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAReadFinishStep == ASSUME LAInvariant, NEW r \in LAReads, LAReadFinish(r) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAReadFinish, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAReadFallbackStep == ASSUME LAInvariant, NEW r \in LAReads, LAReadFallback(r) PROVE LAInvariant'
BY LALegalInputs, SMT DEF LAReadFallback, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAInvariantStep == ASSUME LAInvariant, [LANext]_laVars PROVE LAInvariant'
BY LAAdvanceStep, LAStartRoundStep, LAGrantStep, LADeliverStep, LAActivateStep, LARevokeStep, LARearmStep, LACrashStep, LARestartStep, LAVoteStep, LAElectStep, LAOldCommitStep, LANewCommitStep, LAApplyStep, LAReadBeginStep, LAReadViewStep, LAReadFinishStep, LAReadFallbackStep, SMT DEF LANext, laVars, LAInvariant, LAType, LARecordedGrants, LAPromiseProtection, LAVoteHistory, LAAuthority, LANoReplacementUnderLease, LAReadCoverage, LAUsableRound, LALiveRound, LACanRead, LATicketValid, LAHasQuorum, LADead, LAAdvanceGeneration, LAMax

THEOREM LAInvariantAlways == LASpec => []LAInvariant
BY LAInvariantInit, LAInvariantStep, PTL DEF LASpec
=============================================================================
