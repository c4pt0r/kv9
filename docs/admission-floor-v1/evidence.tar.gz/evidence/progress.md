# Metadata admission floor (#20 items 3-4 slice) — task #33

Baseline: f027ae6. Ports 27320. Serial suite 945 (+3 new = 948 expected).

## Scope decision (surveyed)
Admission is ALREADY bounded (KV9_PUBLIC_MAX_REQUESTS=64 default +
MAX_ENCODED_BYTES, typed refusals, per-class counters; async apply/read
limits exist; raft-internal traffic never passes public admission). The
GAP for item 4: all five WorkClasses share ONE pool — a hot raw client
exhausts max_requests and starves control traffic. Fix: METADATA FLOOR.

## Implemented
- PublicApiLimits.metadata_reserved_requests (env
  KV9_PUBLIC_METADATA_RESERVED, DEFAULT 8, validate < max_requests;
  0 disables). Non-metadata classes refuse at in_flight >=
  max - floor with NEW TYPED Refusal::MetadataFloor (label
  metadata_floor, maps to ResourceExhausted via the generic path);
  metadata classes admit to the full limit. ClassCounters.refused_floor
  + status line extended. DEFAULT ON (the guarantee is the deliverable).
- Unit tests: flood refuses typed at the floor while metadata admits to
  full limit; release reopens; floor >= max refuses config; env parse
  test updated (closure must handle *RESERVED). 25/25 admission tests.
- All PublicApiLimits literals across tests patched (+field).

## Remaining
- [ ] e2e (port 27320): sustained raw flood (32+ writers) for N s;
      concurrent metadata ops (admit-node / create-data-group) must
      keep succeeding; after flood assert public_rpc_raw_write
      refused_floor>0 and metadata refused_floor==0 in status.
- [ ] Lean model proofs/lean/admission-floor/ (~12 theorems: raw never
      consumes the floor; metadata admits whenever total<max; refusal
      is typed pre-append; release restores shared capacity) + prover
      + contract + sibling refresh.
- [ ] docs/ADMISSION-FLOOR.md + qualify (30 models) + packet
      docs/admission-floor-v1 + issues #9 (replace) + #20 (append).
