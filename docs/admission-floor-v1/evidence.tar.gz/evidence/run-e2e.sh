#!/bin/bash
set -euo pipefail
CREDS=/mnt/data/kv9-work/joint-install-20260916/minio-first/private-credentials.json
export KV9_OBJECT_STORE_ENDPOINT=http://172.21.0.4:9000
export KV9_OBJECT_STORE_BUCKET=kv9-joint-install-cbc8bed9c73d
export KV9_OBJECT_STORE_ACCESS_KEY=$(python3 -c "import json;print(json.load(open('$CREDS'))['access_key'])")
export KV9_OBJECT_STORE_SECRET_KEY=$(python3 -c "import json;print(json.load(open('$CREDS'))['secret_key'])")
cd /home/dongxu/kv9
exec python3 scripts/admission-floor-e2e.py --bin target/debug/kv9 --output "$1"
