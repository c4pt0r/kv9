import json, re, subprocess
from pathlib import Path

work = Path('/mnt/data/kv9-work/backpressure-20260917')
root = Path('/home/dongxu/kv9')

text = (work / 'workspace-serial.log').read_text()
tallies = [(int(a), int(b), int(c)) for a, b, c in re.findall(
    r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
serial = {
    'suites': len(tallies),
    'passed': sum(t[0] for t in tallies),
    'failed': sum(t[1] for t in tallies),
    'ignored': sum(t[2] for t in tallies),
    'exit_code': 0,
    'log': 'workspace-serial.log',
}
assert serial['failed'] == 0 and serial['suites'] > 0

minio = (work / 'minio-focused.log').read_text()
m = re.findall(r'test result: ok\. (\d+) passed; 0 failed', minio)
assert m, 'minio focused run must pass'

floor = json.loads((work / 'admission-floor-proof/result.json').read_text())
assert floor['accepted'] and floor['theorems'] == 14 and floor['semantic_controls'] == 5

siblings = {}
for model in ['data-range', 'group-activation', 'group-control', 'group-preparation',
              'joint-install', 'learner-attach', 'migration-authority',
              'protocol-snapshot', 'routed-client', 'source-capture', 'runtime-adoption',
              'install-evidence', 'source-truncation', 'voter-promotion', 'replica-removal',
              'storage-retirement', 'split-intent', 'partition-directory', 'parent-seal',
              'child-population', 'split-publication', 'parent-retirement', 'cross-range',
              'auto-split', 'cascade-split', 'storage-reclamation', 'migration-abort',
              'proposal-batching', 'deferred-sync']:
    r = json.loads((work / f'{model}-proof/result.json').read_text())
    assert r['accepted'], model
    siblings[model] = {'theorems': r['theorems'], 'semantic_controls': r['semantic_controls']}

retention = (work / 'retention-ledger-recheck.log').read_text()
assert 'PASS: retention ledger' in retention.splitlines()[-1]

e2e = json.loads((work / 'e2e-fifth/result.json').read_text())
assert e2e['verdict'] == 'accepted' and e2e['raw_floor_refusals'] > 0
fourth = json.loads((work / 'e2e-fourth/result.json').read_text())
assert fourth['verdict'] == 'accepted'
for run in ('e2e-first', 'e2e-second', 'e2e-third'):
    assert json.loads((work / run / 'result.json').read_text())['verdict'] == 'failed', run

clippy = subprocess.run(
    ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'kv9-raft/testing'],
    cwd=root, capture_output=True, text=True)
warnings = len(re.findall(r'^warning:', clippy.stderr, re.M))
assert clippy.returncode == 0 and warnings == 0, (clippy.returncode, warnings)

out = {
    'schema': 1,
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'workspace': {'serial': serial},
    'lint': {'clippy_warnings': 0},
    'minio_focused': {'passed': int(m[-1]), 'log': 'minio-focused.log'},
    'admission_floor_model': {
        'theorems': floor['theorems'],
        'semantic_controls': floor['semantic_controls'],
        'policy_controls': floor['hole_and_axiom_controls'],
        'result': 'admission-floor-proof/result.json',
    },
    'sibling_lean_models': siblings,
    'retention_tlaps': {'log': 'retention-ledger-recheck.log', 'line': retention.splitlines()[-1]},
    'e2e': {'verdict': e2e['verdict'], 'checks': e2e['checks'],
            'raw_floor_refusals': e2e['raw_floor_refusals'], 'probes': e2e['probes'],
            'result': 'e2e-fifth/result.json'},
    'also_accepted': {'runs': ['e2e-fourth/result.json']},
    'failed_e2e_retained': ['e2e-first (probe conflated admission liveness with raft latency -> idempotent retry)',
                            'e2e-second (flood never saturated 16 shared slots -> pool shrunk)',
                            'e2e-third (typed refusal invisible: client label whitelist -> metadata_floor allowed)'],
    'not_claimed': ['byte-level floors, cross-layer backpressure budgets, dual-WAL unification, '
                    'per-tenant fairness, chaos, performance claims, hosted CI'],
}
(work / 'local-validation.json').write_text(json.dumps(out, indent=2) + '\n')
print('local-validation.json written; serial', serial)
