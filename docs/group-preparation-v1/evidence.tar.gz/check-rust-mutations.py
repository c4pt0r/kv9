import hashlib,json,os,subprocess
from pathlib import Path
repo=Path('/home/dongxu/kv9');work=Path(__file__).parent
plan=json.loads((work/'rust-mutation-plan.json').read_text());env=dict(os.environ,KV9_TEST_DATA_DIR=str(work/'mutation-fixtures'))
def run(name,args):
 with (work/(name+'.log')).open('w') as log:
  result=subprocess.run(['cargo','test',*args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 return result.returncode,(work/(name+'.log')).read_text()
args=['-p','kv9-meta','-p','kv9-server','--lib','group_preparation_','--','--test-threads=1']
code,log=run('mutation-baseline',args);assert code==0 and 'test result: ok. 3 passed' in log and 'test result: ok. 6 passed' in log
receipts=[]
for c in plan:
 path=repo/c['file'];original=path.read_bytes();source=original.decode();assert source.count(c['old'])==1,(c['name'],source.count(c['old']))
 changed=source.replace(c['old'],c['new']);(work/(c['name']+'.rs')).write_text(changed)
 try:
  path.write_text(changed)
  code,log=run(c['name'],['-p',c['package'],'--lib',c['test'],'--','--exact','--test-threads=1'])
 finally:path.write_bytes(original)
 assert code==101 and 'test result: FAILED. 0 passed; 1 failed' in log and c['failure'] in log,(c['name'],code,log[-1800:])
 receipts.append({'name':c['name'],'selected':1,'exit_code':code,'expected_failure':c['failure'],'source_sha256':hashlib.sha256(original).hexdigest(),'mutated_sha256':hashlib.sha256(changed.encode()).hexdigest()})
 (work/'rust-mutation-results.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('CONTROL_ACCEPTED',c['name'],flush=True)
code,log=run('mutation-restored',args);assert code==0 and 'test result: ok. 3 passed' in log and 'test result: ok. 6 passed' in log
print('GROUP_PREPARATION_RUST_CONTROLS_ACCEPTED: 9 tests; 9 single-defect controls',flush=True)
