import gzip,hashlib,io,json,tarfile,time
from pathlib import Path
root=Path('/tmp/kv9-quorum-trace-fixture-root-first');prep=Path('/tmp/kv9-quorum-trace-fixture-preparation-first');out=root/'publication-first';out.mkdir()
records=json.loads((prep/'results-first/input-inventory.json').read_text())
for name,row in json.loads((prep/'inventory.json').read_text())['files'].items():records[str(prep/name)]=row
for p in [prep/'inventory.json',*(prep/'results-first').iterdir(),*root.glob('*.json'),*root.glob('*.py'),*(root/'runtime-first').iterdir(),*(root/'readback-first').iterdir()]:
 if p.is_file() and not p.is_symlink():records[str(p)]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
assert len(records)<=1024 and sum(r['bytes'] for r in records.values())<=128*1024**2
assert all(r['bytes']<=64*1024**2 for r in records.values())
archive=out/'original-evidence.tar.gz';started=time.time_ns()
with archive.open('xb') as dest, gzip.GzipFile(filename='',mode='wb',fileobj=dest,mtime=0,compresslevel=6) as gz, tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,r in sorted(records.items()):
  p=Path(name);assert p.is_file() and not p.is_symlink();data=p.read_bytes();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256'],name
  info=tarfile.TarInfo('original/'+name.lstrip('/'));info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
assert archive.stat().st_size<=32*1024**2
observed={}
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:
  assert member.isfile() and member.name.startswith('original/') and '..' not in Path(member.name).parts and member.size<=64*1024**2
  name='/'+member.name[len('original/'):];assert name in records and name not in observed
  f=tar.extractfile(member);data=f.read();observed[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
assert observed==records
result={'complete':True,'started_ns':started,'ended_ns':time.time_ns(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'raw_bytes':sum(r['bytes'] for r in records.values()),'files':records,'scope':'Original runtime/readback/preparation evidence; exact source/client/build hashes. No executable artifacts. Every gzip member independently read back without extracting.'}
(out/'archive-inventory.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'}))
