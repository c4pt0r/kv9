from pathlib import Path
import json,re,hashlib
repo=Path('/home/dongxu/kv9')
proofs=repo/'proofs/lean/radix'
old=json.loads((proofs/'cursor-contract.json').read_text())
new_modules=['EdgeVector.lean','EdgeSearch.lean','EdgeMutation.lean','DeleteLoop.lean','DeleteWordLoop.lean']
modules=old['modules']+new_modules
runner=(repo/'scripts/resident-radix/prove-cursor.py').read_text()
runner=runner.replace('Check radix cursor, range and predecessor refinement with rejecting controls.','Check indexed edge and iterative deletion refinement with rejecting controls.')
runner=runner.replace('cursor-contract.json','delete-contract.json').replace('import RangeProperties\\n','import DeleteWordLoop\\n').replace('injectedCursorFalse','injectedDeleteFalse')
runner=runner.replace("'Type mismatch',", "'Type mismatch', 'Application type mismatch',")
(repo/'scripts/resident-radix/prove-delete.py').write_text(runner)
controls=[]
def control(label,module,old,new,kind='semantic'):
 source=(proofs/module).read_text()
 assert source.count(old)==1,(label,source.count(old))
 controls.append(dict(name=label,module=module,old=old,new=new,kind=kind))
control('remove-loses-tail','EdgeVector.lean','| 0, .cons _ _ tail => tail','| 0, .cons _ _ tail => .nil')
control('insert-loses-suffix','EdgeVector.lean','| 0, byte, child, forest => .cons byte child forest','| 0, byte, child, forest => .cons byte child .nil')
control('set-loses-suffix','EdgeVector.lean','| 0, child, .cons byte _ tail => .cons byte child tail','| 0, child, .cons byte _ tail => .cons byte child .nil')
control('search-hit-off-by-one','EdgeSearch.lean','| .hit index => .hit (index + 1)','| .hit index => .hit (index + 2)')
control('search-reversed-partition','EdgeSearch.lean','else if target < byte then .miss 0','else if target > byte then .miss 0')
control('replacement-deletes-child','EdgeMutation.lean','| some child => edgeSet index child forest','| some _ => edgeRemove index forest')
control('restore-wrong-index','DeleteLoop.lean','| some child => edgeInsert frame.index frame.byte child frame.detached','| some child => edgeInsert (frame.index + 1) frame.byte child frame.detached')
control('unwind-skips-parent','DeleteLoop.lean','| frame :: tail, replacement => unwindDelete tail (restoreDelete frame replacement)','| _ :: tail, replacement => unwindDelete tail replacement')
control('restore-rejects-end-insertion','DeleteLoop.lean','decide (frame.index > edgeCount frame.detached)','decide (frame.index >= edgeCount frame.detached)')
control('delete-prefix-offset','DeleteLoop.lean','let endOffset := depth + pfx.length','let endOffset := depth + pfx.length + 1')
control('delete-retains-terminal','DeleteLoop.lean','unwindDeleteChecked frames (normalize (.branch pfx none children))','unwindDeleteChecked frames (normalize (.branch pfx terminal children))')
control('delete-retains-leaf','DeleteLoop.lean','| .leaf _ => unwindDeleteChecked frames none','| .leaf entry => unwindDeleteChecked frames (some (.leaf entry))')
control('delete-edge-offset','DeleteLoop.lean','deleteLoop query child (endOffset + 1)','deleteLoop query child (endOffset + 2)')
control('delete-discards-ancestors','DeleteLoop.lean','(⟨pfx, terminal, edgeRemove index children, index, storedByte⟩ :: frames)','(⟨pfx, terminal, edgeRemove index children, index, storedByte⟩ :: [])')
control('absent-delete-drops-root','DeleteLoop.lean','if optionalLookup query root = none then some root','if optionalLookup query root = none then some none')
control('word-prefix-offset','DeleteWordLoop.lean','let endOffset := depth + USize.ofNat pfx.length','let endOffset := depth + USize.ofNat pfx.length + 1')
control('word-edge-offset','DeleteWordLoop.lean','deleteWordLoop query child (endOffset + 1)','deleteWordLoop query child (endOffset + 2)')
control('word-count-double-decrement','DeleteWordLoop.lean','fun root => (⟨root, state.size - 1⟩, true)','fun root => (⟨root, state.size - 2⟩, true)')
control('word-success-flag','DeleteWordLoop.lean','fun root => (⟨root, state.size - 1⟩, true)','fun root => (⟨root, state.size - 1⟩, false)')
control('delete-proof-hole','DeleteLoop.lean','exact ih (restoreDelete frame replacement)','sorry','hole')
control('delete-custom-axiom','DeleteLoop.lean','exact ih (restoreDelete frame replacement)','exact False.elim injectedDeleteFalse','axiom')
rust=(repo/'scripts/resident-radix/src/lib.rs').read_text()
source_controls=[]
for label,old_text,new_text in [
 ('rust-delete-skip-prefix','Node::Branch(branch) => depth += branch.prefix.len(),','Node::Branch(_) => {},'),
 ('rust-delete-count','self.size -= 1;','self.size -= 2;'),
 ('rust-delete-restore-index','.insert(index, Edge { byte, node });','.insert(index + 1, Edge { byte, node });')]:
 assert rust.count(old_text)==1,(label,rust.count(old_text))
 source_controls.append(dict(name=label,old=old_text,new=new_text))
names=[n for module in modules for n in re.findall(r'^\s*theorem\s+(\w+)',(proofs/module).read_text(),re.M)]
assert names[:len(old['theorems'])]==old['theorems'] and len(names)==len(set(names))
sources=dict(old['sources'])
for name in ['proofs/lean/radix/cursor-contract.json','scripts/resident-radix/prove-delete.py']+['proofs/lean/radix/'+m for m in new_modules]:
 sources[name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
contract=dict(modules=modules,theorems=names,new_theorems=names[len(old['theorems']):],sources=sources,lean_sha256=old['lean_sha256'],controls=controls,source_controls=source_controls,complete_algorithm_gate=False,
 scope='Reviewed value-level Rust deletion-loop correspondence: indexed vector/search contracts; iterative descent without repeated prefix checks; detached-parent frames and checked restoration; termination; word-offset simulation and stored word-count/return-flag refinement. Sorted search/Vec/Arc/compiler library contracts remain explicit. This is not verified Rust extraction or heap correspondence. No timing or promotion.',
 remaining=['Insertion action/depth/split and mutable-slot simulation; indexed seek/pending Vec correspondence','Arc/COW heap ownership, snapshots, concurrent reclamation and distinct resident storage for word-count representability; Rust/compiler/library premises','Exact-source executable Rust/model differential evaluation, then predeclared matched performance and recovery/Chaos/Redis gates'])
(proofs/'delete-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
print(json.dumps(dict(theorems=len(names),new_theorems=len(contract['new_theorems']),semantic_controls=sum(c['kind']=='semantic' for c in controls),controls=len(controls)+len(source_controls))))
