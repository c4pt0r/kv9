import DeleteLoop
#print USize.toNat_ofNat
#check USize.toNat_ofNat'
#check USize.toNat_ofNat_of_lt
#check USize.toNat_ofNatLT
#check USize.toNat_add
#check USize.ofNat_toNat
