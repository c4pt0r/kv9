# Independent Raw KV and catalog history checking

This is the C02 increment of [issue #12](https://github.com/c4pt0r/kv9/issues/12),
under [roadmap #9](https://github.com/c4pt0r/kv9/issues/9). It establishes an
independent executable model and concurrent fault histories. Complete protocol
refinement, production multi-chunk fault histories and the broader fault matrix
remain open. Transaction snapshot isolation is a separate T02 obligation.

## History and observable contract

`scripts/history/workload.py` invokes the public CLI. A single external
coordinator records invocation before starting each subprocess and response
after it returns, using a locked, increasing event sequence. Node clocks and
reported Raft positions do not establish ordering. Positions and raw CLI output
are retained for diagnosis. Every endpoint attempt has a distinct operation ID;
retries are visible calls. The client rotates among three stable replica
addresses after failures and remembers successful endpoints. It has no mandatory
seed or gateway. The Kubernetes client Pod has labels outside database fault
selectors; this harness coordinator is not part of the database service.

Version 1 JSONL starts with a header containing the seed, endpoint set, worker
count, initial catalog/KV state and production range chunk size of 1024. Each
invocation includes `id`, `client`, `op`, exact arguments, endpoint and phase.
Each response includes its matching ID, outcome, result, raw stdout/stderr,
exit code and receipt. A missing response means pending/unknown. Byte strings
use canonical lowercase hex; a missing value differs from an empty value.
Malformed successful CLI output fails the recorder and is rejected by the
checker even if a caller later submits the saved history manually.

The independent state is a finite mapping `(keyspace, key) -> value` and a
catalog mapping `name -> id`. No Rust database code, storage file, status file or
production model is imported into `checker.py`.

| Operation | Model transition and observation |
|---|---|
| `put` / `delete` | One atomic point mutation in an existing keyspace |
| `get` | One atomic observation of the current value or absence |
| `scan` | One atomic, sorted observation over `[start,end)`, bounded by `limit`; empty end is unbounded, zero limit returns no rows |
| `create_keyspace` | A unique nonempty name receives a previously unused nonzero 24-bit ID |
| `delete_range` | Select one immutable ordered key set after invocation, then delete its successive chunks atomically; completed chunk count must match the result |

Catalog checking proves name and ID uniqueness/non-reuse for the recorded
operations. It does not require gapless IDs or infer allocation order from
response order. Unknown creations may allocate any observed ID or a fresh
symbolic ID. Symbols represent distinct unobserved IDs and are bounded by the
remaining 24-bit domain; unobserved IDs are otherwise observationally symmetric.
The harness creates its own keyspace; unrelated fixture mutations use a separate
keyspace and do not affect its model. The initial fixture catalog is declared.

A confirmed atomic operation takes effect strictly after invocation and no later
than its response. A transport timeout, generic RPC error or generic NotLeader
is **unknown**, not proof of no write. An unknown mutation may be omitted or may
take effect at any later point, including after the observed timeout response.
Unknown reads have no confirmed observation and no effect, so omission is safe.
Only a separately proven pre-commit refusal has no effect; the recorder currently
emits no such refusal because diagnostic prose is insufficient evidence.

Range deletion follows `RuntimeBackend::raw_delete_range`, `run_delete_range`
and `RawExecutor::plan_delete_range_chunk`: one established snapshot supplies
all chunks. A later write to a selected key can be deleted by its later chunk;
a newly inserted key absent from that snapshot survives. Whole-request range
delete is not atomic, even when the selection fits one chunk. For example,
selecting `{a}`, then observing a completed insert of `b`, then reading old `a`,
then deleting `a` while `b` survives is a legal history. Modeling that request as
one atomic range mutation would incorrectly reject the implementation contract.
A typed partial result proves its completed prefix before the response and allows
at most one extra unresolved chunk. Generic unknown results provide no such
upper bound. Real-time linearizability claims apply to the atomic API subset;
range requests satisfy the explicitly weaker transition contract above.

## Search and certificate argument

A search node contains the observed-event cursor, the entire model state and
per-operation progress. Atomic progress is unstarted or done; range progress
contains the immutable selected keys and applied chunk count. The cursor advances
until a confirmed response (or typed partial prefix) needs more model steps.
Search then enumerates effects of already invoked operations, including unknown
mutations whose timeout response was already observed. It never partitions
overlapping point, scan and range operations into independent key histories.

**Soundness.** Initially the model equals the declared initial state. Every
certificate effect is an enumerated transition on that state; induction on the
certificate preserves the model transition relation and prevents duplicate
atomic effects. Replay rejects effects before invocation. Every response barrier
is checked before advancing past it and again at the end. Consequently each
confirmed observation holds at the indicated step; each required mutation or
partial prefix has completed before its response. Monotone event boundaries
imply that an atomic operation completed before another was invoked precedes
that operation's effect. Unknown writes have only an invocation lower bound.
`verify_witness` replays the complete certificate from scratch, independently of
DFS cursor retirement and memoization, before any valid verdict is returned.
Replay deliberately shares the model transition function; model correctness is
a separate obligation supported by the controls and source mapping.

**Unrestricted search completeness for this finite model.** Take any legal
execution of the finite recorded operations. Move its effects to the next
unsatisfied response barrier without changing their order. No intervening
confirmed response needs them (otherwise that response would have been the
barrier), and moving right does not violate invocation bounds. Effects after the
last observation are unnecessary and may be omitted. This yields a path in the
enumerated search tree. Each operation has finitely many effects and choices:
point effects occur once, each range selects once and advances through a finite
key set, and catalog choices use the finite observed-ID set plus symmetric fresh
representatives. States include exact KV/catalog contents, cursor and progress;
memoizing identical states preserves all possible suffixes. Retired completed
operations are excluded from future candidates by their observed response bound.
Thus exhaustive unrestricted search failure establishes no legal execution of
this model. A time, state or frontier limit yields **inconclusive** instead.

The checker first tries omitting unknown effects, then a guided attempt that
prefers unknown effects reducing the pending observation's mismatch or that of
an eligible overlapping confirmed read (including range-selection lookahead),
a second guided attempt permitting an early range
snapshot before a Put inserts a previously absent key, small unknown-effect
budgets (1, 2, 4), and finally the unrestricted search. Restricted attempts are witness-finding heuristics only:
their negative results never establish invalidity, and every positive result
replays against the unrestricted model. The total time/state budget is shared.
A valid interpretation that omits an unknown write is not evidence that the
actual write failed. Search order may change without strengthening that claim.

Invalid histories retain a proven-invalid event prefix. Prefix minimization
preserves all preceding invocations and treats unfinished calls as unknown.
Arbitrarily removing a causal write could manufacture a stale-read example and
is therefore not used. Budget exhaustion keeps the last proven-invalid prefix;
the result need not be globally minimal.

`proofs/lean/History.lean` checks three unbounded lemmas: accepted generic
certificates form executions, executions are accepted, and operation interval
bounds preserve strict real-time order. The model includes explicit response
check actions. Mapping Python's implicit response checks to these actions,
Python execution to Lean's evaluator, and the concrete transition predicates to
the public API remain source-level refinement obligations. These lemmas do not
mechanically verify Python, the DFS completeness argument, raft-rs or the Rust
binary. Removing eligibility or weakening the ordering premise must fail Lean
for the expected reason. The complete inventory contains 24 lemmas with nine
invalid proof controls.

## Executable acceptance

```sh
python3 -m unittest discover -s scripts/history -p 'test_*.py' -v
python3 scripts/history/check-controls.py --output /tmp/kv9-history-controls-new
cargo build --bin kv9
python3 scripts/history/local-e2e.py
python3 scripts/history/checker.py /path/history.jsonl --output /path/result.json \
  --acceptance --require put get delete scan delete_range create_keyspace
```

The checker exits 0 only for valid, 1 for proven invalid, and 2 for inconclusive
or malformed input. Acceptance requires successful mutations and reads and all
requested API kinds; zero operations, all errors and missing coverage fail.
Controls include 38 tests and 200 deterministic small atomic histories checked
against a separate permutation/subset oracle. Eleven isolated source mutations
each require exactly one selected test to pass, fail its intended assertion,
and pass after byte-for-byte restoration. Sources and mutant hashes, all phase
logs and exact test counts are retained. A compile/import error cannot count as
a caught semantic defect.

`scripts/chaos-mesh-e2e.sh` records a concurrent whole history across its actual
PodChaos, NetworkChaos and IOChaos matrix. Every sustained voter failure,
partition, delay and each voter/errno cell additionally requires an independent
successful put and read invoked after the fault effect was observed and completed
before healing starts. Phase progress is saved and the continuing fault is
checked after those operations. Final checker coverage requires all 13 named
windows. Pod/container kills are instantaneous events spanned by the history,
not intervals with an asserted in-fault operation. CI verifies explicit matrix,
history and per-phase completion markers and uploads all evidence on either
success or failure.

The randomized workload uses three concurrent workers, eight overlapping keys,
bounded scans/ranges, distinct written values, racing catalog names and a
reserved acknowledged key outside mutation ranges checked after healing. This
bounds search while preserving overlapping multi-key operations; it does **not**
exercise a production range larger than 1024 keys or force a typed partial range
result under faults. Synthetic controls cover those semantics; real multi-chunk
and partial-result fault histories remain C02 work. The current IOChaos cells
cover reopen/catch-up Raft writes, not all engine/checkpoint I/O. The one-host
Kind cluster cannot establish host-loss availability. See
[Chaos I/O limits](CHAOS-IO-VALIDATION.md) and the
[mandatory proof/fault/availability contract](CORRECTNESS-GATES.md).

## Local validation record (2026-09-08)

The complete revised Chaos Mesh matrix passed with 1,480 operations: 1,312
confirmed successes and 168 unknown results, all six APIs and all 11 required
fault windows. The checker replayed its witness in 0.389 seconds, visiting 1,444
states. Evidence is retained at `/tmp/kv9-chaos-e2e.C3gAGO`; the runner log is
`/tmp/kv9-c02-chaos-final.log`. The separate three-process acceptance recorded
240 operations (218 successful, 22 unknown), all six APIs, and passed witness
replay; artifacts are at `/tmp/kv9-history-local-vvcf3aki`.

Two earlier complete fault histories exceeded search limits and were correctly
reported inconclusive. Both original histories were retained unchanged. The
first (1,278 operations) exposed expensive branching over irrelevant unknown
read/write effects and passed after the bounded witness attempts were added.
The second (1,448 operations) needed an unknown put to explain a later confirmed
scan after leadership changed. Omitting every unknown effect was therefore
insufficient; the guided attempt found and replayed a full witness in 0.784
seconds. That run's original failure remains at `/tmp/kv9-chaos-e2e.n6jlzr`, with
the successful recheck at `/tmp/kv9-c02-phase-rechecked.json`. Neither history was
reduced to obtain a valid verdict. The 30-test suite includes a bounded-search
regression with many unknown writes and a late scan observation; restricted
negative verdicts remain explicitly non-authoritative.

The seven mutation controls passed baseline/mutant/restored checks, all 12 Lean
lemmas passed with six rejected invalid controls, and Bash syntax, actionlint and
whitespace checks passed. These local observations do not assert hosted CI
success; published issue evidence records the observed runs at their commit.

## Hosted integration follow-up

The first hosted CI run at `c72d550` failed the existing dynamic-membership E2E
at its one-shot post-failover CreateKeyspace call. The saved scene shows the
replacement candidate's local leader status in term 6 while its applied prefix
still belongs to term 5; the public RPC returned `not leader`. Local role status
was being treated as a guarantee that the next RPC would succeed. The failure
is retained in run [34288658386](https://github.com/c4pt0r/kv9/actions/runs/34288658386),
artifact `scene-dynamic-membership-e2e.sh-34288658386-1`.

`scripts/membership-write.sh` now bounds retries of that observed leadership
rejection, re-resolves the routing candidate and saves every attempt's endpoint,
start/end timestamps, stdout, stderr and exit status. It retries the same unique
name. A timeout, transport failure, duplicate-name response or missing successful
receipt cannot satisfy the write. The retry-start budget is 20 seconds and each
in-flight client call remains bounded by the existing 15-second timeout. The
existing exact term/index checks on every surviving and restarted voter remain
unchanged; no production protocol, fsync or quorum rule changed.

Four deterministic controls cover transient leadership rejection, timeout,
duplicate-name refusal and exhausted routing budget. A single-defect source
mutation disabling the leadership retry fails at the intended refusal; baseline
and restored controls pass. The full real five-voter join/promotion/failover and
restart E2E passed locally, with artifacts at `/tmp/kv9-membership.TekcYJ`.
Hosted validation of the follow-up is recorded separately in issue evidence.

Public admission refusals use the existing `refused`/`precommit` model outcome
only after the recorder checks an exclusive Raw CLI refusal, exit 1, empty stdout
and the optional exact kubectl trailer. Timeout or mixed output remains unknown.
The guided search assigns no observation distance to a refused read: it has no
value/rows result to explain. Both parser and heuristic have isolated source
controls; the full witness still uses the same sequential transition relation.
See [PUBLIC-ADMISSION.md](PUBLIC-ADMISSION.md) for the live overload fault window.

Unknown-write candidates are ordered from recent to old after the immediately
required operation and confirmed work. Older unresolved RPCs remain legal search
candidates. This avoids trying many obsolete range selections before a recent
unknown delete that explains the current observation. A fixed-budget known
witness test and its oldest-first mutation discriminate this ordering. No search
cap is increased, no transition is pruned from unrestricted search, and bounded
or guided exhaustion still cannot establish invalidity.

The guided pass prefers an eligible overlapping successful read when its recorded
result already matches the current state, before applying an overlapping write.
Otherwise a later read response can be explained by an unrelated old unknown
delete, causing avoidable backtracking when a subsequent read needs that write.
This changes candidate ordering only. A fixed-budget known witness and isolated
deferred-read mutation exercise this case; all positive witnesses are replayed
and unrestricted exhaustion retains its complete transition set.

### Early snapshot preparation under unknown range deletion

An unknown `delete_range` can select existing key `a`, time out, and delete `a`
after a successful Put inserts `b` in the same range. A subsequent scan may
therefore observe only `b`. Selecting the range only when that scan becomes the
next response would capture both keys and miss this legal execution.

The additional bounded guided pass permits a nonempty range selection before a
pending Put adds a key absent from that selection. Selection still uses the exact
current model snapshot; subsequent chunks must improve the pending observation.
The original guided pass runs first, preserving its smaller search frontier for
histories with many irrelevant unknown ranges. Both share the same total budget.
Neither restricted exhaustion nor budget exhaustion proves invalidity.

This search gap was reproduced in a complete 2,396-operation Chaos history with
243 unknown outcomes. The original checker exhausted its 60-second budget. The
new pass finds and independently replays a complete witness from the initial
state, retaining every invocation and response. No model transition, timeout
semantics, response barrier or witness validation rule changed. A small explicit
history reproduces the early-selection requirement under a fixed state budget;
removing the preparation rule fails that assertion. The gate now requires all
35 history tests and 12 isolated baseline/mutant/restored source controls.

### Reversed concurrent write responses

The probe-routing acceptance run retained at `/tmp/kv9-chaos-e2e.00U4mD` completed
all fault windows and its persistent-client history, but the original CLI history
checker exhausted its unchanged 60-second budget. Its 2,517 operations include
303 unknown outcomes. Near the end, two overlapping Puts to the same key returned
in reverse order; a later Scan required the second invoked value. The previous
response-first search tried many old unknown deletions before reconsidering that
write pair. An independent diagnostic witness explains the original full history
in 4,454 states and 3.30 seconds, with every unknown retained.

The guided witness heuristic now tries overlapping confirmed writes to the same
key in invocation order first. It retains alternative orders, does not trust
server receipts as model constraints, and still replays every positive witness
from the initial state. The sequential model, unrestricted exhaustion, search
limits and treatment of inconclusive results are unchanged. A bounded regression
covers both the reversed-response case with 128 old unknown deletions and the
opposite legal order. All 36 history tests and the 13 isolated source controls
remain required. The original failed acceptance attempt is not relabeled as a
successful process run.


### Complete-history search with overlapping writes (#46)

Hosted run `34372066550` at `5335e47` completed the actual 16-window fault
matrix and its persistent-client history, but its 4,063-operation CLI history
returned `inconclusive` after the unchanged 60-second search budget. The
original failure is retained. Filtering eligible candidates before sorting
removes only operations excluded by the existing interval/read conditions or
whose completed progress has no successor. Unknown writes remain eligible
after their responses. The transition graph and relative candidate order are
unchanged by this filtering.

The guided witness attempt also uses a later successful Get or an explicit
Scan row to rank overlapping confirmed point writes. It tries the matching
write last, after both responses and before another invoked write to the same
key. This is only an ordering hint: older unknown operations can invalidate the
hint, and every alternative order remains in the same search. It never reads
server receipt positions, removes history records, infers a timeout refusal,
or changes the sequential model, global budgets or unrestricted exhaustion.
Every positive certificate is replayed from the initial state across all
response barriers. Without a certificate, acceptance still fails.

The original hosted history now yields a complete witness within the same
60-second budget. Regression coverage includes both response orders, both
observed values, Get and Scan observations, and an unwritten value that must
remain invalid even if a future Put supplies it. The 38-test suite includes
200 independently enumerated small atomic histories. Fourteen isolated source
controls retain exact baseline, single-test assertion failure, and restored
checks; disabling the following-read hint fails its fixed-frontier witness
case. Local retained-corpus success does not change the original hosted run's
failed conclusion or establish a successful subsequent hosted run.

## Confirmed range snapshot ordering

Tracking: [#49](https://github.com/c4pt0r/kv9/issues/49). The 21-window actual
Chaos matrix at `362097a` completed its fault observations, but its complete
4,330-operation CLI history returned `inconclusive` after 197,068 states. A
confirmed range and a later insertion overlapped. Selecting the range after
the insertion deleted a value required by a subsequent scan; the legal
execution selects the old keys first and applies that captured set later.
Unrelated unknown effects consumed the search frontier before it retried the
correct snapshot order.

The range-preparation witness attempt now prefers an eligible, unselected
confirmed range before an overlapping insertion of a new key in that range.
The first guided attempt retains the insertion preference. A reduced history
with 64 interchangeable unknown deletions reproduces the old failure under a
100-state budget; the new ordering finds its witness in eight states. A
separate control applies the same unknown-effect pressure while requiring the
opposite snapshot order, also finding an eight-state witness. Sharing the early
snapshot preference across both attempts exhausted the fifth actual Chaos
run's search budget. The two existing attempts now use different priorities:
the fourth complete history obtains a witness in 22,457 states, and the fifth
4,280-operation history in 7,087 states. Complete witness replay remains
mandatory. No event, unknown outcome, attempt count or search limit changes.

The preservation argument is a permutation argument. The eligible candidate
set and each candidate's transition generator are unchanged. Sorting that
finite set changes exploration order, and all children remain in the frontier.
For unrestricted search, `guided_unknown` is false, so the added priority
component is constant: its relative order is identical to the old order. For
guided search, a positive result still passes the unchanged full witness
replay; restricted exhaustion still cannot establish invalidity. The existing
certificate/interval proof boundary is preserved. This is not an additional
consensus theorem or a completeness guarantee under finite search budgets.

At `1c5c38f`, the Python gate has 40 tests and 16 isolated source mutations. One
mutation disables the confirmed-range preference; another applies it to both
guided attempts. Each must produce its named budget regression; baseline and
restoration must pass. Existing
unknown-write, partial-range, real-time, refusal, witness and unrestricted-search
controls remain required. The original failed Chaos history is retained; a
replayed certificate does not rewrite its original command result.

## Overlapping observations and mixed snapshot order

The sixth full matrix completed all 21 fault windows, but its unchanged
4,264-operation CLI history exhausted the checker budget. Two different
boundaries were reproduced:

- A single confirmed range must select after one overlapping insertion and
  before another. Neither a globally early nor globally late preference is
  sufficient. The existing following-read hint now guides range selections as
  well as competing point writes. Scan absence is usable only inside the scan
  interval and its returned prefix: a full page cannot establish absence after
  its last row, and a zero limit observes no keys. A subsequent possible write
  still terminates the hint search.
- An unknown write may need to take effect before an overlapping read, which
  itself must precede the next confirmed mutation even if that mutation returns
  first. Guiding unknown effects solely by the next response excludes this
  witness. A three-operation example starts with `a=old`, times out `Put(b,new)`,
  overlaps a scan observing `a=old,b=new` with `Put(a,replacement)`, and returns
  the put first. The legal execution applies the unknown put, reads, then
  overwrites `a`. The guided attempt now also considers mismatch improvement
  for eligible confirmed reads that have already been invoked.

The preservation argument has three parts. First, changing a hint only permutes
the existing confirmed-operation candidates; neither hinted order is required.
Second, the set of guidance targets contains the old target, so the mismatch
rule only adds eligible unknown transitions to that restricted attempt. Every
added transition still comes from the unchanged full transition relation and
respects the existing invocation/outcome/progress filters. Third, both changes
are unused by unrestricted search, and restricted exhaustion still cannot
establish invalidity. Every positive result is replayed against the complete
unchanged model and all response barriers. The certificate/interval lemmas and
their stated Python refinement boundary therefore remain applicable. Neither
this argument nor the hints promise completeness within a finite budget.

The complete gate has 44 tests and 21 isolated source mutations. New controls
require a range snapshot between two inserts, preserve scan interval/limit
boundaries, observe scan absence, and permit an unknown write to explain an
overlapping read. Each mutation must cause exactly its intended assertion
failure, between green baseline and restoration runs. The earlier control
forcing preparation in both attempts is replaced by one contradicting the
read-derived preference, which now overrides those defaults. No unknown
outcome, complete history, attempt count, state limit or time limit is changed.
