//! Failure schedules execute the real DiskRaftStorage and raft-rs Ready loop.

use super::*;
use crate::rawnode::RaftPeer;
use kv9_common::fs::testing::{Crash, Fault, ModelFs, Operation};
use kv9_common::{NodeId, RegionId};
use raft::prelude::{Message, MessageType};
use std::sync::Arc;

const DIRECTORY: &str = "/new-parent/replica/raft";

fn open(fs: &ModelFs) -> DiskRaftStorage<ModelFs> {
    DiskRaftStorage::open_on(fs.clone(), Path::new(DIRECTORY), &[1, 2, 3])
        .unwrap()
        .0
}

fn batch_entries(first: u64, count: u64) -> Vec<Entry> {
    (first..first + count)
        .map(|index| Entry {
            term: 2,
            index,
            data: format!("group-entry-{index}").into_bytes().into(),
            ..Default::default()
        })
        .collect()
}

fn stored_entries(store: &DiskRaftStorage<ModelFs>) -> Vec<Entry> {
    let end = raft::Storage::last_index(store).unwrap() + 1;
    if end == 1 {
        return Vec::new();
    }
    raft::Storage::entries(store, 1, end, None, GetEntriesContext::empty(false)).unwrap()
}

#[test]
fn append_slice_uses_one_sync_and_empty_slices_do_no_io() {
    let fs = ModelFs::default();
    let store = open(&fs);
    let entries = batch_entries(1, 3);
    fs.clear_events();
    store.append(&entries).unwrap();
    assert_eq!(
        fs.events()
            .into_iter()
            .map(|event| event.operation)
            .collect::<Vec<_>>(),
        [
            Operation::Write,
            Operation::Write,
            Operation::Write,
            Operation::SyncData
        ],
        "one append slice must synchronize its ordered frames exactly once"
    );
    assert_eq!(stored_entries(&store), entries);
    fs.clear_events();
    store.append(&[]).unwrap();
    assert!(
        fs.events().is_empty(),
        "empty append performed filesystem I/O"
    );
    assert_eq!(stored_entries(&store), entries);
}

#[test]
fn append_batch_ack_survives_loss_of_unsynced_bytes() {
    let fs = ModelFs::default();
    let store = open(&fs);
    let entries = batch_entries(1, 3);
    store.append(&entries).unwrap();
    drop(store);
    fs.crash(Crash::LoseUnsynced);
    assert_eq!(
        stored_entries(&open(&fs)),
        entries,
        "acknowledged append batch lost an entry after loss of unsynced bytes"
    );
}

#[test]
fn every_append_batch_cut_fences_publication_and_preserves_a_recoverable_prefix() {
    batch_failure_matrix(false);
}

#[test]
fn replacement_batch_cuts_preserve_committed_prefix_and_valid_suffix_identity() {
    batch_failure_matrix(true);
}

fn batch_failure_matrix(replace_suffix: bool) {
    fn prepared(old: &[Entry], term: u64) -> (ModelFs, DiskRaftStorage<ModelFs>) {
        let fs = ModelFs::default();
        let store = open(&fs);
        store.append(old).unwrap();
        store
            .set_hardstate(&HardState {
                term,
                vote: 1,
                commit: 1,
                ..Default::default()
            })
            .unwrap();
        fs.clear_events();
        (fs, store)
    }
    let old = batch_entries(1, if replace_suffix { 5 } else { 1 });
    let mut suffix = batch_entries(2, 3);
    let term = if replace_suffix { 3 } else { 2 };
    for entry in &mut suffix {
        entry.term = term;
        if replace_suffix {
            entry.data = format!("replacement-entry-{}", entry.index)
                .into_bytes()
                .into();
        }
    }
    let expected: Vec<_> = old[..1].iter().chain(&suffix).cloned().collect();
    let (fs, store) = prepared(&old, term);
    store.append(&suffix).unwrap();
    assert_eq!(stored_entries(&store), expected);
    let cuts = fs.events();
    let mut cells = 0;
    for cut in cuts {
        for errno in [5, 28] {
            let mut faults = vec![Fault::Before(errno), Fault::After(errno)];
            if cut.operation == Operation::Write {
                faults.push(Fault::ShortWrite { bytes: 4, errno });
            }
            for fault in faults {
                for crash in [Crash::LoseUnsynced, Crash::KeepUnsynced]
                    .into_iter()
                    .chain((0..16).map(Crash::Seeded))
                {
                    let (fs, store) = prepared(&old, term);
                    fs.fail_at(cut.number, fault);
                    assert!(
                        store.append(&suffix).is_err(),
                        "failed batch was acknowledged"
                    );
                    assert!(fs.fault_arrived(), "selected batch fault did not arrive");
                    assert_eq!(
                        stored_entries(&store),
                        old,
                        "failed append batch published a memory suffix"
                    );
                    let after = fs.events().len();
                    assert!(store.append(&suffix).is_err());
                    assert!(store.append(&[]).is_err());
                    assert_eq!(
                        fs.events().len(),
                        after,
                        "fenced batch writer performed more I/O"
                    );
                    drop(store);
                    fs.crash(crash);
                    let store = open(&fs);
                    let recovered = stored_entries(&store);
                    // Before any replacement frame survives, the entire old
                    // suffix can remain. Once a new frame survives, its index
                    // truncates the old suffix: no mixed identity is allowed.
                    assert!(
                        recovered == old || (2..=expected.len()).any(|end| recovered == expected[..end]),
                        "batch recovery invented entries, mixed suffix identities, or lost the durable prefix: {cut:?} {fault:?} {crash:?}"
                    );
                    if cut.operation == Operation::SyncData && matches!(fault, Fault::After(_)) {
                        assert_eq!(
                            recovered, expected,
                            "completed batch sync lost its durable effect"
                        );
                    }
                    drop(store);
                    fs.crash(Crash::LoseUnsynced);
                    assert_eq!(
                        stored_entries(&open(&fs)),
                        recovered,
                        "recovered append prefix was exposed before becoming durable"
                    );
                    cells += 1;
                }
            }
        }
    }
    assert_eq!(cells, 396);
    println!("append batch matrix (replace_suffix={replace_suffix}): {cells} write/sync/error/crash cells");
}

fn hard_state(store: &DiskRaftStorage<ModelFs>) -> HardState {
    raft::Storage::initial_state(store).unwrap().hard_state
}

#[test]
fn original_ready_synchronizes_entries_and_hardstate_once_and_empty_does_no_io() {
    let fs = ModelFs::default();
    let store = open(&fs);
    let entries = batch_entries(1, 3);
    let hs = HardState {
        term: 2,
        vote: 1,
        commit: 3,
        ..Default::default()
    };
    fs.clear_events();
    store.persist_ready(&entries, Some(&hs)).unwrap();
    assert_eq!(
        fs.events()
            .iter()
            .map(|event| event.operation)
            .collect::<Vec<_>>(),
        [
            Operation::Write,
            Operation::Write,
            Operation::Write,
            Operation::Write,
            Operation::SyncData
        ],
        "original Ready must use one common sync after all entry and HardState frames"
    );
    assert_eq!(stored_entries(&store), entries);
    assert_eq!(hard_state(&store), hs);
    fs.clear_events();
    store.persist_ready(&[], None).unwrap();
    assert!(fs.events().is_empty());
    drop(store);
    fs.crash(Crash::LoseUnsynced);
    let recovered = open(&fs);
    assert_eq!(
        stored_entries(&recovered),
        entries,
        "acknowledged Ready lost an entry"
    );
    assert_eq!(
        hard_state(&recovered),
        hs,
        "acknowledged Ready lost term, vote or commit"
    );
}

#[test]
fn original_ready_ack_survives_loss_of_unsynced_bytes() {
    let fs = ModelFs::default();
    let store = open(&fs);
    let entries = batch_entries(1, 3);
    let hs = HardState {
        term: 2,
        vote: 1,
        commit: 3,
        ..Default::default()
    };
    store.persist_ready(&entries, Some(&hs)).unwrap();
    drop(store);
    fs.crash(Crash::LoseUnsynced);
    let recovered = open(&fs);
    assert_eq!(
        stored_entries(&recovered),
        entries,
        "acknowledged Ready lost an entry"
    );
    assert_eq!(
        hard_state(&recovered),
        hs,
        "acknowledged Ready lost term, vote or commit"
    );
}

#[test]
fn real_ready_combines_election_records_but_keeps_light_commit_durable() {
    use crate::RaftGroup;
    let fs = ModelFs::default();
    let store = DiskRaftStorage::open_on(fs.clone(), Path::new(DIRECTORY), &[1])
        .unwrap()
        .0;
    let peer = RaftPeer::with_storage(NodeId(1), RegionId(1), store).unwrap();
    peer.campaign().unwrap();
    fs.clear_events();
    peer.pump().unwrap();
    assert_eq!(
        fs.events()
            .iter()
            .map(|event| event.operation)
            .collect::<Vec<_>>(),
        [
            Operation::Write,
            Operation::Write,
            Operation::SyncData,
            Operation::Write,
            Operation::SyncData
        ],
        "original Ready and subsequent LightReady must have two ordered durability boundaries"
    );
    assert_eq!(peer.status_snapshot().committed, 1);
    fs.clear_events();
    peer.read_index(b"read-without-persistence".to_vec())
        .unwrap();
    peer.pump().unwrap();
    assert!(
        fs.events().is_empty(),
        "read-only Ready acquired a persistence boundary"
    );
    assert!(peer
        .take_read_states()
        .iter()
        .any(|state| state.request_ctx == b"read-without-persistence"));
    drop(peer);
    fs.crash(Crash::LoseUnsynced);
    let recovered = open(&fs);
    assert_eq!(
        hard_state(&recovered).commit,
        1,
        "LightReady commit was not durable"
    );
    assert_eq!(hard_state(&recovered).vote, 1);
}

#[test]
fn combined_follower_ready_never_sends_an_append_ack_after_any_persistence_failure() {
    fn prepare() -> (ModelFs, RaftPeer<DiskRaftStorage<ModelFs>>) {
        let fs = ModelFs::default();
        let peer = RaftPeer::with_storage(NodeId(1), RegionId(1), open(&fs)).unwrap();
        let entries: Vec<_> = batch_entries(1, 2)
            .into_iter()
            .map(|mut entry| {
                entry.term = 3;
                entry
            })
            .collect();
        peer.step_message(Message {
            msg_type: MessageType::MsgAppend,
            from: 2,
            to: 1,
            term: 3,
            commit: 2,
            entries: entries.into(),
            ..Default::default()
        });
        fs.clear_events();
        (fs, peer)
    }
    let (fs, peer) = prepare();
    let replies = peer.pump().unwrap();
    assert!(replies
        .iter()
        .any(|m| m.msg_type == MessageType::MsgAppendResponse
            && m.to == 2
            && m.index == 2
            && !m.reject));
    let cuts = fs.events();
    assert_eq!(
        cuts.iter().map(|c| c.operation).collect::<Vec<_>>(),
        [
            Operation::Write,
            Operation::Write,
            Operation::Write,
            Operation::SyncData
        ]
    );
    drop(peer);
    fs.crash(Crash::LoseUnsynced);
    let recovered = open(&fs);
    assert_eq!(hard_state(&recovered).commit, 2);
    assert_eq!(hard_state(&recovered).term, 3);
    assert_eq!(stored_entries(&recovered).len(), 2);
    let mut cells = 0;
    for cut in cuts {
        for errno in [5, 28] {
            let mut faults = vec![Fault::Before(errno), Fault::After(errno)];
            if cut.operation == Operation::Write {
                faults.push(Fault::ShortWrite { bytes: 4, errno });
            }
            for fault in faults {
                let (fs, peer) = prepare();
                fs.fail_at(cut.number, fault);
                assert!(
                    peer.pump().is_err(),
                    "failed joint Ready returned append acknowledgements"
                );
                assert!(fs.fault_arrived());
                assert_eq!(peer.status_snapshot().term, 3);
                assert!(peer.take_read_states().is_empty());
                let before = fs.events().len();
                assert!(peer.pump().is_err());
                assert_eq!(fs.events().len(), before);
                cells += 1;
            }
        }
    }
    assert_eq!(cells, 22);
}

#[derive(Clone, Copy, Debug)]
enum ReadyCut {
    EntriesOnly,
    HardStateOnly,
    AppendAndCommit,
    ReplaceAndCommit,
}

#[test]
fn every_ready_group_failure_preserves_a_valid_recovery_prefix_and_commit() {
    let mut cells = 0;
    for scenario in [
        ReadyCut::EntriesOnly,
        ReadyCut::HardStateOnly,
        ReadyCut::AppendAndCommit,
        ReadyCut::ReplaceAndCommit,
    ] {
        let old = batch_entries(
            1,
            if matches!(scenario, ReadyCut::ReplaceAndCommit) {
                5
            } else {
                1
            },
        );
        let prior = HardState {
            term: 2,
            vote: 1,
            commit: 1,
            ..Default::default()
        };
        let entries = if matches!(scenario, ReadyCut::HardStateOnly) {
            vec![]
        } else {
            let mut entries = batch_entries(2, 3);
            if !matches!(scenario, ReadyCut::EntriesOnly) {
                for entry in &mut entries {
                    entry.term = 3;
                    entry.data = format!("ready-new-{}", entry.index).into_bytes().into();
                }
            }
            entries
        };
        let next = (!matches!(scenario, ReadyCut::EntriesOnly)).then(|| HardState {
            term: 3,
            vote: 2,
            commit: if entries.is_empty() { 1 } else { 4 },
            ..Default::default()
        });
        let expected: Vec<_> = if entries.is_empty() {
            old.clone()
        } else {
            old[..1].iter().chain(&entries).cloned().collect()
        };
        let expected_hs = next.as_ref().unwrap_or(&prior);
        let prepare = || {
            let fs = ModelFs::default();
            let store = open(&fs);
            store.append(&old).unwrap();
            store.set_hardstate(&prior).unwrap();
            fs.clear_events();
            (fs, store)
        };
        let (fs, store) = prepare();
        store.persist_ready(&entries, next.as_ref()).unwrap();
        assert_eq!(stored_entries(&store), expected);
        assert_eq!(hard_state(&store), *expected_hs);
        let cuts = fs.events();
        assert_eq!(cuts.len(), entries.len() + usize::from(next.is_some()) + 1);
        assert_eq!(cuts.last().unwrap().operation, Operation::SyncData);
        for cut in cuts {
            for errno in [5, 28] {
                let mut faults = vec![Fault::Before(errno), Fault::After(errno)];
                if cut.operation == Operation::Write {
                    faults.push(Fault::ShortWrite { bytes: 4, errno });
                }
                for fault in faults {
                    for crash in [Crash::LoseUnsynced, Crash::KeepUnsynced]
                        .into_iter()
                        .chain((0..16).map(Crash::Seeded))
                    {
                        let (fs, store) = prepare();
                        fs.fail_at(cut.number, fault);
                        assert!(
                            store.persist_ready(&entries, next.as_ref()).is_err(),
                            "failed original Ready was acknowledged"
                        );
                        assert!(fs.fault_arrived(), "selected Ready fault never arrived");
                        assert_eq!(
                            stored_entries(&store),
                            old,
                            "failed original Ready published memory entries"
                        );
                        assert_eq!(
                            hard_state(&store),
                            prior,
                            "failed original Ready published memory HardState"
                        );
                        let after = fs.events().len();
                        assert!(store.persist_ready(&[], None).is_err());
                        assert!(store.persist_ready(&entries, next.as_ref()).is_err());
                        assert!(store.append(&[]).is_err());
                        assert!(store.set_hardstate(&prior).is_err());
                        assert_eq!(
                            fs.events().len(),
                            after,
                            "fenced Ready writer performed more I/O"
                        );
                        drop(store);
                        fs.crash(crash);
                        let recovered = open(&fs);
                        let log = stored_entries(&recovered);
                        let hs = hard_state(&recovered);
                        assert!(log == old || (2..=expected.len()).any(|end| log == expected[..end]), "Ready recovery mixed suffix identities: {scenario:?} {cut:?} {fault:?} {crash:?}");
                        assert!(
                            hs == prior || hs == *expected_hs,
                            "Ready recovery invented a term/vote/commit"
                        );
                        if hs != prior {
                            assert_eq!(
                                log, expected,
                                "new HardState survived without its complete preceding log"
                            );
                        }
                        assert!(
                            hs.commit <= log.last().unwrap().index,
                            "recovered commit exceeded the complete log"
                        );
                        assert_eq!(
                            log[0], old[0],
                            "Ready recovery lost the previously committed prefix"
                        );
                        if cut.operation == Operation::SyncData && matches!(fault, Fault::After(_))
                        {
                            assert_eq!(log, expected, "completed Ready sync lost log entries");
                            assert_eq!(hs, *expected_hs, "completed Ready sync lost HardState");
                        }
                        drop(recovered);
                        fs.crash(Crash::LoseUnsynced);
                        let recovered = open(&fs);
                        assert_eq!(
                            stored_entries(&recovered),
                            log,
                            "recovered Ready log was not synchronized"
                        );
                        assert_eq!(
                            hard_state(&recovered),
                            hs,
                            "recovered Ready HardState was not synchronized"
                        );
                        cells += 1;
                    }
                }
            }
        }
    }
    assert_eq!(cells, 1584);
    println!("Ready group matrix: {cells} actual storage write/sync/failure/crash cells");
}

fn vote_request(candidate: u64, term: u64) -> Message {
    Message {
        msg_type: MessageType::MsgRequestVote,
        from: candidate,
        to: 1,
        term,
        ..Default::default()
    }
}

fn granted(messages: &[Message], candidate: u64, term: u64) -> bool {
    messages.iter().any(|m| {
        m.msg_type == MessageType::MsgRequestVoteResponse
            && m.to == candidate
            && m.term == term
            && !m.reject
    })
}

#[derive(Clone, Copy, Debug)]
enum DriverCut {
    Vote,
    Configuration,
}

fn prepared_driver(
    fs: &ModelFs,
    scenario: DriverCut,
) -> (
    Arc<crate::driver::NodeDriver<DiskRaftStorage<ModelFs>>>,
    crate::transport::InProcEndpoint,
) {
    use crate::{transport::RaftTransport, RaftGroup};
    let voters: &[u64] = match scenario {
        DriverCut::Vote => &[1, 2, 3],
        DriverCut::Configuration => &[1],
    };
    let store = DiskRaftStorage::open_on(fs.clone(), Path::new(DIRECTORY), voters)
        .unwrap()
        .0;
    let peer = Arc::new(RaftPeer::with_storage(NodeId(1), RegionId(1), store).unwrap());
    let hub = crate::transport::InProcHub::new();
    let remote = hub.endpoint(NodeId(2));
    let driver = crate::driver::NodeDriver::new(
        peer.clone(),
        Arc::new(hub.endpoint(NodeId(1))),
        crate::MemStateMachine::new(),
    )
    .unwrap();
    match scenario {
        DriverCut::Vote => remote.send(NodeId(1), vote_request(2, 7)),
        DriverCut::Configuration => {
            peer.campaign().unwrap();
            driver.step().unwrap();
            driver.step().unwrap();
            peer.read_index(b"must-not-escape-failed-ready".to_vec())
                .unwrap();
            driver.add_learner(NodeId(2)).unwrap();
        }
    }
    fs.clear_events();
    (driver, remote)
}

#[test]
fn driver_persistence_failures_stop_without_poisoning_observation_locks() {
    use crate::{transport::RaftTransport, RaftGroup};
    let mut cells = 0;
    let mut causes = std::collections::BTreeSet::new();
    for scenario in [DriverCut::Vote, DriverCut::Configuration] {
        let fs = ModelFs::default();
        let (driver, remote) = prepared_driver(&fs, scenario);
        driver.step().unwrap();
        match scenario {
            DriverCut::Vote => assert!(granted(&remote.drain(), 2, 7)),
            DriverCut::Configuration => assert_eq!(driver.status().learners, [2]),
        }
        let cuts = fs.events();
        assert!(!cuts.is_empty());
        for cut in cuts {
            assert!(matches!(
                cut.operation,
                Operation::Write | Operation::SyncData
            ));
            for errno in [5, 28] {
                for fault in [Fault::Before(errno), Fault::After(errno)] {
                    let fs = ModelFs::default();
                    let (driver, remote) = prepared_driver(&fs, scenario);
                    let before = driver.status();
                    fs.fail_at(cut.number, fault);
                    let error = driver
                        .step()
                        .expect_err("failed persistence must stop the driver");
                    assert!(matches!(error, Error::Raft(_)));
                    assert!(
                        fs.fault_arrived(),
                        "fault did not arrive: {scenario:?} {cut:?}"
                    );
                    // This used to panic while holding peer.inner, leaving even
                    // status() unusable. Observation must survive the I/O error.
                    let status = driver.status();
                    let fatal = status.fatal.expect("runtime must observe a fatal cause");
                    for operation in [
                        "append",
                        "hardstate",
                        "ready sync",
                        "confstate",
                        "light-ready hardstate",
                    ] {
                        if fatal.contains(&format!("during {operation}:")) {
                            causes.insert(operation);
                        }
                    }
                    assert_eq!(status.applied_index, before.applied_index);
                    assert_eq!(status.driver_applied, before.driver_applied);
                    assert_eq!(status.conf_index, before.conf_index);
                    assert!(
                        remote.drain().is_empty(),
                        "failed Ready must emit no messages"
                    );
                    assert!(driver.peer().take_read_states().is_empty());
                    let operations = fs.events().len();
                    let term = driver.peer().term();
                    for _ in 0..3 {
                        assert!(driver.tick_and_step().is_err());
                        driver.peer().step_message(vote_request(2, term + 10));
                        assert!(driver.peer().pump().is_err());
                        assert!(driver.peer().campaign().is_err());
                        assert!(driver.peer().read_index(b"after-failure".to_vec()).is_err());
                        assert!(driver.peer().propose_raw_for_harness(vec![1]).is_err());
                        assert!(driver.add_learner(NodeId(3)).is_err());
                    }
                    assert_eq!(
                        fs.events().len(),
                        operations,
                        "fatal peer performed more I/O"
                    );
                    assert_eq!(driver.peer().term(), term, "fatal peer processed a message");
                    assert_eq!(driver.status().fatal.as_deref(), Some(fatal.as_str()));
                    assert!(remote.drain().is_empty());
                    cells += 1;
                }
            }
        }
    }
    assert_eq!(
        causes.into_iter().collect::<Vec<_>>(),
        [
            "append",
            "confstate",
            "hardstate",
            "light-ready hardstate",
            "ready sync"
        ]
    );
    println!("driver persistence matrix: {cells} named write/sync failure cells");
}

#[test]
fn acknowledged_vote_survives_loss_of_unsynced_namespace() {
    let fs = ModelFs::default();
    let peer = RaftPeer::with_storage(NodeId(1), RegionId(1), open(&fs)).unwrap();
    peer.step_message(vote_request(2, 7));
    assert!(
        granted(&peer.pump().unwrap(), 2, 7),
        "positive control: the first vote must leave the real Ready loop"
    );
    assert!(fs
        .events()
        .iter()
        .any(|e| e.operation == Operation::SyncData));
    drop(peer);
    fs.crash(Crash::LoseUnsynced);
    let peer = RaftPeer::with_storage(NodeId(1), RegionId(1), open(&fs)).unwrap();
    peer.step_message(vote_request(3, 7));
    assert!(
        !granted(&peer.pump().unwrap(), 3, 7),
        "a durable voter must not grant two candidates in the same term after power loss"
    );
}

#[test]
fn partial_append_failure_prevents_later_acknowledgment() {
    let fs = ModelFs::default();
    let store = open(&fs);
    // Establish the namespace separately: this cell isolates failed-write
    // continuation from the independent directory-publication defect.
    fs::sync_ancestors(&fs, Path::new(DIRECTORY)).unwrap();
    let hs = HardState {
        term: 7,
        vote: 2,
        ..Default::default()
    };
    store.set_hardstate(&hs).unwrap();
    fs.clear_events();
    fs.fail_at(0, Fault::ShortWrite { bytes: 4, errno: 5 });
    let failed = HardState {
        term: 8,
        vote: 3,
        ..Default::default()
    };
    assert!(store.set_hardstate(&failed).is_err());
    assert!(
        fs.fault_arrived(),
        "the real append must reach the selected short write"
    );
    let path = Path::new(DIRECTORY).join("raft.log");
    let broken = fs.visible_bytes(&path).unwrap();
    assert!(
        store.set_hardstate(&failed).is_err(),
        "a failed append must refuse later acknowledgments until recovery"
    );
    assert_eq!(
        fs.visible_bytes(&path).unwrap(),
        broken,
        "a poisoned writer must not append after the partial frame"
    );
    assert_eq!(raft::Storage::initial_state(&store).unwrap().hard_state, hs);
    drop(store);
    fs.crash(Crash::KeepUnsynced);
    assert_eq!(
        raft::Storage::initial_state(&open(&fs)).unwrap().hard_state,
        hs
    );
}

#[test]
fn every_initialization_io_cut_refuses_then_recovers() {
    let baseline = ModelFs::default();
    drop(open(&baseline));
    let cuts: Vec<_> = baseline
        .events()
        .into_iter()
        .filter(|e| !(e.operation == Operation::CreateDir && e.path == Path::new("/")))
        .collect();
    assert!(cuts.iter().any(|e| e.operation == Operation::SyncDir));
    for cut in &cuts {
        for errno in [5, 28] {
            for fault in [Fault::Before(errno), Fault::After(errno)] {
                let fs = ModelFs::default();
                fs.fail_at(cut.number, fault);
                let result = DiskRaftStorage::open_on(fs.clone(), Path::new(DIRECTORY), &[1, 2, 3]);
                assert!(
                    fs.fault_arrived(),
                    "initialization fault did not arrive: {cut:?} {fault:?}"
                );
                assert!(
                    result.is_err(),
                    "initialization I/O failure must refuse opening: {cut:?} {fault:?}"
                );
                // Retry while unsynced names from the previous process remain
                // visible. Publishing only newly created paths would lose them.
                let store = open(&fs);
                let hs = HardState {
                    term: 7,
                    vote: 2,
                    ..Default::default()
                };
                store.set_hardstate(&hs).unwrap();
                drop(store);
                fs.crash(Crash::LoseUnsynced);
                assert_eq!(raft::Storage::initial_state(&open(&fs)).unwrap().hard_state, hs,
                    "retry over visible but unsynced names lost an acknowledged vote: {cut:?} {fault:?}");
            }
        }
    }
    println!(
        "initialization matrix: {} named cuts, {} error/recovery cells",
        cuts.len(),
        cuts.len() * 4
    );
}

#[test]
fn write_and_sync_errors_preserve_acknowledged_prefix_for_seeded_crashes() {
    let mut cells = 0;
    for errno in [5, 28] {
        let faults = [
            (0, Fault::Before(errno)),
            (0, Fault::After(errno)),
            (0, Fault::ShortWrite { bytes: 4, errno }),
            (1, Fault::Before(errno)),
            (1, Fault::After(errno)),
        ];
        for (at, fault) in faults {
            for seed in 0..32 {
                let fs = ModelFs::default();
                let store = open(&fs);
                let old = HardState {
                    term: 7,
                    vote: 2,
                    ..Default::default()
                };
                let proposed = HardState {
                    term: 8,
                    vote: 3,
                    ..Default::default()
                };
                store.set_hardstate(&old).unwrap();
                fs.clear_events();
                fs.fail_at(at, fault);
                assert!(store.set_hardstate(&proposed).is_err());
                assert!(
                    fs.fault_arrived(),
                    "write fault did not arrive: {at} {fault:?} seed={seed}"
                );
                assert_eq!(
                    raft::Storage::initial_state(&store).unwrap().hard_state,
                    old,
                    "failed persistence must not publish its memory update"
                );
                let before = fs.events().len();
                assert!(store.set_hardstate(&proposed).is_err());
                assert_eq!(
                    fs.events().len(),
                    before,
                    "poisoned writes must perform no more filesystem operations"
                );
                drop(store);
                fs.crash(Crash::Seeded(seed));
                let recovered = raft::Storage::initial_state(&open(&fs)).unwrap().hard_state;
                assert!(recovered == old || recovered == proposed,
                    "recovery lost the acknowledged prefix or invented a vote: {at} {fault:?} seed={seed}: {recovered:?}");
                if at == 1 && matches!(fault, Fault::After(_)) {
                    assert_eq!(
                        recovered, proposed,
                        "an error after completed sync must retain that sync's effect"
                    );
                }
                cells += 1;
            }
        }
    }
    assert_eq!(cells, 320);
    println!("append matrix: {cells} write/sync/error/seed cells");
}

#[test]
fn recovered_unsynced_tail_is_durable_before_a_repeated_crash() {
    let fs = ModelFs::default();
    let store = open(&fs);
    let hs = HardState {
        term: 7,
        vote: 2,
        ..Default::default()
    };
    store.set_hardstate(&hs).unwrap();
    drop(store);
    // A complete frame can survive process death without its file sync.
    let proposed = HardState {
        term: 8,
        vote: 3,
        ..Default::default()
    };
    let payload = proposed.write_to_bytes().unwrap();
    let path = Path::new(DIRECTORY).join("raft.log");
    let mut f = fs.open_append(&path).unwrap();
    let mut body = vec![REC_HARD_STATE];
    body.extend_from_slice(&payload);
    f.write_all(&(body.len() as u32).to_be_bytes()).unwrap();
    f.write_all(&fnv1a(&body).to_be_bytes()).unwrap();
    f.write_all(&body).unwrap();
    drop(f);
    let store = open(&fs);
    assert_eq!(
        raft::Storage::initial_state(&store).unwrap().hard_state,
        proposed
    );
    drop(store);
    fs.crash(Crash::LoseUnsynced);
    assert_eq!(
        raft::Storage::initial_state(&open(&fs)).unwrap().hard_state,
        proposed,
        "a recovered vote exposed to Raft must survive the next power loss"
    );
}

#[test]
fn three_voter_applied_positions_survive_an_immediate_power_loss() {
    use crate::{transport::InProcHub, Command, RaftGroup, Role};
    let filesystems = [ModelFs::default(), ModelFs::default(), ModelFs::default()];
    let hub = InProcHub::new();
    let drivers: Vec<_> = filesystems
        .iter()
        .enumerate()
        .map(|(i, fs)| {
            let id = NodeId(i as u64 + 1);
            let peer = Arc::new(RaftPeer::with_storage(id, RegionId(1), open(fs)).unwrap());
            crate::driver::NodeDriver::new(
                peer,
                Arc::new(hub.endpoint(id)),
                crate::MemStateMachine::new(),
            )
            .unwrap()
        })
        .collect();
    drivers[0].peer().campaign().unwrap();
    for _ in 0..20 {
        for driver in &drivers {
            driver.step().unwrap();
        }
        if drivers[0].status().role == Role::Leader {
            break;
        }
    }
    assert_eq!(drivers[0].status().role, Role::Leader);
    let proposal = drivers[0]
        .propose(&Command::Put {
            cf: 0,
            key: b"committed".to_vec(),
            value: b"recoverable".to_vec(),
        })
        .unwrap();
    // Stop as soon as every replica has applied the proposal. No later Ready
    // or heartbeat may accidentally repair a missing durable commit watermark.
    for _ in 0..20 {
        for driver in &drivers {
            driver.step().unwrap();
        }
        if drivers
            .iter()
            .all(|d| d.status().applied_index >= proposal.index.0)
        {
            break;
        }
    }
    let positions: Vec<_> = drivers
        .iter()
        .map(|d| d.driver_applied().unwrap())
        .collect();
    assert!(positions.iter().all(|p| p.index >= proposal.index.0));
    drop(drivers);
    for (fs, at) in filesystems.iter().zip(positions) {
        fs.crash(Crash::LoseUnsynced);
        let storage = open(fs);
        assert_eq!(storage.committed_term(at.index).unwrap(), at.term);
    }
}

#[test]
fn wal_observation_preserves_write_sync_short_circuit_and_writer_poison() {
    use kv9_common::metrics::Outcome;
    for cut in [0, 1] {
        for errno in [5, 28] {
            for fault in [Fault::Before(errno), Fault::After(errno)] {
                let fs = ModelFs::default();
                let store = open(&fs);
                let metrics = store.io_metrics();
                let before_write =
                    metrics.write.snapshot().outcomes[Outcome::Success as usize].count;
                let before_sync = metrics.sync.snapshot().outcomes[Outcome::Success as usize].count;
                fs.clear_events();
                fs.fail_at(cut, fault);
                let error = store
                    .set_hardstate(&HardState {
                        term: 7,
                        vote: 2,
                        commit: 0,
                        ..Default::default()
                    })
                    .unwrap_err();
                assert!(
                    error.to_string().contains(&format!("os error {errno}")),
                    "original errno lost: {error}"
                );
                assert!(fs.fault_arrived());
                let writes = metrics.write.snapshot();
                let syncs = metrics.sync.snapshot();
                assert_eq!(
                    writes.outcomes[Outcome::Success as usize].count - before_write,
                    u64::from(cut == 1)
                );
                assert_eq!(
                    writes.outcomes[Outcome::Error as usize].count,
                    u64::from(cut == 0)
                );
                assert_eq!(syncs.outcomes[Outcome::Success as usize].count, before_sync);
                assert_eq!(
                    syncs.outcomes[Outcome::Error as usize].count,
                    u64::from(cut == 1),
                    "sync observation must match actual fsync attempts"
                );
                assert_eq!(
                    fs.events().len(),
                    cut + 1,
                    "failed write must short-circuit fsync"
                );
                assert!(store
                    .set_hardstate(&HardState {
                        term: 8,
                        vote: 3,
                        commit: 0,
                        ..Default::default()
                    })
                    .is_err());
                assert_eq!(
                    fs.events().len(),
                    cut + 1,
                    "poisoned writer performed more I/O"
                );
                assert_eq!(
                    metrics.write.snapshot().outcomes[Outcome::Error as usize].count,
                    u64::from(cut == 0)
                );
                assert_eq!(
                    raft::Storage::initial_state(&store)
                        .unwrap()
                        .hard_state
                        .term,
                    0
                );
            }
        }
    }
    // write_all can contain a successful short write followed by an error.
    // It remains one failed record write and performs no record fsync.
    let fs = ModelFs::default();
    let store = open(&fs);
    let metrics = store.io_metrics();
    let before_sync = metrics.sync.snapshot().outcomes[Outcome::Success as usize].count;
    fs.clear_events();
    fs.fail_at(
        0,
        Fault::ShortWrite {
            bytes: 3,
            errno: 28,
        },
    );
    assert!(store
        .set_hardstate(&HardState {
            term: 7,
            vote: 2,
            commit: 0,
            ..Default::default()
        })
        .is_err());
    assert_eq!(
        metrics.write.snapshot().outcomes[Outcome::Error as usize].count,
        1
    );
    assert_eq!(
        metrics.sync.snapshot().outcomes[Outcome::Success as usize].count,
        before_sync
    );
    assert!(fs.events().iter().all(|e| e.operation == Operation::Write));
}

#[test]
fn recovery_only_faults_preserve_votes_across_repeated_power_loss() {
    fn prepared() -> ModelFs {
        let fs = ModelFs::default();
        let peer = RaftPeer::with_storage(NodeId(1), RegionId(1), open(&fs)).unwrap();
        peer.step_message(vote_request(2, 7));
        assert!(granted(&peer.pump().unwrap(), 2, 7));
        drop(peer);
        fs.crash(Crash::LoseUnsynced);
        fs.clear_events();
        fs
    }
    fn recover(fs: &ModelFs) -> Result<DiskRaftStorage<ModelFs>> {
        DiskRaftStorage::open_mode(fs.clone(), Path::new(DIRECTORY), &[], false).map(|v| v.0)
    }
    let fs = prepared();
    drop(recover(&fs).unwrap());
    let cuts = fs.events();
    assert!(!cuts.is_empty());
    assert!(cuts
        .iter()
        .all(|event| !matches!(event.operation, Operation::CreateDir | Operation::Write)));
    let mut cells = 0;
    for cut in &cuts {
        for errno in [5, 28] {
            for fault in [Fault::Before(errno), Fault::After(errno)] {
                for crash in [
                    Crash::LoseUnsynced,
                    Crash::KeepUnsynced,
                    Crash::Seeded(1),
                    Crash::Seeded(7),
                ] {
                    let fs = prepared();
                    fs.fail_at(cut.number, fault);
                    assert!(
                        recover(&fs).is_err(),
                        "recovery I/O error exposed a usable store"
                    );
                    assert!(fs.fault_arrived());
                    fs.crash(crash);
                    let peer =
                        RaftPeer::with_storage(NodeId(1), RegionId(1), recover(&fs).unwrap())
                            .unwrap();
                    peer.step_message(vote_request(3, 7));
                    let messages = peer.pump().unwrap();
                    assert!(
                        !granted(&messages, 3, 7),
                        "recovery-only retry granted a second vote in the same term"
                    );
                    assert!(messages
                        .iter()
                        .any(|message| message.to == 3 && message.term == 7 && message.reject));
                    drop(peer);
                    fs.crash(Crash::LoseUnsynced);
                    let state = raft::Storage::initial_state(&recover(&fs).unwrap())
                        .unwrap()
                        .hard_state;
                    assert_eq!((state.term, state.vote), (7, 2));
                    cells += 1;
                }
            }
        }
    }
    assert_eq!(cells, cuts.len() * 16);
    println!(
        "recovery-only matrix: {} operation cuts, {cells} error/crash cells",
        cuts.len()
    );
}
