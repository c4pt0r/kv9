# Historical performance input recovery

The unchanged upper-bound versus selected-CRC screen has enough observed disk and tmpfs capacity, but its exact fixed native v3 executable was not found in the bounded retained-copy search. No client was rebuilt and no workload ran. Historical source/output paths remain untouched.

## Inputs actually verified or recovered

| Role | Revision | Executable SHA-256 | Current result |
| --- | --- | --- | --- |
| Selected CRC | `bd42e60f84657e22e36e34924a5c80a08eac623a` | `106f517c84fabe790ea139f3c18661e14447abd9e257fdd6ba82bfabe6796eb9` | Original 16,153,088-byte ELF retained; all 859 source files, clean checkout, exact build manifest and default Cargo graph verified |
| Default upper-bound | `e2e23cca5e70a9ea0cc241877b3b35b5b6433d27` | `6f074e867eae45274c17b54aa763888e92db2c45d5757974fa52ee0f15936d49` | Original 16,151,920-byte ELF retained; all 1,116 source files, clean checkout, exact build manifest and default Cargo graph verified |
| Fixed native v3 client | `0be806d9671e2c50701a64aa7889c8859b7648ba` | `8da9af469f962a938027d1970141bbe4622f7d42b2b795f720e288fb3f8d5957` | Original 5,594,104-byte ELF absent; exact build metadata and all source bytes recovered |

The client build's original output `/home/dongxu/kv9/target/release/kv9-batch-benchmark`, retained release root `/tmp/kv9-point-write-v3-release-first`, and source worktree `/tmp/kv9-point-write-measurement-v3` are absent. No exact executable was found among named or original-size files in the bounded kv9-owned retained roots, explicit shared release/cache directories, or current process executable identities. `copy-search.json` records the scope; it is not a whole-host proof of absence. The known published screen inventories retain client metadata, not its ELF.

`client-original-build/` contains byte-exact original `build.json`, `cargo.jsonl` and `sources.json`, recovered from `docs/published-directory-performance-v1/original-evidence.tar.gz` (archive SHA `cb86d1ce67c278c9cccf86edcb1fb8e17165472d4be25ceb9a2a744a1b9b5186`). Their original hashes are:

- build: `eb8b4e1421dd4e64dcca59fcc7829926d5789611f6b3748d07c4090f634f2c4c`
- Cargo records: `c68ed599b2b0185d8b8bd4ea277d04345f6b5442cdf851f59e93918a5e2a5d06`
- source inventory: `74298441490d8ecb5c17e7004597e1ab66173cd3fda7c5ae147f2e32a6dcc65c`

`client-source-0be806d/` is an exact 581-file, 6,373,684-byte export of the locally retained commit. Every file matches the original SHA-256 map; aggregate source-map SHA is `878339ad2d1aa862b0b24faaae6c2b8c28d9db115a3eb4d473aef6205292b948`. It is deliberately a source export, not a newly fabricated historical Git worktree. `run_fixture.py` is the exact missing RESP/data helper recovered from the same archive, SHA `008c5bea0640a4a5a092feb6617798a84e9dd4889fd11bf8c6791cfe0852864a`.

## Smallest next qualification, not executed

First try to reproduce the missing client in a fresh clean detached checkout of the same commit, using the retained Rust **1.94.0** toolchain explicitly. Current default stable is **1.98.1**, so an unqualified `cargo`/`rustc` invocation is unsuitable. `/home/dongxu/.rustup/toolchains/1.94.0-x86_64-unknown-linux-gnu/bin/{rustc,cargo}` still exists and reports the original rustc commit `4a4ef493e3a1488c6e321570238084b38948f6db`, LLVM 21.1.8 and Cargo `85eff7c80`. No download is required for that compiler. The recovered Cargo.lock SHA is `9d8d56d9e707ea3178c4ba503e424d5170b7435a31f1a29c2f87e9afa1ea2353`; package-cache completeness still requires a fresh offline build preflight.

The exact original build command was:

```text
cargo build --locked -p kv9-server --bin kv9-batch-benchmark --message-format=json-render-diagnostics --release
```

Use the existing protected BuildCache lock/invalidation checks, four jobs, offline dependency inputs, no added features and the original release profile. A small wrapper can retain source before/after, explicit compiler/linker/protoc identities, every actual child result and the new ELF without changing the recovered historical metadata. The original source builder is `scripts/build-workload.py --release --binary kv9-batch-benchmark --output FRESH_BUILD_ROOT`; it has a 900-second Cargo limit and a full source snapshot. Wrap it with the established 8 GiB floor / 16 GiB sampled-decrease budget and 8 MiB launch allowance. This is a future execution proposal, not a released command or an assertion that original compiler/linker inputs have all been reproduced.

Compare the new ELF to the historical hash before choosing the next route. If byte-identical, record that it was reproduced, keeping the new build receipt separate from the recovered original provenance. If different, it is a new causal input: separately qualify the client binary/default-feature/report bindings and its point Put/BatchPut64 behavior through the complete eight-smoke gate, and retain targeted changed-pin refusal checks. Do not present old client acceptance or old timing measurements as acceptance of different bytes. No server rebuild is needed for this comparison.

After the client identity is resolved, prepare only explicit path/binding substitutions for the recovered source/build/helper and fresh data-volume evidence outputs. The old binder requires a real clean Git checkout, and driver/auditor/smoke/retention helpers have literal source/output pins; the source export alone cannot satisfy those checks. Preserve the exact 8-smoke/16-ten-second matrix, opposite orders, all health, histogram, drain, final readback, isolation, retention and restore predicates. Qualify the output-filesystem accounting if moving the frozen `/tmp` output paths to the separate data volume; the checkpoint Chaos guard change does not automatically modify this benchmark policy. Do not patch or overwrite the frozen preparation in place.

## Current environment

Assessment `2204fb/0` verifies all 136 frozen upper-bound preparation files and the actual completed 21-window Chaos/post binding. The original three-container identity, restorable CPU sets and cluster/fault inventory checks also pass read-only (`a99522/0`). `/usr/bin/zstd` still matches the frozen retention codec SHA. No Cargo/rustc/proof-Java/zstd process was observed in the assessment snapshot; this is not a promise of future exclusivity.

At the final assessment, root/NVMe available space was **877,496,307,712 bytes**, exceeding the unchanged **79,455,850,496-byte** full-screen empirical requirement by **798,040,457,216 bytes**. Tmpfs had **66,274,971,648 bytes** versus the **34,359,738,368-byte** launch guard. The data volume had **9,690,734,428,160 bytes**. Keep 24 GiB host measurement floors, 32/16 GiB tmpfs launch/runtime floors, 8 GiB retention floor, existing caps, and 16 GiB restore plus 8 MiB metadata reserve unchanged. Availability is an observation, not a reservation; refresh immediately before any actual run.

The first assessment stopped at `53947/5595d1/1` when its diagnostic equality assertion encountered the changed default compiler; that source and failure are retained. Read-only filename/schema discovery errors are listed separately. An incidental Python import created one new bytecode file beside the frozen isolator; only that exact newly generated file and its empty directory were removed, with source hash unchanged (`incidental-bytecode-correction.json`). No historical cache, source, payload or binary was removed. No benchmark, codec workload, package installation or GitHub action was performed.
