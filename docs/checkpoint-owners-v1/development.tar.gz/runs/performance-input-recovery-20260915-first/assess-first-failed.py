#!/usr/bin/env python3
import ast,hashlib,json,os,stat,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;PREP=Path('/tmp/kv9-upper-bound-performance-preparation-20260915-first')
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def save(n,x):
 with (P/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
def command(argv,cwd=None):
 r=subprocess.run(argv,cwd=cwd,capture_output=True,text=True,timeout=30);assert r.returncode==0,(argv,r.stderr);return r.stdout
roles=json.loads((PREP/'readiness/role-inputs.json').read_text())['roles'];verified={};inputs=[]
(P/'originals').mkdir()
for role in ['old','new']:
 r=roles[role];build=Path(r['build_root']);source=Path(r['source_root']);m=json.loads((build/'build.json').read_text())
 assert sha(build/'build.json')==r['manifest']['sha256'];assert sha(build/'kv9')==r['binary_sha256']==m['binaries']['kv9']['sha256']
 rev=command(['git','-c','safe.directory='+str(source),'rev-parse','HEAD'],source).strip();status=command(['git','-c','safe.directory='+str(source),'status','--porcelain','--untracked-files=all'],source)
 assert rev==r['revision']and not status
 assert len(m['sources'])==r['source_files'];total=0
 for name,digest in m['sources'].items():
  assert sha(source/name)==digest,name;total+=(source/name).stat().st_size
 assert hashlib.sha256(json.dumps(m['sources'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==r['source_tree_sha256']
 records=[json.loads(x)for x in (build/'kv9-cargo.jsonl').read_text().splitlines()];assert records[-1]=={'reason':'build-finished','success':True}
 features={}
 for name in ('kv9','kv9_engine','kv9_raft','kv9_server'):
  rr=[x for x in records if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')==name];assert len(rr)==1;row=rr[0];assert row['features']==[]and row['profile']['opt_level']=='3'and not row['profile']['test'];features[name]=row['features']
 verified[role]={'complete':True,'revision':rev,'clean':True,'source_files':len(m['sources']),'source_bytes':total,'source_tree_sha256':r['source_tree_sha256'],'source_root':str(source),'binary':pin(build/'kv9'),'manifest':pin(build/'build.json'),'cargo':pin(build/'kv9-cargo.jsonl'),'default_features':features,'rustc':m['rustc'],'command':m['binaries']['kv9']['command']}
 for name in ('build.json','kv9-cargo.jsonl'):
  q=P/'originals'/(role+'-'+name);q.write_bytes((build/name).read_bytes())
pi=json.loads((PREP/'inventory.json').read_text());prep_errors=[]
for row in pi['files']:
 f=PREP/row['path']
 if not f.exists()or f.stat().st_size!=row['bytes']or sha(f)!=row['sha256']:prep_errors.append(row['path'])
assert not prep_errors
binding=json.loads((PREP/'actual-chaos-binding.json').read_text());assert binding['complete']and binding['all_post_phases_complete']
for path,r in binding['inputs'].items():assert Path(path).stat().st_size==r['bytes']and sha(path)==r['sha256']
for path in [PREP/'inventory.json',PREP/'ROOT-COMMANDS.json',PREP/'capacity.json',PREP/'actual-chaos-binding.json',PREP/'prerequisites.json',PREP/'readiness/role-inputs.json',PREP/'readiness/role-bindings-first.json',Path('/tmp/kv9-c04-ledger-environment-capacity-20260915-first/protected-metadata.json')]:
 name=path.name if path.name!='inventory.json'else 'preparation-inventory.json';q=P/'originals'/name;q.write_bytes(path.read_bytes());inputs.append(pin(path))
# Bounded known-copy search by names/size, with no original WAL/data/archive body scan.
roots=[x for x in Path('/tmp').iterdir()if x.is_dir()and x.name.startswith('kv9-')];found=[];scanned=[]
skip={'cohorts','data','logs','objects','proofs','node_modules','.git','deps','incremental','build','work','target','tmp','tlapm'}
for root in roots:
 scanned.append(str(root))
 for current,dirs,files in os.walk(root):
  rel=Path(current).relative_to(root)
  if len(rel.parts)>=3:dirs[:]=[]
  else:dirs[:]=[d for d in dirs if d not in skip]
  for n in files:
   p=Path(current)/n
   try:s=p.stat()
   except FileNotFoundError:continue
   if n=='kv9-batch-benchmark' or n.startswith('kv9_batch_benchmark')or s.st_size==5594104:
    if stat.S_ISREG(s.st_mode):found.append(pin(p))
for root in [Path('/home/dongxu/kv9/target/release'),Path('/home/dongxu/kv9/target/release/deps'),Path('/tmp/kv9-c04-configuration-development-20260915-first/target/release/deps')]:
 if root.exists():
  for p in root.iterdir():
   if p.is_file()and ('benchmark' in p.name or p.stat().st_size==5594104):found.append(pin(p))
processes=[];process_matches=[];gaps=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  comm=(p/'comm').read_text().strip();exe=p/'exe'
  if comm in {'cargo','rustc','rustdoc','java','tlapm','zstd','kv9-batch-bench','kv9-batch-benchm'}:
   row={'pid':int(p.name),'comm':comm,'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'executable':str(exe.readlink())};processes.append(row)
  if exe.stat().st_size==5594104 or 'kv9-batch-benchmark' in str(exe.readlink()):process_matches.append(pin(exe))
 except (FileNotFoundError,ProcessLookupError):continue
 except PermissionError:gaps.append(int(p.name))
capacity={}
for path in ['/','/tmp','/mnt/data/kv9-work','/dev/shm']:
 s=os.statvfs(path);capacity[path]={'device':os.stat(path).st_dev,'available_bytes':s.f_bavail*s.f_frsize}
need=79455850496;capacity['initial_screen_requirement_bytes']=need;capacity['root_surplus_bytes']=capacity['/']['available_bytes']-need;capacity['tmpfs_launch_requirement_bytes']=34359738368;capacity['capacity_sufficient_now']=capacity['root_surplus_bytes']>=0 and capacity['/dev/shm']['available_bytes']>=34359738368
constants={}
for node in ast.parse((PREP/'compressed_retention.py').read_text()).body:
 if isinstance(node,ast.Assign)and isinstance(node.targets[0],ast.Name)and node.targets[0].id in ['CODEC','CODEC_SHA']:constants[node.targets[0].id]=ast.literal_eval(node.value)
codec={'path':constants['CODEC'],'expected_sha256':constants['CODEC_SHA'],'actual_sha256':sha(constants['CODEC'])};assert codec['actual_sha256']==codec['expected_sha256']
client=json.loads((P/'client-original-build/build.json').read_text());cargo=[json.loads(x)for x in (P/'client-original-build/cargo.jsonl').read_text().splitlines()];artifact=next(x for x in cargo if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')=='kv9-batch-benchmark')
actual_toolchain=command(['/home/dongxu/.cargo/bin/rustc','-vV']);assert actual_toolchain==client['rustc']
save('assessment.json',{'complete':True,'observed_unix_ns':time.time_ns(),'selected_servers':verified,'client':{'expected_binary_sha256':client['binary_sha256'],'original_binary_bytes':5594104,'original_binary_path_missing':not Path(roles['client']['binary_path']).exists(),'original_source_path_missing':not Path(roles['client']['source_root']).exists(),'original_cargo_output_path':artifact['executable'],'original_cargo_output_missing':not Path(artifact['executable']).exists(),'matching_retained_binary_copies':[r for r in found+process_matches if r['sha256']==client['binary_sha256']],'source_recovered_exact':True,'original_build_metadata_recovered_exact':True,'features':artifact['features'],'rustc_matches_current':True,'rustc':actual_toolchain},'original_preparation_files_checked':len(pi['files']),'preparation_mismatches':prep_errors,'candidate_actual_chaos_binding_valid':True,'capacity':capacity,'codec':codec,'relevant_active_processes':processes,'process_metadata_permission_gaps':gaps,'evidence_inputs':inputs,'scope':'Read-only exact source/binary/manifest checks and bounded copy recovery. No workload, build, cleanup, source edit or historical-path overwrite. Current capacity is not a reservation.'})
save('copy-search.json',{'complete':True,'scope':'kv9-owned /tmp roots, at most three directory levels, excluding data/cohorts/objects/large generated trees; two explicit shared release directories; current process executable identities; named or exact prior-size files only','roots':scanned,'excluded_directory_names':sorted(skip),'candidate_files':found,'current_process_candidate_files':process_matches,'no_binary_found_with_expected_sha256':not any(r['sha256']==client['binary_sha256']for r in found+process_matches),'global_absence_claim':False})
print(json.dumps({'complete':True,'servers':{k:{'binary':v['binary'],'source_files':v['source_files']}for k,v in verified.items()},'capacity':capacity,'client_exact_binary_found':False,'active_processes':processes,'permission_gaps':gaps,'assessment':pin(P/'assessment.json')}))
