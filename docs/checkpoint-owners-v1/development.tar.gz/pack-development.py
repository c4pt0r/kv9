#!/usr/bin/env python3
"""Preserve actual checkpoint-owner development results and original failures."""
from pathlib import Path
import hashlib
import io
import json
import os
import tarfile

ROOT = Path('/home/dongxu/kv9')
BASE = Path('/mnt/data/kv9-work')
PUB = Path(__file__).resolve().parent
DEST = ROOT / 'docs/checkpoint-owners-v1'
DEST.mkdir(exist_ok=True)
ARCHIVE = DEST / 'development.tar.gz'
assert not ARCHIVE.exists()
entries, excluded = {}, []


def digest(b):
    return hashlib.sha256(b).hexdigest()


def add(path, member):
    assert path.is_file() and not path.is_symlink(), path
    assert member not in entries, member
    entries[member] = path


names = [
    'development-20260915-first', 'development-20260915-second',
    'development-20260915-third', 'development-20260915-fourth',
    'tests-20260915-first', 'tests-20260915-second',
    'library-acceptance-20260915-first',
    'proof-development-20260915-first', 'proof-development-20260915-second',
    'proof-inventory-20260915-first',
    'protocol-launch-20260915-first', 'protocol-launch-20260915-second',
    'protocol-20260915-first', 'protocol-20260915-second',
    'composition-20260915-first',
    'default-build-20260915-first', 'default-inputs-20260915-first',
    'testing-build-20260915-first', 'testing-inputs-20260915-first',
    'source-controls-launch-20260915-first', 'source-controls-launch-20260915-second',
    'source-controls-20260915-first', 'source-controls-20260915-second',
]
roots = [BASE / ('checkpoint-owner-' + name) for name in names]
roots.append(BASE / 'performance-input-recovery-20260915-first')
for directory in roots:
    assert directory.is_dir(), directory
    for parent, dirs, files in os.walk(directory):
        parent = Path(parent)
        omitted = {'target', '.git', '__pycache__', '.tlacache', 'states'}
        if parent == directory / 'rebuild-first':
            omitted |= {'source', 'tmp'}
        for name in sorted(set(dirs) & omitted):
            excluded.append(dict(path=str(parent / name),
                reason='Generated state/build tree or duplicate source checkout; original metadata and restored client source are retained.'))
        dirs[:] = sorted(set(dirs) - omitted)
        for name in sorted(files):
            path = parent / name
            assert not path.is_symlink(), path
            with path.open('rb') as f:
                magic = f.read(4)
            if magic == b'\x7fELF' or path.suffix in ('.class', '.fp', '.st') or name == 'fingerprints':
                excluded.append(dict(path=str(path), bytes=path.stat().st_size,
                    sha256=digest(path.read_bytes()),
                    reason='Executable or generated proof cache retained locally; no executable payload published.'))
                continue
            add(path, 'runs/' + directory.name + '/' + str(path.relative_to(directory)))

inputs = json.loads((BASE / 'checkpoint-owner-default-inputs-20260915-first/inputs.json').read_text())
for name, expected in inputs['source_pins'].items():
    path = ROOT / name
    assert digest(path.read_bytes()) == expected, name
    add(path, 'tested-source/' + name)
for flavor in ('default', 'testing'):
    folder = BASE / f'checkpoint-owner-{flavor}-inputs-20260915-first'
    manifest = json.loads((folder / 'inputs.json').read_text())
    assert manifest['source_pins'] == inputs['source_pins']
    assert digest((folder / 'kv9').read_bytes()) == manifest['binary_sha256']
    assert (folder / 'kv9').stat().st_size == manifest['binary_bytes']
for name in ('checkpoint_owner', 'anchor_binding', 'checkpoint_base',
             'checkpoint_publication', 'retention_ledger'):
    for kind in ('tla', 'tlaps'):
        for path in sorted((ROOT / 'proofs' / kind / name).iterdir()):
            if path.is_file():
                add(path, 'tested-proof/' + str(path.relative_to(ROOT)))
for name in ('check-checkpoint-owner.py', 'check-checkpoint-owner-source-controls.py',
             'checkpoint-owner-chaos.py', 'checkpoint-publication-chaos.py',
             'check-tla.py', 'check-tlaps.py', 'ProofAudit.java'):
    add(ROOT / 'scripts' / name, 'tested-runners/' + name)
add(PUB / 'current-validation.json', 'current-validation.json')
for name, filename in [('proof-tools-20260915-first', 'installation.json'),
                       ('chaos-tools-20260915-first', 'restoration.json')]:
    add(BASE / name / filename, 'tools/' + name + '/' + filename)
note = dict(status='preserved', roots=[str(p) for p in roots], excluded=excluded,
    source_pins_checked=len(inputs['source_pins']), no_workload_replayed=True,
    failures=[
        'First check missed a second freeze_parts tuple consumer.',
        'Second check moved the runtime backend Arc before adding the worker reference.',
        'Third check used an inaccessible sibling test helper.',
        'First runtime prefix test completed eight cuts but queried the leader too early after reopening.',
        'First proof draft left three of 43 obligations unproved.',
        'First protocol runner expected transfer; the same fault first violated coverage.',
        'First source-control runner expected generic wording instead of the exact custom assertion message.',
        'Performance client assessment initially observed a newer default compiler; explicit retained 1.94 rebuild succeeds but ELF differs, with original assessment/comparison failures preserved.'
    ],
    separate_packet='Actual default Chaos/helper preparation, original permission failure, full3 stopped-store logs/SST/history, independent audits, owned-gate design and secret-scanned packet are retained in runtime/. The testing pre-upload crash has not run.',
    performance_scope='Exact source/toolchain metadata recovery and one mismatching rebuild only. No replacement client qualification, benchmark replay or new QPS.')
(PUB / 'development-selection.json').write_text(json.dumps(note, indent=2) + '\n')
add(PUB / 'development-selection.json', 'selection.json')
add(Path(__file__), 'pack-development.py')
inventory = []
with tarfile.open(ARCHIVE, 'w:gz', compresslevel=6) as tar:
    for member, path in sorted(entries.items()):
        content = path.read_bytes()
        info = tarfile.TarInfo(member)
        info.size, info.mode, info.mtime = len(content), 0o644, 0
        tar.addfile(info, io.BytesIO(content))
        inventory.append(dict(member=member, original=str(path), bytes=len(content), sha256=digest(content)))
(DEST / 'development-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    assert tar.getnames() == [r['member'] for r in inventory]
    for record in inventory:
        data = tar.extractfile(record['member']).read()
        assert data == Path(record['original']).read_bytes(), record['member']
        assert len(data) == record['bytes'] and digest(data) == record['sha256']
summary = dict(status='PASS', archive_sha256=digest(ARCHIVE.read_bytes()),
    archive_bytes=ARCHIVE.stat().st_size, members=len(inventory),
    decoded_bytes=sum(r['bytes'] for r in inventory),
    inventory_sha256=digest((DEST / 'development-inventory.json').read_bytes()),
    all_members_equal_original=True, frozen_source_pins_checked=len(inputs['source_pins']),
    executable_bytes_excluded=True)
(DEST / 'development-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
