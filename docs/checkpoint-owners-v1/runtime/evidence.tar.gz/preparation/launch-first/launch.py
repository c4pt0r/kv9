"""Bounded single launch; source-bound automatic checkpoint-owner Chaos evidence."""
from pathlib import Path
import ctypes,hashlib,json,os,signal,subprocess,time
ROOT=Path(__file__).resolve().parent
OUT=Path('/mnt/data/kv9-work/checkpoint-owner-chaos-20260915-first')
REPO=Path('/home/dongxu/kv9')
def save(n,v):
 with (ROOT/n).open('x')as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def pin(p):
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def ticks(pid):
 s=Path('/proc',str(pid),'stat').read_text();return int(s[s.rfind(')')+2:].split()[19])
pre=json.loads((ROOT/'preflight.json').read_text())
assert not OUT.exists()
for row in [pre['binary'],pre['inputs'],*pre['helpers'].values(),*pre['source_files'].values()]:assert pin(Path(row['path']))==row
argv=['python3','-u','scripts/checkpoint-owner-chaos.py','--binary',pre['binary']['path'],'--binary-sha256',pre['binary']['sha256'],'--inputs',pre['inputs']['path'],'--output',str(OUT),'--retained-ca-base']
changes={'KV9_KIND':'/mnt/data/kv9-work/chaos-tools-20260915-first/kind','KV9_CHAOS_KUBECONFIG':'/mnt/data/kv9-work/chaos-tools-20260915-first/kubeconfig','PYTHONDONTWRITEBYTECODE':'1','PYTHONOPTIMIZE':'0'}
parent=os.getpid()
def death():
 assert ctypes.CDLL(None).prctl(1,signal.SIGKILL,0,0,0)==0
 if os.getppid()!=parent:os.kill(os.getpid(),signal.SIGKILL)
start=time.monotonic();save('invocation.json',{'argv':argv,'cwd':str(REPO),'environment_overrides':changes,'cpu_affinity':sorted(os.sched_getaffinity(0)),'started_unix_ns':time.time_ns(),'outer_timeout_seconds':1260,'helper_timeout_seconds':1200,'helper_pins':pre['helpers'],'no_retries':True})
child=None;error=None;signals=[]
try:
 with (ROOT/'stdout').open('xb')as out,(ROOT/'stderr').open('xb')as err:
  child=subprocess.Popen(argv,cwd=REPO,env={**os.environ,**changes},stdout=out,stderr=err,start_new_session=True,preexec_fn=death)
  birth={'pid':child.pid,'start_ticks':ticks(child.pid),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'pgid':child.pid};save('child-start.json',birth);print(json.dumps({'live_pid':child.pid,'output':str(OUT),'source_files':len(pre['source_files'])}),flush=True)
  while child.poll()is None:
   assert time.monotonic()-start<1260,'outer deadline'
   assert (ROOT/'stdout').stat().st_size+(ROOT/'stderr').stat().st_size<=16*1024**2,'outer output cap'
   time.sleep(0.5)
except BaseException as e:error=repr(e)
finally:
 if child is not None and child.poll()is None:
  os.killpg(child.pid,signal.SIGTERM);signals.append('SIGTERM')
  try:child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);signals.append('SIGKILL');child.wait(timeout=10)
 code=child.returncode if child else None
 helpers_after={n:pin(Path(p['path']))for n,p in pre['helpers'].items()}
 result={'complete':error is None and code==0 and(OUT/'result.json').exists(),'error':error,'exit_code':code,'signals':signals,'elapsed_seconds':time.monotonic()-start,'ended_unix_ns':time.time_ns(),'helper_pins_after':helpers_after,'helpers_unchanged':helpers_after==pre['helpers'],'binary_after':pin(Path(pre['binary']['path'])),'process_absent':child is not None and not Path('/proc',str(child.pid)).exists(),'output':str(OUT)}
 if (OUT/'result.json').exists():result['result']=pin(OUT/'result.json')
 if (OUT/'failure.json').exists():result['failure']=pin(OUT/'failure.json')
 save('child-terminal.json',result);print(json.dumps(result,sort_keys=True),flush=True)
 if not result['complete']:raise SystemExit(1)
