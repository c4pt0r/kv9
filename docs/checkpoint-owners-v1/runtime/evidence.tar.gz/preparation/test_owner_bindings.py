"""Metadata-only controls for the new observer's identity and refusal predicates."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import unittest

REPO = Path('/home/dongxu/kv9')
sys.path.insert(0, str(REPO / 'scripts'))
spec = importlib.util.spec_from_file_location('owner_cell', REPO / 'scripts/checkpoint-owner-chaos.py')
owner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owner)

class OwnerBindings(unittest.TestCase):
    def setUp(self):
        self.root = b'KV9ROOT\0' + b'\0\1' + bytes(range(1, 17)) + b'fixture-root-tail'
        digest = hashlib.sha256(b'object').hexdigest()
        self.manifest = {'scope': {'cluster': bytes(range(1, 17)).hex(), 'region': 1,
                                  'conf_ver': 2, 'version': 3},
                         'term': 7, 'index': 101, 'files': [{
                             'key': 'clusters/' + bytes(range(1, 17)).hex() + '/regions/1/sst/' + digest,
                             'sha256': digest, 'cf': 0, 'smallest': [1], 'largest': [2],
                             'size': 6, 'count': 2}]}
        self.raw = owner.MAGIC + json.dumps(self.manifest, separators=(',', ':')).encode()
        self.binding = owner.derive(self.root, self.raw, 5)

    def test_exact_canonical_observation_layout(self):
        raw = owner.owner_bytes(self.binding, 'pending', 4)
        self.assertEqual(raw[:8], b'KV9OWN01')
        self.assertEqual(raw[8:40], hashlib.sha256(self.root).digest())
        self.assertEqual(raw[56], 2)
        self.assertEqual(raw[57:81], struct.pack('>QQQ', 1, 2, 3))
        self.assertEqual(raw[113:145], hashlib.sha256(self.raw).digest())
        self.assertEqual(raw[145:156], b'\0\0' + struct.pack('>QB', 1, 4))
        self.assertEqual(raw[156:160], struct.pack('>I', 1))
        self.assertEqual(raw[-32:], hashlib.sha256(raw[:-32]).digest())
        self.assertNotEqual(self.binding['owner_ids']['pending'], self.binding['owner_ids']['version'])

    def test_predecessor_changes_both_ids(self):
        later = owner.derive(self.root, self.raw, 6)
        for name in ('pending', 'version'):
            self.assertNotEqual(later['owner_ids'][name], self.binding['owner_ids'][name])
        with self.assertRaises(RuntimeError):
            owner.derive(self.root, self.raw, -1)

    def test_root_scope_and_noncanonical_bytes_refused(self):
        for raw in (self.raw.replace(b'"region":1', b'"region":2'),
                    owner.MAGIC + json.dumps(self.manifest, sort_keys=True).encode()):
            with self.assertRaises(RuntimeError):
                owner.derive(self.root, raw, 5)
        with self.assertRaises(RuntimeError):
            owner.derive(self.root[:10] + bytes(16) + self.root[26:], self.raw, 5)

    def cell(self, responses):
        cell = owner.OwnerCell.__new__(owner.OwnerCell)
        cell.binding = self.binding
        cell.read_owner = lambda name: responses[name]
        return cell

    def response(self, name, phase):
        return {'found': 'true', 'owner_hex': owner.owner_bytes(self.binding, name, phase).hex()}

    def test_complete_settlement_only(self):
        responses = {'pending': self.response('pending', 4), 'version': self.response('version', 2)}
        self.assertEqual(self.cell(responses).settled(), {'pending': 4, 'version': 2})
        for phase in (1, 2, 3):
            responses['pending'] = self.response('pending', phase)
            self.assertIsNone(self.cell(responses).settled())
        responses['pending'] = {'found': 'false'}
        self.assertIsNone(self.cell(responses).settled())

    def test_wrong_static_binding_and_wrong_kind_refused(self):
        responses = {'pending': self.response('pending', 4), 'version': self.response('version', 2)}
        for byte in (40, 56, 80, 112, 144, 153, 180):
            bad = bytearray(owner.owner_bytes(self.binding, 'pending', 4))
            bad[byte] ^= 1
            bad[-32:] = hashlib.sha256(bad[:-32]).digest()
            responses['pending'] = {'found': 'true', 'owner_hex': bad.hex()}
            with self.assertRaises(RuntimeError):
                self.cell(responses).settled()

    def test_missing_version_never_complete(self):
        responses = {'pending': self.response('pending', 4), 'version': {'found': 'false'}}
        self.assertIsNone(self.cell(responses).settled())
        responses['version'] = self.response('version', 1)
        self.assertIsNone(self.cell(responses).settled())

    def test_selected_victim_is_current_leader(self):
        cell = owner.OwnerCell.__new__(owner.OwnerCell)
        cell.leader_id = 2
        self.assertEqual(cell.choose_victim(), 2)
        self.assertEqual(cell.killed_leader, 2)

if __name__ == '__main__':
    unittest.main()
