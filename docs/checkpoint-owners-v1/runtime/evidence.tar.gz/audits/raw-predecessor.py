"""Independently replay the serial public history and inspect actual fault evidence."""
import hashlib,json,re,sys
from pathlib import Path

root=Path(sys.argv[1])
load=lambda name:json.loads((root/name).read_text())
result=load('result.json');a=load('cell-acceptance.json')
assert result['complete'] and result['owned_namespace_removed']
assert a['complete'] and result['namespace_uid']==a['namespace_uid']
assert result['fault_uid']==a['fault_uid']
assert result['minimum_available_bytes']>=result['floor_bytes']==8*1024**3
assert result['maximum_observed_decrease_bytes']<=result['maximum_added_budget_bytes']==1024**3
before=load('victim-before.json');after=load('victim-after.json')
old=before['status']['containerStatuses'][0];new=after['status']['containerStatuses'][0]
assert before['metadata']['uid']==after['metadata']['uid']
assert old['containerID']==a['old_container_id']==new['lastState']['terminated']['containerID']
assert new['containerID']==a['new_container_id']!=old['containerID']
assert new['restartCount']>old['restartCount']
assert new['lastState']['terminated']['exitCode']==137
assert (root/'lifecycle-before.bin').read_bytes()
pvc1=load('pvc-before.json');pvc2=load('pvc-after.json')
assert pvc1['metadata']['uid']==pvc2['metadata']['uid']
assert pvc1['spec']['volumeName']==pvc2['spec']['volumeName']
fault=load('injected-fault.json')
assert fault['metadata']['uid']==a['fault_uid']
assert fault['spec']['action']=='container-kill'
assert fault['spec']['selector']['pods']=={a['namespace']:[before['metadata']['name']]}
assert any(c['type']=='AllInjected' and c['status']=='True' for c in fault['status']['conditions'])
victim=a['namespace']+'/'+before['metadata']['name']+'/kv9'
assert any(c['id']==victim and c['phase']=='Injected' and c['injectedCount']>0 for c in fault['status']['experiment']['containerRecords'])
actual_matches=[[int(x) for x in row] for row in re.findall(r'node (\d+) recovered checkpoint generation=(\d+) cut=(\d+) publication=(\d+)',(root/'recovered-process.log').read_text())]
assert actual_matches==a['recovery_log_matches']
assert any(n==a['victim'] and cut==a['selected_checkpoint']['index'] and 0<cut<pub and gen>0 for n,gen,cut,pub in a['recovery_log_matches'])
for i,f in enumerate(a['selected_checkpoint']['files']):
 b=(root/f'selected-sst-{i:03d}.bin').read_bytes()
 assert len(b)==f['size'] and hashlib.sha256(b).hexdigest()==f['sha256']
assert a['tested_binary']['sha256']=='2b4d70aac139672a5627e5a0f789245ea039b647f2510aec6f6b938551b1d36e'
assert load('images.json')['kv9_id']==a['image_id']
reclaim=load('reclamation.json');assert reclaim['complete'] and 0<reclaim['filler_writes']<=300
assert reclaim['through']<=a['selected_checkpoint']['index']
state={};keyspace=None;last_end=0;last_write=0;counts={};overwrites=0;post_reads=0
history=load('history.json')
for row in history:
 assert row['exit_code']==0, 'this accepted cell requires zero unknown/refused operations'
 assert row['attempt']==0
 assert last_end<=row['started_ns']<row['ended_ns'];last_end=row['ended_ns']
 args=row['args'];assert len(args)%2==0
 fields=dict(zip(args[::2],args[1::2]));assert len(fields)*2==len(args)
 verb=row['verb'];counts[verb]=counts.get(verb,0)+1
 if verb=='create-keyspace':
  assert keyspace is None
  keyspace=dict(line.split('=',1) for line in row['output'].strip().splitlines())['keyspace_id']
  continue
 assert fields['--keyspace']==keyspace
 key=bytes.fromhex(fields['--key-hex'])
 if verb in ('raw-put','raw-delete'):
  receipt=dict(line.split('=',1) for line in row['output'].strip().splitlines())
  at=int(receipt['applied_index']);assert at>last_write;last_write=at
  if verb=='raw-put':
   value=bytes.fromhex(fields['--value-hex'])
   if key==b'overwrite' and key in state:
    assert state[key]==b'old-value' and value==b'new-value';overwrites+=1
   state[key]=value
  else:state.pop(key,None)
 elif verb=='raw-get':
  expected='found=false' if key not in state else 'value_hex='+state[key].hex()
  assert row['output'].strip()==expected, 'read differs from acknowledged serial state'
  if row['phase']=='recovered-read-write':post_reads+=1
 else:raise AssertionError('unexpected client operation '+verb)
assert overwrites==1 and post_reads>=4
assert state[b'keep']==b'remote-value' and state[b'overwrite']==b'new-value'
assert b'deleted' not in state and b'wal-rotation-filler' not in state
assert state[b'post-chaos']==b'writable-after-remote-checkpoint'
assert counts['raw-put']==reclaim['filler_writes']+5
assert last_write==int(a['fresh_write_receipt']['applied_index'])
statuses=load('recovered-status.json');assert set(statuses)=={'1','2','3'}
assert all(int(s['driver_applied_index'])>=last_write and s['bootstrap_state']=='Serving' and not s['fatal'] for s in statuses.values())
p1=load('protected-before.json');p2=load('protected-after.json')
assert p1['namespaces']==p2['namespaces'] and len(p1['namespaces'])==8
assert p1['fault']['metadata']['uid']==p2['fault']['metadata']['uid']
assert p1['fault']['spec']==p2['fault']['spec']
print(json.dumps({'status':'PASS','history_operations':len(history),'counts':counts,'same_key_overwrites':overwrites,'post_recovery_reads':post_reads,'selected_sst_files':len(a['selected_checkpoint']['files']),'filler_writes':reclaim['filler_writes'],'actual_fault':fault['spec']['action'],'scope':'Complete serial successful-client history, actual injection/lifecycle evidence, selected SST hashes and all-voter fresh-write progress. Single-host process failure; no physical power loss, general concurrent-history or full21 claim.'},indent=2))
