"""Independent finite observer, committed Raft ownership and exact byte audit."""
from pathlib import Path
import hashlib,json,struct,sys,re,tarfile
R=Path(sys.argv[1]);load=lambda n:json.loads((R/n).read_text())
A=load('owner-acceptance.json');B=load('owner-selected-binding.json');C=load('cell-acceptance.json');RESULT=load('result.json')
assert RESULT['complete']and A['complete']and C['complete']
def digest(b):return hashlib.sha256(b).digest()
def checkpin(row):
 p=Path(row['path']);b=p.read_bytes();assert len(b)==row['bytes']and digest(b).hex()==row['sha256'];return b
for row in (A['binding'],A['history'],A['selected_sst_inventory']):checkpin(row)
root=(R/'root.bin').read_bytes();root_hash=digest(root);manifest=(R/'owner-selected-manifest.bin').read_bytes()
assert manifest.startswith(b'KV9CHECKPOINT\x01')
# Use the literal prefix length, not an inferred JSON offset.
M=json.loads(manifest[len(b'KV9CHECKPOINT\x01'):]);assert M==B['manifest']==C['selected_checkpoint']
assert M['scope']['cluster']==root[10:26].hex()and M['scope']['region']==1
assert root_hash.hex()==B['root_digest']and digest(manifest).hex()==B['manifest_sha256']
pred=B['predecessor_generation'];operation=digest(b'kv9-manifest-v1'+struct.pack('>Q',pred)+manifest);assert operation.hex()==B['operation']
ids={n:digest(label+root_hash+operation)[:16]for n,label in(('pending',b'kv9-checkpoint-pending-v1'),('version',b'kv9-checkpoint-version-v1'))};assert {n:v.hex()for n,v in ids.items()}==B['owner_ids']
resources=sorted(b'\1'+digest(f['key'].encode())[:16]+bytes.fromhex(f['sha256'])for f in M['files']);assert 0<len(resources)<=64 and len(set(resources))==len(resources)and [r.hex()for r in resources]==B['resources']
def owner(n,phase):
 s=M['scope'];body=b'KV9OWN01'+root_hash+ids[n]+bytes([{'pending':2,'version':3}[n]])+struct.pack('>QQQ',s['region'],s['conf_ver'],s['version'])+operation+digest(manifest)+b'\0\0'+struct.pack('>QB',1,phase)+struct.pack('>I',len(resources))+b''.join(resources)
 return body+digest(body)
H=load('owner-history.json');observed=[];previous_end=0
for row in H:
 assert row['attempt']==0 and row['exit_code']==0 and previous_end<=row['started_ns']<row['ended_ns'];previous_end=row['ended_ns']
 d=R/'commands'/f"{row['command_number']:05d}";inv=json.loads((d/'invocation.json').read_text());argv=inv['argv'];raw=(d/'stdout').read_bytes();assert raw==row['output'].encode()
 assert argv[argv.index('client')+1]=='retention-owner'and argv[argv.index('--root-digest')+1]==root_hash.hex()and argv[argv.index('--owner-id')+1]==ids[row['name']].hex()
 fields=dict(x.split('=',1)for x in raw.decode().splitlines());assert fields['found']=='true';v=bytes.fromhex(fields['owner_hex']);phase=v[155];assert v==owner(row['name'],phase)
 observed.append({'name':row['name'],'phase':phase,'stage':row['phase'],'command':row['command_number']})
for stage in ('automatic-owner-selected-checkpoint','automatic-owner-after-leader-recovery'):
 last={x['name']:x['phase']for x in observed if x['stage']==stage};assert last=={'pending':4,'version':2}
predecessors=set()
for p in B['worker_logs']:
 raw=checkpin(p)
 for n,g,cut in re.findall(rb'node (\d+) checkpoint pending generation=(\d+) through=(\d+) resuming',raw):
  if int(cut)==M['index']:predecessors.add(int(g))
assert predecessors=={pred}
recover=[[int(x)for x in row]for row in re.findall(rb'node (\d+) recovered checkpoint generation=(\d+) cut=(\d+) publication=(\d+)',(R/'recovered-process.log').read_bytes())]
exact=[x for x in recover if x[0]==C['victim']and x[1]==pred+1 and x[2]==M['index']and x[3]>x[2]];assert exact==A['recovery_publication'];publication=exact[0][3]
# Independent protobuf field parser for retained Raft Entry and HardState only.
def varint(b,i):
 n=0
 for shift in range(0,70,7):
  assert i<len(b);v=b[i];i+=1;n|=(v&127)<<shift
  if v<128:return n,i
 raise AssertionError('overlong varint')
def protobuf(b):
 i=0;d={}
 while i<len(b):
  tag,i=varint(b,i);field,wire=tag>>3,tag&7;assert field>0 and field not in d
  if wire==0:value,i=varint(b,i)
  elif wire==2:
   size,i=varint(b,i);value=b[i:i+size];assert len(value)==size;i+=size
  else:raise AssertionError('unexpected wire type')
  d[field]=value
 return d
class Buf:
 def __init__(self,b):self.b=b
 def take(self,n):x,self.b=self.b[:n],self.b[n:];assert len(x)==n;return x
 def num(self,n):return int.from_bytes(self.take(n),'big')
 def blob(self):return self.take(self.num(4))

def raft_audit(raw):
 offset=0;counts={};entries={};commit=0
 while offset<len(raw):
  assert len(raw)-offset>=8;size,checksum=struct.unpack('>II',raw[offset:offset+8]);assert 0<size<=64*1024**2;body=raw[offset+8:offset+8+size];assert len(body)==size
  h=0x811c9dc5
  for byte in body:h=((h^byte)*0x01000193)&0xffffffff
  assert h==checksum;kind=body[0];assert kind in(1,2,3,4,5);counts[kind]=counts.get(kind,0)+1
  if kind==2:commit=protobuf(body[1:]).get(3,0)
  elif kind==3:
   e=protobuf(body[1:]);idx=e[3]
   for old in [x for x in entries if x>=idx]:del entries[old]
   entries[idx]=e
  offset+=8+size
 assert commit>=A['all_voter_barrier_index'] and publication in entries
 traces={n:[]for n in ids};published=[]
 keys={b'\0kv9\0retention_v1\0\3'+v:n for n,v in ids.items()}
 for idx,e in sorted(entries.items()):
  if idx>commit or e.get(1,0)!=0:continue
  command=e.get(4,b'')
  if not command:continue
  b=Buf(command);assert b.num(1)==1;tag=b.num(1)
  if tag==2:
   count=b.num(4)
   for _ in range(count):
    op,cf=b.num(1),b.num(1);key=b.blob();assert op in(1,2);value=b.blob()if op==1 else None
    if key in keys:
     assert op==1 and cf==0;n=keys[key];phase=value[155];assert value==owner(n,phase);traces[n].append({'index':idx,'term':e[2],'phase':phase})
   assert not b.b
  elif tag==7:
   region=b.num(8);change=b.blob();generation=b.num(8);payload=b.blob();term,index=b.num(8),b.num(8);assert not b.b
   if idx==publication:
    assert region==1 and change==operation and generation==pred and payload==manifest and(term,index)==(M['term'],M['index']);published.append(idx)
 assert published==[publication]
 assert [x['phase']for x in traces['pending']]==[1,2,3,4]and [x['phase']for x in traces['version']]==[1,2]
 assert traces['pending'][1]['index']<publication<traces['version'][0]['index']<traces['version'][1]['index']<traces['pending'][2]['index']<traces['pending'][3]['index']
 return {'bytes':len(raw),'sha256':digest(raw).hex(),'frame_counts':counts,'final_commit':commit,'selected_publication_index':publication,'owner_transitions':traces}
archives=[];raft=[]
for n in(1,2,3):
 inv=load(f'n{n}-stopped-data-inventory.json');assert inv['complete_readback'];p=Path(inv['archive']['path']);assert p.stat().st_size==inv['archive']['bytes']
 with p.open('rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==inv['archive']['sha256']
 expected={x['name']:x for x in inv['files']};seen={};raft_found=False
 with tarfile.open(p,'r:')as tar:
  for ent in tar:
   assert ent.isfile()or ent.isdir()
   if not ent.isfile():continue
   assert ent.name in expected and ent.name not in seen;data=tar.extractfile(ent).read();row={'name':ent.name,'bytes':len(data),'sha256':digest(data).hex()};assert row==expected[ent.name];seen[ent.name]=row
   if ent.name=='./raft/raft.log':
    raft.append({'node':n,**raft_audit(data)});raft_found=True
   if ent.name=='./kv9-root-descriptor':assert data==root
 assert seen==expected and raft_found;archives.append({'node':n,'archive':inv['archive'],'members':len(seen),'decoded_bytes':sum(x['bytes']for x in seen.values())})
assert all(row['owner_transitions']==raft[0]['owner_transitions']for row in raft)
for row in load('selected-sst-inventory.json')['files']:
 data=checkpin(row['retained']);assert len(data)==row['reference']['size']and digest(data).hex()==row['reference']['sha256']
# Actual owned command lifetimes, exact lifecycle command bytes and high-water budgets.
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();births=set();exits={};life=[]
for d in sorted((R/'commands').iterdir()):
 inv=json.loads((d/'invocation.json').read_text());s=json.loads((d/'child-start.json').read_text());t=json.loads((d/'terminal.json').read_text());assert t['complete']and t['child_reaped']and all(t[k]==s[k]for k in('pid','start_ticks','boot_id'))
 key=(s['boot_id'],s['pid'],s['start_ticks']);assert key not in births;births.add(key);exits[t['exit_code']]=exits.get(t['exit_code'],0)+1;p=Path('/proc',str(s['pid']),'stat')
 if s['boot_id']==boot and p.exists():
  raw=p.read_text();assert int(raw[raw.rfind(')')+2:].split()[19])!=s['start_ticks']
 if inv['argv'][-2:]==['cat','/data/kv9-store-lifecycle']:
  assert t['exit_code']==0 and(d/'stdout').read_bytes()==(R/'lifecycle-before.bin').read_bytes();life.append(int(d.name))
assert len(life)==2
previous={};samples=0;peak=0
for line in(R/'resources.jsonl').read_text().splitlines():
 x=json.loads(line)['filesystem_budget'];assert x['schema_version']==1;total=0;seen=set()
 for row in x['filesystems']:
  dev=row['device'];assert dev not in seen;seen.add(dev);baseline=row['baseline_available_bytes'];current=row['current_available_bytes'];minimum=row['minimum_available_bytes'];assert baseline>=9*1024**3+8*1024**2 and current>=8*1024**3
  if dev in previous:assert previous[dev]['baseline_available_bytes']==baseline and minimum==min(previous[dev]['minimum_available_bytes'],current)
  assert row['maximum_observed_decrease_bytes']==max(0,baseline-minimum);previous[dev]=row;total+=row['maximum_observed_decrease_bytes']
 assert total==x['maximum_observed_total_decrease_bytes']and peak<=total<=1024**3;peak=total;samples+=1
assert peak==RESULT['maximum_observed_decrease_bytes']and len(previous)==2
assert not A['live_acquired_phase_observed']and not A['pre_upload_crash_exercised']and A['retention_mutations_by_fixture']==0
print(json.dumps({'complete':True,'actual_owner_cli_observations':observed,'root_digest':root_hash.hex(),'manifest_sha256':digest(manifest).hex(),'predecessor':pred,'selected_publication':exact,'raft':raft,'archives':archives,'lifecycle_commands':life,'gone_command_lifetimes':len(births),'command_exit_counts':exits,'filesystem_samples':samples,'maximum_conservative_decrease_bytes':peak,'scope':'Actual canonical automatic-owner CLI states and full committed Raft acquisition/publication/transfer phases on all three retained logs; exact original SST/archive bytes; process identity and additive resource accounting. No live acquired CLI phase or pre-upload kill claimed.'},indent=2))
