#!/usr/bin/env python3
"""Retained-prefix/fault/diagnosis audit; the second rotation attempt remains FAILED."""
import argparse,json,sys,time,traceback
from pathlib import Path
OWN=Path(__file__).resolve().parent
AUTH=json.loads((OWN/'authority.json').read_text())
sys.path.insert(0,AUTH['original_preparation'])
import audit as original_audit
from checks import digest,load,read,require,fault_check,query_script,query_check,sample_check,process_probe
from runner import verify_preparation

def authority():
    for name,pin in AUTH['inputs'].items():
        raw=read(name,16*1024*1024)
        require(len(raw)==pin['bytes'] and digest(raw)==pin['sha256'],'failed attempt/diagnosis authority changed')
    result=load(Path(AUTH['original_run'])/'result.json')
    require(result['complete'] is False and result['accepted'] is False and result['command_count']==201 and
            result['failure']=="ValueError('all three voters did not freshly drain in 20 seconds')",'wrong original failure')
    terminal=load(Path(AUTH['original_root'])/'runtime-terminal.json')
    require(terminal['complete'] is False and terminal['exit_code']==1 and terminal['session_id']==96298 and
            terminal['terminal_receipt']=='ff7a2e/1' and terminal['result_sha256']==digest(read(Path(AUTH['original_run'])/'result.json')),'actual failed terminal differs')
    dt=load(Path(AUTH['original_root'])/'diagnostic-terminal.json')
    require(dt['complete'] is True and dt['exit_code']==0 and dt['session_id']==41659 and dt['terminal_receipt']=='598e27/0' and
            dt['original_supplement_accepted'] is False and dt['result_sha256']==digest(read(Path(AUTH['diagnosis'])/'result.json')),'actual diagnosis terminal differs')
    require(not Path('/proc/'+str(result['controller']['pid'])).exists(),'original controller remains live')
    return result,terminal

class FailedEvidence(original_audit.Evidence):
    def __init__(self,root,p,count):
        self.root=Path(root);self.p=p;self.inventory={};self.commands={};self.result=self.json('result.json')
        require(0<count<=p['max_commands'],'command count bound')
        for n in range(count):
            stem=f'command-{n:04d}';start=self.json(stem+'.start.json');row=self.json(stem+'.result.json');child=self.json(stem+'.child.json')
            require(start['argv']==row['argv'] and start['started_ns']==row['started_ns'] and row['child']==child and
                    row['complete'] is True and row['reaped'] is True and row['failure'] is None and
                    row['exit_code']==0 and row['ended_ns']>=row['started_ns'],'altered/failed/unreaped command')
            for kind in ('stdout','stderr'):
                raw=self.bytes(row[kind]['path'],p['max_command_output_bytes'])
                require(len(raw)==row[kind]['bytes'] and digest(raw)==row[kind]['sha256'],'raw command output changed')
            if 'stdin' in row:require(digest(self.bytes(row['stdin']))==row['stdin_sha256'],'original command input changed')
            self.commands[n]=row

def sample(e,ref,ns):
    before=json.loads(e.output(ref['before'],e.k('get','pods','-n',ns,'-o','json')))
    after=json.loads(e.output(ref['after'],e.k('get','pods','-n',ns,'-o','json')))
    raw={n:e.output(i,e.exe(ns,'kv9-n'+n,'/bin/bash','-c',process_probe.PROBE,'rotation-process','/data/status','/usr/local/bin/kv9')).decode() for n,i in ref['probes'].items()}
    return sample_check(before,raw,after,e.p)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    a.output.mkdir(exist_ok=False);result=dict(complete=False,partial_prefix_valid=False,accepted=False)
    try:
        original,terminal=authority();p=verify_preparation();e=FailedEvidence(AUTH['original_run'],p,201);ns=AUTH['namespace']
        owned=e.json('owned.json');bootstrap=e.json('bootstrap.json')
        require((owned['namespace'],owned['namespace_uid'])==(ns,AUTH['namespace_uid']),'owned namespace mismatch')
        initial_namespaces=json.loads(e.output(owned['namespaces_before'],e.k('get','namespaces','-o','json')))
        require({x['metadata']['name']:x['metadata']['uid'] for x in initial_namespaces['items']}==p['preserve_namespaces'],'original historical namespace map changed')
        namespace=json.loads(e.output(owned['namespace_command'],e.k('get','namespace',ns,'-o','json')))
        require(namespace['metadata']['uid']==AUTH['namespace_uid'] and namespace['metadata'].get('annotations',{}).get('chaos-mesh.org/inject')=='enabled','actual namespace identity/opt-in missing')
        config,population,refs=original_audit.read_burst(e,'pre',owned,bootstrap)
        first,_,_=original_audit.read_drain(e,'initial-drain',ns)
        pre,pre_samples,_=original_audit.read_drain(e,'pre-drain',ns)
        top,top_refs=original_audit.read_topology(e,'pre-topology',ns)
        require(refs['final_pod']<min(x['topology'] for x in top_refs.values()) and
                max(x['topology_after'] for x in top_refs.values())<113 and set(top)==set('123'),'pre-fault topology ordering')
        f=e.json('fault.json');leader=pre['leader'];require(leader=='2','unexpected observed victim')
        before=json.loads(e.output(f['before'],e.k('get','pod','kv9-n'+leader,'-n',ns,'-o','json')))
        after=json.loads(e.output(f['after'],e.k('get','pod','kv9-n'+leader,'-n',ns,'-o','json')))
        actual_fault=json.loads(e.output(f['fault'],e.k('get','podchaos','kill-rotation-leader','-n',ns,'-o','json')))
        checked=fault_check(actual_fault,before,after,leader,ns,e.output(f['lifecycle_before']),e.output(f['lifecycle_after']))
        observed=process_probe.parse(e.output(f['leader_probe'],e.exe(ns,'kv9-n'+leader,'bash','-c',process_probe.PROBE,'fault-leader','/data/status','/usr/local/bin/kv9')).decode(),p['server']['sha256'],'/usr/local/bin/kv9')
        require(all(observed[k]['leader_id']==leader and observed[k]['role']=='leader' for k in ('state','state_after')) and
                observed['process_start_ticks']==pre_samples[leader]['process_start_ticks'],'victim leader/process binding')
        require(checked==f['checked']==AUTH['fault_checked'],'exact fault UID/container/lifecycle mismatch')
        tree=f['original_tree'];require(tree in e.json('pre-fault-trees.json')['rows'] and tree['container']==checked['old_container'].removeprefix('containerd://'),'original leader tree changed')
        text=e.output(tree['tree']).decode();boot=text.split('@@BOOT@@\n')[1].split('@@')[0].strip();sections=text.split('@@PID@@\n')[1:]
        require(sections and len(sections)==len(f['original_process_exit_commands']),'old leader exit count')
        for section,i in zip(sections,f['original_process_exit_commands']):
            pid=int(section.splitlines()[0].split(' ',1)[0]);script='set -e; cat /proc/sys/kernel/random/boot_id; if test -e /proc/"$1"/stat; then cat /proc/"$1"/stat; else printf "absent\\n"; fi'
            require(e.output(i,['docker','exec',tree['node'],'bash','-c',script,'owned-exit',str(pid)]).decode().splitlines()==[boot,'absent'],'old leader death not observed')
        failed_drain=e.json('recovered-drain-incomplete.json')
        require(failed_drain['accepted'] is False and len(failed_drain['samples'])==16,'failed recovered drain observation differs')
        d=FailedEvidence(AUTH['diagnosis'],p,12);diagnosis=d.result
        require(diagnosis['complete'] is True and diagnosis['diagnostic_only'] is True and diagnosis['supplement_accepted'] is False and
                (diagnosis['namespace'],diagnosis['namespace_uid'])==(ns,AUTH['namespace_uid']) and
                diagnosis['history_sha256']==digest(e.bytes('native-pre/history.jsonl',p['max_command_output_bytes'])),'diagnostic authority/history mismatch')
        before_d=sample(d,diagnosis['before'],ns);after_d=sample(d,diagnosis['after'],ns)
        for n in '123':
            require(before_d[n]['process_start_ticks']==after_d[n]['process_start_ticks'] and before_d[n]['pod_uid']==after_d[n]['pod_uid'],'diagnosis process changed')
            for field in ('state','state_after'):
                state=after_d[n][field]
                require(state['fatal']=='' and state['bootstrap_state']=='Serving' and state['driver_applied_index']==state['raft_committed']=='52' and
                        state['driver_applied_term']=='2' and state['applied_index']=='51' and state['applied_term']=='1','original no-op gap changed')
        require(before_d['2']['process_start_ticks']!=observed['process_start_ticks'],'restarted leader process not new')
        query=d.json('acknowledged-values.json');script=query_script(config['client']['keyspace_id'],population['expected_values'])
        raw=d.output(query['command'],d.exe(ns,'kv9-n'+query['leader'],'bash','-c',script))
        verified=query_check(raw.decode(),population['expected_values'])
        require(verified==query['result']==diagnosis['full_public_value_readback']==dict(full_dataset_equal=True,keys=65,value_bytes=524288),'public full acknowledged dataset differs')
        result=dict(complete=True,partial_prefix_valid=True,accepted=False,original_runtime_exit_code=1,original_runtime_complete=False,
            runtime_terminal_path=str(Path(AUTH['original_root'])/'runtime-terminal.json'),runtime_result_sha256=digest(read(e.root/'result.json')),
            namespace=ns,namespace_uid=AUTH['namespace_uid'],fault_uid=AUTH['fault_uid'],fault=checked,
            pre_burst={k:v for k,v in population.items() if k!='expected_values'},independent_native_full_history_checked=True,
            selected_topology=top,fresh_drains={'initial':first,'pre':pre},recovered_drain_original_accepted=False,
            original_failed_samples=16,diagnostic_public_readback=verified,original_leader_processes_exited=len(sections),
            scope='Valid retained pre-burst prefix, actual injected leader-container kill and separate public read-only recovery diagnosis. Original recovered-drain gate failed; no second burst, second rotation or supplement acceptance.')
        (a.output/'input-inventory.json').write_text(json.dumps({'runtime':e.inventory,'diagnosis':d.inventory,'authority':AUTH['inputs']},indent=2,sort_keys=True)+'\n')
    except BaseException as exc:
        result.update(failure=repr(exc),traceback=traceback.format_exc());raise
    finally:
        result['ended_ns']=time.time_ns();(a.output/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:result[k] for k in ['complete','partial_prefix_valid','accepted','original_runtime_exit_code']}))

if __name__=='__main__':main()
