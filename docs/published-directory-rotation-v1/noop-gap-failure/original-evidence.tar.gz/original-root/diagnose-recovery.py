"""Read-only recovery diagnosis after the retained failed supplement terminal."""
from pathlib import Path
import hashlib
import json
import sys

PREP = Path('/tmp/kv9-published-directory-rotation-supplement-corrected-preparation-20260915-first')
RUN = Path('/tmp/kv9-published-directory-rotation-supplement-corrected-20260915-first')
OUT = Path('/tmp/kv9-published-directory-rotation-supplement-corrected-recovery-diagnosis-20260915-first')
sys.dont_write_bytecode = True
sys.path.insert(0, str(PREP))
from runner import Commands, fresh_sample, query, save, verify_preparation
from checks import history_population, load, require


def main():
    protocol = verify_preparation()
    original = load(RUN / 'result.json')
    require(original['complete'] is False and original['accepted'] is False,
            'diagnosis requires the retained failed original run')
    owned = load(RUN / 'owned.json')
    commands = Commands(OUT, protocol, original['baseline_available'])
    result = dict(complete=False, diagnostic_only=True,
                  original_runtime_exit_code=1, supplement_accepted=False)
    try:
        _, namespace = commands.get('namespace', owned['namespace'])
        require(namespace['metadata']['uid'] == owned['namespace_uid'], 'namespace replaced')
        before_ref, before = fresh_sample(commands, owned['namespace'])
        leaders = {r[k]['leader_id'] for r in before.values() for k in ('state', 'state_after')}
        require(len(leaders) == 1 and leaders <= set('123'), 'no agreed leader')
        leader = next(iter(leaders))
        for row in before.values():
            for field in ('state', 'state_after'):
                state = row[field]
                require(state['fatal'] == '' and state['bootstrap_state'] == 'Serving'
                        and state['driver_applied_index'] == state['raft_committed'] == '52'
                        and state['driver_applied_term'] == '2'
                        and state['applied_index'] == '51' and state['applied_term'] == '1',
                        'observed diagnostic no-op gap changed')
        history = RUN / 'native-pre/history.jsonl'
        records = [json.loads(line) for line in history.read_bytes().splitlines()]
        population = history_population(records, protocol)
        config = load(RUN / 'native-pre/config.json')
        query(commands, owned['namespace'], leader, config, population, 'acknowledged-values')
        after_ref, after = fresh_sample(commands, owned['namespace'])
        require(all(before[n]['process_start_ticks'] == after[n]['process_start_ticks']
                    and before[n]['pod_uid'] == after[n]['pod_uid'] for n in '123'),
                'process changed during read-only diagnosis')
        result.update(complete=True, namespace=owned['namespace'],
                      namespace_uid=owned['namespace_uid'], before=before_ref, after=after_ref,
                      history_sha256=hashlib.sha256(history.read_bytes()).hexdigest(),
                      full_public_value_readback=load(OUT / 'acknowledged-values.json')['result'],
                      scope='All acknowledged final values and the sentinel read back through the public API after the actual leader kill. No new write or second rotation; the original failed protocol remains failed.')
    except BaseException as exc:
        result['failure'] = repr(exc)
        raise
    finally:
        save(OUT / 'result.json', result)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
