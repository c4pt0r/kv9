"""Finite supplement predicates. Existing native/history/topology readers are unchanged."""
import hashlib
import ipaddress
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'lib'))
import batch_workload_report as native
import process_probe
import observer_fields
import wal_layout
from native_protocol import process_identity, state_writer

def require(ok, message):
    if not ok:
        raise ValueError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(path, cap=4 * 1024 * 1024):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing/aliased reporting file: ' + str(path))
    with path.open('rb') as stream:
        data = stream.read(cap + 1)
    require(len(data) <= cap, 'reporting file exceeds cap: ' + str(path))
    return data

def load(path):
    return json.loads(read(path))

def prepared_store(text,node):
    tokens=text.split()
    require(len(tokens)==3 and all(token.count('=')==1 for token in tokens),'malformed store-prepare CLI receipt')
    fields=dict(token.split('=',1) for token in tokens)
    require(set(fields)=={'store_prepared','node_id','store_incarnation'} and fields['store_prepared']=='true' and
            fields['node_id']==str(node) and re.fullmatch('[0-9a-f]{32}',fields['store_incarnation']),
            'store-prepare CLI identity invalid')
    return fields

def config_check(c, p, phase, run_id, services):
    native.config_check(c)
    require(phase in ('pre', 'post'), 'unknown burst')
    require(c['run_id'] == c['keyspace_name'] == 'pdrot-' + phase + '-' + run_id, 'wrong fresh keyspace name')
    require(all(type(c.get(k)) is type(v) and c[k] == v for k, v in p['config'].items()), 'burst configuration differs')
    require(all(type(c['client'].get(k)) is type(v) and c['client'][k] == v for k, v in p['client'].items()), 'client limits differ')
    expected = [{'node_id': n, 'address': services[str(n)] + ':20160'} for n in (1, 2, 3)]
    require(c['client']['peers'] == expected, 'burst does not use the three retained Services')
    for address in services.values():
        require(not ipaddress.ip_address(address).is_loopback, 'Service address is loopback')

def history_population(records, p):
    """Additional healthy finite-burst requirements after unchanged full native validation."""
    calls = {}; replies = {}; previous = -1; active = None
    for seq, event in enumerate(records[1:]):
        require(type(event.get('seq')) is int and event['seq'] == seq, 'history sequence missing/reordered')
        require(event['monotonic_ns'] >= previous, 'history clock reversed')
        previous = event['monotonic_ns']
        if event['type'] == 'invoke':
            require(active is None and event['id'] not in calls, 'single-worker history overlaps or repeats')
            calls[event['id']] = event; active = event['id']
        else:
            require(event['type'] == 'return' and event['id'] == active and active not in replies,
                    'missing/duplicate history completion')
            require(event['outcome'] == 'ok', 'unhealthy burst outcome retained but not accepted')
            replies[active] = event; active = None
    require(active is None and len(calls) == len(replies) == p['config']['max_calls'], 'finite burst incomplete')
    traffic = [v for v in calls.values() if v['phase'] == 'baseline']
    writes = [v for v in traffic if v['op'] == 'batch_put']
    reads = [v for v in traffic if v['op'] == 'batch_get']
    require(len(traffic) == 50 and len(writes) >= p['minimum_confirmed_batches'] and reads,
            'finite burst lacks required acknowledged batch population')
    require(len(writes) + len(reads) == len(traffic), 'unexpected traffic API')
    expected = {}
    for call in calls.values():
        if call['op'] == 'batch_put':
            for key, value in call['args']['pairs']:
                expected[key] = value
    require(len(expected) == 65, 'complete dataset/sentinel missing')
    return dict(calls=len(calls), traffic_calls=len(traffic), acknowledged_batches=len(writes),
                acknowledged_batch_items=sum(len(c['args']['pairs']) for c in writes),
                acknowledged_input_value_bytes=sum(len(v) // 2 for c in writes for _, v in c['args']['pairs']),
                read_calls=len(reads), outcomes={'ok': len(replies)}, expected_values=expected)

ZERO = ('public_rpc_in_flight', 'public_rpc_queued', 'public_rpc_running', 'public_rpc_encoded_bytes',
        'raft_async_apply_queued', 'raft_async_apply_in_flight', 'raft_async_read_queued',
        'raft_async_read_active', 'raft_async_read_in_flight', 'raft_async_read_active_groups')

def acknowledged_write_fence(records):
    """Maximum successful actual native write receipt, after full-history validation."""
    calls={}; receipts=[]; paired={}
    for event in records[1:]:
        if event['type']=='invoke':
            require(event['id'] not in calls,'duplicate invocation while deriving acknowledged fence')
            calls[event['id']]=event
        elif event['type']=='return':
            require(event['id'] in calls,'receipt lacks invocation')
            call=calls[event['id']]
            if call['op'] not in ('put','delete','batch_put'):continue
            require(event['outcome']=='ok','unhealthy write cannot define accepted acknowledged prefix')
            receipt=event['observation']['receipt']
            require(isinstance(receipt,dict) and set(receipt)=={'applied_term','applied_index'},'missing exact write receipt')
            term,index=receipt['applied_term'],receipt['applied_index']
            require(type(term)is int and type(index)is int and term>0 and index>0,'invalid acknowledged receipt position')
            require(index not in paired or paired[index]==term,'same receipt index has different terms')
            paired[index]=term;receipts.append((index,term))
    require(receipts,'no actual acknowledged native write fence')
    ordered=sorted(set(receipts))
    require(all(a[1]<=b[1] for a,b in zip(ordered,ordered[1:])),'acknowledged receipt term regressed by index')
    index,term=ordered[-1]
    return dict(term=term,index=index)

def watermark_check(s,acknowledged_fence=None):
    """Command-only positions skip no-ops; unified driver progress covers every entry kind."""
    names=('raft_committed','term','driver_applied_index','driver_applied_term','applied_index','applied_term')
    if not all(isinstance(s.get(k),str) and re.fullmatch(r'0|[1-9][0-9]*',s[k])for k in names):return False
    committed,current,di,dt,ai,at=(int(s[k])for k in names)
    if not (committed>0 and di==committed and 0<dt<=current and 0<=ai<=di and 0<=at<=dt):return False
    if (ai==0)!=(at==0) or (ai==di and at!=dt):return False
    if acknowledged_fence is not None:
        require(isinstance(acknowledged_fence,dict) and set(acknowledged_fence)=={'term','index'} and
                all(type(v)is int and v>0 for v in acknowledged_fence.values()),'malformed acknowledged fence')
        fi,ft=acknowledged_fence['index'],acknowledged_fence['term']
        if not (ai>=fi and at>=ft and (ai!=fi or at==ft)):return False
    return True

def drained(s,acknowledged_fence=None):
    return (s.get('bootstrap_state') == 'Serving' and s.get('fatal') == '' and
            all(s.get(k) == '0' for k in ZERO) and
            s.get('raft_async_apply_stopped') == s.get('raft_async_read_stopped') == 'false' and
            watermark_check(s,acknowledged_fence))

def sample_check(before, raw, after, p):
    def voters(obj):
        selected = [x for x in obj['items'] if x['metadata'].get('labels', {}).get('app') == 'kv9']
        require(len(selected) == 3, 'voter Pod count differs')
        result = {x['metadata']['labels']['kv9-node']: x for x in selected}
        require(set(result) == set('123'), 'voter identities differ')
        return result
    first, last = voters(before), voters(after)
    require(set(raw) == set('123'), 'missing process sample')
    rows = {}
    for n, pod in first.items():
        require(process_identity(pod) == process_identity(last[n]), 'container changed during process sample')
        require(pod['status']['phase'] == 'Running' and len(pod['status']['containerStatuses']) == 1,
                'voter container absent/ambiguous')
        cs = pod['status']['containerStatuses'][0]
        require(cs['name'] == 'kv9' and 'running' in cs['state'] and cs['imageID'] in p['accepted_cri_image_ids'],
                'voter executing image differs')
        row = process_probe.parse(raw[n], p['server']['sha256'], '/usr/local/bin/kv9')
        observer_fields.validate(row, pod, p['source_default_limits'])
        row.update(pod_uid=pod['metadata']['uid'], pod=pod['metadata']['name'])
        require(row['state']['node_id'] == row['state_after']['node_id'] == n, 'status node mismatch')
        rows[n] = row
    return rows

def drain_check(samples,acknowledged_fence=None):
    require(3 <= len(samples) <= 100, 'fresh drain sample count invalid')
    ids = {n: state_writer(r) for n, r in samples[0].items()}
    last = {n: int(r['state_after']['metrics_export_successes']) for n, r in samples[0].items()}
    advances = dict.fromkeys(ids, 0)
    for sample in samples[1:]:
        require(set(sample) == set('123'), 'drain voter missing')
        for n, row in sample.items():
            require(state_writer(row) == ids[n], 'drain process identity changed')
            before, after = (int(row[k]['metrics_export_successes']) for k in ('state', 'state_after'))
            require(last[n] <= before <= after, 'publication counter regressed')
            if before > last[n]:
                advances[n] += 1; last[n] = after
    final = samples[-1]
    require(all(v >= 2 for v in advances.values()), 'two fresh publications absent')
    require(all(drained(r[k],acknowledged_fence) for r in final.values() for k in ('state', 'state_after')), 'fresh final drain incomplete')
    leaders = {r[k]['leader_id'] for r in final.values() for k in ('state', 'state_after')}
    require(len(leaders) == 1 and leaders <= set('123'), 'no agreed leader')
    require(len({r['state_after']['raft_committed'] for r in final.values()}) == 1, 'voters not equally applied')
    return dict(leader=next(iter(leaders)), advances=advances, identities={n:list(v) for n,v in ids.items()},
                acknowledged_write_fence=acknowledged_fence,
                command_positions={n:dict(term=int(r['state_after']['applied_term']),index=int(r['state_after']['applied_index']))for n,r in final.items()},
                driver_positions={n:dict(term=int(r['state_after']['driver_applied_term']),index=int(r['state_after']['driver_applied_index']))for n,r in final.items()},
                committed=int(next(iter(final.values()))['state_after']['raft_committed']))

def selected_topology(data, headers):
    layout = wal_layout.decode_topology(data, Path('/data'))
    require(layout.active['sequence'] >= 2 and layout.closed, 'selected successor rotation absent')
    selected = list(layout.closed) + [layout.active]
    require(set(headers) == {str(x['sequence']) for x in selected}, 'selected segment header set differs')
    for item in selected:
        row = headers[str(item['sequence'])]
        require(wal_layout.header(bytes.fromhex(row['header_hex'])) ==
                {k: item[k] for k in ('stream', 'sequence', 'previous')}, 'physical selected segment header differs')
        require(row['bytes'] >= item.get('bytes', 60) and row['inode'] > 0 and row['device'] > 0,
                'selected segment file absent/truncated')
        require(row['path'] == str(layout.segment_path(item)), 'selected segment path differs')
    return layout.evidence()

def sequence_advance(pre, recovered, post):
    require(set(pre) == set(recovered) == set(post) == set('123'), 'topology lacks all three stores')
    for n in pre:
        a, b, c = pre[n], recovered[n], post[n]
        require(a['active']['stream'] == b['active']['stream'] == c['active']['stream'], 'store stream identity changed')
        require(b['active']['sequence'] >= a['active']['sequence'] and b['generation'] >= a['generation'],
                'recovered selected topology regressed')
        require(c['active']['sequence'] > b['active']['sequence'] and c['generation'] > b['generation'],
                'second burst did not advance selected successor sequence')

def observation_order(pre_end, pre_top, fault_probe, fault_capture, recovered_top, recovery_query, post_start, post_end, post_top):
    for group in (pre_top,recovered_top,post_top):
        require(set(group)==set('123'),'ordered topology does not cover three stores')
        require(all(type(r[k]) is int and r[k]>=0 for r in group.values() for k in ('topology','topology_after')),
                'invalid topology command sequence')
        require(all(r['topology']<r['topology_after'] for r in group.values()),'reversed topology capture')
    require(pre_end < min(x['topology'] for x in pre_top.values()) and
            max(x['topology_after'] for x in pre_top.values()) < fault_probe < fault_capture <
            min(x['topology'] for x in recovered_top.values()) and
            max(x['topology_after'] for x in recovered_top.values()) < recovery_query < post_start <= post_end <
            min(x['topology'] for x in post_top.values()), 'fault/rotation/recovery/burst ordering differs')

def fault_check(fault, before, after, leader, ns, lifecycle_before, lifecycle_after):
    require(before['metadata']['labels']['kv9-node'] == leader, 'fault victim was not the observed leader')
    require(before['metadata']['uid'] == after['metadata']['uid'] and
            before['metadata']['name'] == after['metadata']['name'] and
            before['spec']['volumes'] == after['spec']['volumes'], 'restart changed Pod or original storage')
    require(lifecycle_before and lifecycle_before == lifecycle_after, 'original lifecycle bytes changed')
    a, b = before['status']['containerStatuses'][0], after['status']['containerStatuses'][0]
    require(a['name'] == b['name'] == 'kv9' and b['restartCount'] == a['restartCount'] + 1 and
            a['containerID'] != b['containerID'] and 'running' in b['state'], 'not exactly one container restart')
    dead = b['lastState']['terminated']
    require(dead['containerID'] == a['containerID'] and dead['exitCode'] == 137, 'original container death not proven')
    require(fault['kind'] == 'PodChaos' and fault['metadata']['namespace'] == ns and
            fault['metadata']['name'] == 'kill-rotation-leader' and fault['metadata'].get('uid') and
            not fault['metadata'].get('deletionTimestamp'), 'wrong or deleted fault resource')
    s = fault['spec']
    require(s['action'] == 'container-kill' and s['mode'] == 'one' and s['containerNames'] == ['kv9'] and
            s['selector']['namespaces'] == [ns] and s['selector']['pods'] == {ns: [before['metadata']['name']]},
            'fault does not exclusively target the owned leader container')
    require(any(c['type'] == 'AllInjected' and c['status'] == 'True' for c in fault['status']['conditions']),
            'Chaos fault not injected')
    target = ns + '/' + before['metadata']['name'] + '/kv9'
    require(any(r['id'] == target and r['phase'] == 'Injected' and r['injectedCount'] > 0
                for r in fault['status']['experiment']['containerRecords']), 'Chaos lacks exact container injection receipt')
    return dict(victim=leader, pod_uid=before['metadata']['uid'], old_container=a['containerID'],
                new_container=b['containerID'], fault_uid=fault['metadata']['uid'], exit_code=137)

def query_script(keyspace, expected):
    require(type(keyspace) is int and keyspace > 0, 'invalid keyspace')
    lines = ['set -euo pipefail']
    for key in sorted(expected):
        require(re.fullmatch('[0-9a-f]+', key), 'non-hex query key')
        lines += ["printf '@@KEY:" + key + "@@\\n'",
                  'timeout 2 /usr/local/bin/kv9 client raw-get --addr 127.0.0.1:20160 --keyspace ' +
                  str(keyspace) + ' --key-hex ' + key]
    return '\n'.join(lines) + '\n'

def query_check(text, expected):
    parts = re.split(r'^@@KEY:([0-9a-f]+)@@\n', text, flags=re.M)
    require(parts[0] == '' and len(parts[1::2]) == len(expected) and len(set(parts[1::2])) == len(expected),
            'recovery readback missing/duplicate key')
    found = {}
    for key, output in zip(parts[1::2], parts[2::2]):
        values = [line[len('value_hex='):] for line in output.splitlines() if line.startswith('value_hex=')]
        require(len(values) == 1, 'recovery readback lacks one present value')
        found[key] = values[0]
    require(found == expected, 'acknowledged dataset or empty sentinel not recovered')
    return dict(keys=len(found), value_bytes=sum(len(v) // 2 for v in found.values()), full_dataset_equal=True)
