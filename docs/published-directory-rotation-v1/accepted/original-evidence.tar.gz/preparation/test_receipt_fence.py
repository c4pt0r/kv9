"""Small controls for the corrected watermark/acknowledged-prefix boundary only."""
import copy
import unittest
import checks as c
from test_reader import drain_samples

def receipt_history():
    rows=[{'type':'header'}]
    for i,(term,index) in enumerate([(1,49),(1,51),(1,50)]):
        rows.extend([dict(type='invoke',id=i,op='batch_put'),
          dict(type='return',id=i,outcome='ok',observation={'receipt':{'applied_term':term,'applied_index':index}})])
    return rows

def noop_gap():
    rows=drain_samples()
    for sample in rows:
        for row in sample.values():
            for when in ('state','state_after'):
                row[when].update(term='2',raft_committed='52',driver_applied_index='52',driver_applied_term='2',
                                  applied_index='51',applied_term='1')
    return rows

class ReceiptFence(unittest.TestCase):
    def test_maximum_successful_receipt_and_observed_noop_gap(self):
        fence=c.acknowledged_write_fence(receipt_history())
        self.assertEqual(fence,{'term':1,'index':51})
        result=c.drain_check(noop_gap(),fence)
        self.assertEqual(result['acknowledged_write_fence'],fence)
        self.assertEqual(result['driver_positions']['2'],{'term':2,'index':52})
        self.assertEqual(result['command_positions']['2'],{'term':1,'index':51})
        # No-op allowance preserves all required quiescence/freshness checks.
        rows=noop_gap();rows[-1]['2']['state_after']['raft_async_apply_in_flight']='1'
        with self.assertRaises(ValueError):c.drain_check(rows,fence)
    def test_committed_not_driver_applied_is_refused(self):
        rows=noop_gap()
        for when in ('state','state_after'):
            rows[-1]['2'][when]['driver_applied_index']='51'
            rows[-1]['2'][when]['driver_applied_term']='1'
        with self.assertRaises(ValueError):c.drain_check(rows,{'term':1,'index':51})
    def test_below_acknowledged_prefix_and_incoherent_pairs_are_refused(self):
        for change in ({'applied_index':'50'},{'applied_term':'2'},
                       {'driver_applied_term':'none'},{'applied_index':'52','applied_term':'1'}):
            rows=noop_gap();rows[-1]['2']['state_after'].update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):c.drain_check(rows,{'term':1,'index':51})
        for change in ('missing','unknown','same-index-other-term'):
            history=receipt_history()
            if change=='missing':history[-1]['observation']['receipt']=None
            if change=='unknown':history[-1]['outcome']='unknown'
            if change=='same-index-other-term':history[-1]['observation']['receipt']={'applied_term':2,'applied_index':51}
            with self.subTest(receipt=change),self.assertRaises(ValueError):c.acknowledged_write_fence(history)

if __name__=='__main__':unittest.main(verbosity=2)
