"""Exercise the actual new namespace-create/readback statements without a cluster."""
import ast
import copy
from pathlib import Path
import unittest

from checks import require

HERE=Path(__file__).resolve().parent

class FakeCommands:
    def __init__(self,observed='enabled'):
        self.observed=observed;self.created=[]
    def create(self,obj):self.created.append(copy.deepcopy(obj))
    def get(self,*args):
        assert args==('namespace','owned')
        result=copy.deepcopy(self.created[-1])
        if self.observed is None:result['metadata'].pop('annotations',None)
        else:result['metadata']['annotations']['chaos-mesh.org/inject']=self.observed
        return 1,result

class NamespaceOptIn(unittest.TestCase):
    def test_actual_create_and_independent_readback_opt_in(self):
        tree=ast.parse((HERE/'runner.py').read_text())
        run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
        index=next(i for i,n in enumerate(run.body) if isinstance(n,ast.Expr) and
            isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='create' and
            any(isinstance(x,ast.Constant) and x.value=='Namespace' for x in ast.walk(n)))
        # Compile precisely the actual create/get/require statements, not a duplicate predicate.
        code=compile(ast.fix_missing_locations(ast.Module(body=run.body[index:index+3],type_ignores=[])),str(HERE/'runner.py'),'exec')
        for observed in ('enabled',None,'disabled'):
            c=FakeCommands(observed);scope=dict(c=c,ns='owned',require=require)
            if observed=='enabled':exec(code,scope)
            else:
                with self.assertRaises(ValueError):exec(code,scope)
            self.assertEqual(c.created[0]['metadata']['annotations'],{'chaos-mesh.org/inject':'enabled'})
        audit=ast.parse((HERE/'audit.py').read_text())
        predicate=next(n for n in ast.walk(audit) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and
            any(isinstance(x,ast.Constant) and x.value=='original owned namespace lacked explicit Chaos Mesh opt-in' for x in ast.walk(n)))
        code=compile(ast.fix_missing_locations(ast.Module(body=[predicate],type_ignores=[])),str(HERE/'audit.py'),'exec')
        for observed in ('enabled',None,'disabled'):
            namespace={'metadata':{'annotations':{'chaos-mesh.org/inject':observed}}}
            if observed=='enabled':exec(code,dict(namespace=namespace,require=require))
            else:
                with self.assertRaises(ValueError):exec(code,dict(namespace=namespace,require=require))

if __name__=='__main__':unittest.main(verbosity=2)
