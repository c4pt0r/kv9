#!/usr/bin/env python3
"""Independent offline acceptance of the exact complete rotation supplement."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import time
import traceback

from checks import *

class Evidence:
    def __init__(self, root, p):
        self.root = Path(root); self.p = p; self.inventory = {}; self.commands = {}
        result = self.json('result.json')
        require(result['complete'] is True and result['accepted'] is True, 'original runner failed/incomplete')
        count = result['command_count']
        require(type(count) is int and 0 < count <= p['max_commands'], 'invalid command count')
        self.result = result
        for n in range(count):
            stem = f'command-{n:04d}'
            start = self.json(stem+'.start.json'); row = self.json(stem+'.result.json')
            child = self.json(stem+'.child.json')
            require(start['argv'] == row['argv'] and start['started_ns'] == row['started_ns'] and
                    row['child'] == child and row['complete'] is True and row['reaped'] is True and
                    row['exit_code'] == 0 and row['failure'] is None and row['ended_ns'] >= row['started_ns'],
                    'failed/unreaped/altered command record')
            for kind in ('stdout','stderr'):
                data = self.bytes(row[kind]['path'], p['max_command_output_bytes'])
                require(len(data) == row[kind]['bytes'] and digest(data) == row[kind]['sha256'], 'command output identity changed')
            if 'stdin' in row:
                require(digest(self.bytes(row['stdin'])) == row['stdin_sha256'], 'command input changed')
            self.commands[n] = row

    def bytes(self, path, cap=4*1024*1024):
        require(not Path(path).is_absolute() and '..' not in Path(path).parts, 'evidence path escapes output')
        data = read(self.root/path,cap)
        self.inventory[path] = dict(bytes=len(data),sha256=digest(data))
        return data
    def json(self,path): return json.loads(self.bytes(path))
    def output(self,n,expected=None,cap=None):
        require(type(n) is int and n in self.commands, 'unknown command reference')
        row = self.commands[n]
        if expected is not None: require(row['argv'] == expected, 'command argv does not match required observation')
        return self.bytes(row['stdout']['path'],cap or self.p['max_command_output_bytes'])
    def k(self,*args): return ['kubectl','--kubeconfig',self.p['kubeconfig'],'--request-timeout=10s',*args]
    def exe(self,ns,pod,*args): return self.k('exec','-n',ns,pod,'--',*args)

def read_drain(e, name, ns):
    refs = e.json(name+'.json'); samples=[]
    for ref in refs['samples']:
        before=json.loads(e.output(ref['before'],e.k('get','pods','-n',ns,'-o','json')))
        after=json.loads(e.output(ref['after'],e.k('get','pods','-n',ns,'-o','json')))
        raw={n:e.output(i,e.exe(ns,'kv9-n'+n,'/bin/bash','-c',process_probe.PROBE,
                    'rotation-process','/data/status','/usr/local/bin/kv9')).decode() for n,i in ref['probes'].items()}
        samples.append(sample_check(before,raw,after,e.p))
    result=drain_check(samples)
    require(result == refs['accepted'], 'runner fresh-drain summary does not reproduce')
    times=[e.commands[x['before']]['started_ns'] for x in refs['samples']]
    require(times==sorted(times) and e.commands[refs['samples'][-1]['after']]['ended_ns']-times[0] <= 25_000_000_000,
            'fresh drain is unordered or exceeds bounded observation')
    return result,samples[-1],refs

def read_topology(e,name,ns):
    refs=e.json(name+'.json'); result={}
    require(set(refs)==set('123'),'topology store missing')
    for n,ref in refs.items():
        expected=e.exe(ns,'kv9-n'+n,'bash','-c',
             'set -e; test ! -L /data/catalog.wal; test "$(stat -c %s /data/catalog.wal)" -le 4194304; cat /data/catalog.wal')
        data=e.output(ref['topology'],expected,4*1024*1024)
        require(data==e.output(ref['topology_after'],e.exe(ns,'kv9-n'+n,'cat','/data/catalog.wal'),4*1024*1024),
                'topology changed during selected header capture')
        layout=wal_layout.decode_topology(data,Path('/data')); headers={}
        selected=list(layout.closed)+[layout.active]
        require(set(ref['headers'])=={str(x['sequence']) for x in selected},'selected header command missing')
        for item in selected:
            path=str(layout.segment_path(item)); i=ref['headers'][str(item['sequence'])]
            script='set -e; test ! -L "$1"; test -f "$1"; stat -c "%s %i %d" "$1"; dd if="$1" bs=60 count=1 status=none'
            raw=e.output(i,e.exe(ns,'kv9-n'+n,'bash','-c',script,'selected-segment',path),4096)
            line,header=raw.split(b'\n',1); size,inode,device=map(int,line.split())
            headers[str(item['sequence'])]=dict(path=path,bytes=size,inode=inode,device=device,header_hex=header.hex())
            require(ref['topology']<i<ref['topology_after'],'physical header was not captured inside topology identity bracket')
        result[n]=selected_topology(data,headers)
    return result,refs

def read_burst(e,phase,owned,bootstrap):
    ref=e.json(phase+'-burst.json'); directory=e.root/('native-'+phase)
    config=e.json('native-'+phase+'/config.json')
    config_check(config,e.p,phase,owned['run_id'],bootstrap['services'])
    for name,i in ref['files'].items():
        data=e.bytes('native-'+phase+'/'+name,e.p['config']['history_bytes'])
        require(data==e.output(i,e.exe(owned['namespace'],'client-'+phase,'cat','/tmp/workload/'+name)),
                'native original/captured files differ')
    require(set(ref['files'])==set(('config.json','build.json','history.jsonl','report.json','ready.json','progress.json')),
            'native retained original file set differs')
    verdict=native.validate(directory,Path(e.p['native_build']),e.p['revision'],seconds=30)
    require(verdict==ref['validation'],'independent original full-history verdict differs')
    records=[json.loads(x) for x in e.bytes('native-'+phase+'/history.jsonl',e.p['config']['history_bytes']).splitlines()]
    population=history_population(records,e.p)
    require({k:v for k,v in population.items() if k!='expected_values'}==ref['population'],'burst outcome summary differs')
    report=e.json('native-'+phase+'/report.json');ready=e.json('native-'+phase+'/ready.json')
    require(report['stop']['reason']=='operation_limit' and report['process_id']==ready['process_id'],'native finite stop/PID differs')
    before=json.loads(e.output(ref['initial_pod'],e.k('get','pod','client-'+phase,'-n',owned['namespace'],'-o','json')))
    after=json.loads(e.output(ref['final_pod'],e.k('get','pod','client-'+phase,'-n',owned['namespace'],'-o','json')))
    require(process_identity(before)==process_identity(after),'client lifetime changed')
    cs=after['status']['containerStatuses']
    require(len(cs)==1 and cs[0]['restartCount']==0 and cs[0]['imageID'] in e.p['accepted_cri_image_ids'], 'client image/restart differs')
    exit_text=e.output(ref['process_exit']).decode()
    fields=dict(line.split('=',1) for line in exit_text.splitlines() if '='in line)
    require(fields.get('process_pid')==str(report['process_id']) and fields.get('process_absent')=='true' and
            re.fullmatch(r'[0-9a-f-]{36}',fields.get('process_boot_id','')),'native child exit not proven')
    require(e.output(ref['exit_marker']).strip()==b'0','native shell exit marker failed')
    return config,population,ref

def audit(root, terminal_path, terminal_sha):
    from runner import verify_preparation
    p=verify_preparation(); e=Evidence(root,p)
    terminal=load(terminal_path)
    require(digest(read(terminal_path))==terminal_sha and terminal['complete'] is True and terminal['exit_code']==0 and
            terminal.get('terminal_receipt') and Path(terminal['result_path']).resolve()==(e.root/'result.json').resolve() and
            terminal['result_sha256']==digest(e.bytes('result.json')),'actual runtime terminal binding absent')
    require(not Path('/proc/'+str(e.result['controller']['pid'])).exists(),'runner controller still exists; PID reuse requires explicit review')
    owned=e.json('owned.json');ns=owned['namespace'];bootstrap=e.json('bootstrap.json')
    require(ns=='kv9-pdrot-'+owned['run_id'] and ns not in p['preserve_namespaces'],'namespace outside generated ownership')
    initial=json.loads(e.output(owned['namespaces_before'],e.k('get','namespaces','-o','json')))
    require({x['metadata']['name']:x['metadata']['uid'] for x in initial['items']}==p['preserve_namespaces'],'historical namespace binding changed')
    namespace=json.loads(e.output(owned['namespace_command'],e.k('get','namespace',ns,'-o','json')))
    require(namespace['metadata']['uid']==owned['namespace_uid'],'owned UID differs')
    require(namespace['metadata'].get('annotations',{}).get('chaos-mesh.org/inject')=='enabled',
            'original owned namespace lacked explicit Chaos Mesh opt-in')
    samples={};drains={};drain_refs={}
    for name in ('initial','pre','recovered','post','final'):
        drains[name],samples[name],drain_refs[name]=read_drain(e,name+'-drain',ns)
    for n in '123':
        prepared=bootstrap['prepared'][n]['fields']
        require(prepared_store(e.output(bootstrap['prepared'][n]['command']).decode(),n)==prepared,
                'store-prepare original receipt differs from bootstrap summary')
        for sample in samples.values():
            for key in ('state','state_after'):
                require(sample[n][key]['store_incarnation']==prepared['store_incarnation'], 'original prepared store changed')
        if n!=drains['pre']['leader']:
            require(len({state_writer(sample[n]) for sample in samples.values()})==1, 'non-victim voter lifetime changed')
        require(samples['pre'][n]['state_after']['root_digest']==samples['final'][n]['state_after']['root_digest'], 'root identity changed')
    resources_ref=e.json('final-resource-capture.json')
    final_resources=json.loads(e.output(resources_ref['command'],e.k('get','pods,pvc,podchaos,service','-n',ns,'-o','json')))
    final_pvcs={x['metadata']['name']:x for x in final_resources['items'] if x['kind']=='PersistentVolumeClaim'}
    require(set(final_pvcs)=={'data-n'+n for n in '123'},'final original PVC set differs')
    for n in '123':
        old=bootstrap['pvcs'][n];new=final_pvcs['data-n'+n]
        require(old['metadata']['uid']==new['metadata']['uid'] and old['spec']['volumeName']==new['spec']['volumeName'],
                'original physical volume binding changed')
    first_ref=drain_refs['initial']['samples'][0]
    first_pods=json.loads(e.output(first_ref['before']))
    require(all(x['status']['containerStatuses'][0]['restartCount']==0 for x in first_pods['items']
                if x['metadata'].get('labels',{}).get('app')=='kv9'),'bootstrap silently restarted a voter')
    top={};top_refs={}
    for phase in ('pre','recovered','post'):
        top[phase],top_refs[phase]=read_topology(e,phase+'-topology',ns)
    sequence_advance(top['pre'],top['recovered'],top['post'])
    pre,pop_pre,ref_pre=read_burst(e,'pre',owned,bootstrap)
    post,pop_post,ref_post=read_burst(e,'post',owned,bootstrap)
    require(pre['client']['keyspace_id']!=post['client']['keyspace_id'],'post keyspace not fresh')
    f=e.json('fault.json');leader=drains['pre']['leader']
    before=json.loads(e.output(f['before'],e.k('get','pod','kv9-n'+leader,'-n',ns,'-o','json')))
    after=json.loads(e.output(f['after'],e.k('get','pod','kv9-n'+leader,'-n',ns,'-o','json')))
    actual_fault=json.loads(e.output(f['fault'],e.k('get','podchaos','kill-rotation-leader','-n',ns,'-o','json')))
    checked=fault_check(actual_fault,before,after,leader,ns,e.output(f['lifecycle_before']),e.output(f['lifecycle_after']))
    observed=process_probe.parse(e.output(f['leader_probe'],e.exe(ns,'kv9-n'+leader,'bash','-c',process_probe.PROBE,
                  'fault-leader','/data/status','/usr/local/bin/kv9')).decode(),p['server']['sha256'],'/usr/local/bin/kv9')
    require(all(observed[k]['leader_id']==leader and observed[k]['role']=='leader' for k in ('state','state_after')),
            'killed container was not observed leader')
    require(observed['process_start_ticks']==samples['pre'][leader]['process_start_ticks'] and
            samples['recovered'][leader]['process_start_ticks']!=observed['process_start_ticks'], 'server replacement identity missing')
    require(checked==f['checked'],'fault summary differs')
    tree=f['original_tree'];original_tree=load(e.root/'pre-fault-trees.json')
    require(tree in original_tree['rows'] and tree['pod']=='kv9-n'+leader and
            tree['container']==checked['old_container'].removeprefix('containerd://'),'original leader tree identity differs')
    text=e.output(tree['tree']).decode();boot=text.split('@@BOOT@@\n')[1].split('@@')[0].strip()
    sections=text.split('@@PID@@\n')[1:]
    require(sections and len(sections)==len(f['original_process_exit_commands']),'original leader exit population differs')
    for section,i in zip(sections,f['original_process_exit_commands']):
        pid=int(section.splitlines()[0].split(' ',1)[0])
        script='set -e; cat /proc/sys/kernel/random/boot_id; if test -e /proc/"$1"/stat; then cat /proc/"$1"/stat; else printf "absent\\n"; fi'
        raw=e.output(i,['docker','exec',tree['node'],'bash','-c',script,'owned-exit',str(pid)])
        require(raw.decode().splitlines()==[boot,'absent'],'original leader process death not observed')
    # Establish actual command ordering, including all three selected topologies before the fault.
    pre_end=ref_pre['final_pod'];fault_at=f['leader_probe'];post_start=ref_post['create_keyspace']
    observation_order(pre_end,top_refs['pre'],fault_at,f['fault'],top_refs['recovered'],
                      e.json('recovered-pre-values.json')['command'],post_start,ref_post['final_pod'],top_refs['post'])
    queries={}
    for name,config,pop,phase in [('recovered-pre-values',pre,pop_pre,'recovered'),
                                ('final-pre-values',pre,pop_pre,'post'),('final-post-values',post,pop_post,'post')]:
        ref=e.json(name+'.json');require(ref['leader']==drains[phase]['leader'],'query leader differs from fresh agreement')
        script=query_script(config['client']['keyspace_id'],pop['expected_values'])
        data=e.output(ref['command'],e.exe(ns,'kv9-n'+ref['leader'],'bash','-c',script)).decode()
        queries[name]=query_check(data,pop['expected_values'])
        require(queries[name]==ref['result'],'query summary differs')
        require(f['fault']<ref['command'],'recovery query predates fault')
    require(e.json('recovered-pre-values.json')['command']<post_start,'pre-fault dataset not checked before second burst')
    floor=max(p['floor_bytes'],owned['baseline_available']-p['maximum_added_bytes'])
    resources=[json.loads(x) for x in e.bytes('resources.jsonl',16*1024*1024).splitlines()]
    require(resources and all(x['available_bytes']>=floor for x in resources),'recorded space floor violated')
    require(len({x['device'] for x in resources})==1,'resource samples changed device')
    require(max(b['unix_ns']-a['unix_ns'] for a,b in zip(resources,resources[1:]))<=6_000_000_000,
            'unobserved host-space sample gap exceeds six seconds')
    trees=e.json('prearchive-trees.json');require(len(trees['rows'])==5,'three voters/two collector containers not retained')
    # Stage acceptance leaves the exact owned resources alive until archival is independently read back.
    result=dict(complete=True,accepted=True,protocol_id=p['id'],revision=p['revision'],
       runtime_terminal_path=str(terminal_path),runtime_terminal_sha256=terminal_sha,runtime_result_sha256=terminal['result_sha256'],
       namespace=ns,namespace_uid=owned['namespace_uid'],default_segment_target_bytes=p['engine_segment_target_bytes'],
       full_history_checked=True,bursts={phase:{k:v for k,v in pop.items() if k!='expected_values'}
          for phase,pop in [('pre',pop_pre),('post',pop_post)]},topology=top,fault=checked,
       fresh_drains=drains,recovery_readback=queries,cleanup_pending=True,
       scope='Closed-loop correctness supplement. Final acknowledged value per key and empty sentinel recovered; overwritten intermediate versions remain in complete client histories. No QPS claim or instruction-boundary crash claim.',
       minimum_observed_available=min(x['available_bytes'] for x in resources))
    return result,e.inventory

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--run',type=Path,required=True)
    ap.add_argument('--runtime-terminal',type=Path,required=True);ap.add_argument('--runtime-terminal-sha256',required=True)
    ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(exist_ok=False)
    result=dict(complete=False,accepted=False,started_ns=time.time_ns())
    try:
        result,inventory=audit(a.run,a.runtime_terminal,a.runtime_terminal_sha256)
        (a.output/'input-inventory.json').write_text(json.dumps(inventory,indent=2,sort_keys=True)+'\n')
    except BaseException as exc:
        result.update(failure=repr(exc),traceback=traceback.format_exc());raise
    finally:
        result['ended_ns']=time.time_ns()
        (a.output/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:result[k] for k in ('complete','accepted','namespace','protocol_id')}))

if __name__=='__main__':main()
