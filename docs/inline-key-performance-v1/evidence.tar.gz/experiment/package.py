#!/usr/bin/env python3
"""Retain all completed stage-one samples without duplicate corpus or executables."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

R=Path('/home/dongxu/kv9');S=Path(__file__).resolve().parent
O=R/'docs/inline-key-performance-v1';O.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
analysis=json.loads((S/'analysis.json').read_text());assert analysis['complete'] and not analysis['stage_one_gate_passed']
assert analysis['processes']==52 and len(list((S/'runs').glob('*-terminal.json')))==52
members={};excluded=[]
for p in sorted(S.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=str(p.relative_to(S))
    if p.name=='groups.bin' or p.name.endswith('-progress.json') or p.name.startswith('issue9'):continue
    with p.open('rb') as f:magic=f.read(4)
    if magic==b'\x7fELF':excluded.append(relative);continue
    members['experiment/'+relative]=p
for p in sorted((R/'scripts/inline-key-performance').glob('*')):
    if p.is_file():members['repo/'+str(p.relative_to(R))]=p
members['repo/scripts/build_cache.py']=R/'scripts/build_cache.py'
records=[];archive=O/'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,p in sorted(members.items()):
                assert not p.is_symlink();data=p.read_bytes();info=tar.gettarinfo(str(p),arcname=name)
                info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
                with p.open('rb') as f:tar.addfile(info,f)
                records.append(dict(path=name,bytes=len(data),sha256=sha(data)))
with tarfile.open(archive,'r:gz') as tar:
    assert tar.getnames()==[r['path'] for r in records]
    for r in records:
        data=tar.extractfile(r['path']).read();assert len(data)==r['bytes'] and sha(data)==r['sha256']
manifest=dict(complete=True,members=len(records),expanded_bytes=sum(r['bytes'] for r in records),compressed_bytes=archive.stat().st_size,
              sha256=sha(archive.read_bytes()),all_members_read_back=True,local_root=str(S),processes=52,timing_rows=32,allocation_rows=16,
              stage_one_gate_passed=False,stage_two='not run; stopped by declared write gate',production_promoted=False,
              excluded_binaries=excluded,other_exclusions=['Duplicate groups.bin','Mutable progress/GitHub payloads and Python cache'],
              external=dict(corpus='../outlined-mutation-path-v1/evidence.tar.gz:outlined/groups.bin',corpus_sha256='d978ba9e49131f6277f975ecd333c33854845cc03bd14ee57a22fff915a08350',
                            qualified_sources='../inline-key-qualification-v1/evidence.tar.gz',qualification_sha256='a4ba06b9691df33b25ece57652898f13d79fc281da5090dabdaf3c8f568fc5ab'),
              binaries=json.loads((S/'build-summary.json').read_text())['arms'])
for name,data in [('manifest.json',manifest),('members.json',records)]:
    (O/name).write_text(json.dumps(data,indent=2)+'\n')
for name in ('plan.json','declared-plan.json','analysis.json','allocation-analysis.json','next-entry-buffer-plan.json'):
    shutil.copyfile(S/name,O/name)
(O/'README.md').write_text(f'''# Inline-key write-screen evidence

See the [report](../INLINE-KEY-PERFORMANCE.md). All correctness/accounting checks
pass, but the write gate fails. The declared next read stage is not run.
Production is unchanged.

[evidence.tar.gz](evidence.tar.gz) contains {manifest['members']:,} members,
{manifest['expanded_bytes']:,} expanded bytes and {manifest['compressed_bytes']:,} compressed bytes.
SHA-256: `{manifest['sha256']}`.
Every member size/hash passed readback; [members.json](members.json) and
[manifest.json](manifest.json) record all retained bytes and exclusions.

The packet includes four identified release builds, exact generated harnesses,
source correspondence, all 52 process launch/terminal records and outputs,
32 timing / 16 allocation rows and raw windows, independent input/allocation/
statistics checks, final-index requested-byte observations and both declared
and executable stage-one plans. Timing is separate from allocation counting.
All binaries remain local with exact hashes in their records.

The [qualification packet](../inline-key-qualification-v1/README.md) supplies
the exact original/candidate engine/common sources and prior model/proof evidence.
The original corpus is published as `outlined/groups.bin` in the
[outlined packet](../outlined-mutation-path-v1/README.md). Manifest hashes bind
both external inputs. Restore recorded paths/source base `940d13e`, or adapt a
fresh attempt without relabeling existing results.

The [next entry-buffer plan](next-entry-buffer-plan.json) is prospective, not
implemented or timed. No database/Redis result, new MinIO/recovery/Chaos acceptance
or industrial checklist closure is claimed here. Keep all failed gates intact.
''')
print(json.dumps(manifest))
