# Scoped routed client checkpoint (in progress)

Base HEAD: cfb5561235067789bfc7db7c7f8e635a4c7add0d. Code is not committed yet.

- Distinct LookupRawRoute/RoutedRaw RPCs and stream opcode 5; canonical complete scope and echoed digest; no legacy fallback.
- Persistent bounded discovery/cache/endpoint pool. One absolute deadline/shared 16-attempt maximum. Every learned metadata candidate visited per lookup round; stale hint cycle regression covered.
- Unknown data writes terminal. Read failover and trusted no-effect scope refresh remain bounded. Real runtime preserves one client across each endpoint loss.
- Local workspace-fourth.log: 895 passing tests/doctests, 28 ignored; clippy-third.log passes; routed-tests-third.log 7 current tests pass; formatting clean.
- Routing proof 15 theorems, 11 semantic controls, 2 policy controls; preparation/activation/control/data-range prerequisites checked under updated source pins. Source-contract updates recorded.
- Retained failures: missing Read trait import in runner; old invalid stream opcode fixture; overly short election test backoff plus stale metadata hint cycle; Clippy range-loop fixture style; Lean development failures.
- Qualified stripped debug server/workload are in binaries, exact default-feature/source/qualification manifests retained. Image kv9-routed:d02-20260916-479f8327 loaded in existing Kind. No release/performance claim.
- Agent stream_review owns only scripts/routed-client-chaos.py, scripts/check-routed-client-chaos.py and chaos-dev. Actual runtime launch still pending final handoff.
- Preserve unrelated scripts/checkpoint-publication-chaos.py and scripts/checkpoint-owned-crash.py; exclude from commit/evidence source changes.
- docs/ROUTED-CLIENT.md drafted; update actual Chaos results honestly after execution. No new QPS, split or measured 3/6/9-host scaling. Main goal remains active.
- Next: actual fresh-namespace Chaos run, independent checker, retained failure/success artifacts, exact-owned cleanup, portable packet, English commit/push and #9/#23 readback; zero hosted CI.
