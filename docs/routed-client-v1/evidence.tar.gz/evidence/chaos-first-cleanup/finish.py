#!/usr/bin/env python3
"""Reconcile the failed cleanup using exact container-task absence, without inventing exits."""
import hashlib, importlib.util, json, os, subprocess, time
from pathlib import Path
P=Path('/mnt/data/kv9-work/routed-client-20260916');OUT=P/'chaos-first-cleanup';SOURCE=P/'chaos-first-sources'
NS='kv9-routed-1789592601-587550';UID='3e14ad75-1132-471c-9c39-df6312c98ce0';NODE='kv9-chaos-ci-p0-20260908-control-plane'
K=['/usr/local/bin/kubectl','--kubeconfig','/mnt/data/kv9-work/chaos-tools-20260915-first/kubeconfig','--request-timeout=15s']
def read(p):return json.loads(Path(p).read_text())
def save(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def need(v,msg):
    if not v:raise RuntimeError(msg)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
count=0;started=time.monotonic();samples=[]
def guard():
    need(time.monotonic()-started<300,'deadline')
    for p in [Path('/'),OUT]:need(os.statvfs(p).f_bavail*os.statvfs(p).f_frsize>=8*1024**3,'space floor')
    need(sum(p.stat().st_blocks*512 for p in OUT.rglob('*') if p.is_file())<=512*1024**2,'output cap')
def cmd(argv,timeout=30):
    global count
    guard();count+=1;prefix=OUT/f'finish-command-{count:03d}';start=time.time_ns()
    q=subprocess.run(argv,capture_output=True,timeout=timeout);need(len(q.stdout)<=8*1024**2 and len(q.stderr)<=1024**2,'output limit')
    prefix.with_suffix('.stdout').write_bytes(q.stdout);prefix.with_suffix('.stderr').write_bytes(q.stderr)
    save(prefix.with_suffix('.json'),{'argv':argv,'exit_code':q.returncode,'started_ns':start,'finished_ns':time.time_ns()});need(q.returncode==0,'command failed')
    return q.stdout
def get(*args):return json.loads(cmd(K+['get',*args,'-o','json']))
def faults(d):return sorted([[x['kind'],x['metadata']['namespace'],x['metadata']['name'],x['metadata']['uid']] for x in d['items']])
try:
    authority=read(OUT/'authority.json');protected=read(P/'chaos-first/protected.json');owned=read(P/'chaos-first/owned-resources.json')
    for row in authority['originals']:need(Path(row['path']).stat().st_size==row['bytes'] and sha(row['path'])==row['sha256'],'original failed input changed')
    need(get('namespace',NS)['metadata']['uid']==UID,'namespace UID')
    pods=get('pods','-n',NS);need({x['metadata']['name'] for x in pods['items']}=={'archive-1','archive-2','archive-3'},'unexpected live Pod')
    need({x['metadata']['name']:x['metadata']['uid'] for x in get('pvc','-n',NS)['items']}=={x['metadata']['name']:x['metadata']['uid'] for x in read(OUT/'pvcs-before.json')['items']},'PVC identities')
    cri=json.loads(cmd(['docker','exec',NODE,'crictl','ps','-a','--output','json']));save(OUT/'cri-container-list-before-cleanup.json',cri)
    tasks=cmd(['docker','exec',NODE,'ctr','-n','k8s.io','tasks','list']).decode()
    ids={x['id'] for x in cri['containers']};voter_ids={x.removeprefix('containerd://') for x in owned['server_container_ids']}
    need(not voter_ids.intersection(ids) and all(cid not in tasks for cid in voter_ids),'recorded voter still in CRI/tasks')
    save(OUT/'voter-absence.json',{'complete':True,'container_ids':sorted(voter_ids),'cri_records_absent':True,'containerd_tasks_absent':True,'exit_codes':None,'limitation':'CRI records were already collected after Pod removal; no exit-code claim. Original NotFound receipts are retained.'})
    # Independent full-member readback of the already completed stopped-store archives.
    need(sha(SOURCE/'check-routed-client-chaos.py')==authority['source_pins']['check-routed-client-chaos.py'],'checker pin')
    spec=importlib.util.spec_from_file_location('frozen_checker',SOURCE/'check-routed-client-chaos.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    archives=read(OUT/'archives.json');need(len(archives)==3,'archive population')
    rows=[]
    for r in archives:rows.append({'node':r['node'],'file':r['file'],'pvc_uid':r['pvc_uid'],'sha256':r['sha256'],'archive_bytes':r['bytes'],'decoded_bytes':checker.verify_archive(OUT/r['file'],r),'members':len(r['members'])})
    save(OUT/'archive-readback.json',{'complete':True,'runtime_accepted':False,'archives':rows})
    # Stop archive-only sleep containers while their Pods still exist, retaining actual exit status.
    archive_exits=[]
    for pod in pods['items']:
        cid=pod['status']['containerStatuses'][0]['containerID'].removeprefix('containerd://')
        cmd(['docker','exec',NODE,'crictl','stop','--timeout','2',cid])
        # Raw CRI inspect contains resolved environment: retain only identity/exit fields.
        argv=['docker','exec',NODE,'crictl','inspect',cid];q=subprocess.run(argv,capture_output=True,timeout=20);need(q.returncode==0,'archive inspect')
        status=json.loads(q.stdout)['status'];need(status['state']=='CONTAINER_EXITED','archive container not exited')
        archive_exits.append({'pod':pod['metadata']['name'],'pod_uid':pod['metadata']['uid'],'argv':argv,'command_exit_code':q.returncode,'observed_ns':time.time_ns(),'container':{k:status.get(k) for k in ['id','state','exitCode','startedAt','finishedAt']}})
    save(OUT/'archive-container-exits.json',archive_exits)
    need(get('namespace',NS)['metadata']['uid']==UID,'namespace UID before delete')
    need(faults(get('podchaos,networkchaos,iochaos','-A'))==protected['faults'],'historical fault set changed')
    cmd(K+['delete','namespace',NS,'--wait=true','--timeout=60s'],timeout=65)
    ns=get('namespaces');save(OUT/'namespaces-after.json',ns);current={x['metadata']['name']:x['metadata']['uid'] for x in ns['items']}
    need(current==protected['namespaces'],'historical namespace set changed')
    fs=get('podchaos,networkchaos,iochaos','-A');save(OUT/'faults-after.json',fs);need(faults(fs)==protected['faults'],'historical faults changed')
    final_tasks=cmd(['docker','exec',NODE,'ctr','-n','k8s.io','tasks','list']).decode()
    need(all(cid not in final_tasks for cid in voter_ids|{r['container']['id'] for r in archive_exits}),'owned task survives')
    for row in authority['originals']:need(Path(row['path']).stat().st_size==row['bytes'] and sha(row['path'])==row['sha256'],'original failed input changed')
    save(OUT/'result.json',{'complete':True,'runtime_accepted':False,'original_failure_preserved':True,'namespace':NS,'namespace_uid':UID,'namespace_absent':True,'historical_namespaces_unchanged':True,'historical_faults_unchanged':True,'stopped_store_full_member_readback':True,'archives':rows,'voter_containers_absent':sorted(voter_ids),'voter_exit_codes_unavailable_after_gc':True,'archive_container_exits':archive_exits,'all_owned_containerd_tasks_absent':True})
except BaseException as error:
    save(OUT/'finish-failure.json',{'complete':False,'error':repr(error),'runtime_accepted':False});raise
