#!/usr/bin/env python3
"""Exact failed D02 namespace preservation and cleanup; not runtime acceptance."""
import hashlib, importlib.util, json, os, subprocess, time, traceback
from pathlib import Path
from types import SimpleNamespace
P=Path('/mnt/data/kv9-work/routed-client-20260916')
OLD=P/'chaos-first'; OUT=P/'chaos-first-cleanup'; SOURCE=P/'chaos-first-sources'
NS='kv9-routed-1789592601-587550'; UID='3e14ad75-1132-471c-9c39-df6312c98ce0'
def load(path): return json.loads(Path(path).read_text())
def pin(path):
    p=Path(path); return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
def save(path,value):
    with Path(path).open('x') as f: json.dump(value,f,indent=2,sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
for name,digest in load(SOURCE/'pins.json').items(): need(pin(SOURCE/name)['sha256']==digest,'frozen source changed')
m=module('original_routed_runner',SOURCE/'routed-client-chaos.py')
c=module('original_routed_checker',SOURCE/'check-routed-client-chaos.py')
failure=load(OLD/'failure.json'); owned=load(OLD/'owned-resources.json'); protected=load(OLD/'protected.json'); inputs=load(OLD/'inputs.json')
need(failure['runtime_complete'] is False and failure['namespace']==NS and failure['namespace_uid']==UID,'failure authority')
need(owned['namespace']==NS and owned['namespace_uid']==UID and owned['client_host_pids']==[] and owned['client_host_exits']==[],'unexpected client lifetime')
old_pins=[pin(OLD/n) for n in ['failure.json','owned-resources.json','namespace-created.json','protected.json','inputs.json','command-00089.json','command-00089.stdout','command-00089.stderr']]
save(OUT/'authority.json',{'failed_run':str(OLD),'namespace':NS,'namespace_uid':UID,'originals':old_pins,'source_pins':load(SOURCE/'pins.json'),'runtime_accepted':False,'scope':'Stop, archive, independently read back, and clean the exact failed namespace only.'})
g=m.Gate.__new__(m.Gate)
g.a=SimpleNamespace(kubectl=Path('/usr/local/bin/kubectl'),kubeconfig=Path('/mnt/data/kv9-work/chaos-tools-20260915-first/kubeconfig'),image=inputs['image'])
g.out=OUT;g.started=time.monotonic();g.commands=0;g.clients=[];g.ns=NS;g.uid=UID;g.pods={};g.stores={};g.samples=[];g.snapshots=[]
g.cids=set(owned['server_container_ids']);g.checker=c;g.protected=protected['namespaces'];g.baselines=g.space()
g.kind_node='kv9-chaos-ci-p0-20260908-control-plane'
try:
    g.guard(launch=True)
    ns=g.get('namespace',NS,ns=False);save(OUT/'namespace-before.json',ns)
    need(ns['metadata']['uid']==UID and NS not in protected['namespaces'],'namespace UID')
    before_ns=g.get('namespaces',ns=False);save(OUT/'namespaces-before.json',before_ns)
    nsmap={x['metadata']['name']:x['metadata']['uid'] for x in before_ns['items']}
    need(nsmap==dict(protected['namespaces'],**{NS:UID}),'unexpected namespace set')
    faults=json.loads(g.k(['get','podchaos,networkchaos,iochaos','-A','-o','json']).stdout);save(OUT/'faults-before.json',faults)
    need(json.loads(json.dumps(g.fault_ids(faults)))==protected['faults'],'historical/new fault set differs')
    g.protected_faults=json.dumps(faults).encode()
    pods=g.get('pods');pvcs=g.get('pvc');deployments=g.get('deployments')
    for name,doc in [('pods-before.json',pods),('pvcs-before.json',pvcs),('deployments-before.json',deployments)]:save(OUT/name,doc)
    need(len(pods['items'])==3 and len(pvcs['items'])==3 and len(deployments['items'])==3,'unexpected owned resource population')
    need({x['metadata']['name'] for x in deployments['items']}=={'n1','n2','n3'},'deployment population')
    need({x['metadata']['name'] for x in pvcs['items']}=={'data-1','data-2','data-3'},'PVC population')
    for row in pvcs['items']:
        n=int(row['metadata']['name'].split('-')[-1]);g.stores[n]=row['metadata']['uid']
        need(row['status']['phase']=='Bound','PVC not bound')
        pv=g.get('pv',row['spec']['volumeName'],ns=False);save(OUT/f'pv-{n}-before.json',pv)
        need(pv['spec']['claimRef']['uid']==row['metadata']['uid'] and pv['spec']['claimRef']['namespace']==NS,'PV claim identity')
    observed=set()
    for pod in pods['items']:
        meta=pod['metadata'];name=meta['name'];need(meta['labels'].get('app')=='kv9-routed-voter','unexpected Pod role')
        n=int(meta['labels']['kv9-node']);need(pod['spec']['volumes'][0]['persistentVolumeClaim']['claimName']==f'data-{n}','Pod PVC identity')
        for cs in pod['status']['containerStatuses']: observed.add(cs['containerID'])
        q=g.k(['logs','-n',NS,name,'--all-containers=true','--timestamps=true','--limit-bytes=8388608']);(OUT/f'voter-{n}.log').write_bytes(q.stdout)
        status=g.exec(name,['cat','/data/status']);(OUT/f'voter-{n}-last-status.txt').write_bytes(status.stdout)
    need(observed==g.cids,'recorded voter containers changed')
    save(OUT/'events-before.json',g.get('events'))
    # Original proven method stops voters, waits for no voter Pod, archives all three PVCs,
    # computes complete member inventories, and invokes the independent verifier.
    g.archive()
    after_pods=g.get('pods');save(OUT/'archive-pods.json',after_pods)
    need({x['metadata']['name'] for x in after_pods['items']}=={'archive-1','archive-2','archive-3'},'unexpected archive Pod set')
    after_pvcs=g.get('pvc');save(OUT/'pvcs-after-archive.json',after_pvcs)
    need({x['metadata']['name']:x['metadata']['uid'] for x in after_pvcs['items']}=={x['metadata']['name']:x['metadata']['uid'] for x in pvcs['items']},'PVC identity changed')
    states=[]
    for cid in sorted(g.cids):
        q=subprocess.run(['docker','exec',g.kind_node,'crictl','inspect',cid.removeprefix('containerd://')],capture_output=True,timeout=20)
        need(q.returncode==0,'CRI voter inspect');status=json.loads(q.stdout)['status'];need(status['state']=='CONTAINER_EXITED','voter not stopped')
        states.append({k:status.get(k) for k in ['id','state','exitCode','startedAt','finishedAt']})
    save(OUT/'stopped-voter-containers.json',states)
    # Save explicit separate readback gate before the destructive namespace removal.
    archives=load(OUT/'archives.json')
    save(OUT/'archive-readback.json',{'complete':True,'scope':'Full stopped-store tar/member SHA and EOF readback only; failed runtime remains unaccepted.','archives':[{'file':r['file'],'sha256':r['sha256'],'decoded_bytes':c.verify_archive(OUT/r['file'],r),'members':len(r['members'])} for r in archives]})
    for item in old_pins:need(pin(item['path'])==item,'original failed evidence changed')
    g.cleanup()
    archive_states=[]
    for pod in after_pods['items']:
        for cs in pod['status']['containerStatuses']:
            cid=cs['containerID'].removeprefix('containerd://')
            q=subprocess.run(['docker','exec',g.kind_node,'crictl','inspect',cid],capture_output=True,timeout=20)
            need(q.returncode==0,'CRI archive inspect');status=json.loads(q.stdout)['status'];need(status['state']=='CONTAINER_EXITED','archive container not stopped')
            archive_states.append(dict({k:status.get(k) for k in ['id','state','exitCode','startedAt','finishedAt']},pod_uid=pod['metadata']['uid']))
    save(OUT/'archive-container-exits.json',archive_states)
    save(OUT/'events-after-cleanup.json',{'namespace_absent':True,'original_failure_unchanged':True,'original_run_runtime_accepted':False})
    save(OUT/'result.json',{'complete':True,'runtime_accepted':False,'failure_preserved':True,'namespace':NS,'namespace_uid':UID,'namespace_absent':True,'archives_readback':pin(OUT/'archive-readback.json'),'cleanup':pin(OUT/'cleanup.json'),'original_pins_unchanged':old_pins})
except BaseException as error:
    save(OUT/'failure.json',{'complete':False,'runtime_accepted':False,'error':repr(error),'traceback':traceback.format_exc(),'namespace':NS,'namespace_uid':UID,'resources_may_remain':True})
    raise
finally:
    save(OUT/'resource-samples.json',g.samples)
