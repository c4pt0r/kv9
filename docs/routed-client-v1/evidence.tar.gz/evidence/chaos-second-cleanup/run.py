#!/usr/bin/env python3
"""Preserve and clean exactly the second failed D02 namespace, never acceptance."""
import hashlib,importlib.util,json,os,subprocess,time,traceback
from pathlib import Path
from types import SimpleNamespace
P=Path('/mnt/data/kv9-work/routed-client-20260916');OLD=P/'chaos-second';OUT=P/'chaos-second-cleanup';SOURCE=P/'chaos-second-sources'
NS='kv9-routed-1789593222-5db2fd';UID='d73b2d2a-c74c-4388-801b-03d27c3ab0f6';FAULT_UID='6812bd0c-dc30-44de-8576-aad088efe214'
def read(p):return json.loads(Path(p).read_text())
def pin(p):
    p=Path(p)
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def save(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def need(v,msg):
    if not v:raise RuntimeError(msg)
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
inputs=read(OLD/'inputs.json');owned=read(OLD/'owned-resources.json');failure=read(OLD/'failure.json');protected=read(OLD/'protected.json')
for role,name in [('runner','routed-client-chaos.py'),('checker','check-routed-client-chaos.py')]:need(pin(SOURCE/name)['sha256']==inputs[role]['sha256'],'frozen source hash')
need(failure['runtime_complete'] is False and failure['namespace']==NS and failure['namespace_uid']==UID,'failure authority')
need(owned['namespace']==NS and owned['namespace_uid']==UID and owned['client_host_exits']==[0,0],'client wrappers not exited')
originals=[pin(p) for p in sorted(OLD.rglob('*')) if p.is_file()]
save(OUT/'authority.json',{'runtime_accepted':False,'namespace':NS,'namespace_uid':UID,'fault_uid':FAULT_UID,'originals':originals,'sources':[pin(SOURCE/'routed-client-chaos.py'),pin(SOURCE/'check-routed-client-chaos.py')]})
m=module('second_frozen_runner',SOURCE/'routed-client-chaos.py');c=module('second_frozen_checker',SOURCE/'check-routed-client-chaos.py')
g=m.Gate.__new__(m.Gate);g.a=SimpleNamespace(kubectl=Path('/usr/local/bin/kubectl'),kubeconfig=Path('/mnt/data/kv9-work/chaos-tools-20260915-first/kubeconfig'),image=inputs['image'])
g.out=OUT;g.started=time.monotonic();g.commands=0;g.clients=[];g.ns=NS;g.uid=UID;g.pods={};g.stores={};g.samples=[];g.snapshots=[]
g.cids=set(owned['server_container_ids']);g.host_processes=dict(owned['kind_processes']);g.checker=c;g.protected=protected['namespaces'];g.baselines=g.space();g.kind_node='kv9-chaos-ci-p0-20260908-control-plane'
def capture_container(cid):
    d=g.inspect_container(cid);need(d is not None,'current container missing');ident=g.host_process(d['info']['pid']);need(ident is not None,'current process missing')
    return {'container_id':cid,'process':ident,'status':{k:d['status'].get(k) for k in ['id','state','exitCode','startedAt','finishedAt']}}
try:
    g.guard(launch=True)
    ns=g.get('namespace',NS,ns=False);save(OUT/'namespace-before.json',ns);need(ns['metadata']['uid']==UID,'namespace UID')
    names=g.get('namespaces',ns=False);save(OUT/'namespaces-before.json',names)
    need({x['metadata']['name']:x['metadata']['uid'] for x in names['items']}==dict(protected['namespaces'],**{NS:UID}),'namespace set')
    fs=json.loads(g.k(['get','podchaos,networkchaos,iochaos','-A','-o','json']).stdout);save(OUT/'faults-before.json',fs)
    expected=sorted(protected['faults']+[['PodChaos',NS,'container-kill',FAULT_UID]])
    need(json.loads(json.dumps(g.fault_ids(fs)))==expected,'fault ownership set')
    old_fault=read(OLD/'command-00168.stdout');need(old_fault['metadata']['uid']==FAULT_UID,'original injected fault UID')
    pods=g.get('pods');pvcs=g.get('pvc');deploy=g.get('deployments')
    for name,doc in [('pods-before.json',pods),('pvcs-before.json',pvcs),('deployments-before.json',deploy)]:save(OUT/name,doc)
    need(len(pods['items'])==5 and len(pvcs['items'])==3 and {x['metadata']['name'] for x in deploy['items']}=={'n1','n2','n3'},'resource population')
    for row in pvcs['items']:
        n=int(row['metadata']['name'].split('-')[-1]);need(n in (1,2,3),'PVC name');g.stores[n]=row['metadata']['uid']
        pv=g.get('pv',row['spec']['volumeName'],ns=False);save(OUT/f'pv-{n}-before.json',pv);need(pv['spec']['claimRef']['uid']==row['metadata']['uid'] and pv['spec']['claimRef']['namespace']==NS,'PV identity')
    current=[];client_pods=[]
    for pod in pods['items']:
        name=pod['metadata']['name'];app=pod['metadata']['labels'].get('app');need(app in ('kv9-routed-voter','kv9-routed-client'),'unexpected Pod role')
        q=g.k(['logs','-n',NS,name,'--all-containers=true','--timestamps=true','--limit-bytes=8388608']);(OUT/f'{name}.log').write_bytes(q.stdout)
        for cs in pod['status']['containerStatuses']:
            row=capture_container(cs['containerID']);row.update(pod=name,pod_uid=pod['metadata']['uid']);current.append(row)
            if app=='kv9-routed-voter':g.cids.add(cs['containerID']);g.host_processes[cs['containerID']]=row['process']
        if app=='kv9-routed-client':
            old=read(OLD/name/'exit.json');need(old['exit_code']==0 and old['remote_absent'] is True,'original client exit')
            need(not g.remote_same(name,old['remote_identity']),'workload remote process still present');client_pods.append(name)
        else:
            q=g.exec(name,['cat','/data/status']);(OUT/f'{name}-last-status.txt').write_bytes(q.stdout)
    save(OUT/'current-container-identities.json',current)
    save(OUT/'known-original-process-observations.json',[{'container_id':cid,'original':p,'current':g.host_process(p['pid'])} for cid,p in owned['kind_processes'].items()])
    save(OUT/'events-before.json',g.get('events'))
    fault=g.get('podchaos','container-kill');save(OUT/'owned-fault-before-delete.json',fault);need(fault['metadata']['uid']==FAULT_UID,'fault UID before delete')
    g.k(['delete','podchaos','container-kill','-n',NS,'--wait=true','--timeout=30s'],timeout=35)
    healed=json.loads(g.k(['get','podchaos,networkchaos,iochaos','-A','-o','json']).stdout);save(OUT/'faults-after-owned-delete.json',healed)
    need(json.loads(json.dumps(g.fault_ids(healed)))==protected['faults'],'fault cleanup changed historical set');g.protected_faults=json.dumps(healed).encode()
    g.archive()
    archives=read(OUT/'archives.json')
    save(OUT/'archive-readback.json',{'complete':True,'runtime_accepted':False,'archives':[{'node':r['node'],'file':r['file'],'sha256':r['sha256'],'archive_bytes':r['bytes'],'decoded_bytes':c.verify_archive(OUT/r['file'],r),'members':len(r['members'])} for r in archives]})
    after=g.get('pods');save(OUT/'pods-after-archive.json',after)
    need({x['metadata']['name'] for x in after['items']}==set(client_pods)|{'archive-1','archive-2','archive-3'},'post archive Pod population')
    need({x['metadata']['name']:x['metadata']['uid'] for x in g.get('pvc')['items']}=={x['metadata']['name']:x['metadata']['uid'] for x in pvcs['items']},'PVC identities changed')
    helper_exits=[]
    for pod in after['items']:
        for cs in pod['status']['containerStatuses']:
            cid=cs['containerID'];row=capture_container(cid)
            g.command(['docker','exec',g.kind_node,'crictl','stop','--timeout','2',cid.removeprefix('containerd://')])
            d=g.inspect_container(cid);need(d is not None and d['status']['state']=='CONTAINER_EXITED','helper exit not observed')
            need(g.host_process(row['process']['pid'])!=row['process'],'helper process remains')
            helper_exits.append(dict(pod=pod['metadata']['name'],pod_uid=pod['metadata']['uid'],process=row['process'],status={k:d['status'].get(k) for k in ['id','state','exitCode','startedAt','finishedAt']}))
    save(OUT/'helper-exits.json',helper_exits)
    for r in originals:need(pin(r['path'])==r,'original evidence changed')
    g.cleanup()
    tasks=set(g.command(['docker','exec',g.kind_node,'ctr','-n','k8s.io','tasks','list','-q']).stdout.decode().split())
    need(all(r['status']['id'] not in tasks for r in helper_exits),'helper container task remains')
    save(OUT/'result.json',{'complete':True,'runtime_accepted':False,'original_failure_preserved':True,'namespace':NS,'namespace_uid':UID,'namespace_absent':True,'original_fault_uid':FAULT_UID,'owned_fault_absent':True,'historical_resources_unchanged':True,'all_known_voter_processes_absent':True,'all_helper_processes_absent':True,'archive_readback':pin(OUT/'archive-readback.json'),'cleanup':pin(OUT/'cleanup.json'),'helper_exits':pin(OUT/'helper-exits.json')})
except BaseException as error:
    save(OUT/'failure.json',{'complete':False,'runtime_accepted':False,'error':repr(error),'traceback':traceback.format_exc(),'resources_may_remain':True});raise
finally:save(OUT/'resource-samples.json',g.samples)
