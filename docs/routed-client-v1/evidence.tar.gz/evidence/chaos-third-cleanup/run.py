#!/usr/bin/env python3
"""Verify retained stopped stores and close exact third-run resources; preserve wrapper failure."""
import hashlib,importlib.util,json,os,time,traceback
from pathlib import Path
from types import SimpleNamespace
P=Path('/mnt/data/kv9-work/routed-client-20260916');OLD=P/'chaos-third';OUT=P/'chaos-third-cleanup';SOURCE=P/'chaos-third-sources'
NS='kv9-routed-1789593566-371c55';UID='414adfb1-c125-4119-8345-3a6795880d9e'
def read(p):return json.loads(Path(p).read_text())
def pin(p):
    p=Path(p)
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def save(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def need(v,msg):
    if not v:raise RuntimeError(msg)
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
inputs=read(OLD/'inputs.json');owned=read(OLD/'owned-resources.json');failure=read(OLD/'failure.json');protected=read(OLD/'protected.json')
for role,name in [('runner','routed-client-chaos.py'),('checker','check-routed-client-chaos.py')]:need(pin(SOURCE/name)['sha256']==inputs[role]['sha256'],'frozen source hash')
need(failure['failure']=="ValueError('client root/tenant/budget/seed scope')" and failure['namespace']==NS and failure['namespace_uid']==UID,'failure authority')
need(owned['namespace']==NS and owned['namespace_uid']==UID and owned['client_host_exits']==[0,0],'client wrapper exits')
originals=[pin(p) for p in sorted(OLD.rglob('*')) if p.is_file()]
save(OUT/'authority.json',{'original_wrapper_exit_preserved':1,'namespace':NS,'namespace_uid':UID,'originals':originals,'sources':[pin(SOURCE/'routed-client-chaos.py'),pin(SOURCE/'check-routed-client-chaos.py')]})
m=module('third_frozen_runner',SOURCE/'routed-client-chaos.py');c=module('third_frozen_checker',SOURCE/'check-routed-client-chaos.py')
g=m.Gate.__new__(m.Gate);g.a=SimpleNamespace(kubectl=Path('/usr/local/bin/kubectl'),kubeconfig=Path('/mnt/data/kv9-work/chaos-tools-20260915-first/kubeconfig'),image=inputs['image'])
g.out=OUT;g.started=time.monotonic();g.commands=0;g.clients=[];g.ns=NS;g.uid=UID;g.pods={};g.stores={};g.samples=[];g.snapshots=[]
g.cids=set(owned['server_container_ids']);g.host_processes=dict(owned['kind_processes']);g.checker=c;g.protected=protected['namespaces'];g.baselines=g.space();g.kind_node='kv9-chaos-ci-p0-20260908-control-plane'
try:
    g.guard(launch=True)
    ns=g.get('namespace',NS,ns=False);save(OUT/'namespace-before.json',ns);need(ns['metadata']['uid']==UID,'namespace UID')
    names=g.get('namespaces',ns=False);save(OUT/'namespaces-before.json',names)
    need({x['metadata']['name']:x['metadata']['uid'] for x in names['items']}==dict(protected['namespaces'],**{NS:UID}),'namespace set')
    fs=json.loads(g.k(['get','podchaos,networkchaos,iochaos','-A','-o','json']).stdout);save(OUT/'faults-before.json',fs)
    need(json.loads(json.dumps(g.fault_ids(fs)))==protected['faults'],'owned fault remains or historical set changed');g.protected_faults=json.dumps(fs).encode()
    pods=g.get('pods');pvcs=g.get('pvc');deploy=g.get('deployments')
    for name,doc in [('pods-before.json',pods),('pvcs-before.json',pvcs),('deployments-before.json',deploy)]:save(OUT/name,doc)
    need({p['metadata']['name'] for p in pods['items']}=={'client-0','client-1','archive-1','archive-2','archive-3'},'unexpected Pod population')
    need(len(deploy['items'])==3 and all(x['spec']['replicas']==0 for x in deploy['items']),'voters not stopped')
    expected_pvcs={f"data-{r['node']}":r['pvc_uid'] for r in read(OLD/'archives.json')}
    need({r['metadata']['name']:r['metadata']['uid'] for r in pvcs['items']}==expected_pvcs,'archived PVC identities')
    observations=[]
    for cid,p in g.host_processes.items():
        current=g.host_process(p['pid']);need(current!=p,'known voter still alive');observations.append({'container_id':cid,'original':p,'current':current,'original_absent':True})
    save(OUT/'voter-process-absence-before-cleanup.json',observations)
    for i in (0,1):
        name=f'client-{i}';old=read(OLD/name/'exit.json');need(old['exit_code']==0 and old['remote_absent'] is True,'original client exit')
        need(not g.remote_same(name,old['remote_identity']),'workload process remains')
    archives=read(OLD/'archives.json');need(len(archives)==3 and {r['node'] for r in archives}=={1,2,3},'archive population')
    rows=[]
    for r in archives:
        need(r['child_exit_code']==0,'archive producer exit')
        rows.append({'node':r['node'],'original_file':str(OLD/r['file']),'sha256':r['sha256'],'archive_bytes':r['bytes'],'decoded_bytes':c.verify_archive(OLD/r['file'],r),'members':len(r['members'])})
    save(OUT/'archive-readback.json',{'complete':True,'scope':'Existing stopped-store archives only; original wrapper exit 1 unchanged.','archives':rows})
    helpers=[]
    for pod in pods['items']:
        for cs in pod['status']['containerStatuses']:
            cid=cs['containerID'];inspection=g.inspect_container(cid);need(inspection is not None,'helper CRI status missing')
            if inspection['status']['state']=='CONTAINER_RUNNING':
                ident=g.host_process(inspection['info']['pid']);need(ident is not None,'helper process missing')
                g.command(['docker','exec',g.kind_node,'crictl','stop','--timeout','2',cid.removeprefix('containerd://')])
                inspection=g.inspect_container(cid);need(g.host_process(ident['pid'])!=ident,'helper still alive')
            else:ident=None
            need(inspection is not None and inspection['status']['state']=='CONTAINER_EXITED','helper exit not observed')
            helpers.append({'pod':pod['metadata']['name'],'pod_uid':pod['metadata']['uid'],'process':ident,'status':{k:inspection['status'].get(k) for k in ['id','state','exitCode','startedAt','finishedAt']}})
    save(OUT/'helper-exits.json',helpers)
    for r in originals:need(pin(r['path'])==r,'original evidence changed')
    g.cleanup()
    tasks=set(g.command(['docker','exec',g.kind_node,'ctr','-n','k8s.io','tasks','list','-q']).stdout.decode().split())
    need(all(r['status']['id'] not in tasks for r in helpers),'helper task remains')
    save(OUT/'result.json',{'complete':True,'scope':'Cleanup and archive preservation, not a new runtime gate receipt.','original_wrapper_exit_preserved':1,'original_failure_preserved':True,'namespace':NS,'namespace_uid':UID,'namespace_absent':True,'all_four_owned_faults_already_absent':True,'historical_resources_unchanged':True,'all_known_voter_processes_absent':True,'all_helper_processes_absent':True,'archive_readback':pin(OUT/'archive-readback.json'),'cleanup':pin(OUT/'cleanup.json'),'helper_exits':pin(OUT/'helper-exits.json')})
except BaseException as error:
    save(OUT/'failure.json',{'complete':False,'error':repr(error),'traceback':traceback.format_exc(),'resources_may_remain':True});raise
finally:save(OUT/'resource-samples.json',g.samples)
