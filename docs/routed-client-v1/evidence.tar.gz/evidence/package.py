import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/dongxu/kv9'); work=Path('/mnt/data/kv9-work/routed-client-20260916'); out=root/'docs/routed-client-v1'
assert json.loads((work/'chaos-fourth-wrapper.json').read_text())['exit_code']==0
assert json.loads((work/'chaos-fourth-independent.json').read_text())['complete']
out.mkdir(exist_ok=False)
files={}
for p in work.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 r=p.relative_to(work)
 if r.parts[0]=='binaries' and p.name in ('kv9','kv9-routed-workload'):continue
 if '__pycache__' in r.parts or p.suffix in ('.olean','.ilean','.pyc'):continue
 if p.name in ('issue9-before.json','issue23-before.json'):continue
 files['evidence/'+str(r)]=p
names=set()
for model in ['routed-client','data-range','group-preparation','group-activation','group-control']:
 c=root/'proofs/lean'/model/'source-contract.json';names.add(str(c.relative_to(root)));names.update(json.loads(c.read_text())['source_sha256'])
names.update(['scripts/routed-client-chaos.py','scripts/check-routed-client-chaos.py','docs/ROUTED-CLIENT.md','docs/HORIZONTAL-SCALING-PLAN.md','Cargo.toml','Cargo.lock'])
for command in [['git','diff','--name-only'],['git','ls-files','--others','--exclude-standard']]:
 for name in subprocess.check_output(command,cwd=root).decode().splitlines():
  if name not in ('scripts/checkpoint-publication-chaos.py','scripts/checkpoint-owned-crash.py') and not name.startswith('docs/routed-client-v1/'):
   names.add(name)
for name in names:files['source/'+name]=root/name
members=[];total=0
with (out/'evidence.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,p in sorted(files.items()):
  data=p.read_bytes();total+=len(data);assert total<=128*1024**2
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  members.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 actual=[]
 for m in tar:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  d=tar.extractfile(m).read();actual.append({'name':m.name,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
assert actual==members
artifact=out/'evidence.tar.gz'
summary={'schema':1,'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'archive_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'archive_bytes':artifact.stat().st_size,'decoded_bytes':total,'members':members,'accepted':{'workspace':'evidence/workspace-fourth.log','clippy':'evidence/clippy-third.log','current_routing_tests':'evidence/routed-tests-third.log','routing_proof':'evidence/routed-client-proof-current/result.json','actual_chaos':'evidence/chaos-fourth-wrapper.json','independent_chaos_reader':'evidence/chaos-fourth-independent.json','offline_reader_controls':'evidence/chaos-dev/final-controls.json'},'not_claimed':['complete D02','general concurrent linearizability','all-voter Chaos matrix','batch/IO fault coverage','verified Rust extraction','split or migration','new throughput','independent-host scaling','hosted CI']}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k] for k in ['archive_sha256','archive_bytes','decoded_bytes']}));print('members',len(members))
