"""Focused offline CLI and minority-observation controls."""
import copy,importlib.util,unittest
from pathlib import Path

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=module('h','/home/dongxu/kv9/scripts/routed-client-chaos.py')
t=module('t','/mnt/data/kv9-work/routed-client-20260916/chaos-dev/test_checker_second.py');c=t.c
class FixtureControls(unittest.TestCase):
 def test_one_line_prepare(self):
  self.assertEqual(h.cli_fields('store_prepared=true node_id=2 store_incarnation='+'ab'*16+'\n'),{'store_prepared':'true','node_id':'2','store_incarnation':'ab'*16})
 def test_multiline_group_receipt(self):
  self.assertEqual(h.cli_fields('region_id=7\ntask_id=4\nreadiness=not_asserted\n')['region_id'],'7')
 def test_status_json_keeps_spaces(self):
  self.assertEqual(h.fields('pid=4\ndata_groups=[{"region": 7, "state": "active"}]\n')['data_groups'],'[{"region": 7, "state": "active"}]')
 def test_duplicate_cli_refused(self):
  with self.assertRaisesRegex(RuntimeError,'duplicate'):h.cli_fields('node_id=1 node_id=2')
 def minority(self):
  f=t.fault();f['phase']='leader-partition';f['fault']['spec']['selector']['pods']={'owned':['minority']}
  f['minority_control']={'node':1,'region':7,'retried':False,'exit_code':1,'stdout':'','stderr':'not_leader=true leader_node_id=unknown\ncommand terminated with exit code 1\n',
   'started_ns':8,'finished_ns':9,'before':{'node':1,'groups':[{'region':7,'role':'Follower'}]}}
  return f
 def test_minority_exclusive_refusal(self):self.assertTrue(c.fault_check(self.minority(),'owned','nsuid'))
 def test_minority_candidate_refusal(self):
  f=self.minority();f['minority_control']['before']['groups'][0]['role']='Candidate'
  self.assertTrue(c.fault_check(f,'owned','nsuid'))
 def test_minority_leader_is_not_nonleader(self):
  f=self.minority();f['minority_control']['before']['groups'][0]['role']='Leader'
  with self.assertRaisesRegex(ValueError,'wrong group/process'):c.fault_check(f,'owned','nsuid')
 def test_minority_unknown_is_not_refusal(self):
  f=self.minority();f['minority_control']['stderr']='deadline exceeded; outcome unknown\n'
  with self.assertRaisesRegex(ValueError,'exclusive'):c.fault_check(f,'owned','nsuid')
 def test_minority_ack_rejected(self):
  f=self.minority();f['minority_control']['exit_code']=0;f['minority_control']['stdout']='applied_index=7\n'
  with self.assertRaisesRegex(ValueError,'exclusive'):c.fault_check(f,'owned','nsuid')
if __name__=='__main__':unittest.main(verbosity=2)
