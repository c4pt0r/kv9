"""Synthetic-only controls. No Kubernetes, codec, server or workload is invoked."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

SOURCE = Path('/home/dongxu/kv9/scripts/check-routed-client-chaos.py')
spec = importlib.util.spec_from_file_location('checker', SOURCE)
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)


def attempt(n=1, failure=None, phase='data'):
    return {'ordinal': n, 'phase': phase, 'node_id': 1, 'elapsed_ns': 1, 'failure': failure,
            'route': None if phase == 'lookup' else {'region_id': 7, 'epoch_conf_ver': 1, 'epoch_version': 1, 'binding_digest': [7]*32}}


def row(kind='put'):
    op = {'kind': kind, 'key': [1]}
    if kind == 'put': op['value'] = [9]
    value = {'kind': 'applied', 'term': 1, 'index': 5} if kind == 'put' else {'kind': 'get', 'value': [9]}
    return {'kind': 'operation', 'id': 1, 'operation': op, 'invoked_unix_ns': 10, 'finished_unix_ns': 20,
            'report': {'operation': kind, 'elapsed_ns': 10, 'attempts': [attempt()], 'stop': 'terminal', 'outcome': {'kind': 'success', 'value': value}}}


def fault():
    selector = {'namespaces': ['owned'], 'pods': {'owned': ['client-1']}}
    document = {'kind': 'NetworkChaos', 'metadata': {'namespace': 'owned', 'uid': 'fault'},
        'spec': {'action': 'partition', 'direction': 'both', 'selector': selector, 'target': {'selector': {'namespaces': ['owned']}}},
        'status': {'conditions': [{'type': 'AllInjected', 'status': 'True'}]}}
    return {'phase': 'discovery-seed-partition', 'fault': document, 'fault_after_progress': copy.deepcopy(document),
            'namespace_uid': 'nsuid', 'injected_observed_ns': 5, 'progress_finished_ns': 30,
            'seed': 1, 'data_leader_before': 2, 'metadata_leader_before': 3, 'effect': {'blocked': [{'exit_code': 124, 'to': 1}],
            'connected': [{'from': str(a), 'to': b, 'exit_code': 0} for a in (1,2,3) for b in (1,2,3) if a != b]}}


class Controls(unittest.TestCase):
    def test_success_exact_scope(self): self.assertEqual(c.report_check(row(), 7), 'success')
    def test_lookup_success_then_data(self):
        r = row(); r['report']['attempts'] = [attempt(1, phase='lookup'), attempt(2)]; c.report_check(r, 7)
    def test_scope_refusal_can_retry_write(self):
        r = row(); r['report']['attempts'] = [attempt(1, {'kind': 'scope_refused'}), attempt(2)]; c.report_check(r, 7)
    def test_read_failure_can_retry(self):
        r = row('get'); r['report']['attempts'] = [attempt(1, {'kind': 'rpc', 'reason': {'kind': 'deadline'}}), attempt(2)]; c.report_check(r, 7)
    def test_uncertain_write_cannot_retry(self):
        r = row(); r['report']['attempts'] = [attempt(1, {'kind': 'rpc', 'reason': {'kind': 'deadline'}}), attempt(2)]
        with self.assertRaisesRegex(ValueError, 'uncertain'): c.report_check(r, 7)
    def test_unknown_write_is_retained(self):
        r = row(); r['report']['attempts'][0]['failure'] = {'kind': 'rpc', 'reason': {'kind': 'deadline'}}
        r['report']['outcome'] = {'kind': 'unknown_write', 'failure': r['report']['attempts'][0]['failure']}
        self.assertEqual(c.report_check(r, 7), 'unknown_write')
    def test_wrong_route_refused(self):
        with self.assertRaisesRegex(ValueError, 'route identity'): c.report_check(row(), 8)
    def test_missing_route_refused(self):
        r = row(); r['report']['attempts'][0]['route'] = None
        with self.assertRaisesRegex(ValueError, 'exact data route'): c.report_check(r, 7)
    def test_bool_integer_and_reset(self):
        for field in ('ordinal', 'node_id'):
            r = row(); r['report']['attempts'][0][field] = True
            with self.assertRaises(ValueError): c.report_check(r, 7)
        r = row(); r['finished_unix_ns'] = 9
        with self.assertRaisesRegex(ValueError, 'clock'): c.report_check(r, 7)
    def test_complete_sequential_history(self):
        put = row(); get = row('get'); get.update(id=2, invoked_unix_ns=21, finished_unix_ns=30)
        commands = [{'id': x['id'], 'operation': x['operation'], 'phase': 'baseline'} for x in [put,get]]
        h = c.history_check(commands, [{'kind': 'start', 'pid': 99, 'config': {}}]+[put,get], {}, 7)
        self.assertEqual(h['calls'], 2)
        get['report']['outcome']['value']['value'] = [8]
        with self.assertRaisesRegex(ValueError, 'sequential history'): c.history_check(commands, [{'kind': 'start', 'pid': 99, 'config': {}}]+[put,get], {}, 7)
    def test_missing_return_refused(self):
        r = row(); command = {'id': 1, 'operation': r['operation'], 'phase': 'baseline'}
        with self.assertRaisesRegex(ValueError, 'incomplete'): c.history_check([command], [{'kind': 'start', 'pid': 99, 'config': {}}], {}, 7)
    def test_reused_unknown_mutation_key_refused(self):
        first = row(); first['report']['attempts'][0]['failure'] = {'kind': 'rpc', 'reason': {'kind': 'deadline'}}
        first['report']['outcome'] = {'kind': 'unknown_write'}
        second = row(); second.update(id=2, invoked_unix_ns=21, finished_unix_ns=30)
        commands = [{'id': x['id'], 'operation': x['operation'], 'phase': 'baseline'} for x in [first,second]]
        with self.assertRaisesRegex(ValueError, 'key reused'): c.history_check(commands, [{'kind': 'start', 'pid': 99, 'config': {}}]+[first,second], {}, 7)
    def test_seed_fault_valid(self): self.assertTrue(c.fault_check(fault(), 'owned', 'nsuid'))
    def test_fault_wrong_namespace_and_uid(self):
        for ns, uid in [('other','nsuid'), ('owned','other')]:
            with self.assertRaises(ValueError): c.fault_check(fault(), ns, uid)
    def test_missing_injection_or_effect(self):
        f = fault(); f['fault']['status']['conditions'][0]['status'] = 'False'
        with self.assertRaisesRegex(ValueError, 'injection'): c.fault_check(f, 'owned', 'nsuid')
        f = fault(); f['effect']['blocked'][0]['exit_code'] = 0
        with self.assertRaisesRegex(ValueError, 'effect'): c.fault_check(f, 'owned', 'nsuid')
    def test_fault_healed_before_progress_refused(self):
        f = fault(); f['fault_after_progress']['metadata']['deletionTimestamp'] = 'now'
        with self.assertRaisesRegex(ValueError, 'remain installed'): c.fault_check(f, 'owned', 'nsuid')
    def test_batch_history_requires_a_different_checker(self):
        r = row(); r['operation'] = {'kind': 'batch_put', 'pairs': [[[1],[9]],[[2],[8]]]}
        r['report']['operation'] = 'batch_put'
        command = {'id': 1, 'operation': r['operation'], 'phase': 'baseline'}
        with self.assertRaisesRegex(ValueError, 'single-key'): c.history_check([command], [{'kind': 'start', 'pid': 99, 'config': {}}]+[r], {}, 7)
    def test_seed_must_not_be_metadata_leader(self):
        f = fault(); f['metadata_leader_before'] = 1
        with self.assertRaisesRegex(ValueError, 'seed isolation scope'): c.fault_check(f, 'owned', 'nsuid')
    def test_seed_must_not_be_data_leader(self):
        f = fault(); f['data_leader_before'] = 1
        with self.assertRaisesRegex(ValueError, 'isolation scope'): c.fault_check(f, 'owned', 'nsuid')


if __name__ == '__main__': unittest.main(verbosity=2)
