"""Tiny synthetic archive refusal checks, no runtime data."""
import importlib.util,io,tarfile,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('c','/home/dongxu/kv9/scripts/check-routed-client-chaos.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
class ArchiveControls(unittest.TestCase):
 def test_exact_and_corrupt_archive(self):
  with tempfile.TemporaryDirectory(dir='/mnt/data/kv9-work/routed-client-20260916/chaos-dev') as d:
   p=Path(d)/'tiny.tar'
   with tarfile.open(p,'w') as t:
    m=tarfile.TarInfo('wal');m.size=3;t.addfile(m,io.BytesIO(b'abc'))
   expected=c.pin(p);expected['members']={'wal':{'bytes':3,'sha256':__import__('hashlib').sha256(b'abc').hexdigest()}}
   self.assertEqual(c.verify_archive(p,expected),3)
   b=bytearray(p.read_bytes());b[512]^=1;p.write_bytes(b)
   with self.assertRaisesRegex(ValueError,'hash/size'):c.verify_archive(p,expected)
 def test_trailing_bytes_refused_even_with_updated_container_hash(self):
  with tempfile.TemporaryDirectory(dir='/mnt/data/kv9-work/routed-client-20260916/chaos-dev') as d:
   p=Path(d)/'tiny.tar'
   with tarfile.open(p,'w') as t:
    m=tarfile.TarInfo('wal');m.size=0;t.addfile(m,io.BytesIO())
   p.write_bytes(p.read_bytes()+b'garbage');e=c.pin(p);e['members']={'wal':{'bytes':0,'sha256':__import__('hashlib').sha256(b'').hexdigest()}}
   with self.assertRaisesRegex(ValueError,'EOF'):c.verify_archive(p,e)
if __name__=='__main__':unittest.main(verbosity=2)
