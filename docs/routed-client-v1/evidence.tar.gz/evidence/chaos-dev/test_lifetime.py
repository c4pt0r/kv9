import copy, importlib.util, unittest
s=importlib.util.spec_from_file_location('c','/home/dongxu/kv9/scripts/check-routed-client-chaos.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
def fixture():
 p={'pid':100,'start_ticks':55,'boot_id':'boot'}
 return [{'id':'a','state':'GARBAGE_COLLECTED','exitCode':None,'cri_absent':True,'task_absent':True,'process_absent':True,'process':p}],{'server_container_ids':['containerd://a'],'kind_processes':{'containerd://a':p}}
class Lifetime(unittest.TestCase):
 def test_gc_is_explicit(self): c.lifetime_check(*fixture())
 def test_observed_exit(self):
  s,o=fixture();s[0].update(state='CONTAINER_EXITED',exitCode=0);c.lifetime_check(s,o)
 def test_gc_cannot_invent_exit(self):
  s,o=fixture();s[0]['exitCode']=0
  with self.assertRaisesRegex(ValueError,'GC'):c.lifetime_check(s,o)
 def test_live_process(self):
  s,o=fixture();s[0]['process_absent']=False
  with self.assertRaisesRegex(ValueError,'process absence'):c.lifetime_check(s,o)
 def test_remaining_task(self):
  s,o=fixture();s[0]['task_absent']=False
  with self.assertRaisesRegex(ValueError,'GC'):c.lifetime_check(s,o)
 def test_duplicate_container(self):
  s,o=fixture();s.append(copy.deepcopy(s[0]))
  with self.assertRaisesRegex(ValueError,'inventory'):c.lifetime_check(s,o)
if __name__=='__main__':unittest.main(verbosity=2)
