import importlib.util,types,unittest
s=importlib.util.spec_from_file_location('h','/home/dongxu/kv9/scripts/routed-client-chaos.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
class Status(unittest.TestCase):
 def test_interrupted_status_probe_is_not_an_observation(self):
  for code in (1,126,137):
   g=h.Gate.__new__(h.Gate);g.stale_status=[];g.pod_for=lambda node:{'metadata':{'name':'owned'}}
   g.exec=lambda *a,**kw:types.SimpleNamespace(returncode=code,stdout=b'partial')
   self.assertIsNone(g.status(1))
 def test_persisted_previous_owner_cannot_be_accepted(self):
  g=h.Gate.__new__(h.Gate);g.stale_status=[]
  g.pod_for=lambda node:{'metadata':{'name':'owned'}}
  fields=['S']+['0']*18+['200']
  rows=iter([b'pid=1\nendpoint_ready=true\nprocess_start_ticks=100\nprocess_boot_id=boot\n',('1 (kv9) '+' '.join(fields)+'\nboot\n').encode()])
  g.exec=lambda *a,**kw:types.SimpleNamespace(returncode=0,stdout=next(rows))
  self.assertIsNone(g.status(1));self.assertEqual(g.stale_status[0]['live']['start_ticks'],200)
  self.assertEqual(g.stale_status[0]['recorded_start_ticks'],'100')
if __name__=='__main__':unittest.main(verbosity=2)
