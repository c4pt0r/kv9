# Matched write-diagnostics release pair

Exact clean detached source: 9317e63a4b866aad4acf05d569f15e39ded58368 at /tmp/kv9-write-diagnostics-release-source-20260915-first.

Both builds completed under one existing BuildCache lock/invalidation transaction, using the shared /home/dongxu/kv9/target, four jobs, offline Rust/Cargo1.94.0 and default release ThinLTO/codegen1/opt3. Each binary was copied and hash-verified before the next build. Default root/Raft/server features are []; the instrumented graph enables only write-path-diagnostics on those packages. The standard build.json/kv9-cargo.jsonl and all source, compiler, cache and command evidence remain beside the binaries.

Successful build tool83432/e70fbd/0; independent exact source, metadata, binary and observed-process-lifetime readback a648fa/0. The original 28,413,685,760-byte baseline precedes the detached source and both attempts; minimum sampled available was28,109,729,792 bytes. The unchanged 8GiB floor/16GiB maximum decrease/8MiB launch allowance and per-Cargo1200-second bounds were retained. Nine build lifetimes were observed in5-second process samples and are absent; short-lived children need not appear in those samples. Final owned process group was empty.

First attempt66726/53be9f/1 is preserved under the first root/default paths. Cargo compilation exited0, but -vv mixed three build-script lines into the JSON stdout and the original BuildCache reader correctly refused it. The unqualified default ELF and full first logs remain; the fresh second attempt uses single -v. No source, acceptance predicate or historical artifact was changed to bypass that failure.

No server, performance workload, ordinary recovery or Chaos fixture was executed. Root owns subsequent diagnostic harness execution.
