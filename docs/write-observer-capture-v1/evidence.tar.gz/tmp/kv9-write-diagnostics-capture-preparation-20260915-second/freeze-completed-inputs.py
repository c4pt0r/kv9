"""Freeze only the terminal diagnostic metadata for the existing offline checker."""
import hashlib,json,os
from pathlib import Path
import continuation as c
HERE=Path(__file__).resolve().parent
OUT=Path('/tmp/kv9-write-diagnostics-capture-20260915-second')
def pin(p):
    p=Path(p)
    return {'bytes':p.stat().st_size,'sha256':c.digest(p)}
def save(name,d):
    with (HERE/name).open('x') as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
summary=c.read(OUT/'summary.json'); matrix=c.read(OUT/'cohorts/matrix.json')
c.require(summary['complete'] is True and summary['restoration_complete'] is True and summary['child_exit_code']==0 and not summary['child_cleanup_errors'] and not summary['deferred_cleanup_signals'],'outer capture/restoration not accepted')
before=c.read(OUT/'before.json');after=c.read(OUT/'after.json')
c.require(not after['errors'] and before['containers']==after['containers'] and before['clusters']==after['clusters'],'owned isolation restoration differs')
c.require(matrix['complete'] is True and len(matrix['rows'])==len(matrix['attempts'])==16 and matrix['available_before']==28108746752,'full capture scope/baseline differs')
files={};rows=[];lifetimes=[];health=[];retained_bytes=0
for descriptor,attempt in zip(matrix['rows'],matrix['attempts']):
    ordinal=descriptor['ordinal'];d=Path(attempt['directory'])
    c.require(ordinal==attempt['ordinal']==len(rows) and c.read(d/'result.json')==attempt['result'],'row/result identity differs')
    actual=c.health(attempt['result'],c.read(d/'run/report.json'))
    c.require(actual==attempt['health'],'health receipt differs')
    rows.append(dict(ordinal=ordinal,mode=descriptor['mode'],api='Put' if descriptor['shared']['batch_size']==1 else 'BatchPut64',concurrency=descriptor['shared']['workers'],repeat=descriptor['repeat'],directory=str(d)))
    health.append(dict(ordinal=ordinal,**actual))
    cleanup=c.read(d/'cleanup.json');c.require(cleanup['complete'] and len(cleanup['children'])==4,'cleanup scope differs')
    for child in cleanup['children']:
        c.require(child['absent'] and child['exit_code'] is not None and c.gone(child['identity']),'owned lifetime remains')
        ident=child['identity'];lifetimes.append(dict(ordinal=ordinal,pid=ident['pid'],start_ticks=ident['start_ticks'],boot_id=ident['boot_id'],exit_code=child['exit_code'],same_lifetime_currently_absent=True))
    retained_bytes+=c.read(d/'fixture/diagnostic-retention-budget.json')['bytes']
    for name in ['before-status.json','after-status.json','before-metrics.json','after-metrics.json','before-fresh-drain.json','post-client-fresh-drain.json','post-readback-fresh-drain.json','requested-config.json','run/report.json','result.json','cleanup.json','client-identity.json','client-exit.json','fixture/diagnostic-retention-budget.json','fixture/tmpfs-retention.json']:
        files[str(d/name)]=pin(d/name)
c.require(rows[0]['directory']==c.read(HERE/'row-zero-binding.json')['original_row'] and len({r['directory'] for r in rows})==16,'original first row/unique directories differ')
for p in [OUT/n for n in ['summary.json','before.json','after.json','isolation.json','invocation.json','cohorts/plan.json','cohorts/matrix.json']]+[HERE/n for n in ['inventory.final.json','row-zero-binding.json','capture.py','continuation.py','isolate-and-run.py','inherited-driver.py','protocol.json','ROOT-COMMANDS.json','runtime-tool-terminal.json','launch-child-terminal.json']]:files[str(p)]=pin(p)
for role in ['old','new']:
    d=Path(matrix['source_bindings'][role]['build_directory'])
    for name in ['build.json','kv9-cargo.jsonl']:files[str(d/name)]=pin(d/name)
save('analysis-inputs.json',files)
manifest=dict(schema_version=1,source_revision=matrix['source_revision'],role_features={'default':[],'diagnostic':['write-path-diagnostics']},input_inventory=dict(path=str(HERE/'analysis-inputs.json'),**pin(HERE/'analysis-inputs.json')),rows=rows)
save('analysis-manifest.json',manifest)
s=os.statvfs('/tmp')
save('completed-capture.json',dict(complete=True,outer_summary=dict(path=str(OUT/'summary.json'),**pin(OUT/'summary.json')),manifest=dict(path=str(HERE/'analysis-manifest.json'),**pin(HERE/'analysis-manifest.json')),cohorts=16,reused_ordinals=[0],newly_executed_ordinals=list(range(1,16)),original_root_remains_failed=True,original_available_before=matrix['available_before'],actual_available_after=s.f_bavail*s.f_frsize,retained_payload_bytes=retained_bytes,owned_lifetimes=lifetimes,health=health,scope='Existing full diagnostic acceptance and current lifecycle metadata; no new payload replay or offline analysis.'))
print(json.dumps({'complete':True,'manifest_path':str(HERE/'analysis-manifest.json'),'manifest_sha256':c.digest(HERE/'analysis-manifest.json'),'input_count':len(files),'input_bytes':sum(p['bytes'] for p in files.values()),'completed_capture_sha256':c.digest(HERE/'completed-capture.json'),'available_bytes':s.f_bavail*s.f_frsize}))
