"""Fixed row-zero continuation and narrowly typed initialization-read discovery."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def health(result, report):
    require(result['complete'] is True and report['complete'] is True, 'incomplete logical workload')
    require(not report['failure'] and not report['task_failures'] and report['dropped_slots'] == 0,
            'failed or dropped workload')
    phases = {'initialization', 'warmup', 'measurement', 'verification'}
    require(set(report['metrics']) == phases == set(result['population_observations']), 'phase scope differs')
    discovery = 0
    for phase, metrics in report['metrics'].items():
        require(metrics['valid'] is True, 'invalid population')
        require(metrics['attempt_outcomes'] == ['success','refused','failed_or_unknown'], 'attempt schema differs')
        require(metrics['outcomes'] == ['success','refused','unknown_write','read_failure','client_rejected'], 'outcome schema differs')
        require(len(metrics['statistics']) == 2, 'operation scope differs')
        if phase == 'initialization':
            require(metrics['operations'] == ['batch_get','batch_put'], 'initialization operation differs')
        counts, successes, attempts = [], [], []
        for index, op in enumerate(metrics['statistics']):
            logical = [p['calls'] for p in op['populations']]
            attempt = [p['raw']['count'] for p in op['attempts']]
            reasons = op['attempt_reasons']
            require(len(logical) == 5 and len(attempt) == 3 and len(reasons) == len(metrics['reasons']), 'counter schema differs')
            require(all(type(n) is int and n >= 0 for n in logical+attempt+reasons), 'invalid typed counter')
            calls = sum(logical); tries = sum(attempt)
            require(logical[0] == calls and attempt[0] == calls and attempt[2] == 0, 'non-success or unknown operation')
            expected = [0] * len(reasons)
            expected[metrics['reasons'].index('success')] = calls
            if phase == 'initialization' and index == 0:
                discovery = attempt[1]
                expected[metrics['reasons'].index('not_leader')] = discovery
            else:
                require(tries == calls, 'write or post-initialization retry')
            require(reasons == expected, 'retry reason is not initialization-read not_leader discovery')
            counts.append(calls); successes.append(logical[0]); attempts.append(tries)
        observed = result['population_observations'][phase]
        require(observed == dict(calls=counts,successes=successes,attempts=attempts,
                                 all_success=counts==successes,
                                 all_success_single_attempt=counts==successes==attempts), 'population observation differs')
    return {'initialization_read_discovery_retries': discovery, 'allowed_reason':'not_leader',
            'initialization_writes_single_attempt':True,'warmup_measurement_verification_single_attempt':True,
            'every_phase_logically_successful':True}

def gone(identity):
    require(type(identity['pid']) is int and type(identity['start_ticks']) is int and identity['boot_id'], 'missing lifetime')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != identity['boot_id']:
        return True
    try:
        current = Path('/proc')/str(identity['pid'])/'stat'
        start = int(current.read_text().rsplit(')',1)[1].split()[19])
    except FileNotFoundError:
        return True
    return start != identity['start_ticks']

def original(driver, rows, roles, policy):
    binding = read(HERE/'row-zero-binding.json')
    for name,pin in binding['files'].items():
        path=Path(name)
        require(path.is_file() and path.stat().st_size == pin['bytes'] and digest(path) == pin['sha256'], 'original metadata changed: '+name)
    root=Path(binding['original_root']); row=Path(binding['original_row'])
    plan=read(root/'cohorts/plan.json'); matrix=read(root/'cohorts/matrix.json')
    require(plan['available_before'] == binding['original_available_before'] == 28108746752, 'original budget baseline differs')
    require(plan['rows'] == rows and plan['source_bindings'] == roles and plan['policy'] == policy, 'original roles/workload/policy differs')
    require(matrix['complete'] is False and len(matrix['attempts']) == 1 and matrix['failure'] == "ValueError('non-success/retry cohort is not a healthy overhead comparison')", 'original failure scope differs')
    attempt=matrix['attempts'][0]; result=read(row/'result.json')
    require(attempt == dict(ordinal=0,directory=str(row),result=result), 'row zero binding differs')
    h=health(result,read(row/'run/report.json'))
    require(h['initialization_read_discovery_retries'] == 1, 'original discovery count differs')
    require(result['cleanup_complete'] and result['workload_complete'] and result['validated']['accepted'], 'original workload incomplete')
    require(result['report_sha256'] == digest(row/'run/report.json') and result['validated']['report_sha256'] == result['report_sha256'], 'report acceptance differs')
    require(result['server_binary_sha256'] == roles['old']['binary_sha256'] and result['client_binary_sha256'] == roles['client']['binary_sha256'], 'row binary roles differ')
    require(all('write_path_diagnostics' not in s for phase in ['before','after'] for s in read(row/(phase+'-status.json')).values()), 'original default observer feature present')
    summary=read(root/'summary.json')
    require(summary['complete'] is False and summary['restoration_complete'] is True and summary['child_exit_code'] == 1 and not summary['child_cleanup_errors'] and not summary['deferred_cleanup_signals'], 'original isolator did not restore')
    before=read(root/'before.json'); after=read(root/'after.json')
    require(not after['errors'] and before['containers'] == after['containers'] and before['clusters'] == after['clusters'], 'original isolation identities/restoration differ')
    cleanup=read(row/'cleanup.json'); client=read(row/'client-identity.json')
    require(cleanup['complete'] and len(cleanup['children']) == 4 and read(row/'client-exit.json')['exit_code'] == 0 and gone(client), 'original client/cleanup incomplete')
    require(all(c['absent'] and c['exit_code'] is not None and gone(c['identity']) for c in cleanup['children']), 'original writer lifetime remains')
    for name in ['before-fresh-drain.json','post-client-fresh-drain.json','post-readback-fresh-drain.json']:
        drain=read(row/name)
        require(drain['completed_unix_ns']-drain['started_unix_ns'] <= 20_000_000_000 and len(drain['final']) == 3, 'original fresh drain scope differs')
        for node,status in drain['final'].items():
            base=drain['baseline'][node]; first=drain['first_advances'][node]['status']
            require(int(status['metrics_export_successes']) > int(first['metrics_export_successes']) > int(base['metrics_export_successes']), 'original drain freshness differs')
            require(all(status[k]=='0' for k in driver.ZERO) and status['bootstrap']=='Serving' and status['fatal']=='' and status['raft_async_apply_stopped']==status['raft_async_read_stopped']=='false', 'original drain health differs')
    require(result['readback']['keys'] == 4097 and all(result['readback'][k] is True for k in ['sentinel_unchanged','deterministic_values_valid','deterministic_write_key_membership_checked']), 'original public readback differs')
    retention=read(row/'fixture/tmpfs-retention.json'); budget=read(row/'fixture/diagnostic-retention-budget.json')
    require(retention['complete'] and retention['children_exited'] and retention['scratch_removed'] and budget['full_readback'] and budget['original_available'] == plan['available_before'] and budget['bytes'] == sum(v['bytes'] for v in retention['files'].values()) <= policy['max_cohort_payload_bytes'], 'original retention scope differs')
    return binding, dict(attempt, health=h)
