import copy
import json
from pathlib import Path
import unittest
import continuation as c
import capture

ROOT=Path('/tmp/kv9-write-diagnostics-capture-20260915-first')
ROW=ROOT/'cohorts/00-default-point-r000-c1'

class ContinuationControls(unittest.TestCase):
    def setUp(self):
        self.result=c.read(ROW/'result.json'); self.report=c.read(ROW/'run/report.json')
    def sync(self):
        driver=capture.load('test_driver',capture.HERE/'inherited-driver.py')
        self.result['population_observations']=driver.population_observations(self.report,self.report['configuration'],False)
    def retry(self, phase, op, reason='not_leader'):
        m=self.report['metrics'][phase]; s=m['statistics'][op]
        s['attempts'][1]['raw']['count']+=1; s['attempt_reasons'][m['reasons'].index(reason)]+=1
        self.sync()
    def test_actual_successful_original(self):
        self.assertEqual(c.health(self.result,self.report)['initialization_read_discovery_retries'],1)
    def test_strict_single_attempt_positive(self):
        m=self.report['metrics']['initialization']; s=m['statistics'][0]
        s['attempts'][1]['raw']['count']=0;s['attempt_reasons'][m['reasons'].index('not_leader')]=0;self.sync()
        self.assertEqual(c.health(self.result,self.report)['initialization_read_discovery_retries'],0)
    def test_other_initialization_reasons_refused(self):
        for reason in ['deadline','rpc_status','protocol','client_capacity']:
            with self.subTest(reason=reason):
                self.setUp(); self.retry('initialization',0,reason)
                with self.assertRaises(ValueError): c.health(self.result,self.report)
    def test_write_retry_refused(self):
        self.retry('initialization',1)
        with self.assertRaises(ValueError):c.health(self.result,self.report)
    def test_post_initialization_retries_refused(self):
        for phase,op in [('warmup',1),('measurement',1),('verification',0)]:
            with self.subTest(phase=phase):
                self.setUp();self.retry(phase,op)
                with self.assertRaises(ValueError):c.health(self.result,self.report)
    def test_unknown_or_logical_failure_refused(self):
        self.report['metrics']['initialization']['statistics'][0]['populations'][3]['calls']=1;self.sync()
        with self.assertRaises(ValueError):c.health(self.result,self.report)
    def test_untyped_or_missing_counter_refused(self):
        self.report['metrics']['initialization']['statistics'][0]['attempt_reasons'][0]=True
        with self.assertRaises(ValueError):c.health(self.result,self.report)
    def test_missing_phase_refused(self):
        del self.report['metrics']['verification']
        with self.assertRaises(ValueError):c.health(self.result,self.report)
    def test_actual_fixed_original_binding(self):
        p=c.read(ROOT/'cohorts/plan.json'); d=capture.load('binding_driver',capture.HERE/'inherited-driver.py')
        b,row=c.original(d,capture.plan_rows(d),p['source_bindings'],capture.POLICY)
        self.assertEqual(row['ordinal'],0);self.assertEqual(b['original_available_before'],28108746752)
    def test_changed_rows_or_roles_refuse(self):
        p=c.read(ROOT/'cohorts/plan.json');d=capture.load('binding_bad_driver',capture.HERE/'inherited-driver.py')
        rows=copy.deepcopy(p['rows']);rows[1]['shared']['measure_ms']=1000
        with self.assertRaises(ValueError):c.original(d,rows,p['source_bindings'],capture.POLICY)
    def test_original_budget_still_charges_prior_spend(self):
        baseline=28108746752;limit=capture.POLICY['max_campaign_decrease_bytes']
        capture.check_space(baseline-limit,baseline)
        with self.assertRaises(ValueError):capture.check_space(baseline-limit-1,baseline)

if __name__=='__main__':unittest.main(verbosity=2)
