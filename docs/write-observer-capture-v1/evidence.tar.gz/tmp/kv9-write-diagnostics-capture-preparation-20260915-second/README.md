# Diagnostic capture continuation

The original observer wrapper remains failed (contextual tool session 49943, chunk 741a49, exit 1). Its saved summary proves restoration completed; no separate tool terminal was available. The exact successful original row 0 is retained in place and bound through 48 original metadata files, including report, public-readback pages, three fresh drains, lifecycle, retention and isolation receipts. Original payload readback remains historical evidence; no payload was decoded again.

The corrected predicate permits only typed `not_leader` retries for initialization batch reads. Every phase must succeed logically; initialization writes and all warmup, measured and verification operations remain single-attempt. Original row 0 has one such discovery retry. The existing driver, isolator, fixed client, sources, features, 16-row order and two-second diagnostic protocol remain unchanged. The new matrix contains original row 0 plus newly executed rows 1–15.

Capacity remains relative to the original 28,108,746,752-byte baseline: 8 GiB host floor, maximum 16 GiB sampled decrease, maximum 3 GiB per-row retained payload, and original tmpfs bounds. This is a shared-host observer diagnostic, not promotion or a ten-second performance acceptance screen.

Eleven focused controls passed at direct receipt ba08cb/0. Two earlier metadata-control failures are retained: cleanup includes the client as its fourth child; drain fields are `*_unix_ns` and `bootstrap_state`. Neither attempt executed a workload. ROOT-COMMANDS.json contains the exact authorized continuation invocation.
