import importlib.util
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture', HERE/'capture.py')
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
driver = capture.load('inherited_test_driver', HERE/'inherited-driver.py')


class CaptureContract(unittest.TestCase):
    def test_all_cells_both_orders_and_explicit_new_duration(self):
        rows = capture.plan_rows(driver)
        self.assertEqual(len(rows), 16)
        identity = lambda r: (r['shared']['workers'], r['shared']['batch_size'], r['mode'])
        first = [identity(r) for r in rows[:8]]
        self.assertEqual([identity(r) for r in rows[8:]], list(reversed(first)))
        self.assertEqual(set(first), {(c,b,m) for c in [1,64] for b in [1,64] for m in ['default','diagnostic']})
        self.assertEqual([r['ordinal'] for r in rows], list(range(16)))
        for row in rows:
            self.assertEqual(row['shared']['measure_ms'], 2000)
            self.assertEqual(row['shared']['keys'], 4096)
            self.assertEqual(row['shared']['value_bytes'], 128)
            self.assertEqual(row['shared']['seed'], 71)
            self.assertEqual(row['shared']['warmup_calls'], 128)
            self.assertEqual(row['write_api'], 'point_put' if row['shared']['batch_size']==1 else 'batch_put')
        self.assertTrue(all(r['shared']['measure_ms']==10000 for r in driver.make_plan(False)))

    def test_space_floor_includes_the_prospective_retained_copy(self):
        floor = capture.POLICY['host_floor_bytes']
        capture.check_space(floor+100, floor+100, 100)
        with self.assertRaises(ValueError):
            capture.check_space(floor+100, floor+100, 101)

    def test_space_budget_remains_relative_to_original_campaign_baseline(self):
        floor = capture.POLICY['host_floor_bytes']
        budget = capture.POLICY['max_campaign_decrease_bytes']
        capture.check_space(floor+100, floor+budget, 100)
        with self.assertRaises(ValueError):
            capture.check_space(floor+100, floor+budget+1, 100)

    def test_invalid_budget_inputs_refuse(self):
        for args in [(True, 10, 0), (10., 10, 0), (10,10,-1)]:
            with self.assertRaises(ValueError):
                capture.check_space(*args)


if __name__ == '__main__':
    unittest.main()
