All16 offline diagnostic rows accepted by the unchanged checker (9465de/0). The original row0 remains reused at its first-run path. Capture continuation7565/275fe1/0 and restoration are separate parent-owned acceptance receipts.

The eight instrumented endpoint leaders are node2 at both boundaries. Their whole-capture observations are:

| API | c | Order | Mean commands/group | Singleton groups | Mean requests/nonempty service | Mean logical probes/lookup | Miss fraction | Mean hit slots behind tail |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Put | 1 | 0 | 1.000 | 100.00% | 1.000 | 1013.285 | 56.10% | 0.000 |
| BatchPut64 | 1 | 0 | 1.000 | 100.00% | 1.000 | 981.699 | 50.04% | 0.000 |
| Put | 64 | 0 | 11.116 | 27.80% | 27.608 | 1021.855 | 86.00% | 11.475 |
| BatchPut64 | 64 | 0 | 15.162 | 14.19% | 36.578 | 1008.689 | 85.41% | 12.231 |
| BatchPut64 | 64 | 1 | 15.133 | 13.37% | 36.827 | 1010.085 | 84.08% | 11.842 |
| Put | 64 | 1 | 10.968 | 27.53% | 27.246 | 1021.898 | 86.11% | 11.263 |
| BatchPut64 | 1 | 1 | 1.000 | 100.00% | 1.000 | 981.729 | 50.04% | 0.000 |
| Put | 1 | 1 | 1.000 | 100.00% | 1.000 | 1013.181 | 56.00% | 0.000 |

At c1 every observed successful application group and nonempty extracted queue has one command/request. A BatchPut64 command still contains64 input items; it is one Raft command, not64 commands. At c64 both APIs have group p99 bounds32–63 commands and an observed maximum64. Put median group bounds are4–7; BatchPut64 median bounds are8–15.

All24 instrumented per-node deltas have zero failed pumps, canceled, expired and closed branches. Every conservation and joint-table check passed. Joint co-occurrence includes zero-apply turns that can resolve earlier requests; it does not equate application groups with client completion batches.

Lookup probes are close to the1024-entry ring length even though successful c64 hits average about11–12 slots behind the tail. Miss fractions are about86% for c64 Put and84–85% for c64 BatchPut64. These are repeated whole-capture lookup events, not failed client writes. They establish long logical scans, not CPU-cost shares, exclusive timing or a predicted optimization speedup.

Ages are registration-to-inspection observations, not RPC latency. c64 resolved-age means are about269–271us for Put and2.73–2.79ms for BatchPut64; their p99 bucket bounds are262.144–524.287us and4.194304–8.388607ms respectively. Repeated pending inspections contribute repeatedly to inspection ages.

Limits: the snapshots cover prefill/setup inside the boundaries, warmup, measurement, completion tail, drains and dataset readback. They do not isolate the nominal two-second interval. Endpoint leader identity does not prove continuous leadership. Driver/Ready snapshots are independent. Instrumentation can perturb timing/grouping. Default rows correctly lack the diagnostic feature line. This is observer qualification and event analysis, not the original ten-second promotion screen or a new baseline selection.

result.json retains all20 distributions with units per node and all joint cells; observations.json is a compact projection with source-result pin. input-hashes.json binds the144 consumed capture files plus manifest/inventory. No workload, codec, source test or passed control was rerun.
