#!/usr/bin/env python3
"""Offline schema-1 write observations. No database, procfs or codec execution."""
import argparse
import hashlib
import json
import re
from pathlib import Path

U64 = (1 << 64) - 1
METRICS = [
    ('committed_entries_taken_per_pump', 'entries'),
    ('applied_commands_per_pump', 'commands'),
    ('successful_apply_group_commands', 'commands'),
    ('successful_apply_group_encoded_bytes', 'bytes'),
    ('async_requests_extracted_per_service', 'requests'),
    ('async_requests_inspected_per_service', 'requests'),
    ('async_requests_resolved_per_service', 'requests'),
    ('async_requests_canceled_per_service', 'requests'),
    ('async_requests_expired_per_service', 'requests'),
    ('async_requests_requeued_per_service', 'requests'),
    ('async_requests_closed_during_service', 'requests'),
    ('async_request_inspection_age', 'nanoseconds'),
    ('async_request_resolved_age', 'nanoseconds'),
    ('receipt_ring_length_at_lookup', 'receipts'),
    ('receipt_linear_probes_per_lookup', 'receipts'),
    ('receipt_hit_slots_behind_tail', 'receipts'),
    ('receipt_hit_index_distance_from_tail', 'log_indexes'),
]
READY = [(n, 'entries') for n in ('ready_entries_to_persist', 'ready_committed_entries', 'light_ready_committed_entries')]
HEADER = dict(schema_version=1, snapshot_consistency='coherent_per_component_independent_between_components',
              bucket_rule='0=[0,0]; i>0=[2^(i-1),2^i-1]',
              joint_bucket_rule='0=[0,0]; 1..7=[2^(i-1),2^i-1]; 8=[128,infinity)')
COUNTERS = ('successful_pumps', 'failed_pumps', 'lookup_hits', 'lookup_misses')
IDENTITY = ('pid', 'process_start_ticks', 'process_boot_id', 'node_id', 'cluster_id', 'bootstrap_generation', 'root_digest', 'store_incarnation')
NODES = {'1', '2', '3'}
SCOPE = ('Before-status to after-status whole capture: setup/prefill, warmup, measurement, completion tail, fresh drains and final dataset readback where they fall between these boundaries. '
         'Initial fixture/keyspace setup before the first snapshot is excluded. Not the nominal two-second window; no exclusive CPU/service-time or per-client-causality claim. '
         'Ages begin at registration after proposal and count repeated inspections. Lookup callers are not limited to async service. '
         'Applied commands and resolved requests include non-client-success outcomes. Driver/Ready are separately coherent; no cross-component equality is inferred.')

class Refusal(ValueError): pass
def need(condition, message):
    if not condition: raise Refusal(message)
def exact_keys(d, keys): need(type(d) is dict and set(d) == set(keys), 'field inventory mismatch')
def uint(n): need(type(n) is int and 0 <= n <= U64, 'expected exact unsigned u64'); return n
def decimal(n):
    need(type(n) is str and re.fullmatch(r'0|[1-9][0-9]*', n) is not None, 'expected canonical decimal status field')
    return uint(int(n))
def add(values): return uint(sum(values))
def object_pairs(pairs):
    d = {}
    for k,v in pairs:
        need(k not in d, 'duplicate JSON object key'); d[k] = v
    return d
def loads(text):
    try: return json.loads(text, object_pairs_hook=object_pairs, parse_constant=lambda x: (_ for _ in ()).throw(Refusal('nonfinite JSON number')))
    except (ValueError, TypeError) as e: raise Refusal('malformed JSON: '+str(e)) from e
def limits(i): return (0, 0) if i == 0 else (1 << (i-1), (1 << i)-1)
def population(count, total, buckets):
    uint(count); uint(total)
    need(type(buckets) is list and len(buckets) == 65, '65 distribution buckets required')
    for n in buckets: uint(n)
    need(add(buckets) == count, 'histogram count/bucket mismatch')
    lower = sum(n*limits(i)[0] for i,n in enumerate(buckets))
    upper = sum(n*limits(i)[1] for i,n in enumerate(buckets))
    need(lower <= total <= upper, 'sum outside histogram bounds')
    return lower, upper
def distribution(d, name, unit):
    exact_keys(d, ('name','unit','buckets','count','sum','max','saturated'))
    need(d['name'] == name and d['unit'] == unit, 'metric name/unit mismatch')
    need(d['saturated'] is False, 'saturated distribution')
    lo, hi = population(d['count'], d['sum'], d['buckets'])
    if d['count'] == 0: need(d['max'] is None, 'empty population maximum')
    else:
        mx = uint(d['max']); top = max(i for i,n in enumerate(d['buckets']) if n)
        need(limits(top)[0] <= mx <= limits(top)[1] and mx <= d['sum'] <= d['count']*mx, 'maximum inconsistent')
        need(lo + mx-limits(top)[0] <= d['sum'] <= sum(n*min(limits(i)[1],mx) for i,n in enumerate(d['buckets'])), 'maximum/sum/buckets inconsistent')
    return d
def matrix(m):
    need(type(m) is list and len(m) == 9 and all(type(r) is list and len(r) == 9 for r in m), 'joint table shape')
    for r in m:
        for v in r: uint(v)
    return m
def collapsed(buckets): return buckets[:8] + [add(buckets[8:])]

def conservation(driver, ready):
    d = driver['distributions']; counters = {k:uint(driver[k]) for k in COUNTERS}
    successful = counters['successful_pumps']; failed = counters['failed_pumps']
    need(d[0]['count'] == d[1]['count'] == add([successful, failed]), 'pump sample count')
    need(d[2]['count'] == d[3]['count'] and d[2]['sum'] == d[1]['sum'], 'apply group population/command sum')
    need(d[2]['buckets'][0] == d[3]['buckets'][0] == 0, 'successful apply group cannot be empty')
    need(all(x['count'] == successful for x in d[4:11]), 'service count must equal successful pumps')
    extracted, inspected, resolved, canceled, expired, pending, closed = [x['sum'] for x in d[4:11]]
    need(extracted == add([resolved,canceled,expired,pending,closed]), 'extracted service conservation')
    need(inspected == add([resolved,expired,pending,closed]), 'inspected service conservation')
    need(d[11]['count'] == inspected and d[12]['count'] == resolved, 'age/inspection count mismatch')
    need(d[12]['sum'] <= d[11]['sum'] and all(a<=b for a,b in zip(d[12]['buckets'],d[11]['buckets'])), 'resolved ages not subset of inspections')
    lookups = add([counters['lookup_hits'], counters['lookup_misses']])
    need(d[13]['count'] == d[14]['count'] == lookups, 'lookup population mismatch')
    need(d[15]['count'] == counters['lookup_hits'] and d[16]['count'] <= counters['lookup_hits'], 'hit population mismatch')
    need(d[13]['sum'] == add([d[14]['sum'],d[15]['sum']]), 'first-match probe/tail-slot conservation')
    need(d[14]['buckets'][0] <= counters['lookup_misses'], 'zero probes cannot be hits')
    m = matrix(driver['applied_vs_resolved']); row = [add(x) for x in m]; col = [add([m[i][j] for i in range(9)]) for j in range(9)]
    need(add(row) == successful, 'joint/successful-pump count mismatch')
    need(col == collapsed(d[6]['buckets']), 'joint resolved marginal mismatch')
    all_applied = collapsed(d[1]['buckets'])
    need(all(a<=b for a,b in zip(row,all_applied)) and add([b-a for a,b in zip(row,all_applied)]) == failed, 'joint applied marginal/failed-pump mismatch')
    need(len({x['count'] for x in ready}) == 1, 'Ready/LightReady population mismatch')
    return dict(service_extracted=extracted,service_inspected=inspected,service_resolved=resolved,service_canceled=canceled,service_expired=expired,service_requeued=pending,service_closed=closed,lookup_count=lookups,joint_total=successful,joint_rows=row,joint_columns=col)

def snapshot(s):
    exact_keys(s, (*HEADER, 'driver', 'ready'))
    need(type(s['schema_version']) is int and all(s[k] == v for k,v in HEADER.items()), 'schema/rules mismatch')
    d=s['driver']; exact_keys(d, ('valid','saturated','lookup_algorithm',*COUNTERS,'distributions','applied_vs_resolved'))
    need(d['valid'] is True and d['saturated'] is False and d['lookup_algorithm'] == 'first_match_linear_scan', 'invalid/saturated/unknown driver')
    for rows, inventory in ((d['distributions'],METRICS),(s['ready'],READY)):
        need(type(rows) is list and len(rows) == len(inventory), 'metric inventory count')
        for row,(name,unit) in zip(rows,inventory): distribution(row,name,unit)
    conservation(d,s['ready'])
    return s

def subtract(a,b):
    uint(a);uint(b);need(b>=a,'counter reset/nonmonotonic delta');return b-a
def delta_distribution(a,b):
    out=dict(name=a['name'],unit=a['unit'],count=subtract(a['count'],b['count']),sum=subtract(a['sum'],b['sum']),buckets=[subtract(x,y)for x,y in zip(a['buckets'],b['buckets'])])
    population(out['count'],out['sum'],out['buckets'])
    need(a['max'] is None or (b['max'] is not None and b['max']>=a['max']), 'maximum reset')
    if not out['count']: need(a['max']==b['max'],'maximum changed without samples')
    out['mean'] = out['sum']/out['count'] if out['count'] else None
    out['before_cumulative_max']=a['max'];out['after_cumulative_max']=b['max'];out['maximum_bounds']=None
    if out['count']:
        i=max(i for i,n in enumerate(out['buckets'])if n);lo,hi=limits(i);hi=min(hi,b['max'])
        if a['max'] is None or b['max']>a['max']:lo=hi=b['max']
        need(lo<=hi and lo<=out['sum']<=out['count']*hi,'delta maximum/sum mismatch')
        out['maximum_bounds']=dict(lower=lo,upper=hi)
    for percentile in (50,95,99):
        out['p'+str(percentile)]=None
        rank=(out['count']*percentile+99)//100
        if rank:
            seen=0
            for i,n in enumerate(out['buckets']):
                seen+=n
                if seen>=rank:
                    lo,hi=limits(i);out['p'+str(percentile)]=dict(lower=lo,upper=hi);break
    return out
def delta(before,after):
    snapshot(before);snapshot(after)
    a=before['driver'];b=after['driver']
    d={k:subtract(a[k],b[k])for k in COUNTERS}
    d['distributions']=[delta_distribution(x,y)for x,y in zip(a['distributions'],b['distributions'])]
    d['applied_vs_resolved']=[[subtract(x,y)for x,y in zip(ar,br)]for ar,br in zip(a['applied_vs_resolved'],b['applied_vs_resolved'])]
    ready=[delta_distribution(x,y)for x,y in zip(before['ready'],after['ready'])]
    checks=conservation(d,ready)
    return dict(driver=d,ready=ready,conservation=checks)

def status_identity(s,node):
    need(type(s)is dict and s.get('node_id')==node,'status node mismatch')
    for k in IDENTITY:need(type(s.get(k))is str and s[k]not in ('','unavailable','none'),'missing process/store identity')
    need(decimal(s['pid'])>0 and decimal(s['process_start_ticks'])>0,'invalid process identity')
    need(re.fullmatch('[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}',s['process_boot_id'])is not None,'boot identity')
    need(s.get('leader_id')in NODES and s.get('role')==('leader'if s['leader_id']==node else'follower'),'leader identity')
    need(s.get('fatal')==''and s.get('bootstrap_state')=='Serving','fatal/not serving status')
    need(s.get('metrics_export_failures_saturated')=='false'and s.get('metrics_export_last')=='success','invalid exporter status')
    for k in ('metrics_export_failures','metrics_export_successes','term'):decimal(s[k])
    return {k:s[k]for k in IDENTITY}
def pair(before,after,mode):
    need(type(before)is dict and type(after)is dict and set(before)==set(after)==NODES,'three exact status nodes required')
    need(mode in ('default','diagnostic'),'unknown build mode')
    out={}
    for node in sorted(NODES):
        a,b=before[node],after[node];identity=status_identity(a,node)
        need(identity==status_identity(b,node),'process/store lifetime changed')
        need(decimal(b['metrics_export_successes'])>decimal(a['metrics_export_successes']),'status export did not advance')
        need(b['metrics_export_failures']==a['metrics_export_failures'],'export failure during capture')
        need(decimal(b['term'])>=decimal(a['term']),'term reset')
        r=dict(identity=identity,leader_before=a['leader_id'],leader_after=b['leader_id'],role_before=a['role'],role_after=b['role'],term_before=a['term'],term_after=b['term'],endpoint_leader_unchanged=a['leader_id']==b['leader_id'],continuous_leadership_proven=False)
        if mode=='default':need('write_path_diagnostics'not in a and 'write_path_diagnostics'not in b,'default build exposed diagnostic feature line')
        else:
            need(type(a.get('write_path_diagnostics'))is str and type(b.get('write_path_diagnostics'))is str,'missing diagnostic feature line')
            r['delta']=delta(loads(a['write_path_diagnostics']),loads(b['write_path_diagnostics']))
        out[node]=r
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--manifest-sha256',required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    used={}
    def read(path,pin=None):
        path=Path(path);need(path.is_absolute()and path.is_file()and not path.is_symlink()and path.stat().st_size<=32*1024**2,'unsafe/large metadata input')
        b=path.read_bytes();observed=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());need(str(path)not in used or used[str(path)]==observed,'input mutated');used[str(path)]=observed
        if pin is not None:need(all(observed[k]==pin[k]for k in observed),'input hash/size differs')
        return loads(b)
    need(args.output.is_absolute()and args.output.parent==Path(__file__).resolve().parent,'output outside owned preparation')
    args.output.mkdir(exist_ok=False)
    result=dict(complete=False,scope=SCOPE,performance_promotion=False)
    try:
        manifest=read(args.manifest);need(used[str(args.manifest)]['sha256']==args.manifest_sha256,'manifest hash mismatch')
        need(manifest['schema_version']==1 and manifest['role_features']=={'default':[],'diagnostic':['write-path-diagnostics']},'feature/source authority')
        need(re.fullmatch('[0-9a-f]{40}',manifest['source_revision'])is not None,'source revision')
        authority=manifest['input_inventory'];inventory=read(authority['path'],authority)
        def bound(path):need(str(path)in inventory,'missing input inventory');return read(path,inventory[str(path)])
        rows=manifest['rows'];need(len(rows)==16,'exact16 diagnostic sweep rows')
        forward=[(mode,api,c,0)for c in (1,64)for api in ('Put','BatchPut64')for mode in ('default','diagnostic')]
        expected=forward+[(m,a,c,1)for m,a,c,_ in reversed(forward)]
        need([(r['mode'],r['api'],r['concurrency'],r['repeat'])for r in rows]==expected,'opposite-order matrix mismatch')
        need([r['ordinal']for r in rows]==list(range(16))and len({r['directory']for r in rows})==16,'duplicate/reordered rows')
        output=[]
        for r in rows:
            folder=Path(r['directory']);before=bound(folder/'before-status.json');after=bound(folder/'after-status.json');nodes=pair(before,after,r['mode'])
            ma=bound(folder/'before-metrics.json');mb=bound(folder/'after-metrics.json');need(set(ma)==set(mb)==NODES,'metrics node inventory')
            for n in NODES:
                a,b=ma[n],mb[n]
                for k in ('schema_version','node_id','process_id','exporter_created_unix_ns','reset','clock','duration_unit'):need(a[k]==b[k],'metrics exporter identity changed')
                need(uint(a['node_id'])==int(n)and uint(a['process_id'])==int(before[n]['pid']),'metrics/status writer mismatch')
                need(decimal(b['captured_unix_ns'])>decimal(a['captured_unix_ns'])and type(a['exporter_uptime_ns'])is int and b['exporter_uptime_ns']>a['exporter_uptime_ns'],'metrics capture did not advance')
                need(a['export_failures_saturated']is False and b['export_failures_saturated']is False and uint(a['export_failures_before_capture'])==uint(b['export_failures_before_capture']),'metrics export failure')
                nodes[n]['metrics_capture_before_unix_ns']=a['captured_unix_ns'];nodes[n]['metrics_capture_after_unix_ns']=b['captured_unix_ns'];nodes[n]['exporter_created_unix_ns']=a['exporter_created_unix_ns']
            drains=[]
            for label in ('before','post-client','post-readback'):
                d=bound(folder/(label+'-fresh-drain.json'));need(type(d['started_unix_ns'])is int and d['started_unix_ns']<d['completed_unix_ns']<=d['started_unix_ns']+20_000_000_000,'drain time bound')
                need(set(d['baseline'])==set(d['final'])==set(d['first_advances'])==NODES,'drain inventory')
                for n in NODES:
                    bs=d['baseline'][n];fs=d['first_advances'][n]['status'];end=d['final'][n]
                    need(all(status_identity(x,n)==nodes[n]['identity']for x in (bs,fs,end)),'drain writer changed')
                    need(decimal(bs['metrics_export_successes'])<decimal(fs['metrics_export_successes'])<decimal(end['metrics_export_successes']),'fresh two-export drain')
                    for x in (fs,end):
                        for k in ('public_rpc_in_flight','public_rpc_queued','public_rpc_running','public_rpc_encoded_bytes','raft_async_apply_queued','raft_async_apply_in_flight','raft_async_read_queued','raft_async_read_active','raft_async_read_in_flight'):need(x.get(k)=='0','drain queue nonempty')
                drains.append(dict(label=label,started_unix_ns=d['started_unix_ns'],completed_unix_ns=d['completed_unix_ns']))
            cfg=bound(folder/'requested-config.json');report=bound(folder/'run/report.json')
            for k,v in dict(workers=r['concurrency'],keys=4096,batch_size=1 if r['api']=='Put' else 64,value_bytes=128,seed=71,warmup_calls=128,measure_ms=2000,read_percent=0).items():need(cfg[k]==v,'diagnostic workload configuration differs')
            need(report['complete']is True and report['failure']is None,'capture workload incomplete')
            need(drains[0]['completed_unix_ns']<=report['measurement_start_unix_ns']and drains[1]['started_unix_ns']>=report['measurement_start_unix_ns']+report['cohort_elapsed_ns']and drains[1]['completed_unix_ns']<=drains[2]['started_unix_ns'],'drain/measurement ordering')
            joint=None
            if r['mode']=='diagnostic':joint=[[sum(nodes[n]['delta']['driver']['applied_vs_resolved'][i][j]for n in NODES)for j in range(9)]for i in range(9)]
            output.append(dict(**r,nodes=nodes,drain_receipts=drains,three_voter_joint=joint,three_voter_joint_total=sum(map(sum,joint))if joint else None,whole_capture_scope=SCOPE))
        result.update(complete=True,source_revision=manifest['source_revision'],role_features=manifest['role_features'],rows=output,diagnostic_samples=16,ordinary_promotion_screen=False)
        for path,pin in list(used.items()):read(path,pin)
    except BaseException as e:
        result['failure']=repr(e);raise
    finally:
        for name,obj in [('result.json',result),('input-hashes.json',used)]:
            with(args.output/name).open('x')as f:json.dump(obj,f,indent=2);f.write('\n')
    print(json.dumps(dict(complete=True,rows=len(output),source_revision=manifest['source_revision'],performance_promotion=False)))
if __name__=='__main__':main()
