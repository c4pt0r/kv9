import copy
import json
import unittest
import check as c

def dist(name,unit,values):
    b=[0]*65
    for n in values:b[n.bit_length()]+=1
    return dict(name=name,unit=unit,buckets=b,count=len(values),sum=sum(values),max=max(values)if values else None,saturated=False)
def sample(empty=False):
    values = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]] if empty else [
        [0,2,1],[0,2,1],[2,1],[200,100],[0,4],[0,3],[0,1],[0,1],[0,1],[0,1],[0,0],
        [10,20,30],[10],[3,3,0,1],[1,3,0,1],[2,0],[99,0]]
    driver=dict(valid=True,saturated=False,lookup_algorithm='first_match_linear_scan',successful_pumps=0 if empty else 2,failed_pumps=0 if empty else 1,lookup_hits=0 if empty else 2,lookup_misses=0 if empty else 2,distributions=[dist(n,u,v)for(n,u),v in zip(c.METRICS,values)],applied_vs_resolved=[[0]*9 for _ in range(9)])
    if not empty:driver['applied_vs_resolved'][0][0]=1;driver['applied_vs_resolved'][2][1]=1
    return dict(**c.HEADER,driver=driver,ready=[dist(n,u,[]if empty else v)for(n,u),v in zip(c.READY,([0,3],[0,2],[1,0]))])
def status(node,diagnostic=None,exports=1):
    d=dict(pid=str(100+int(node)),process_start_ticks='1000',process_boot_id='11111111-2222-3333-4444-555555555555',node_id=node,cluster_id='cluster',bootstrap_generation='generation',root_digest='root',store_incarnation='store'+node,leader_id='2',role='leader'if node=='2'else'follower',fatal='',bootstrap_state='Serving',metrics_export_failures_saturated='false',metrics_export_last='success',metrics_export_failures='0',metrics_export_successes=str(exports),term='1')
    if diagnostic is not None:d['write_path_diagnostics']=json.dumps(diagnostic)
    return d

class Controls(unittest.TestCase):
    def reject(self,change):
        s=sample();change(s)
        with self.assertRaises(c.Refusal):c.snapshot(s)
    def test_valid_conservation_and_independent_lookup_population(self):
        d=c.delta(sample(True),sample())
        self.assertEqual(d['conservation']['lookup_count'],4)
        self.assertEqual(d['conservation']['service_inspected'],3)
        self.assertEqual(d['conservation']['joint_total'],2)
        self.assertEqual(d['driver']['distributions'][11]['p99'],{'lower':16,'upper':31})
        self.assertEqual(d['driver']['distributions'][11]['mean'],20)
    def test_malformed_duplicate_and_nonfinite_json(self):
        for text in ('{','{"driver":1,"driver":2}','{"v":NaN}'):
            with self.subTest(text=text),self.assertRaises(c.Refusal):c.loads(text)
    def test_unsigned_exact_integer_overflow(self):
        for value in (-1,True,1.0,'1',c.U64+1):
            with self.subTest(value=value):self.reject(lambda s:s['driver'].__setitem__('lookup_hits',value))
    def test_schema_inventory_name_unit_and_rules(self):
        mutations=[lambda s:s.__setitem__('schema_version',True),lambda s:s.__setitem__('extra',0),lambda s:s['driver']['distributions'].pop(),lambda s:s['driver']['distributions'][1].__setitem__('name',c.METRICS[0][0]),lambda s:s['ready'][0].__setitem__('unit','bytes'),lambda s:s.__setitem__('bucket_rule','other'),lambda s:s['driver'].pop('failed_pumps')]
        for fn in mutations:
            with self.subTest(fn=fn):self.reject(fn)
    def test_invalid_saturation_flags(self):
        for fn in (lambda s:s['driver'].__setitem__('valid',False),lambda s:s['driver'].__setitem__('saturated',True),lambda s:s['ready'][0].__setitem__('saturated',True),lambda s:s['driver']['distributions'][0].__setitem__('saturated',0)):
            with self.subTest(fn=fn):self.reject(fn)
    def test_count_bucket_sum_and_max(self):
        for field,value in [('count',5),('sum',c.U64),('max',0),('buckets',[0]*64)]:
            with self.subTest(field=field):self.reject(lambda s:s['driver']['distributions'][0].__setitem__(field,value))
    def test_service_and_age_conservation(self):
        for index,values in [(4,[0,5]),(5,[0,2]),(11,[10,20]),(12,[20]),(10,[0,1])]:
            with self.subTest(index=index):self.reject(lambda s:s['driver']['distributions'].__setitem__(index,dist(*c.METRICS[index],values)))
    def test_pump_joint_marginals_and_ready(self):
        for fn in (lambda s:s['driver'].__setitem__('successful_pumps',3),lambda s:s['driver']['applied_vs_resolved'][0].__setitem__(0,2),lambda s:s['driver'].__setitem__('applied_vs_resolved',[[0]*8]*9),lambda s:s['driver']['applied_vs_resolved'].__setitem__(2,[0,0,1,0,0,0,0,0,0]),lambda s:s['ready'].__setitem__(0,dist(*c.READY[0],[0]))):
            with self.subTest(fn=fn):self.reject(fn)
    def test_probe_and_hit_conservation(self):
        for index,values in [(14,[1,2,0,1]),(15,[2]),(16,[99,0,1])]:
            with self.subTest(index=index):self.reject(lambda s:s['driver']['distributions'].__setitem__(index,dist(*c.METRICS[index],values)))
    def test_counter_reset(self):
        with self.assertRaises(c.Refusal):c.delta(sample(),sample(True))
        a=dist('x','u',[3]);b=dist('x','u',[1,1])
        with self.assertRaises(c.Refusal):c.delta_distribution(a,b)
    def test_delta_maximum_not_subtracted(self):
        a=dist('x','u',[100]);b=dist('x','u',[100,20])
        d=c.delta_distribution(a,b)
        self.assertEqual(d['maximum_bounds'],{'lower':16,'upper':31})
        d=c.delta_distribution(a,dist('x','u',[100,200]))
        self.assertEqual(d['maximum_bounds'],{'lower':200,'upper':200})
        self.assertIsNone(c.delta_distribution(a,a)['maximum_bounds'])
    def test_process_identity_and_feature_absence(self):
        a={n:status(n)for n in c.NODES};b={n:status(n,exports=2)for n in c.NODES}
        self.assertEqual(len(c.pair(a,b,'default')),3)
        for key,value in [('pid','999'),('process_start_ticks','999'),('process_boot_id','aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee')]:
            changed=copy.deepcopy(b);changed['1'][key]=value
            with self.subTest(key=key),self.assertRaises(c.Refusal):c.pair(a,changed,'default')
        b['1']['write_path_diagnostics']='{}'
        with self.assertRaises(c.Refusal):c.pair(a,b,'default')
        with self.assertRaises(c.Refusal):c.pair(a,a,'diagnostic')
    def test_diagnostic_status_delta(self):
        a={n:status(n,sample(True))for n in c.NODES};b={n:status(n,sample(),2)for n in c.NODES}
        self.assertEqual(c.pair(a,b,'diagnostic')['2']['delta']['conservation']['joint_total'],2)
        b['1']['write_path_diagnostics']='{}'
        with self.assertRaises(c.Refusal):c.pair(a,b,'diagnostic')

if __name__=='__main__':unittest.main(verbosity=2)
