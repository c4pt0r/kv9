#!/usr/bin/env python3
"""Summarize accepted observer captures; never promote a performance candidate."""
import argparse
import hashlib
import json
from pathlib import Path


def pin(path):
    data = Path(path).read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def percentile(buckets, percent):
    rank = (sum(buckets) * percent + 99) // 100
    if not rank:
        return None
    seen = 0
    for i, count in enumerate(buckets):
        seen += count
        if seen >= rank:
            if i < 64:
                return [i, i]
            exponent, part = divmod(i - 64, 64)
            lower = (64 + part) * 2**exponent
            return [lower, lower + 2**exponent - 1]
    raise ValueError('incomplete histogram population')


def timing(rows):
    calls = sum(r['calls'] for r in rows)
    elapsed = sum(r['elapsed_ns'] for r in rows)
    buckets = [sum(r['buckets'][i] for r in rows) for i in range(3776)]
    assert sum(buckets) == calls > 0
    return dict(calls=calls, input_items=sum(r['input_items'] for r in rows),
                elapsed_ns=elapsed, calls_per_second=calls * 1e9 / elapsed,
                input_items_per_second=sum(r['input_items'] for r in rows) * 1e9 / elapsed,
                mean_ns=sum(r['sum_ns'] for r in rows) / calls,
                p99_ns=percentile(buckets, 99))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--analysis', type=Path, required=True)
    ap.add_argument('--analysis-sha256', required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    assert __debug__ and not args.output.exists()
    assert pin(args.analysis)['sha256'] == args.analysis_sha256
    analysis = json.loads(args.analysis.read_text())
    assert analysis['complete'] is True and analysis['performance_promotion'] is False
    authority_path = args.analysis.parent / 'input-hashes.json'
    authority = json.loads(authority_path.read_text())
    inputs = {str(args.analysis): pin(args.analysis), str(authority_path): pin(authority_path)}
    measured, observed = [], []
    for row in analysis['rows']:
        path = Path(row['directory']) / 'run/report.json'
        actual = pin(path)
        assert actual == authority[str(path)]
        inputs[str(path)] = actual
        report = json.loads(path.read_text())
        op = report['metrics']['measurement']['statistics'][1]
        success = op['populations'][0]
        raw = success['whole_call']['raw']
        assert raw['count'] == success['calls'] == report['measured_issued'] == report['measured_completed']
        assert sum(p['calls'] for p in op['populations'][1:]) == 0
        assert sum(h['raw']['count'] for h in op['attempts']) == success['calls']
        assert report['dropped_slots'] == 0 and raw['valid'] is True
        measured.append(dict(ordinal=row['ordinal'], mode=row['mode'], api=row['api'],
                             concurrency=row['concurrency'], repeat=row['repeat'],
                             calls=success['calls'], input_items=success['input_items'],
                             elapsed_ns=report['cohort_elapsed_ns'], sum_ns=raw['sum_ns'],
                             buckets=raw['buckets']))
        if row['mode'] != 'diagnostic':
            continue
        leaders = [(node, value) for node, value in row['nodes'].items()
                   if value['role_before'] == value['role_after'] == 'leader'
                   and value['endpoint_leader_unchanged']]
        assert len(leaders) == 1
        node, value = leaders[0]
        delta = value['delta']
        driver = delta['driver']
        distributions = {d['name']: d for d in driver['distributions']}
        extracts = distributions['async_requests_extracted_per_service']
        nonempty = extracts['count'] - extracts['buckets'][0]
        group = distributions['successful_apply_group_commands']
        observed.append(dict(ordinal=row['ordinal'], api=row['api'], concurrency=row['concurrency'],
                             repeat=row['repeat'], endpoint_leader=node,
                             continuous_leadership_proven=False,
                             successful_pumps=driver['successful_pumps'], failed_pumps=driver['failed_pumps'],
                             lookup_hits=driver['lookup_hits'], lookup_misses=driver['lookup_misses'],
                             lookup_miss_fraction=driver['lookup_misses'] / (driver['lookup_hits'] + driver['lookup_misses']),
                             nonempty_service_count=nonempty,
                             nonempty_extracted_mean=extracts['sum'] / nonempty if nonempty else None,
                             singleton_group_fraction=group['buckets'][1] / group['count'],
                             conservation=delta['conservation'], distributions=distributions,
                             ready=delta['ready'], applied_vs_resolved=driver['applied_vs_resolved'],
                             scope=row['whole_capture_scope']))
    comparisons = []
    for api in ('Put', 'BatchPut64'):
        for concurrency in (1, 64):
            selected = [r for r in measured if (r['api'], r['concurrency']) == (api, concurrency)]
            modes = {mode: timing([r for r in selected if r['mode'] == mode]) for mode in ('default', 'diagnostic')}
            changes = []
            for repeat in (0, 1):
                pair = {r['mode']: timing([r]) for r in selected if r['repeat'] == repeat}
                changes.append(dict(repeat=repeat, **pair,
                                    throughput_change_percent=100 * (pair['diagnostic']['calls_per_second'] / pair['default']['calls_per_second'] - 1)))
            comparisons.append(dict(api=api, concurrency=concurrency, **modes, paired=changes,
                                    throughput_change_percent=100 * (modes['diagnostic']['calls_per_second'] / modes['default']['calls_per_second'] - 1),
                                    mean_latency_change_percent=100 * (modes['diagnostic']['mean_ns'] / modes['default']['mean_ns'] - 1)))
    result = dict(complete=True, source_revision=analysis['source_revision'],
                  scope='Two-second observer overhead and whole-capture event observations; no new baseline or promotion.',
                  performance_promotion=False, comparisons=comparisons, observations=observed,
                  measured_calls=sum(r['calls'] for r in measured),
                  measured_input_items=sum(r['input_items'] for r in measured),
                  inputs=inputs, summarizer=pin(__file__))
    for path, expected in inputs.items():
        assert pin(path) == expected
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('observations', 'inputs')}))


if __name__ == '__main__':
    main()
