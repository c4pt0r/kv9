#!/usr/bin/env python3
"""Publish original small observer records without copying retained WAL payloads."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

OUT = Path('/home/dongxu/kv9/docs/write-observer-capture-v1')
OUT.mkdir(exist_ok=False)
PREP = Path('/tmp/kv9-write-diagnostics-capture-preparation-20260915-second')
inventory = json.loads((PREP/'analysis-inputs.json').read_text())
files = set(Path(p) for p in inventory)
roots = [
    'kv9-write-diagnostics-capture-preparation-20260915-first',
    'kv9-write-diagnostics-capture-preparation-20260915-second',
    'kv9-write-diagnostics-analysis-20260915-first',
    'kv9-write-observer-report-20260915-first',
    'kv9-write-diagnostics-release-root-20260915-first',
    'kv9-write-diagnostics-release-root-20260915-second',
    'kv9-write-diagnostics-release-default-20260915-first',
    'kv9-write-diagnostics-release-default-20260915-second',
    'kv9-write-diagnostics-release-instrumented-20260915-second',
]
for name in roots:
    for p in (Path('/tmp')/name).rglob('*'):
        if p.is_file() and p.name not in ('kv9','unqualified-kv9'):
            files.add(p)
for name in ('kv9-write-diagnostics-capture-20260915-first','kv9-write-diagnostics-capture-20260915-second'):
    files.update(p for p in (Path('/tmp')/name).iterdir() if p.is_file())


def pin(p):
    data = p.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


members = {}
for p in sorted(files):
    assert not p.is_symlink() and p.stat().st_size <= 32*1024**2
    assert 'fixture/data' not in str(p) and p.read_bytes()[:4] != b'\x7fELF'
    record = pin(p)
    if str(p) in inventory:
        assert record == inventory[str(p)]
    members[str(p.relative_to('/'))] = dict(path=str(p), **record)

archive = OUT/'evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for member, entry in members.items():
        tar.add(entry['path'], arcname=member, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert tar.getnames() == list(members)
    for member in tar:
        raw = tar.extractfile(member).read()
        expected = members[member.name]
        assert len(raw) == expected['bytes']
        assert hashlib.sha256(raw).hexdigest() == expected['sha256']
with gzip.open(archive, 'rb') as f:
    while f.read(1024**2):
        pass
for member, entry in members.items():
    assert pin(Path(entry['path'])) == {k:entry[k] for k in ('bytes','sha256')}
shutil.copyfile('/tmp/kv9-write-observer-report-20260915-first/summary.json',OUT/'summary.json')
result = dict(complete=True,archive=pin(archive),member_count=len(members),
              uncompressed_member_bytes=sum(p['bytes'] for p in members.values()),
              all_members_and_gzip_stream_read_back=True,source_inputs_unchanged=True,
              excluded='Server/client executables, source checkouts and retained database payloads. Their identities remain in the original records.',
              members=members)
(OUT/'archive.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'}))
