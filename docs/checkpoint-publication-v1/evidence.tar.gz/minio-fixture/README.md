# Isolated MinIO protocol fixture

Live endpoint: **http://127.0.0.1:32789**. Fresh bucket: **kv9-c04-tmpfs-6b7478a538**. Region: `us-east-1`.

Credentials: `/tmp/kv9-c04-minio-tmpfs-fixture-20260915-first/attempt-second/credentials.env` (mode0600, outside the repository). Read `MINIO_ROOT_USER` as access key and `MINIO_ROOT_PASSWORD` as secret key. Do not print, log, copy into evidence or commit this file. Credential values are absent from command metadata and this report.

Actual direct execution **8e230c / exit0** created the fresh bucket (HTTP200), acknowledged a1024-bytePUT (HTTP200), and read exactly the same bytes withGET (HTTP200). The fixture remains running for the parent's imminent test. It qualifies HTTP/object protocol and local KV WAL recovery integration only. Tmpfs does not qualify object-store crash/power-loss durability or full performance acceptance.

Container `0a5e647045482e1d3eaf650d9480fd946c8dbc9e76fa7b536ba67ba70eaa96c0`, name `/kv9-c04-minio-tmpfs-20260915-6b7478a538`, uses the already retained image `sha256:69b2ec208575b69597784255eec6fa6a2985ee9e1a47f4411a51f7f5fdd193a9`; nothing was pulled. Port publication is loopback-only. `/data` is a512MiBtmpfs; `/tmp` is16MiBtmpfs; image root is read-only. The container has a1GiBmemory/swap-total cap,256PIDcap,2CPUquota and helperCPUset6–15,22–31. Existing `kv9-minio-dev` identity/state/configuration remained unchanged.

The footprint snapshot recorded 77,824 allocated filesystem bytes in `/data`, 160,952,320 memory-cgroup bytes, and 0 writable-layer bytes. These are current observations, not post-test claims. No host data mount, RAID, reserved-block setting or historical guard changed.

Two preparation failures remain exact: **132ee8/1** encountered an absent optional `HostConfig.Tmpfs` key before credentials/container creation; **1ac4d0/1** created an owned container but never started it because Docker's local log driver rejects enabled compression with `max-file=1`. The successful fresh derivative explicitly sets `compress=false`. Its predecessor Created container is retained separately; neither failure is relabeled successful.

`cleanup.json` gives exact identity-scoped commands for the live fixture and the failed never-started container. Run them only after the parent's test/evidence collection finishes. No cleanup, Cargo, test suite, source change or unrelated container mutation was performed by this helper. All payload bytes here are new disposable fixture objects; historical benchmark evidence remains untouched.
