"""Owned 512 MiB MinIO protocol fixture. Credentials never enter argv or evidence."""
from pathlib import Path
import datetime,hashlib,hmac,json,os,secrets,stat,subprocess,time,urllib.request,urllib.error
P=Path(__file__).resolve().parent
IMAGE='sha256:69b2ec208575b69597784255eec6fa6a2985ee9e1a47f4411a51f7f5fdd193a9'
BASE='kv9-minio-dev';suffix=secrets.token_hex(5)
NAME='kv9-c04-minio-tmpfs-20260915-'+suffix;BUCKET='kv9-c04-tmpfs-'+suffix
def save(name,v):
 with (P/name).open('x')as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def docker(*args):
 r=subprocess.run(['sudo','-n','docker',*args],capture_output=True,timeout=30)
 if r.returncode:raise RuntimeError('Docker operation failed: '+args[0]+' exit '+str(r.returncode))
 return r.stdout.decode().strip()
def selected_inspect(target):
 d=json.loads(docker('inspect',target))[0]
 return dict(id=d['Id'],image=d['Image'],name=d['Name'],state={k:d['State'][k]for k in ['Status','Running','Pid','StartedAt','ExitCode']},ports=d['NetworkSettings']['Ports'],tmpfs=d['HostConfig'].get('Tmpfs',{}),read_only_rootfs=d['HostConfig']['ReadonlyRootfs'],memory_bytes=d['HostConfig']['Memory'],memory_swap_bytes=d['HostConfig']['MemorySwap'],cpuset=d['HostConfig']['CpusetCpus'],nano_cpus=d['HostConfig']['NanoCpus'],pids_limit=d['HostConfig']['PidsLimit'],labels=d['Config']['Labels'])
def available():
 v=os.statvfs(P);return v.f_bavail*v.f_frsize
before=selected_inspect(BASE);free_before=available()
assert docker('image','inspect',IMAGE,'--format','{{.Id}}')==IMAGE
credential_path=P/'credentials.env';access=secrets.token_hex(16);secret=secrets.token_urlsafe(36)
fd=os.open(credential_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w')as f:
 f.write('MINIO_ROOT_USER='+access+'\nMINIO_ROOT_PASSWORD='+secret+'\nMINIO_BROWSER=off\nMINIO_UPDATE=off\nHOME=/tmp\n');f.flush();os.fsync(f.fileno())
assert stat.S_IMODE(credential_path.stat().st_mode)==0o600
argv=['run','--detach','--pull','never','--name',NAME,'--label','kv9.fixture.owner=c04-minio-tmpfs-20260915','--label','kv9.fixture.scope=http-object-protocol-only','--read-only','--tmpfs','/data:rw,nosuid,nodev,noexec,size=536870912,mode=0700','--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=16777216,mode=1777','--memory','1073741824','--memory-swap','1073741824','--pids-limit','256','--cpuset-cpus','6-15,22-31','--cpus','2','--publish','127.0.0.1::9000','--env-file',str(credential_path),'--log-driver','local','--log-opt','max-size=1m','--log-opt','max-file=1','--log-opt','compress=false',IMAGE,'server','/data','--address',':9000','--quiet']
save('invocation.json',dict(argv=['sudo','-n','docker',*argv],credential_file=str(credential_path),credentials_excluded_from_metadata=True,existing_container_before=before,host_available_before=free_before))
cid=None
try:
 cid=docker(*argv);own=selected_inspect(cid);assert own['image']==IMAGE and own['name']=='/'+NAME
 mappings=own['ports']['9000/tcp'];assert len(mappings)==1 and mappings[0]['HostIp']=='127.0.0.1'
 endpoint='http://127.0.0.1:'+mappings[0]['HostPort'];host='127.0.0.1:'+mappings[0]['HostPort']
 started=time.monotonic()
 while True:
  try:
   with urllib.request.urlopen(endpoint+'/minio/health/live',timeout=2)as r:assert r.status==200
   break
  except (OSError,AssertionError):
   if time.monotonic()-started>40:raise RuntimeError('Owned MinIO health deadline exceeded')
   time.sleep(.25)
 def request(method,path,body=b''):
  now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ');date=stamp[:8];payload=hashlib.sha256(body).hexdigest()
  headers={'host':host,'x-amz-content-sha256':payload,'x-amz-date':stamp};signed=';'.join(sorted(headers));canonical_headers=''.join(k+':'+headers[k]+'\n'for k in sorted(headers))
  canonical='\n'.join([method,path,'',canonical_headers,signed,payload]);scope=date+'/us-east-1/s3/aws4_request'
  to_sign='AWS4-HMAC-SHA256\n'+stamp+'\n'+scope+'\n'+hashlib.sha256(canonical.encode()).hexdigest()
  def sign(key,msg):return hmac.new(key,msg.encode(),hashlib.sha256).digest()
  key=sign(sign(sign(sign(('AWS4'+secret).encode(),date),'us-east-1'),'s3'),'aws4_request')
  headers['authorization']='AWS4-HMAC-SHA256 Credential='+access+'/'+scope+', SignedHeaders='+signed+', Signature='+hmac.new(key,to_sign.encode(),hashlib.sha256).hexdigest()
  try:
   with urllib.request.urlopen(urllib.request.Request(endpoint+path,data=body if method=='PUT'else None,headers=headers,method=method),timeout=5)as r:return r.status,r.read(2048),r.headers.get('ETag')
  except urllib.error.HTTPError as e:raise RuntimeError('Signed '+method+' returned HTTP '+str(e.code))from None
 bucket_status,_,_=request('PUT','/'+BUCKET);assert bucket_status==200
 body=(b'kv9 C04 isolated object protocol fixture\n'*32)[:1024];key='fixture-acknowledged-put-get'
 put_status,_,etag=request('PUT','/'+BUCKET+'/'+key,body);assert put_status==200
 get_status,received,_=request('GET','/'+BUCKET+'/'+key);assert get_status==200 and received==body
 own=selected_inspect(cid);assert own['state']['Running']and own['state']['Pid']>0
 after=selected_inspect(BASE);assert after==before,'Existing MinIO identity/state/config changed'
 save('result.json',dict(complete=True,fixture_live=True,endpoint=endpoint,bucket=BUCKET,region='us-east-1',credential_file=str(credential_path),credential_format='Mode0600 env file: MINIO_ROOT_USER and MINIO_ROOT_PASSWORD map to access/secret keys. Do not print or commit.',container=own,bucket_create_status=bucket_status,acknowledged_put_status=put_status,get_status=get_status,probe=dict(key=key,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),etag=etag,readback_exact=True),existing_container_unchanged=True,host_available_before=free_before,host_available_after=available(),scope='HTTP/object protocol and local KV WAL recovery integration only. Tmpfs is volatile; not object-store crash/power-loss durability or full performance acceptance.',cleanup=dict(require_exact_container_id=cid,argv=['sudo','-n','docker','rm','--force',cid],warning='Only after root test/evidence collection is terminal. Removing this owned container discards its volatile fixture objects; existing MinIO and historical evidence are unaffected.')))
 print(json.dumps(dict(complete=True,endpoint=endpoint,bucket=BUCKET,credential_file=str(credential_path),container_id=cid,image=IMAGE,probe_bytes=len(body),scope='Protocol fixture only; container left running.'),sort_keys=True))
except BaseException as e:
 save('failure.json',dict(complete=False,error=repr(e),container_id=cid,container_name=NAME,credential_file=str(credential_path),scope='Credentials omitted; failed owned fixture is retained for explicit diagnosis/cleanup.'))
 raise
