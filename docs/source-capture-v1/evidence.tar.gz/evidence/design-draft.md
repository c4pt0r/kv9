# Unified-cut source capture (design draft)

Goal: under the driver owner on a data group's leader, produce the canonical
offline image (KV9DIMG1 = exact DataRange + checkpoint manifest, inside the
bounded protocol snapshot record) that the joint installer consumes and the
migration owners pin — at one exact, defensible cut.

## Invariants (predeclared)

1. **One cut, engine-defined.** The image cut C is the engine's durable
   applied position at freeze. The Snapshot metadata index/term equal the
   manifest cut exactly (installer already refuses otherwise).
2. **Configuration at-or-before the cut.** The attached ConfState is the
   committed configuration whose commit index ≤ C — looked up from the
   durable configuration history, never the current/latest ConfState. The
   engine's applied position may lag no-op/conf entries; attaching a later
   configuration to an older image is the named failure mode and must have
   a test + a Lean mutation control.
3. **Pin before upload.** The committed migration intent and both published
   MigrationOwners (subject = manifest digest, closure = SST set) precede
   any external PUT. The manifest is fully known before upload (plan on the
   frozen view), so the owner subject binds first; upload then PUT+verified-
   GETs exactly the pinned closure.
4. **Capture grants nothing.** The receipt (image bytes + digests) carries
   no serving, voting, release or install authority. Existing installer
   validation is unchanged; the destination revalidates everything.
5. **Term/HardState honesty.** The capture reports the term of the entry at
   C from durable storage. It does not fabricate election state; the
   HardState the installer receives binds cut/term/ConfState consistently
   under the installer's existing transition rules.
6. **Fail closed.** Freeze/plan/pin/upload failures leave a poisoned
   capture attempt with everything retained; retries re-derive from the
   engine, never reuse a partially uploaded closure without re-verification.

## Shape

- `crates/server` capture module: reach the group triple (driver, engine,
  storage) through RegionManager under the group lock discipline; require
  leader + committed migration intent for the group; freeze → plan →
  MigrationOwners::bind → upload → emit image.
- RPC `CaptureMigrationImage {root, operation}` → image bytes (≤2 MiB
  protocol record) + manifest digest + cut; CLI `capture-migration-image`.
- Tests: config-lag unit case (conf entry after C), leader/intent refusals,
  MemEngine+memory-store capture path if available, real-MinIO e2e closing
  capture → offline JointInstaller install at a prepared fourth store with
  value readback.

## Non-goals

No snapshot Ready coordination, no runtime installation/serving, no learner,
no release decision, no split publication, no new scaling claims.
