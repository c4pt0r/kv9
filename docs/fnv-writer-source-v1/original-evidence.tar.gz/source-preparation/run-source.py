#!/usr/bin/env python3
"""Root-only finite source supervisor; does not execute when imported."""
import argparse,hashlib,json,os,re,signal,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/kv9-fnv-writer-source-root-20260914-first')
SCRIPT=Path(__file__).with_name('check-source.py')
FLOOR=96*1024**3
RESERVATION=8*1024**3
def available():
 s=os.statvfs('/home/dongxu/kv9');return s.f_bavail*s.f_frsize
def main():
 assert __debug__
 ap=argparse.ArgumentParser();ap.add_argument('--expected-revision',required=True);ap.add_argument('--expected-script-sha256',required=True);args=ap.parse_args()
 assert re.fullmatch('[0-9a-f]{40}',args.expected_revision),'actual frozen source HEAD required'
 assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()==args.expected_script_sha256,'reviewed source checker changed'
 ROOT.mkdir(exist_ok=False)
 cmd=['taskset','-c','6-15,22-31','env','PYTHONDONTWRITEBYTECODE=1','PYTHONOPTIMIZE=0','python3',str(SCRIPT),'--expected-revision',args.expected_revision]
 start=available()
 r=dict(complete=False,argv=cmd,script_sha256=args.expected_script_sha256,expected_revision=args.expected_revision,
  started_ns=time.time_ns(),initial_available_bytes=start,minimum_available_bytes=FLOOR,additional_consumption_ceiling_bytes=RESERVATION,
  accounting='Conservative available-byte decrease including unrelated host writers; five-second samples and final sample',samples=[])
 p=None
 def sample():
  free=available();r['samples'].append(dict(unix_ns=time.time_ns(),available_bytes=free))
  if free<FLOOR or start-free>RESERVATION:raise RuntimeError('source qualification disk guard exceeded')
 try:
  if start-RESERVATION<FLOOR:raise RuntimeError('96 GiB floor plus 8 GiB source reservation cannot fit')
  with (ROOT/'source-first.log').open('x') as log:
   p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=p.pid
   (ROOT/'source-invocation.json').write_text(json.dumps(r,indent=2)+'\n')
   while True:
    if time.time_ns()-r['started_ns']>1800*1_000_000_000:raise RuntimeError('source command budget exceeded')
    sample()
    try:r['exit_code']=p.wait(timeout=5);break
    except subprocess.TimeoutExpired:pass
   sample()
   if r['exit_code']!=0:raise RuntimeError('source qualification failed')
  r['complete']=True
 except BaseException as error:
  r['failure']=repr(error)
  if p is not None and p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  raise
 finally:
  if p is not None:
   r['exit_code']=p.returncode;r['reaped']=p.poll() is not None;r['pid_absent']=not Path('/proc',str(p.pid)).exists()
  r['ended_ns']=time.time_ns();(ROOT/'source-result.json').write_text(json.dumps(r,indent=2)+'\n')
 print('PASS: source qualification completed within its 8 GiB reservation')
if __name__=='__main__':main()
