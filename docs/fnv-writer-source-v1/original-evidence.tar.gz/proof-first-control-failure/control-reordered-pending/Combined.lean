import Std

namespace Kv9.FnvInterleave

variable {State Byte : Type}

def scalar (step : State → Byte → State) (bytes : List Byte) (hash : State) : State :=
  bytes.foldl step hash

def four (step : State → Byte → State) : List Byte → List Byte → List Byte → List Byte →
    State → State → State → State → State × State × State × State
  | a::as, b::bs, c::cs, d::ds, h0, h1, h2, h3 =>
      four step as bs cs ds (step h0 a) (step h1 b) (step h2 c) (step h3 d)
  | as, bs, cs, ds, h0, h1, h2, h3 =>
      (scalar step as h0, scalar step bs h1, scalar step cs h2, scalar step ds h3)

theorem scalar_append (step : State → Byte → State) (as bs : List Byte) (hash : State) :
    scalar step (as ++ bs) hash = scalar step bs (scalar step as hash) := by
  exact List.foldl_append

/-- Arbitrary initial states, all lengths, unequal tails and empty lanes. -/
theorem four_equivalence (step : State → Byte → State)
    (as bs cs ds : List Byte) (h0 h1 h2 h3 : State) :
    four step as bs cs ds h0 h1 h2 h3 =
      (scalar step as h0, scalar step bs h1, scalar step cs h2, scalar step ds h3) := by
  induction as generalizing bs cs ds h0 h1 h2 h3 with
  | nil => rfl
  | cons a as ih =>
    cases bs with
    | nil => rfl
    | cons b bs =>
      cases cs with
      | nil => rfl
      | cons c cs =>
        cases ds with
        | nil => rfl
        | cons d ds =>
          simpa only [four, scalar, List.foldl_cons] using
            ih bs cs ds (step h0 a) (step h1 b) (step h2 c) (step h3 d)

/-- A common prefix and each lane's scalar tail consume the same full list. -/
theorem split_equivalence (step : State → Byte → State)
    (a0 a1 b0 b1 c0 c1 d0 d1 : List Byte) (h0 h1 h2 h3 : State) :
    let states := four step a0 b0 c0 d0 h0 h1 h2 h3
    four step a1 b1 c1 d1 states.1 states.2.1 states.2.2.1 states.2.2.2 =
      four step (a0 ++ a1) (b0 ++ b1) (c0 ++ c1) (d0 ++ d1) h0 h1 h2 h3 := by
  simp only [four_equivalence, scalar_append]

/-- Changing the other lanes cannot affect lane zero, including ragged inputs. -/
theorem lane_independence (step : State → Byte → State)
    (as bs cs ds bs' cs' ds' : List Byte) (h0 h1 h2 h3 h1' h2' h3' : State) :
    (four step as bs cs ds h0 h1 h2 h3).1 =
      (four step as bs' cs' ds' h0 h1' h2' h3').1 := by
  simp only [four_equivalence]

theorem common_length_bound (a b c d : Nat) :
    min (min (min a b) c) d ≤ a ∧ min (min (min a b) c) d ≤ b ∧
    min (min (min a b) c) d ≤ c ∧ min (min (min a b) c) d ≤ d := by
  omega

abbrev Word := BitVec 32
abbrev Octet := BitVec 8

def initial : Word := 0x811c9dc5
def prime : Word := 0x01000193
def fnvStep (hash : Word) (byte : Octet) : Word :=
  (hash ^^^ byte.zeroExtend 32) * prime

def checksum4 (as bs cs ds : List Octet) : Word × Word × Word × Word :=
  four fnvStep as bs cs ds initial initial initial initial

theorem checksum_equivalence (as bs cs ds : List Octet) :
    checksum4 as bs cs ds =
      (scalar fnvStep as initial, scalar fnvStep bs initial,
       scalar fnvStep cs initial, scalar fnvStep ds initial) := by
  exact four_equivalence fnvStep as bs cs ds initial initial initial initial

end Kv9.FnvInterleave

-- The checker prepends the exact, source-bound Interleave.lean kernel model.
namespace Kv9.FnvWriter

abbrev Body := List FnvInterleave.Octet
def budget : Nat := 65536
def bodyBytes (bodies : List Body) : Nat := (bodies.map List.length).sum

structure WriterState where
  written : List Body
  pending : List Body

def view (s : WriterState) : List Body := s.written ++ s.pending
def flush (s : WriterState) : WriterState := ⟨view s, []⟩
def push (s : WriterState) (b : Body) : WriterState := ⟨s.written, b :: s.pending⟩
def fits (s : WriterState) (b : Body) : Prop :=
  s.pending.length < 4 ∧ bodyBytes s.pending + b.length ≤ budget
instance (s : WriterState) (b : Body) : Decidable (fits s b) :=
  inferInstanceAs (Decidable (_ ∧ _))

def finishGroup (s : WriterState) : WriterState :=
  if s.pending.length = 4 then flush s else s

def stage (s : WriterState) (b : Body) : WriterState :=
  if b.length > budget then ⟨view s ++ [b], []⟩
  else
    let ready := if fits s b then s else flush s
    finishGroup (push ready b)

def bounded (s : WriterState) : Prop :=
  s.pending.length < 4 ∧ bodyBytes s.pending ≤ budget

theorem flush_view (s : WriterState) : view (flush s) = view s := by
  simp [view, flush]

theorem push_view (s : WriterState) (b : Body) : view (push s b) = view s ++ [b] := by
  simp [view, push, List.append_assoc]

theorem finishGroup_view (s : WriterState) : view (finishGroup s) = view s := by
  unfold finishGroup
  split
  · exact flush_view s
  · rfl

theorem stage_view (s : WriterState) (b : Body) : view (stage s b) = view s ++ [b] := by
  unfold stage
  split
  · simp [view]
  · rw [finishGroup_view, push_view]
    congr 1
    split
    · rfl
    · exact flush_view s

theorem fold_view (bodies : List Body) (s : WriterState) :
    view (bodies.foldl stage s) = view s ++ bodies := by
  induction bodies generalizing s with
  | nil => simp
  | cons b bs ih => simp only [List.foldl_cons, ih, stage_view]; simp [List.append_assoc]

theorem complete_stream (bodies : List Body) :
    (flush (bodies.foldl stage ⟨[], []⟩)).written = bodies := by
  simpa [flush, view] using fold_view bodies ⟨[], []⟩

theorem flush_bound (s : WriterState) : bounded (flush s) := by
  simp [bounded, flush, bodyBytes, budget]

theorem push_bound (s : WriterState) (b : Body) (h : fits s b) :
    (push s b).pending.length ≤ 4 ∧ bodyBytes (push s b).pending ≤ budget := by
  constructor
  · simp only [push, List.length_append, List.length_singleton]
    have := h.1
    omega
  · simpa [push, bodyBytes, List.map_append, List.sum_append] using h.2

theorem finishGroup_bound (s : WriterState)
    (h : s.pending.length ≤ 4 ∧ bodyBytes s.pending ≤ budget) : bounded (finishGroup s) := by
  unfold finishGroup
  split
  · exact flush_bound s
  · simp only [bounded]; constructor <;> omega

theorem stage_bound (s : WriterState) (b : Body) : bounded (stage s b) := by
  unfold stage
  split
  · simp [bounded, bodyBytes, budget]
  · rename_i small
    have valid : fits (if fits s b then s else flush s) b := by
      split
      · assumption
      · simp [fits, flush, bodyBytes]; omega
    exact finishGroup_bound _ (push_bound _ b valid)

theorem fold_bound (bodies : List Body) (s : WriterState) (h : bounded s) :
    bounded (bodies.foldl stage s) := by
  induction bodies generalizing s with
  | nil => exact h
  | cons b bs ih => exact ih (stage s b) (stage_bound s b)

/-- Matches Rust's subtraction guard without overflowing payload + 1. -/
theorem payload_guard (used payload : Nat) (h : used ≤ budget) :
    payload < budget - used ↔ used + (payload + 1) ≤ budget := by
  omega

/-- Failed encoding can leave pending bodies unwritten, never reordered. -/
theorem written_prefix (s : WriterState) : s.written.IsPrefix (view s) := by
  exact ⟨s.pending, rfl⟩

/-- A short write after complete frames leaves a prefix of the canonical bytes. -/
theorem partial_frame_prefix (done rest : List Body) (current : Body) (n : Nat) :
    (done.flatten ++ current.take n).IsPrefix ((done ++ current :: rest).flatten) := by
  refine ⟨current.drop n ++ rest.flatten, ?_⟩
  simp only [List.flatten_append, List.flatten_cons, List.append_assoc]
  rw [← List.append_assoc (current.take n) (current.drop n), List.take_append_drop]

def scalarHash (b : Body) := FnvInterleave.scalar FnvInterleave.fnvStep b FnvInterleave.initial

/-- Any deterministic existing length/checksum/body encoding is preserved. -/
theorem four_frames (encode : Body → FnvInterleave.Word → Body) (a b c d : Body) :
    let sums := FnvInterleave.checksum4 a b c d
    [encode a sums.1, encode b sums.2.1, encode c sums.2.2.1, encode d sums.2.2.2] =
      [encode a (scalarHash a), encode b (scalarHash b),
       encode c (scalarHash c), encode d (scalarHash d)] := by
  simp only [FnvInterleave.checksum_equivalence, scalarHash]

end Kv9.FnvWriter

#print axioms Kv9.FnvWriter.flush_view
#print axioms Kv9.FnvWriter.push_view
#print axioms Kv9.FnvWriter.finishGroup_view
#print axioms Kv9.FnvWriter.stage_view
#print axioms Kv9.FnvWriter.fold_view
#print axioms Kv9.FnvWriter.complete_stream
#print axioms Kv9.FnvWriter.flush_bound
#print axioms Kv9.FnvWriter.push_bound
#print axioms Kv9.FnvWriter.finishGroup_bound
#print axioms Kv9.FnvWriter.stage_bound
#print axioms Kv9.FnvWriter.fold_bound
#print axioms Kv9.FnvWriter.payload_guard
#print axioms Kv9.FnvWriter.written_prefix
#print axioms Kv9.FnvWriter.partial_frame_prefix
#print axioms Kv9.FnvWriter.four_frames
